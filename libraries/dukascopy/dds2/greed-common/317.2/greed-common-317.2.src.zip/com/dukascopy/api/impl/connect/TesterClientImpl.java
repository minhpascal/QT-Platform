/*      */ package com.dukascopy.api.impl.connect;
/*      */ 
/*      */ import com.dukascopy.api.DataType;
/*      */ import com.dukascopy.api.IChart;
/*      */ import com.dukascopy.api.IClientGUIListener;
/*      */ import com.dukascopy.api.ICurrency;
/*      */ import com.dukascopy.api.INewsFilter;
/*      */ import com.dukascopy.api.INewsFilter.NewsSource;
/*      */ import com.dukascopy.api.IStrategy;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.LoadingProgressListener;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.Period;
/*      */ import com.dukascopy.api.chart.IChartTheme;
/*      */ import com.dukascopy.api.chart.IChartTheme.ColoredElement;
/*      */ import com.dukascopy.api.feed.IFeedDescriptor;
/*      */ import com.dukascopy.api.impl.IndicatorContext;
/*      */ import com.dukascopy.api.plugins.Plugin;
/*      */ import com.dukascopy.api.strategy.IStrategyParameter;
/*      */ import com.dukascopy.api.system.Commissions;
/*      */ import com.dukascopy.api.system.IPreferences;
/*      */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*      */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*      */ import com.dukascopy.api.system.ISystemListener;
/*      */ import com.dukascopy.api.system.ITesterClient.DataLoadingMethod;
/*      */ import com.dukascopy.api.system.ITesterClient.InterpolationMethod;
/*      */ import com.dukascopy.api.system.ITesterReportData;
/*      */ import com.dukascopy.api.system.JFVersionException;
/*      */ import com.dukascopy.api.system.Overnights;
/*      */ import com.dukascopy.api.system.tester.ITesterExecution;
/*      */ import com.dukascopy.api.system.tester.ITesterGui;
/*      */ import com.dukascopy.api.system.tester.ITesterIndicatorsParameters;
/*      */ import com.dukascopy.api.system.tester.ITesterUserInterface;
/*      */ import com.dukascopy.api.system.tester.ITesterVisualModeParameters;
/*      */ import com.dukascopy.api.util.DateUtils;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*      */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*      */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*      */ import com.dukascopy.charts.data.datacache.customperiod.tick.LastTickLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.customticks.data.ICustomTicksLoadingDescriptor;
/*      */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*      */ import com.dukascopy.charts.persistence.ChartBean;
/*      */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.BalanceHistoricalTesterIndicator;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.EquityHistoricalTesterIndicator;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.ExecutionControl;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.IStrategyRunner;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.MinTradableAmounts;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.ProfLossHistoricalTesterIndicator;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.StrategyDataStorageImpl;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.StrategyRunner;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterAccount;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterChartData;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterDataLoader;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterFeedDataProvider;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterIndicatorWrapper;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterOrdersProvider;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterReport;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.listener.IInstrumentSubscriber;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.util.HistoricalTesterUtils;
/*      */ import com.dukascopy.dds2.greed.connection.GreedClientAuthorizationProvider;
/*      */ import com.dukascopy.dds2.greed.util.AbstractCurrencyConverter;
/*      */ import com.dukascopy.dds2.greed.util.IFilePathManager;
/*      */ import com.dukascopy.dds2.greed.util.IndicatorHelper;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*      */ import com.dukascopy.dds4.transport.client.TransportClient;
/*      */ import com.dukascopy.dds4.transport.common.mina.ITransportClient;
/*      */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*      */ import java.awt.Color;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.net.URL;
/*      */ import java.util.Calendar;
/*      */ import java.util.Currency;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.regex.Matcher;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ public class TesterClientImpl implements com.dukascopy.api.system.ITesterClient
/*      */ {
/*  105 */   private static final Logger LOGGER = LoggerFactory.getLogger(TesterClientImpl.class);
/*      */   
/*      */   public static final String HISTORY_SERVER_URL = "history.server.url";
/*      */   
/*      */   public static final String ENCRYPTION_KEY = "encryptionKey";
/*      */   public static final String SUPPORTED_INSTRUMENTS = "instruments";
/*      */   public static final String FEED_COMMISSION_HISTORY = "feed.commission.history";
/*      */   public static final String CACHE_NAME = "SINGLEJAR";
/*  113 */   private int chart_id = 0;
/*      */   
/*      */   private volatile ISystemListener systemListener;
/*      */   
/*      */   private TransportClient transportClient;
/*      */   
/*      */   private GreedClientAuthorizationProvider authorizationProvider;
/*      */   
/*  121 */   private Set<Instrument> instruments = new HashSet();
/*      */   
/*      */   private PrintStream out;
/*      */   
/*      */   private PrintStream err;
/*      */   private Properties serverProperties;
/*      */   private AuthorizationClient authorizationClient;
/*      */   private String sessionID;
/*      */   private String captchaId;
/*  130 */   private boolean connected = false;
/*      */   
/*      */   private String clientMode;
/*      */   private long strategyIdCounter;
/*  134 */   private Map<Long, StrategyStuff> strategies = new HashMap();
/*      */   
/*  136 */   private Period period = Period.TICK;
/*  137 */   private OfferSide offerSide = OfferSide.BID;
/*      */   
/*      */   private ITesterClient.InterpolationMethod interpolationMethod;
/*      */   
/*      */   private ITesterClient.DataLoadingMethod dataLoadingMethod;
/*      */   private long from;
/*      */   private long to;
/*  144 */   private ICurrency accountCurrency = Instrument.EURUSD.getSecondaryJFCurrency();
/*  145 */   private double deposit = 50000.0D;
/*  146 */   private int leverage = 100;
/*  147 */   private Commissions commission = new Commissions(false);
/*  148 */   private Overnights overnights = new Overnights(false);
/*      */   private boolean gatherReportData;
/*      */   private boolean eventLogEnabled;
/*      */   private boolean processingStatsEnabled;
/*  152 */   private int marginCutLevel = 200;
/*  153 */   private double mcEquity = 0.0D;
/*      */   
/*      */   private LinkedList<TesterIndicatorWrapper> indicatorsWrappers;
/*      */   
/*      */   private String userName;
/*      */   DDSChartsController ddsChartsController;
/*  159 */   private com.dukascopy.api.IConsole console = new com.dukascopy.api.ConsoleAdapter()
/*      */   {
/*      */     public PrintStream getOut() {
/*  162 */       return TesterClientImpl.this.out;
/*      */     }
/*      */     
/*      */     public PrintStream getErr()
/*      */     {
/*  167 */       return TesterClientImpl.this.err;
/*      */     }
/*      */   };
/*      */   
/*      */   public TesterClientImpl() {
/*  172 */     this.out = System.out;
/*  173 */     this.err = System.err;
/*  174 */     NotificationUtilsProvider.setNotificationUtils(new PrintStreamNotificationUtils(this.out, this.err));
/*      */     
/*  176 */     Calendar calendar = Calendar.getInstance(java.util.TimeZone.getTimeZone("GMT"));
/*  177 */     calendar.setTimeInMillis(System.currentTimeMillis());
/*  178 */     calendar.set(11, 0);
/*  179 */     calendar.set(12, 0);
/*  180 */     calendar.set(13, 0);
/*  181 */     calendar.set(14, 0);
/*  182 */     this.to = calendar.getTimeInMillis();
/*  183 */     calendar.add(6, -3);
/*  184 */     this.from = calendar.getTimeInMillis();
/*      */     
/*  186 */     this.dataLoadingMethod = ITesterClient.DataLoadingMethod.ALL_TICKS;
/*      */     
/*  188 */     this.ddsChartsController = DDSChartsControllerFactory.instance().getDefaultInstance();
/*      */   }
/*      */   
/*      */   public synchronized void connect(String jnlpUrl, String username, String password) throws Exception
/*      */   {
/*  193 */     connect(jnlpUrl, username, password, null);
/*      */   }
/*      */   
/*      */   public synchronized void connect(String jnlp, String username, String password, String pin) throws Exception
/*      */   {
/*  198 */     if (!this.connected) {
/*  199 */       String authServersCsv = getAuthServers(jnlp);
/*  200 */       if (this.sessionID == null) {
/*  201 */         this.sessionID = UUID.randomUUID().toString();
/*      */       }
/*  203 */       initAuthorizationClient(authServersCsv);
/*  204 */       String authResponse = authenticateAPI(username, password, this.sessionID, pin);
/*  205 */       Matcher matcher = AuthorizationClient.RESULT_PATTERN.matcher(authResponse);
/*  206 */       if (!matcher.matches()) {
/*  207 */         throw new IOException("Authentication procedure returned unexpected result [" + authResponse + "]");
/*      */       }
/*      */       
/*  210 */       String url = matcher.group(1);
/*  211 */       String ticket = matcher.group(7);
/*  212 */       this.serverProperties = this.authorizationClient.getAllProperties(username, ticket, this.sessionID);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  218 */       IFilePathManager fmanager = com.dukascopy.dds2.greed.util.FilePathManager.getInstance();
/*  219 */       fmanager.setStrategiesFolderPath(fmanager.getDefaultStrategiesFolderPath());
/*      */       
/*  221 */       com.dukascopy.charts.data.orders.OrdersProvider.createInstance(null);
/*      */       
/*  223 */       Set<String> supportedInstruments = (Set)this.serverProperties.get("instruments");
/*  224 */       List<String[]> feedCommissionHistory = (List)this.serverProperties.get("feed.commission.history");
/*  225 */       FeedDataProvider.createFeedDataProvider("SINGLEJAR", feedCommissionHistory, supportedInstruments);
/*      */       
/*      */ 
/*      */ 
/*  229 */       int semicolonIndex = url.indexOf(':');
/*  230 */       int port; String host; int port; if (semicolonIndex != -1) {
/*  231 */         String host = url.substring(0, semicolonIndex);
/*  232 */         int port; if (semicolonIndex + 1 >= url.length()) {
/*  233 */           LOGGER.warn("port not set, using default 443");
/*  234 */           port = 443;
/*      */         } else {
/*  236 */           port = Integer.parseInt(url.substring(semicolonIndex + 1));
/*      */         }
/*      */       } else {
/*  239 */         host = url;
/*  240 */         port = 443;
/*      */       }
/*      */       
/*  243 */       final Object LOCKER = new Object();
/*      */       
/*  245 */       com.dukascopy.dds4.transport.common.mina.ClientListener clientListener = new com.dukascopy.dds4.transport.common.mina.ClientListener()
/*      */       {
/*      */         public void feedbackMessageReceived(ITransportClient client, ProtocolMessage message)
/*      */         {
/*  249 */           TransportClient providedClient = (TransportClient)TransportClient.class.cast(client);
/*  250 */           if ((providedClient != null) && (
/*  251 */             (!providedClient.isOnline()) || (providedClient.isTerminated()) || (ObjectUtils.isNullOrEmpty(TesterClientImpl.this.transportClient)) || (!ObjectUtils.isEqual(providedClient.getSessionId(), TesterClientImpl.this.transportClient.getSessionId()))))
/*      */           {
/*      */ 
/*  254 */             return;
/*      */           }
/*      */           
/*  257 */           if (FeedDataProvider.getDefaultInstance() != null) {
/*  258 */             FeedDataProvider.getDefaultInstance().processMessage(message);
/*      */           }
/*      */         }
/*      */         
/*      */         public void disconnected(com.dukascopy.dds4.transport.common.mina.DisconnectedEvent disconnectedEvent)
/*      */         {
/*  264 */           if (FeedDataProvider.getDefaultInstance() != null) {
/*  265 */             FeedDataProvider.getDefaultInstance().disconnected();
/*      */           }
/*      */         }
/*      */         
/*      */         public void authorized(ITransportClient client)
/*      */         {
/*  271 */           TesterClientImpl.LOGGER.debug("Authorized");
/*  272 */           synchronized (LOCKER) {
/*  273 */             LOCKER.notifyAll();
/*      */           }
/*      */         }
/*      */       };
/*      */       
/*  278 */       if (this.authorizationProvider == null) {
/*  279 */         this.authorizationProvider = new GreedClientAuthorizationProvider(username, ticket, this.sessionID);
/*      */       } else {
/*  281 */         this.authorizationProvider.setSessionId(this.sessionID);
/*  282 */         this.authorizationProvider.setTicket(ticket);
/*  283 */         this.authorizationProvider.setLogin(username);
/*      */       }
/*      */       
/*  286 */       this.transportClient = new TransportClient();
/*  287 */       this.transportClient.setAddress(new java.net.InetSocketAddress(host, port));
/*  288 */       this.transportClient.addListener(clientListener);
/*  289 */       this.transportClient.setAuthorizationProvider(this.authorizationProvider);
/*  290 */       this.transportClient.setUseSsl(true);
/*  291 */       this.transportClient.connect();
/*      */       
/*  293 */       synchronized (LOCKER) {
/*  294 */         LOCKER.wait(5000L);
/*      */       }
/*      */       
/*  297 */       FeedDataProvider.getDefaultInstance().connectToHistoryServer(this.transportClient, username, "http://www.dukascopy.com/datafeed/", this.serverProperties.getProperty("encryptionKey", null), true);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  305 */       com.dukascopy.charts.math.indicators.IndicatorsProvider.createInstance(new IndicatorsSettingsStorage(username));
/*      */       
/*  307 */       this.connected = true;
/*  308 */       this.userName = username;
/*  309 */       fireConnected();
/*      */     }
/*      */   }
/*      */   
/*      */   private String getAuthServers(String jnlp) throws Exception {
/*  314 */     URL jnlpUrl = new URL(jnlp);
/*      */     
/*      */ 
/*  317 */     InputStream jnlpIs = jnlpUrl.openConnection().getInputStream();Throwable localThrowable2 = null;
/*  318 */     Document doc; try { javax.xml.parsers.DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  319 */       doc = builder.parse(jnlpIs);
/*      */     }
/*      */     catch (Throwable localThrowable1)
/*      */     {
/*  317 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*      */     }
/*      */     finally {
/*  320 */       if (jnlpIs != null) if (localThrowable2 != null) try { jnlpIs.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jnlpIs.close();
/*      */     }
/*  322 */     String authServersCsv = null;
/*  323 */     NodeList jnlpNodes = doc.getElementsByTagName("jnlp");
/*  324 */     if (jnlpNodes.getLength() < 1) {
/*  325 */       throw new Exception("Can't find jnlp element");
/*      */     }
/*  327 */     Element jnlpNode = (Element)jnlpNodes.item(0);
/*  328 */     NodeList resourcesNodes = jnlpNode.getElementsByTagName("resources");
/*  329 */     if (resourcesNodes.getLength() < 1) {
/*  330 */       throw new Exception("Can't find resources element");
/*      */     }
/*  332 */     Element resourcesNode = (Element)resourcesNodes.item(0);
/*  333 */     NodeList propertyNodes = resourcesNode.getElementsByTagName("property");
/*  334 */     for (int i = 0; i < propertyNodes.getLength(); i++) {
/*  335 */       Element propertyElement = (Element)propertyNodes.item(i);
/*      */       
/*  337 */       String nameAttribute = propertyElement.getAttribute("name");
/*  338 */       if ((nameAttribute != null) && (nameAttribute.trim().equals("jnlp.client.mode"))) {
/*  339 */         String clientMode = propertyElement.getAttribute("value").trim();
/*  340 */         if (!ObjectUtils.isNullOrEmpty(clientMode)) {
/*  341 */           this.clientMode = clientMode;
/*      */         }
/*  343 */       } else if ((nameAttribute != null) && (nameAttribute.trim().equals("jnlp.login.url"))) {
/*  344 */         authServersCsv = propertyElement.getAttribute("value").trim();
/*      */       }
/*      */     }
/*  347 */     if (authServersCsv == null) {
/*  348 */       throw new Exception("Can't find property with name attribute equals to jnlp.login.url");
/*      */     }
/*  350 */     return authServersCsv;
/*      */   }
/*      */   
/*      */   public BufferedImage getCaptchaImage(String jnlp) throws Exception
/*      */   {
/*  355 */     String authServersCsv = getAuthServers(jnlp);
/*  356 */     initAuthorizationClient(authServersCsv);
/*  357 */     Map<String, BufferedImage> imageCaptchaMap = this.authorizationClient.getImageCaptcha();
/*  358 */     if (!imageCaptchaMap.isEmpty()) {
/*  359 */       Map.Entry<String, BufferedImage> imageCaptchaEntry = (Map.Entry)imageCaptchaMap.entrySet().iterator().next();
/*  360 */       this.captchaId = ((String)imageCaptchaEntry.getKey());
/*  361 */       return (BufferedImage)imageCaptchaEntry.getValue();
/*      */     }
/*  363 */     return null;
/*      */   }
/*      */   
/*      */   private void initAuthorizationClient(String authServersCsv)
/*      */   {
/*  368 */     if (this.authorizationClient != null) {
/*  369 */       return;
/*      */     }
/*  371 */     String version = getClass().getPackage().getImplementationVersion();
/*  372 */     if (version == null) {
/*  373 */       version = "99.99.99";
/*      */     }
/*  375 */     if (version.endsWith("SNAPSHOT")) {
/*  376 */       version = "99.99.99";
/*      */     }
/*      */     
/*  379 */     String[] urlList = authServersCsv.split(",");
/*  380 */     List<String> authServers = java.util.Arrays.asList(urlList);
/*  381 */     this.authorizationClient = AuthorizationClient.getInstance(authServers, version);
/*      */   }
/*      */   
/*      */   private String authenticateAPI(String username, String password, String session, String pin) throws Exception
/*      */   {
/*      */     AuthorizationServerResponse authorizationServerResponse;
/*      */     AuthorizationServerResponse authorizationServerResponse;
/*  388 */     if (pin == null) {
/*  389 */       authorizationServerResponse = this.authorizationClient.getAPIsAndTicketUsingLogin(username, password, session, "DDS3_JFOREXSDK");
/*      */     } else {
/*  391 */       authorizationServerResponse = this.authorizationClient.getAPIsAndTicketUsingLogin(username, password, this.captchaId, pin, session, "DDS3_JFOREXSDK");
/*      */     }
/*      */     String authResponse;
/*  394 */     if (authorizationServerResponse != null) {
/*  395 */       authResponse = authorizationServerResponse.getFastestAPIAndTicket();
/*      */     } else {
/*  397 */       throw new IOException("Authentication failed, no server response.");
/*      */     }
/*      */     String authResponse;
/*  400 */     LOGGER.debug(authResponse);
/*      */     
/*  402 */     if (!authorizationServerResponse.isOK()) {
/*  403 */       AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode = authorizationServerResponse.getResponseCode();
/*      */       
/*  405 */       if (authorizationServerResponse.isEmptyResponse()) {
/*  406 */         throw new IOException("Authentication failed");
/*      */       }
/*      */       
/*  409 */       if ((AuthorizationClient.AuthorizationServerResponseCode.MINUS_ONE_OLD_ERROR == authorizationServerResponseCode) || (AuthorizationClient.AuthorizationServerResponseCode.AUTHENTICATION_AUTHORIZATION_ERROR == authorizationServerResponseCode))
/*      */       {
/*  411 */         throw new com.dukascopy.api.system.JFAuthenticationException("Incorrect username or password");
/*      */       }
/*      */       
/*  414 */       if (authorizationServerResponse.isWrongVersion()) {
/*  415 */         throw new JFVersionException("Incorrect version");
/*      */       }
/*      */       
/*  418 */       if (authorizationServerResponse.isNoAPIServers()) {
/*  419 */         throw new JFVersionException("System offline");
/*      */       }
/*      */       
/*  422 */       if (authorizationServerResponse.isSystemError()) {
/*  423 */         throw new JFVersionException("System error");
/*      */       }
/*      */       
/*  426 */       String message = authorizationServerResponseCode.getMessage();
/*  427 */       throw new com.dukascopy.api.JFException(message);
/*      */     }
/*      */     
/*  430 */     return authResponse;
/*      */   }
/*      */   
/*      */   public synchronized void reconnect()
/*      */   {
/*  435 */     if ((this.transportClient != null) && (!this.transportClient.isOnline())) {
/*  436 */       this.transportClient.connect();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void disconnect()
/*      */   {
/*  445 */     for (Long processId : getStartedStrategies().keySet()) {
/*  446 */       stopStrategy(processId.longValue());
/*      */     }
/*  448 */     if (FeedDataProvider.getDefaultInstance() != null) {
/*  449 */       FeedDataProvider.getDefaultInstance().close();
/*      */     }
/*      */     try {
/*  452 */       TimeUnit.SECONDS.sleep(5L);
/*      */     } catch (InterruptedException e) {}
/*  454 */     if (this.transportClient != null) {
/*  455 */       if (this.transportClient.isOnline()) {
/*      */         try {
/*  457 */           this.transportClient.controlRequest(new com.dukascopy.dds3.transport.msg.ddsApi.QuitRequestMessage());
/*      */         } catch (Throwable e) {
/*  459 */           LOGGER.error(e.getMessage(), e);
/*      */         }
/*      */       }
/*  462 */       this.transportClient.disconnect();
/*  463 */       this.transportClient.terminate();
/*  464 */       this.transportClient = null;
/*  465 */       this.authorizationProvider = null;
/*      */     }
/*  467 */     this.captchaId = null;
/*  468 */     this.sessionID = null;
/*  469 */     this.authorizationClient = null;
/*  470 */     this.serverProperties = new Properties();
/*  471 */     this.strategyIdCounter = 0L;
/*      */     
/*  473 */     this.period = Period.TICK;
/*  474 */     this.offerSide = OfferSide.BID;
/*  475 */     this.interpolationMethod = null;
/*  476 */     this.dataLoadingMethod = ITesterClient.DataLoadingMethod.ALL_TICKS;
/*  477 */     this.accountCurrency = Instrument.EURUSD.getSecondaryJFCurrency();
/*  478 */     this.deposit = 50000.0D;
/*  479 */     this.leverage = 100;
/*  480 */     this.commission = new Commissions(false);
/*  481 */     this.overnights = new Overnights(false);
/*  482 */     this.gatherReportData = false;
/*  483 */     this.eventLogEnabled = false;
/*  484 */     this.processingStatsEnabled = false;
/*  485 */     this.marginCutLevel = 200;
/*  486 */     this.mcEquity = 0.0D;
/*  487 */     this.connected = false;
/*      */   }
/*      */   
/*      */   public boolean isConnected()
/*      */   {
/*  492 */     return this.connected;
/*      */   }
/*      */   
/*      */   public synchronized void setSystemListener(final ISystemListener userSystemListener)
/*      */   {
/*  497 */     this.systemListener = new ISystemListener()
/*      */     {
/*      */       public void onStart(long processId) {
/*  500 */         userSystemListener.onStart(processId);
/*      */       }
/*      */       
/*      */       public void onStop(long processId) {
/*  504 */         userSystemListener.onStop(processId);
/*      */       }
/*      */       
/*      */       public void onConnect() {
/*  508 */         userSystemListener.onConnect();
/*      */       }
/*      */       
/*      */       public void onDisconnect() {
/*  512 */         userSystemListener.onDisconnect();
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addClientGUIListener(IClientGUIListener clientGuiListener) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeClientGUIListener(IClientGUIListener clientGuiListener) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public IChart openChart(IFeedDescriptor feedDescriptor)
/*      */   {
/*  529 */     throw new IllegalStateException("It's not designed to open charts in back-testing at the moment");
/*      */   }
/*      */   
/*      */   public void closeChart(IChart chart)
/*      */   {
/*  534 */     throw new IllegalStateException("It's not designed to close charts in back-testing at the moment");
/*      */   }
/*      */   
/*      */   public com.dukascopy.api.IClientGUI getClientGUI(IChart chart)
/*      */   {
/*  539 */     throw new IllegalStateException("It's not designed to open chart GUI in back-testing at the moment");
/*      */   }
/*      */   
/*      */   public synchronized void setStrategyEventsCallback(com.dukascopy.api.impl.StrategyEventsCallback strategyEventsCallback) {
/*  543 */     for (StrategyStuff strategyStuff : this.strategies.values()) {
/*  544 */       strategyStuff.strategyRunner.addStrategyEventsCallback(strategyEventsCallback);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fireConnected()
/*      */   {
/*  550 */     ISystemListener systemListener = this.systemListener;
/*  551 */     if (systemListener != null) {
/*  552 */       systemListener.onConnect();
/*      */     }
/*      */     
/*  555 */     FeedDataProvider.getDefaultInstance().connected();
/*      */   }
/*      */   
/*      */   public synchronized long startStrategy(IStrategy strategy) throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  560 */     if (!this.connected) {
/*  561 */       throw new IllegalStateException("Not connected");
/*      */     }
/*  563 */     if (strategy == null) {
/*  564 */       throw new IllegalArgumentException("Strategy is null");
/*      */     }
/*  566 */     return startTest(strategy, null, null);
/*      */   }
/*      */   
/*      */   public synchronized long startStrategy(IStrategy strategy, LoadingProgressListener testerProgressListener) throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  571 */     if (!this.connected) {
/*  572 */       throw new IllegalStateException("Not connected");
/*      */     }
/*  574 */     if (strategy == null) {
/*  575 */       throw new IllegalArgumentException("Strategy is null");
/*      */     }
/*  577 */     return startTest(strategy, null, testerProgressListener);
/*      */   }
/*      */   
/*      */   public synchronized long startStrategy(IStrategy strategy, IStrategyExceptionHandler exceptionHandler) throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  582 */     if (!this.connected) {
/*  583 */       throw new IllegalStateException("Not connected");
/*      */     }
/*  585 */     if (strategy == null) {
/*  586 */       throw new IllegalArgumentException("Strategy is null");
/*      */     }
/*  588 */     if (exceptionHandler == null) {
/*  589 */       throw new IllegalArgumentException("Exception handler is null");
/*      */     }
/*  591 */     return startTest(strategy, exceptionHandler, null);
/*      */   }
/*      */   
/*      */   public synchronized long startStrategy(IStrategy strategy, IStrategyExceptionHandler exceptionHandler, LoadingProgressListener testerProgressListener) throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  596 */     if (!this.connected) {
/*  597 */       throw new IllegalStateException("Not connected");
/*      */     }
/*  599 */     if (strategy == null) {
/*  600 */       throw new IllegalArgumentException("Strategy is null");
/*      */     }
/*  602 */     if (exceptionHandler == null) {
/*  603 */       throw new IllegalArgumentException("Exception handler is null");
/*      */     }
/*  605 */     return startTest(strategy, exceptionHandler, testerProgressListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long startStrategy(IStrategy strategy, LoadingProgressListener testerProgressListener, ITesterExecution testerExecution, ITesterUserInterface testerUserInterface)
/*      */     throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  615 */     return startTest(strategy, testerProgressListener, null, testerExecution, testerUserInterface);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized long startStrategy(IStrategy strategy, LoadingProgressListener testerProgressListener, ITesterVisualModeParameters testerVisualModeParameters, ITesterExecution testerExecution, ITesterUserInterface testerUserInterface)
/*      */     throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  632 */     if (!this.connected) {
/*  633 */       throw new IllegalStateException("Not connected");
/*      */     }
/*  635 */     if (strategy == null) {
/*  636 */       throw new IllegalArgumentException("Strategy is null");
/*      */     }
/*  638 */     if (testerProgressListener == null) {
/*  639 */       throw new IllegalArgumentException("TesterProgressListener is null");
/*      */     }
/*  641 */     if (testerUserInterface == null) {
/*  642 */       throw new IllegalArgumentException("TesterUserInterface is null");
/*      */     }
/*  644 */     if (testerExecution == null) {
/*  645 */       throw new IllegalArgumentException("TesterExecution is null");
/*      */     }
/*      */     
/*  648 */     if (testerVisualModeParameters != null) {
/*  649 */       Map<Instrument, ITesterIndicatorsParameters> testerIndicatorsParameters = testerVisualModeParameters.getTesterIndicatorsParameters();
/*  650 */       if (testerIndicatorsParameters == null) {
/*  651 */         throw new IllegalArgumentException("TesterIndicatorsParameters is null");
/*      */       }
/*  653 */       for (Map.Entry<Instrument, ITesterIndicatorsParameters> entry : testerIndicatorsParameters.entrySet()) {
/*  654 */         Instrument instrument = (Instrument)entry.getKey();
/*  655 */         if (instrument == null) {
/*  656 */           throw new IllegalArgumentException("TesterIndicatorsParameters: instrument is null");
/*      */         }
/*      */         
/*  659 */         ITesterIndicatorsParameters parameters = (ITesterIndicatorsParameters)entry.getValue();
/*  660 */         if (parameters == null) {
/*  661 */           throw new IllegalArgumentException("IndicatorsParameters is null for instrument:" + instrument);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  666 */     return startTest(strategy, testerProgressListener, testerVisualModeParameters, testerExecution, testerUserInterface);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long startTest(IStrategy strategy, IStrategyExceptionHandler exceptionHandler, LoadingProgressListener testerProgressListener)
/*      */   {
/*  732 */     long result = startTest(strategy, exceptionHandler, testerProgressListener, true);
/*  733 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long startTest(IStrategy strategy, IStrategyExceptionHandler exceptionHandler, LoadingProgressListener testerProgressListener, boolean writeHTDataToFiles)
/*      */   {
/*  743 */     FeedDataProvider.getDefaultInstance().setCurrentTime(System.currentTimeMillis());
/*      */     
/*  745 */     StrategyStuff strategyStuff = new StrategyStuff(null);
/*  746 */     this.strategyIdCounter += 1L;
/*  747 */     strategyStuff.processId = this.strategyIdCounter;
/*  748 */     strategyStuff.loadingProgressListener = new TesterLoadingProgressListener(strategyStuff, testerProgressListener, this.accountCurrency, this.eventLogEnabled);
/*  749 */     strategyStuff.strategies = new IStrategy[] { strategy };
/*      */     
/*      */ 
/*  752 */     TesterOrdersProvider testerOrdersProvider = new TesterOrdersProvider();
/*  753 */     TesterAccount account = new TesterAccount(this.accountCurrency, this.deposit, this.leverage, this.marginCutLevel, this.mcEquity, this.commission, this.overnights, "", this.userName);
/*      */     
/*  755 */     if (exceptionHandler == null) {
/*  756 */       exceptionHandler = new DefaultStrategyExceptionHandler(strategyStuff, null);
/*      */     }
/*      */     
/*  759 */     MinTradableAmounts minTradableAmounts = new MinTradableAmounts(Double.valueOf(1000.0D));
/*      */     
/*  761 */     ICustomTicksLoadingDescriptor ticksLoadingDescriptor = HistoricalTesterUtils.createTicksLoadingDescriptor(this.period, this.offerSide, this.interpolationMethod, this.dataLoadingMethod);
/*      */     
/*      */     final TesterFeedDataProvider testerFeedDataProvider;
/*      */     try
/*      */     {
/*  766 */       testerFeedDataProvider = new TesterFeedDataProvider("SINGLEJAR", testerOrdersProvider, ticksLoadingDescriptor, this.from, this.to, writeHTDataToFiles);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  774 */       testerFeedDataProvider.setInstrumentsSubscribed(this.instruments);
/*      */     } catch (DataCacheException e) {
/*  776 */       LOGGER.error(e.getMessage(), e);
/*  777 */       throw new RuntimeException(e);
/*      */     }
/*      */     
/*  780 */     IInstrumentSubscriber instrumentSubscriber = new IInstrumentSubscriber()
/*      */     {
/*      */       public void subscribe(Set<Instrument> instruments) throws Throwable {
/*  783 */         TesterClientImpl.this.subscribeInstruments(testerFeedDataProvider, instruments);
/*      */       }
/*      */       
/*  786 */     };
/*  787 */     List<IStrategyParameter> params = com.dukascopy.dds2.greed.util.ParameterUtils.getParameters(strategy);
/*      */     
/*  789 */     List<String[]> strategyParameters = new java.util.ArrayList();
/*      */     
/*      */ 
/*  792 */     for (IStrategyParameter param : params) {
/*  793 */       Object value = param.getValue();
/*  794 */       if ((value instanceof Calendar)) {
/*  795 */         value = ((Calendar)value).getTime();
/*      */       }
/*  797 */       String fieldValue = value == null ? "null" : value.toString();
/*  798 */       String fieldName = param.getName();
/*      */       
/*  800 */       strategyParameters.add(new String[] { fieldName, fieldValue });
/*      */     }
/*      */     
/*  803 */     strategyStuff.strategyRunner = new StrategyRunner(strategy.getClass().getName(), strategy, true, ticksLoadingDescriptor, this.from, this.to, new HashSet(this.instruments), null, strategyStuff.loadingProgressListener, NotificationUtilsProvider.getNotificationUtils(), minTradableAmounts, account, testerFeedDataProvider, testerOrdersProvider, new HashMap(0), new ExecutionControl() { public void pause() {} public void setSpeed(int value) {} }, this.processingStatsEnabled, exceptionHandler, null, strategyParameters, null, null, instrumentSubscriber);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  839 */     strategyStuff.reportDatas = new TesterReport[] { ((StrategyRunner)strategyStuff.strategyRunner).getReportData() };
/*  840 */     strategyStuff.apiReportDatas = new ITesterReportData[strategyStuff.reportDatas.length];
/*      */     
/*  842 */     this.strategies.put(Long.valueOf(strategyStuff.processId), strategyStuff);
/*  843 */     if (this.systemListener != null) {
/*  844 */       this.systemListener.onStart(strategyStuff.processId);
/*      */     }
/*  846 */     ((StrategyRunner)strategyStuff.strategyRunner).start();
/*  847 */     return strategyStuff.processId;
/*      */   }
/*      */   
/*      */   private void subscribeInstruments(TesterFeedDataProvider testerFeedDataProvider, Set<Instrument> instrumentsToSubscribe) throws DataCacheException {
/*  851 */     instrumentsToSubscribe.removeAll(this.instruments);
/*      */     
/*  853 */     testerFeedDataProvider.addInstrumentsSubscribed(instrumentsToSubscribe);
/*  854 */     FeedDataProvider.getDefaultInstance().addInstrumentsSubscribed(instrumentsToSubscribe);
/*      */     
/*  856 */     this.instruments.addAll(instrumentsToSubscribe);
/*  857 */     setupLastTicks(FeedDataProvider.getDefaultInstance(), instrumentsToSubscribe, this.from, this.to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long startTest(IStrategy strategy, LoadingProgressListener testerProgressListener, ITesterVisualModeParameters testerVisualModeParameters, ITesterExecution testerExecution, ITesterUserInterface testerUserInterface)
/*      */   {
/*  867 */     long result = startTest(strategy, testerProgressListener, testerVisualModeParameters, testerExecution, testerUserInterface, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  876 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long startStrategy(IStrategy strategy, LoadingProgressListener testerProgressListener, ITesterVisualModeParameters testerVisualModeParameters, ITesterExecution testerExecution, ITesterUserInterface testerUserInterface, boolean writeHTDataToFiles)
/*      */     throws IllegalStateException, IllegalArgumentException
/*      */   {
/*  888 */     if ((testerExecution == null) && (testerUserInterface == null)) {
/*  889 */       return startTest(strategy, null, testerProgressListener, writeHTDataToFiles);
/*      */     }
/*  891 */     return startTest(strategy, testerProgressListener, testerVisualModeParameters, testerExecution, testerUserInterface, writeHTDataToFiles);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long startTest(IStrategy strategy, LoadingProgressListener testerProgressListener, ITesterVisualModeParameters testerVisualModeParameters, ITesterExecution testerExecution, ITesterUserInterface testerUserInterface, boolean writeHTDataToFiles)
/*      */   {
/*  902 */     this.indicatorsWrappers = new LinkedList();
/*  903 */     TesterOrdersProvider testerOrdersProvider = new TesterOrdersProvider();
/*      */     final TesterFeedDataProvider testerFeedDataProvider;
/*      */     try
/*      */     {
/*  907 */       ICustomTicksLoadingDescriptor ticksLoadingDescriptor = HistoricalTesterUtils.createTicksLoadingDescriptor(this.period, this.offerSide, this.interpolationMethod, this.dataLoadingMethod);
/*  908 */       testerFeedDataProvider = new TesterFeedDataProvider("jnlp.client.mode", testerOrdersProvider, ticksLoadingDescriptor, this.from, this.to, writeHTDataToFiles);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (DataCacheException e)
/*      */     {
/*      */ 
/*      */ 
/*  917 */       LOGGER.error(e.getMessage(), e);
/*  918 */       e.printStackTrace();
/*  919 */       throw new RuntimeException("Cannot create TesterFeedDataProvider in the TesterClientImpl:" + e.getMessage());
/*      */     }
/*      */     
/*  922 */     testerFeedDataProvider.setInstrumentsSubscribed(this.instruments);
/*      */     
/*  924 */     JForexPeriod jForexPeriod = getJForexPeriod();
/*      */     
/*  926 */     List<ChartBean> chartBeans = createChartBeans(this.ddsChartsController, testerFeedDataProvider, jForexPeriod);
/*      */     
/*  928 */     Map<IChart, ITesterGui> chartsPanels = createChartsPanels(this.ddsChartsController, chartBeans);
/*  929 */     testerUserInterface.setChartPanels(chartsPanels);
/*      */     
/*      */ 
/*  932 */     StrategyDataStorageImpl strategyDataStorage = getStrategyDataStorage(testerVisualModeParameters, chartBeans);
/*  933 */     addTesterIndicators(testerVisualModeParameters, chartBeans, this.ddsChartsController, strategyDataStorage);
/*      */     
/*  935 */     ExecutionControl executionControl = new ExecutionControl();
/*  936 */     executionControl.startExecuting(true);
/*  937 */     TesterExecutionControl testerExecutionControl = new TesterExecutionControl(executionControl);
/*  938 */     testerExecution.setExecutionControl(testerExecutionControl);
/*      */     
/*  940 */     Map<Instrument, TesterChartData> testerChartsData = createTesterChartData(this.ddsChartsController, chartBeans);
/*      */     
/*  942 */     StrategyStuff strategyStuff = new StrategyStuff(null);
/*  943 */     this.strategyIdCounter += 1L;
/*  944 */     strategyStuff.processId = this.strategyIdCounter;
/*  945 */     strategyStuff.loadingProgressListener = new TesterLoadingProgressListener(strategyStuff, testerProgressListener, testerExecutionControl, this.accountCurrency, this.eventLogEnabled);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  953 */     strategyStuff.strategies = new IStrategy[] { strategy };
/*      */     
/*  955 */     TesterAccount account = new TesterAccount(this.accountCurrency, this.deposit, this.leverage, this.marginCutLevel, this.mcEquity, this.commission, this.overnights, "", this.userName);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  967 */     MinTradableAmounts minTradableAmounts = new MinTradableAmounts(Double.valueOf(1000.0D));
/*      */     
/*  969 */     IStrategyExceptionHandler exceptionHandler = new DefaultStrategyExceptionHandler(strategyStuff, null);
/*  970 */     ICustomTicksLoadingDescriptor ticksLoadingDescriptor = HistoricalTesterUtils.createTicksLoadingDescriptor(this.period, this.offerSide, this.interpolationMethod, this.dataLoadingMethod);
/*      */     
/*  972 */     IInstrumentSubscriber instrumentSubscriber = new IInstrumentSubscriber()
/*      */     {
/*      */       public void subscribe(Set<Instrument> instruments) throws Throwable {
/*  975 */         TesterClientImpl.this.subscribeInstruments(testerFeedDataProvider, instruments);
/*      */       }
/*      */       
/*  978 */     };
/*  979 */     strategyStuff.strategyRunner = new StrategyRunner(strategy.getClass().getName(), strategy, true, ticksLoadingDescriptor, this.from, this.to, new HashSet(this.instruments), strategyStuff.loadingProgressListener, NotificationUtilsProvider.getNotificationUtils(), minTradableAmounts, account, testerFeedDataProvider, testerOrdersProvider, testerChartsData, executionControl, this.processingStatsEnabled, exceptionHandler, strategyDataStorage, instrumentSubscriber);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1001 */     strategyStuff.reportDatas = new TesterReport[] { ((StrategyRunner)strategyStuff.strategyRunner).getReportData() };
/* 1002 */     strategyStuff.apiReportDatas = new ITesterReportData[strategyStuff.reportDatas.length];
/* 1003 */     this.strategies.put(Long.valueOf(strategyStuff.processId), strategyStuff);
/* 1004 */     if (this.systemListener != null) {
/* 1005 */       this.systemListener.onStart(strategyStuff.processId);
/*      */     }
/* 1007 */     ((StrategyRunner)strategyStuff.strategyRunner).start();
/*      */     
/* 1009 */     return strategyStuff.processId;
/*      */   }
/*      */   
/*      */   private List<ChartBean> createChartBeans(final DDSChartsController ddsChartsController, com.dukascopy.charts.data.datacache.IFeedDataProvider feedDataProvider, JForexPeriod jForexPeriod) {
/* 1013 */     List<ChartBean> chartBeans = new java.util.ArrayList();
/*      */     
/* 1015 */     for (Instrument instrument : this.instruments) {
/* 1016 */       final ChartBean chartBean = new ChartBean(getNextChartId(), instrument, jForexPeriod, OfferSide.BID);
/* 1017 */       chartBean.setHistoricalTesterChart(true);
/* 1018 */       chartBean.setReadOnly(true);
/* 1019 */       chartBean.setFeedDataProvider(feedDataProvider);
/*      */       
/* 1021 */       Runnable dataLoadingStarter = new Runnable()
/*      */       {
/*      */         public void run() {
/* 1024 */           if (ddsChartsController != null) {
/* 1025 */             ddsChartsController.startLoadingData(Integer.valueOf(chartBean.getId()), chartBean.getAutoShiftActiveAsBoolean(), chartBean.getChartShiftInPx());
/*      */           }
/*      */         }
/* 1028 */       };
/* 1029 */       chartBean.setStartLoadingDataRunnable(dataLoadingStarter);
/* 1030 */       chartBeans.add(chartBean);
/*      */     }
/*      */     
/* 1033 */     return chartBeans;
/*      */   }
/*      */   
/*      */   private Map<IChart, ITesterGui> createChartsPanels(DDSChartsController ddsChartsController, List<ChartBean> chartBeans) {
/* 1037 */     Map<IChart, ITesterGui> chartPanels = new HashMap();
/*      */     
/* 1039 */     for (ChartBean chartBean : chartBeans) {
/* 1040 */       ITesterGuiImpl chartGuiImpl = new ITesterGuiImpl();
/*      */       
/*      */ 
/* 1043 */       javax.swing.JPanel chartPanel = ddsChartsController.createNewChartOrGetById(chartBean);
/* 1044 */       com.dukascopy.charts.utils.ChartUtils.setWaterMarkSign(chartPanel);
/*      */       
/* 1046 */       chartGuiImpl.setChartPanel(chartPanel);
/*      */       
/*      */ 
/* 1049 */       com.dukascopy.api.system.tester.ITesterChartController testerChartControl = new TesterChartControllerImpl(ddsChartsController, chartBean.getId(), this.indicatorsWrappers);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1055 */       chartGuiImpl.setTesterChartControl(testerChartControl);
/*      */       
/* 1057 */       IChart chart = ddsChartsController.getIChartBy(Integer.valueOf(chartBean.getId()));
/* 1058 */       chartPanels.put(chart, chartGuiImpl);
/*      */     }
/*      */     
/* 1061 */     return chartPanels;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addTesterIndicators(ITesterVisualModeParameters testerVisualModeParameters, List<ChartBean> chartBeans, DDSChartsController ddsChartsController, StrategyDataStorageImpl strategyDataStorage)
/*      */   {
/* 1070 */     if (testerVisualModeParameters == null) {
/* 1071 */       return;
/*      */     }
/*      */     
/* 1074 */     LinkedList<com.dukascopy.api.indicators.IIndicator> indicators = new LinkedList();
/* 1075 */     Map<Instrument, ITesterIndicatorsParameters> testerIndicatorsParameters = testerVisualModeParameters.getTesterIndicatorsParameters();
/* 1076 */     if (testerIndicatorsParameters == null) {
/* 1077 */       return;
/*      */     }
/*      */     
/* 1080 */     for (ChartBean chartBean : chartBeans) {
/* 1081 */       Instrument instrument = chartBean.getInstrument();
/* 1082 */       ITesterIndicatorsParameters indicatorsParameters = (ITesterIndicatorsParameters)testerIndicatorsParameters.get(instrument);
/*      */       
/* 1084 */       if (indicatorShouldBeAdded(indicatorsParameters)) {
/* 1085 */         IChartTheme theme = com.dukascopy.charts.persistence.ThemeManager.getTheme(ddsChartsController.getTheme(chartBean.getId()));
/*      */         
/* 1087 */         if (indicatorsParameters.isEquityIndicatorEnabled()) {
/* 1088 */           EquityHistoricalTesterIndicator indicator = new EquityHistoricalTesterIndicator(this.from, this.deposit);
/* 1089 */           indicator.setInstrument(chartBean.getInstrument());
/* 1090 */           IndicatorContext ctx = IndicatorHelper.createIndicatorContext();
/* 1091 */           TesterIndicatorWrapper indicatorWrapper = new TesterIndicatorWrapper(indicator, ctx);
/*      */           
/*      */ 
/* 1094 */           indicatorWrapper.setChangeTreeSelection(false);
/*      */           
/* 1096 */           indicatorWrapper.setLineWidth(0, 1);
/* 1097 */           Color equityColor = theme.getColor(IChartTheme.ColoredElement.HT_EQUITY);
/* 1098 */           indicatorWrapper.setOutputColor(0, equityColor);
/* 1099 */           indicatorWrapper.setOutputColor2(0, equityColor);
/*      */           
/* 1101 */           ddsChartsController.addIndicator(Integer.valueOf(chartBean.getId()), indicatorWrapper);
/* 1102 */           indicators.add(indicator);
/*      */           
/* 1104 */           this.indicatorsWrappers.add(indicatorWrapper);
/*      */         }
/*      */         
/* 1107 */         if (indicatorsParameters.isBalanceIndicatorEnabled()) {
/* 1108 */           BalanceHistoricalTesterIndicator indicator = new BalanceHistoricalTesterIndicator(this.from, this.deposit);
/* 1109 */           indicator.setInstrument(chartBean.getInstrument());
/* 1110 */           IndicatorContext ctx = IndicatorHelper.createIndicatorContext();
/* 1111 */           TesterIndicatorWrapper indicatorWrapper = new TesterIndicatorWrapper(indicator, ctx);
/*      */           
/*      */ 
/* 1114 */           indicatorWrapper.setChangeTreeSelection(false);
/*      */           
/* 1116 */           indicatorWrapper.setLineWidth(0, 1);
/*      */           
/* 1118 */           Color balanceColor = theme.getColor(IChartTheme.ColoredElement.HT_BALANCE);
/* 1119 */           indicatorWrapper.setOutputColor(0, balanceColor);
/* 1120 */           indicatorWrapper.setOutputColor2(0, balanceColor);
/*      */           
/* 1122 */           ddsChartsController.addIndicator(Integer.valueOf(chartBean.getId()), indicatorWrapper);
/* 1123 */           indicators.add(indicator);
/*      */           
/* 1125 */           this.indicatorsWrappers.add(indicatorWrapper);
/*      */         }
/*      */         
/* 1128 */         if (indicatorsParameters.isProfitLossIndicatorEnabled()) {
/* 1129 */           ProfLossHistoricalTesterIndicator indicator = new ProfLossHistoricalTesterIndicator(this.from, this.deposit);
/* 1130 */           indicator.setInstrument(chartBean.getInstrument());
/* 1131 */           IndicatorContext ctx = IndicatorHelper.createIndicatorContext();
/* 1132 */           TesterIndicatorWrapper indicatorWrapper = new TesterIndicatorWrapper(indicator, ctx);
/*      */           
/*      */ 
/* 1135 */           indicatorWrapper.setChangeTreeSelection(false);
/*      */           
/* 1137 */           indicatorWrapper.setLineWidth(0, 1);
/*      */           
/* 1139 */           Color plColor = theme.getColor(IChartTheme.ColoredElement.HT_PROFIT_LOSS);
/* 1140 */           indicatorWrapper.setOutputColor(0, plColor);
/* 1141 */           indicatorWrapper.setOutputColor2(0, plColor);
/*      */           
/* 1143 */           ddsChartsController.addIndicator(Integer.valueOf(chartBean.getId()), indicatorWrapper);
/* 1144 */           indicators.add(indicator);
/*      */           
/* 1146 */           this.indicatorsWrappers.add(indicatorWrapper);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1151 */     if ((indicators.size() > 0) && (strategyDataStorage != null)) {
/* 1152 */       for (com.dukascopy.api.indicators.IIndicator iIndicator : indicators) {
/* 1153 */         ((com.dukascopy.dds2.greed.agent.strategy.tester.AbstractHistoricalTesterIndicator)iIndicator).setIndicatorStorage(strategyDataStorage);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean indicatorShouldBeAdded(ITesterIndicatorsParameters indicatorsParameters) {
/* 1159 */     boolean addIndicator = false;
/* 1160 */     if ((indicatorsParameters != null) && (
/* 1161 */       (indicatorsParameters.isEquityIndicatorEnabled()) || (indicatorsParameters.isBalanceIndicatorEnabled()) || (indicatorsParameters.isProfitLossIndicatorEnabled())))
/*      */     {
/*      */ 
/*      */ 
/* 1165 */       addIndicator = true;
/*      */     }
/*      */     
/*      */ 
/* 1169 */     return addIndicator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private StrategyDataStorageImpl getStrategyDataStorage(ITesterVisualModeParameters testerVisualModeParameters, List<ChartBean> chartBeans)
/*      */   {
/* 1176 */     StrategyDataStorageImpl strategyDataStorage = null;
/* 1177 */     if (testerVisualModeParameters == null) {
/* 1178 */       return strategyDataStorage;
/*      */     }
/*      */     
/* 1181 */     Map<Instrument, ITesterIndicatorsParameters> testerIndicatorsParameters = testerVisualModeParameters.getTesterIndicatorsParameters();
/* 1182 */     if (testerIndicatorsParameters == null) {
/* 1183 */       return strategyDataStorage;
/*      */     }
/*      */     
/* 1186 */     for (ChartBean chartBean : chartBeans) {
/* 1187 */       ITesterIndicatorsParameters indicatorsParameters = (ITesterIndicatorsParameters)testerIndicatorsParameters.get(chartBean.getInstrument());
/* 1188 */       if (indicatorShouldBeAdded(indicatorsParameters)) {
/* 1189 */         strategyDataStorage = new StrategyDataStorageImpl();
/* 1190 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1194 */     return strategyDataStorage;
/*      */   }
/*      */   
/*      */   private Map<Instrument, TesterChartData> createTesterChartData(DDSChartsController ddsChartsController, List<ChartBean> chartBeans) {
/* 1198 */     Map<Instrument, TesterChartData> testerChartsData = new HashMap();
/*      */     
/* 1200 */     for (ChartBean chartBean : chartBeans) {
/* 1201 */       IChart chart = ddsChartsController.getIChartBy(Integer.valueOf(chartBean.getId()));
/*      */       
/* 1203 */       TesterChartData chartData = new TesterChartData();
/* 1204 */       chartData.instrument = chartBean.getInstrument();
/* 1205 */       chartData.jForexPeriod = chartBean.getJForexPeriod();
/* 1206 */       chartData.offerSide = chartBean.getOfferSide();
/* 1207 */       chartData.feedDataProvider = chartBean.getFeedDataProvider();
/* 1208 */       chartData.chartPanelId = chartBean.getId();
/* 1209 */       chartData.chart = chart;
/* 1210 */       testerChartsData.put(chartBean.getInstrument(), chartData);
/*      */     }
/*      */     
/* 1213 */     return testerChartsData;
/*      */   }
/*      */   
/*      */   private JForexPeriod getJForexPeriod()
/*      */   {
/* 1218 */     JForexPeriod jForexPeriod = new JForexPeriod();
/*      */     
/* 1220 */     long HOURS = 3600000L;
/* 1221 */     long DAYS = HOURS * 24L;
/* 1222 */     long range = Math.abs(this.to - this.from);
/*      */     
/* 1224 */     if (range < HOURS * 22L)
/*      */     {
/* 1226 */       jForexPeriod.setPeriod(Period.FIVE_MINS);
/* 1227 */       jForexPeriod.setDataType(DataType.TIME_PERIOD_AGGREGATION);
/*      */     }
/* 1229 */     else if (range < DAYS * 6L)
/*      */     {
/* 1231 */       jForexPeriod.setPeriod(Period.TEN_MINS);
/* 1232 */       jForexPeriod.setDataType(DataType.TIME_PERIOD_AGGREGATION);
/*      */     }
/* 1234 */     else if (range < DAYS * 25L)
/*      */     {
/* 1236 */       jForexPeriod.setPeriod(Period.THIRTY_MINS);
/* 1237 */       jForexPeriod.setDataType(DataType.TIME_PERIOD_AGGREGATION);
/*      */     }
/*      */     else
/*      */     {
/* 1241 */       jForexPeriod.setPeriod(Period.ONE_HOUR);
/* 1242 */       jForexPeriod.setDataType(DataType.TIME_PERIOD_AGGREGATION);
/*      */     }
/*      */     
/* 1245 */     return jForexPeriod;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEventLogEnabled(boolean eventLogEnabled)
/*      */   {
/* 1296 */     this.eventLogEnabled = eventLogEnabled;
/*      */   }
/*      */   
/*      */   public boolean getEventLogEnabled()
/*      */   {
/* 1301 */     return this.eventLogEnabled;
/*      */   }
/*      */   
/*      */   public void setProcessingStatsEnabled(boolean processingStats)
/*      */   {
/* 1306 */     this.processingStatsEnabled = processingStats;
/*      */   }
/*      */   
/*      */   public boolean getProcessingStats()
/*      */   {
/* 1311 */     return this.processingStatsEnabled;
/*      */   }
/*      */   
/*      */   public IStrategy loadStrategy(File strategyBinaryFile) throws Exception
/*      */   {
/* 1316 */     JFXPack jfxPack = JFXPack.loadFromPack(strategyBinaryFile);
/* 1317 */     return (IStrategy)jfxPack.getTarget();
/*      */   }
/*      */   
/*      */   public synchronized void stopStrategy(long processId)
/*      */   {
/* 1322 */     if (!this.strategies.containsKey(Long.valueOf(processId))) {
/* 1323 */       return;
/*      */     }
/* 1325 */     TesterLoadingProgressListener listener = ((StrategyStuff)this.strategies.remove(Long.valueOf(processId))).loadingProgressListener;
/* 1326 */     if (listener != null) {
/* 1327 */       listener.cancel();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized ISystemListener getSystemListener() {
/* 1332 */     return this.systemListener;
/*      */   }
/*      */   
/*      */   public synchronized Map<Long, IStrategy> getStartedStrategies()
/*      */   {
/* 1337 */     HashMap<Long, IStrategy> startedStrategies = new HashMap();
/* 1338 */     for (StrategyStuff strategy : this.strategies.values()) {
/* 1339 */       if (strategy.strategyRunner != null) {
/* 1340 */         startedStrategies.put(Long.valueOf(strategy.processId), strategy.strategies[0]);
/*      */       }
/*      */     }
/* 1343 */     return startedStrategies;
/*      */   }
/*      */   
/*      */   public synchronized void setSubscribedInstruments(Set<Instrument> instruments)
/*      */   {
/* 1348 */     for (Instrument instrument : new HashSet(instruments)) {
/* 1349 */       instruments.addAll(AbstractCurrencyConverter.getConversionDeps(instrument.getSecondaryJFCurrency(), Instrument.EURUSD.getSecondaryJFCurrency()));
/*      */     }
/* 1351 */     instruments.addAll(AbstractCurrencyConverter.getConversionDeps(Instrument.EURUSD.getSecondaryJFCurrency(), this.accountCurrency));
/*      */     
/* 1353 */     if (FeedDataProvider.getDefaultInstance() != null) {
/* 1354 */       Future<?> future = FeedDataProvider.getDefaultInstance().setInstrumentsSubscribed(instruments);
/* 1355 */       if (future != null) {
/*      */         try {
/* 1357 */           future.get();
/*      */         } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/* 1359 */           LOGGER.error(e.getMessage(), e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1364 */     this.instruments = instruments;
/*      */   }
/*      */   
/*      */   public synchronized INewsFilter getNewsFilter(INewsFilter.NewsSource newsSource)
/*      */   {
/* 1369 */     return null;
/*      */   }
/*      */   
/*      */   public synchronized INewsFilter removeNewsFilter(INewsFilter.NewsSource newsSource)
/*      */   {
/* 1374 */     return null;
/*      */   }
/*      */   
/*      */   public synchronized Set<Instrument> getSubscribedInstruments()
/*      */   {
/* 1379 */     return java.util.Collections.unmodifiableSet(this.instruments);
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void addNewsFilter(INewsFilter newsFilter) {}
/*      */   
/*      */ 
/*      */   public synchronized void setOut(PrintStream out)
/*      */   {
/* 1388 */     this.out = out;
/* 1389 */     NotificationUtilsProvider.setNotificationUtils(new PrintStreamNotificationUtils(out, this.err));
/*      */   }
/*      */   
/*      */   public synchronized void setErr(PrintStream err)
/*      */   {
/* 1394 */     this.err = err;
/* 1395 */     NotificationUtilsProvider.setNotificationUtils(new PrintStreamNotificationUtils(this.out, err));
/*      */   }
/*      */   
/*      */   public void setDataInterval(Period period, OfferSide offerSide, ITesterClient.InterpolationMethod interpolationMethod, long from, long to)
/*      */   {
/* 1400 */     if (period == null) {
/* 1401 */       this.period = Period.TICK;
/*      */     }
/*      */     
/* 1404 */     if (period.isTickBasedPeriod()) {
/* 1405 */       setDataInterval(ITesterClient.DataLoadingMethod.ALL_TICKS, from, to);
/* 1406 */       return;
/*      */     }
/*      */     
/* 1409 */     if (offerSide == null) {
/* 1410 */       offerSide = OfferSide.BID;
/*      */     }
/*      */     
/* 1413 */     if ((!period.isTickBasedPeriod()) && (interpolationMethod == null)) {
/* 1414 */       throw new IllegalArgumentException("InterpolationMethod is null");
/*      */     }
/*      */     
/* 1417 */     this.period = period;
/* 1418 */     this.offerSide = offerSide;
/* 1419 */     this.interpolationMethod = interpolationMethod;
/*      */     
/* 1421 */     this.from = DataCacheUtils.getCandleStartFast(period, from);
/* 1422 */     this.to = DataCacheUtils.getCandleStartFast(period, to);
/* 1423 */     this.dataLoadingMethod = null;
/*      */   }
/*      */   
/*      */   public void setDataInterval(ITesterClient.DataLoadingMethod dataLoadingMethod, long from, long to)
/*      */   {
/* 1428 */     this.dataLoadingMethod = dataLoadingMethod;
/* 1429 */     this.from = DataCacheUtils.getCandleStartFast(Period.ONE_SEC, from);
/* 1430 */     this.to = DataCacheUtils.getCandleStartFast(Period.ONE_SEC, to);
/* 1431 */     this.interpolationMethod = null;
/*      */   }
/*      */   
/*      */   public Future<?> downloadData(final LoadingProgressListener loadingProgressListener)
/*      */   {
/* 1436 */     final TesterDataLoader testerDataLoader = new TesterDataLoader(this.from, this.to, this.instruments, new ILoadingProgressListener()
/*      */     {
/*      */       public void dataLoaded(long startTime, long endTime, long currentTime, String information) {
/* 1439 */         if (loadingProgressListener != null) {
/* 1440 */           loadingProgressListener.dataLoaded(startTime, endTime, currentTime, information);
/*      */         }
/*      */       }
/*      */       
/*      */       public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */       {
/* 1446 */         if (loadingProgressListener != null) {
/* 1447 */           loadingProgressListener.loadingFinished(allDataLoaded, startTime, endTime, currentTime);
/*      */         }
/*      */       }
/*      */       
/*      */       public boolean stopJob()
/*      */       {
/* 1453 */         return (loadingProgressListener != null) && (loadingProgressListener.stopJob());
/*      */       }
/*      */       
/* 1456 */     });
/* 1457 */     java.util.concurrent.FutureTask<?> future = new java.util.concurrent.FutureTask(new Runnable()
/*      */     {
/*      */ 
/* 1460 */       public void run() { testerDataLoader.loadData(); } }, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1469 */     Thread thread = new Thread(future, "Data loading thread");
/* 1470 */     thread.start();
/* 1471 */     return future;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setupLastTicks(FeedDataProvider feedDataProvider, Set<Instrument> instruments, long from, long to)
/*      */     throws DataCacheException
/*      */   {
/* 1486 */     if ((feedDataProvider == null) || (instruments == null) || (from > to)) {
/* 1487 */       throw new DataCacheException("Wrong parameters: " + instruments + " / " + from + ", " + to + " / " + feedDataProvider);
/*      */     }
/*      */     
/* 1490 */     for (Instrument instrument : instruments) {
/* 1491 */       long INTERVAL = TimeUnit.HOURS.toMillis(1L);
/* 1492 */       long currentTo = to;
/* 1493 */       LastTickLiveFeedListener tickListener = new LastTickLiveFeedListener();
/*      */       
/* 1495 */       while ((currentTo > from) && (tickListener.getLastTick() == null)) {
/* 1496 */         long currentFrom = currentTo - INTERVAL;
/* 1497 */         currentFrom = currentFrom < from ? from : currentFrom;
/*      */         
/* 1499 */         feedDataProvider.loadTicksDataSynched(instrument, currentFrom, currentTo, tickListener, new com.dukascopy.charts.data.datacache.LoadingProgressAdapter() {});
/* 1507 */         currentTo = currentFrom;
/*      */       }
/*      */       
/* 1510 */       if (tickListener.getLastTick() != null) {
/* 1511 */         feedDataProvider.tickReceived(tickListener.getLastTick(), instrument, false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setGatherReportData(boolean gatherReportData)
/*      */   {
/* 1518 */     this.gatherReportData = gatherReportData;
/*      */   }
/*      */   
/*      */   public boolean getGatherReportData()
/*      */   {
/* 1523 */     return this.gatherReportData;
/*      */   }
/*      */   
/*      */   public synchronized void createReport(File file) throws IOException, IllegalStateException
/*      */   {
/* 1528 */     StrategyStuff strategy = (StrategyStuff)this.strategies.get(Long.valueOf(1L));
/* 1529 */     if ((strategy == null) || (strategy.reportFiles == null)) {
/* 1530 */       throw new IllegalStateException("Report data is not available");
/*      */     }
/* 1532 */     OutputStream os = new BufferedOutputStream(new java.io.FileOutputStream(file));Throwable localThrowable3 = null;
/* 1533 */     try { InputStream is = new BufferedInputStream(new java.io.FileInputStream(strategy.reportFiles[0]));Throwable localThrowable4 = null;
/* 1534 */       try { byte[] buff = new byte[' '];
/*      */         int i;
/* 1536 */         while ((i = is.read(buff)) != -1) {
/* 1537 */           os.write(buff, 0, i);
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/* 1533 */         localThrowable4 = localThrowable1;throw localThrowable1;
/*      */       }
/*      */       finally {}
/*      */     }
/*      */     catch (Throwable localThrowable2)
/*      */     {
/* 1532 */       localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/* 1540 */       if (os != null) if (localThrowable3 != null) try { os.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else os.close();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void createReport(long processId, File file) throws IOException, IllegalStateException
/*      */   {
/* 1546 */     StrategyStuff strategy = (StrategyStuff)this.strategies.get(Long.valueOf(processId));
/* 1547 */     if ((strategy != null) && (strategy.reportFiles != null)) {
/* 1548 */       OutputStream os = new BufferedOutputStream(new java.io.FileOutputStream(file));Throwable localThrowable3 = null;
/* 1549 */       try { InputStream is = new BufferedInputStream(new java.io.FileInputStream(strategy.reportFiles[0]));Throwable localThrowable4 = null;
/* 1550 */         try { byte[] buff = new byte[' '];
/*      */           int i;
/* 1552 */           while ((i = is.read(buff)) != -1) {
/* 1553 */             os.write(buff, 0, i);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 1549 */           localThrowable4 = localThrowable1;throw localThrowable1;
/*      */         }
/*      */         finally {}
/*      */       }
/*      */       catch (Throwable localThrowable2)
/*      */       {
/* 1548 */         localThrowable3 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/* 1556 */         if (os != null) if (localThrowable3 != null) try { os.close(); } catch (Throwable x2) { localThrowable3.addSuppressed(x2); } else os.close();
/*      */       }
/* 1558 */     } else { throw new IllegalStateException("Report data is not available");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized ITesterReportData getReportData(long processId)
/*      */     throws IllegalStateException
/*      */   {
/* 1590 */     StrategyStuff strategy = (StrategyStuff)this.strategies.get(Long.valueOf(processId));
/* 1591 */     if ((strategy != null) && (strategy.apiReportDatas != null)) {
/* 1592 */       return strategy.apiReportDatas[0];
/*      */     }
/* 1594 */     throw new IllegalStateException("Report data is not available");
/*      */   }
/*      */   
/*      */   public File saveReportToFile(TesterReport reportData, ICurrency accountCurrency, boolean eventLogEnabled) throws IOException
/*      */   {
/* 1599 */     File tempFile = File.createTempFile("jfrep", null);
/* 1600 */     tempFile.deleteOnExit();
/* 1601 */     com.dukascopy.dds2.greed.agent.strategy.tester.StrategyReport.createReport(tempFile, reportData, accountCurrency, eventLogEnabled);
/* 1602 */     return tempFile;
/*      */   }
/*      */   
/*      */   public void setInitialDeposit(Currency currency, double deposit) throws IllegalArgumentException
/*      */   {
/* 1607 */     ICurrency jfCurrency = com.dukascopy.api.JFCurrency.getInstance(currency.getCurrencyCode());
/* 1608 */     setInitialDeposit(jfCurrency, deposit);
/*      */   }
/*      */   
/*      */   public void setInitialDeposit(ICurrency currency, double deposit) throws IllegalArgumentException
/*      */   {
/* 1613 */     Set<ICurrency> majors = AbstractCurrencyConverter.getMajors();
/* 1614 */     if (currency == null) {
/* 1615 */       this.accountCurrency = Instrument.EURUSD.getSecondaryJFCurrency();
/* 1616 */     } else { if (!majors.contains(currency)) {
/* 1617 */         throw new IllegalArgumentException("Currency [" + currency.getCurrencyCode() + "] cannot be set as an account currency");
/*      */       }
/* 1619 */       this.accountCurrency = currency;
/*      */     }
/*      */     
/*      */ 
/* 1623 */     setSubscribedInstruments(this.instruments);
/*      */     
/* 1625 */     this.deposit = deposit;
/*      */   }
/*      */   
/*      */   public double getInitialDeposit()
/*      */   {
/* 1630 */     return this.deposit;
/*      */   }
/*      */   
/*      */   public Currency getInitialDepositCurrency()
/*      */   {
/* 1635 */     return this.accountCurrency.getJavaCurrency();
/*      */   }
/*      */   
/*      */   public ICurrency getInitialDepositJFCurrency()
/*      */   {
/* 1640 */     return this.accountCurrency;
/*      */   }
/*      */   
/*      */   public void setLeverage(int leverage)
/*      */   {
/* 1645 */     this.leverage = leverage;
/*      */   }
/*      */   
/*      */   public int getLeverage()
/*      */   {
/* 1650 */     return this.leverage;
/*      */   }
/*      */   
/*      */   public void setCommissions(Commissions commission)
/*      */   {
/* 1655 */     this.commission = commission;
/*      */   }
/*      */   
/*      */   public Commissions getCommissions()
/*      */   {
/* 1660 */     return this.commission;
/*      */   }
/*      */   
/*      */   public void setOvernights(Overnights overnights)
/*      */   {
/* 1665 */     this.overnights = overnights;
/*      */   }
/*      */   
/*      */   public Overnights getOvernights()
/*      */   {
/* 1670 */     return this.overnights;
/*      */   }
/*      */   
/*      */   public void setMarginCutLevel(int marginCutLevel)
/*      */   {
/* 1675 */     this.marginCutLevel = marginCutLevel;
/*      */   }
/*      */   
/*      */   public int getMarginCutLevel()
/*      */   {
/* 1680 */     return this.marginCutLevel;
/*      */   }
/*      */   
/*      */   public void setMCEquity(double mcEquity)
/*      */   {
/* 1685 */     this.mcEquity = mcEquity;
/*      */   }
/*      */   
/*      */   public double getMCEquity()
/*      */   {
/* 1690 */     return this.mcEquity;
/*      */   }
/*      */   
/*      */   public void setCacheDirectory(File cacheDirectory)
/*      */   {
/* 1695 */     if (!cacheDirectory.exists()) {
/* 1696 */       LOGGER.warn("Cache directory [" + cacheDirectory + "] doesn't exist, trying to create");
/* 1697 */       if (!cacheDirectory.mkdirs()) {
/* 1698 */         LOGGER.error("Cannot create cache directory [" + cacheDirectory + "], default cache directory will be used");
/* 1699 */         return;
/*      */       }
/*      */       try
/*      */       {
/* 1703 */         com.dukascopy.charts.data.datacache.CacheManager.createVersionFile(cacheDirectory);
/*      */       } catch (DataCacheException e) {
/* 1705 */         LOGGER.error("Cannot create cache directory [" + cacheDirectory + "], default cache directory will be used. Reason [" + e.getLocalizedMessage() + "]", e);
/* 1706 */         return;
/*      */       }
/*      */     }
/*      */     
/* 1710 */     com.dukascopy.dds2.greed.util.FilePathManager.getInstance().setCacheFolderPath(cacheDirectory.getAbsolutePath());
/*      */   }
/*      */   
/*      */   private class DefaultStrategyExceptionHandler implements IStrategyExceptionHandler {
/* 1714 */     private final Logger LOGGER = LoggerFactory.getLogger(DefaultStrategyExceptionHandler.class);
/*      */     private TesterClientImpl.StrategyStuff strategy;
/*      */     
/*      */     private DefaultStrategyExceptionHandler(TesterClientImpl.StrategyStuff strategy)
/*      */     {
/* 1719 */       this.strategy = strategy;
/*      */     }
/*      */     
/*      */     public void onException(long strategyId, IStrategyExceptionHandler.Source source, Throwable t)
/*      */     {
/* 1724 */       this.LOGGER.error("Exception thrown while running " + source + " method: " + t.getMessage(), t);
/* 1725 */       this.strategy.loadingProgressListener.cancel();
/*      */     }
/*      */   }
/*      */   
/*      */   private class TesterLoadingProgressListener implements ILoadingProgressListener
/*      */   {
/*      */     private boolean cancel;
/*      */     private TesterClientImpl.StrategyStuff strategy;
/*      */     private LoadingProgressListener testerProgressListener;
/*      */     private TesterClientImpl.TesterExecutionControl testerExecutionControl;
/*      */     private ICurrency accountCurrency;
/*      */     private boolean eventLogEnabled;
/*      */     
/*      */     public TesterLoadingProgressListener(TesterClientImpl.StrategyStuff strategy, LoadingProgressListener testerProgressListener, ICurrency accountCurrency, boolean eventLogEnabled)
/*      */     {
/* 1740 */       this.accountCurrency = accountCurrency;
/* 1741 */       this.eventLogEnabled = eventLogEnabled;
/* 1742 */       this.strategy = strategy;
/* 1743 */       this.testerProgressListener = testerProgressListener;
/*      */     }
/*      */     
/*      */     public TesterLoadingProgressListener(TesterClientImpl.StrategyStuff strategy, LoadingProgressListener testerProgressListener, TesterClientImpl.TesterExecutionControl testerExecutionControl, ICurrency accountCurrency, boolean eventLogEnabled)
/*      */     {
/* 1748 */       this.accountCurrency = accountCurrency;
/* 1749 */       this.eventLogEnabled = eventLogEnabled;
/* 1750 */       this.strategy = strategy;
/* 1751 */       this.testerProgressListener = testerProgressListener;
/* 1752 */       this.testerExecutionControl = testerExecutionControl;
/*      */     }
/*      */     
/*      */     public void dataLoaded(long startTime, long endTime, long currentTime, String information)
/*      */     {
/* 1757 */       if (this.testerProgressListener != null) {
/* 1758 */         this.testerProgressListener.dataLoaded(startTime, endTime, currentTime, information);
/*      */       }
/*      */     }
/*      */     
/*      */     public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable ex)
/*      */     {
/* 1764 */       synchronized (TesterClientImpl.this) {
/* 1765 */         if ((!allDataLoaded) && (ex != null)) {
/* 1766 */           TesterClientImpl.LOGGER.error(ex.getMessage(), ex);
/*      */         }
/* 1768 */         if (((this.testerProgressListener == null) || (!this.testerProgressListener.stopJob())) && (!this.strategy.strategyRunner.wasCanceled())) {
/* 1769 */           this.strategy.reportFiles = new File[this.strategy.strategies.length];
/* 1770 */           for (int i = 0; i < this.strategy.strategies.length; i++) {
/*      */             try {
/* 1772 */               this.strategy.reportFiles[i] = TesterClientImpl.this.saveReportToFile(this.strategy.reportDatas[i], this.accountCurrency, this.eventLogEnabled);
/*      */             } catch (IOException e) {
/* 1774 */               TesterClientImpl.LOGGER.error(e.getMessage(), e);
/*      */             }
/*      */             
/* 1777 */             this.strategy.apiReportDatas[i] = com.dukascopy.dds2.greed.agent.strategy.tester.StrategyReport.createReport(this.strategy.reportDatas[i], this.accountCurrency, TesterClientImpl.this.connected);
/*      */           }
/*      */         }
/* 1780 */         this.strategy.strategies = null;
/* 1781 */         this.strategy.reportDatas = null;
/* 1782 */         this.strategy.loadingProgressListener = null;
/* 1783 */         this.strategy.strategyRunner = null;
/*      */         
/* 1785 */         if (TesterClientImpl.this.systemListener != null) {
/* 1786 */           TesterClientImpl.this.systemListener.onStop(this.strategy.processId);
/*      */         }
/* 1788 */         if (this.testerProgressListener != null) {
/* 1789 */           this.testerProgressListener.loadingFinished(allDataLoaded, startTime, endTime, currentTime);
/* 1790 */           this.testerProgressListener = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean stopJob()
/*      */     {
/* 1797 */       return (this.cancel) || ((this.testerProgressListener != null) && (this.testerProgressListener.stopJob())) || ((this.testerExecutionControl != null) && (this.testerExecutionControl.isExecutionCanceled()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void cancel()
/*      */     {
/* 1804 */       this.cancel = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StrategyStuff
/*      */   {
/*      */     private long processId;
/*      */     private IStrategy[] strategies;
/*      */     private TesterReport[] reportDatas;
/*      */     private IStrategyRunner strategyRunner;
/*      */     private TesterClientImpl.TesterLoadingProgressListener loadingProgressListener;
/*      */     private File[] reportFiles;
/*      */     private ITesterReportData[] apiReportDatas;
/*      */   }
/*      */   
/*      */   private class TesterExecutionControl implements com.dukascopy.api.system.tester.ITesterExecutionControl {
/* 1820 */     ExecutionControl executionControl = null;
/*      */     
/*      */     public TesterExecutionControl(ExecutionControl executionControl) {
/* 1823 */       this.executionControl = executionControl;
/*      */     }
/*      */     
/*      */     public void pauseExecution()
/*      */     {
/* 1828 */       this.executionControl.pause();
/*      */     }
/*      */     
/*      */     public boolean isExecutionPaused()
/*      */     {
/* 1833 */       return this.executionControl.isPaused();
/*      */     }
/*      */     
/*      */     public void continueExecution()
/*      */     {
/* 1838 */       this.executionControl.run();
/*      */     }
/*      */     
/*      */     public void cancelExecution()
/*      */     {
/* 1843 */       this.executionControl.stopExecuting(true);
/*      */     }
/*      */     
/*      */     public boolean isExecutionCanceled()
/*      */     {
/* 1848 */       return !this.executionControl.isExecuting();
/*      */     }
/*      */   }
/*      */   
/*      */   private int getNextChartId() {
/* 1853 */     return this.chart_id++;
/*      */   }
/*      */   
/*      */   public String getSessionID() {
/* 1857 */     return this.sessionID;
/*      */   }
/*      */   
/*      */   public StrategyRunner getStrategyRunner(long processID) {
/* 1861 */     return (StrategyRunner)((StrategyStuff)this.strategies.get(Long.valueOf(processID))).strategyRunner;
/*      */   }
/*      */   
/*      */   public void compileStrategy(String srcJavaFile, boolean obfuscate)
/*      */   {
/* 1866 */     com.dukascopy.dds2.greed.agent.compiler.JFXCompiler.getInstance().compile(new File(srcJavaFile), this.console, obfuscate);
/*      */   }
/*      */   
/*      */   public Set<Instrument> getAvailableInstruments()
/*      */   {
/* 1871 */     Set<String> setAsString = (Set)this.serverProperties.get("instruments");
/* 1872 */     return Instrument.fromStringSet(setAsString);
/*      */   }
/*      */   
/*      */   public com.dukascopy.api.system.tester.ITesterDataInterval getDataInterval()
/*      */   {
/* 1877 */     if (this.interpolationMethod == null) {
/* 1878 */       new com.dukascopy.api.system.tester.ITesterDataInterval.ILoading()
/*      */       {
/*      */         public long getTo()
/*      */         {
/* 1882 */           return TesterClientImpl.this.to;
/*      */         }
/*      */         
/*      */         public long getFrom()
/*      */         {
/* 1887 */           return TesterClientImpl.this.from;
/*      */         }
/*      */         
/*      */         public ITesterClient.DataLoadingMethod getDataLoadingMethod()
/*      */         {
/* 1892 */           return TesterClientImpl.this.dataLoadingMethod;
/*      */         }
/*      */         
/*      */         public String toString()
/*      */         {
/* 1897 */           return String.format("ITesterDataInterval.ILoading %s %s - %s", new Object[] { TesterClientImpl.this.dataLoadingMethod, DateUtils.format(TesterClientImpl.this.from), DateUtils.format(TesterClientImpl.this.to) });
/*      */         }
/*      */       };
/*      */     }
/*      */     
/* 1902 */     new com.dukascopy.api.system.tester.ITesterDataInterval.IInterpolation()
/*      */     {
/*      */       public long getTo()
/*      */       {
/* 1906 */         return TesterClientImpl.this.to;
/*      */       }
/*      */       
/*      */       public long getFrom()
/*      */       {
/* 1911 */         return TesterClientImpl.this.from;
/*      */       }
/*      */       
/*      */       public Period getPeriod()
/*      */       {
/* 1916 */         return TesterClientImpl.this.period;
/*      */       }
/*      */       
/*      */       public OfferSide getOfferSide()
/*      */       {
/* 1921 */         return TesterClientImpl.this.offerSide;
/*      */       }
/*      */       
/*      */       public ITesterClient.InterpolationMethod getInterpolationMethod()
/*      */       {
/* 1926 */         return TesterClientImpl.this.interpolationMethod;
/*      */       }
/*      */       
/*      */       public String toString()
/*      */       {
/* 1931 */         return String.format("ITesterDataInterval.IInterpolation %s %s %s %s - %s", new Object[] { TesterClientImpl.this.interpolationMethod, TesterClientImpl.this.period, TesterClientImpl.this.offerSide, DateUtils.format(TesterClientImpl.this.from), DateUtils.format(TesterClientImpl.this.to) });
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */ 
/*      */   public File packPluginToJfx(File file)
/*      */   {
/* 1939 */     throw new RuntimeException("Use IClient for plugin packaging!");
/*      */   }
/*      */   
/*      */   public UUID runPlugin(Plugin plugin, IStrategyExceptionHandler exceptionHandler) throws IllegalStateException, NullPointerException
/*      */   {
/* 1944 */     throw new RuntimeException("No back-testing for plugins!");
/*      */   }
/*      */   
/*      */ 
/*      */   public UUID runPlugin(Plugin plugin, IStrategyExceptionHandler exceptionHandler, com.dukascopy.api.plugins.PluginGuiListener pluginGuiListener)
/*      */     throws IllegalStateException, NullPointerException
/*      */   {
/* 1951 */     throw new RuntimeException("No back-testing for plugins!");
/*      */   }
/*      */   
/*      */ 
/*      */   public void stopPlugin(UUID processId) {}
/*      */   
/*      */   public IPreferences getPreferences()
/*      */   {
/* 1959 */     return this.ddsChartsController.getPreferences();
/*      */   }
/*      */   
/*      */   public void setPreferences(IPreferences preferences)
/*      */   {
/* 1964 */     this.ddsChartsController.setPreferences(preferences);
/*      */   }
/*      */   
/*      */   public Map<UUID, Plugin> getRunningPlugins()
/*      */   {
/* 1969 */     return java.util.Collections.emptyMap();
/*      */   }
/*      */   
/*      */ 
/*      */   public com.dukascopy.api.strategy.remote.IRemoteStrategyManager getRemoteStrategyManager()
/*      */   {
/* 1975 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public File packToJfx(File file)
/*      */   {
/* 1981 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\TesterClientImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */