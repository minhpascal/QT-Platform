/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.IReportPosition;
/*     */ import com.dukascopy.api.IReportPosition.PositionType;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFCurrency;
/*     */ import com.dukascopy.api.Money;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.ord.data.PositionData;
/*     */ import com.dukascopy.dds3.transport.msg.ord.data.PositionType;
/*     */ import com.dukascopy.dds3.transport.msg.types.PositionSide;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReportPosition
/*     */   implements IReportPosition
/*     */ {
/*     */   private final PositionData adaptee;
/*     */   private final Instrument instrument;
/*     */   
/*     */   public ReportPosition(PositionData positionData)
/*     */   {
/*  30 */     this.adaptee = positionData;
/*  31 */     this.instrument = Instrument.fromString(positionData.getInstrument());
/*     */   }
/*     */   
/*     */   public IReportPosition.PositionType getPositionType()
/*     */   {
/*  36 */     return IReportPosition.PositionType.valueOf(this.adaptee.getPositionType().toString());
/*     */   }
/*     */   
/*     */   public String getPositionId()
/*     */   {
/*  41 */     return this.adaptee.getPositionId();
/*     */   }
/*     */   
/*     */   public boolean isLong()
/*     */   {
/*  46 */     return ObjectUtils.isEqual(PositionSide.LONG, this.adaptee.getSide());
/*     */   }
/*     */   
/*     */   public Instrument getInstrument()
/*     */   {
/*  51 */     return this.instrument;
/*     */   }
/*     */   
/*     */   public double getAmount()
/*     */   {
/*  56 */     double amount = 0.0D;
/*  57 */     if (this.adaptee.getAmount() != null) {
/*  58 */       amount = StratUtils.round(this.adaptee.getAmount().doubleValue(), 2);
/*     */     }
/*  60 */     return amount;
/*     */   }
/*     */   
/*     */   public double getOpenPrice()
/*     */   {
/*  65 */     double openPrice = 0.0D;
/*  66 */     if (this.adaptee.getOpenPrice() != null) {
/*  67 */       openPrice = StratUtils.round05Pips(this.adaptee.getOpenPrice().doubleValue(), this.instrument.getPipScale());
/*     */     }
/*  69 */     return openPrice;
/*     */   }
/*     */   
/*     */   public double getCurrentPrice()
/*     */   {
/*  74 */     double currentPrice = 0.0D;
/*  75 */     if (this.adaptee.getCurrentPrice() != null) {
/*  76 */       currentPrice = StratUtils.round05Pips(this.adaptee.getCurrentPrice().doubleValue(), this.instrument.getPipScale());
/*     */     }
/*  78 */     return currentPrice;
/*     */   }
/*     */   
/*     */   public double getClosePrice()
/*     */   {
/*  83 */     double closePrice = 0.0D;
/*  84 */     if (this.adaptee.getClosePrice() != null) {
/*  85 */       closePrice = StratUtils.round05Pips(this.adaptee.getClosePrice().doubleValue(), this.instrument.getPipScale());
/*     */     }
/*  87 */     return closePrice;
/*     */   }
/*     */   
/*     */   public Money getProfitLoss()
/*     */   {
/*  92 */     double profitLoss = 0.0D;
/*  93 */     if (this.adaptee.getProfitLoss() != null) {
/*  94 */       profitLoss = StratUtils.round(this.adaptee.getProfitLoss().doubleValue(), 2);
/*     */     }
/*  96 */     return new Money(profitLoss, getInstrument().getSecondaryJFCurrency());
/*     */   }
/*     */   
/*     */ 
/*     */   public Money getSwaps()
/*     */   {
/* 102 */     double swaps = 0.0D;
/* 103 */     if (this.adaptee.getSwaps() != null) {
/* 104 */       swaps = StratUtils.round(this.adaptee.getSwaps().doubleValue(), 2);
/*     */     }
/* 106 */     return new Money(swaps, getInstrument().getSecondaryJFCurrency());
/*     */   }
/*     */   
/*     */   public Money getGrossProfitLoss()
/*     */   {
/* 111 */     double grossProfitLoss = 0.0D;
/* 112 */     if (this.adaptee.getGrossProfitLoss() != null) {
/* 113 */       grossProfitLoss = StratUtils.round(this.adaptee.getGrossProfitLoss().doubleValue(), 2);
/*     */     }
/* 115 */     return new Money(grossProfitLoss, getInstrument().getSecondaryJFCurrency());
/*     */   }
/*     */   
/*     */   public Money getCommission()
/*     */   {
/* 120 */     double commission = 0.0D;
/* 121 */     if (this.adaptee.getCommission() != null) {
/* 122 */       commission = StratUtils.round(this.adaptee.getCommission().doubleValue(), 2);
/*     */     }
/* 124 */     return new Money(commission, JFCurrency.getInstance(this.adaptee.getCommissionCurrency()));
/*     */   }
/*     */   
/*     */   public long getOpenTime()
/*     */   {
/* 129 */     return this.adaptee.getOpenDate();
/*     */   }
/*     */   
/*     */   public long getCloseTime()
/*     */   {
/* 134 */     return this.adaptee.getCloseDate();
/*     */   }
/*     */   
/*     */   public boolean isClosed()
/*     */   {
/* 139 */     return (getCloseTime() > 0L) && (getClosePrice() > 0.0D);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 144 */     int prime = 31;
/* 145 */     int result = 1;
/* 146 */     result = 31 * result + (this.adaptee == null ? 0 : this.adaptee.hashCode());
/*     */     
/* 148 */     long temp = Double.doubleToLongBits(getAmount());
/* 149 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 150 */     temp = Double.doubleToLongBits(getClosePrice());
/* 151 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 152 */     result = 31 * result + (int)(getCloseTime() ^ getCloseTime() >>> 32);
/* 153 */     result = 31 * result + (getCommission() == null ? 0 : getCommission().hashCode());
/*     */     
/* 155 */     temp = Double.doubleToLongBits(getCurrentPrice());
/* 156 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 157 */     result = 31 * result + (getGrossProfitLoss() == null ? 0 : getGrossProfitLoss().hashCode());
/*     */     
/* 159 */     result = 31 * result + (this.instrument == null ? 0 : this.instrument.hashCode());
/*     */     
/* 161 */     result = 31 * result + (isLong() ? 1231 : 1237);
/* 162 */     temp = Double.doubleToLongBits(getOpenPrice());
/* 163 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 164 */     result = 31 * result + (int)(getOpenTime() ^ getOpenTime() >>> 32);
/* 165 */     result = 31 * result + (getPositionId() == null ? 0 : getPositionId().hashCode());
/*     */     
/* 167 */     result = 31 * result + (getPositionType() == null ? 0 : getPositionType().hashCode());
/*     */     
/* 169 */     result = 31 * result + (getProfitLoss() == null ? 0 : getProfitLoss().hashCode());
/*     */     
/* 171 */     result = 31 * result + (getSwaps() == null ? 0 : getSwaps().hashCode());
/* 172 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 177 */     if (this == obj)
/* 178 */       return true;
/* 179 */     if (obj == null)
/* 180 */       return false;
/* 181 */     if (!(obj instanceof ReportPosition))
/* 182 */       return false;
/* 183 */     ReportPosition other = (ReportPosition)obj;
/* 184 */     if (this.adaptee == null) {
/* 185 */       if (other.adaptee != null)
/* 186 */         return false;
/* 187 */     } else if (!this.adaptee.equals(other.adaptee))
/* 188 */       return false;
/* 189 */     if (Double.doubleToLongBits(getAmount()) != Double.doubleToLongBits(other.getAmount()))
/*     */     {
/* 191 */       return false; }
/* 192 */     if (Double.doubleToLongBits(getClosePrice()) != Double.doubleToLongBits(other.getClosePrice()))
/*     */     {
/* 194 */       return false; }
/* 195 */     if (getCloseTime() != other.getCloseTime())
/* 196 */       return false;
/* 197 */     if (getCommission() == null) {
/* 198 */       if (other.getCommission() != null)
/* 199 */         return false;
/* 200 */     } else if (!getCommission().equals(other.getCommission()))
/* 201 */       return false;
/* 202 */     if (Double.doubleToLongBits(getCurrentPrice()) != Double.doubleToLongBits(other.getCurrentPrice()))
/*     */     {
/* 204 */       return false; }
/* 205 */     if (getGrossProfitLoss() == null) {
/* 206 */       if (other.getGrossProfitLoss() != null)
/* 207 */         return false;
/* 208 */     } else if (!getGrossProfitLoss().equals(other.getGrossProfitLoss()))
/* 209 */       return false;
/* 210 */     if (this.instrument != other.instrument)
/* 211 */       return false;
/* 212 */     if (isLong() != other.isLong())
/* 213 */       return false;
/* 214 */     if (Double.doubleToLongBits(getOpenPrice()) != Double.doubleToLongBits(other.getOpenPrice()))
/*     */     {
/* 216 */       return false; }
/* 217 */     if (getOpenTime() != other.getOpenTime())
/* 218 */       return false;
/* 219 */     if (getPositionId() == null) {
/* 220 */       if (other.getPositionId() != null)
/* 221 */         return false;
/* 222 */     } else if (!getPositionId().equals(other.getPositionId()))
/* 223 */       return false;
/* 224 */     if (getPositionType() != other.getPositionType())
/* 225 */       return false;
/* 226 */     if (getProfitLoss() == null) {
/* 227 */       if (other.getProfitLoss() != null)
/* 228 */         return false;
/* 229 */     } else if (!getProfitLoss().equals(other.getProfitLoss()))
/* 230 */       return false;
/* 231 */     if (getSwaps() == null) {
/* 232 */       if (other.getSwaps() != null)
/* 233 */         return false;
/* 234 */     } else if (!getSwaps().equals(other.getSwaps()))
/* 235 */       return false;
/* 236 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 241 */     return String.format("ReportPosition:%n[positionType=%s,%npositionId=%s,%nisLong=%B,%ninstrument=%s,%namount=%.2f,%nopenPrice=%.5f,%ncurrentPrice=%.5f,%nclosePrice=%.5f,%nprofitLoss=%s,%nswaps=%s,%ngrossProfitLoss=%s,%ncommission=%s,%nopenDate=" + (getOpenTime() > 0L ? "%13$tD %13$tT" : "N/A") + ",%n" + "closeDate=" + (getCloseTime() > 0L ? "%14$tD %14$tT" : "N/A"), new Object[] { getPositionType(), getPositionId(), Boolean.valueOf(isLong()), this.instrument, Double.valueOf(getAmount()), Double.valueOf(getOpenPrice()), Double.valueOf(getCurrentPrice()), Double.valueOf(getClosePrice()), getProfitLoss(), getSwaps(), getGrossProfitLoss(), getCommission(), Long.valueOf(getOpenTime()), Long.valueOf(getCloseTime()) });
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\ReportPosition.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */