/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.beforetimeafter;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadClosestTickBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadToCacheTickBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PANthTickBarFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PALoadByTimeIntervalTickBarAction;
/*     */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarCreator;
/*     */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.tickbar.TickBarData;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PALoadNumberOfBarsBeforeAfterTimeTickBarAction
/*     */   extends PAAbstractLoadNumOfBarsBeforeAfterTimeAction<TickBarData, ITickBarLiveFeedListener, ITickBarCreator, PALoadToCacheTickBarAction, PALoadByTimeIntervalTickBarAction>
/*     */ {
/*     */   public PALoadNumberOfBarsBeforeAfterTimeTickBarAction(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int numOfBarsBefore, long time, int numOfBarsAfter, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, ITickBarLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  54 */     super(cacheManager, instrument, interpolationDescriptor, side, jfPeriod, numOfBarsBefore, time, numOfBarsAfter, fireUncompletedLastBasePeriodBars, infinitBasePeriod, version, listener, loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ITickBarLiveFeedListener createOneBarListener(final List<TickBarData> oneBarList)
/*     */   {
/*  74 */     new ITickBarLiveFeedListener()
/*     */     {
/*     */       public void newPriceData(TickBarData data) {
/*  77 */         oneBarList.add(data);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   protected PALoadByTimeIntervalTickBarAction createLoadIntervalAction(long timeFrom, long timeTo, ILoadingProgressListener loadingProgressListener) throws DataCacheException
/*     */   {
/*  84 */     return new PALoadByTimeIntervalTickBarAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), timeFrom, timeTo, isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), (ITickBarLiveFeedListener)getListener(), loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PALoadClosestTickBarAction createLoadClosestAction(ITickBarLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 102 */     PALoadClosestTickBarAction action = new PALoadClosestTickBarAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), getTime(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), listener, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */     return action;
/*     */   }
/*     */   
/*     */ 
/*     */   protected PANthTickBarFromSeedBarAction createNthBarFromSeedAction(TickBarData timedBar, ITickBarLiveFeedListener oneBarListener, boolean lookLeft, ILoadingProgressListener loadingProgressListener)
/*     */   {
/* 121 */     PANthTickBarFromSeedBarAction action = new PANthTickBarFromSeedBarAction(getCacheManager(), getVersion(), getNumOfBarsBefore(), timedBar, getNumOfBarsAfter(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), lookLeft, loadingProgressListener, oneBarListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */     return action;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\beforetimeafter\PALoadNumberOfBarsBeforeAfterTimeTickBarAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */