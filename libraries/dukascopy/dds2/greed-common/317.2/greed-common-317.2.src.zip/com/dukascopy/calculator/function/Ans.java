/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.complex.Complex;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ans
/*    */   extends Container
/*    */ {
/*    */   public Ans()
/*    */   {
/* 19 */     this.d = new Double(0.0D).doubleValue();
/* 20 */     this.c = new Complex();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(double d)
/*    */   {
/* 28 */     this.d = d;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(OObject c)
/*    */   {
/* 36 */     this.c = c;
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 40 */     return fname;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 44 */     Ans o = new Ans();
/* 45 */     StringBuilder s = new StringBuilder("<html>");
/* 46 */     s.append(o.name());
/* 47 */     s.append("</html>");
/* 48 */     JOptionPane.showMessageDialog(null, s.toString());
/*    */   }
/*    */   
/* 51 */   private static final String[] fname = { "A", "N", "S" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Ans.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */