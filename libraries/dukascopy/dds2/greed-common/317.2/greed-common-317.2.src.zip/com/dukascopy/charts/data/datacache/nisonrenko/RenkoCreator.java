/*     */ package com.dukascopy.charts.data.datacache.nisonrenko;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.PriceRange;
/*     */ import com.dukascopy.api.feed.RenkoCreationPoint;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractFantomablePriceAggregationCreator;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenkoCreator
/*     */   extends AbstractFantomablePriceAggregationCreator<RenkoData, TickData, IRenkoLiveFeedListener>
/*     */   implements IRenkoCreator
/*     */ {
/*     */   private final JForexPeriod jfPeriod;
/*     */   private final PriceRange brickSize;
/*     */   private int loadedBarsCount;
/*     */   private double range;
/*     */   private final RenkoCreationPoint ohlc;
/*     */   private int pipScale;
/*  44 */   private double leftPricePoint = Double.MIN_VALUE;
/*  45 */   private long createBarsFromTime = Long.MAX_VALUE;
/*     */   
/*     */   private double accumulatedVolume;
/*     */   private long accumulatedFEC;
/*  49 */   private double currentMinimum = Double.MAX_VALUE;
/*  50 */   private double currentMaximum = Double.MIN_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RenkoCreator(Instrument instrument, OfferSide offerSide, JForexPeriod jfPeriod, int desiredBarsCount, boolean directOrder, boolean liveCreation, boolean isInfinity)
/*     */   {
/*  61 */     super(instrument, offerSide, desiredBarsCount, liveCreation, directOrder, isInfinity);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     this.jfPeriod = jfPeriod;
/*  70 */     this.brickSize = jfPeriod.getPriceRange();
/*  71 */     this.ohlc = jfPeriod.getRenkoCreationPoint();
/*  72 */     this.pipScale = instrument.getPipScale();
/*  73 */     initRange(jfPeriod);
/*  74 */     reset();
/*     */   }
/*     */   
/*     */   private void initRange(JForexPeriod jfPeriod) {
/*  78 */     this.range = roundPipScalePlusOne(jfPeriod.getPriceRange().getPipCount() * getInstrument().getPipValue());
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean analyse(CandleData candleData)
/*     */   {
/*  84 */     if (candleData == null) {
/*  85 */       return false;
/*     */     }
/*     */     
/*  88 */     if (this.currentMinimum > candleData.getLow()) {
/*  89 */       this.currentMinimum = candleData.getLow();
/*     */     }
/*  91 */     if (this.currentMaximum < candleData.getHigh()) {
/*  92 */       this.currentMaximum = candleData.getHigh();
/*     */     }
/*     */     
/*  95 */     TickData fakeTick = DataCacheUtils.createFakeRenkoTickDataFromCandleParameters(getInstrument(), this.jfPeriod.getRenkoCreationPoint(), this.jfPeriod.getRenkoSession(), candleData.getTime(), candleData.getOpen(), candleData.getClose(), candleData.getLow(), candleData.getHigh(), candleData.getVolume());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */     return analyse(fakeTick);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean analyse(TickData data)
/*     */   {
/* 112 */     if (data == null) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     double price = getPrice(data);
/*     */     
/* 118 */     if (this.currentMinimum > price) {
/* 119 */       this.currentMinimum = price;
/*     */     }
/* 121 */     if (this.currentMaximum < price) {
/* 122 */       this.currentMaximum = price;
/*     */     }
/*     */     
/* 125 */     if (this.leftPricePoint == Double.MIN_VALUE) {
/* 126 */       this.leftPricePoint = getBasePrice(data);
/* 127 */       this.createBarsFromTime = data.getTime();
/* 128 */       this.accumulatedVolume += getDataVolume(data);
/* 129 */       this.accumulatedFEC += 1L;
/* 130 */       return false;
/*     */     }
/*     */     
/* 133 */     if ((this.leftPricePoint != Double.MIN_VALUE) && (!canContinueByTime(this.createBarsFromTime, data.getTime())))
/*     */     {
/*     */ 
/*     */ 
/* 137 */       resetSoft();
/* 138 */       this.leftPricePoint = getBasePrice(data);
/* 139 */       this.createBarsFromTime = data.getTime();
/* 140 */       this.accumulatedVolume += getDataVolume(data);
/* 141 */       this.currentMinimum = price;
/* 142 */       this.currentMaximum = price;
/*     */       
/* 144 */       this.accumulatedFEC += 1L;
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     this.accumulatedVolume += getDataVolume(data);
/* 149 */     this.accumulatedFEC += 1L;
/*     */     
/* 151 */     boolean gotRenkos = isGotRenkos(this.leftPricePoint, price);
/*     */     
/* 153 */     if (!gotRenkos) {
/* 154 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 158 */     RenkoData[] createdRenkos = getNewRenkos(this.leftPricePoint, price, data);
/*     */     
/*     */ 
/* 161 */     if (createdRenkos.length > 0) {
/* 162 */       fireRenkosOneByOne(createdRenkos);
/* 163 */       this.createBarsFromTime = (createdRenkos[(createdRenkos.length - 1)].getEndTime() + 1L);
/* 164 */       this.accumulatedVolume = 0.0D;
/* 165 */       this.accumulatedFEC = 0L;
/*     */     }
/*     */     
/* 168 */     return isAllDesiredDataLoaded();
/*     */   }
/*     */   
/*     */   private void fireRenkosOneByOne(RenkoData[] createdRenkos)
/*     */   {
/* 173 */     for (int x = 0; x < createdRenkos.length; x++) {
/* 174 */       fireRenko(createdRenkos[x]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void fireRenko(RenkoData renko) {
/* 179 */     super.fireNewBarCreated(renko);
/* 180 */     setLastElementIndex(getLastElementIndex() + 1);
/* 181 */     ((RenkoData[])this.result)[getLastElementIndex()] = renko;
/* 182 */     this.loadedBarsCount += 1;
/*     */   }
/*     */   
/*     */   protected void setLastElementIndex(int index) {
/* 186 */     this.lastElementIndex = index;
/*     */   }
/*     */   
/*     */   private RenkoData[] getNewRenkos(double leftPricePoint, double rightPricePoint, TickData data)
/*     */   {
/* 191 */     double priceDiff = roundPipScalePlusOne(leftPricePoint - rightPricePoint);
/* 192 */     RenkoData previousBar = getLastCompletedData();
/*     */     
/* 194 */     boolean barsWillRise = priceDiff < 0.0D;
/*     */     
/* 196 */     double createFrom = Double.MIN_VALUE;
/* 197 */     double createTo = Double.MIN_VALUE;
/*     */     
/*     */     int numOfBars;
/* 200 */     if (previousBar == null) {
/* 201 */       createFrom = leftPricePoint;
/* 202 */       int numOfBars = (int)(Math.abs(priceDiff) / this.range);
/* 203 */       if (barsWillRise) {
/* 204 */         createTo = createFrom + numOfBars * this.range;
/*     */       }
/*     */       else {
/* 207 */         createTo = createFrom - numOfBars * this.range;
/*     */       }
/*     */     }
/* 210 */     else if (previousBar.isRising().booleanValue()) {
/* 211 */       if (barsWillRise) {
/* 212 */         int numOfBars = (int)(Math.abs(priceDiff) / this.range);
/* 213 */         createFrom = leftPricePoint;
/* 214 */         createTo = createFrom + numOfBars * this.range;
/*     */       }
/*     */       else {
/* 217 */         int numOfBars = (int)((priceDiff - this.range) / this.range);
/* 218 */         createFrom = leftPricePoint - this.range;
/* 219 */         createTo = createFrom - numOfBars * this.range;
/*     */       }
/*     */       
/*     */     }
/* 223 */     else if (barsWillRise) {
/* 224 */       int numOfBars = (int)((Math.abs(priceDiff) - this.range) / this.range);
/* 225 */       createFrom = leftPricePoint + this.range;
/* 226 */       createTo = createFrom + numOfBars * this.range;
/*     */     }
/*     */     else {
/* 229 */       numOfBars = (int)(priceDiff / this.range);
/* 230 */       createFrom = leftPricePoint;
/* 231 */       createTo = createFrom - numOfBars * this.range;
/*     */     }
/*     */     
/*     */ 
/* 235 */     createFrom = roundPipScalePlusOne(createFrom);
/* 236 */     createTo = roundPipScalePlusOne(createTo);
/*     */     
/* 238 */     if ((roundPipScalePlusOne(Math.abs(createFrom - createTo)) < this.range) || (numOfBars <= 0)) {
/* 239 */       throw new IllegalArgumentException("Cannot create renko bars, if price difference < range or if the number of new bars is <= 0! Price difference is [" + Math.abs(createFrom - createTo) + "] and range [" + this.range + "], number of new bars [" + numOfBars + "]");
/*     */     }
/*     */     
/* 242 */     long fromTime = this.createBarsFromTime;
/* 243 */     long toTime = data.getTime();
/*     */     
/*     */ 
/* 246 */     RenkoData[] createdRenkos = createRenkos(createFrom, createTo, numOfBars, fromTime, toTime, this.accumulatedVolume, this.accumulatedFEC);
/*     */     
/* 248 */     if (fromTime == toTime)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 253 */       return createdRenkos;
/*     */     }
/*     */     
/* 256 */     if (createdRenkos.length <= 0) {
/* 257 */       throw new IllegalArgumentException("Couldn't create renkos!");
/*     */     }
/*     */     
/*     */ 
/* 261 */     long lastBarEndTime = createdRenkos[(createdRenkos.length - 1)].getEndTime();
/* 262 */     long lastTheoreticalEndTime = Period.TICK.equals(this.jfPeriod.getRenkoSession()) ? lastBarEndTime : DataCacheUtils.getNextCandleStartFast(this.jfPeriod.getRenkoSession(), DataCacheUtils.getCandleStartFast(this.jfPeriod.getRenkoSession(), data.getTime())) - 1L;
/*     */     
/*     */ 
/* 265 */     boolean isLastCandleLast = lastBarEndTime == lastTheoreticalEndTime;
/*     */     
/* 267 */     if (barsWillRise)
/*     */     {
/* 269 */       if (this.currentMinimum < createFrom) {
/* 270 */         createdRenkos[0].setWickPrice(Double.valueOf(this.currentMinimum));
/*     */       }
/* 272 */       if (this.currentMaximum > createTo) {
/* 273 */         createdRenkos[(createdRenkos.length - 1)].setOppositeWickPrice(Double.valueOf(this.currentMaximum));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 278 */       if (this.currentMaximum > createFrom) {
/* 279 */         createdRenkos[0].setWickPrice(Double.valueOf(this.currentMaximum));
/*     */       }
/* 281 */       if (this.currentMinimum < createTo) {
/* 282 */         createdRenkos[(createdRenkos.length - 1)].setOppositeWickPrice(Double.valueOf(this.currentMinimum));
/*     */       }
/*     */     }
/*     */     
/* 286 */     this.currentMinimum = 9.223372036854776E18D;
/* 287 */     this.currentMaximum = -9.223372036854776E18D;
/*     */     
/* 289 */     this.leftPricePoint = createTo;
/*     */     
/* 291 */     return createdRenkos;
/*     */   }
/*     */   
/*     */   private RenkoData[] createRenkos(double priceFrom, double priceTo, int numOfBars, long dataTimeFrom, long dataTimeTo, double volume, long fec)
/*     */   {
/* 296 */     List<RenkoData> renkos = new ArrayList();
/*     */     
/* 298 */     boolean rising = priceFrom < priceTo;
/*     */     
/* 300 */     long fromTime = dataTimeFrom;
/* 301 */     long toTime = dataTimeTo;
/* 302 */     long currentFromTime = fromTime;
/* 303 */     long currentToTime = fromTime;
/*     */     
/*     */ 
/*     */ 
/* 307 */     int numOfPhantoms = numOfBars - 1;
/* 308 */     long totalTimeSpan = dataTimeTo - fromTime;
/* 309 */     long totalPhantomTimeSpan = numOfPhantoms * 2;
/*     */     
/* 311 */     long firstBarToTime = toTime;
/*     */     
/* 313 */     if (numOfPhantoms > 0) {
/* 314 */       if (totalPhantomTimeSpan + 2L >= totalTimeSpan) {
/* 315 */         firstBarToTime = fromTime + 1L;
/*     */       }
/*     */       else {
/* 318 */         firstBarToTime = toTime - totalPhantomTimeSpan;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 323 */     for (int x = 0; x < numOfBars; x++)
/*     */     {
/* 325 */       if (x == 0) {
/* 326 */         currentToTime = firstBarToTime;
/*     */       }
/*     */       else {
/* 329 */         currentToTime = currentFromTime + 1L;
/*     */       }
/*     */       
/* 332 */       if (currentToTime > toTime) {
/* 333 */         currentToTime = toTime;
/* 334 */         if (currentToTime <= currentFromTime) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 340 */       if (x == numOfBars - 1) {
/* 341 */         currentToTime = toTime;
/*     */       }
/*     */       
/* 344 */       double open = 0.0D;
/* 345 */       double close = 0.0D;
/* 346 */       double low = 0.0D;
/* 347 */       double high = 0.0D;
/*     */       
/* 349 */       if (rising) {
/* 350 */         open = roundPipScalePlusOne(priceFrom + x * this.range);
/* 351 */         close = roundPipScalePlusOne(open + this.range);
/* 352 */         low = roundPipScalePlusOne(open);
/* 353 */         high = roundPipScalePlusOne(close);
/*     */       }
/*     */       else {
/* 356 */         open = roundPipScalePlusOne(priceFrom - x * this.range);
/* 357 */         close = roundPipScalePlusOne(open - this.range);
/* 358 */         low = roundPipScalePlusOne(close);
/* 359 */         high = roundPipScalePlusOne(open);
/*     */       }
/*     */       
/*     */ 
/* 363 */       RenkoData renko = new RenkoData(currentFromTime, currentToTime, open, close, low, high, x == 0 ? volume : 0.0D, x == 0 ? fec : 0L);
/* 364 */       renko.setRising(Boolean.valueOf(rising));
/* 365 */       renko.setElementTimeFinishedCurrentBar(dataTimeTo);
/* 366 */       renko.setFinishedFromTheEnd(true);
/*     */       
/* 368 */       currentFromTime = currentToTime + 1L;
/* 369 */       currentToTime = currentFromTime;
/*     */       
/* 371 */       renkos.add(renko);
/*     */     }
/*     */     
/*     */ 
/* 375 */     return (RenkoData[])renkos.toArray(new RenkoData[renkos.size()]);
/*     */   }
/*     */   
/*     */   private boolean isGotRenkos(double previousClosePrice, double price)
/*     */   {
/* 380 */     double priceDiff = roundPipScalePlusOne(previousClosePrice - price);
/*     */     
/* 382 */     RenkoData lastCompleted = getLastCompletedData();
/*     */     
/* 384 */     if (lastCompleted == null) {
/* 385 */       return Math.abs(priceDiff) >= this.range;
/*     */     }
/*     */     
/* 388 */     if (lastCompleted.isRising().booleanValue())
/*     */     {
/* 390 */       if (priceDiff < 0.0D)
/*     */       {
/* 392 */         return Math.abs(priceDiff) >= this.range;
/*     */       }
/* 394 */       if (priceDiff > 0.0D)
/*     */       {
/* 396 */         return priceDiff >= roundPipScalePlusOne(this.range * 2.0D);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 401 */       if (priceDiff < 0.0D)
/*     */       {
/* 403 */         return Math.abs(priceDiff) >= roundPipScalePlusOne(this.range * 2.0D);
/*     */       }
/* 405 */       if (priceDiff > 0.0D)
/*     */       {
/* 407 */         return priceDiff >= this.range;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 412 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 419 */     resetResulArray();
/* 420 */     resetSoft();
/*     */   }
/*     */   
/*     */   private void resetSoft()
/*     */   {
/* 425 */     this.lastElementIndex = -1;
/* 426 */     this.loadedBarsCount = 0;
/* 427 */     this.leftPricePoint = Double.MIN_VALUE;
/* 428 */     this.createBarsFromTime = Long.MAX_VALUE;
/* 429 */     this.accumulatedVolume = 0.0D;
/* 430 */     this.accumulatedFEC = 0L;
/* 431 */     this.currentMinimum = Double.MAX_VALUE;
/* 432 */     this.currentMaximum = Double.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public boolean isAllDesiredDataLoaded()
/*     */   {
/* 437 */     return getLoadedElementsNumber() >= getDesiredDatasCount();
/*     */   }
/*     */   
/*     */   public RenkoData getLastCompletedData()
/*     */   {
/* 442 */     if (getLastElementIndex() >= 0) {
/* 443 */       return ((RenkoData[])getResult())[getLastElementIndex()];
/*     */     }
/* 445 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setupLastData(RenkoData data)
/*     */   {
/* 451 */     reset();
/*     */     
/* 453 */     if (data == null) {
/* 454 */       return;
/*     */     }
/*     */     
/* 457 */     this.createBarsFromTime = (data.getEndTime() + 1L);
/*     */     
/*     */ 
/* 460 */     this.lastElementIndex += 1;
/* 461 */     ((RenkoData[])getResult())[getLastElementIndex()] = data;
/*     */     
/* 463 */     double price = 0.0D;
/* 464 */     if (this.ohlc == null) {
/* 465 */       price = roundPipScalePlusOne(data.getClose());
/*     */     }
/*     */     else {
/* 468 */       price = data.getClose();
/*     */     }
/* 470 */     this.leftPricePoint = price;
/*     */     
/* 472 */     if (data.getWickPrice() != null) {
/* 473 */       if (data.isRising().booleanValue()) {
/* 474 */         this.currentMinimum = data.getWickPrice().doubleValue();
/*     */       }
/*     */       else {
/* 477 */         this.currentMaximum = data.getWickPrice().doubleValue();
/*     */       }
/*     */     }
/* 480 */     if (data.getOppositeWickPrice() != null) {
/* 481 */       if (data.isRising().booleanValue()) {
/* 482 */         this.currentMaximum = data.getOppositeWickPrice().doubleValue();
/*     */       }
/*     */       else {
/* 485 */         this.currentMinimum = data.getOppositeWickPrice().doubleValue();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setupIndicationPoint(RenkoData indicationPoint)
/*     */   {
/* 492 */     setupLastData(indicationPoint);
/* 493 */     this.accumulatedVolume = indicationPoint.getVolume();
/* 494 */     this.accumulatedFEC = indicationPoint.getFormedElementsCount();
/*     */   }
/*     */   
/*     */   public boolean canContinueCurrentDataConstruction(RenkoData currentData, TickData sourceData)
/*     */   {
/* 499 */     return true;
/*     */   }
/*     */   
/*     */   protected RenkoData createBar(double price, double volume, long time, long ticksCount, RenkoData previousBar)
/*     */   {
/* 504 */     return null;
/*     */   }
/*     */   
/*     */   protected RenkoData continueBar(RenkoData bar, double price, Double volume, Long time, long incTicksCount)
/*     */   {
/* 509 */     return null;
/*     */   }
/*     */   
/*     */   protected RenkoData[] createArray(RenkoData bar)
/*     */   {
/* 514 */     return null;
/*     */   }
/*     */   
/*     */   protected RenkoData[] createArray(int size)
/*     */   {
/* 519 */     return new RenkoData[size];
/*     */   }
/*     */   
/*     */   protected double getBasePrice(TickData data) {
/* 523 */     if (data == null) {
/* 524 */       return Double.MIN_VALUE;
/*     */     }
/*     */     
/* 527 */     double pipValue = getInstrument().getPipValue();
/* 528 */     double price = getPrice(data);
/*     */     
/* 530 */     if (this.brickSize.getPipCount() < 5)
/*     */     {
/* 532 */       return StratUtils.roundHalfUp(price, this.pipScale);
/*     */     }
/*     */     
/*     */     double priceRange;
/*     */     double priceRange;
/* 537 */     if (this.brickSize.getPipCount() < 10) {
/* 538 */       priceRange = pipValue * 5.0D;
/*     */     }
/*     */     else {
/* 541 */       priceRange = pipValue * 10.0D;
/*     */     }
/*     */     
/* 544 */     double remnant = roundPipScalePlusOne(price % priceRange);
/* 545 */     double half = roundPipScalePlusOne(priceRange / 2.0D);
/*     */     
/* 547 */     if (remnant < half) {
/* 548 */       return price - remnant;
/*     */     }
/*     */     
/* 551 */     return price + (priceRange - remnant);
/*     */   }
/*     */   
/*     */   protected double roundPipScalePlusOne(double value)
/*     */   {
/* 556 */     return StratUtils.round(value, this.pipScale + 1);
/*     */   }
/*     */   
/*     */   protected void resetResulArray() {
/* 560 */     this.result = new RenkoData[getDesiredDatasCount()];
/*     */   }
/*     */   
/*     */   public int getLoadedBarsCount() {
/* 564 */     return this.loadedBarsCount;
/*     */   }
/*     */   
/*     */   public void setLoadedBarsCount(int count) {
/* 568 */     this.loadedBarsCount = count;
/*     */   }
/*     */   
/*     */   public JForexPeriod getJfPeriod() {
/* 572 */     return this.jfPeriod;
/*     */   }
/*     */   
/*     */   public PriceRange getBrickSize() {
/* 576 */     return this.brickSize;
/*     */   }
/*     */   
/*     */   public double getRange() {
/* 580 */     return this.range;
/*     */   }
/*     */   
/*     */   public RenkoCreationPoint getOhlc() {
/* 584 */     return this.ohlc;
/*     */   }
/*     */   
/*     */   public int getPipScale() {
/* 588 */     return this.pipScale;
/*     */   }
/*     */   
/*     */   protected double getDataVolume(TickData data)
/*     */   {
/* 593 */     if (data == null) {
/* 594 */       return Double.MIN_VALUE;
/*     */     }
/*     */     
/* 597 */     switch (getOfferSide()) {
/*     */     case ASK: 
/* 599 */       return data.getAskVolume();
/*     */     case BID: 
/* 601 */       return data.getBidVolume();
/*     */     }
/*     */     
/* 604 */     return Double.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public long getCreateBarsFromTime()
/*     */   {
/* 609 */     return this.createBarsFromTime;
/*     */   }
/*     */   
/*     */   public double getLeftPricePoint() {
/* 613 */     return this.leftPricePoint;
/*     */   }
/*     */   
/*     */   public double getAccumulatedVolume()
/*     */   {
/* 618 */     return this.accumulatedVolume;
/*     */   }
/*     */   
/*     */   public long getAccumulatedFEC()
/*     */   {
/* 623 */     return this.accumulatedFEC;
/*     */   }
/*     */   
/*     */   public double getCurrentMinimum()
/*     */   {
/* 628 */     return this.currentMinimum;
/*     */   }
/*     */   
/*     */   public double getCurrentMaximum()
/*     */   {
/* 633 */     return this.currentMaximum;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\nisonrenko\RenkoCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */