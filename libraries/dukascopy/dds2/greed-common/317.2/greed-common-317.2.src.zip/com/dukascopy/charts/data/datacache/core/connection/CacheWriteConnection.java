/*     */ package com.dukascopy.charts.data.datacache.core.connection;
/*     */ 
/*     */ import com.dukascopy.charts.data.datacache.core.CacheCoreHelper;
/*     */ import com.dukascopy.charts.data.datacache.core.lock.CacheFileHandler;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheWriteConnection
/*     */   extends CacheReadConnection
/*     */   implements ICacheWriteConnection
/*     */ {
/*  25 */   private static final Logger LOGGER = LoggerFactory.getLogger(CacheWriteConnection.class);
/*     */   
/*     */   private RandomAccessFile writeRandomAccessFile;
/*     */   private FileOutputStream fileOutputStream;
/*     */   private FileWriter fileWriter;
/*     */   
/*     */   public CacheWriteConnection(CacheFileHandler cacheFileHandler)
/*     */   {
/*  33 */     super(cacheFileHandler);
/*     */   }
/*     */   
/*     */   public void createFile() throws IOException
/*     */   {
/*  38 */     checkIsActive();
/*     */     
/*  40 */     if (this.cacheFileHandler.isFileExists()) {
/*  41 */       throw new FileNotFoundException("File " + this.cacheFileHandler.getFile() + " already exist");
/*     */     }
/*     */     
/*  44 */     File file = this.cacheFileHandler.getFile();
/*     */     
/*  46 */     CacheCoreHelper.ensureFileCreated(file);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */     this.cacheFileHandler.setFileExists(true);
/*     */   }
/*     */   
/*     */   public boolean mkdirs()
/*     */   {
/*  57 */     checkIsActive();
/*     */     
/*  59 */     if (isFileExists()) {
/*  60 */       boolean result = this.cacheFileHandler.getFile().mkdirs();
/*  61 */       this.cacheFileHandler.setFileExists(this.cacheFileHandler.getFile().exists());
/*  62 */       return result;
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */   
/*     */   public boolean renameFrom(File file) throws IOException
/*     */   {
/*  69 */     checkIsActive();
/*     */     
/*  71 */     if (isFileExists()) {
/*  72 */       throw new IOException("File " + this.cacheFileHandler.getFile() + " already exist");
/*     */     }
/*     */     
/*  75 */     boolean result = file.renameTo(this.cacheFileHandler.getFile());
/*  76 */     this.cacheFileHandler.setFileExists(this.cacheFileHandler.getFile().exists());
/*     */     
/*  78 */     return result;
/*     */   }
/*     */   
/*     */   public void deleteFile() throws IOException
/*     */   {
/*  83 */     checkIsActive();
/*     */     
/*  85 */     if (!this.cacheFileHandler.isFileExists()) {
/*  86 */       throw new FileNotFoundException("File " + this.cacheFileHandler.getFile() + " doesn't exist");
/*     */     }
/*     */     
/*  89 */     if (!this.cacheFileHandler.clearReadCache()) {
/*  90 */       throw new IOException("Failed to clear cache before delete file " + this.cacheFileHandler.getFile());
/*     */     }
/*     */     
/*  93 */     if (this.writeRandomAccessFile != null) {
/*  94 */       this.writeRandomAccessFile.close();
/*  95 */       this.writeRandomAccessFile = null;
/*     */     }
/*     */     
/*  98 */     if (this.fileOutputStream != null) {
/*  99 */       this.fileOutputStream.close();
/* 100 */       this.fileOutputStream = null;
/*     */     }
/*     */     
/* 103 */     if (this.fileWriter != null) {
/* 104 */       this.fileWriter.close();
/* 105 */       this.fileWriter = null;
/*     */     }
/*     */     
/* 108 */     if (!this.cacheFileHandler.getFile().delete()) {
/* 109 */       throw new IOException("Failed to delete file " + this.cacheFileHandler.getFile());
/*     */     }
/*     */     
/* 112 */     this.cacheFileHandler.setFileExists(false);
/*     */   }
/*     */   
/*     */   protected RandomAccessFile doGetRandomAccessFile() throws IOException
/*     */   {
/* 117 */     if ((this.writeRandomAccessFile == null) && (this.cacheFileHandler.isFileExists())) {
/* 118 */       this.writeRandomAccessFile = new RandomAccessFile(this.cacheFileHandler.getFile(), "rw");
/*     */     }
/* 120 */     return this.writeRandomAccessFile;
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException
/*     */   {
/* 125 */     checkIsActive();
/*     */     
/* 127 */     getRandomAccessFile().write(b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b) throws IOException
/*     */   {
/* 132 */     checkIsActive();
/*     */     
/* 134 */     getRandomAccessFile().write(b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException
/*     */   {
/* 139 */     checkIsActive();
/*     */     
/* 141 */     getRandomAccessFile().write(b, off, len);
/*     */   }
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException
/*     */   {
/* 146 */     checkIsActive();
/*     */     
/* 148 */     getRandomAccessFile().writeBoolean(v);
/*     */   }
/*     */   
/*     */   public void writeByte(int v) throws IOException
/*     */   {
/* 153 */     checkIsActive();
/*     */     
/* 155 */     getRandomAccessFile().writeByte(v);
/*     */   }
/*     */   
/*     */   public void writeShort(int v) throws IOException
/*     */   {
/* 160 */     checkIsActive();
/*     */     
/* 162 */     getRandomAccessFile().writeShort(v);
/*     */   }
/*     */   
/*     */   public void writeChar(int v) throws IOException
/*     */   {
/* 167 */     checkIsActive();
/*     */     
/* 169 */     getRandomAccessFile().writeChar(v);
/*     */   }
/*     */   
/*     */   public void writeInt(int v) throws IOException
/*     */   {
/* 174 */     checkIsActive();
/*     */     
/* 176 */     getRandomAccessFile().writeInt(v);
/*     */   }
/*     */   
/*     */   public void writeLong(long v) throws IOException
/*     */   {
/* 181 */     checkIsActive();
/*     */     
/* 183 */     getRandomAccessFile().writeLong(v);
/*     */   }
/*     */   
/*     */   public void writeFloat(float v) throws IOException
/*     */   {
/* 188 */     checkIsActive();
/*     */     
/* 190 */     getRandomAccessFile().writeFloat(v);
/*     */   }
/*     */   
/*     */   public void writeDouble(double v) throws IOException
/*     */   {
/* 195 */     checkIsActive();
/*     */     
/* 197 */     getRandomAccessFile().writeDouble(v);
/*     */   }
/*     */   
/*     */   public void writeBytes(String s) throws IOException
/*     */   {
/* 202 */     checkIsActive();
/*     */     
/* 204 */     getRandomAccessFile().writeBytes(s);
/*     */   }
/*     */   
/*     */   public void writeChars(String s) throws IOException
/*     */   {
/* 209 */     checkIsActive();
/*     */     
/* 211 */     getRandomAccessFile().writeChars(s);
/*     */   }
/*     */   
/*     */   public void writeUTF(String str) throws IOException
/*     */   {
/* 216 */     checkIsActive();
/*     */     
/* 218 */     getRandomAccessFile().writeUTF(str);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/* 223 */     super.close();
/*     */     
/* 225 */     if (this.writeRandomAccessFile != null) {
/*     */       try {
/* 227 */         this.writeRandomAccessFile.close();
/*     */       } catch (Throwable e) {
/* 229 */         LOGGER.error(e.getLocalizedMessage(), e);
/*     */       }
/* 231 */       this.writeRandomAccessFile = null;
/*     */     }
/*     */     
/* 234 */     if (this.fileOutputStream != null) {
/*     */       try {
/* 236 */         this.fileOutputStream.close();
/*     */       } catch (Throwable e) {
/* 238 */         LOGGER.error(e.getLocalizedMessage(), e);
/*     */       }
/* 240 */       this.fileOutputStream = null;
/*     */     }
/*     */     
/* 243 */     if (this.fileWriter != null) {
/*     */       try {
/* 245 */         this.fileWriter.close();
/*     */       } catch (Throwable e) {
/* 247 */         LOGGER.error(e.getLocalizedMessage(), e);
/*     */       }
/* 249 */       this.fileWriter = null;
/*     */     }
/*     */     
/* 252 */     performWriteUnlock();
/*     */   }
/*     */   
/*     */   protected void performWriteUnlock() {
/* 256 */     this.cacheFileHandler.writeUnlock();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void performReadUnlock() {}
/*     */   
/*     */ 
/*     */   public FileOutputStream getFileOutputStream()
/*     */     throws FileNotFoundException
/*     */   {
/* 266 */     checkIsActive();
/*     */     
/* 268 */     if (this.fileOutputStream == null) {
/* 269 */       checkAndThrowFileNotFound();
/* 270 */       this.fileOutputStream = new FileOutputStream(this.cacheFileHandler.getFile());
/*     */     }
/* 272 */     return this.fileOutputStream;
/*     */   }
/*     */   
/*     */   public FileWriter getFileWriter() throws IOException
/*     */   {
/* 277 */     checkIsActive();
/*     */     
/* 279 */     if (this.fileWriter == null) {
/* 280 */       checkAndThrowFileNotFound();
/* 281 */       this.fileWriter = new FileWriter(this.cacheFileHandler.getFile());
/*     */     }
/* 283 */     return this.fileWriter;
/*     */   }
/*     */   
/*     */   public void setLength(int length) throws IOException
/*     */   {
/* 288 */     checkIsActive();
/*     */     
/* 290 */     getRandomAccessFile().setLength(length);
/*     */   }
/*     */   
/*     */   public void ensureFileCreated() throws IOException
/*     */   {
/* 295 */     if (!isFileExists()) {
/* 296 */       createFile();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\CacheWriteConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */