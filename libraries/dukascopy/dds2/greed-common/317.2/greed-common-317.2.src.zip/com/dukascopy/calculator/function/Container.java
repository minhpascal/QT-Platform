/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.complex.Complex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Container
/*    */   extends PObject
/*    */ {
/*    */   protected double d;
/*    */   protected OObject c;
/*    */   protected boolean error;
/*    */   
/*    */   public Container()
/*    */   {
/* 18 */     this.error = false;
/* 19 */     this.d = new Double(0.0D).doubleValue();
/* 20 */     this.c = new Complex();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double dvalue()
/*    */   {
/* 28 */     return this.d;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public OObject value()
/*    */   {
/* 35 */     return this.c;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean error()
/*    */   {
/* 44 */     return this.error;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Container.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */