/*     */ package com.dukascopy.charts.data.datacache.core;
/*     */ 
/*     */ import com.dukascopy.charts.data.datacache.core.connection.CacheReadConnection;
/*     */ import com.dukascopy.charts.data.datacache.core.connection.CacheWriteConnection;
/*     */ import com.dukascopy.charts.data.datacache.core.connection.ICacheConnection;
/*     */ import com.dukascopy.charts.data.datacache.core.connection.ICacheReadConnection;
/*     */ import com.dukascopy.charts.data.datacache.core.connection.ICacheWriteConnection;
/*     */ import com.dukascopy.charts.data.datacache.core.lock.CacheFileHandler;
/*     */ import com.dukascopy.charts.data.datacache.core.lock.GlobalLockCacheFileHandler;
/*     */ import com.dukascopy.charts.data.datacache.core.lock.HandlerSyncronizerCounter;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheCore
/*     */   implements ICacheCore
/*     */ {
/*  36 */   private static final Logger LOGGER = LoggerFactory.getLogger(CacheCore.class);
/*     */   
/*  38 */   private final int CONCURRENCY_LEVEL = 100;
/*     */   
/*  40 */   private final Map<File, CacheFileHandler> cacheFileHandlers = new ConcurrentHashMap(200, 0.75F, 100);
/*  41 */   private final ConcurrentMap<File, HandlerSyncronizerCounter> fileSyncObjects = new ConcurrentHashMap(200, 0.75F, 100);
/*  42 */   private final HandlerSyncronizerCounter ZERO_HANDLER_SYNCHRONIZERS = new HandlerSyncronizerCounter(0);
/*     */   
/*     */   private final boolean useGlobalLocking;
/*     */   
/*     */   private final boolean useLocalReadWriteLocking;
/*     */   
/*     */   private final long globalLockAcquiringOneIterationTimeoutInMillis;
/*     */   
/*     */   private final int globalLockAcquiringIterationsCount;
/*     */   
/*     */   private final IGlobalLockFileFactory globalLockFileFactory;
/*     */   
/*     */   private final long fileHandlersCacheClearanceDelay;
/*     */   
/*     */   private final long fileHandlersCacheClearancePeriod;
/*     */   
/*     */   private final boolean deleteGlobalLockFiles;
/*     */   private final Timer timer;
/*     */   private static CacheCore instance;
/*     */   
/*     */   public CacheCore(boolean useLocalReadWriteLocking, boolean useGlobalLocking)
/*     */   {
/*  64 */     this(useLocalReadWriteLocking, useGlobalLocking, 100L, 100, new DefaultGlobalLockFileFactory(), TimeUnit.MINUTES.toMillis(1L), TimeUnit.MINUTES.toMillis(5L), true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheCore(boolean useLocalReadWriteLocking, boolean useGlobalLocking, long globalLockAcquiringOneIterationTimeoutInMillis, int globalLockAcquiringIterationsCount, IGlobalLockFileFactory globalLockFileFactory, long fileHandlersCacheClearanceDelay, long fileHandlersCacheClearancePeriod, boolean deleteGlobalLockFiles)
/*     */   {
/*  86 */     this.useGlobalLocking = useGlobalLocking;
/*  87 */     this.useLocalReadWriteLocking = useLocalReadWriteLocking;
/*  88 */     this.globalLockAcquiringOneIterationTimeoutInMillis = globalLockAcquiringOneIterationTimeoutInMillis;
/*  89 */     this.globalLockAcquiringIterationsCount = globalLockAcquiringIterationsCount;
/*  90 */     this.globalLockFileFactory = globalLockFileFactory;
/*  91 */     this.deleteGlobalLockFiles = deleteGlobalLockFiles;
/*     */     
/*  93 */     if (fileHandlersCacheClearanceDelay < 0L) {
/*  94 */       throw new IllegalArgumentException("cacheClearanceDelay is negative " + fileHandlersCacheClearanceDelay);
/*     */     }
/*  96 */     if (fileHandlersCacheClearancePeriod <= 0L) {
/*  97 */       throw new IllegalArgumentException("cacheClearancePeriod is not positive " + fileHandlersCacheClearancePeriod);
/*     */     }
/*     */     
/* 100 */     this.fileHandlersCacheClearanceDelay = fileHandlersCacheClearanceDelay;
/* 101 */     this.fileHandlersCacheClearancePeriod = fileHandlersCacheClearancePeriod;
/*     */     
/* 103 */     this.timer = new Timer("CacheCoreCleaner", true);
/*     */   }
/*     */   
/*     */   public ICacheReadConnection getCacheReadConnection(File file) throws IOException, TimeoutException
/*     */   {
/* 108 */     ICacheReadConnection connection = getCacheReadConnection(file, false);
/* 109 */     return connection;
/*     */   }
/*     */   
/*     */   public ICacheWriteConnection getCacheWriteConnection(File file) throws TimeoutException, IOException
/*     */   {
/* 114 */     ICacheWriteConnection connection = getCacheWriteConnection(file, false);
/* 115 */     return connection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ICacheReadConnection getCacheReadConnection(File file, boolean deleteGlobalLockFileOnConnectionClose)
/*     */     throws TimeoutException, IOException
/*     */   {
/* 123 */     CacheFileHandler handler = getHandler(file, true, deleteGlobalLockFileOnConnectionClose);
/* 124 */     ICacheReadConnection connection = new CacheReadConnection(handler);
/* 125 */     return connection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ICacheWriteConnection getCacheWriteConnection(File file, boolean deleteGlobalLockFileOnConnectionClose)
/*     */     throws TimeoutException, IOException
/*     */   {
/* 133 */     CacheFileHandler handler = getHandler(file, false, deleteGlobalLockFileOnConnectionClose);
/* 134 */     ICacheWriteConnection connection = new CacheWriteConnection(handler);
/* 135 */     return connection;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private CacheFileHandler getHandler(File file, boolean readLock, boolean deleteGlobalLockFileOnConnectionClose)
/*     */     throws TimeoutException, IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokespecial 49	com/dukascopy/charts/data/datacache/core/CacheCore:getHandlerSyncronizer	(Ljava/io/File;)Lcom/dukascopy/charts/data/datacache/core/lock/HandlerSyncronizerCounter;
/*     */     //   5: astore 4
/*     */     //   7: aload 4
/*     */     //   9: dup
/*     */     //   10: astore 5
/*     */     //   12: monitorenter
/*     */     //   13: aload_0
/*     */     //   14: getfield 16	com/dukascopy/charts/data/datacache/core/CacheCore:cacheFileHandlers	Ljava/util/Map;
/*     */     //   17: aload_1
/*     */     //   18: invokeinterface 50 2 0
/*     */     //   23: checkcast 51	com/dukascopy/charts/data/datacache/core/lock/CacheFileHandler
/*     */     //   26: astore 6
/*     */     //   28: aload 6
/*     */     //   30: ifnonnull +105 -> 135
/*     */     //   33: aload_0
/*     */     //   34: getfield 22	com/dukascopy/charts/data/datacache/core/CacheCore:useLocalReadWriteLocking	Z
/*     */     //   37: ifeq +14 -> 51
/*     */     //   40: new 52	java/util/concurrent/locks/ReentrantReadWriteLock
/*     */     //   43: dup
/*     */     //   44: iconst_1
/*     */     //   45: invokespecial 53	java/util/concurrent/locks/ReentrantReadWriteLock:<init>	(Z)V
/*     */     //   48: goto +4 -> 52
/*     */     //   51: aconst_null
/*     */     //   52: astore 7
/*     */     //   54: aload_0
/*     */     //   55: getfield 21	com/dukascopy/charts/data/datacache/core/CacheCore:useGlobalLocking	Z
/*     */     //   58: ifeq +31 -> 89
/*     */     //   61: new 54	com/dukascopy/charts/data/datacache/core/lock/GlobalLockCacheFileHandler
/*     */     //   64: dup
/*     */     //   65: aload_0
/*     */     //   66: getfield 25	com/dukascopy/charts/data/datacache/core/CacheCore:globalLockFileFactory	Lcom/dukascopy/charts/data/datacache/core/IGlobalLockFileFactory;
/*     */     //   69: aload_1
/*     */     //   70: invokeinterface 55 2 0
/*     */     //   75: aload_0
/*     */     //   76: getfield 23	com/dukascopy/charts/data/datacache/core/CacheCore:globalLockAcquiringOneIterationTimeoutInMillis	J
/*     */     //   79: aload_0
/*     */     //   80: getfield 24	com/dukascopy/charts/data/datacache/core/CacheCore:globalLockAcquiringIterationsCount	I
/*     */     //   83: invokespecial 56	com/dukascopy/charts/data/datacache/core/lock/GlobalLockCacheFileHandler:<init>	(Ljava/io/File;JI)V
/*     */     //   86: goto +4 -> 90
/*     */     //   89: aconst_null
/*     */     //   90: astore 8
/*     */     //   92: new 51	com/dukascopy/charts/data/datacache/core/lock/CacheFileHandler
/*     */     //   95: dup
/*     */     //   96: aload_1
/*     */     //   97: aload 7
/*     */     //   99: aload 8
/*     */     //   101: iload_3
/*     */     //   102: ifeq +14 -> 116
/*     */     //   105: aload_0
/*     */     //   106: getfield 21	com/dukascopy/charts/data/datacache/core/CacheCore:useGlobalLocking	Z
/*     */     //   109: ifeq +7 -> 116
/*     */     //   112: iconst_1
/*     */     //   113: goto +4 -> 117
/*     */     //   116: iconst_0
/*     */     //   117: invokespecial 57	com/dukascopy/charts/data/datacache/core/lock/CacheFileHandler:<init>	(Ljava/io/File;Ljava/util/concurrent/locks/ReentrantReadWriteLock;Lcom/dukascopy/charts/data/datacache/core/lock/GlobalLockCacheFileHandler;Z)V
/*     */     //   120: astore 6
/*     */     //   122: aload_0
/*     */     //   123: getfield 16	com/dukascopy/charts/data/datacache/core/CacheCore:cacheFileHandlers	Ljava/util/Map;
/*     */     //   126: aload_1
/*     */     //   127: aload 6
/*     */     //   129: invokeinterface 58 3 0
/*     */     //   134: pop
/*     */     //   135: iload_2
/*     */     //   136: ifeq +11 -> 147
/*     */     //   139: aload 6
/*     */     //   141: invokevirtual 59	com/dukascopy/charts/data/datacache/core/lock/CacheFileHandler:readLock	()V
/*     */     //   144: goto +8 -> 152
/*     */     //   147: aload 6
/*     */     //   149: invokevirtual 60	com/dukascopy/charts/data/datacache/core/lock/CacheFileHandler:writeLock	()V
/*     */     //   152: aload_1
/*     */     //   153: invokevirtual 61	java/io/File:exists	()Z
/*     */     //   156: istore 7
/*     */     //   158: aload 6
/*     */     //   160: iload 7
/*     */     //   162: invokevirtual 62	com/dukascopy/charts/data/datacache/core/lock/CacheFileHandler:setFileExists	(Z)V
/*     */     //   165: aload 6
/*     */     //   167: astore 8
/*     */     //   169: aload 5
/*     */     //   171: monitorexit
/*     */     //   172: aload_0
/*     */     //   173: aload_1
/*     */     //   174: aload 4
/*     */     //   176: invokespecial 63	com/dukascopy/charts/data/datacache/core/CacheCore:releaseHandlerSyncronizer	(Ljava/io/File;Lcom/dukascopy/charts/data/datacache/core/lock/HandlerSyncronizerCounter;)V
/*     */     //   179: aload 8
/*     */     //   181: areturn
/*     */     //   182: astore 9
/*     */     //   184: aload 5
/*     */     //   186: monitorexit
/*     */     //   187: aload 9
/*     */     //   189: athrow
/*     */     //   190: astore 10
/*     */     //   192: aload_0
/*     */     //   193: aload_1
/*     */     //   194: aload 4
/*     */     //   196: invokespecial 63	com/dukascopy/charts/data/datacache/core/CacheCore:releaseHandlerSyncronizer	(Ljava/io/File;Lcom/dukascopy/charts/data/datacache/core/lock/HandlerSyncronizerCounter;)V
/*     */     //   199: aload 10
/*     */     //   201: athrow
/*     */     // Line number table:
/*     */     //   Java source line #139	-> byte code offset #0
/*     */     //   Java source line #141	-> byte code offset #7
/*     */     //   Java source line #142	-> byte code offset #13
/*     */     //   Java source line #144	-> byte code offset #28
/*     */     //   Java source line #146	-> byte code offset #33
/*     */     //   Java source line #147	-> byte code offset #54
/*     */     //   Java source line #156	-> byte code offset #92
/*     */     //   Java source line #163	-> byte code offset #122
/*     */     //   Java source line #166	-> byte code offset #135
/*     */     //   Java source line #167	-> byte code offset #139
/*     */     //   Java source line #170	-> byte code offset #147
/*     */     //   Java source line #173	-> byte code offset #152
/*     */     //   Java source line #174	-> byte code offset #158
/*     */     //   Java source line #176	-> byte code offset #165
/*     */     //   Java source line #179	-> byte code offset #172
/*     */     //   Java source line #177	-> byte code offset #182
/*     */     //   Java source line #179	-> byte code offset #190
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	202	0	this	CacheCore
/*     */     //   0	202	1	file	File
/*     */     //   0	202	2	readLock	boolean
/*     */     //   0	202	3	deleteGlobalLockFileOnConnectionClose	boolean
/*     */     //   5	190	4	syncObject	HandlerSyncronizerCounter
/*     */     //   26	140	6	handler	CacheFileHandler
/*     */     //   52	46	7	localReadWriteLock	java.util.concurrent.locks.ReentrantReadWriteLock
/*     */     //   156	5	7	fileExists	boolean
/*     */     //   90	90	8	globalLockFile	GlobalLockCacheFileHandler
/*     */     //   182	6	9	localObject1	Object
/*     */     //   190	10	10	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   13	172	182	finally
/*     */     //   182	187	182	finally
/*     */     //   7	172	190	finally
/*     */     //   182	192	190	finally
/*     */   }
/*     */   
/*     */   private void releaseHandlerSyncronizer(File file, HandlerSyncronizerCounter counter)
/*     */   {
/* 184 */     int counterValue = counter.dec();
/* 185 */     if (counterValue == 0) {
/* 186 */       this.fileSyncObjects.remove(file, this.ZERO_HANDLER_SYNCHRONIZERS);
/*     */     }
/* 188 */     else if (counterValue < 0) {
/* 189 */       throw new IllegalArgumentException("Counter value '" + counterValue + "' could not be less than zero - most likely this is algoritm bug");
/*     */     }
/*     */   }
/*     */   
/*     */   private HandlerSyncronizerCounter getHandlerSyncronizer(File file) {
/* 194 */     HandlerSyncronizerCounter result = new HandlerSyncronizerCounter(1);
/* 195 */     HandlerSyncronizerCounter old = (HandlerSyncronizerCounter)this.fileSyncObjects.putIfAbsent(file, result);
/*     */     
/* 197 */     if (old != null) {
/* 198 */       result = old;
/* 199 */       int counterValue = result.inc();
/* 200 */       if (counterValue <= 0) {
/* 201 */         throw new IllegalArgumentException("Counter value '" + counterValue + "' must be greater than zero - most likely this is algoritm bug");
/*     */       }
/*     */       
/* 204 */       this.fileSyncObjects.putIfAbsent(file, result);
/*     */     }
/* 206 */     return result;
/*     */   }
/*     */   
/*     */   public void close(ICacheConnection connection) throws Exception
/*     */   {
/* 211 */     connection.close();
/*     */   }
/*     */   
/*     */   public void setup() {
/* 215 */     this.timer.schedule(new TimerTask()
/*     */     {
/*     */       public void run()
/*     */       {
/*     */         try {
/* 220 */           CacheCore.this.cleanup(false);
/*     */         } catch (IOException e) {
/* 222 */           CacheCore.LOGGER.error("Failed to clear cache " + e.getLocalizedMessage(), e); } } }, this.fileHandlersCacheClearanceDelay, this.fileHandlersCacheClearancePeriod);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 232 */     this.timer.cancel();
/*     */     try {
/* 234 */       if (!cleanup(true)) {
/* 235 */         LOGGER.warn("Failed to make correct shutdown, not all cache items are removed");
/*     */       }
/*     */     } catch (Exception e) {
/* 238 */       LOGGER.error("Failed to shutdown", e);
/*     */     }
/* 240 */     instance = null;
/*     */   }
/*     */   
/*     */   public boolean cleanup(boolean cleanEverything) throws IOException
/*     */   {
/* 245 */     boolean anythingToClean = true;
/*     */     
/* 247 */     while (anythingToClean)
/*     */     {
/* 249 */       anythingToClean = false;
/*     */       
/* 251 */       Iterator<Map.Entry<File, CacheFileHandler>> iter = this.cacheFileHandlers.entrySet().iterator();
/* 252 */       while (iter.hasNext()) {
/* 253 */         Map.Entry<File, CacheFileHandler> entry = (Map.Entry)iter.next();
/* 254 */         CacheFileHandler handler = (CacheFileHandler)entry.getValue();
/*     */         
/* 256 */         if ((!handler.isGlobalLockingEnabled()) || (!handler.isGloballyLocked())) {
/* 257 */           if (!handler.isLocalLockingEnabled()) {
/* 258 */             if (handler.clearReadCache()) {
/* 259 */               if (this.deleteGlobalLockFiles) {
/* 260 */                 deleteLockFile(handler);
/*     */               }
/* 262 */               iter.remove();
/*     */             }
/*     */           } else {
/* 265 */             boolean locked = handler.tryLocalWriteLock();
/* 266 */             if (locked) {
/*     */               try {
/* 268 */                 if (handler.clearReadCache()) {
/* 269 */                   if (this.deleteGlobalLockFiles) {
/* 270 */                     deleteLockFile(handler);
/*     */                   }
/* 272 */                   iter.remove();
/*     */                 }
/*     */               } finally {
/* 275 */                 handler.unlockLocalWriteLock();
/*     */               }
/*     */             } else {
/* 278 */               anythingToClean = true;
/*     */             }
/*     */           }
/*     */         } else {
/* 282 */           anythingToClean = true;
/*     */         }
/*     */       }
/*     */       
/* 286 */       if (!cleanEverything)
/*     */         break;
/* 288 */       if (anythingToClean) {
/*     */         try {
/* 290 */           Thread.sleep(100L);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/*     */     }
/*     */     
/* 296 */     return this.cacheFileHandlers.isEmpty();
/*     */   }
/*     */   
/*     */   private void deleteLockFile(CacheFileHandler handler) {
/* 300 */     File file = handler.getGlobalLockFileHandler().getFile();
/* 301 */     file.delete();
/*     */     
/* 303 */     File parent = file.getParentFile();
/* 304 */     if (parent != null) {
/* 305 */       File[] children = parent.listFiles();
/* 306 */       if ((children == null) || (children.length <= 0)) {
/* 307 */         parent.delete();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static synchronized CacheCore getInstance() {
/* 313 */     if (instance == null) {
/* 314 */       instance = new CacheCore(true, true);
/* 315 */       instance.setup();
/*     */     }
/* 317 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\CacheCore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */