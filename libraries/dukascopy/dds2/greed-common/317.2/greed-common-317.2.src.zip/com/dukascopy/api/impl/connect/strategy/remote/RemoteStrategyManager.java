/*     */ package com.dukascopy.api.impl.connect.strategy.remote;
/*     */ 
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.impl.connect.strategy.StrategyManager;
/*     */ import com.dukascopy.api.impl.connect.strategy.StrategyResponse;
/*     */ import com.dukascopy.api.strategy.IStrategyResponse;
/*     */ import com.dukascopy.api.strategy.remote.IRemoteStrategyDescriptor;
/*     */ import com.dukascopy.api.strategy.remote.IRemoteStrategyManager;
/*     */ import com.dukascopy.api.strategy.remote.RemoteStrategyListener;
/*     */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.bean.StrategyNewBean;
/*     */ import com.dukascopy.dds3.transport.msg.jss.StrategyProcessDescriptor;
/*     */ import com.dukascopy.dds3.transport.msg.jss.StrategyState;
/*     */ import com.dukascopy.jss.IJssManager;
/*     */ import com.dukascopy.jss.JssException;
/*     */ import com.dukascopy.jss.nofication.JssEventsAdapter;
/*     */ import com.dukascopy.jss.nofication.JssEventsListener;
/*     */ import com.dukascopy.jss.nofication.bean.RemoteStrategiesListBean;
/*     */ import com.dukascopy.jss.nofication.bean.RemoteStrategyRunBean;
/*     */ import com.dukascopy.jss.nofication.bean.RemoteStrategyRunErrorBean;
/*     */ import com.dukascopy.jss.nofication.bean.RemoteStrategyStateChangeBean;
/*     */ import com.dukascopy.jss.nofication.bean.RemoteStrategyStopBean;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.commons.lang3.concurrent.ConcurrentUtils;
/*     */ 
/*     */ public class RemoteStrategyManager
/*     */   extends StrategyManager<IRemoteStrategyDescriptor, RemoteStrategyListener>
/*     */   implements IRemoteStrategyManager
/*     */ {
/*     */   private JssEventsListener jssEventsListener;
/*     */   private IJssManager jssManager;
/*     */   private static RemoteStrategyManager remoteStrategyManager;
/*     */   
/*     */   public static RemoteStrategyManager getInstance()
/*     */   {
/*  45 */     if (remoteStrategyManager == null) {
/*  46 */       remoteStrategyManager = new RemoteStrategyManager();
/*     */     }
/*  48 */     return remoteStrategyManager;
/*     */   }
/*     */   
/*     */   public static RemoteStrategyManager getResetInstance() {
/*  52 */     if (remoteStrategyManager == null) {
/*  53 */       remoteStrategyManager = new RemoteStrategyManager();
/*     */     } else {
/*  55 */       remoteStrategyManager.dispose();
/*     */     }
/*  57 */     remoteStrategyManager.setup();
/*  58 */     return remoteStrategyManager;
/*     */   }
/*     */   
/*     */   private RemoteStrategyManager() {
/*  62 */     setup();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void setup()
/*     */   {
/*  68 */     this.jssManager = FeedDataProvider.getDefaultInstance().getJssManager();
/*  69 */     if ((this.jssEventsListener != null) && (this.jssManager.getJssListeners().contains(this.jssEventsListener))) {
/*  70 */       this.jssManager.removeJssListener(this.jssEventsListener);
/*     */     }
/*  72 */     this.jssEventsListener = new JssEventsAdapter()
/*     */     {
/*     */       public void onStrategyRun(final RemoteStrategyRunBean bean)
/*     */       {
/*  76 */         RemoteStrategyManager.this.processResponse(RemoteStrategyManager.this.stratStartMap, bean.getRequestIdAsUUID(), new Callable()
/*     */         {
/*     */           public IStrategyResponse<UUID> call() throws Exception {
/*  79 */             return StrategyResponse.newOkResponse(UUID.fromString(bean.getDescriptor().getPid()));
/*     */           }
/*     */         });
/*     */       }
/*     */       
/*     */       public void onStrategyRunError(final RemoteStrategyRunErrorBean bean) {
/*  85 */         RemoteStrategyManager.this.processResponse(RemoteStrategyManager.this.stratStartMap, bean.getRequestIdAsUUID(), new Callable()
/*     */         {
/*     */           public IStrategyResponse<UUID> call() throws Exception {
/*  88 */             return StrategyResponse.newErrorRespnose(bean.getErrorMessage());
/*     */           }
/*     */         });
/*     */       }
/*     */       
/*     */       public void onStrategyStop(final RemoteStrategyStopBean bean) {
/*  94 */         RemoteStrategyManager.this.processResponse(RemoteStrategyManager.this.stratStopMap, bean.getRequestIdAsUUID(), new Callable()
/*     */         {
/*     */           public IStrategyResponse<Void> call() throws Exception {
/*  97 */             if (bean.isError()) {
/*  98 */               return StrategyResponse.newErrorRespnose(bean.getErrorMessage());
/*     */             }
/* 100 */             return StrategyResponse.newOkResponse(null);
/*     */           }
/*     */         });
/*     */       }
/*     */       
/*     */       public void onStrategyStateChange(RemoteStrategyStateChangeBean bean)
/*     */       {
/* 107 */         for (RemoteStrategyListener remoteSystemListener : RemoteStrategyManager.this.strategyListeners) {
/* 108 */           if (bean.getStrategyState() == StrategyState.TERMINATED) {
/* 109 */             remoteSystemListener.onStrategyStop(new RemoteStrategyDescriptor(bean.getStrategyProcessDescriptor(), bean.getComments()));
/* 110 */           } else if (bean.getStrategyState() == StrategyState.LAUNCHED) {
/* 111 */             remoteSystemListener.onStrategyRun(new RemoteStrategyDescriptor(bean.getStrategyProcessDescriptor(), bean.getComments()));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 118 */       public void onStrategiesList(final RemoteStrategiesListBean bean) { RemoteStrategyManager.this.processResponse(RemoteStrategyManager.this.listMap, bean.getRequestIdAsUUID(), new Callable()
/*     */         {
/*     */           public IStrategyResponse<Set<IRemoteStrategyDescriptor>> call() throws Exception {
/* 121 */             if (bean.isError()) {
/* 122 */               return StrategyResponse.newErrorRespnose(bean.getErrorMessage());
/*     */             }
/* 124 */             Set<IRemoteStrategyDescriptor> remoteStrategyDescriptors = new HashSet();
/* 125 */             for (StrategyProcessDescriptor d : bean.getStrategyProcessDescriptors()) {
/* 126 */               remoteStrategyDescriptors.add(new RemoteStrategyDescriptor(d));
/*     */             }
/* 128 */             return StrategyResponse.newOkResponse(remoteStrategyDescriptors);
/*     */           }
/*     */         }); }
/* 131 */     };
/* 132 */     this.jssManager.addJssListener(this.jssEventsListener);
/*     */   }
/*     */   
/*     */   protected void dispose()
/*     */   {
/* 137 */     if (this.jssEventsListener != null) {
/* 138 */       this.jssManager.removeJssListener(this.jssEventsListener);
/*     */     }
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile) throws IOException
/*     */   {
/*     */     try {
/* 145 */       return startStrategy(strategyFile, null);
/*     */     } catch (JFException e) {}
/* 147 */     return null;
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile, Object[] params) throws IOException, JFException
/*     */   {
/*     */     StrategyNewBean bean;
/*     */     try
/*     */     {
/* 155 */       bean = StrategyNewBean.createRunnableBean(strategyFile);
/* 156 */       if ((params != null) && (params.length > 0)) {
/*     */         try {
/* 158 */           bean.setConfigurablesAsActivePreset(params);
/*     */         } catch (Exception e) {
/* 160 */           throw new JFException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (GeneralSecurityException e1) {
/* 165 */       throw new IOException(e1);
/*     */     }
/*     */     try {
/* 168 */       String requestId = this.jssManager.launchStrategyAsynch(bean, new HashSet());
/* 169 */       bean.setRemoteRequestId(requestId);
/* 170 */       return processRequest(this.stratStartMap, UUID.fromString(requestId));
/*     */     } catch (JssException e) {
/* 172 */       return getErrorResponse(e, this.stratStartMap);
/*     */     }
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<Void>> stopStrategy(UUID processId)
/*     */   {
/* 178 */     StrategyNewBean bean = new StrategyNewBean();
/* 179 */     bean.setRemoteProcessId(processId.toString());
/* 180 */     String requestId = null;
/*     */     try {
/* 182 */       requestId = this.jssManager.stopStrategyAsynch(bean);
/*     */     } catch (JssException e) {
/* 184 */       return getErrorResponse(e, this.stratStopMap);
/*     */     }
/* 186 */     return processRequest(this.stratStopMap, UUID.fromString(requestId));
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<Set<IRemoteStrategyDescriptor>>> getStartedStrategies()
/*     */   {
/* 191 */     String requestId = null;
/*     */     try {
/* 193 */       requestId = this.jssManager.requestStrategiesListAsynch();
/*     */     } catch (JssException e) {
/* 195 */       return getErrorResponse(e, this.listMap);
/*     */     }
/* 197 */     return processRequest(this.listMap, UUID.fromString(requestId));
/*     */   }
/*     */   
/*     */   private <T> Future<IStrategyResponse<T>> getErrorResponse(JssException e, Map<?, IStrategyResponse<T>> map)
/*     */   {
/* 202 */     return ConcurrentUtils.constantFuture(StrategyResponse.newErrorResponse(e, map));
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\remote\RemoteStrategyManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */