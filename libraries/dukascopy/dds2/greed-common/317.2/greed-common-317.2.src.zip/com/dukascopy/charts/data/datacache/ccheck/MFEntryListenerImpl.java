/*    */ package com.dukascopy.charts.data.datacache.ccheck;
/*    */ 
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*    */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*    */ import java.io.IOException;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MFEntryListenerImpl
/*    */   implements IMFEntryListener
/*    */ {
/* 24 */   private static final Logger LOGGER = LoggerFactory.getLogger(MFEntryListenerImpl.class);
/*    */   
/* 26 */   private static int BUFFER_SIZE = 1000;
/*    */   private MissingFileEntryManager mfmanager;
/*    */   private MFEntry[] buffer;
/*    */   private Integer bufferPos;
/*    */   private Period period;
/*    */   
/*    */   public MFEntryListenerImpl(MissingFileEntryManager mfmanager, Period period)
/*    */   {
/* 34 */     this.mfmanager = mfmanager;
/* 35 */     this.period = period;
/* 36 */     this.buffer = new MFEntry['Ϩ'];
/* 37 */     this.bufferPos = Integer.valueOf(-1);
/*    */   }
/*    */   
/*    */ 
/*    */   public void newEntry(MFEntry entry)
/*    */   {
/* 43 */     if ((entry == null) || (entry.getInstrument() == null) || (entry.getChunkTime() == Long.MIN_VALUE) || (entry.getChunkTime() == 0L) || (DataCacheUtils.getChunkStartFast(this.period, entry.getChunkTime()) != entry.getChunkTime()) || ((!Period.TICK.equals(this.period)) && (entry.getSide() == null)))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 51 */       LOGGER.error("Invalid MFEntry! [" + (entry == null ? null : entry.toString()) + "], listener's period [" + this.period + "]"); return;
/*    */     }
/*    */     Integer localInteger1;
/*    */     Integer localInteger2;
/* 55 */     if (this.bufferPos.intValue() < BUFFER_SIZE) {
/* 56 */       if (this.bufferPos.intValue() == -1) {
/* 57 */         this.bufferPos = Integer.valueOf(this.bufferPos.intValue() + 1);
/*    */       }
/* 59 */       localInteger1 = this.bufferPos;localInteger2 = this.bufferPos = Integer.valueOf(this.bufferPos.intValue() + 1);this.buffer[localInteger1.intValue()] = entry;
/*    */     }
/*    */     else {
/* 62 */       flush();
/* 63 */       this.bufferPos = Integer.valueOf(this.bufferPos.intValue() + 1);
/* 64 */       localInteger1 = this.bufferPos;localInteger2 = this.bufferPos = Integer.valueOf(this.bufferPos.intValue() + 1);this.buffer[localInteger1.intValue()] = entry;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void flush()
/*    */   {
/* 75 */     if (this.bufferPos.intValue() <= 0) {
/* 76 */       return;
/*    */     }
/*    */     
/*    */ 
/* 80 */     MFEntry[] toWriteInArray = new MFEntry[this.bufferPos.intValue()];
/* 81 */     System.arraycopy(this.buffer, 0, toWriteInArray, 0, this.bufferPos.intValue());
/*    */     try
/*    */     {
/* 84 */       this.mfmanager.appendFileWithEntries(toWriteInArray, this.period);
/*    */     } catch (IOException|DataCacheException e) {
/* 86 */       LOGGER.error("Couldn't write missing chunks in the files!", e);
/*    */     }
/*    */     
/* 89 */     this.bufferPos = Integer.valueOf(-1);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFEntryListenerImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */