/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ import com.dukascopy.calculator.AngleType;
/*   */ 
/*   */ public class Cos extends Monadic {
/*   */   public Cos(Expression expression, AngleType angleType) {
/* 7 */     super(new com.dukascopy.calculator.function.Cos(angleType), expression);
/*   */   }
/*   */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Cos.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */