/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IMessage.Type;
/*    */ import com.dukascopy.api.IWithdrawalMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WithdrawalMessageImpl
/*    */   extends PlatformMessageImpl
/*    */   implements IWithdrawalMessage
/*    */ {
/*    */   private static final String FORMAT = "Withdrawal Message: [%s]";
/*    */   private String clientId;
/*    */   private double amount;
/*    */   private boolean scheduled;
/*    */   
/*    */   public WithdrawalMessageImpl(String clientId, double amount, boolean scheduled, String content, long creationTime)
/*    */   {
/* 34 */     super(content, null, IMessage.Type.WITHDRAWAL, creationTime);
/* 35 */     this.clientId = clientId;
/* 36 */     this.scheduled = scheduled;
/* 37 */     this.amount = amount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getClientId()
/*    */   {
/* 45 */     return this.clientId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double amount()
/*    */   {
/* 53 */     return this.amount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isScheduled()
/*    */   {
/* 61 */     return this.scheduled;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 69 */     return String.format("Withdrawal Message: [%s]", new Object[] { getContent() });
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\WithdrawalMessageImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */