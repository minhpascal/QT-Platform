package com.dukascopy.api.impl.connect;

public enum PlatformType
{
  JFOREX,  STANDALONE,  JSS;
  
  private PlatformType() {}
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */