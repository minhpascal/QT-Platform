/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.impl.talib.FuncInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.InputParameterInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.IntegerListHolder;
/*     */ import com.dukascopy.api.impl.talib.IntegerRangeHolder;
/*     */ import com.dukascopy.api.impl.talib.OptInputParameterInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.OutputParameterInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.RealListHolder;
/*     */ import com.dukascopy.api.impl.talib.RealRangeHolder;
/*     */ import com.dukascopy.api.indicators.DoubleListDescription;
/*     */ import com.dukascopy.api.indicators.DoubleRangeDescription;
/*     */ import com.dukascopy.api.indicators.IIndicator;
/*     */ import com.dukascopy.api.indicators.IIndicatorContext;
/*     */ import com.dukascopy.api.indicators.IndicatorInfo;
/*     */ import com.dukascopy.api.indicators.IndicatorResult;
/*     */ import com.dukascopy.api.indicators.InputParameterInfo;
/*     */ import com.dukascopy.api.indicators.InputParameterInfo.Type;
/*     */ import com.dukascopy.api.indicators.IntegerListDescription;
/*     */ import com.dukascopy.api.indicators.IntegerRangeDescription;
/*     */ import com.dukascopy.api.indicators.OptInputDescription;
/*     */ import com.dukascopy.api.indicators.OptInputParameterInfo;
/*     */ import com.dukascopy.api.indicators.OptInputParameterInfo.Type;
/*     */ import com.dukascopy.api.indicators.OutputParameterInfo;
/*     */ import com.dukascopy.api.indicators.OutputParameterInfo.DrawingStyle;
/*     */ import com.dukascopy.api.indicators.OutputParameterInfo.Type;
/*     */ import com.dukascopy.charts.math.indicators.IndicatorsFilter;
/*     */ import com.tictactec.ta.lib.MInteger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ public class TaLibIndicator
/*     */   implements IIndicator
/*     */ {
/*  36 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaLibIndicator.class);
/*     */   private TaLibMetaData taLibMetaData;
/*     */   private IndicatorInfo indicatorInfo;
/*     */   private InputParameterInfo[] inputParamInfos;
/*     */   private OptInputParameterInfo[] optInputParamInfos;
/*     */   private OutputParameterInfo[] outputParamInfos;
/*     */   
/*     */   public TaLibIndicator(TaLibMetaData taLibMetaData)
/*     */   {
/*  45 */     this.taLibMetaData = taLibMetaData;
/*  46 */     FuncInfoHolder funcInfo = taLibMetaData.getFuncInfo();
/*  47 */     String name = funcInfo.name.toUpperCase();
/*  48 */     String groupName = funcInfo.group;
/*  49 */     this.indicatorInfo = new IndicatorInfo(name, IndicatorsFilter.getTitle(funcInfo.name), groupName, ((funcInfo.flags & 0x1000000) > 0) || ((funcInfo.flags & 0x10000000) > 0), (funcInfo.flags & 0x4000000) > 0, ((funcInfo.flags & 0x8000000) > 0) || (funcInfo.name.startsWith("MACD")) || (funcInfo.name.equals("TRIX")) || (funcInfo.name.equals("DEMA")) || (funcInfo.name.equals("TEMA")) || (funcInfo.name.equals("OBV")), funcInfo.nbInput, funcInfo.nbOptInput, funcInfo.nbOutput);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */     if ((name.equalsIgnoreCase("SAR")) || (name.equalsIgnoreCase("SAREXT")) || (name.equalsIgnoreCase("AD")) || (name.equalsIgnoreCase("OBV")) || (name.equalsIgnoreCase("DEMA")) || (name.equalsIgnoreCase("TEMA")) || (funcInfo.name.startsWith("MAMA")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */       this.indicatorInfo.setRecalculateAll(true);
/*     */     }
/*     */     
/*  71 */     this.inputParamInfos = new InputParameterInfo[this.indicatorInfo.getNumberOfInputs()];
/*  72 */     for (int i = 0; i < this.inputParamInfos.length; i++) {
/*  73 */       InputParameterInfoHolder info = taLibMetaData.getInputParameterInfo(i);
/*     */       InputParameterInfo.Type type;
/*  75 */       switch (info.type) {
/*     */       case TA_Input_Integer: 
/*  77 */         throw new IllegalArgumentException("Ints as input isn't supported");
/*     */       case TA_Input_Price: 
/*  79 */         type = InputParameterInfo.Type.PRICE;
/*  80 */         break;
/*     */       case TA_Input_Real: 
/*  82 */         type = InputParameterInfo.Type.DOUBLE;
/*  83 */         break;
/*     */       default: 
/*  85 */         throw new IllegalArgumentException("Unknown input type");
/*     */       }
/*  87 */       this.inputParamInfos[i] = new InputParameterInfo(renameInputs(info.paramName), type);
/*     */     }
/*     */     
/*  90 */     this.optInputParamInfos = new OptInputParameterInfo[this.indicatorInfo.getNumberOfOptionalInputs()];
/*  91 */     for (int i = 0; i < this.optInputParamInfos.length; i++) {
/*  92 */       OptInputParameterInfoHolder info = taLibMetaData.getOptInputParameterInfo(i);
/*     */       OptInputDescription description;
/*  94 */       switch (info.type) {
/*     */       case TA_OptInput_IntegerList: 
/*  96 */         IntegerListHolder list = taLibMetaData.getOptInputIntegerList(i);
/*  97 */         description = new IntegerListDescription(funcInfo.name.startsWith("BBANDS") ? 1 : list.defaultValue, list.value, list.string);
/*  98 */         break;
/*     */       case TA_OptInput_IntegerRange: 
/* 100 */         IntegerRangeHolder range = taLibMetaData.getOptInputIntegerRange(i);
/* 101 */         int value = range.defaultValue;
/* 102 */         if (funcInfo.name.startsWith("BBANDS")) {
/* 103 */           value = 20;
/*     */         }
/* 105 */         int min = range.min;
/* 106 */         if ((funcInfo.name.equals("MACD")) && (i == 2)) {
/* 107 */           min = 2;
/*     */         }
/* 109 */         if ((funcInfo.name.equals("MACDFIX")) && (i == 0)) {
/* 110 */           min = 2;
/*     */         }
/* 112 */         if ((funcInfo.name.equals("TRIX")) && (i == 0)) {
/* 113 */           min = 2;
/*     */         }
/* 115 */         if ((funcInfo.name.equals("ULTOSC")) && (i == 2)) {
/* 116 */           min = 2;
/*     */         }
/* 118 */         int increment = range.suggested_increment;
/* 119 */         if (increment == 0) {
/* 120 */           increment = 1;
/*     */         }
/* 122 */         description = new IntegerRangeDescription(value, min, range.max, increment);
/* 123 */         break;
/*     */       case TA_OptInput_RealList: 
/* 125 */         RealListHolder rlist = taLibMetaData.getOptInputRealList(i);
/* 126 */         description = new DoubleListDescription(rlist.defaultValue, rlist.value, rlist.string);
/* 127 */         break;
/*     */       case TA_OptInput_RealRange: 
/* 129 */         RealRangeHolder rrange = taLibMetaData.getOptInputRealRange(i);
/* 130 */         double suggestedIncrement = rrange.suggested_increment;
/* 131 */         if (suggestedIncrement == 0.0D) {
/* 132 */           if (rrange.precision > 0) {
/* 133 */             suggestedIncrement = 1 / (10 * rrange.precision);
/*     */           } else {
/* 135 */             suggestedIncrement = 1.0D;
/*     */           }
/*     */         }
/* 138 */         description = new DoubleRangeDescription(rrange.defaultValue, rrange.min, rrange.max, suggestedIncrement, rrange.precision);
/* 139 */         break;
/*     */       default: 
/* 141 */         throw new IllegalArgumentException("Unknown optional input type"); }
/*     */       OptInputParameterInfo.Type type;
/*     */       OptInputParameterInfo.Type type;
/* 144 */       if ((info.flags & 0x100000) > 0) {
/* 145 */         type = OptInputParameterInfo.Type.PERCENT; } else { OptInputParameterInfo.Type type;
/* 146 */         if ((info.flags & 0x200000) > 0) {
/* 147 */           type = OptInputParameterInfo.Type.DEGREE; } else { OptInputParameterInfo.Type type;
/* 148 */           if ((info.flags & 0x400000) > 0) {
/* 149 */             type = OptInputParameterInfo.Type.CURRENCY;
/*     */           } else
/* 151 */             type = OptInputParameterInfo.Type.OTHER;
/*     */         }
/*     */       }
/* 154 */       this.optInputParamInfos[i] = new OptInputParameterInfo(renameOptInput(info.paramName), type, description);
/*     */     }
/*     */     
/* 157 */     this.outputParamInfos = new OutputParameterInfo[this.indicatorInfo.getNumberOfOutputs()];
/* 158 */     for (int i = 0; i < this.outputParamInfos.length; i++) {
/* 159 */       OutputParameterInfoHolder info = taLibMetaData.getOutputParameterInfo(i);
/*     */       OutputParameterInfo.Type type;
/* 161 */       switch (info.type) {
/*     */       case TA_Output_Integer: 
/* 163 */         type = OutputParameterInfo.Type.INT;
/* 164 */         break;
/*     */       case TA_Output_Real: 
/* 166 */         type = OutputParameterInfo.Type.DOUBLE;
/* 167 */         break;
/*     */       default: 
/* 169 */         throw new IllegalArgumentException("Unknown output type");
/*     */       }
/* 171 */       int flags = info.flags;
/* 172 */       if ((funcInfo.flags & 0x10000000) > 0)
/*     */       {
/* 174 */         if ((flags & 0x1) > 0) {
/* 175 */           flags ^= 0x1;
/*     */         }
/* 177 */         if ((type == OutputParameterInfo.Type.INT) && ((flags & 0x40) == 0) && ((flags & 0x20) == 0) && ((flags & 0x80) == 0) && ((flags & 0x10) <= 0) && ((flags & 0x4) <= 0) && ((flags & 0x8) <= 0) && ((flags & 0x2) <= 0) && ((flags & 0x1) <= 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */           flags |= 0x40;
/*     */         }
/*     */       }
/*     */       
/* 189 */       OutputParameterInfo.DrawingStyle drawingStyle = OutputParameterInfo.DrawingStyle.fromFlagValue(flags);
/* 190 */       if (drawingStyle == OutputParameterInfo.DrawingStyle.NONE) {
/* 191 */         drawingStyle = OutputParameterInfo.DrawingStyle.LINE;
/*     */       }
/* 193 */       if ((name.equals("SAR")) || (name.equals("SAREXT"))) {
/* 194 */         drawingStyle = OutputParameterInfo.DrawingStyle.DOTS;
/*     */       }
/*     */       
/* 197 */       this.outputParamInfos[i] = new OutputParameterInfo(renameOutput(info.paramName), type, drawingStyle);
/* 198 */       if ((drawingStyle == OutputParameterInfo.DrawingStyle.HISTOGRAM) && ((name.equals("MACD")) || (name.equals("MACDEXT")) || (name.equals("MACDFIX")))) {
/* 199 */         this.outputParamInfos[i].setHistogramTwoColor(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String renameOutput(String origName)
/*     */   {
/* 214 */     if (origName == null)
/* 215 */       return "";
/* 216 */     if (origName.equalsIgnoreCase("outReal"))
/* 217 */       return "Line";
/* 218 */     if (origName.equalsIgnoreCase("outInPhase"))
/* 219 */       return "Phase";
/* 220 */     if (origName.equalsIgnoreCase("outQuadrature"))
/* 221 */       return "Quadrature";
/* 222 */     if (origName.equalsIgnoreCase("outInteger"))
/* 223 */       return "Integer";
/* 224 */     if (origName.equalsIgnoreCase("outSine"))
/* 225 */       return "Sine";
/* 226 */     if (origName.equalsIgnoreCase("outLeadSine"))
/* 227 */       return "Lead Sine";
/* 228 */     if (origName.equalsIgnoreCase("outMin"))
/* 229 */       return "Min";
/* 230 */     if (origName.equalsIgnoreCase("outMax"))
/* 231 */       return "Max";
/* 232 */     if (origName.equalsIgnoreCase("outMAMA"))
/* 233 */       return "MAMA";
/* 234 */     if (origName.equalsIgnoreCase("outFAMA"))
/* 235 */       return "FAMA";
/* 236 */     if (origName.equalsIgnoreCase("outRealUpperBand"))
/* 237 */       return "Upper Band";
/* 238 */     if (origName.equalsIgnoreCase("outRealMiddleBand"))
/* 239 */       return "Middle Band";
/* 240 */     if (origName.equalsIgnoreCase("outRealLowerBand"))
/* 241 */       return "Lower Band";
/* 242 */     if (origName.equalsIgnoreCase("outMACD"))
/* 243 */       return "MACD";
/* 244 */     if (origName.equalsIgnoreCase("outMACDSignal"))
/* 245 */       return "MACD Signal";
/* 246 */     if (origName.equalsIgnoreCase("outMACDHist"))
/* 247 */       return "MACD Hist";
/* 248 */     if (origName.equalsIgnoreCase("outSlowK"))
/* 249 */       return "Slow %K";
/* 250 */     if (origName.equalsIgnoreCase("outSlowD"))
/* 251 */       return "Slow %D";
/* 252 */     if (origName.equalsIgnoreCase("outFastK"))
/* 253 */       return "Fast %K";
/* 254 */     if (origName.equalsIgnoreCase("outFastD"))
/* 255 */       return "Fast %D";
/* 256 */     if (origName.equalsIgnoreCase("outAroonDown"))
/* 257 */       return "Aroon Down";
/* 258 */     if (origName.equalsIgnoreCase("outAroonUp")) {
/* 259 */       return "Aroon Up";
/*     */     }
/* 261 */     return origName;
/*     */   }
/*     */   
/*     */   private String renameOptInput(String origName) {
/* 265 */     if (origName == null)
/* 266 */       return "";
/* 267 */     if (origName.equalsIgnoreCase("optInFastPeriod"))
/* 268 */       return "Fast Period";
/* 269 */     if (origName.equalsIgnoreCase("optInSlowPeriod"))
/* 270 */       return "Slow Period";
/* 271 */     if (origName.equalsIgnoreCase("optInTimePeriod"))
/* 272 */       return "Time Period";
/* 273 */     if (origName.equalsIgnoreCase("optInTimePeriod1"))
/* 274 */       return "Time Period 1";
/* 275 */     if (origName.equalsIgnoreCase("optInTimePeriod2"))
/* 276 */       return "Time Period 2";
/* 277 */     if (origName.equalsIgnoreCase("optInTimePeriod3"))
/* 278 */       return "Time Period 3";
/* 279 */     if (origName.equalsIgnoreCase("optInNbDev"))
/* 280 */       return "Nb Dev";
/* 281 */     if (origName.equalsIgnoreCase("optInStartValue"))
/* 282 */       return "Start Value";
/* 283 */     if (origName.equalsIgnoreCase("optInOffsetOnReverse"))
/* 284 */       return "Offset On Reverse";
/* 285 */     if (origName.equalsIgnoreCase("optInAccelerationInitLong"))
/* 286 */       return "Acceleration Init Long";
/* 287 */     if (origName.equalsIgnoreCase("optInAccelerationLong"))
/* 288 */       return "Acceleration Long";
/* 289 */     if (origName.equalsIgnoreCase("optInAccelerationMaxLong"))
/* 290 */       return "Acceleration Max Long";
/* 291 */     if (origName.equalsIgnoreCase("optInAccelerationInitShort"))
/* 292 */       return "Acceleration Init Short";
/* 293 */     if (origName.equalsIgnoreCase("optInAccelerationShort"))
/* 294 */       return "Acceleration Short";
/* 295 */     if (origName.equalsIgnoreCase("optInAccelerationMaxShort"))
/* 296 */       return "Acceleration Max Short";
/* 297 */     if (origName.equalsIgnoreCase("optInFastLimit"))
/* 298 */       return "Fast Limit";
/* 299 */     if (origName.equalsIgnoreCase("optInSlowLimit"))
/* 300 */       return "Slow Limit";
/* 301 */     if (origName.equalsIgnoreCase("optInVFactor"))
/* 302 */       return "V Factor";
/* 303 */     if (origName.equalsIgnoreCase("optInAcceleration"))
/* 304 */       return "Acceleration";
/* 305 */     if (origName.equalsIgnoreCase("optInMaximum"))
/* 306 */       return "Maximum";
/* 307 */     if (origName.equalsIgnoreCase("optInMinPeriod"))
/* 308 */       return "Min Period";
/* 309 */     if (origName.equalsIgnoreCase("optInMaxPeriod"))
/* 310 */       return "Max Period";
/* 311 */     if (origName.equalsIgnoreCase("optInMAType"))
/* 312 */       return "MA Type";
/* 313 */     if (origName.equalsIgnoreCase("optInNbDevUp"))
/* 314 */       return "Nb Dev Up";
/* 315 */     if (origName.equalsIgnoreCase("optInNbDevDn"))
/* 316 */       return "Nb Dev Dn";
/* 317 */     if (origName.equalsIgnoreCase("optInPenetration"))
/* 318 */       return "Penetration";
/* 319 */     if (origName.equalsIgnoreCase("optInFastMAType"))
/* 320 */       return "Fast MAType";
/* 321 */     if (origName.equalsIgnoreCase("optInSlowMAType"))
/* 322 */       return "Slow MAType";
/* 323 */     if (origName.equalsIgnoreCase("optInSignalPeriod"))
/* 324 */       return "Signal Period";
/* 325 */     if (origName.equalsIgnoreCase("optInSignalMAType"))
/* 326 */       return "Signal MAType";
/* 327 */     if (origName.equalsIgnoreCase("optInFastK_Period"))
/* 328 */       return "Fast %K Period";
/* 329 */     if (origName.equalsIgnoreCase("optInFastD_Period"))
/* 330 */       return "Fast %D Period";
/* 331 */     if (origName.equalsIgnoreCase("optInSlowK_Period"))
/* 332 */       return "Slow %K Period";
/* 333 */     if (origName.equalsIgnoreCase("optInSlowD_Period"))
/* 334 */       return "Slow %D Period";
/* 335 */     if (origName.equalsIgnoreCase("optInSlowK_MAType"))
/* 336 */       return "Slow %K MAType";
/* 337 */     if (origName.equalsIgnoreCase("optInSlowD_MAType"))
/* 338 */       return "Slow %D MAType";
/* 339 */     if (origName.equalsIgnoreCase("optInFastK_MAType"))
/* 340 */       return "Fast %K MAType";
/* 341 */     if (origName.equalsIgnoreCase("optInFastD_MAType")) {
/* 342 */       return "Fast %D MAType";
/*     */     }
/* 344 */     return origName;
/*     */   }
/*     */   
/*     */   private String renameInputs(String origName) {
/* 348 */     if (origName == null)
/* 349 */       return "";
/* 350 */     if (origName.equalsIgnoreCase("inReal"))
/* 351 */       return "Price";
/* 352 */     if (origName.equalsIgnoreCase("inReal0"))
/* 353 */       return "Price 0";
/* 354 */     if (origName.equalsIgnoreCase("inReal1"))
/* 355 */       return "Price 1";
/* 356 */     if (origName.equalsIgnoreCase("inPriceOHLC"))
/* 357 */       return "Price OHLC";
/* 358 */     if (origName.equalsIgnoreCase("inPriceHLCV"))
/* 359 */       return "Price HLCV";
/* 360 */     if (origName.equalsIgnoreCase("inPriceHLC"))
/* 361 */       return "Price HLC";
/* 362 */     if (origName.equalsIgnoreCase("inPriceHL"))
/* 363 */       return "Price HL";
/* 364 */     if (origName.equalsIgnoreCase("inPriceV"))
/* 365 */       return "Price V";
/* 366 */     if (origName.equalsIgnoreCase("inPeriods")) {
/* 367 */       return "Periods";
/*     */     }
/* 369 */     return origName;
/*     */   }
/*     */   
/*     */   public void onStart(IIndicatorContext context) {}
/*     */   
/*     */   public IndicatorResult calculate(int startIndex, int endIndex)
/*     */   {
/* 376 */     MInteger outBegIdx = new MInteger();
/* 377 */     MInteger outNbElement = new MInteger();
/*     */     try {
/* 379 */       this.taLibMetaData.callFunc(startIndex, endIndex, outBegIdx, outNbElement);
/*     */     } catch (RuntimeException e) {
/* 381 */       throw e;
/*     */     } catch (Exception e) {
/* 383 */       throw new TaLibException(e);
/*     */     }
/* 385 */     return new IndicatorResult(outBegIdx.value, outNbElement.value);
/*     */   }
/*     */   
/*     */   public IndicatorInfo getIndicatorInfo() {
/* 389 */     return this.indicatorInfo;
/*     */   }
/*     */   
/*     */   public InputParameterInfo getInputParameterInfo(int index) {
/* 393 */     return this.inputParamInfos[index];
/*     */   }
/*     */   
/*     */   public int getLookback() {
/*     */     try {
/* 398 */       return this.taLibMetaData.getLookback();
/*     */     } catch (Exception e) {
/* 400 */       LOGGER.error(e.getMessage(), e); }
/* 401 */     return 0;
/*     */   }
/*     */   
/*     */   public int getLookforward()
/*     */   {
/* 406 */     return 0;
/*     */   }
/*     */   
/*     */   public OptInputParameterInfo getOptInputParameterInfo(int index) {
/* 410 */     return this.optInputParamInfos[index];
/*     */   }
/*     */   
/*     */   public OutputParameterInfo getOutputParameterInfo(int index) {
/* 414 */     return this.outputParamInfos[index];
/*     */   }
/*     */   
/*     */   public void setInputParameter(int index, Object array)
/*     */   {
/* 419 */     InputParameterInfo inputParamInfo = this.inputParamInfos[index];
/* 420 */     switch (inputParamInfo.getType()) {
/*     */     case DOUBLE: 
/* 422 */       this.taLibMetaData.setInputParamReal(index, array);
/* 423 */       break;
/*     */     case PRICE: 
/* 425 */       double[][] prices = (double[][])array;
/* 426 */       this.taLibMetaData.setInputParamPrice(index, prices[0], prices[2], prices[3], prices[1], prices[4], new double[prices[0].length]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOptInputParameter(int index, Object value)
/*     */   {
/* 432 */     OptInputParameterInfo inputParamInfo = this.optInputParamInfos[index];
/* 433 */     if (((inputParamInfo.getDescription() instanceof IntegerListDescription)) || ((inputParamInfo.getDescription() instanceof IntegerRangeDescription))) {
/* 434 */       this.taLibMetaData.setOptInputParamInteger(index, ((Integer)value).intValue());
/* 435 */     } else if (((inputParamInfo.getDescription() instanceof DoubleListDescription)) || ((inputParamInfo.getDescription() instanceof DoubleRangeDescription))) {
/* 436 */       this.taLibMetaData.setOptInputParamReal(index, ((Double)value).doubleValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOutputParameter(int index, Object array)
/*     */   {
/* 442 */     OutputParameterInfo outputParamInfo = this.outputParamInfos[index];
/* 443 */     switch (outputParamInfo.getType()) {
/*     */     case DOUBLE: 
/* 445 */       this.taLibMetaData.setOutputParamReal(index, array);
/* 446 */       break;
/*     */     case INT: 
/* 448 */       this.taLibMetaData.setOutputParamInteger(index, array);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\TaLibIndicator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */