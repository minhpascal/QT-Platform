package com.dukascopy.api.impl.email;

import com.dukascopy.api.JFException;
import com.dukascopy.api.util.IEmailResponse;
import com.dukascopy.dds4.transport.client.TransportClient;
import java.util.concurrent.Future;

public abstract interface IEmailManager
{
  public abstract Future<IEmailResponse> sendMail(String paramString1, String paramString2, String paramString3)
    throws JFException;
  
  public abstract void setup(TransportClient paramTransportClient, String paramString);
  
  public abstract void dispose();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\email\IEmailManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */