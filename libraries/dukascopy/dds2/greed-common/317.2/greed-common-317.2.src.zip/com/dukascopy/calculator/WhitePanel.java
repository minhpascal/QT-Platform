/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ public class WhitePanel extends javax.swing.JPanel { private static final long serialVersionUID = 1L;
/*    */   
/*  7 */   public WhitePanel() { setBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0)); }
/*    */   
/*    */   public void paintComponent(Graphics graphics)
/*    */   {
/* 11 */     super.paintComponent(graphics);
/* 12 */     graphics.setColor(java.awt.Color.WHITE);
/* 13 */     graphics.fillRect(0, 0, getWidth(), getHeight());
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\WhitePanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */