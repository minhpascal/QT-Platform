/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Numeral
/*    */   extends PObject
/*    */ {
/*    */   private final char c;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Numeral(char c)
/*    */   {
/* 16 */     this.c = c;
/* 17 */     this.ftooltip = "";
/* 18 */     this.fshortcut = c;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public char get()
/*    */   {
/* 26 */     return this.c;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String name()
/*    */   {
/* 34 */     return Character.toString(get());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] name_array()
/*    */   {
/* 42 */     String[] string = new String[1];
/* 43 */     string[0] = Character.toString(this.c);
/* 44 */     return string;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Numeral.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */