/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IMessage.Reason;
/*     */ import com.dukascopy.api.IMessage.Type;
/*     */ import com.dukascopy.api.INewsMessage;
/*     */ import com.dukascopy.api.INewsMessage.Action;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.dds2.greed.util.EnumConverter;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.news.NewsSource;
/*     */ import com.dukascopy.dds4.transport.msg.types.GeoRegion;
/*     */ import com.dukascopy.dds4.transport.msg.types.MarketSector;
/*     */ import com.dukascopy.dds4.transport.msg.types.StockIndex;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformNewsMessageImpl
/*     */   implements INewsMessage
/*     */ {
/*     */   private final String text;
/*     */   private final String copyright;
/*     */   private final String header;
/*     */   private final String newsId;
/*     */   private long publishDate;
/*     */   private boolean endOfStory;
/*     */   private boolean isHot;
/*     */   private final Set<String> currencies;
/*     */   private final Set<GeoRegion> geoRegions;
/*     */   private final Set<MarketSector> marketSectors;
/*     */   private final Set<StockIndex> stockIndicies;
/*     */   private final NewsSource source;
/*     */   private final INewsMessage.Action action;
/*  38 */   protected DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PlatformNewsMessageImpl(String text, String copyright, String header, String newsId, long publishDate, boolean endOfStory, boolean isHot, Set<String> currencies, Set<GeoRegion> geoRegions, Set<MarketSector> marketSectors, Set<StockIndex> stockIndicies, NewsSource source)
/*     */   {
/*  54 */     this(text, copyright, header, newsId, publishDate, endOfStory, isHot, currencies, geoRegions, marketSectors, stockIndicies, source, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PlatformNewsMessageImpl(String text, String copyright, String header, String newsId, long publishDate, boolean endOfStory, boolean isHot, Set<String> currencies, Set<GeoRegion> geoRegions, Set<MarketSector> marketSectors, Set<StockIndex> stockIndicies, NewsSource source, INewsMessage.Action action)
/*     */   {
/*  72 */     this.text = text;
/*  73 */     this.copyright = copyright;
/*  74 */     this.header = header;
/*  75 */     this.newsId = newsId;
/*  76 */     this.publishDate = publishDate;
/*  77 */     this.endOfStory = endOfStory;
/*  78 */     this.isHot = isHot;
/*  79 */     this.currencies = currencies;
/*  80 */     this.geoRegions = geoRegions;
/*  81 */     this.marketSectors = marketSectors;
/*  82 */     this.stockIndicies = stockIndicies;
/*  83 */     this.source = source;
/*  84 */     this.action = action;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IOrder getOrder()
/*     */   {
/*  92 */     return null;
/*     */   }
/*     */   
/*     */   public String getContent()
/*     */   {
/*  97 */     return this.text;
/*     */   }
/*     */   
/*     */   public String getCopyright()
/*     */   {
/* 102 */     return this.copyright;
/*     */   }
/*     */   
/*     */   public String getHeader()
/*     */   {
/* 107 */     return this.header;
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/* 112 */     return this.newsId;
/*     */   }
/*     */   
/*     */   public long getPublishDate() {
/* 116 */     return this.publishDate;
/*     */   }
/*     */   
/*     */   public boolean isEndOfStory() {
/* 120 */     return this.endOfStory;
/*     */   }
/*     */   
/*     */   public boolean isHot()
/*     */   {
/* 125 */     return this.isHot;
/*     */   }
/*     */   
/*     */   public INewsMessage.Action getAction()
/*     */   {
/* 130 */     return this.action;
/*     */   }
/*     */   
/*     */   public Set<String> getCurrencies()
/*     */   {
/* 135 */     return this.currencies;
/*     */   }
/*     */   
/*     */   public Set<String> getGeoRegions()
/*     */   {
/* 140 */     return EnumConverter.convert(this.geoRegions);
/*     */   }
/*     */   
/*     */   public Set<String> getMarketSectors()
/*     */   {
/* 145 */     return EnumConverter.convert(this.marketSectors);
/*     */   }
/*     */   
/*     */   public Set<String> getStockIndicies()
/*     */   {
/* 150 */     return EnumConverter.convert(this.stockIndicies);
/*     */   }
/*     */   
/*     */   public long getCreationTime()
/*     */   {
/* 155 */     return this.publishDate;
/*     */   }
/*     */   
/*     */   public IMessage.Type getType()
/*     */   {
/* 160 */     return IMessage.Type.NEWS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<IMessage.Reason> getReasons()
/*     */   {
/* 168 */     return EnumSet.noneOf(IMessage.Reason.class);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 173 */     StringBuilder sb = new StringBuilder();
/* 174 */     if (ObjectUtils.isEqual(INewsMessage.Action.DELETE, getAction())) {
/* 175 */       sb.append(String.format("[MessageType %s]:%n \taction : %s, id : %s, source : %s", new Object[] { getType(), getAction(), getId(), getSource() }));
/*     */     }
/*     */     else
/*     */     {
/* 179 */       sb.append(String.format("[MessageType %s]:%n \ttext : %s, publish date : %s, end of story : %s, hot : %s", new Object[] { getType(), getHeader(), this.df.format(Long.valueOf(getPublishDate())), Boolean.valueOf(isEndOfStory()), Boolean.valueOf(isHot()) }));
/*     */       
/* 181 */       sb.append(String.format("%n", new Object[0])).append(getMetaDataInfo());
/*     */     }
/* 183 */     return sb.toString();
/*     */   }
/*     */   
/*     */   protected String getMetaDataInfo() {
/* 187 */     return String.format("\tMeta info:%n\t\tStock Indicies: %s, Regions: %s, Market sectors: %s, Currencies: %s", new Object[] { getStockIndicies(), getGeoRegions(), getMarketSectors(), getCurrencies() });
/*     */   }
/*     */   
/*     */ 
/*     */   public NewsSource getSource()
/*     */   {
/* 193 */     return this.source;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformNewsMessageImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */