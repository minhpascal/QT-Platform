/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IUserInterface;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FacelessUserInterface
/*    */   implements IUserInterface
/*    */ {
/*    */   public JPanel getBottomTab(String key)
/*    */   {
/* 14 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public void removeBottomTab(String key) {}
/*    */   
/*    */ 
/*    */   public JPanel getMainTab(String key)
/*    */   {
/* 23 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public void removeMainTab(String key) {}
/*    */   
/*    */ 
/*    */   public JFrame getMainFrame()
/*    */   {
/* 32 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\FacelessUserInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */