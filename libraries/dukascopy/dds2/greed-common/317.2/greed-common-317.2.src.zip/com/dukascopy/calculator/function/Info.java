/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ public class Info extends PObject {
/*    */   public Info() {
/*  7 */     this.ftooltip = "sc.calculator.about";
/*  8 */     this.fshortcut = '@';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 12 */     return fname;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 16 */     Info o = new Info();
/* 17 */     JOptionPane.showMessageDialog(null, o.name());
/*    */   }
/*    */   
/* 20 */   private static final String[] fname = { "About" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Info.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */