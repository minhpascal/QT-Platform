/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ public class Ln extends Monadic {
/*   */   public Ln(Expression expression) {
/* 5 */     super(new com.dukascopy.calculator.function.Ln(), expression);
/*   */   }
/*   */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Ln.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */