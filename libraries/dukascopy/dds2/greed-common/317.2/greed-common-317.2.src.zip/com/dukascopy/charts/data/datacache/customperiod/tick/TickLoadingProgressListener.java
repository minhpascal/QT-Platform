/*    */ package com.dukascopy.charts.data.datacache.customperiod.tick;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TickLoadingProgressListener
/*    */   implements ILoadingProgressListener
/*    */ {
/*    */   private final ILoadingProgressListener loadingProgressListenerDelegate;
/*    */   
/*    */   public TickLoadingProgressListener(ILoadingProgressListener loadingProgressListenerDelegate)
/*    */   {
/* 14 */     this.loadingProgressListenerDelegate = loadingProgressListenerDelegate;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean stopJob()
/*    */   {
/* 41 */     return getLoadingProgressListenerDelegate().stopJob();
/*    */   }
/*    */   
/*    */   public ILoadingProgressListener getLoadingProgressListenerDelegate() {
/* 45 */     return this.loadingProgressListenerDelegate;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customperiod\tick\TickLoadingProgressListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */