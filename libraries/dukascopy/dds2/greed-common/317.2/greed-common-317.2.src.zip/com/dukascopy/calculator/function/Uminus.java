/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Uminus
/*    */   extends RFunction
/*    */ {
/*    */   public double function(double x)
/*    */   {
/* 22 */     return -x;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 31 */     return x.negate();
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 35 */     return fname;
/*    */   }
/*    */   
/* 38 */   private static final String[] fname = { "(&#8722;)" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Uminus.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */