/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IReportPosition;
/*    */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.IReportPositionsListener;
/*    */ import com.dukascopy.charts.data.datacache.LoadReportClosedPositionsAction;
/*    */ import com.dukascopy.charts.data.datacache.LoadReportOpenPositionsAction;
/*    */ import com.dukascopy.charts.data.datacache.listener.LoadingProgressListenerImpl;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportPositionProvider
/*    */   implements IReportPositionProvider
/*    */ {
/*    */   private final IFeedDataProvider feedDataProvider;
/*    */   
/*    */   public ReportPositionProvider(IFeedDataProvider feedDataProvider)
/*    */   {
/* 31 */     this.feedDataProvider = feedDataProvider;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<IReportPosition> getOpenPositions()
/*    */     throws DataCacheException
/*    */   {
/* 39 */     LoadReportOpenPositionsAction loadReportOpenPositionsAction = getLoadReportOpenPositionsAction(new ReportPositionsListener(), new LoadingProgressListenerImpl());
/* 40 */     return loadReportOpenPositionsAction.load();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void readOpenPositions(IReportPositionsListener reportPositionListener, ILoadingProgressListener loadingProgress)
/*    */     throws DataCacheException
/*    */   {
/* 51 */     LoadReportOpenPositionsAction loadReportOpenPositionsAction = getLoadReportOpenPositionsAction(reportPositionListener, loadingProgress);
/* 52 */     this.feedDataProvider.runTask(loadReportOpenPositionsAction);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public List<IReportPosition> getClosedPositions(long from, long to)
/*    */     throws DataCacheException
/*    */   {
/* 61 */     LoadReportClosedPositionsAction loadReportClosedPositionsAction = getLoadReportClosedPositionsAction(from, to, new ReportPositionsListener(), new LoadingProgressListenerImpl());
/* 62 */     return loadReportClosedPositionsAction.load();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void readClosedPositions(long from, long to, IReportPositionsListener reportPositionListener, ILoadingProgressListener loadingProgress)
/*    */     throws DataCacheException
/*    */   {
/* 74 */     LoadReportClosedPositionsAction loadReportClosedPositionsAction = getLoadReportClosedPositionsAction(from, to, reportPositionListener, loadingProgress);
/* 75 */     this.feedDataProvider.runTask(loadReportClosedPositionsAction);
/*    */   }
/*    */   
/*    */ 
/*    */   private LoadReportOpenPositionsAction getLoadReportOpenPositionsAction(IReportPositionsListener reportPositionsListener, ILoadingProgressListener loadingProgress)
/*    */     throws DataCacheException
/*    */   {
/* 82 */     LoadReportOpenPositionsAction loadReportOpenPositionsAction = new LoadReportOpenPositionsAction(reportPositionsListener, loadingProgress);
/* 83 */     if (this.feedDataProvider.isStopped()) {
/* 84 */       loadReportOpenPositionsAction.cancel();
/*    */     }
/* 86 */     return loadReportOpenPositionsAction;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private LoadReportClosedPositionsAction getLoadReportClosedPositionsAction(long from, long to, IReportPositionsListener reportPositionsListener, ILoadingProgressListener loadingProgress)
/*    */     throws DataCacheException
/*    */   {
/* 95 */     LoadReportClosedPositionsAction loadReportClosedPositionsAction = new LoadReportClosedPositionsAction(this.feedDataProvider, from, to, reportPositionsListener, loadingProgress);
/* 96 */     if (this.feedDataProvider.isStopped()) {
/* 97 */       loadReportClosedPositionsAction.cancel();
/*    */     }
/* 99 */     return loadReportClosedPositionsAction;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\ReportPositionProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */