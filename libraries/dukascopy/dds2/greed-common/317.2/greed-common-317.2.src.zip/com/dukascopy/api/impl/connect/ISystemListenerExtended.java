package com.dukascopy.api.impl.connect;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.system.ISystemListener;
import java.util.Set;

public abstract interface ISystemListenerExtended
  extends ISystemListener
{
  public abstract void subscribeToInstruments(Set<Instrument> paramSet, boolean paramBoolean);
  
  public abstract Set<Instrument> getSubscribedInstruments();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ISystemListenerExtended.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */