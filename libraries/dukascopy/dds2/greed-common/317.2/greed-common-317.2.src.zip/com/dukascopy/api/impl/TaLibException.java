/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ 
/*    */ public class TaLibException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public TaLibException(String message, Throwable cause)
/*    */   {
/* 11 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public TaLibException(Throwable cause) {
/* 15 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\TaLibException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */