/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Xor
/*    */   extends BoolFunction
/*    */ {
/*    */   public Xor()
/*    */   {
/* 16 */     this.ftooltip = "sc.calculator.logical.bitwise.exclusive.or";
/* 17 */     this.fshortcut = 'X';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x, double y)
/*    */   {
/* 27 */     if ((Double.isNaN(x)) || (Double.isNaN(y)) || (Double.isInfinite(x)) || (Double.isInfinite(y)))
/*    */     {
/*    */ 
/* 30 */       throw new RuntimeException("Boolean Error"); }
/* 31 */     if (Math.abs(y) > Math.abs(x)) {
/* 32 */       double tmp = x;
/* 33 */       x = y;
/* 34 */       y = tmp;
/*    */     }
/* 36 */     long x_bits = Double.doubleToLongBits(x);
/* 37 */     boolean x_sign = x_bits >> 63 == 0L;
/* 38 */     int x_exponent = (int)(x_bits >> 52 & 0x7FF);
/* 39 */     long x_significand = x_exponent == 0 ? (x_bits & 0xFFFFFFFFFFFFF) << 1 : x_bits & 0xFFFFFFFFFFFFF | 0x10000000000000;
/*    */     
/* 41 */     long y_bits = Double.doubleToLongBits(y);
/* 42 */     boolean y_sign = y_bits >> 63 == 0L;
/* 43 */     int y_exponent = (int)(y_bits >> 52 & 0x7FF);
/* 44 */     long y_significand = y_exponent == 0 ? (y_bits & 0xFFFFFFFFFFFFF) << 1 : y_bits & 0xFFFFFFFFFFFFF | 0x10000000000000;
/*    */     
/* 46 */     y_significand >>= x_exponent - y_exponent;
/*    */     
/*    */ 
/* 49 */     x_significand ^= y_significand;
/*    */     
/*    */ 
/* 52 */     if (x_exponent == 0) {
/* 53 */       x_significand >>= 1;
/*    */     } else {
/* 55 */       if (x_significand == 0L) return 0.0D;
/* 56 */       while ((x_significand & 0x10000000000000) == 0L) {
/* 57 */         x_significand <<= 1;
/* 58 */         x_exponent--;
/* 59 */         if (x_exponent == 0) {
/* 60 */           x_significand >>= 1;
/*    */         }
/*    */       }
/*    */       
/* 64 */       x_significand &= 0xFFFFFFFFFFFFF;
/*    */     }
/*    */     
/* 67 */     x_bits = x_exponent << 52;
/* 68 */     x_bits |= x_significand;
/*    */     
/* 70 */     double result = Double.longBitsToDouble(x_bits);
/*    */     
/*    */ 
/* 73 */     if ((x_sign ^ y_sign))
/* 74 */       result = -result;
/* 75 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x, OObject y)
/*    */   {
/* 85 */     return x.xor(y);
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 89 */     return fname;
/*    */   }
/*    */   
/* 92 */   private static final String[] fname = { " ", "x", "o", "r", " " };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Xor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */