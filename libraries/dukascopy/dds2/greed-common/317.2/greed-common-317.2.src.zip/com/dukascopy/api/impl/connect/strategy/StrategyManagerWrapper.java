/*    */ package com.dukascopy.api.impl.connect.strategy;
/*    */ 
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.strategy.IStrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.IStrategyManager;
/*    */ import com.dukascopy.api.strategy.IStrategyResponse;
/*    */ import com.dukascopy.api.strategy.StrategyListener;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.Future;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrategyManagerWrapper<DESCRIPTOR extends IStrategyDescriptor, LISTENER extends StrategyListener<DESCRIPTOR>, MANAGER extends IStrategyManager<DESCRIPTOR, LISTENER>>
/*    */   implements IStrategyManager<DESCRIPTOR, LISTENER>
/*    */ {
/*    */   protected final MANAGER manager;
/* 29 */   private final Set<LISTENER> listeners = new HashSet();
/*    */   
/*    */   public StrategyManagerWrapper(MANAGER m) {
/* 32 */     this.manager = m;
/*    */   }
/*    */   
/*    */   public void removeAllListeners() {
/* 36 */     for (LISTENER listener : this.listeners) {
/* 37 */       removeStrategyListener(listener);
/*    */     }
/* 39 */     this.listeners.clear();
/*    */   }
/*    */   
/*    */   public void addStrategyListener(LISTENER strategyListener)
/*    */   {
/* 44 */     this.manager.addStrategyListener(strategyListener);
/* 45 */     this.listeners.add(strategyListener);
/*    */   }
/*    */   
/*    */   public void removeStrategyListener(LISTENER strategyListener)
/*    */   {
/* 50 */     this.manager.removeStrategyListener(strategyListener);
/* 51 */     this.listeners.remove(strategyListener);
/*    */   }
/*    */   
/*    */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile) throws IOException
/*    */   {
/* 56 */     return this.manager.startStrategy(strategyFile);
/*    */   }
/*    */   
/*    */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile, Object[] params) throws IOException, JFException
/*    */   {
/* 61 */     return this.manager.startStrategy(strategyFile, params);
/*    */   }
/*    */   
/*    */   public Future<IStrategyResponse<Void>> stopStrategy(UUID processId)
/*    */   {
/* 66 */     return this.manager.stopStrategy(processId);
/*    */   }
/*    */   
/*    */   public Future<IStrategyResponse<Set<DESCRIPTOR>>> getStartedStrategies()
/*    */   {
/* 71 */     return this.manager.getStartedStrategies();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\StrategyManagerWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */