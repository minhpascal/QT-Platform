package com.dukascopy.charts.data.datacache.core.connection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public abstract interface ICacheReadConnection
  extends ICacheConnection
{
  public abstract FileInputStream getFileInputStream()
    throws FileNotFoundException;
  
  public abstract FileReader getFileReader()
    throws FileNotFoundException;
  
  public abstract int read()
    throws IOException;
  
  public abstract int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract int read(byte[] paramArrayOfByte)
    throws IOException;
  
  public abstract void readFully(byte[] paramArrayOfByte)
    throws IOException;
  
  public abstract void readFully(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract int skipBytes(int paramInt)
    throws IOException;
  
  public abstract boolean readBoolean()
    throws IOException;
  
  public abstract byte readByte()
    throws IOException;
  
  public abstract int readUnsignedByte()
    throws IOException;
  
  public abstract short readShort()
    throws IOException;
  
  public abstract int readUnsignedShort()
    throws IOException;
  
  public abstract char readChar()
    throws IOException;
  
  public abstract int readInt()
    throws IOException;
  
  public abstract long readLong()
    throws IOException;
  
  public abstract float readFloat()
    throws IOException;
  
  public abstract double readDouble()
    throws IOException;
  
  public abstract String readLine()
    throws IOException;
  
  public abstract String readUTF()
    throws IOException;
  
  public abstract ICacheWriteConnection getChildWriteConnection();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\ICacheReadConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */