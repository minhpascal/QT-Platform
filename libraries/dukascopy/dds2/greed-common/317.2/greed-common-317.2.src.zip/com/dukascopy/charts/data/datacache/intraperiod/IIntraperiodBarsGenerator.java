package com.dukascopy.charts.data.datacache.intraperiod;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.feed.DataInterpolationDescriptor;
import com.dukascopy.api.feed.util.PointAndFigureFeedDescriptor;
import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
import com.dukascopy.api.feed.util.RenkoFeedDescriptor;
import com.dukascopy.api.feed.util.TickBarFeedDescriptor;
import com.dukascopy.charts.data.datacache.TickData;
import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoLiveFeedListener;
import com.dukascopy.charts.data.datacache.nisonrenko.RenkoData;
import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
import com.dukascopy.charts.data.datacache.tickbar.TickBarData;

public abstract interface IIntraperiodBarsGenerator
{
  public abstract void processTick(Instrument paramInstrument, TickData paramTickData);
  
  public abstract void startToFillInProgressPriceRange(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener);
  
  public abstract void startToFillInProgressPriceRange(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract boolean isInProgressPriceRangeLoadingNow(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract void startToFillInProgressPointAndFigure(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener);
  
  public abstract void startToFillInProgressPointAndFigure(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract boolean isInProgressPointAndFigureLoadingNow(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract void startToFillInProgressTickBar(TickBarFeedDescriptor paramTickBarFeedDescriptor, ITickBarLiveFeedListener paramITickBarLiveFeedListener);
  
  public abstract void startToFillInProgressTickBar(TickBarFeedDescriptor paramTickBarFeedDescriptor);
  
  public abstract boolean isInProgressTickBarLoadingNow(TickBarFeedDescriptor paramTickBarFeedDescriptor);
  
  public abstract void startToFillInProgressRenko(RenkoFeedDescriptor paramRenkoFeedDescriptor, IRenkoLiveFeedListener paramIRenkoLiveFeedListener);
  
  public abstract void startToFillInProgressRenko(RenkoFeedDescriptor paramRenkoFeedDescriptor);
  
  public abstract boolean isInProgressRenkoLoadingNow(RenkoFeedDescriptor paramRenkoFeedDescriptor);
  
  public abstract PriceRangeData getInProgressPriceRange(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract PointAndFigureData getInProgressPointAndFigure(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract TickBarData getInProgressTickBar(TickBarFeedDescriptor paramTickBarFeedDescriptor);
  
  public abstract RenkoData getInProgressRenko(RenkoFeedDescriptor paramRenkoFeedDescriptor);
  
  public abstract RenkoData getLastCompletedRenko(RenkoFeedDescriptor paramRenkoFeedDescriptor);
  
  public abstract void addInProgressPriceRangeListener(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener1, IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener2);
  
  public abstract void addInProgressPriceRangeListener(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener);
  
  public abstract void removeInProgressPriceRangeListener(IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener);
  
  public abstract void addPriceRangeNotificationListener(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener);
  
  public abstract void removePriceRangeNotificationListener(IPriceRangeLiveFeedListener paramIPriceRangeLiveFeedListener);
  
  public abstract void addInProgressPointAndFigureListener(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener1, IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener2);
  
  public abstract void addInProgressPointAndFigureListener(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener);
  
  public abstract void removeInProgressPointAndFigureListener(IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener);
  
  public abstract void addPointAndFigureNotificationListener(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor, IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener);
  
  public abstract void removePointAndFigureNotificationListener(IPointAndFigureLiveFeedListener paramIPointAndFigureLiveFeedListener);
  
  public abstract void addInProgressTickBarListener(TickBarFeedDescriptor paramTickBarFeedDescriptor, ITickBarLiveFeedListener paramITickBarLiveFeedListener1, ITickBarLiveFeedListener paramITickBarLiveFeedListener2);
  
  public abstract void addInProgressTickBarListener(TickBarFeedDescriptor paramTickBarFeedDescriptor, ITickBarLiveFeedListener paramITickBarLiveFeedListener);
  
  public abstract void removeInProgressTickBarListener(ITickBarLiveFeedListener paramITickBarLiveFeedListener);
  
  public abstract void addTickBarNotificationListener(TickBarFeedDescriptor paramTickBarFeedDescriptor, ITickBarLiveFeedListener paramITickBarLiveFeedListener);
  
  public abstract void removeTickBarNotificationListener(ITickBarLiveFeedListener paramITickBarLiveFeedListener);
  
  public abstract void addInProgressRenkoListener(RenkoFeedDescriptor paramRenkoFeedDescriptor, IRenkoLiveFeedListener paramIRenkoLiveFeedListener1, IRenkoLiveFeedListener paramIRenkoLiveFeedListener2);
  
  public abstract void addInProgressRenkoListener(RenkoFeedDescriptor paramRenkoFeedDescriptor, IRenkoLiveFeedListener paramIRenkoLiveFeedListener);
  
  public abstract void removeInProgressRenkoListener(IRenkoLiveFeedListener paramIRenkoLiveFeedListener);
  
  public abstract void addRenkoNotificationListener(RenkoFeedDescriptor paramRenkoFeedDescriptor, IRenkoLiveFeedListener paramIRenkoLiveFeedListener);
  
  public abstract void removeRenkoNotificationListener(IRenkoLiveFeedListener paramIRenkoLiveFeedListener);
  
  public abstract PointAndFigureData getOrLoadInProgressPointAndFigure(PointAndFigureFeedDescriptor paramPointAndFigureFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract PriceRangeData getOrLoadInProgressPriceRange(RangeBarFeedDescriptor paramRangeBarFeedDescriptor, DataInterpolationDescriptor paramDataInterpolationDescriptor);
  
  public abstract TickBarData getOrLoadInProgressTickBar(TickBarFeedDescriptor paramTickBarFeedDescriptor);
  
  public abstract RenkoData getOrLoadLastCompletedRenko(RenkoFeedDescriptor paramRenkoFeedDescriptor);
  
  public abstract void close();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\IIntraperiodBarsGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */