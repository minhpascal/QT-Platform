/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadOpenTicksAction
/*    */   extends AbstractLoadCustomTicksFromCandlesAction
/*    */ {
/*    */   private final TickFeedListener feedListener;
/*    */   private final double spreadInPipsAsk;
/*    */   private final double spreadInPipsBid;
/*    */   
/*    */   public LoadOpenTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, OfferSide offerSide, long from, long to, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 35 */     super(feedDataProvider, instrument, period, offerSide, from, to, loadingProgressListener);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */     this.feedListener = feedListener;
/*    */     
/* 46 */     this.spreadInPipsAsk = ((OfferSide.ASK.equals(offerSide) ? 0.0D : 2.0D) * instrument.getPipValue());
/* 47 */     this.spreadInPipsBid = ((OfferSide.ASK.equals(offerSide) ? -2.0D : 0.0D) * instrument.getPipValue());
/*    */   }
/*    */   
/*    */   protected void candleReceived(long time, double open, double close, double low, double high, double vol)
/*    */   {
/* 52 */     if ((this.from <= time) && (time <= this.to)) {
/* 53 */       double ask = StratUtils.round(open + this.spreadInPipsAsk, 5);
/* 54 */       double bid = StratUtils.round(open + this.spreadInPipsBid, 5);
/*    */       
/* 56 */       this.feedListener.newTick(this.instrument, time, ask, bid, vol, vol);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadOpenTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */