/*      */ package com.dukascopy.api.impl.connect;
/*      */ 
/*      */ import com.dukascopy.api.IChart;
/*      */ import com.dukascopy.api.IClientGUI;
/*      */ import com.dukascopy.api.IClientGUIListener;
/*      */ import com.dukascopy.api.IJFRunnable;
/*      */ import com.dukascopy.api.INewsFilter;
/*      */ import com.dukascopy.api.INewsFilter.NewsSource;
/*      */ import com.dukascopy.api.IStrategy;
/*      */ import com.dukascopy.api.IStrategyListener;
/*      */ import com.dukascopy.api.IUserInterface;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.feed.IFeedDescriptor;
/*      */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*      */ import com.dukascopy.api.impl.util.TransportUserAgent;
/*      */ import com.dukascopy.api.plugins.Plugin;
/*      */ import com.dukascopy.api.plugins.PluginGuiListener;
/*      */ import com.dukascopy.api.strategy.remote.IRemoteStrategyManager;
/*      */ import com.dukascopy.api.system.IPreferences;
/*      */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*      */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*      */ import com.dukascopy.api.system.ISystemListener;
/*      */ import com.dukascopy.api.system.JFVersionException;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*      */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.TickListener;
/*      */ import com.dukascopy.charts.data.datacache.feed.IFeedCommissionManager;
/*      */ import com.dukascopy.charts.data.orders.OrdersProvider;
/*      */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*      */ import com.dukascopy.charts.math.indicators.IndicatorsProvider;
/*      */ import com.dukascopy.dds2.greed.agent.compiler.JFXCompiler;
/*      */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.bean.IJFRunnablesListener;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.bean.StrategyNewBean;
/*      */ import com.dukascopy.dds2.greed.connection.GreedClientAuthorizationProvider;
/*      */ import com.dukascopy.dds2.greed.gui.storage.utils.JStoreSettings;
/*      */ import com.dukascopy.dds2.greed.market.ICurrencyMarketManager;
/*      */ import com.dukascopy.dds2.greed.strategy.TransportHelper;
/*      */ import com.dukascopy.dds2.greed.util.AbstractCurrencyConverter;
/*      */ import com.dukascopy.dds2.greed.util.EnumConverter;
/*      */ import com.dukascopy.dds2.greed.util.FilePathManager;
/*      */ import com.dukascopy.dds2.greed.util.IFilePathManager;
/*      */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*      */ import com.dukascopy.dds2.greed.util.InstrumentUtils;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*      */ import com.dukascopy.dds2.greed.util.ProtocolUtils;
/*      */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessage;
/*      */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessageInit;
/*      */ import com.dukascopy.dds3.transport.msg.acc.PackedAccountInfoMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ddsApi.InitRequestMessage;
/*      */ import com.dukascopy.dds3.transport.msg.feeder.InstrumentStatusUpdateMessage;
/*      */ import com.dukascopy.dds3.transport.msg.feeder.QuoteSubscribeRequestMessage;
/*      */ import com.dukascopy.dds3.transport.msg.news.CalendarType;
/*      */ import com.dukascopy.dds3.transport.msg.news.NewsCommandMessage;
/*      */ import com.dukascopy.dds3.transport.msg.news.NewsSource;
/*      */ import com.dukascopy.dds3.transport.msg.news.NewsStoryMessage;
/*      */ import com.dukascopy.dds3.transport.msg.news.NewsSubscribeRequest;
/*      */ import com.dukascopy.dds3.transport.msg.news.SubscribeRequestType;
/*      */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderSyncMessage;
/*      */ import com.dukascopy.dds3.transport.msg.types.NotificationLevel;
/*      */ import com.dukascopy.dds3.transport.msg.types.TradabilityState;
/*      */ import com.dukascopy.dds4.transport.client.TransportClient;
/*      */ import com.dukascopy.dds4.transport.common.mina.DisconnectedEvent;
/*      */ import com.dukascopy.dds4.transport.common.mina.ITransportClient;
/*      */ import com.dukascopy.dds4.transport.msg.system.CurrencyMarket;
/*      */ import com.dukascopy.dds4.transport.msg.system.ErrorResponseMessage;
/*      */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*      */ import com.dukascopy.dds4.transport.msg.types.EventCategory;
/*      */ import com.dukascopy.dds4.transport.msg.types.GeoRegion;
/*      */ import com.dukascopy.dds4.transport.msg.types.MarketSector;
/*      */ import com.dukascopy.dds4.transport.msg.types.StockIndex;
/*      */ import com.dukascopy.jss.IJssManager;
/*      */ import com.dukascopy.jss.nofication.bean.RemoteStrategyBroadcastBean;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.UnknownHostException;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ public class DCClientImpl implements com.dukascopy.api.system.IClient, com.dukascopy.dds4.transport.common.mina.ClientListener
/*      */ {
/*  123 */   private static final Logger LOGGER = LoggerFactory.getLogger(DCClientImpl.class);
/*      */   
/*  125 */   private static final long TRANSPORT_PING_TIMEOUT = TimeUnit.SECONDS.toMillis(10L);
/*      */   
/*      */   private static final String SNAPSHOT = "SNAPSHOT";
/*      */   
/*      */   private static final String DEFAULT_VERSION = "99.99.99";
/*      */   
/*      */   private static final String FEED_COMMISSION_HISTORY = "feed.commission.history";
/*      */   
/*      */   private static final String SUPPORTED_INSTRUMENTS = "instruments";
/*      */   
/*      */   private static final String HISTORY_SERVER_URL = "history.server.url";
/*      */   
/*      */   private static final String ENCRYPTION_KEY = "encryptionKey";
/*      */   private static final String SERVICES1_URL = "services1.url";
/*      */   private static final String TRADELOG_SFX = "tradelog_sfx.url";
/*      */   private static final String EXTERNAL_IP_ADDRESS = "external_ip";
/*      */   private static final String STORAGE_URL_PARAM_NAME = "sss.server.url";
/*      */   private static final String USER_TYPES = "userTypes";
/*      */   private static final String ANALITIC_CONTEST = "ANALITIC_CONTEST";
/*      */   private static final String LAYOUT_TYPES = "additionalUserTypes";
/*      */   private static final String WL_ENVIRONMENT_KEY = "wlabel.uniEnvironmentKey";
/*      */   private static final String JSTORE_ENABLED = "wlabel.jsEnable";
/*      */   private static final String INFO = "INFO";
/*      */   private static final String WARNING = "WARNING";
/*      */   private static final String ERROR = "ERROR";
/*      */   private ClientGUIListener clientGUIListener;
/*      */   private volatile ISystemListenerExtended systemListener;
/*      */   private TransportClient transportClient;
/*      */   private GreedClientAuthorizationProvider authProvider;
/*  154 */   private boolean initialized = false;
/*      */   
/*      */   private boolean live;
/*      */   private String accountName;
/*      */   private String version;
/*  159 */   private Set<Instrument> instruments = new HashSet();
/*      */   
/*      */   private PrintStream out;
/*      */   private PrintStream err;
/*      */   private Properties serverProperties;
/*      */   private String internalIP;
/*      */   private String sessionID;
/*      */   private String captchaId;
/*  167 */   private long temporaryKeys = -1L;
/*  168 */   private Map<Long, IJFRunnable<?>> runningJfRunnables = new HashMap();
/*  169 */   private final Map<Long, JForexTaskManager<?, ?, ?>> taskManagers = new HashMap();
/*      */   
/*  171 */   private Map<INewsFilter.NewsSource, INewsFilter> newsFilters = new HashMap();
/*  172 */   private final Map<UUID, Long> pluginIdMap = new HashMap();
/*      */   
/*      */   private AccountInfoMessage lastAccountInfoMessage;
/*      */   
/*      */   private AccountInfoMessageInit lastAccountInfoMessageInit;
/*      */   
/*      */   private ILotAmountProvider lotAmountProvider;
/*      */   
/*      */   private DDSChartsController ddsChartsController;
/*      */   private ClientChartsController clientChartsController;
/*      */   private final ICurrencyMarketManager currencyMarketManager;
/*      */   private IRemoteStrategyManager remoteManager;
/*      */   private final com.dukascopy.jss.nofication.JssEventsListener jssBroadcastListener;
/*  185 */   Object arbLock = new Object();
/*      */   
/*      */   private static enum LayoutType {
/*  188 */     GLOBAL_EXTENDED(13), 
/*  189 */     PLACE_BID_OFFER_HIDDEN(16), 
/*  190 */     DELIVERABLE_XAU(22);
/*      */     
/*      */     private int layoutId;
/*      */     
/*      */     private LayoutType(int layoutId) {
/*  195 */       this.layoutId = layoutId;
/*      */     }
/*      */     
/*      */     public int getId() {
/*  199 */       return this.layoutId;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  204 */   private com.dukascopy.api.IConsole console = new com.dukascopy.api.ConsoleAdapter()
/*      */   {
/*      */     public PrintStream getOut() {
/*  207 */       return DCClientImpl.this.out;
/*      */     }
/*      */     
/*      */     public PrintStream getErr()
/*      */     {
/*  212 */       return DCClientImpl.this.err;
/*      */     }
/*      */   };
/*      */   
/*      */   public DCClientImpl() {
/*  217 */     ThreadFactory threadFactory = new ThreadFactory() {
/*  218 */       final AtomicInteger threadNumber = new AtomicInteger(1);
/*      */       
/*      */       public Thread newThread(Runnable r)
/*      */       {
/*  222 */         Thread thread = new Thread(r, "Mina_Thread_" + this.threadNumber.getAndIncrement());
/*  223 */         if (!thread.isDaemon()) {
/*  224 */           thread.setDaemon(true);
/*      */         }
/*  226 */         return thread;
/*      */       }
/*  228 */     };
/*  229 */     this.out = System.out;
/*  230 */     this.err = System.err;
/*  231 */     NotificationUtilsProvider.setNotificationUtils(new PrintStreamNotificationUtils(this.out, this.err));
/*      */     
/*  233 */     this.version = getClass().getPackage().getImplementationVersion();
/*  234 */     if ((this.version == null) || (this.version.endsWith("SNAPSHOT"))) {
/*  235 */       this.version = "99.99.99";
/*      */     }
/*  237 */     this.serverProperties = new Properties();
/*  238 */     this.clientGUIListener = new ClientGUIListener(null);
/*      */     
/*  240 */     this.currencyMarketManager = new com.dukascopy.dds2.greed.market.LiveCurrencyMarketManager();
/*  241 */     this.jssBroadcastListener = new com.dukascopy.jss.nofication.JssEventsAdapter()
/*      */     {
/*      */       public void onStrategyBroadcast(RemoteStrategyBroadcastBean bean)
/*      */       {
/*  245 */         for (JForexTaskManager<?, ?, ?> taskManager : DCClientImpl.this.taskManagers.values()) {
/*  246 */           taskManager.onBroadcastMessage(bean.getTransactionId(), new StrategyBroadcastMessageImpl(bean.getTopic(), bean.getMessage(), System.currentTimeMillis()));
/*      */         }
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void connect(String jnlpUrl, String username, String password)
/*      */     throws Exception
/*      */   {
/*  261 */     connect(jnlpUrl, username, password, null);
/*      */   }
/*      */   
/*      */   public synchronized void connect(String jnlpUrl, String username, String password, String pin) throws Exception
/*      */   {
/*  266 */     if (this.transportClient == null) {
/*  267 */       String authServersCsv = getAuthServers(jnlpUrl);
/*  268 */       this.sessionID = UUID.randomUUID().toString();
/*  269 */       String[] urlList = authServersCsv.split(",");
/*  270 */       List<String> authServers = Arrays.asList(urlList);
/*  271 */       String ticket = authenticate(authServers, this.sessionID, username, password, true, pin);
/*      */       
/*  273 */       this.accountName = username;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  278 */       IFilePathManager fmanager = FilePathManager.getInstance();
/*  279 */       fmanager.setStrategiesFolderPath(fmanager.getDefaultStrategiesFolderPath());
/*      */       
/*  281 */       OrdersProvider.createInstance(null);
/*      */       
/*  283 */       String servicesUrl = this.serverProperties.getProperty("services1.url", "") + this.serverProperties.getProperty("tradelog_sfx.url", "");
/*  284 */       ActivityLogger.init(servicesUrl, username);
/*  285 */       List<String[]> feedCommissions = (List)this.serverProperties.get("feed.commission.history");
/*  286 */       Set<String> supportedInstruments = (Set)this.serverProperties.get("instruments");
/*  287 */       FeedDataProvider.createFeedDataProvider("SINGLEJAR", feedCommissions, supportedInstruments, new JStoreSettings()
/*      */       {
/*      */ 
/*      */ 
/*      */         public boolean isJStoreEnabled()
/*      */         {
/*      */ 
/*  294 */           Object property = DCClientImpl.this.serverProperties.get("wlabel.jsEnable");
/*  295 */           if (property == null) {
/*  296 */             return false;
/*      */           }
/*  298 */           return Boolean.valueOf(property.toString()).booleanValue();
/*      */         }
/*      */         
/*      */         public String getWlEnvironmentKey() {
/*  302 */           Object property = DCClientImpl.this.serverProperties.get("wlabel.uniEnvironmentKey");
/*  303 */           return property == null ? null : property.toString();
/*      */         }
/*      */         
/*      */         public String getLinkToCommunityRegistrationHomePage() {
/*  307 */           return "";
/*      */         }
/*      */         
/*  310 */       });
/*  311 */       FeedDataProvider.setPlatformTicket(ticket);
/*      */       
/*  313 */       this.transportClient.connect();
/*  314 */       FeedDataProvider.getDefaultInstance().connectToHistoryServer(this.transportClient, username, this.serverProperties.getProperty("history.server.url", null), this.serverProperties.getProperty("encryptionKey", null), true);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  320 */       FeedDataProvider.getDefaultInstance().setInstrumentsSubscribed(this.instruments);
/*      */       
/*  322 */       IndicatorsProvider.createInstance(new IndicatorsSettingsStorage(username));
/*      */       
/*  324 */       PlatformSessionClientBean platformSessionClientBean = PlatformSessionClientBean.getInstance();
/*  325 */       platformSessionClientBean.setSessionID(this.sessionID);
/*  326 */       platformSessionClientBean.setTicket(ticket);
/*  327 */       platformSessionClientBean.setUserName(username);
/*  328 */       platformSessionClientBean.setPlatformType(PlatformType.STANDALONE);
/*  329 */       platformSessionClientBean.setScheme(this.live ? "LIVE" : "DEMO");
/*      */ 
/*      */     }
/*  332 */     else if (!this.transportClient.isOnline())
/*      */     {
/*  334 */       this.lastAccountInfoMessage = null;
/*  335 */       this.initialized = false;
/*  336 */       String authServersCsv = getAuthServers(jnlpUrl);
/*  337 */       this.sessionID = UUID.randomUUID().toString();
/*  338 */       String[] urlList = authServersCsv.split(",");
/*  339 */       List<String> authServerUrls = Arrays.asList(urlList);
/*  340 */       String ticket = authenticate(authServerUrls, this.sessionID, username, password, true, pin);
/*  341 */       String servicesUrl = this.serverProperties.getProperty("services1.url", "") + this.serverProperties.getProperty("tradelog_sfx.url", "");
/*  342 */       ActivityLogger.init(servicesUrl, username);
/*  343 */       FeedDataProvider.setPlatformTicket(ticket);
/*  344 */       FeedDataProvider.getDefaultInstance().getFeedCommissionManager().clear();
/*      */       
/*  346 */       this.transportClient.connect();
/*  347 */       FeedDataProvider.getDefaultInstance().connectToHistoryServer(this.transportClient, username, this.serverProperties.getProperty("history.server.url", null), this.serverProperties.getProperty("encryptionKey", null), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void connect(Collection<String> authServerUrls, boolean live, String username, String password, boolean encodePassword)
/*      */     throws Exception
/*      */   {
/*  358 */     connect(authServerUrls, live, username, password, encodePassword, null);
/*      */   }
/*      */   
/*      */   public synchronized void connect(Collection<String> authServerUrls, boolean live, String username, String password, boolean encodePassword, String pin) throws Exception {
/*  362 */     this.live = live;
/*  363 */     if (this.transportClient == null) {
/*  364 */       String session = UUID.randomUUID().toString();
/*  365 */       String ticket = authenticate(authServerUrls, session, username, password, encodePassword, pin);
/*      */       
/*  367 */       this.accountName = username;
/*      */       
/*      */ 
/*      */ 
/*  371 */       OrdersProvider.createInstance(null);
/*      */       
/*  373 */       String servicesUrl = this.serverProperties.getProperty("services1.url", "") + this.serverProperties.getProperty("tradelog_sfx.url", "");
/*  374 */       ActivityLogger.init(servicesUrl, username);
/*  375 */       List<String[]> feedCommissions = (List)this.serverProperties.get("feed.commission.history");
/*  376 */       Set<String> supportedInstruments = (Set)this.serverProperties.get("instruments");
/*  377 */       FeedDataProvider.createFeedDataProvider("SINGLEJAR", feedCommissions, supportedInstruments);
/*  378 */       FeedDataProvider.setPlatformTicket(ticket);
/*      */       
/*  380 */       this.transportClient.connect();
/*  381 */       FeedDataProvider.getDefaultInstance().connectToHistoryServer(this.transportClient, username, this.serverProperties.getProperty("history.server.url", null), this.serverProperties.getProperty("encryptionKey", null), true);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  387 */       FeedDataProvider.getDefaultInstance().setInstrumentsSubscribed(this.instruments);
/*      */       
/*  389 */       IndicatorsProvider.createInstance(new IndicatorsSettingsStorage(username));
/*      */ 
/*      */     }
/*  392 */     else if (!this.transportClient.isOnline())
/*      */     {
/*  394 */       this.lastAccountInfoMessage = null;
/*  395 */       this.initialized = false;
/*  396 */       this.sessionID = UUID.randomUUID().toString();
/*  397 */       String ticket = authenticate(authServerUrls, this.sessionID, username, password, encodePassword, pin);
/*  398 */       String servicesUrl = this.serverProperties.getProperty("services1.url", "") + this.serverProperties.getProperty("tradelog_sfx.url", "");
/*  399 */       ActivityLogger.init(servicesUrl, username);
/*  400 */       FeedDataProvider.getDefaultInstance().getFeedCommissionManager().clear();
/*  401 */       FeedDataProvider.setPlatformTicket(ticket);
/*      */       
/*  403 */       this.transportClient.connect();
/*  404 */       FeedDataProvider.getDefaultInstance().connectToHistoryServer(this.transportClient, username, this.serverProperties.getProperty("history.server.url", null), this.serverProperties.getProperty("encryptionKey", null), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAuthServers(String jnlp)
/*      */     throws Exception
/*      */   {
/*  415 */     URL jnlpUrl = new URL(jnlp);
/*      */     
/*  417 */     InputStream jnlpIs = jnlpUrl.openConnection().getInputStream();Throwable localThrowable2 = null;
/*  418 */     Document doc; try { DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  419 */       doc = builder.parse(jnlpIs);
/*      */     }
/*      */     catch (Throwable localThrowable1)
/*      */     {
/*  417 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*      */     }
/*      */     finally {
/*  420 */       if (jnlpIs != null) if (localThrowable2 != null) try { jnlpIs.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else jnlpIs.close();
/*      */     }
/*  422 */     String authServersCsv = null;
/*  423 */     NodeList jnlpNodes = doc.getElementsByTagName("jnlp");
/*  424 */     if (jnlpNodes.getLength() < 1) {
/*  425 */       throw new Exception("Can't find jnlp element");
/*      */     }
/*  427 */     Element jnlpNode = (Element)jnlpNodes.item(0);
/*  428 */     NodeList resourcesNodes = jnlpNode.getElementsByTagName("resources");
/*  429 */     if (resourcesNodes.getLength() < 1) {
/*  430 */       throw new Exception("Can't find resources element");
/*      */     }
/*  432 */     Element resourcesNode = (Element)resourcesNodes.item(0);
/*  433 */     NodeList propertyNodes = resourcesNode.getElementsByTagName("property");
/*  434 */     for (int i = 0; i < propertyNodes.getLength(); i++) {
/*  435 */       Element propertyElement = (Element)propertyNodes.item(i);
/*      */       
/*  437 */       String nameAttribute = propertyElement.getAttribute("name");
/*  438 */       if ((nameAttribute != null) && (nameAttribute.trim().equals("jnlp.client.mode"))) {
/*  439 */         String clientMode = propertyElement.getAttribute("value").trim();
/*  440 */         this.live = ((!ObjectUtils.isNullOrEmpty(clientMode)) && (clientMode.equals("LIVE")));
/*  441 */       } else if ((nameAttribute != null) && (nameAttribute.trim().equals("jnlp.login.url"))) {
/*  442 */         authServersCsv = propertyElement.getAttribute("value").trim();
/*      */       }
/*      */     }
/*  445 */     if (authServersCsv == null) {
/*  446 */       throw new Exception("Can't find property with name attribute equals to jnlp.login.url");
/*      */     }
/*  448 */     return authServersCsv;
/*      */   }
/*      */   
/*      */   public BufferedImage getCaptchaImage(String jnlp) throws Exception
/*      */   {
/*  453 */     String authServersCsv = getAuthServers(jnlp);
/*  454 */     String[] urlList = authServersCsv.split(",");
/*  455 */     List<String> authServers = Arrays.asList(urlList);
/*  456 */     AuthorizationClient authorizationClient = AuthorizationClient.getInstance(authServers, this.version);
/*  457 */     Map<String, BufferedImage> imageCaptchaMap = authorizationClient.getImageCaptcha();
/*  458 */     if (!imageCaptchaMap.isEmpty()) {
/*  459 */       Map.Entry<String, BufferedImage> imageCaptchaEntry = (Map.Entry)imageCaptchaMap.entrySet().iterator().next();
/*  460 */       this.captchaId = ((String)imageCaptchaEntry.getKey());
/*  461 */       return (BufferedImage)imageCaptchaEntry.getValue();
/*      */     }
/*  463 */     return null;
/*      */   }
/*      */   
/*      */   private String authenticate(Collection<String> authServerUrls, String session, String username, String password, boolean encodePassword, String pin) throws Exception
/*      */   {
/*  468 */     AuthorizationClient authorizationClient = AuthorizationClient.getInstance(authServerUrls, this.version);
/*      */     
/*  470 */     if ((!encodePassword) && (pin != null)) {
/*  471 */       throw new Exception("(EncodePassword == false && pin != null) == NOT SUPPORTED");
/*      */     }
/*      */     
/*      */     AuthorizationServerResponse authorizationServerResponse;
/*      */     AuthorizationServerResponse authorizationServerResponse;
/*  476 */     if ((!encodePassword) || (pin == null)) {
/*  477 */       authorizationServerResponse = authorizationClient.getAPIsAndTicketUsingLogin(username, password, session, encodePassword, "DDS3_JFOREXSDK");
/*      */     } else {
/*  479 */       authorizationServerResponse = authorizationClient.getAPIsAndTicketUsingLogin(username, password, this.captchaId, pin, session, "DDS3_JFOREXSDK");
/*      */     }
/*      */     String authResponse;
/*  482 */     if (authorizationServerResponse != null) {
/*  483 */       authResponse = authorizationServerResponse.getFastestAPIAndTicket();
/*      */     } else {
/*  485 */       throw new IOException("Authentication failed, no server response.");
/*      */     }
/*      */     String authResponse;
/*  488 */     LOGGER.debug(authResponse);
/*      */     
/*  490 */     if (!authorizationServerResponse.isOK()) {
/*  491 */       AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode = authorizationServerResponse.getResponseCode();
/*      */       
/*  493 */       if (authorizationServerResponse.isEmptyResponse()) {
/*  494 */         throw new IOException("Authentication failed");
/*      */       }
/*      */       
/*  497 */       if ((AuthorizationClient.AuthorizationServerResponseCode.MINUS_ONE_OLD_ERROR == authorizationServerResponseCode) || (AuthorizationClient.AuthorizationServerResponseCode.AUTHENTICATION_AUTHORIZATION_ERROR == authorizationServerResponseCode))
/*      */       {
/*  499 */         throw new com.dukascopy.api.system.JFAuthenticationException("Incorrect username or password");
/*      */       }
/*      */       
/*  502 */       if (authorizationServerResponse.isWrongVersion()) {
/*  503 */         throw new JFVersionException("Incorrect version");
/*      */       }
/*      */       
/*  506 */       if (authorizationServerResponse.isNoAPIServers()) {
/*  507 */         throw new JFVersionException("System offline");
/*      */       }
/*      */       
/*  510 */       if (authorizationServerResponse.isSystemError()) {
/*  511 */         throw new JFVersionException("System error");
/*      */       }
/*      */       
/*  514 */       String message = authorizationServerResponseCode.getMessage();
/*  515 */       throw new com.dukascopy.api.JFException(message);
/*      */     }
/*      */     
/*  518 */     Matcher matcher = AuthorizationClient.RESULT_PATTERN.matcher(authResponse);
/*  519 */     if (!matcher.matches()) {
/*  520 */       throw new IOException("Authentication procedure returned unexpected result [" + authResponse + "]");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  525 */     String url = matcher.group(1);
/*  526 */     int semicolonIndex = url.indexOf(':');
/*  527 */     int port; String host; int port; if (semicolonIndex != -1) {
/*  528 */       String host = url.substring(0, semicolonIndex);
/*  529 */       int port; if (semicolonIndex + 1 >= url.length()) {
/*  530 */         LOGGER.warn("port not set, using default 443");
/*  531 */         port = 443;
/*      */       } else {
/*  533 */         port = Integer.parseInt(url.substring(semicolonIndex + 1));
/*      */       }
/*      */     } else {
/*  536 */       host = url;
/*  537 */       port = 443;
/*      */     }
/*      */     
/*  540 */     InetSocketAddress address = new InetSocketAddress(InetAddress.getByName(host), port);
/*      */     
/*  542 */     String ticket = matcher.group(7);
/*  543 */     Properties properties = authorizationClient.getAllProperties(username, ticket, session);
/*  544 */     initServerProperties(properties);
/*  545 */     this.lotAmountProvider = new LotAmountProvider();
/*      */     try {
/*  547 */       InetAddress localhost = InetAddress.getLocalHost();
/*  548 */       this.internalIP = (localhost != null ? localhost.getHostAddress() : null);
/*      */     } catch (UnknownHostException e) {
/*  550 */       LOGGER.error("Can't detect local IP : " + e.getMessage());
/*  551 */       this.internalIP = "";
/*      */     }
/*      */     
/*  554 */     String userAgent = getUserAgent(this.version, username, this.internalIP);
/*  555 */     LOGGER.debug("UserAgent: " + userAgent);
/*      */     
/*  557 */     if (this.authProvider == null) {
/*  558 */       this.authProvider = new GreedClientAuthorizationProvider(username, ticket, session);
/*      */     } else {
/*  560 */       this.authProvider.setSessionId(session);
/*  561 */       this.authProvider.setTicket(ticket);
/*  562 */       this.authProvider.setLogin(username);
/*      */     }
/*      */     
/*  565 */     this.authProvider.setUserAgent(userAgent);
/*      */     
/*  567 */     if (this.transportClient == null) {
/*  568 */       this.transportClient = new TransportClient();
/*  569 */       this.transportClient.setAddress(address);
/*  570 */       this.transportClient.addListener(this);
/*  571 */       this.transportClient.setAuthorizationProvider(this.authProvider);
/*      */       
/*  573 */       this.transportClient.setUserAgent(userAgent);
/*      */       
/*  575 */       this.transportClient.setPingConnection(true);
/*  576 */       this.transportClient.setPingTimeout(TRANSPORT_PING_TIMEOUT);
/*  577 */       this.transportClient.setPoolSize(2);
/*      */       
/*  579 */       this.transportClient.setUseSsl(true);
/*  580 */       this.transportClient.setSecurityExceptionHandler(new com.dukascopy.dds4.transport.client.SecurityExceptionHandler()
/*      */       {
/*      */         public boolean isIgnoreSecurityException(X509Certificate[] chain, String authType, CertificateException ex) {
/*  583 */           DCClientImpl.LOGGER.warn("Security exception : " + ex);
/*  584 */           return true;
/*      */         }
/*      */       });
/*      */     } else {
/*  588 */       this.transportClient.setAddress(address);
/*      */     }
/*  590 */     return ticket;
/*      */   }
/*      */   
/*      */   public static String getUserAgent(String version, String userName, String internalIP)
/*      */   {
/*  595 */     TransportUserAgent userAgent = new TransportUserAgent();
/*      */     
/*  597 */     userAgent.setClientVersion(version);
/*  598 */     userAgent.setJavaVersion(System.getProperty("java.version"));
/*  599 */     userAgent.setJvmVersion(System.getProperty("java.vm.version"));
/*  600 */     userAgent.setOsName(System.getProperty("os.name"));
/*  601 */     userAgent.setUserName(userName);
/*  602 */     userAgent.setIp(internalIP);
/*  603 */     userAgent.setClientType("sdk");
/*      */     
/*  605 */     return userAgent.toJsonString();
/*      */   }
/*      */   
/*      */   public synchronized void reconnect()
/*      */   {
/*  610 */     if ((this.transportClient != null) && (!this.transportClient.isOnline())) {
/*  611 */       this.transportClient.connect();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void disconnect()
/*      */   {
/*  617 */     for (Long processId : getStartedStrategies().keySet()) {
/*  618 */       stopStrategy(processId.longValue());
/*      */     }
/*  620 */     if (FeedDataProvider.getDefaultInstance() != null) {
/*  621 */       FeedDataProvider.getDefaultInstance().close();
/*      */     }
/*      */     try {
/*  624 */       TimeUnit.SECONDS.sleep(1L);
/*      */     } catch (InterruptedException e) {}
/*  626 */     if (this.transportClient != null) {
/*  627 */       if (this.transportClient.isOnline()) {
/*      */         try {
/*  629 */           this.transportClient.controlRequest(new com.dukascopy.dds3.transport.msg.ddsApi.QuitRequestMessage());
/*      */         } catch (Throwable e) {
/*  631 */           LOGGER.error(e.getMessage(), e);
/*      */         }
/*      */       }
/*  634 */       this.transportClient.disconnect();
/*  635 */       this.transportClient.terminate();
/*  636 */       this.transportClient = null;
/*  637 */       this.authProvider = null;
/*      */     }
/*  639 */     this.newsFilters.clear();
/*  640 */     this.instruments.clear();
/*  641 */     this.captchaId = null;
/*  642 */     this.lastAccountInfoMessage = null;
/*  643 */     this.accountName = null;
/*  644 */     this.internalIP = null;
/*  645 */     this.sessionID = null;
/*  646 */     this.live = false;
/*  647 */     this.serverProperties = new Properties();
/*  648 */     this.initialized = false;
/*      */   }
/*      */   
/*      */   public boolean isConnected()
/*      */   {
/*  653 */     return (this.transportClient != null) && (this.transportClient.isOnline()) && (this.initialized);
/*      */   }
/*      */   
/*      */   private void connectedInit()
/*      */   {
/*  658 */     InitRequestMessage initRequestMessage = new InitRequestMessage();
/*  659 */     initRequestMessage.setSendGroups(true);
/*  660 */     initRequestMessage.setSendPacked(true);
/*  661 */     this.transportClient.controlRequest(initRequestMessage);
/*  662 */     setSubscribedInstruments(this.instruments);
/*      */     
/*  664 */     for (INewsFilter newsFilter : this.newsFilters.values()) {
/*  665 */       NewsSubscribeRequest newsSubscribeRequest = new NewsSubscribeRequest();
/*      */       
/*  667 */       Set<NewsSource> sources = TransportHelper.toTransportSources(newsFilter.getNewsSources());
/*  668 */       newsSubscribeRequest.setSources(sources);
/*  669 */       if ((sources != null) && (!sources.isEmpty())) {
/*  670 */         newsSubscribeRequest.setSource((NewsSource)sources.iterator().next());
/*      */       }
/*      */       
/*  673 */       newsSubscribeRequest.setHot(newsFilter.isOnlyHot());
/*  674 */       newsSubscribeRequest.setGeoRegions(EnumConverter.convert(newsFilter.getCountries(), GeoRegion.class));
/*  675 */       newsSubscribeRequest.setMarketSectors(EnumConverter.convert(newsFilter.getMarketSectors(), MarketSector.class));
/*  676 */       newsSubscribeRequest.setIndicies(EnumConverter.convert(newsFilter.getStockIndicies(), StockIndex.class));
/*  677 */       newsSubscribeRequest.setCurrencies(EnumConverter.convertByName(newsFilter.getCurrencies()));
/*  678 */       newsSubscribeRequest.setEventCategories(EnumConverter.convert(newsFilter.getEventCategories(), EventCategory.class));
/*      */       
/*  680 */       newsSubscribeRequest.setKeywords(newsFilter.getKeywords());
/*  681 */       newsSubscribeRequest.setFrom(newsFilter.getFrom() == null ? Long.MIN_VALUE : newsFilter.getFrom().getTime());
/*  682 */       newsSubscribeRequest.setTo(newsFilter.getTo() == null ? Long.MIN_VALUE : newsFilter.getTo().getTime());
/*  683 */       newsSubscribeRequest.setCalendarType((CalendarType)EnumConverter.convert(newsFilter.getType(), CalendarType.class));
/*      */       
/*  685 */       LOGGER.debug("Subscribing : " + newsSubscribeRequest);
/*      */       
/*  687 */       this.transportClient.controlRequest(newsSubscribeRequest);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setSystemListener(final ISystemListener userSystemListener)
/*      */   {
/*  694 */     this.systemListener = new ISystemListenerExtended()
/*      */     {
/*      */       public void onStart(long processId) {
/*  697 */         userSystemListener.onStart(processId);
/*      */       }
/*      */       
/*      */       public void onStop(long processId) {
/*  701 */         synchronized (DCClientImpl.this) {
/*  702 */           DCClientImpl.this.taskManagers.remove(Long.valueOf(processId));
/*  703 */           DCClientImpl.this.runningJfRunnables.remove(Long.valueOf(processId));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  712 */         userSystemListener.onStop(processId);
/*  713 */         ActivityLogger.getInstance().flush();
/*      */       }
/*      */       
/*      */       public void onConnect() {
/*  717 */         userSystemListener.onConnect();
/*      */       }
/*      */       
/*      */       public void onDisconnect() {
/*  721 */         userSystemListener.onDisconnect();
/*      */       }
/*      */       
/*      */       public void subscribeToInstruments(Set<Instrument> instruments, boolean lock)
/*      */       {
/*  726 */         Set<Instrument> combinedInstruments = new HashSet(DCClientImpl.this.instruments);
/*  727 */         combinedInstruments.addAll(instruments);
/*  728 */         DCClientImpl.this.setSubscribedInstruments(combinedInstruments);
/*      */       }
/*      */       
/*      */       /* Error */
/*      */       public Set<Instrument> getSubscribedInstruments()
/*      */       {
/*      */         // Byte code:
/*      */         //   0: aload_0
/*      */         //   1: getfield 1	com/dukascopy/api/impl/connect/DCClientImpl$6:this$0	Lcom/dukascopy/api/impl/connect/DCClientImpl;
/*      */         //   4: dup
/*      */         //   5: astore_1
/*      */         //   6: monitorenter
/*      */         //   7: new 14	java/util/HashSet
/*      */         //   10: dup
/*      */         //   11: aload_0
/*      */         //   12: getfield 1	com/dukascopy/api/impl/connect/DCClientImpl$6:this$0	Lcom/dukascopy/api/impl/connect/DCClientImpl;
/*      */         //   15: invokestatic 15	com/dukascopy/api/impl/connect/DCClientImpl:access$700	(Lcom/dukascopy/api/impl/connect/DCClientImpl;)Ljava/util/Set;
/*      */         //   18: invokespecial 16	java/util/HashSet:<init>	(Ljava/util/Collection;)V
/*      */         //   21: aload_1
/*      */         //   22: monitorexit
/*      */         //   23: areturn
/*      */         //   24: astore_2
/*      */         //   25: aload_1
/*      */         //   26: monitorexit
/*      */         //   27: aload_2
/*      */         //   28: athrow
/*      */         // Line number table:
/*      */         //   Java source line #733	-> byte code offset #0
/*      */         //   Java source line #734	-> byte code offset #7
/*      */         //   Java source line #735	-> byte code offset #24
/*      */         // Local variable table:
/*      */         //   start	length	slot	name	signature
/*      */         //   0	29	0	this	6
/*      */         //   5	21	1	Ljava/lang/Object;	Object
/*      */         //   24	4	2	localObject1	Object
/*      */         // Exception table:
/*      */         //   from	to	target	type
/*      */         //   7	23	24	finally
/*      */         //   24	27	24	finally
/*      */       }
/*      */     };
/*  739 */     for (JForexTaskManager<?, ?, ?> taskManager : this.taskManagers.values()) {
/*  740 */       taskManager.setSystemListener(this.systemListener);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addClientGUIListener(IClientGUIListener listener)
/*      */   {
/*  746 */     this.clientGUIListener.addListener(listener);
/*      */   }
/*      */   
/*      */   public void removeClientGUIListener(IClientGUIListener listener)
/*      */   {
/*  751 */     this.clientGUIListener.removeListener(listener);
/*      */   }
/*      */   
/*      */   public synchronized void setStrategyEventsListener(StrategyEventsCallback strategyEventsCallback) {
/*  755 */     for (JForexTaskManager<?, ?, ?> taskManager : this.taskManagers.values()) {
/*  756 */       taskManager.setStrategyEventsCallback(strategyEventsCallback);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void feedbackMessageReceived(ITransportClient client, ProtocolMessage message)
/*      */   {
/*  764 */     TransportClient providedClient = (TransportClient)TransportClient.class.cast(client);
/*  765 */     if ((providedClient != null) && (
/*  766 */       (!providedClient.isOnline()) || (providedClient.isTerminated()) || (ObjectUtils.isNullOrEmpty(this.transportClient)) || (!ObjectUtils.isEqual(providedClient.getSessionId(), this.transportClient.getSessionId()))))
/*      */     {
/*      */ 
/*  769 */       return;
/*      */     }
/*      */     
/*  772 */     if ((message instanceof AccountInfoMessage)) {
/*  773 */       onAccountInfoMessage((AccountInfoMessage)message);
/*  774 */     } else if ((message instanceof PackedAccountInfoMessage)) {
/*  775 */       onPackedAccountInfoMessage((PackedAccountInfoMessage)message);
/*  776 */     } else if ((message instanceof OrderGroupMessage)) {
/*  777 */       onOrderGroupMessage(message);
/*  778 */     } else if ((message instanceof OrderMessage)) {
/*  779 */       onOrderMessage(message);
/*  780 */     } else if ((message instanceof MergePositionsMessage)) {
/*  781 */       OrdersProvider.getInstance().groupsMerged((MergePositionsMessage)message);
/*  782 */     } else if ((message instanceof CurrencyMarket)) {
/*  783 */       if (this.lastAccountInfoMessage != null) {
/*  784 */         CurrencyMarket currencyMarket = (CurrencyMarket)message;
/*  785 */         if (this.instruments.contains(Instrument.fromString(currencyMarket.getInstrument())))
/*      */         {
/*  787 */           this.currencyMarketManager.currencyUpdateReceived(currencyMarket, new TickListener()
/*      */           {
/*      */ 
/*      */             public boolean tickReceived(CurrencyMarket hTick, boolean realTime)
/*      */             {
/*  792 */               FeedDataProvider.getDefaultInstance().tickReceived(hTick, realTime);
/*  793 */               synchronized (DCClientImpl.this.taskManagers) {
/*  794 */                 for (JForexTaskManager<?, ?, ?> taskManager : DCClientImpl.this.taskManagers.values()) {
/*  795 */                   if ((taskManager instanceof StrategyTaskManager))
/*      */                   {
/*      */ 
/*  798 */                     if ((DCClientImpl.this.lastAccountInfoMessage != null) && 
/*  799 */                       (DCClientImpl.this.instruments.contains(Instrument.fromString(hTick.getInstrument())))) {
/*  800 */                       ((StrategyTaskManager)taskManager).onMarketState(hTick);
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*  805 */               return true;
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */     }
/*  811 */     else if (((message instanceof ErrorResponseMessage)) || ((message instanceof com.dukascopy.dds3.transport.msg.dfs.AbstractDFSMessage))) {
/*  812 */       FeedDataProvider.getDefaultInstance().processMessage(message);
/*      */     }
/*      */     
/*  815 */     for (JForexTaskManager<?, ?, ?> taskManager : this.taskManagers.values()) {
/*  816 */       if ((message instanceof OrderGroupMessage)) {
/*  817 */         taskManager.onOrderGroupReceived((OrderGroupMessage)message);
/*  818 */       } else if ((message instanceof OrderMessage)) {
/*  819 */         OrderMessageExt orderMessage = null;
/*  820 */         if ((message instanceof OrderMessageExt)) {
/*  821 */           orderMessage = (OrderMessageExt)message;
/*      */         } else {
/*  823 */           orderMessage = ProtocolUtils.getInstance((OrderMessage)message);
/*      */         }
/*  825 */         taskManager.onOrderReceived(orderMessage);
/*  826 */       } else if ((message instanceof NotificationMessage)) {
/*  827 */         NotificationMessage notificationMessage = (NotificationMessage)message;
/*  828 */         if ((notificationMessage.getLevel() == null) || (notificationMessage.getLevel().equals("INFO"))) {
/*  829 */           NotificationUtilsProvider.getNotificationUtils().postInfoMessage(notificationMessage.getText());
/*  830 */         } else if (notificationMessage.getLevel().equals("WARNING")) {
/*  831 */           NotificationUtilsProvider.getNotificationUtils().postWarningMessage(notificationMessage.getText());
/*  832 */         } else if (notificationMessage.getLevel().equals("ERROR")) {
/*  833 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(notificationMessage.getText());
/*      */         } else {
/*  835 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(notificationMessage.getText());
/*      */         }
/*  837 */         taskManager.onNotifyMessage(notificationMessage);
/*  838 */       } else if ((message instanceof AccountInfoMessage)) {
/*  839 */         taskManager.updateAccountInfo((AccountInfoMessage)message);
/*  840 */       } else if ((message instanceof PackedAccountInfoMessage)) {
/*  841 */         AccountInfoMessageInit accountInfoMessageInit = ((PackedAccountInfoMessage)message).getAccount();
/*  842 */         taskManager.updateAccountInfo(accountInfoMessageInit);
/*  843 */       } else if ((message instanceof MergePositionsMessage)) {
/*  844 */         taskManager.onOrdersMergedMessage((MergePositionsMessage)message);
/*  845 */       } else if ((message instanceof OrderSyncMessage)) {
/*  846 */         OrdersProvider.getInstance().orderSynch((OrderSyncMessage)message);
/*  847 */         taskManager.orderSynch((OrderSyncMessage)message);
/*  848 */         taskManager.onConnect(true);
/*  849 */       } else if ((message instanceof InstrumentStatusUpdateMessage)) {
/*  850 */         InstrumentStatusUpdateMessage instrumentStatusUpdateMessage = (InstrumentStatusUpdateMessage)InstrumentStatusUpdateMessage.class.cast(message);
/*  851 */         Instrument instrument = Instrument.fromString(instrumentStatusUpdateMessage.getInstrument());
/*  852 */         TradabilityState state = instrumentStatusUpdateMessage.getState();
/*  853 */         boolean tradable = ObjectUtils.isEqual(TradabilityState.TRADING_ALLOWED, state);
/*  854 */         taskManager.onIntrumentUpdate(instrument, tradable, message.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : message.getTimestamp().longValue());
/*  855 */       } else if ((message instanceof NewsStoryMessage)) {
/*  856 */         taskManager.onNewsMessage((NewsStoryMessage)message);
/*  857 */       } else if ((message instanceof NewsCommandMessage)) {
/*  858 */         taskManager.onNewsCommandMessage((NewsCommandMessage)message);
/*  859 */       } else if ((!(message instanceof com.dukascopy.dds4.transport.msg.system.OkResponseMessage)) && (!(message instanceof com.dukascopy.dds3.transport.msg.dfs.CandleHistoryGroupMessage)) && (!(message instanceof com.dukascopy.dds3.transport.msg.jss.StrategyBroadcastMessage)) && (!(message instanceof CurrencyMarket)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  868 */         LOGGER.debug("Unrecognized protocol message : " + message.getClass() + " / " + message);
/*  869 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void onAccountInfoMessage(AccountInfoMessage message) {
/*  875 */     com.dukascopy.dds2.greed.agent.indicator.AccountProvider.updateAccountInfo(message, this.accountName);
/*  876 */     FeedDataProvider.getDefaultInstance().setCurrentTime(message.getTimestamp().longValue());
/*  877 */     OrdersProvider.getInstance().updateAccountInfoData(message);
/*      */     
/*  879 */     if ((message instanceof AccountInfoMessageInit)) {
/*  880 */       this.lastAccountInfoMessageInit = ((AccountInfoMessageInit)message);
/*      */       
/*  882 */       Map<String, com.dukascopy.dds3.transport.msg.acc.FeedCommission> feedCommissions = ((AccountInfoMessageInit)AccountInfoMessageInit.class.cast(message)).getFeedCommissionMap();
/*  883 */       if (feedCommissions != null) {
/*  884 */         FeedDataProvider.getDefaultInstance().getFeedCommissionManager().addFeedCommissions(feedCommissions, message.getTimestamp());
/*      */       }
/*      */     } else {
/*  887 */       this.lastAccountInfoMessage = message;
/*  888 */       if (!this.initialized)
/*      */       {
/*  890 */         setSubscribedInstruments(this.instruments);
/*  891 */         this.initialized = true;
/*  892 */         fireConnected();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void onPackedAccountInfoMessage(PackedAccountInfoMessage packedAccountInfoMessage) {
/*  898 */     AccountInfoMessageInit accountInfoMessage = packedAccountInfoMessage.getAccount();
/*  899 */     if (accountInfoMessage != null) {
/*  900 */       onAccountInfoMessage(accountInfoMessage);
/*      */     }
/*      */     
/*  903 */     for (OrderMessage orderMessage : packedAccountInfoMessage.getOrders()) {
/*  904 */       onOrderMessage(orderMessage);
/*      */     }
/*  906 */     for (OrderGroupMessage orderGroupMessage : packedAccountInfoMessage.getGroups()) {
/*  907 */       onOrderGroupMessage(orderGroupMessage);
/*      */     }
/*      */   }
/*      */   
/*      */   private void onOrderMessage(ProtocolMessage protocolMessage) {
/*  912 */     OrderMessage orderMessage = (OrderMessage)protocolMessage;
/*  913 */     orderMessage = ProtocolUtils.updateAmounts(orderMessage);
/*  914 */     OrdersProvider.getInstance().updateOrder(orderMessage);
/*  915 */     String instrumentStr = orderMessage.getInstrument();
/*  916 */     if (instrumentStr != null) {
/*  917 */       Instrument instrument = Instrument.fromString(instrumentStr);
/*  918 */       if (!this.instruments.contains(instrument)) {
/*  919 */         LOGGER.debug("Order received for instrument [" + instrument + "], adding instrument to the list of the subscribed instruments");
/*  920 */         setSubscribedInstruments(this.instruments);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void onOrderGroupMessage(ProtocolMessage protocolMessage) {
/*  926 */     OrderGroupMessage orderGroupMessage = (OrderGroupMessage)protocolMessage;
/*  927 */     orderGroupMessage = ProtocolUtils.updateAmounts(orderGroupMessage);
/*  928 */     OrdersProvider.getInstance().updateOrderGroup(orderGroupMessage);
/*  929 */     String instrumentStr = orderGroupMessage.getInstrument();
/*  930 */     if (instrumentStr != null) {
/*  931 */       Instrument instrument = Instrument.fromString(instrumentStr);
/*  932 */       if (!this.instruments.contains(instrument)) {
/*  933 */         LOGGER.debug("Order group received for instrument [" + instrument + "], adding instrument to the list of the subscribed instruments");
/*  934 */         setSubscribedInstruments(this.instruments);
/*      */       }
/*      */     } else {
/*  937 */       OrderMessage openingOrder = ProtocolUtils.getOpeningOrder(orderGroupMessage);
/*  938 */       instrumentStr = openingOrder == null ? null : openingOrder.getInstrument();
/*  939 */       if (instrumentStr != null) {
/*  940 */         Instrument instrument = Instrument.fromString(instrumentStr);
/*  941 */         if (!this.instruments.contains(instrument)) {
/*  942 */           LOGGER.debug("Order group received for instrument [" + instrument + "], adding instrument to the list of the subscribed instruments");
/*  943 */           setSubscribedInstruments(this.instruments);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void authorized(ITransportClient client)
/*      */   {
/*  951 */     connectedInit();
/*      */     
/*  953 */     if (this.initialized) {
/*  954 */       fireConnected();
/*      */     }
/*      */     
/*  957 */     this.currencyMarketManager.start();
/*      */   }
/*      */   
/*      */   private void fireConnected()
/*      */   {
/*  962 */     ISystemListener systemListener = getSystemListener();
/*  963 */     systemListener.onConnect();
/*      */     
/*  965 */     FeedDataProvider.getDefaultInstance().connected();
/*  966 */     this.remoteManager = com.dukascopy.api.impl.connect.strategy.remote.RemoteStrategyManager.getResetInstance();
/*  967 */     this.ddsChartsController = DDSChartsControllerFactory.instance().getDefaultInstance();
/*  968 */     this.clientChartsController = new ClientChartsController(this.ddsChartsController, getClass().getName());
/*  969 */     this.ddsChartsController.changeChartTrading(false);
/*  970 */     FeedDataProvider.getDefaultInstance().getJssManager().addJssListener(this.jssBroadcastListener);
/*      */   }
/*      */   
/*      */   public synchronized void disconnected(DisconnectedEvent event)
/*      */   {
/*  975 */     if (FeedDataProvider.getDefaultInstance() != null) {
/*  976 */       FeedDataProvider.getDefaultInstance().disconnected();
/*  977 */       FeedDataProvider.getDefaultInstance().getJssManager().removeJssListener(this.jssBroadcastListener);
/*      */     }
/*      */     
/*  980 */     ISystemListener systemListener = getSystemListener();
/*  981 */     systemListener.onDisconnect();
/*  982 */     for (JForexTaskManager<?, ?, ?> taskManager : this.taskManagers.values()) {
/*  983 */       taskManager.onConnect(false);
/*      */     }
/*  985 */     if (this.ddsChartsController != null) {
/*  986 */       this.ddsChartsController.dispose();
/*      */     }
/*      */     
/*  989 */     this.currencyMarketManager.stop();
/*      */   }
/*      */   
/*      */   public long startStrategy(IStrategy strategy) throws IllegalStateException, NullPointerException
/*      */   {
/*  994 */     return startJFRunnable(strategy, StrategyTaskManager.Builder.newSdkInstance(), null, null, JForexTaskManager.Environment.LOCAL_EMBEDDED, true, null);
/*      */   }
/*      */   
/*      */   public long startStrategy(IStrategy strategy, IStrategyExceptionHandler exceptionHandler)
/*      */   {
/*  999 */     return startJFRunnable(strategy, StrategyTaskManager.Builder.newSdkInstance(), null, exceptionHandler, JForexTaskManager.Environment.LOCAL_EMBEDDED, true, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <RUNNABLE extends IJFRunnable<?>, UI extends IUserInterface, MANAGER extends JForexTaskManager<?, RUNNABLE, UI>, BUILDER extends JForexTaskManager.Builder<?, RUNNABLE, UI, MANAGER>> long startJFRunnable(final RUNNABLE jfRunnable, BUILDER builder, IStrategyListener strategyListener, IStrategyExceptionHandler exceptionHandler, JForexTaskManager.Environment taskManagerEnvironment, boolean fullAccessGranted, String strategyHash)
/*      */     throws IllegalStateException, NullPointerException
/*      */   {
/*      */     MANAGER taskManager;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     long temporaryProcessId;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1020 */     synchronized (this) {
/* 1021 */       if (!this.transportClient.isOnline()) {
/* 1022 */         throw new IllegalStateException("Not connected");
/*      */       }
/* 1024 */       if (!this.initialized) {
/* 1025 */         throw new IllegalStateException("Not initialized");
/*      */       }
/* 1027 */       if (jfRunnable == null) {
/* 1028 */         throw new NullPointerException("Runnable is null");
/*      */       }
/* 1030 */       if (exceptionHandler == null) {
/* 1031 */         exceptionHandler = new DefaultStrategyExceptionHandler(null);
/*      */       }
/*      */       
/* 1034 */       taskManager = builder.build(taskManagerEnvironment, this.live, this.accountName, this.console, this.transportClient, this.ddsChartsController, this.lotAmountProvider, exceptionHandler, this.lastAccountInfoMessage, this.lastAccountInfoMessageInit, this.serverProperties.getProperty("external_ip"), this.internalIP, this.sessionID, this.serverProperties, this.clientGUIListener);
/*      */       
/*      */ 
/*      */ 
/* 1038 */       taskManager.setSystemListener((ISystemListenerExtended)ISystemListenerExtended.class.cast(getSystemListener()));
/* 1039 */       if ((exceptionHandler instanceof DefaultStrategyExceptionHandler)) {
/* 1040 */         ((DefaultStrategyExceptionHandler)exceptionHandler).setTaskManager(taskManager);
/*      */       }
/*      */       
/* 1043 */       temporaryProcessId = this.temporaryKeys;
/* 1044 */       this.temporaryKeys -= 1L;
/* 1045 */       this.taskManagers.put(Long.valueOf(temporaryProcessId), taskManager);
/* 1046 */       this.runningJfRunnables.put(Long.valueOf(temporaryProcessId), jfRunnable);
/*      */     }
/*      */     
/*      */ 
/* 1050 */     String strategyKey = jfRunnable.getClass().getSimpleName();
/* 1051 */     String classMD5 = "";
/* 1052 */     if (strategyHash == null) {
/* 1053 */       classMD5 = ObjectUtils.getMD5(jfRunnable.getClass());
/* 1054 */       strategyKey = strategyKey + ".class" + (classMD5 == null ? "" : new StringBuilder().append(" ").append(classMD5).toString());
/*      */     } else {
/* 1056 */       strategyKey = strategyKey + ".jfx " + strategyHash;
/*      */     }
/*      */     
/* 1059 */     final long processId = taskManager.startJfRunnable(jfRunnable, strategyListener, strategyKey, fullAccessGranted, classMD5, null);
/* 1060 */     synchronized (this) {
/* 1061 */       if (processId == 0L) {
/* 1062 */         this.taskManagers.remove(Long.valueOf(temporaryProcessId));
/* 1063 */         this.runningJfRunnables.remove(Long.valueOf(temporaryProcessId));
/*      */       } else {
/* 1065 */         this.taskManagers.remove(Long.valueOf(temporaryProcessId));
/* 1066 */         this.runningJfRunnables.remove(Long.valueOf(temporaryProcessId));
/*      */         
/* 1068 */         this.taskManagers.put(Long.valueOf(processId), taskManager);
/* 1069 */         this.runningJfRunnables.put(Long.valueOf(processId), jfRunnable);
/*      */         
/*      */ 
/* 1072 */         new Thread(new Runnable()
/*      */         {
/*      */           public void run()
/*      */           {
/*      */             try {
/* 1077 */               Thread.sleep(100L);
/*      */             } catch (InterruptedException e) {
/* 1079 */               e.printStackTrace();
/*      */             }
/* 1081 */             if ((jfRunnable instanceof IStrategy)) {
/* 1082 */               synchronized (DCClientImpl.this.runnablesListeners) {
/* 1083 */                 for (IJFRunnablesListener listener : DCClientImpl.this.runnablesListeners) {
/* 1084 */                   StrategyNewBean bean = StrategyNewBean.createFilelessBean((IStrategy)jfRunnable);
/* 1085 */                   bean.setStatus(com.dukascopy.dds2.greed.agent.strategy.bean.JFRunnableStatus.STARTING);
/* 1086 */                   listener.onStrategyStart(processId, bean);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }).start();
/*      */       }
/*      */       
/*      */ 
/* 1095 */       return processId;
/*      */     }
/*      */   }
/*      */   
/*      */   public IStrategy loadStrategy(File strategyBinaryFile) throws IOException, java.security.GeneralSecurityException
/*      */   {
/* 1101 */     JFXPack jfxPack = JFXPack.loadFromPack(strategyBinaryFile);
/* 1102 */     return (IStrategy)jfxPack.getTarget();
/*      */   }
/*      */   
/*      */   public synchronized void stopStrategy(long processId)
/*      */   {
/* 1107 */     if (!this.runningJfRunnables.containsKey(Long.valueOf(processId))) {
/* 1108 */       return;
/*      */     }
/* 1110 */     JForexTaskManager<?, ?, ?> taskManager = (JForexTaskManager)this.taskManagers.remove(Long.valueOf(processId));
/* 1111 */     taskManager.stopStrategy();
/* 1112 */     IJFRunnable<?> jfRunnable = (IJFRunnable)this.runningJfRunnables.remove(Long.valueOf(processId));
/* 1113 */     if ((jfRunnable != null) && ((jfRunnable instanceof IStrategy))) {
/* 1114 */       synchronized (this.runnablesListeners) {
/* 1115 */         for (IJFRunnablesListener listener : this.runnablesListeners) {
/* 1116 */           listener.onStrategyStop(processId, StrategyNewBean.createFilelessBean((IStrategy)jfRunnable));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized ISystemListener getSystemListener()
/*      */   {
/* 1124 */     if (this.systemListener == null)
/*      */     {
/*      */ 
/* 1127 */       setSystemListener(new DefaultSystemListener(null));
/*      */     }
/* 1129 */     return this.systemListener;
/*      */   }
/*      */   
/*      */   public synchronized Map<Long, IStrategy> getStartedStrategies()
/*      */   {
/* 1134 */     Map<Long, IStrategy> map = new HashMap();
/* 1135 */     for (Map.Entry<Long, IJFRunnable<?>> entry : this.runningJfRunnables.entrySet()) {
/* 1136 */       if ((entry.getValue() instanceof IStrategy)) {
/* 1137 */         map.put(entry.getKey(), (IStrategy)entry.getValue());
/*      */       }
/*      */     }
/* 1140 */     return map;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Map<UUID, Plugin> getRunningPlugins()
/*      */   {
/* 1146 */     Map<UUID, Plugin> map = new HashMap();
/* 1147 */     for (Iterator i$ = this.runningJfRunnables.entrySet().iterator(); i$.hasNext();) { runnableEntry = (Map.Entry)i$.next();
/* 1148 */       if ((runnableEntry.getValue() instanceof Plugin))
/*      */       {
/*      */ 
/* 1151 */         id = ((Long)runnableEntry.getKey()).longValue();
/* 1152 */         for (Map.Entry<UUID, Long> pluginEntry : this.pluginIdMap.entrySet())
/* 1153 */           if (((Long)pluginEntry.getValue()).equals(Long.valueOf(id))) {
/* 1154 */             map.put(pluginEntry.getKey(), (Plugin)runnableEntry.getValue());
/* 1155 */             break;
/*      */           } } }
/*      */     Map.Entry<Long, IJFRunnable<?>> runnableEntry;
/*      */     long id;
/* 1159 */     return map;
/*      */   }
/*      */   
/*      */   public synchronized void setSubscribedInstruments(final Set<Instrument> instruments)
/*      */   {
/*      */     try {
/* 1165 */       java.security.AccessController.doPrivileged(new java.security.PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception {
/* 1168 */           Set<Instrument> mergedInstruments = new HashSet(instruments);
/* 1169 */           synchronized (DCClientImpl.this.taskManagers) {
/* 1170 */             for (JForexTaskManager<?, ?, ?> engine : DCClientImpl.this.taskManagers.values()) {
/* 1171 */               mergedInstruments.addAll(engine.getRequiredInstruments());
/*      */             }
/*      */           }
/* 1174 */           if (DCClientImpl.this.transportClient != null) {
/* 1175 */             mergedInstruments.addAll(OrdersProvider.getInstance().getOrderInstruments());
/* 1176 */             mergedInstruments.addAll(OrdersProvider.getInstance().getExposureInstruments());
/*      */           }
/* 1178 */           for (Instrument instrument : new HashSet(mergedInstruments)) {
/* 1179 */             mergedInstruments.addAll(AbstractCurrencyConverter.getConversionDeps(instrument.getSecondaryJFCurrency(), Instrument.EURUSD.getSecondaryJFCurrency()));
/*      */           }
/* 1181 */           if (DCClientImpl.this.lastAccountInfoMessage != null) {
/* 1182 */             mergedInstruments.addAll(AbstractCurrencyConverter.getConversionDeps(Instrument.EURUSD.getSecondaryJFCurrency(), com.dukascopy.api.JFCurrency.getInstance(DCClientImpl.this.lastAccountInfoMessage.getCurrency())));
/*      */           }
/* 1184 */           if (DCClientImpl.this.transportClient != null) {
/* 1185 */             QuoteSubscribeRequestMessage quoteSubscribeRequestMessage = new QuoteSubscribeRequestMessage();
/* 1186 */             quoteSubscribeRequestMessage.setInstruments(Instrument.toStringSet(mergedInstruments));
/* 1187 */             quoteSubscribeRequestMessage.setTopOfBook(false);
/* 1188 */             DCClientImpl.this.transportClient.controlRequest(quoteSubscribeRequestMessage);
/*      */           }
/* 1190 */           if (FeedDataProvider.getDefaultInstance() != null) {
/* 1191 */             FeedDataProvider.getDefaultInstance().setInstrumentsSubscribed(mergedInstruments);
/*      */           }
/* 1193 */           DCClientImpl.this.instruments = new HashSet(mergedInstruments);
/*      */           
/* 1195 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException ex) {
/* 1199 */       throw new RuntimeException("Instruments subscription error", ex.getException());
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized INewsFilter getNewsFilter(INewsFilter.NewsSource newsSource)
/*      */   {
/* 1205 */     return (INewsFilter)this.newsFilters.get(newsSource);
/*      */   }
/*      */   
/*      */   public synchronized INewsFilter removeNewsFilter(INewsFilter.NewsSource newsSource)
/*      */   {
/* 1210 */     if ((this.transportClient != null) && (this.transportClient.isOnline())) {
/* 1211 */       NewsSubscribeRequest newsUnsubscribeRequest = new NewsSubscribeRequest();
/* 1212 */       newsUnsubscribeRequest.setRequestType(SubscribeRequestType.UNSUBSCRIBE);
/* 1213 */       newsUnsubscribeRequest.setSources(Collections.singleton(NewsSource.valueOf(newsSource.name())));
/* 1214 */       newsUnsubscribeRequest.setSource(NewsSource.valueOf(newsSource.name()));
/*      */       
/* 1216 */       LOGGER.debug("Unsubscribing : " + newsUnsubscribeRequest);
/*      */       
/* 1218 */       this.transportClient.controlRequest(newsUnsubscribeRequest);
/* 1219 */       return (INewsFilter)this.newsFilters.remove(newsSource);
/*      */     }
/* 1221 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized Set<Instrument> getSubscribedInstruments()
/*      */   {
/* 1227 */     return new HashSet(this.instruments);
/*      */   }
/*      */   
/*      */   public synchronized void addNewsFilter(INewsFilter newsFilter)
/*      */   {
/* 1232 */     if ((this.transportClient != null) && (this.transportClient.isOnline())) {
/* 1233 */       for (INewsFilter.NewsSource source : newsFilter.getNewsSources()) {
/* 1234 */         this.newsFilters.put(source, newsFilter);
/*      */       }
/*      */       
/* 1237 */       NewsSubscribeRequest newsSubscribeRequest = new NewsSubscribeRequest();
/*      */       
/* 1239 */       newsSubscribeRequest.setRequestType(SubscribeRequestType.SUBSCRIBE);
/*      */       
/* 1241 */       Set<NewsSource> sources = TransportHelper.toTransportSources(newsFilter.getNewsSources());
/* 1242 */       newsSubscribeRequest.setSources(sources);
/* 1243 */       if ((sources != null) && (!sources.isEmpty())) {
/* 1244 */         newsSubscribeRequest.setSource((NewsSource)sources.iterator().next());
/*      */       }
/*      */       
/* 1247 */       newsSubscribeRequest.setHot(newsFilter.isOnlyHot());
/* 1248 */       newsSubscribeRequest.setGeoRegions(EnumConverter.convert(newsFilter.getCountries(), GeoRegion.class));
/* 1249 */       newsSubscribeRequest.setMarketSectors(EnumConverter.convert(newsFilter.getMarketSectors(), MarketSector.class));
/* 1250 */       newsSubscribeRequest.setIndicies(EnumConverter.convert(newsFilter.getStockIndicies(), StockIndex.class));
/* 1251 */       newsSubscribeRequest.setCurrencies(EnumConverter.convertByName(newsFilter.getCurrencies()));
/*      */       
/* 1253 */       newsSubscribeRequest.setEventCategories(EnumConverter.convert(newsFilter.getEventCategories(), EventCategory.class));
/* 1254 */       newsSubscribeRequest.setKeywords(newsFilter.getKeywords());
/*      */       
/* 1256 */       newsSubscribeRequest.setFrom(newsFilter.getFrom() == null ? Long.MIN_VALUE : newsFilter.getFrom().getTime());
/* 1257 */       newsSubscribeRequest.setTo(newsFilter.getTo() == null ? Long.MIN_VALUE : newsFilter.getTo().getTime());
/*      */       
/* 1259 */       newsSubscribeRequest.setCalendarType((CalendarType)EnumConverter.convert(newsFilter.getType(), CalendarType.class));
/*      */       
/* 1261 */       LOGGER.debug("Subscribing : " + newsSubscribeRequest);
/*      */       
/* 1263 */       this.transportClient.controlRequest(newsSubscribeRequest);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void setOut(PrintStream out)
/*      */   {
/* 1269 */     this.out = out;
/* 1270 */     NotificationUtilsProvider.setNotificationUtils(new PrintStreamNotificationUtils(out, this.err));
/*      */   }
/*      */   
/*      */   public synchronized void setErr(PrintStream err)
/*      */   {
/* 1275 */     this.err = err;
/* 1276 */     NotificationUtilsProvider.setNotificationUtils(new PrintStreamNotificationUtils(this.out, err));
/*      */   }
/*      */   
/*      */   public void setCacheDirectory(File cacheDirectory)
/*      */   {
/* 1281 */     if (!cacheDirectory.exists()) {
/* 1282 */       LOGGER.warn("Cache directory [" + cacheDirectory + "] doesn't exist, trying to create");
/* 1283 */       if (!cacheDirectory.mkdirs()) {
/* 1284 */         LOGGER.error("Cannot create cache directory [" + cacheDirectory + "], default cache directory will be used");
/* 1285 */         return;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 1290 */         com.dukascopy.charts.data.datacache.CacheManager.createVersionFile(cacheDirectory);
/*      */       } catch (DataCacheException e) {
/* 1292 */         LOGGER.error("Cannot create cache directory [" + cacheDirectory + "], default cache directory will be used. Reason [" + e.getLocalizedMessage() + "]", e);
/* 1293 */         return;
/*      */       }
/*      */     }
/*      */     
/* 1297 */     FilePathManager.getInstance().setCacheFolderPath(cacheDirectory.getAbsolutePath());
/*      */   }
/*      */   
/*      */   public void compileStrategy(String srcJavaFile, boolean obfuscate)
/*      */   {
/* 1302 */     JFXCompiler.getInstance().compile(new File(srcJavaFile), this.console, obfuscate);
/*      */   }
/*      */   
/*      */   public File packPluginToJfx(File file)
/*      */   {
/* 1307 */     return packToJfx(file);
/*      */   }
/*      */   
/*      */   public File packToJfx(File file)
/*      */   {
/*      */     try {
/* 1313 */       return JFXCompiler.getInstance().packJarToJfx(file);
/*      */     } catch (Exception e) {
/* 1315 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/* 1317 */     return null;
/*      */   }
/*      */   
/*      */   public String getVersion() {
/* 1321 */     return this.version;
/*      */   }
/*      */   
/*      */   public IChart openChart(IFeedDescriptor feedDescriptor)
/*      */   {
/* 1326 */     return this.clientChartsController.openChart(feedDescriptor);
/*      */   }
/*      */   
/*      */   public void closeChart(IChart chart)
/*      */   {
/* 1331 */     this.clientChartsController.closeChart(chart);
/*      */   }
/*      */   
/*      */   public IClientGUI getClientGUI(IChart chart)
/*      */   {
/* 1336 */     return this.clientChartsController.getClientGUI(chart);
/*      */   }
/*      */   
/*      */   private static class DefaultStrategyExceptionHandler
/*      */     implements IStrategyExceptionHandler
/*      */   {
/* 1342 */     private static final Logger LOGGER = LoggerFactory.getLogger(DefaultStrategyExceptionHandler.class);
/*      */     private JForexTaskManager<?, ?, ?> taskManager;
/*      */     
/*      */     public void setTaskManager(JForexTaskManager<?, ?, ?> taskManager) {
/* 1346 */       this.taskManager = taskManager;
/*      */     }
/*      */     
/*      */     public void onException(long strategyId, IStrategyExceptionHandler.Source source, Throwable t)
/*      */     {
/* 1351 */       LOGGER.error("Exception thrown while running " + source + " method: " + t.getMessage(), t);
/* 1352 */       this.taskManager.stopStrategy();
/*      */     }
/*      */   }
/*      */   
/*      */   private class LotAmountProvider
/*      */     extends DefaultLotAmountProvider implements ILotAmountProvider
/*      */   {
/* 1359 */     private final BigDecimal MIN_CONTEST_TRADABLE_AMOUNT = BigDecimal.valueOf(0.1D);
/* 1360 */     private final BigDecimal MAX_CONTEST_TRADABLE_AMOUNT = BigDecimal.valueOf(5L);
/*      */     
/*      */ 
/* 1363 */     private boolean contest = false;
/*      */     
/*      */     public LotAmountProvider() {
/* 1366 */       this.contest = DCClientImpl.this.getBooleanProperty("ANALITIC_CONTEST");
/*      */     }
/*      */     
/*      */     public BigDecimal getMinTradableAmount(Instrument instrument)
/*      */     {
/* 1371 */       BigDecimal result = super.getMinTradableAmount(instrument);
/* 1372 */       if ((instrument != null) && (InstrumentUtils.isForex(instrument)) && (this.contest)) {
/* 1373 */         result = this.MIN_CONTEST_TRADABLE_AMOUNT;
/*      */       }
/* 1375 */       return result;
/*      */     }
/*      */     
/*      */     public BigDecimal getMaxTradableAmount(Instrument instrument)
/*      */     {
/* 1380 */       BigDecimal result = super.getMaxTradableAmount(instrument);
/* 1381 */       if ((instrument != null) && (InstrumentUtils.isForex(instrument)) && (this.contest)) {
/* 1382 */         result = this.MAX_CONTEST_TRADABLE_AMOUNT;
/*      */       }
/* 1384 */       return result;
/*      */     }
/*      */   }
/*      */   
/*      */   private class ClientGUIListener implements IClientGUIListener
/*      */   {
/* 1390 */     private volatile List<IClientGUIListener> listeners = Collections.synchronizedList(new ArrayList());
/*      */     
/*      */     private ClientGUIListener() {}
/*      */     
/* 1394 */     public void onOpenChart(IClientGUI clientGUI) { for (IClientGUIListener clientGUIListener : this.listeners) {
/* 1395 */         clientGUIListener.onOpenChart(clientGUI);
/*      */       }
/*      */     }
/*      */     
/*      */     public void onCloseChart(IChart chart)
/*      */     {
/* 1401 */       for (IClientGUIListener clientGUIListener : this.listeners) {
/* 1402 */         clientGUIListener.onCloseChart(chart);
/*      */       }
/*      */     }
/*      */     
/*      */     public void addListener(IClientGUIListener listener) {
/* 1407 */       this.listeners.add(listener);
/*      */     }
/*      */     
/*      */     public void removeListener(IClientGUIListener listener) {
/* 1411 */       this.listeners.remove(listener);
/*      */     }
/*      */   }
/*      */   
/*      */   private class DefaultSystemListener implements ISystemListener {
/*      */     private DefaultSystemListener() {}
/*      */     
/*      */     public void onStart(long processId) {
/* 1419 */       DCClientImpl.LOGGER.info("Strategy started: " + processId);
/*      */     }
/*      */     
/*      */     public void onStop(long processId)
/*      */     {
/* 1424 */       DCClientImpl.LOGGER.info("Strategy stopped: " + processId);
/*      */     }
/*      */     
/*      */     public void onConnect()
/*      */     {
/* 1429 */       DCClientImpl.LOGGER.info("Connected");
/*      */     }
/*      */     
/*      */     public void onDisconnect()
/*      */     {
/* 1434 */       DCClientImpl.LOGGER.warn("Disconnected");
/*      */     }
/*      */   }
/*      */   
/*      */   public Set<Instrument> getAvailableInstruments()
/*      */   {
/* 1440 */     Set<String> setAsString = (Set)this.serverProperties.get("instruments");
/* 1441 */     return Instrument.fromStringSet(setAsString);
/*      */   }
/*      */   
/*      */   public UUID runPlugin(Plugin plugin, IStrategyExceptionHandler exceptionHandler)
/*      */     throws IllegalStateException, NullPointerException
/*      */   {
/* 1447 */     return runPlugin(plugin, exceptionHandler, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public UUID runPlugin(Plugin plugin, IStrategyExceptionHandler exceptionHandler, PluginGuiListener pluginGuiListener)
/*      */     throws IllegalStateException, NullPointerException
/*      */   {
/* 1455 */     long id = startJFRunnable(plugin, com.dukascopy.api.impl.connect.plugin.PluginTaskManager.Builder.newSdkInstance(pluginGuiListener), null, exceptionHandler, JForexTaskManager.Environment.LOCAL_EMBEDDED, true, this.accountName);
/*      */     
/* 1457 */     UUID uid = UUID.randomUUID();
/* 1458 */     this.pluginIdMap.put(uid, Long.valueOf(id));
/* 1459 */     return uid;
/*      */   }
/*      */   
/*      */   public void stopPlugin(UUID processId)
/*      */   {
/* 1464 */     Long id = (Long)this.pluginIdMap.get(processId);
/* 1465 */     if (id == null) {
/* 1466 */       LOGGER.warn("No plugin running with id " + processId);
/* 1467 */       return;
/*      */     }
/* 1469 */     stopStrategy(id.longValue());
/* 1470 */     this.pluginIdMap.remove(processId);
/*      */   }
/*      */   
/*      */   public IPreferences getPreferences()
/*      */   {
/* 1475 */     return this.ddsChartsController.getPreferences();
/*      */   }
/*      */   
/*      */   public void setPreferences(IPreferences preferences)
/*      */   {
/* 1480 */     this.ddsChartsController.setPreferences(preferences);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void initServerProperties(Properties properties)
/*      */   {
/* 1487 */     if (properties != null) {
/* 1488 */       this.serverProperties.putAll(properties);
/* 1489 */       PlatformSessionClientBean.getInstance().setStorageServerUrl(properties.getProperty("sss.server.url"));
/*      */       
/* 1491 */       String typesList = this.serverProperties.getProperty("userTypes");
/* 1492 */       if (typesList == null) {
/* 1493 */         LOGGER.warn("Types list was not found");
/* 1494 */         return;
/*      */       }
/*      */       
/* 1497 */       List<String> accountTypeList = splitUserTypes(typesList);
/* 1498 */       boolean isContest = accountTypeList.contains("ANALITIC_CONTEST");
/* 1499 */       this.serverProperties.put("ANALITIC_CONTEST", Boolean.valueOf(isContest));
/*      */       
/* 1501 */       Set<Integer> typesSet = (Set)this.serverProperties.get("additionalUserTypes");
/* 1502 */       if (typesSet == null) {
/* 1503 */         LOGGER.warn("Layout Types list was not found");
/* 1504 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1508 */       boolean isPlaceBidOfferHidden = typesSet.contains(Integer.valueOf(LayoutType.PLACE_BID_OFFER_HIDDEN.getId()));
/* 1509 */       this.serverProperties.put(LayoutType.PLACE_BID_OFFER_HIDDEN.toString(), Boolean.valueOf(isPlaceBidOfferHidden));
/*      */       
/* 1511 */       boolean isDelivirableXau = typesSet.contains(Integer.valueOf(LayoutType.DELIVERABLE_XAU.getId()));
/* 1512 */       this.serverProperties.put(LayoutType.DELIVERABLE_XAU.toString(), Boolean.valueOf(isDelivirableXau));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static List<String> splitUserTypes(String input)
/*      */   {
/* 1519 */     Pattern p = Pattern.compile("[,\\s]+");
/* 1520 */     String[] result = p.split(input);
/*      */     
/* 1522 */     List<String> accountTypes = new ArrayList();
/*      */     
/* 1524 */     Collections.addAll(accountTypes, result);
/*      */     
/* 1526 */     return accountTypes;
/*      */   }
/*      */   
/*      */   private boolean getBooleanProperty(String property)
/*      */   {
/* 1531 */     boolean value = false;
/* 1532 */     if (this.serverProperties.get(property) != null) {
/* 1533 */       value = ((Boolean)this.serverProperties.get(property)).booleanValue();
/*      */     }
/* 1535 */     return value;
/*      */   }
/*      */   
/*      */   public IRemoteStrategyManager getRemoteStrategyManager()
/*      */   {
/* 1540 */     return this.remoteManager;
/*      */   }
/*      */   
/* 1543 */   private final Set<IJFRunnablesListener> runnablesListeners = new HashSet();
/*      */   
/*      */   public void addJFRunnablesListener(IJFRunnablesListener listener) {
/* 1546 */     synchronized (this.runnablesListeners) {
/* 1547 */       this.runnablesListeners.add(listener);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeJFRunnablesListener(IJFRunnablesListener listener) {
/* 1552 */     synchronized (this.runnablesListeners) {
/* 1553 */       this.runnablesListeners.remove(listener);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\DCClientImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */