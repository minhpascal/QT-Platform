/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.function.BoolFunction;
/*    */ 
/*    */ 
/*    */ public class Or
/*    */   extends Dyadic<BoolFunction>
/*    */ {
/*    */   public Or(OObject expression1, OObject expression2)
/*    */   {
/* 12 */     super(new com.dukascopy.calculator.function.Or(), expression1, expression2);
/*    */   }
/*    */   
/*    */   public Product negate() {
/* 16 */     Product p = new Product(this, false);
/* 17 */     return p.negate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Or.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */