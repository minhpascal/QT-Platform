/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AngleType
/*    */ {
/*  8 */   DEGREES,  RADIANS;
/*    */   
/*    */ 
/*    */   private AngleType() {}
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 16 */     switch (this) {
/*    */     case DEGREES: 
/* 18 */       return "Degrees";
/*    */     case RADIANS: 
/* 20 */       return "Radians";
/*    */     }
/* 22 */     throw new AssertionError("Unknown AngleType");
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\AngleType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */