/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class On
/*    */   extends PObject
/*    */ {
/*    */   public String[] name_array()
/*    */   {
/* 12 */     return fname;
/*    */   }
/*    */   
/* 15 */   private static final String[] fname = { "A", "C" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\On.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */