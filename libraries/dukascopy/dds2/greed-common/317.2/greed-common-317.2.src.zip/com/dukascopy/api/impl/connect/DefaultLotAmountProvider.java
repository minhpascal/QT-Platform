/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.dds2.greed.util.InstrumentUtils;
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLotAmountProvider
/*    */   implements ILotAmountProvider
/*    */ {
/* 21 */   public static final BigDecimal MIN_XAU_AMOUNT = BigDecimal.valueOf(1.0E-6D);
/* 22 */   public static final BigDecimal MIN_XAG_AMOUNT = BigDecimal.valueOf(5.0E-5D);
/* 23 */   public static final BigDecimal MIN_TRADABLE_AMOUNT = BigDecimal.valueOf(0.001D);
/* 24 */   public static final BigDecimal MIN_CFD_AMOUNT = BigDecimal.valueOf(1.0E-6D);
/*    */   
/* 26 */   public static final BigDecimal MAX_TRADABLE_AMOUNT = BigDecimal.valueOf(500L);
/*    */   
/*    */ 
/*    */ 
/*    */   public BigDecimal getMinTradableAmount(Instrument instrument)
/*    */   {
/* 32 */     BigDecimal result = MIN_TRADABLE_AMOUNT;
/* 33 */     if (instrument != null) {
/* 34 */       if (Instrument.XAUUSD.equals(instrument)) {
/* 35 */         result = MIN_XAU_AMOUNT;
/* 36 */       } else if (Instrument.XAGUSD.equals(instrument)) {
/* 37 */         result = MIN_XAG_AMOUNT;
/* 38 */       } else if (InstrumentUtils.isCfd(instrument)) {
/* 39 */         result = MIN_CFD_AMOUNT;
/*    */       }
/*    */     }
/* 42 */     return result;
/*    */   }
/*    */   
/*    */   public BigDecimal getMaxTradableAmount(Instrument instrument)
/*    */   {
/* 47 */     return MAX_TRADABLE_AMOUNT;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\DefaultLotAmountProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */