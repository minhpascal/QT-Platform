/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IStrategy;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrategyWrapper
/*    */   extends JFRunnableWrapper<IStrategy>
/*    */ {
/*    */   public String getName()
/*    */   {
/* 13 */     if (this.isNewUnsaved) {
/* 14 */       return "*Strategy" + this.newFileIndex;
/*    */     }
/* 16 */     if (this.srcFile != null) {
/* 17 */       if (this.isModified) {
/* 18 */         return "*" + this.srcFile.getName();
/*    */       }
/* 20 */       return this.srcFile.getName();
/*    */     }
/*    */     
/* 23 */     if (this.binFile != null) {
/* 24 */       return this.binFile.getName();
/*    */     }
/* 26 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\StrategyWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */