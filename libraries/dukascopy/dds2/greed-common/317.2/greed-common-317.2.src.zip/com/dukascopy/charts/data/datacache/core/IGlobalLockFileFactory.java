package com.dukascopy.charts.data.datacache.core;

import java.io.File;

public abstract interface IGlobalLockFileFactory
{
  public abstract File getGlobalLockFile(File paramFile);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\IGlobalLockFileFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */