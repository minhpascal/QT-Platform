/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.DataType;
/*     */ import com.dukascopy.api.IAccount;
/*     */ import com.dukascopy.api.IConsole;
/*     */ import com.dukascopy.api.IDataService;
/*     */ import com.dukascopy.api.IHistory;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.feed.FeedDescriptor;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.api.impl.connect.JForexDataService;
/*     */ import com.dukascopy.api.indicators.IIndicatorChartPanel;
/*     */ import com.dukascopy.api.indicators.IIndicatorContext;
/*     */ import com.dukascopy.api.indicators.IIndicatorsProvider;
/*     */ import com.dukascopy.charts.math.indicators.IndicatorsProvider;
/*     */ import com.dukascopy.dds2.greed.agent.indicator.AccountProvider;
/*     */ import com.dukascopy.dds2.greed.util.FilePathManager;
/*     */ import com.dukascopy.dds2.greed.util.IFilePathManager;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.IndicatorHelper;
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IndicatorContext
/*     */   implements IIndicatorContext
/*     */ {
/*     */   private NotificationConsoleImpl console;
/*     */   private History history;
/*     */   private IFeedDescriptor feedDescriptor;
/*     */   private JForexDataService dataService;
/*     */   private IIndicatorChartPanel indicatorChartPanel;
/*     */   private boolean live;
/*     */   private File filesDir;
/*     */   
/*     */   public IndicatorContext(INotificationUtils notificationUtils, History history, boolean live)
/*     */   {
/*  41 */     this.history = history;
/*  42 */     this.console = new NotificationConsoleImpl(notificationUtils);
/*  43 */     this.live = live;
/*     */     
/*  45 */     this.filesDir = FilePathManager.getInstance().getFilesForStrategiesDir();
/*     */   }
/*     */   
/*     */   public IAccount getAccount()
/*     */   {
/*  50 */     return AccountProvider.getAccount();
/*     */   }
/*     */   
/*     */   public IHistory getHistory()
/*     */   {
/*  55 */     return this.history;
/*     */   }
/*     */   
/*     */   public IConsole getConsole()
/*     */   {
/*  60 */     return this.console;
/*     */   }
/*     */   
/*     */   public IIndicatorsProvider getIndicatorsProvider()
/*     */   {
/*  65 */     return IndicatorsProvider.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void setChartInfo(Instrument instrument, Period period, OfferSide offerSide)
/*     */   {
/*  76 */     this.feedDescriptor = new FeedDescriptor();
/*     */     
/*  78 */     if (period.isTickBasedPeriod()) {
/*  79 */       this.feedDescriptor.setDataType(DataType.TICKS);
/*     */     }
/*     */     else {
/*  82 */       this.feedDescriptor.setDataType(DataType.TIME_PERIOD_AGGREGATION);
/*     */     }
/*     */     
/*  85 */     this.feedDescriptor.setInstrument(instrument);
/*  86 */     this.feedDescriptor.setPeriod(period);
/*  87 */     this.feedDescriptor.setOfferSide(offerSide);
/*     */   }
/*     */   
/*     */   public Instrument getInstrument()
/*     */   {
/*  92 */     Instrument result = getFeedDescriptor() == null ? null : getFeedDescriptor().getInstrument();
/*     */     
/*     */ 
/*  95 */     return result;
/*     */   }
/*     */   
/*     */   public Period getPeriod() {
/*  99 */     Period result = getFeedDescriptor() == null ? null : getFeedDescriptor().getPeriod();
/*     */     
/*     */ 
/* 102 */     return result;
/*     */   }
/*     */   
/*     */   public OfferSide getOfferSide() {
/* 106 */     OfferSide result = getFeedDescriptor() == null ? null : getFeedDescriptor().getOfferSide();
/*     */     
/*     */ 
/* 109 */     return result;
/*     */   }
/*     */   
/*     */   public IFeedDescriptor getFeedDescriptor()
/*     */   {
/* 114 */     return this.feedDescriptor;
/*     */   }
/*     */   
/*     */   public void setFeedDescriptor(IFeedDescriptor feedDescriptor) {
/* 118 */     this.feedDescriptor = feedDescriptor;
/*     */   }
/*     */   
/*     */   public void resetFeedDescriptor() {
/* 122 */     if (this.feedDescriptor == null) {
/* 123 */       return;
/*     */     }
/* 125 */     this.feedDescriptor.setInstrument(null);
/* 126 */     this.feedDescriptor.setPeriod(null);
/* 127 */     this.feedDescriptor.setOfferSide(null);
/* 128 */     this.feedDescriptor.setFilter(null);
/*     */     
/* 130 */     this.feedDescriptor.setPriceRange(null);
/* 131 */     this.feedDescriptor.setReversalAmount(null);
/* 132 */     this.feedDescriptor.setTickBarSize(null);
/*     */     
/* 134 */     this.feedDescriptor.setDataType(DataType.TIME_PERIOD_AGGREGATION);
/*     */   }
/*     */   
/*     */   public void setHistory(History history) {
/* 138 */     this.history = history;
/*     */   }
/*     */   
/*     */   public void reinitConsole(INotificationUtils notificationUtils) {
/* 142 */     this.console.reinit(notificationUtils);
/*     */   }
/*     */   
/*     */   public IDataService getDataService()
/*     */   {
/* 147 */     if (this.dataService == null) {
/* 148 */       this.dataService = IndicatorHelper.createDataService(null);
/*     */     }
/*     */     
/* 151 */     return this.dataService;
/*     */   }
/*     */   
/*     */   public void setIndicatorChartPanel(IIndicatorChartPanel indicatorChartPanel) {
/* 155 */     this.indicatorChartPanel = indicatorChartPanel;
/*     */   }
/*     */   
/*     */   public IIndicatorChartPanel getIndicatorChartPanel()
/*     */   {
/* 160 */     return this.indicatorChartPanel;
/*     */   }
/*     */   
/*     */   public boolean isLive()
/*     */   {
/* 165 */     return this.live;
/*     */   }
/*     */   
/*     */   public File getFilesDir()
/*     */   {
/* 170 */     return this.filesDir;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\IndicatorContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */