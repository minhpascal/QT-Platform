package com.dukascopy.api.impl.talib;

public class IntegerRangeHolder
  extends Holder
{
  public String paramName;
  public int defaultValue;
  public int min;
  public int max;
  public int suggested_start;
  public int suggested_end;
  public int suggested_increment;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\talib\IntegerRangeHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */