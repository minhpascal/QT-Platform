/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IConnectionStatusMessage;
/*    */ import com.dukascopy.api.IMessage.Type;
/*    */ 
/*    */ class ConnectionStatusMessageImpl
/*    */   extends PlatformMessageImpl
/*    */   implements IConnectionStatusMessage
/*    */ {
/*    */   private final boolean connected;
/*    */   
/*    */   public ConnectionStatusMessageImpl(boolean connected, long creationTime)
/*    */   {
/* 14 */     super(null, null, IMessage.Type.CONNECTION_STATUS, creationTime);
/* 15 */     this.connected = connected;
/*    */   }
/*    */   
/*    */   public boolean isConnected()
/*    */   {
/* 20 */     return this.connected;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 25 */     return "MessageType " + getType() + " Connected : " + this.connected;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ConnectionStatusMessageImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */