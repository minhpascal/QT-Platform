package com.dukascopy.charts.data.datacache.business.listener;

import com.dukascopy.charts.data.datacache.TickData;

public abstract interface ITickDataListener
{
  public abstract void onTick(TickData paramTickData);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\business\listener\ITickDataListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */