/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IContext;
/*    */ import com.dukascopy.api.IDownloadableStrategies;
/*    */ import com.dukascopy.api.IDownloadableStrategy;
/*    */ import com.dukascopy.api.IDownloadableStrategy.ComponentType;
/*    */ import com.dukascopy.api.IEngine.StrategyMode;
/*    */ import com.dukascopy.api.JFException;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class DownloadableStrategies
/*    */   implements IDownloadableStrategies
/*    */ {
/*    */   public IDownloadableStrategy init(String id, String name, IContext context, IDownloadableStrategy.ComponentType type, IEngine.StrategyMode mode, Map<String, Object> configurables)
/*    */     throws JFException
/*    */   {
/* 17 */     DownloadableStrategy strategy = new DownloadableStrategy(id, name, context, type, mode, configurables);
/* 18 */     strategy.start();
/* 19 */     return strategy;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\DownloadableStrategies.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */