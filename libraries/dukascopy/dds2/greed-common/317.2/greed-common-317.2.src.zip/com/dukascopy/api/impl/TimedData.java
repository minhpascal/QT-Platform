package com.dukascopy.api.impl;

import com.dukascopy.api.ITimedData;

public abstract interface TimedData
  extends ITimedData
{
  public abstract void setTime(long paramLong);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\TimedData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */