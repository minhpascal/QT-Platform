/*    */ package com.dukascopy.charts.data.datacache.pamanager.creators;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*    */ import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.nisonrenko.RenkoCreator;
/*    */ import com.dukascopy.charts.data.datacache.nisonrenko.RenkoData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheRenkoCreator
/*    */   extends RenkoCreator
/*    */ {
/*    */   private IRenkoLiveFeedListener cacheFeedListener;
/*    */   
/*    */   public CacheRenkoCreator(Instrument instrument, OfferSide offerSide, JForexPeriod jfPeriod, IRenkoLiveFeedListener cacheFeedListener)
/*    */   {
/* 29 */     super(instrument, offerSide, jfPeriod, -1, true, false, Period.isInfinity(jfPeriod.getPeriod()));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 39 */     this.cacheFeedListener = cacheFeedListener;
/*    */   }
/*    */   
/*    */   public boolean isAllDesiredDataLoaded()
/*    */   {
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 49 */     return 0;
/*    */   }
/*    */   
/*    */   public void fireRenko(RenkoData renko)
/*    */   {
/* 54 */     this.cacheFeedListener.newPriceData(renko);
/* 55 */     ((RenkoData[])this.result)[getLastElementIndex()] = renko;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void resetResulArray()
/*    */   {
/* 61 */     this.result = new RenkoData[1];
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\creators\CacheRenkoCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */