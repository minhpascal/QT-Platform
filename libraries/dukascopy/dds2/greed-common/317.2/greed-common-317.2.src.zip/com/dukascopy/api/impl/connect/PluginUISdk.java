/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.plugin.IPluginUserInterface;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginUISdk
/*    */   implements IPluginUserInterface
/*    */ {
/*    */   public JPanel getBottomTab(String key)
/*    */   {
/* 19 */     return new JPanel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void removeBottomTab(String key) {}
/*    */   
/*    */ 
/*    */   public JPanel getMainTab(String key)
/*    */   {
/* 29 */     return new JPanel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void removeMainTab(String key) {}
/*    */   
/*    */ 
/*    */   public JFrame getMainFrame()
/*    */   {
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public JMenu addMenu(String name)
/*    */   {
/* 44 */     return new JMenu(name);
/*    */   }
/*    */   
/*    */   public void removeMenu(JMenu menu) {}
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PluginUISdk.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */