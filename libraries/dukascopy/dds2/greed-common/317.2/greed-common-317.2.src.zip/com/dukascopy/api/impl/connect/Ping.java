/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ping
/*     */ {
/*  63 */   private static final Logger LOGGER = LoggerFactory.getLogger(Ping.class);
/*     */   
/*     */   private static final int DAYTIME_PORT = 13;
/*     */   
/*     */   private static final int TIMEOUT = 2000;
/*     */   
/*     */ 
/*     */   private static class Target
/*     */   {
/*     */     private InetSocketAddress address;
/*     */     private SocketChannel channel;
/*     */     private Exception failure;
/*     */     private long connectStart;
/*  76 */     private long connectFinish = Long.MIN_VALUE;
/*  77 */     private boolean shown = false;
/*     */     
/*     */     public Target(String host, int port) {
/*     */       try {
/*  81 */         this.address = new InetSocketAddress(InetAddress.getByName(host), port);
/*     */       } catch (IOException x) {
/*  83 */         this.failure = x;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  88 */     public Target(InetSocketAddress address) { this.address = address; }
/*     */     
/*     */     public void show() {
/*     */       String result;
/*     */       String result;
/*  93 */       if (this.connectFinish != Long.MIN_VALUE) {
/*  94 */         result = Long.toString(this.connectFinish - this.connectStart) + "ms"; } else { String result;
/*  95 */         if (this.failure != null) {
/*  96 */           result = this.failure.toString();
/*     */         } else
/*  98 */           result = "Timed out"; }
/*  99 */       System.out.println(this.address + " : " + result);
/* 100 */       this.shown = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Connector
/*     */     extends Thread
/*     */   {
/*     */     private Selector sel;
/*     */     
/*     */ 
/*     */ 
/* 114 */     private LinkedList<Ping.Target> pending = new LinkedList();
/*     */     
/* 116 */     private volatile boolean shutdown = false;
/*     */     
/*     */     public Connector() throws IOException {
/* 119 */       this.sel = Selector.open();
/* 120 */       setName("Connector");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void add(Ping.Target t)
/*     */     {
/* 127 */       SocketChannel sc = null;
/*     */       try
/*     */       {
/* 130 */         sc = SocketChannel.open();
/* 131 */         sc.configureBlocking(false);
/* 132 */         Ping.LOGGER.debug("Initiating pinging connect to " + Ping.Target.access$000(t));
/* 133 */         sc.connect(Ping.Target.access$000(t));
/*     */         
/*     */ 
/* 136 */         Ping.Target.access$202(t, sc);
/* 137 */         Ping.Target.access$302(t, System.currentTimeMillis());
/*     */         
/*     */ 
/* 140 */         synchronized (this.pending) {
/* 141 */           this.pending.add(t);
/*     */         }
/*     */         
/*     */ 
/* 145 */         this.sel.wakeup();
/*     */       } catch (Exception x) {
/* 147 */         if (sc != null) {
/*     */           try {
/* 149 */             sc.close();
/*     */           }
/*     */           catch (Exception xx) {}
/*     */         }
/*     */         
/* 154 */         Ping.LOGGER.error("Ping to [" + Ping.Target.access$000(t) + "] failed: " + x.getMessage(), x);
/* 155 */         Ping.Target.access$402(t, x);
/* 156 */         synchronized (this) {
/* 157 */           notifyAll();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void processPendingTargets()
/*     */       throws IOException
/*     */     {
/* 165 */       synchronized (this.pending) {
/* 166 */         while (this.pending.size() > 0) {
/* 167 */           Ping.Target t = (Ping.Target)this.pending.removeFirst();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 174 */             Ping.Target.access$200(t).register(this.sel, 8, t);
/*     */           }
/*     */           catch (IOException x)
/*     */           {
/* 178 */             Ping.Target.access$200(t).close();
/* 179 */             Ping.Target.access$402(t, x);
/* 180 */             Ping.LOGGER.error("Ping to [" + Ping.Target.access$000(t) + "] failed: " + x.getMessage(), x);
/* 181 */             synchronized (this) {
/* 182 */               notifyAll();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private void processSelectedKeys()
/*     */       throws IOException
/*     */     {
/* 192 */       for (Iterator i = this.sel.selectedKeys().iterator(); i.hasNext();)
/*     */       {
/*     */ 
/* 195 */         SelectionKey sk = (SelectionKey)i.next();
/* 196 */         i.remove();
/*     */         
/*     */ 
/* 199 */         Ping.Target t = (Ping.Target)sk.attachment();
/* 200 */         SocketChannel sc = (SocketChannel)sk.channel();
/*     */         
/*     */         try
/*     */         {
/* 204 */           if (sc.finishConnect()) {
/* 205 */             sk.cancel();
/* 206 */             Ping.Target.access$502(t, System.currentTimeMillis());
/* 207 */             sc.close();
/* 208 */             Ping.LOGGER.debug("Ping to [" + Ping.Target.access$000(t) + "] resulted in [" + (Ping.Target.access$500(t) - Ping.Target.access$300(t)) + "]ms");
/* 209 */             synchronized (this) {
/* 210 */               notifyAll();
/*     */             }
/*     */           }
/*     */         } catch (IOException x) {
/* 214 */           sc.close();
/* 215 */           Ping.Target.access$402(t, x);
/* 216 */           Ping.LOGGER.error("Ping to [" + Ping.Target.access$000(t) + "] failed: " + x.getMessage(), x);
/* 217 */           synchronized (this) {
/* 218 */             notifyAll();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void shutdown()
/*     */     {
/* 227 */       this.shutdown = true;
/* 228 */       this.sel.wakeup();
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/*     */         for (;;) {
/* 236 */           int n = this.sel.select();
/* 237 */           if (n > 0)
/* 238 */             processSelectedKeys();
/* 239 */           processPendingTargets();
/* 240 */           if (this.shutdown) {
/* 241 */             this.sel.close();
/* 242 */             return;
/*     */           }
/*     */         }
/* 245 */       } catch (IOException x) { x.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static Map<String, Long[]> ping(Map<String, InetSocketAddress> addresses)
/*     */     throws IOException, InterruptedException
/*     */   {
/* 253 */     Connector connector = new Connector();
/* 254 */     connector.start();
/*     */     
/*     */ 
/* 257 */     Map<String, Target[]> targets = new LinkedHashMap();
/* 258 */     for (Map.Entry<String, InetSocketAddress> entry : addresses.entrySet()) {
/* 259 */       InetSocketAddress address = (InetSocketAddress)entry.getValue();
/* 260 */       Target[] triple = { new Target(address), new Target(address), new Target(address) };
/* 261 */       connector.add(triple[0]);
/* 262 */       connector.add(triple[1]);
/* 263 */       connector.add(triple[2]);
/* 264 */       targets.put(entry.getKey(), triple);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 269 */     synchronized (connector) {
/* 270 */       boolean allFinished = false;
/* 271 */       long timeoutStart = System.currentTimeMillis();
/* 272 */       while ((!allFinished) && (timeoutStart + 2000L > System.currentTimeMillis())) {
/* 273 */         allFinished = true;
/* 274 */         for (Target[] triple : targets.values()) {
/* 275 */           for (Target target : triple) {
/* 276 */             if ((target.failure == null) && (target.connectFinish == Long.MIN_VALUE)) {
/* 277 */               allFinished = false;
/*     */             }
/*     */           }
/*     */         }
/* 281 */         if (!allFinished) {
/* 282 */           long sleep = timeoutStart + 2000L - System.currentTimeMillis();
/* 283 */           if (sleep > 0L) {
/* 284 */             connector.wait(sleep);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 289 */     connector.shutdown();
/* 290 */     connector.join();
/*     */     
/* 292 */     Map<String, Long[]> result = new LinkedHashMap();
/* 293 */     for (Map.Entry<String, Target[]> entry : targets.entrySet()) {
/* 294 */       Target[] triple = (Target[])entry.getValue();
/* 295 */       Long[] addressResult = new Long[triple.length];
/* 296 */       for (int i = 0; i < triple.length; i++) {
/* 297 */         Target target = triple[i];
/* 298 */         if (target.failure != null) {
/* 299 */           addressResult[i] = Long.valueOf(Long.MIN_VALUE);
/* 300 */         } else if (target.connectFinish != Long.MIN_VALUE) {
/* 301 */           addressResult[i] = Long.valueOf(target.connectFinish - target.connectStart);
/*     */         } else {
/* 303 */           LOGGER.debug("Ping to [" + target.address + "] timed out");
/* 304 */           addressResult[i] = Long.valueOf(Long.MAX_VALUE);
/*     */         }
/*     */       }
/* 307 */       result.put(entry.getKey(), addressResult);
/*     */     }
/*     */     
/* 310 */     return result;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws InterruptedException, IOException
/*     */   {
/* 315 */     if (args.length < 1) {
/* 316 */       System.err.println("Usage: java Ping [port] host...");
/* 317 */       return;
/*     */     }
/* 319 */     int firstArg = 0;
/*     */     
/*     */ 
/*     */ 
/* 323 */     int port = 13;
/* 324 */     if (Pattern.matches("[0-9]+", args[0])) {
/* 325 */       port = Integer.parseInt(args[0]);
/* 326 */       firstArg = 1;
/*     */     }
/*     */     
/*     */ 
/* 330 */     Connector connector = new Connector();
/* 331 */     connector.start();
/*     */     
/*     */ 
/* 334 */     LinkedList<Target> targets = new LinkedList();
/* 335 */     for (int i = firstArg; i < args.length; i++) {
/* 336 */       Target t = new Target(args[i], port);
/* 337 */       targets.add(t);
/* 338 */       connector.add(t);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 343 */     synchronized (connector) {
/* 344 */       boolean allFinished = false;
/* 345 */       long timeoutStart = System.currentTimeMillis();
/* 346 */       while ((!allFinished) && (timeoutStart + 2000L > System.currentTimeMillis())) {
/* 347 */         allFinished = true;
/* 348 */         for (Target target : targets) {
/* 349 */           if ((target.failure == null) && (target.connectFinish == Long.MIN_VALUE)) {
/* 350 */             allFinished = false;
/*     */           }
/*     */         }
/* 353 */         if (!allFinished) {
/* 354 */           long sleep = timeoutStart + 2000L - System.currentTimeMillis();
/* 355 */           if (sleep > 0L) {
/* 356 */             connector.wait();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 361 */     connector.shutdown();
/* 362 */     connector.join();
/*     */     
/*     */ 
/* 365 */     for (Target t : targets) {
/* 366 */       if (!t.shown) {
/* 367 */         t.show();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\Ping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */