/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadCloseTicksAction
/*    */   extends AbstractLoadCustomTicksFromCandlesAction
/*    */ {
/*    */   private final TickFeedListener feedListener;
/*    */   private final double spreadInPipsAsk;
/*    */   private final double spreadInPipsBid;
/*    */   
/*    */   public LoadCloseTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, OfferSide offerSide, long from, long to, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 36 */     super(feedDataProvider, instrument, period, offerSide, from, to, loadingProgressListener);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 45 */     this.feedListener = feedListener;
/*    */     
/* 47 */     this.spreadInPipsAsk = ((OfferSide.ASK.equals(offerSide) ? 0.0D : 2.0D) * instrument.getPipValue());
/* 48 */     this.spreadInPipsBid = ((OfferSide.ASK.equals(offerSide) ? -2.0D : 0.0D) * instrument.getPipValue());
/*    */   }
/*    */   
/*    */   protected void candleReceived(long time, double open, double close, double low, double high, double vol)
/*    */   {
/* 53 */     long tickTime = DataCacheUtils.getNextCandleStartFast(this.period, time) - 1L;
/*    */     
/* 55 */     if ((this.from <= tickTime) && (tickTime <= this.to)) {
/* 56 */       double ask = StratUtils.round(close + this.spreadInPipsAsk, 5);
/* 57 */       double bid = StratUtils.round(close + this.spreadInPipsBid, 5);
/*    */       
/* 59 */       this.feedListener.newTick(this.instrument, tickTime, ask, bid, vol, vol);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadCloseTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */