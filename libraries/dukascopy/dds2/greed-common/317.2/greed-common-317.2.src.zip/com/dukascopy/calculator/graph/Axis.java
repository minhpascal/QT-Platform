/*    */ package com.dukascopy.calculator.graph;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ 
/*    */ public abstract class Axis extends Element { protected boolean showMajorUnit;
/*    */   protected boolean showMinorUnit;
/*    */   protected int majorUnitTick;
/*    */   protected int minorUnitTick;
/*    */   java.text.NumberFormat numberFormat;
/*    */   
/* 11 */   public Axis() { this.numberFormat = java.text.NumberFormat.getNumberInstance();
/* 12 */     if ((this.numberFormat instanceof DecimalFormat)) {
/* 13 */       DecimalFormat df = (DecimalFormat)this.numberFormat;
/* 14 */       df.setNegativePrefix("−");
/*    */     }
/* 16 */     this.majorUnitTick = 5;
/* 17 */     this.minorUnitTick = 2;
/* 18 */     setShowMajorUnit(true);
/* 19 */     setShowMinorUnit(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setShowMajorUnit(boolean value)
/*    */   {
/* 28 */     this.showMajorUnit = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setShowMinorUnit(boolean value)
/*    */   {
/* 36 */     this.showMinorUnit = value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean getShowMajorUnit()
/*    */   {
/* 43 */     return this.showMajorUnit;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean getShowMinorUnit()
/*    */   {
/* 50 */     return this.showMinorUnit;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getMajorUnitTickLength()
/*    */   {
/* 58 */     return this.majorUnitTick;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getMinorUnitTickLength()
/*    */   {
/* 65 */     return this.minorUnitTick;
/*    */   }
/*    */   
/*    */ 
/*    */   public String convertDouble(double d)
/*    */   {
/* 71 */     return this.numberFormat.format(d);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\graph\Axis.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */