/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IConsole;
/*    */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*    */ import com.dukascopy.dds2.greed.util.NotificationLevel;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class NotificationConsoleImpl
/*    */   implements IConsole
/*    */ {
/* 11 */   protected PrintStream errorStream = null;
/* 12 */   protected PrintStream outputStream = null;
/* 13 */   protected PrintStream warnStream = null;
/* 14 */   protected PrintStream infoclientStream = null;
/* 15 */   protected PrintStream notifclientStream = null;
/*    */   
/*    */   public NotificationConsoleImpl(INotificationUtils notificationUtils) {
/* 18 */     reinit(notificationUtils);
/*    */   }
/*    */   
/*    */   public void reinit(INotificationUtils notificationUtils) {
/* 22 */     this.errorStream = new PrintStream(new NotificationOutputStream(NotificationLevel.ERROR, notificationUtils));
/* 23 */     this.outputStream = new PrintStream(new NotificationOutputStream(NotificationLevel.INFO, notificationUtils));
/* 24 */     this.warnStream = new PrintStream(new NotificationOutputStream(NotificationLevel.WARNING, notificationUtils));
/* 25 */     this.infoclientStream = new PrintStream(new NotificationOutputStream(NotificationLevel.INFOCLIENT, notificationUtils));
/* 26 */     this.notifclientStream = new PrintStream(new NotificationOutputStream(NotificationLevel.NOTIFCLIENT, notificationUtils));
/*    */   }
/*    */   
/*    */   public PrintStream getOut()
/*    */   {
/* 31 */     return this.outputStream;
/*    */   }
/*    */   
/*    */   public PrintStream getErr()
/*    */   {
/* 36 */     return this.errorStream;
/*    */   }
/*    */   
/*    */   public PrintStream getWarn()
/*    */   {
/* 41 */     return this.warnStream;
/*    */   }
/*    */   
/*    */   public PrintStream getInfo()
/*    */   {
/* 46 */     return this.infoclientStream;
/*    */   }
/*    */   
/*    */   public PrintStream getNotif()
/*    */   {
/* 51 */     return this.notifclientStream;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\NotificationConsoleImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */