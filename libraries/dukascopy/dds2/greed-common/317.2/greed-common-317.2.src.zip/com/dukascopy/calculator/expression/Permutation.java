/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.function.DFunction;
/*    */ 
/*    */ 
/*    */ public class Permutation
/*    */   extends Dyadic<DFunction>
/*    */ {
/*    */   public Permutation(OObject expression1, OObject expression2)
/*    */   {
/* 12 */     super(new com.dukascopy.calculator.function.Permutation(), expression1, expression2);
/*    */   }
/*    */   
/*    */   public Product negate() {
/* 16 */     Product p = new Product(this, false);
/* 17 */     return p.negate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Permutation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */