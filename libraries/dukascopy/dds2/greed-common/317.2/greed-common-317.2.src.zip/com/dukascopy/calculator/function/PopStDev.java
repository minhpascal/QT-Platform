/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.complex.Complex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PopStDev
/*    */   extends Container
/*    */ {
/*    */   public PopStDev()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.pop.st.dev.function";
/* 15 */     this.fshortcut = 'N';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(double d)
/*    */   {
/* 23 */     this.d = d;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(Complex c)
/*    */   {
/* 31 */     this.c = c;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setError(boolean error)
/*    */   {
/* 39 */     this.error = error;
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 43 */     return fname;
/*    */   }
/*    */   
/* 46 */   private static final String[] fname = { "<i>&#963;</i>", "<sub><i>n</i></sub>" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\PopStDev.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */