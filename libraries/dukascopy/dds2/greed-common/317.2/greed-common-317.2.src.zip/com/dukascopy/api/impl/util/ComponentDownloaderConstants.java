package com.dukascopy.api.impl.util;

public class ComponentDownloaderConstants
{
  protected static final String DATA = "data";
  protected static final String MODIFY_DATE = "ModifyDate";
  protected static final String MODIFY_DATE_5 = "&modifyDate={5}";
  protected static final String AUTH_AND_ID_PARAMS = "id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_STRATEGY_DATE = "getUserStrategyTime";
  protected static final String GET_STRATEGYS_LIST_ACTION = "getUserStrategiesList";
  protected static final String FILENAME = "filename=";
  protected static final String GET_USER_STRATEGY_PARAMS = "getUserStrategy?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_COMPILED_FILE_PLATFORM_PARAMS = "getCompiledFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_SOURCE_FILE_PLATFORM_PARAMS = "getSourceFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_USER_STRATEGY_SRC_PARAMS = "getUserStrategySrc?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_USER_STRATEGY_SRC_DATE_PARAMS = "getUserStrategySrc?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_MODIFIED_USER_STRATEGY_PARAMS = "getUserStrategy?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}";
  protected static final String GET_MODIFIED_COMPILED_FILE_PLATFORM_PARAMS = "getCompiledFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}";
  protected static final String GET_MODIFIED_USER_STRATEGY_SRC_PARAMS = "getUserStrategySrc?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}";
  protected static final String GET_MODIFIED_USER_STRATEGY_SRC_DATE_PARAMS = "getUserStrategySrc?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}";
  protected static final String GET_USER_STRATEGY_JSS_PARAMS = "protected/getProtectedUserStrategy?id={0}&login={1}";
  protected static final String GET_COMPILED_FILE_PLATFORM_JSS_PARAMS = "protected/getProtectedCompiledFilePlatform?id={0}&login={1}";
  protected static final String GET_USER_STRATEGY_SRC_JSS_PARAMS = "protected/getProtectedUserStrategySrc?id={0}&login={1}";
  protected static final String GET_SOURCE_FILE_PLATFORM_JSS_PARAMS = "protected/getProtectedSourceFilePlatform?id={0}&login={1}";
  protected static final String GET_MODIFIED_SOURCE_FILE_PLATFORM_PARAMS = "getSourceFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
  protected static final String GET_MODIFIED_USER_STRATEGY_JSS_PARAMS = "protected/getProtectedUserStrategy?id={0}&login={1}&modifyDate={2}";
  protected static final String GET_MODIFIED_COMPILED_FILE_PLATFORM_JSS_PARAMS = "protected/getProtectedCompiledFilePlatform?id={0}&login={1}&modifyDate={2}";
  protected static final String GET_MODIFIED_USER_STRATEGY_SRC_JSS_PARAMS = "protected/getProtectedUserStrategySrc?id={0}&login={1}&modifyDate={2}";
  protected static final String GET_MODIFIED_SOURCE_FILE_PLATFORM_JSS_PARAMS = "protected/getProtectedSourceFilePlatform?id={0}&login={1}&modifyDate={2}";
  protected static final int HTTP_RESPONSE_OK = 200;
  protected static final String STRATEGY_DATE = "strategyModifyDate";
  public static final String STRATEGY_TYPE = "user";
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\ComponentDownloaderConstants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */