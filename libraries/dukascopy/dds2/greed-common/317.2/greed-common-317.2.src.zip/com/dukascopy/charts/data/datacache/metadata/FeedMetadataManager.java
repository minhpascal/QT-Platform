/*     */ package com.dukascopy.charts.data.datacache.metadata;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.PriceRange;
/*     */ import com.dukascopy.api.ReversalAmount;
/*     */ import com.dukascopy.api.TickBarSize;
/*     */ import com.dukascopy.charts.data.datacache.CurvesProtocolUtil;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.ICurvesProtocolHandler;
/*     */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*     */ import com.dukascopy.charts.data.datacache.SingleResponseMessageHandler;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.TimeDataUtils;
/*     */ import com.dukascopy.charts.utils.map.ITwoKeyMap;
/*     */ import com.dukascopy.charts.utils.map.SynchronizedTwoKeyMap;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.dfs.DFHistoryStartRequestMessage;
/*     */ import com.dukascopy.dds3.transport.msg.dfs.DFHistoryStartResponseMessage;
/*     */ import com.dukascopy.dds4.transport.client.TransportClient;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TimeZone;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeedMetadataManager
/*     */   implements IFeedMetadataManager
/*     */ {
/*  43 */   private static final Logger LOGGER = LoggerFactory.getLogger(FeedMetadataManager.class);
/*     */   
/*  45 */   protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
/*     */   
/*  47 */   static { DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT 0")); }
/*     */   
/*     */ 
/*     */   private final long initializationTime;
/*     */   
/*     */   private TransportClient transportClient;
/*     */   
/*     */   private final ICurvesProtocolHandler curvesProtocolHandler;
/*     */   private final Set<Instrument> supportedInstruments;
/*     */   private final Set<String> supportedInstrumentsAsStr;
/*  57 */   private boolean initialFirstTimesLoadExecuted = false;
/*     */   
/*  59 */   private final ITwoKeyMap<Instrument, Period, Long> firstTimes = new SynchronizedTwoKeyMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeedMetadataManager(ICurvesProtocolHandler curvesProtocolHandler, Set<String> supportedInstrumentsAsStr)
/*     */   {
/*  66 */     this.initializationTime = System.currentTimeMillis();
/*  67 */     this.curvesProtocolHandler = curvesProtocolHandler;
/*  68 */     this.supportedInstrumentsAsStr = supportedInstrumentsAsStr;
/*  69 */     this.supportedInstruments = Instrument.fromStringSet(supportedInstrumentsAsStr);
/*     */   }
/*     */   
/*     */   public void setTransportClient(TransportClient transportClient) {
/*  73 */     this.transportClient = transportClient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTimeOfFirstCandle(Instrument instrument, Period period)
/*     */   {
/*  87 */     synchronized (this.firstTimes)
/*     */     {
/*  89 */       Period basicPeriod = Period.getBasicPeriodForCustom(period);
/*  90 */       Long cachedFirstTime = (Long)this.firstTimes.get(instrument, basicPeriod);
/*     */       
/*  92 */       if (cachedFirstTime == null) {
/*  93 */         boolean dfsAvailable = (this.transportClient != null) && (this.transportClient.isOnline());
/*  94 */         if (!dfsAvailable) {
/*  95 */           Period p = period.isTickBasedPeriod() ? Period.ONE_SEC : period;
/*  96 */           long result = DataCacheUtils.getCandleStartFast(p, this.initializationTime);
/*  97 */           return result;
/*     */         }
/*     */       }
/*     */       
/* 101 */       preloadCache();
/*     */       
/* 103 */       if (cachedFirstTime != null) {
/* 104 */         long requestedPeriodTime = getRequestedPeriodTime(period, cachedFirstTime.longValue());
/* 105 */         return requestedPeriodTime;
/*     */       }
/*     */       
/* 108 */       long firstTime = Long.MAX_VALUE;
/*     */       
/* 110 */       firstTime = getFirstTimeFromLocalCacheOrDFS(instrument, basicPeriod);
/*     */       
/* 112 */       if (firstTime == Long.MAX_VALUE) {
/* 113 */         LOGGER.warn("No data for " + instrument + ", " + basicPeriod);
/*     */       }
/*     */       
/* 116 */       this.firstTimes.put(instrument, basicPeriod, Long.valueOf(firstTime));
/* 117 */       long requestedPeriodTime = getRequestedPeriodTime(period, firstTime);
/* 118 */       return requestedPeriodTime;
/*     */     }
/*     */   }
/*     */   
/*     */   private long getRequestedPeriodTime(Period period, long time)
/*     */   {
/* 124 */     if (period.isTickBasedPeriod()) {
/* 125 */       return time;
/*     */     }
/* 127 */     return DataCacheUtils.getCandleStartFast(period, time);
/*     */   }
/*     */   
/*     */   private Map<Instrument, Map<Period, Long>> getFirstTimeFromDFS(final Set<Instrument> instruments)
/*     */   {
/*     */     try {
/* 133 */       Map<Instrument, Map<Period, Long>> result = (Map)this.curvesProtocolHandler.processMessage(new SingleResponseMessageHandler()
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */         new LoadingProgressAdapter
/*     */         {
/*     */           public Map<Instrument, Map<Period, Long>> handleResponseMessages(SortedSet<DFHistoryStartResponseMessage> messages)
/*     */           {
/* 137 */             DFHistoryStartResponseMessage message = (DFHistoryStartResponseMessage)messages.first();
/* 138 */             return FeedMetadataManager.this.covertDFHistoryStartResponse(message.getHistoryStart());
/*     */           }
/*     */           
/*     */           public DFHistoryStartRequestMessage createRequestMessage()
/*     */           {
/* 143 */             String instrumentsAsString = CurvesProtocolUtil.instrumentsToString(instruments);
/*     */             
/* 145 */             DFHistoryStartRequestMessage requestMessage = new DFHistoryStartRequestMessage();
/* 146 */             requestMessage.setInstruments(instrumentsAsString);
/*     */             
/* 148 */             return requestMessage; } }, new LoadingProgressAdapter() {});
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */       if (result == null) {}
/* 155 */       return new HashMap();
/*     */ 
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */ 
/* 161 */       LOGGER.error(e.getLocalizedMessage(), e);
/*     */     }
/*     */     
/* 164 */     return null;
/*     */   }
/*     */   
/*     */   private Map<Instrument, Map<Period, Long>> covertDFHistoryStartResponse(String historyStart) {
/* 168 */     Map<Instrument, Map<Period, Long>> result = new HashMap();
/* 169 */     if (historyStart != null) {
/* 170 */       String[] instrumentsHistoryStarts = historyStart.split(";");
/* 171 */       for (String byInstrument : instrumentsHistoryStarts) {
/* 172 */         String[] periodsHistoryStarts = byInstrument.split(",");
/*     */         
/* 174 */         Instrument instrument = Instrument.fromString(periodsHistoryStarts[0]);
/* 175 */         Map<Period, Long> periodMap = new HashMap();
/* 176 */         result.put(instrument, periodMap);
/*     */         
/* 178 */         for (int i = 1; i < periodsHistoryStarts.length; i += 2) {
/* 179 */           Period period = DataCacheUtils.getOldBasicPeriodFromInterval(Long.valueOf(periodsHistoryStarts[i]).longValue());
/* 180 */           Long time = Long.valueOf(periodsHistoryStarts[(i + 1)]);
/* 181 */           periodMap.put(period, time);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 186 */     return result;
/*     */   }
/*     */   
/*     */   private long getFirstTimeFromLocalCacheOrDFS(Instrument instrument, Period period)
/*     */   {
/* 191 */     Long result = checkDFS(instrument, period);
/*     */     
/* 193 */     if (result == null) {
/* 194 */       return Long.MAX_VALUE;
/*     */     }
/*     */     
/* 197 */     return result.longValue();
/*     */   }
/*     */   
/*     */   private Long checkDFS(Instrument instrument, Period period)
/*     */   {
/* 202 */     Set<Instrument> instruments = Collections.singleton(instrument);
/* 203 */     checkDFSFillAllCaches(instruments);
/*     */     
/* 205 */     Long time = (Long)this.firstTimes.get(instrument, period);
/* 206 */     return time;
/*     */   }
/*     */   
/*     */   private void checkDFSFillAllCaches(Set<Instrument> instruments) {
/* 210 */     Map<Instrument, Map<Period, Long>> firstTimes = getFirstTimeFromDFS(instruments);
/*     */     
/* 212 */     if (firstTimes == null) {
/* 213 */       return;
/*     */     }
/*     */     
/* 216 */     putToRAMCache(instruments, firstTimes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void putToRAMCache(Set<Instrument> instruments, Map<Instrument, Map<Period, Long>> firstTimes)
/*     */   {
/* 223 */     if ((instruments != null) && (!instruments.isEmpty())) {
/* 224 */       for (Instrument i : instruments) {
/* 225 */         Map<Period, Long> localCacheFirstTimes = (Map)firstTimes.get(i);
/* 226 */         putToRAMCache(i, localCacheFirstTimes);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void putToRAMCache(Instrument instrument, Map<Period, Long> localCacheFirstTimes) {
/* 232 */     if ((localCacheFirstTimes != null) && (!localCacheFirstTimes.isEmpty())) {
/* 233 */       for (Period period : localCacheFirstTimes.keySet()) {
/* 234 */         Long time = (Long)localCacheFirstTimes.get(period);
/*     */         
/* 236 */         this.firstTimes.put(instrument, period, time);
/*     */       }
/*     */       
/*     */     } else {
/* 240 */       for (Period period : Period.valuesForIndicator()) {
/* 241 */         this.firstTimes.put(instrument, period, Long.valueOf(Long.MAX_VALUE));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Instrument> getSupportedInstruments()
/*     */   {
/* 248 */     if (this.supportedInstruments == null) {
/* 249 */       return new ArrayList();
/*     */     }
/* 251 */     return Collections.unmodifiableList(new ArrayList(this.supportedInstruments));
/*     */   }
/*     */   
/*     */   public void preloadCache()
/*     */   {
/* 256 */     if ((!this.initialFirstTimesLoadExecuted) && (this.firstTimes.isEmpty()) && (!ObjectUtils.isNullOrEmpty(this.supportedInstruments)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 261 */       this.initialFirstTimesLoadExecuted = true;
/* 262 */       checkDFSFillAllCaches(this.supportedInstruments);
/*     */     }
/*     */   }
/*     */   
/*     */   public Set<String> getSupportedInstrumentsAsStr()
/*     */   {
/* 268 */     return this.supportedInstrumentsAsStr;
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstBar(Instrument instrument, PriceRange priceRange)
/*     */   {
/* 273 */     Period period = TimeDataUtils.getSuitablePeriod(priceRange);
/* 274 */     long result = getTimeOfFirstCandle(instrument, period);
/* 275 */     return result;
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstBar(Instrument instrument, PriceRange priceRange, ReversalAmount reversalAmount)
/*     */   {
/* 280 */     Period period = TimeDataUtils.getSuitablePeriod(priceRange, reversalAmount);
/* 281 */     long result = getTimeOfFirstCandle(instrument, period);
/* 282 */     return result;
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstBar(Instrument instrument, TickBarSize tickBarSize)
/*     */   {
/* 287 */     long result = getTimeOfFirstCandle(instrument, Period.TICK);
/* 288 */     return result;
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstTick(Instrument instrument)
/*     */   {
/* 293 */     long result = getTimeOfFirstCandle(instrument, Period.TICK);
/* 294 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\metadata\FeedMetadataManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */