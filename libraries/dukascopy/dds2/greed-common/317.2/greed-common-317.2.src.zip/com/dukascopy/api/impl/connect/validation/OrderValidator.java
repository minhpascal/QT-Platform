/*     */ package com.dukascopy.api.impl.connect.validation;
/*     */ 
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.IEngine.OrderCommand;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.api.IOrder.State;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.JFException.Error;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.impl.connect.ILotAmountProvider;
/*     */ import com.dukascopy.api.impl.connect.JForexAPI;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.AbstractCurrencyConverter;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrderValidator
/*     */   implements IOrderValidator
/*     */ {
/*  36 */   private static final Logger LOGGER = LoggerFactory.getLogger(OrderValidator.class);
/*     */   private final IThreadValidator threadValidator;
/*     */   private final ILotAmountProvider lotAmountProvider;
/*     */   
/*     */   public OrderValidator(IThreadValidator threadValidator, ILotAmountProvider lotAmountProvider)
/*     */   {
/*  42 */     this.threadValidator = threadValidator;
/*  43 */     this.lotAmountProvider = lotAmountProvider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateLabel(String label)
/*     */     throws JFException
/*     */   {
/*  53 */     if (label == null) {
/*  54 */       throw new JFException(JFException.Error.LABEL_INCONSISTENT);
/*     */     }
/*  56 */     if (label.length() > 256) {
/*  57 */       throw new JFException(JFException.Error.LABEL_INCONSISTENT);
/*     */     }
/*  59 */     if (!label.matches("^[a-zA-Z_][a-zA-Z0-9_]+")) {
/*  60 */       throw new JFException(JFException.Error.LABEL_INCONSISTENT);
/*     */     }
/*  62 */     return label.trim();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateComment(String comment)
/*     */   {
/*  74 */     if (!ObjectUtils.isNullOrEmpty(comment)) {
/*  75 */       if ((comment.startsWith("[")) || (comment.startsWith("\\"))) {
/*  76 */         comment = " " + comment;
/*     */       }
/*  78 */       if ((comment.endsWith("]")) || (comment.endsWith("\\"))) {
/*  79 */         comment = comment + " ";
/*     */       }
/*     */     }
/*  82 */     return comment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateOrderParameters(String label, boolean isGlobal, Instrument instrument, ICurrency accountCurrency, IEngine.OrderCommand orderCommand, double amount, double price, double stopLossPrice, double takeProfitPrice, long goodTillTime)
/*     */     throws JFException
/*     */   {
/*  96 */     return validateOrderParameters(label, isGlobal, instrument, accountCurrency, orderCommand, amount, price, stopLossPrice, takeProfitPrice, goodTillTime, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateOrderParameters(String label, boolean isGlobal, Instrument instrument, ICurrency accountCurrency, IEngine.OrderCommand orderCommand, double amount, double price, double stopLossPrice, double takeProfitPrice, long goodTillTime, IFeedDataProvider feedDataProvider)
/*     */     throws JFException
/*     */   {
/* 114 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 115 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 117 */     label = validateLabel(label);
/*     */     
/* 119 */     if (feedDataProvider != null) {
/* 120 */       if (!feedDataProvider.isSubscribedToInstrument(instrument)) {
/* 121 */         throw new JFException("Not subscribed to the instrument [" + instrument + "]");
/*     */       }
/* 123 */       Set<Instrument> conversionDeps = AbstractCurrencyConverter.getConversionDeps(instrument.getSecondaryJFCurrency(), AbstractCurrencyConverter.USD);
/* 124 */       for (Instrument instrumentDep : conversionDeps) {
/* 125 */         if (!feedDataProvider.isSubscribedToInstrument(instrumentDep)) {
/* 126 */           throw new JFException("Not subscribed to the instrument [" + instrumentDep + "]");
/*     */         }
/*     */       }
/* 129 */       conversionDeps = AbstractCurrencyConverter.getConversionDeps(AbstractCurrencyConverter.USD, accountCurrency);
/* 130 */       for (Instrument instrumentDep : conversionDeps) {
/* 131 */         if (!feedDataProvider.isSubscribedToInstrument(instrumentDep)) {
/* 132 */           throw new JFException("Not subscribed to the instrument [" + instrumentDep + "]");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 137 */     if (orderCommand == null) {
/* 138 */       throw new JFException(JFException.Error.COMMAND_IS_NULL);
/*     */     }
/* 140 */     if (amount <= 0.0D) {
/* 141 */       throw new JFException("Invalid order amount: " + amount);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 146 */     if ((price == 0.0D) && 
/* 147 */       (!JForexAPI.isMarket(orderCommand))) {
/* 148 */       throw new JFException(JFException.Error.ZERO_PRICE_NOT_ALLOWED);
/*     */     }
/*     */     
/* 151 */     validateGoodTillTime(goodTillTime, orderCommand);
/*     */     
/* 153 */     if (isGlobal) {
/* 154 */       if (StratUtils.round(stopLossPrice, 7) > 0.0D) {
/* 155 */         throw new JFException("Stop loss orders are not allowed on global accounts");
/*     */       }
/* 157 */       if (StratUtils.round(takeProfitPrice, 7) > 0.0D) {
/* 158 */         throw new JFException("Take profit orders are not allowed on global accounts");
/*     */       }
/*     */     }
/* 161 */     return label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateOrder(IOrder platformOrder)
/*     */   {
/* 169 */     StringBuilder warning = new StringBuilder();
/* 170 */     Instrument instrument = platformOrder.getInstrument();
/* 171 */     warning = append(warning, validatePrice(platformOrder.getOpenPrice(), instrument));
/* 172 */     warning = append(warning, validateMinMaxAmount(platformOrder.getAmount(), instrument));
/* 173 */     warning = append(warning, validateStopLossTakeProfitPrice(true, platformOrder.getStopLossPrice(), instrument));
/* 174 */     warning = append(warning, validateStopLossTakeProfitPrice(false, platformOrder.getTakeProfitPrice(), instrument));
/* 175 */     return warning.toString();
/*     */   }
/*     */   
/*     */   public String validateMinMaxAmount(double amount, Instrument instrument)
/*     */   {
/* 180 */     String warning = null;
/* 181 */     double minTradableAmount = this.lotAmountProvider.getMinTradableAmount(instrument).doubleValue();
/* 182 */     double maxTradableAmount = this.lotAmountProvider.getMaxTradableAmount(instrument).doubleValue();
/* 183 */     if (minTradableAmount > amount) {
/* 184 */       warning = String.format("Order amount: %.7f can't be less than minimum allowed: %.6f", new Object[] { Double.valueOf(amount), Double.valueOf(minTradableAmount) });
/* 185 */     } else if (maxTradableAmount < amount) {
/* 186 */       warning = String.format("Order amount: %.7f can't be more than maximum allowed: %.6f", new Object[] { Double.valueOf(amount), Double.valueOf(maxTradableAmount) });
/*     */     }
/* 188 */     return warning;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String validateStopLossTakeProfitPrice(boolean stopLoss, double price, Instrument instrument)
/*     */   {
/* 195 */     String warning = null;
/* 196 */     if (Double.compare(price, 0.0D) != 0) {
/* 197 */       warning = validatePrice(price, instrument);
/* 198 */       if (!ObjectUtils.isNullOrEmpty(warning)) {
/* 199 */         String trigger = stopLoss ? "STOP LOSS" : "TAKE PROFIT";
/* 200 */         warning = trigger + warning;
/*     */       }
/*     */     }
/* 203 */     return warning;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateRequestedAmount(IOrder order, double requestedAmount, long requestedAmountChangeTime, String openingOrderId, String pendingOrderId)
/*     */     throws JFException
/*     */   {
/* 215 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 216 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 218 */     if ((requestedAmount > 0.0D) && (!ObjectUtils.isEqual(IOrder.State.OPENED, order.getState()))) {
/* 219 */       throw new JFException("Cannot change amount of created (not yet accepted), filled, closed or canceled order");
/*     */     }
/* 221 */     if (JForexAPI.isPlaceBidOffer(order.getOrderCommand())) {
/* 222 */       throw new JFException("Cannot change amount of PLACE_BID or PLACE_OFFER");
/*     */     }
/* 224 */     if (Double.compare(requestedAmount, 0.0D) == 0) {
/* 225 */       if ((!ObjectUtils.isEqual(IOrder.State.FILLED, order.getState())) && (!ObjectUtils.isEqual(IOrder.State.OPENED, order.getState()))) {
/* 226 */         throw new JFException("Cannot cancel created (not yet accepted), closed or canceled order");
/*     */       }
/* 228 */       if ((ObjectUtils.isEqual(IOrder.State.FILLED, order.getState())) && (pendingOrderId == null)) {
/* 229 */         throw new JFException("Cannot cancel pending part of the filled order when it doesn't have pending part");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 234 */     String rejectWarningFormat = "Position #" + order.getId() + " ENTRY #" + openingOrderId + " amount change REJECTED" + ", REASON: %s";
/*     */     
/* 236 */     String content = null;
/*     */     
/* 238 */     if (requestedAmountChangeTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 239 */       content = String.format(rejectWarningFormat, new Object[] { "can't change requested amount more than once in a second" });
/* 240 */     } else if (Double.compare(requestedAmount, 0.0D) != 0)
/*     */     {
/* 242 */       String amountWarning = validateMinMaxAmount(requestedAmount, order.getInstrument());
/* 243 */       if (!ObjectUtils.isNullOrEmpty(amountWarning)) {
/* 244 */         content = String.format(rejectWarningFormat, new Object[] { amountWarning });
/*     */       }
/*     */     }
/* 247 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateLabel(IOrder order, String label, long labelChangeTime, boolean fulfilled, String openingOrderId, String pendingOrderId)
/*     */     throws JFException
/*     */   {
/* 259 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 260 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 262 */     if (!ObjectUtils.isEqual(order.getState(), IOrder.State.OPENED)) {
/* 263 */       throw new JFException("Cannot change label. Order not in OPENED state");
/*     */     }
/* 265 */     if (JForexAPI.isPlaceBidOffer(order.getOrderCommand())) {
/* 266 */       throw new JFException("Cannot change label of PLACE_BID or PLACE_OFFER");
/*     */     }
/*     */     
/*     */ 
/* 270 */     String rejectWarningFormat = "Position #" + order.getId() + " ENTRY #" + openingOrderId + " label change REJECTED" + ", REASON: %s";
/*     */     
/* 272 */     String content = null;
/*     */     
/* 274 */     if (labelChangeTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 275 */       content = String.format(rejectWarningFormat, new Object[] { "can't change label more than once in a second" });
/*     */     }
/* 277 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateOpenPrice(IOrder order, double price, long openPriceChangeTime, boolean fulfilled, String openingOrderId)
/*     */     throws JFException
/*     */   {
/* 291 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 292 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/*     */     
/* 295 */     if ((!ObjectUtils.isEqual(order.getState(), IOrder.State.OPENED)) && ((!ObjectUtils.isEqual(order.getState(), IOrder.State.FILLED)) || (fulfilled))) {
/* 296 */       throw new JFException("Order not in OPENED or FILLED(partially) state");
/*     */     }
/*     */     String content;
/*     */     String content;
/* 300 */     if (openPriceChangeTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 301 */       content = "Position #" + order.getId() + " ENTRY #" + openingOrderId + " price stop change REJECTED" + ", REASON: can't change price more than once in a second";
/*     */     }
/*     */     else {
/* 304 */       content = validatePrice(price, order.getInstrument());
/*     */     }
/*     */     
/* 307 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateStopLossPrice(IOrder order, double price, OfferSide side, double trailingStepInPips, boolean global, long stopLossChangeTime)
/*     */     throws JFException
/*     */   {
/* 325 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 326 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 328 */     if ((global) && (price > 0.0D)) {
/* 329 */       throw new JFException("Stop loss orders are not allowed on global accounts");
/*     */     }
/* 331 */     if ((!ObjectUtils.isEqual(IOrder.State.FILLED, order.getState())) && (!ObjectUtils.isEqual(IOrder.State.OPENED, order.getState()))) {
/* 332 */       throw new JFException(JFException.Error.ORDER_STATE_IMMUTABLE);
/*     */     }
/* 334 */     if ((trailingStepInPips != 0.0D) && (trailingStepInPips < 10.0D)) {
/* 335 */       throw new JFException("Trailing step must be >= 10 or equals to 0 (cancel)");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 341 */     String rejectWarningFormat = "Order REJECTED: STOP LOSS " + (order.isLong() ? "SELL" : "BUY") + " " + order.getInstrument() + " @MKT IF " + side.name() + " " + (order.isLong() ? "<=" : "=>") + " " + price + " - Position #" + order.getId() + ", REASON: %s";
/*     */     
/*     */ 
/*     */ 
/* 345 */     String content = null;
/*     */     
/*     */ 
/* 348 */     if (stopLossChangeTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 349 */       content = String.format(rejectWarningFormat, new Object[] { "can't change stop loss price more than once in a second" });
/*     */     }
/*     */     else {
/* 352 */       String priceWarning = validateStopLossTakeProfitPrice(true, price, order.getInstrument());
/* 353 */       if (!ObjectUtils.isNullOrEmpty(priceWarning)) {
/* 354 */         content = String.format(rejectWarningFormat, new Object[] { priceWarning });
/*     */       }
/*     */     }
/* 357 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateTakeProfitPrice(IOrder order, double price, OfferSide side, boolean global, long takeProfitChangeTime)
/*     */     throws JFException
/*     */   {
/* 370 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 371 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 373 */     if ((global) && (price > 0.0D)) {
/* 374 */       throw new JFException("Take Profit orders are not allowed on global accounts");
/*     */     }
/* 376 */     if ((!ObjectUtils.isEqual(IOrder.State.FILLED, order.getState())) && (!ObjectUtils.isEqual(IOrder.State.OPENED, order.getState()))) {
/* 377 */       throw new JFException(JFException.Error.ORDER_STATE_IMMUTABLE);
/*     */     }
/*     */     
/*     */ 
/* 381 */     String rejectWarningFormat = "Order REJECTED: TAKE PROFIT " + (order.isLong() ? "SELL" : "BUY") + " " + order.getInstrument() + " @MKT IF " + side.name() + " " + (order.isLong() ? "=>" : "<=") + " " + price + " - Position #" + order.getId() + ", REASON: %s";
/*     */     
/*     */ 
/*     */ 
/* 385 */     String content = null;
/*     */     
/*     */ 
/* 388 */     if (takeProfitChangeTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 389 */       content = String.format(rejectWarningFormat, new Object[] { "can't change take profit price more than once in a second" });
/*     */     }
/*     */     else {
/* 392 */       String priceWarning = validateStopLossTakeProfitPrice(false, price, order.getInstrument());
/* 393 */       if (!ObjectUtils.isNullOrEmpty(priceWarning)) {
/* 394 */         content = String.format(rejectWarningFormat, new Object[] { priceWarning });
/*     */       }
/*     */     }
/* 397 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateGoodTillTime(IOrder order, long goodTillTime, long goodTillTimeChangeTime, boolean fulfilled, String openingOrderId)
/*     */     throws JFException
/*     */   {
/* 412 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 413 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 415 */     validateGoodTillTime(goodTillTime, order.getOrderCommand());
/* 416 */     if ((!ObjectUtils.isEqual(order.getState(), IOrder.State.OPENED)) && ((!ObjectUtils.isEqual(order.getState(), IOrder.State.FILLED)) || (fulfilled))) {
/* 417 */       throw new JFException("Order not in OPENED or FILLED(partially) state");
/*     */     }
/*     */     
/* 420 */     String content = null;
/*     */     
/* 422 */     if (goodTillTimeChangeTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 423 */       content = "Position #" + order.getId() + " ENTRY #" + openingOrderId + " good till time change REJECTED" + ", REASON: can't change good till time more than once in a second";
/*     */     }
/*     */     
/* 426 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateClose(IOrder order, double amount, double price, double slippage, long closeAttemptTime)
/*     */     throws JFException
/*     */   {
/* 440 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 441 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/*     */     
/* 444 */     if (((amount > 0.0D) || (price > 0.0D) || (slippage >= 0.0D)) && (ObjectUtils.isEqual(order.getState(), IOrder.State.OPENED))) {
/* 445 */       throw new JFException(JFException.Error.ORDER_CANCEL_INCORRECT);
/*     */     }
/* 447 */     String content = null;
/* 448 */     if (closeAttemptTime + TimeUnit.SECONDS.toMillis(1L) > System.currentTimeMillis()) {
/* 449 */       content = "Position #" + order.getId() + " order close REJECTED" + ", REASON: can't send request to fully close order more than once in a second";
/*     */     }
/*     */     
/* 452 */     return content;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validateGoodTillTime(long goodTillTime, IEngine.OrderCommand orderCommand)
/*     */     throws JFException
/*     */   {
/* 461 */     if (JForexAPI.isMarket(orderCommand)) {
/* 462 */       if (goodTillTime > 0L) {
/* 463 */         throw new JFException("Order should be either conditional or \"place bid\" or \"place offer\"");
/*     */       }
/*     */     } else {
/* 466 */       if (goodTillTime < 0L) {
/* 467 */         throw new JFException(JFException.Error.INVALID_GTT);
/*     */       }
/* 469 */       if ((goodTillTime > 0L) && (goodTillTime < TimeUnit.DAYS.toMillis(730L))) {
/* 470 */         throw new JFException(JFException.Error.INVALID_GTT);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateMergeOrders(String label, boolean isGlobal, Collection<IOrder> orders)
/*     */     throws JFException
/*     */   {
/* 481 */     if (isGlobal) {
/* 482 */       throw new JFException("Merges are not supported on global accounts");
/*     */     }
/* 484 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 485 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 487 */     if ((ObjectUtils.isNullOrEmpty(orders)) || (orders.size() < 2)) {
/* 488 */       throw new JFException("Cannot merge less then 2 orders");
/*     */     }
/* 490 */     Instrument instrument = null;
/* 491 */     Set<String> mergeOrderGroupIdList = new HashSet();
/* 492 */     for (IOrder order : orders) {
/* 493 */       if (instrument == null) {
/* 494 */         instrument = order.getInstrument();
/*     */       }
/* 496 */       if (order.getInstrument() != instrument) {
/* 497 */         throw new JFException("Cannot merge orders with instruments not equal");
/*     */       }
/* 499 */       if (order.getState() != IOrder.State.FILLED) {
/* 500 */         throw new JFException("Cannot merge orders in state other than FILLED");
/*     */       }
/* 502 */       if (order.getStopLossPrice() != 0.0D) {
/* 503 */         throw new JFException("Cannot merge orders with stop loss");
/*     */       }
/* 505 */       if (order.getTakeProfitPrice() != 0.0D) {
/* 506 */         throw new JFException("Cannot merge orders with take profit");
/*     */       }
/* 508 */       if (mergeOrderGroupIdList.contains(order.getId())) {
/* 509 */         throw new JFException("Order [" + order.getLabel() + "] appears more than once in list of orders to merge");
/*     */       }
/* 511 */       mergeOrderGroupIdList.add(order.getId());
/*     */     }
/*     */     
/* 514 */     if (label == null) {
/* 515 */       label = StratUtils.generateLabel();
/*     */     } else {
/* 517 */       label = validateLabel(label);
/*     */     }
/* 519 */     return label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void validateCloseOrders(boolean isGlobal, Collection<IOrder> orders)
/*     */     throws JFException
/*     */   {
/* 527 */     if (ObjectUtils.isNullOrEmpty(orders)) {
/* 528 */       LOGGER.warn("Mass orders' close skipped. Orders are not specified.");
/* 529 */       return;
/*     */     }
/* 531 */     if (isGlobal) {
/* 532 */       throw new JFException("Cannot close orders on global accounts. Please open opposite order instead");
/*     */     }
/* 534 */     if (!this.threadValidator.isThreadOk(Thread.currentThread().getId())) {
/* 535 */       throw new JFException(JFException.Error.THREAD_INCORRECT);
/*     */     }
/* 537 */     for (IOrder order : orders) {
/* 538 */       if (order.getState() != IOrder.State.FILLED) {
/* 539 */         throw new JFException("Cannot mass close orders in state other than FILLED");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String validatePrice(double price, Instrument instrument)
/*     */   {
/* 546 */     String warning = null;
/*     */     
/* 548 */     if (Double.compare(price, 0.0D) != 0) {
/* 549 */       if (price < 0.0D) {
/* 550 */         warning = " Price can't be negative";
/* 551 */       } else if (price > 999999.0D) {
/* 552 */         warning = " Price max price violated";
/*     */       } else {
/* 554 */         int pipScale = instrument.getPipScale();
/* 555 */         double priceRound = StratUtils.roundHalfEven(price, Math.max(0, pipScale) + 1);
/* 556 */         if (Double.compare(priceRound, price) != 0) {
/* 557 */           warning = " Invalid price format - please use increments of 0.1 pip.";
/*     */         }
/*     */       }
/*     */     }
/* 561 */     return warning;
/*     */   }
/*     */   
/*     */   private StringBuilder append(StringBuilder stringBuilder, String string)
/*     */   {
/* 566 */     if (!ObjectUtils.isNullOrEmpty(string)) {
/* 567 */       if (stringBuilder.length() > 0) {
/* 568 */         stringBuilder.append("; ");
/*     */       }
/* 570 */       stringBuilder.append(string);
/*     */     }
/* 572 */     return stringBuilder;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\validation\OrderValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */