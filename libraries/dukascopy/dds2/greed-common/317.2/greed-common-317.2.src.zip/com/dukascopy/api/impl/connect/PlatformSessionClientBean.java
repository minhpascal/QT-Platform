/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ public class PlatformSessionClientBean
/*    */ {
/*  5 */   private static PlatformSessionClientBean instance = null;
/*    */   
/*    */   private String userName;
/*    */   private String sessionID;
/*    */   private String ticket;
/*    */   private String storageServerUrl;
/*    */   private String scheme;
/*    */   private PlatformType platformType;
/*    */   
/*    */   public static PlatformSessionClientBean getInstance()
/*    */   {
/* 16 */     if (instance == null) {
/* 17 */       instance = new PlatformSessionClientBean();
/*    */     }
/* 19 */     return instance;
/*    */   }
/*    */   
/*    */   public String getUserName() {
/* 23 */     return this.userName;
/*    */   }
/*    */   
/*    */   public void setUserName(String userName) {
/* 27 */     this.userName = userName;
/*    */   }
/*    */   
/*    */   public String getSessionID() {
/* 31 */     return this.sessionID;
/*    */   }
/*    */   
/*    */   public void setSessionID(String sessionID) {
/* 35 */     this.sessionID = sessionID;
/*    */   }
/*    */   
/*    */   public String getTicket() {
/* 39 */     return this.ticket;
/*    */   }
/*    */   
/*    */   public void setTicket(String ticket) {
/* 43 */     this.ticket = ticket;
/*    */   }
/*    */   
/*    */   public String getStorageServerUrl() {
/* 47 */     return this.storageServerUrl;
/*    */   }
/*    */   
/*    */   public void setStorageServerUrl(String starageUrl) {
/* 51 */     this.storageServerUrl = starageUrl;
/*    */   }
/*    */   
/*    */   public PlatformType getPlatformType() {
/* 55 */     return this.platformType;
/*    */   }
/*    */   
/*    */   public void setPlatformType(PlatformType platformType) {
/* 59 */     this.platformType = platformType;
/*    */   }
/*    */   
/*    */   public String getScheme() {
/* 63 */     return this.scheme;
/*    */   }
/*    */   
/*    */   public void setScheme(String scheme) {
/* 67 */     this.scheme = scheme;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformSessionClientBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */