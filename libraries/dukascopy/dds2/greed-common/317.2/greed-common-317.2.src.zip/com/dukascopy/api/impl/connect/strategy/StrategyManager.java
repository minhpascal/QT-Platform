/*    */ package com.dukascopy.api.impl.connect.strategy;
/*    */ 
/*    */ import com.dukascopy.api.strategy.IStrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.IStrategyManager;
/*    */ import com.dukascopy.api.strategy.IStrategyResponse;
/*    */ import com.dukascopy.api.strategy.StrategyListener;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ public abstract class StrategyManager<DESCRIPTOR extends IStrategyDescriptor, LISTENER extends StrategyListener<DESCRIPTOR>>
/*    */   implements IStrategyManager<DESCRIPTOR, LISTENER>
/*    */ {
/* 24 */   private static final Logger LOGGER = LoggerFactory.getLogger(StrategyManager.class);
/*    */   
/* 26 */   private static final long REQUEST_TIMEOUT = TimeUnit.SECONDS.toMillis(60L);
/*    */   
/* 28 */   protected final Map<UUID, IStrategyResponse<Set<DESCRIPTOR>>> listMap = new HashMap();
/* 29 */   protected final Map<UUID, IStrategyResponse<UUID>> stratStartMap = new HashMap();
/* 30 */   protected final Map<UUID, IStrategyResponse<Void>> stratStopMap = new HashMap();
/*    */   
/* 32 */   protected final ExecutorService executor = Executors.newFixedThreadPool(5);
/*    */   
/* 34 */   protected final Set<LISTENER> strategyListeners = new HashSet();
/*    */   
/*    */   protected abstract void setup();
/*    */   
/*    */   protected abstract void dispose();
/*    */   
/*    */   public void addStrategyListener(LISTENER strategyListener)
/*    */   {
/* 42 */     this.strategyListeners.add(strategyListener);
/*    */   }
/*    */   
/*    */   public void removeStrategyListener(LISTENER strategyListener)
/*    */   {
/* 47 */     this.strategyListeners.remove(strategyListener);
/*    */   }
/*    */   
/*    */   protected <T> Future<IStrategyResponse<T>> processRequest(final Map<UUID, IStrategyResponse<T>> requestResponseMap, final UUID requestId) {
/* 51 */     synchronized (requestResponseMap) {
/* 52 */       requestResponseMap.put(requestId, null);
/*    */     }
/*    */     
/* 55 */     Callable<IStrategyResponse<T>> callable = new Callable()
/*    */     {
/*    */       public IStrategyResponse<T> call() throws Exception {
/* 58 */         synchronized (requestId)
/*    */         {
/* 60 */           if (requestResponseMap.get(requestId) == null) {
/* 61 */             requestId.wait(StrategyManager.REQUEST_TIMEOUT);
/*    */           }
/*    */         }
/* 64 */         synchronized (requestResponseMap) {
/* 65 */           Object responseValue = (IStrategyResponse)requestResponseMap.remove(requestId);
/* 66 */           if (responseValue == null) {
/* 67 */             return StrategyResponse.newErrorResponse(new Exception("Strategy request " + requestId + " timed out!"), requestResponseMap);
/*    */           }
/* 69 */           return (IStrategyResponse<T>)responseValue;
/*    */         }
/*    */       }
/* 72 */     };
/* 73 */     return this.executor.submit(callable);
/*    */   }
/*    */   
/*    */   protected <T> void processResponse(Map<UUID, IStrategyResponse<T>> requestResponseMap, UUID beanRequestId, Callable<IStrategyResponse<T>> getValueCallable) {
/* 77 */     synchronized (requestResponseMap)
/*    */     {
/* 79 */       if (!requestResponseMap.containsKey(beanRequestId)) {
/* 80 */         return;
/*    */       }
/*    */       
/* 83 */       for (UUID requestId : requestResponseMap.keySet()) {
/* 84 */         if (requestId.equals(beanRequestId)) {
/* 85 */           synchronized (requestId) {
/*    */             try {
/* 87 */               requestResponseMap.put(requestId, getValueCallable.call());
/*    */             } catch (Exception e) {
/* 89 */               LOGGER.error(e.getMessage(), e);
/*    */             }
/* 91 */             requestId.notifyAll();
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\StrategyManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */