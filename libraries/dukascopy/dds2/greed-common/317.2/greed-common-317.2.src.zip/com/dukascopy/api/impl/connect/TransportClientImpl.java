/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.dds4.transport.client.TransportClient;
/*    */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransportClientImpl
/*    */   implements ITransportClient
/*    */ {
/*    */   private TransportClient transportClient;
/*    */   
/*    */   public TransportClientImpl(TransportClient transportClient)
/*    */   {
/* 17 */     this.transportClient = transportClient;
/*    */   }
/*    */   
/*    */   public ProtocolMessage controlRequest(ProtocolMessage message)
/*    */   {
/* 22 */     return this.transportClient.controlRequest(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\TransportClientImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */