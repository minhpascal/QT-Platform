/*    */ package com.dukascopy.charts.data.datacache.listener;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OccasionalDataOnWeekendsSubstitutionLiveFeedListener
/*    */   implements LiveFeedListener
/*    */ {
/*    */   private final LiveFeedListener originalLiveFeedListener;
/*    */   private final IFilterManager filterManager;
/* 23 */   private double previousCandleClosePrice = Double.MIN_VALUE;
/* 24 */   private long previousCandleTime = Long.MIN_VALUE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OccasionalDataOnWeekendsSubstitutionLiveFeedListener(IFilterManager filterManager, LiveFeedListener originalLiveFeedListener)
/*    */   {
/* 31 */     this.originalLiveFeedListener = originalLiveFeedListener;
/* 32 */     this.filterManager = filterManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol)
/*    */   {
/* 44 */     boolean isWeekend = this.filterManager.isWeekendTime(time, Period.TICK);
/* 45 */     if (!isWeekend) {
/* 46 */       this.originalLiveFeedListener.newTick(instrument, time, ask, bid, askVol, bidVol);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol)
/*    */   {
/* 62 */     boolean isFlat = this.filterManager.isFlat(open, close, low, high, vol);
/* 63 */     boolean sendFlat = false;
/*    */     
/* 65 */     if (!isFlat) {
/* 66 */       boolean isWeekendTime = this.filterManager.isWeekendTime(time, period);
/* 67 */       if (isWeekendTime)
/*    */       {
/* 69 */         sendFlat = true;
/*    */       }
/*    */     }
/*    */     else {
/* 73 */       sendFlat = true;
/*    */     }
/*    */     
/* 76 */     if (sendFlat) {
/* 77 */       double flatPrice = close;
/* 78 */       if ((this.previousCandleClosePrice > Double.MIN_VALUE) && (this.previousCandleTime < time))
/*    */       {
/* 80 */         flatPrice = this.previousCandleClosePrice;
/*    */       }
/* 82 */       this.originalLiveFeedListener.newCandle(instrument, period, side, time, flatPrice, flatPrice, flatPrice, flatPrice, 0.0D);
/* 83 */       this.previousCandleClosePrice = flatPrice;
/*    */     }
/*    */     else {
/* 86 */       this.originalLiveFeedListener.newCandle(instrument, period, side, time, open, close, low, high, vol);
/* 87 */       this.previousCandleClosePrice = close;
/*    */     }
/*    */     
/* 90 */     this.previousCandleTime = time;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\listener\OccasionalDataOnWeekendsSubstitutionLiveFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */