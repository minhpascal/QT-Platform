package com.dukascopy.charts.data.datacache.intraperiod.listener;

import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
import com.dukascopy.charts.data.datacache.tickbar.TickBarData;

public class LastTickBarLiveFeedListener
  extends LastAbstractPriceAggregationLiveFeedListener<TickBarData>
  implements ITickBarLiveFeedListener
{}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\listener\LastTickBarLiveFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */