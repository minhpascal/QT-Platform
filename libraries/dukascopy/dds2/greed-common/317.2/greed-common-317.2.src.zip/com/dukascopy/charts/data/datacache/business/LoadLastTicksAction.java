/*     */ package com.dukascopy.charts.data.datacache.business;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.ICurvesProtocolHandler;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.feed.IFeedCommissionManager;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadLastTicksAction
/*     */   implements Runnable
/*     */ {
/*  28 */   private static final Logger LOGGER = LoggerFactory.getLogger(LoadLastTicksAction.class);
/*     */   
/*     */   private final IFeedDataProvider feedDataProvider;
/*     */   
/*     */   private final Set<Instrument> instruments;
/*     */   
/*     */   private final ILoadingProgressListener loadingProgressListener;
/*     */   
/*     */   private final LiveFeedListener liveFeedListener;
/*     */   
/*     */   private final boolean applyFeedCommission;
/*     */   
/*     */ 
/*     */   public LoadLastTicksAction(IFeedDataProvider feedDataProvider, Set<Instrument> instruments, LiveFeedListener liveFeedListener, ILoadingProgressListener loadingProgressListener)
/*     */   {
/*  43 */     this(feedDataProvider, instruments, liveFeedListener, loadingProgressListener, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoadLastTicksAction(IFeedDataProvider feedDataProvider, Set<Instrument> instruments, LiveFeedListener liveFeedListener, ILoadingProgressListener loadingProgressListener, boolean applyFeedCommission)
/*     */   {
/*  53 */     this.feedDataProvider = feedDataProvider;
/*  54 */     this.instruments = instruments;
/*  55 */     this.liveFeedListener = liveFeedListener;
/*  56 */     this.loadingProgressListener = loadingProgressListener;
/*  57 */     this.applyFeedCommission = applyFeedCommission;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*  62 */     if (this.loadingProgressListener.stopJob()) {
/*  63 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  67 */       Set<Instrument> notSubscribedInstuments = new HashSet();
/*  68 */       Set<Instrument> subscribedInstuments = new HashSet();
/*     */       
/*     */       Map<Instrument, TickData> lastTicks;
/*     */       Map<Instrument, TickData> lastTicks;
/*  72 */       if ((this.instruments != null) && (!this.instruments.isEmpty())) {
/*  73 */         for (Instrument instrument : this.instruments) {
/*  74 */           if (this.feedDataProvider.getLastTick(instrument) != null) {
/*  75 */             subscribedInstuments.add(instrument);
/*     */           }
/*     */           else {
/*  78 */             notSubscribedInstuments.add(instrument);
/*     */           }
/*     */         }
/*     */         Map<Instrument, TickData> lastTicks;
/*  82 */         if (notSubscribedInstuments.isEmpty()) {
/*  83 */           lastTicks = new HashMap();
/*     */         }
/*     */         else {
/*  86 */           lastTicks = this.feedDataProvider.getICurvesProtocolHandler().loadLastTicks(notSubscribedInstuments, this.loadingProgressListener);
/*     */         }
/*     */       }
/*     */       else {
/*  90 */         lastTicks = this.feedDataProvider.getICurvesProtocolHandler().loadLastTicks(null, this.loadingProgressListener);
/*     */       }
/*     */       
/*     */ 
/*  94 */       if (this.loadingProgressListener.stopJob()) {
/*  95 */         return;
/*     */       }
/*     */       
/*  98 */       for (Instrument instrument : subscribedInstuments) {
/*  99 */         TickData tick = this.feedDataProvider.getLastTick(instrument);
/* 100 */         if (tick != null) {
/* 101 */           lastTicks.put(instrument, tick);
/*     */         }
/*     */         else
/*     */         {
/* 105 */           tick = this.feedDataProvider.getICurvesProtocolHandler().loadLastTick(instrument, this.loadingProgressListener);
/* 106 */           if (tick != null) {
/* 107 */             lastTicks.put(instrument, tick);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 112 */       if (this.loadingProgressListener.stopJob()) {
/* 113 */         return;
/*     */       }
/*     */       
/* 116 */       sendTicks(lastTicks);
/*     */       
/* 118 */       this.loadingProgressListener.loadingFinished(true, 0L, 1L, 1L, null);
/*     */     }
/*     */     catch (DataCacheException e) {
/* 121 */       LOGGER.error("Unable to load last ticks, reason <" + e.getLocalizedMessage() + ">", e);
/* 122 */       this.loadingProgressListener.loadingFinished(false, 0L, 1L, 0L, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void sendTicks(Map<Instrument, TickData> lastTicks)
/*     */   {
/* 128 */     int i = 0;
/*     */     
/* 130 */     IFeedCommissionManager feedCommissionManager = this.feedDataProvider.getFeedCommissionManager();
/*     */     
/* 132 */     for (Instrument instrument : lastTicks.keySet())
/*     */     {
/* 134 */       TickData tick = (TickData)lastTicks.get(instrument);
/*     */       
/* 136 */       if (tick != null)
/*     */       {
/* 138 */         if ((this.applyFeedCommission) && (feedCommissionManager.hasCommission(instrument))) {
/* 139 */           tick = feedCommissionManager.applyFeedCommissionToTick(instrument, tick);
/*     */         }
/*     */         
/* 142 */         this.liveFeedListener.newTick(instrument, tick.time, tick.ask, tick.bid, tick.askVol, tick.bidVol);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 152 */         LOGGER.warn("No ticks for instrument " + instrument);
/*     */       }
/*     */       
/* 155 */       i++;
/* 156 */       this.loadingProgressListener.dataLoaded(0L, lastTicks.size(), i, instrument + " " + tick);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\business\LoadLastTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */