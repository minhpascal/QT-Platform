/*      */ package com.dukascopy.api.impl.connect;
/*      */ 
/*      */ import com.dukascopy.api.ICloseOrder;
/*      */ import com.dukascopy.api.ICurrency;
/*      */ import com.dukascopy.api.IEngine.OrderCommand;
/*      */ import com.dukascopy.api.IFillOrder;
/*      */ import com.dukascopy.api.IMessage;
/*      */ import com.dukascopy.api.IMessage.Reason;
/*      */ import com.dukascopy.api.IMessage.Type;
/*      */ import com.dukascopy.api.IOrder;
/*      */ import com.dukascopy.api.IOrder.State;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.JFException;
/*      */ import com.dukascopy.api.JFException.Error;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.impl.CloseOrder;
/*      */ import com.dukascopy.api.impl.connect.validation.IOrderValidator;
/*      */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*      */ import com.dukascopy.charts.data.orders.ExposureData;
/*      */ import com.dukascopy.charts.data.orders.OrdersProvider;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*      */ import com.dukascopy.dds2.greed.util.CurrencyConverter;
/*      */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*      */ import com.dukascopy.dds2.greed.util.ProtocolUtils;
/*      */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*      */ import com.dukascopy.dds3.transport.msg.types.NotificationMessageCode;
/*      */ import com.dukascopy.dds3.transport.msg.types.OrderDirection;
/*      */ import com.dukascopy.dds3.transport.msg.types.OrderSide;
/*      */ import com.dukascopy.dds3.transport.msg.types.OrderState;
/*      */ import com.dukascopy.dds3.transport.msg.types.StopDirection;
/*      */ import com.dukascopy.dds4.transport.client.TransportClient;
/*      */ import com.dukascopy.dds4.transport.msg.system.ErrorResponseMessage;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.RoundingMode;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ public class PlatformOrderImpl implements IOrder, Cloneable, com.dukascopy.api.impl.execution.ScienceWaitForUpdate
/*      */ {
/*   57 */   private static final Logger LOGGER = LoggerFactory.getLogger(PlatformOrderImpl.class);
/*      */   
/*   59 */   private JForexTaskManager<?, ?, ?> taskManager = null;
/*      */   
/*   61 */   String comment = null;
/*      */   
/*   63 */   Instrument instrument = null;
/*      */   
/*   65 */   private double originalAmount = 0.0D;
/*      */   
/*   67 */   double requestedAmount = 0.0D;
/*      */   
/*   69 */   double filledAmount = 0.0D;
/*      */   
/*   71 */   double filledAmountInitial = 0.0D;
/*      */   
/*   73 */   String label = null;
/*      */   
/*   75 */   double tpPrice = 0.0D;
/*      */   
/*   77 */   double slPrice = 0.0D;
/*      */   
/*   79 */   OfferSide slSide = null;
/*      */   
/*   81 */   double slTrailStep = 0.0D;
/*      */   
/*   83 */   double openPrice = 0.0D;
/*      */   
/*   85 */   double slippage = NaN.0D;
/*      */   
/*   87 */   double closePrice = 0.0D;
/*      */   
/*   89 */   double commission = 0.0D;
/*      */   
/*   91 */   private IOrder.State state = IOrder.State.CREATED;
/*      */   
/*   93 */   String groupId = null;
/*      */   
/*   95 */   String openingOrderId = null;
/*   96 */   String pendingOrderId = null;
/*   97 */   IEngine.OrderCommand pendingOrderCommand = null;
/*      */   String parentOrderId;
/*   99 */   String slOrderId = null;
/*  100 */   String tpOrderId = null;
/*      */   
/*  102 */   long goodTillTime = 0L;
/*      */   
/*  104 */   long creationTime = 0L;
/*      */   
/*  106 */   long fillTime = 0L;
/*      */   
/*  108 */   long closeTime = 0L;
/*      */   
/*  110 */   IEngine.OrderCommand orderCommand = null;
/*      */   
/*  112 */   long localCreationTime = 0L;
/*      */   
/*  114 */   private volatile boolean updated = true;
/*      */   private volatile IMessage updatedMessage;
/*      */   private boolean awaitingResubmit;
/*      */   private Map<String, OrderMessageExt> ordersToAttach;
/*      */   
/*      */   public static enum ServerRequest
/*      */   {
/*  121 */     NONE,  SUBMIT,  SET_REQ_AMOUNT,  SET_OPEN_PRICE,  CLOSE,  SET_EXPIRATION,  SET_SL,  SET_TP,  MERGE_SOURCE,  MERGE_TARGET,  CANCEL_ORDER,  SET_LABEL;
/*      */     
/*      */     private ServerRequest() {} }
/*  124 */   ServerRequest lastServerRequest = ServerRequest.NONE;
/*      */   
/*      */   private long stopLossChangeTime;
/*      */   
/*      */   private long takeProfitChangeTime;
/*      */   
/*      */   private long requestedAmountChangeTime;
/*      */   
/*      */   private long labelChangeTime;
/*      */   
/*      */   private long openPriceChangeTime;
/*      */   
/*      */   private long closeAttemptTime;
/*      */   private long goodTillTimeChangeTime;
/*  138 */   private static final long GTC_THRESHOLD = TimeUnit.DAYS.toMillis(18250L);
/*  139 */   private static final ResponseMessageGenerator responseMessageGenerator = new ResponseMessageGenerator();
/*      */   
/*      */   private boolean closedBySL;
/*      */   private boolean closedByTP;
/*      */   private final List<IFillOrder> fillHistory;
/*      */   private final List<ICloseOrder> closeHistory;
/*      */   
/*      */   public void setLastServerRequest(ServerRequest lastServerRequest)
/*      */   {
/*  148 */     this.lastServerRequest = lastServerRequest;
/*      */   }
/*      */   
/*      */   public PlatformOrderImpl(JForexTaskManager<?, ?, ?> taskManager) {
/*  152 */     this.taskManager = taskManager;
/*  153 */     this.localCreationTime = System.currentTimeMillis();
/*  154 */     this.fillHistory = Collections.synchronizedList(new ArrayList());
/*  155 */     this.closeHistory = Collections.synchronizedList(new ArrayList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PlatformOrderImpl(JForexTaskManager<?, ?, ?> taskManager, String comment, Instrument instrument, double requestedAmount, double filledAmount, String label, double tpPrice, double slPrice, OfferSide slSide, double slTrailStep, double openPrice, double closePrice, IOrder.State state, String groupId, String openingOrderId, String pendingOrderId, IEngine.OrderCommand pendingOrderCommand, String slOrderId, String tpOrderId, long goodTillTime, long creationTime, long fillTime, long closeTime, IEngine.OrderCommand orderCommand, double commission, List<IFillOrder> fillHistory, List<ICloseOrder> closeHistory)
/*      */   {
/*  187 */     this.taskManager = taskManager;
/*  188 */     this.comment = comment;
/*  189 */     this.instrument = instrument;
/*  190 */     this.requestedAmount = requestedAmount;
/*  191 */     this.filledAmount = filledAmount;
/*  192 */     this.filledAmountInitial = filledAmount;
/*  193 */     this.label = label;
/*  194 */     this.tpPrice = tpPrice;
/*  195 */     this.slPrice = slPrice;
/*  196 */     this.slSide = slSide;
/*  197 */     this.slTrailStep = slTrailStep;
/*  198 */     this.openPrice = openPrice;
/*  199 */     this.closePrice = closePrice;
/*  200 */     this.state = state;
/*  201 */     this.groupId = groupId;
/*  202 */     this.openingOrderId = openingOrderId;
/*  203 */     this.pendingOrderId = pendingOrderId;
/*  204 */     this.pendingOrderCommand = pendingOrderCommand;
/*  205 */     this.slOrderId = slOrderId;
/*  206 */     this.tpOrderId = tpOrderId;
/*  207 */     this.goodTillTime = goodTillTime;
/*  208 */     this.creationTime = creationTime;
/*  209 */     this.fillTime = fillTime;
/*  210 */     this.closeTime = closeTime;
/*  211 */     this.orderCommand = orderCommand;
/*  212 */     this.localCreationTime = System.currentTimeMillis();
/*  213 */     this.commission = commission;
/*  214 */     this.fillHistory = Collections.synchronizedList(fillHistory);
/*  215 */     this.closeHistory = Collections.synchronizedList(closeHistory);
/*      */   }
/*      */   
/*      */   public void setRequestedAmount(double amount) throws JFException {
/*  219 */     amount = StratUtils.round(amount, 8);
/*      */     
/*  221 */     String warning = this.taskManager.getOrderValidator().validateRequestedAmount(this, amount, this.requestedAmountChangeTime, this.openingOrderId, this.pendingOrderId);
/*  222 */     if (checkWarning(warning)) {
/*  223 */       return;
/*      */     }
/*  225 */     this.requestedAmountChangeTime = System.currentTimeMillis();
/*      */     
/*  227 */     if (amount == 0.0D)
/*      */     {
/*  229 */       this.lastServerRequest = ServerRequest.CANCEL_ORDER;
/*  230 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*      */       
/*  232 */       OrderMessage om = JForexAPI.cancelOrder(this.taskManager, this.label, this.instrument, getGroupId(), this.pendingOrderId, this.parentOrderId);
/*  233 */       if (LOGGER.isDebugEnabled()) {
/*  234 */         LOGGER.debug("Canceling pending order [" + om + "]");
/*      */       }
/*  236 */       sendRequest(transportClient, om);
/*  237 */       DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  238 */       format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */       
/*      */ 
/*  241 */       NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Cancelling order #" + this.pendingOrderId + " " + (this.orderCommand == IEngine.OrderCommand.PLACE_OFFER ? "PLACE OFFER" : this.orderCommand == IEngine.OrderCommand.PLACE_BID ? "PLACE BID" : new StringBuilder().append("ENTRY ").append(isLong() ? "BUY" : "SELL").toString()) + " " + BigDecimal.valueOf(getRequestedAmount()).subtract(BigDecimal.valueOf(getAmount())).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ " + ((this.orderCommand != IEngine.OrderCommand.PLACE_BID) && (this.orderCommand != IEngine.OrderCommand.PLACE_OFFER) ? "LIMIT " + (this.orderCommand.isLong() ? BigDecimal.valueOf(this.openPrice).add(BigDecimal.valueOf(this.slippage)).toPlainString() : BigDecimal.valueOf(this.openPrice).subtract(BigDecimal.valueOf(this.slippage)).toPlainString()) : Double.isNaN(this.slippage) ? "MKT" : BigDecimal.valueOf(this.openPrice).toPlainString()) + ((this.orderCommand == IEngine.OrderCommand.PLACE_BID) || (this.orderCommand == IEngine.OrderCommand.PLACE_OFFER) ? " EXPIRES:" + (this.goodTillTime == 0L ? "GTC" : format.format(Long.valueOf(this.goodTillTime))) : new StringBuilder().append(" IF ").append((this.orderCommand == IEngine.OrderCommand.BUYLIMIT) || (this.orderCommand == IEngine.OrderCommand.BUYSTOP) || (this.orderCommand == IEngine.OrderCommand.SELLLIMIT_BYASK) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "ASK" : "BID").append(" ").append((this.orderCommand == IEngine.OrderCommand.BUYLIMIT) || (this.orderCommand == IEngine.OrderCommand.BUYLIMIT_BYBID) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "<=" : "=>").append(" ").append(BigDecimal.valueOf(this.openPrice).toPlainString()).toString()) + " at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  255 */       this.lastServerRequest = ServerRequest.SET_REQ_AMOUNT;
/*  256 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*  257 */       OrderMessage om = JForexAPI.modifyAmount(this.taskManager, this.instrument, this.label, getGroupId(), this.pendingOrderId, amount, isLong());
/*  258 */       if (LOGGER.isDebugEnabled()) {
/*  259 */         LOGGER.debug("Changing amount of pending order [" + om + "]");
/*      */       }
/*  261 */       sendRequest(transportClient, om);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setLabel(String newLabel) throws JFException
/*      */   {
/*  267 */     IOrderValidator orderValidator = this.taskManager.getOrderValidator();
/*  268 */     PlatformOrderImpl existentOrder = this.taskManager.getOrdersInternalCollection().getOrderByLabel(newLabel);
/*  269 */     if (existentOrder != null) {
/*  270 */       throw new JFException(JFException.Error.LABEL_NOT_UNIQUE, "Label not unique. (Order already exists) [" + newLabel + "]" + ":" + existentOrder.toStringDetail());
/*      */     }
/*  272 */     newLabel = orderValidator.validateLabel(newLabel);
/*  273 */     String warning = orderValidator.validateLabel(this, newLabel, this.labelChangeTime, getAmount() == getRequestedAmount(), this.openingOrderId, this.pendingOrderId);
/*  274 */     if (checkWarning(warning)) {
/*  275 */       return;
/*      */     }
/*  277 */     this.labelChangeTime = System.currentTimeMillis();
/*      */     
/*  279 */     this.lastServerRequest = ServerRequest.SET_LABEL;
/*  280 */     TransportClient transportClient = this.taskManager.getTransportClient();
/*      */     
/*  282 */     OrderMessage om = JForexAPI.modifyLabel(this.taskManager, this.instrument, newLabel, getGroupId(), this.pendingOrderId, getRequestedAmount(), isLong());
/*  283 */     if (LOGGER.isDebugEnabled()) {
/*  284 */       LOGGER.debug("Changing label of pending order [" + om + "]");
/*      */     }
/*  286 */     sendRequest(transportClient, om);
/*      */   }
/*      */   
/*      */   public void setOpenPrice(double price) throws JFException {
/*  290 */     String warning = this.taskManager.getOrderValidator().validateOpenPrice(this, price, this.openPriceChangeTime, getAmount() == getRequestedAmount(), this.openingOrderId);
/*  291 */     if (checkWarning(warning)) {
/*  292 */       return;
/*      */     }
/*  294 */     this.openPriceChangeTime = System.currentTimeMillis();
/*      */     
/*  296 */     price = StratUtils.round(price, 7);
/*  297 */     this.lastServerRequest = ServerRequest.SET_OPEN_PRICE;
/*  298 */     TransportClient transportClient = this.taskManager.getTransportClient();
/*      */     
/*  300 */     IEngine.OrderCommand currentOrderCommand = getOrderCommand();
/*  301 */     String currentOrderId = this.openingOrderId;
/*  302 */     double currentAmount = getAmount();
/*  303 */     if ((!ObjectUtils.isNullOrEmpty(this.pendingOrderId)) && (!ObjectUtils.isNullOrEmpty(this.pendingOrderCommand))) {
/*  304 */       currentOrderCommand = this.pendingOrderCommand;
/*  305 */       currentOrderId = this.pendingOrderId;
/*  306 */       currentAmount = this.requestedAmount - this.filledAmount;
/*      */     }
/*  308 */     currentAmount = StratUtils.round(currentAmount, 8);
/*  309 */     if (JForexAPI.isPlaceBidOffer(currentOrderCommand)) {
/*  310 */       OrderMessage om = JForexAPI.modifyBidOfferPrice(this.taskManager, this.instrument, this.label, getGroupId(), currentOrderId, price, currentAmount, isLong());
/*  311 */       if (LOGGER.isDebugEnabled()) {
/*  312 */         LOGGER.debug("Changing price of bid/offer order [" + om + "]");
/*      */       }
/*  314 */       sendRequest(transportClient, om);
/*      */     } else {
/*  316 */       OrderMessage om = JForexAPI.modifyPrice(this.taskManager, this.label, this.instrument, getGroupId(), currentOrderId, price, currentAmount, OrderDirection.OPEN, JForexAPI.getStopDirection(currentOrderCommand), isLong());
/*      */       
/*  318 */       if (LOGGER.isDebugEnabled()) {
/*  319 */         LOGGER.debug("Changing price of pending order [" + om + "]");
/*      */       }
/*  321 */       sendRequest(transportClient, om);
/*      */     }
/*      */   }
/*      */   
/*      */   public void close(double amount, double price, double slippage) throws JFException {
/*  326 */     String warning = this.taskManager.getOrderValidator().validateClose(this, amount, price, slippage, this.closeAttemptTime);
/*  327 */     if (checkWarning(warning)) {
/*  328 */       return;
/*      */     }
/*  330 */     if (Double.compare(amount, 0.0D) > 0) {
/*  331 */       if (Double.compare(getAmount(), 1.0E-6D) <= 0)
/*      */       {
/*  333 */         amount = 0.0D;
/*      */       }
/*      */       else {
/*  336 */         RoundingMode roundingMode = RoundingMode.HALF_EVEN;
/*  337 */         if (Double.compare(amount, 1.0E-6D) < 0) {
/*  338 */           roundingMode = RoundingMode.CEILING;
/*      */         }
/*  340 */         amount = new BigDecimal(amount).setScale(6, roundingMode).doubleValue();
/*      */       }
/*      */     }
/*  343 */     if ((amount == 0.0D) || (amount == getAmount()) || (getState() == IOrder.State.OPENED))
/*      */     {
/*  345 */       this.closeAttemptTime = System.currentTimeMillis();
/*      */     }
/*      */     
/*      */ 
/*  349 */     if (slippage < 0.0D) {
/*  350 */       slippage = 5.0D;
/*      */     }
/*      */     
/*      */ 
/*  354 */     slippage = StratUtils.round(slippage * this.instrument.getPipValue(), 7);
/*  355 */     price = StratUtils.round(price, 7);
/*      */     
/*  357 */     if (getState() == IOrder.State.OPENED) {
/*  358 */       this.lastServerRequest = ServerRequest.CLOSE;
/*  359 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*      */       
/*  361 */       OrderMessage om = JForexAPI.cancelOrder(this.taskManager, this.label, this.instrument, getGroupId(), this.openingOrderId, this.parentOrderId);
/*  362 */       if (LOGGER.isDebugEnabled()) {
/*  363 */         LOGGER.debug("Canceling pending order order [" + om + "]");
/*      */       }
/*  365 */       sendRequest(transportClient, om);
/*      */       
/*  367 */       DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  368 */       format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */       
/*  370 */       NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Cancelling order #" + this.openingOrderId + " " + (this.orderCommand == IEngine.OrderCommand.PLACE_OFFER ? "PLACE OFFER" : this.orderCommand == IEngine.OrderCommand.PLACE_BID ? "PLACE BID" : new StringBuilder().append("ENTRY ").append(isLong() ? "BUY" : "SELL").toString()) + " " + BigDecimal.valueOf(getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ " + ((this.orderCommand != IEngine.OrderCommand.PLACE_BID) && (this.orderCommand != IEngine.OrderCommand.PLACE_OFFER) ? "LIMIT " + (this.orderCommand.isLong() ? BigDecimal.valueOf(this.openPrice).add(BigDecimal.valueOf(slippage)).toPlainString() : BigDecimal.valueOf(this.openPrice).subtract(BigDecimal.valueOf(slippage)).toPlainString()) : Double.isNaN(slippage) ? "MKT" : BigDecimal.valueOf(this.openPrice).toPlainString()) + ((this.orderCommand == IEngine.OrderCommand.PLACE_BID) || (this.orderCommand == IEngine.OrderCommand.PLACE_OFFER) ? " EXPIRES:" + (this.goodTillTime == 0L ? "GTC" : format.format(Long.valueOf(this.goodTillTime))) : new StringBuilder().append(" IF ").append((this.orderCommand == IEngine.OrderCommand.BUYLIMIT) || (this.orderCommand == IEngine.OrderCommand.BUYSTOP) || (this.orderCommand == IEngine.OrderCommand.SELLLIMIT_BYASK) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "ASK" : "BID").append(" ").append((this.orderCommand == IEngine.OrderCommand.BUYLIMIT) || (this.orderCommand == IEngine.OrderCommand.BUYLIMIT_BYBID) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "<=" : "=>").append(" ").append(BigDecimal.valueOf(this.openPrice).toPlainString()).toString()) + " at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  383 */     else if (getState() == IOrder.State.FILLED) {
/*  384 */       if ((amount == 0.0D) && (this.requestedAmount > this.filledAmount)) {
/*  385 */         TransportClient transportClient = this.taskManager.getTransportClient();
/*  386 */         OrderMessage om = JForexAPI.cancelOrder(this.taskManager, this.label, this.instrument, getGroupId(), this.pendingOrderId, this.parentOrderId);
/*  387 */         if (LOGGER.isDebugEnabled()) {
/*  388 */           LOGGER.debug("Canceling pending part of partially filled order [" + om + "]");
/*      */         }
/*  390 */         sendRequest(transportClient, om);
/*  391 */         DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  392 */         format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  393 */         NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Cancelling order #" + this.pendingOrderId + " " + (this.orderCommand == IEngine.OrderCommand.PLACE_OFFER ? "PLACE OFFER" : this.orderCommand == IEngine.OrderCommand.PLACE_BID ? "PLACE BID" : new StringBuilder().append("ENTRY ").append(isLong() ? "BUY" : "SELL").toString()) + " " + BigDecimal.valueOf(getRequestedAmount()).subtract(BigDecimal.valueOf(getAmount())).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ " + ((this.orderCommand != IEngine.OrderCommand.PLACE_BID) && (this.orderCommand != IEngine.OrderCommand.PLACE_OFFER) ? "LIMIT " + (this.orderCommand.isLong() ? BigDecimal.valueOf(this.openPrice).add(BigDecimal.valueOf(slippage)).toPlainString() : BigDecimal.valueOf(this.openPrice).subtract(BigDecimal.valueOf(slippage)).toPlainString()) : Double.isNaN(slippage) ? "MKT" : BigDecimal.valueOf(this.openPrice).toPlainString()) + ((this.orderCommand == IEngine.OrderCommand.PLACE_BID) || (this.orderCommand == IEngine.OrderCommand.PLACE_OFFER) ? " EXPIRES:" + (this.goodTillTime == 0L ? "GTC" : format.format(Long.valueOf(this.goodTillTime))) : new StringBuilder().append(" IF ").append((this.orderCommand == IEngine.OrderCommand.BUYLIMIT) || (this.orderCommand == IEngine.OrderCommand.BUYSTOP) || (this.orderCommand == IEngine.OrderCommand.SELLLIMIT_BYASK) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "ASK" : "BID").append(" ").append((this.orderCommand == IEngine.OrderCommand.BUYLIMIT) || (this.orderCommand == IEngine.OrderCommand.BUYLIMIT_BYBID) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP) || (this.orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "<=" : "=>").append(" ").append(BigDecimal.valueOf(this.openPrice).toPlainString()).toString()) + " at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  406 */       else if (this.taskManager.isGlobal()) {
/*  407 */         throw new JFException("Cannot close orders on global accounts. Please open opposite order instead");
/*      */       }
/*      */       
/*  410 */       if (!this.taskManager.isGlobal()) {
/*  411 */         this.lastServerRequest = ServerRequest.CLOSE;
/*  412 */         TransportClient transportClient = this.taskManager.getTransportClient();
/*  413 */         OrderMessage om = JForexAPI.closePosition(this.taskManager, getOrderCommand(), getInstrument(), getGroupId(), this.label, amount == 0.0D ? getAmount() : amount, price, slippage);
/*  414 */         if (LOGGER.isDebugEnabled()) {
/*  415 */           LOGGER.debug("Closing order [" + om + "]");
/*      */         }
/*  417 */         sendRequest(transportClient, om);
/*  418 */         DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  419 */         format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  420 */         NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Closing order " + (isLong() ? "SELL" : "BUY") + " " + BigDecimal.valueOf(getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ MKT" + " is sent at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  426 */       throw new JFException(JFException.Error.ORDER_STATE_IMMUTABLE, " state is " + getState());
/*      */     }
/*      */   }
/*      */   
/*      */   public void close(double amount, double price) throws JFException {
/*  431 */     close(amount, price, -1.0D);
/*      */   }
/*      */   
/*      */   public void close(double amount) throws JFException {
/*  435 */     close(amount, 0.0D);
/*      */   }
/*      */   
/*      */   public void close() throws JFException {
/*  439 */     close(0.0D);
/*      */   }
/*      */   
/*      */   public double getAmount() {
/*  443 */     if ((this.state == IOrder.State.CREATED) || (this.state == IOrder.State.CANCELED) || (this.state == IOrder.State.OPENED))
/*  444 */       return this.requestedAmount;
/*  445 */     if (this.state == IOrder.State.CLOSED) {
/*  446 */       return this.filledAmountInitial;
/*      */     }
/*      */     
/*  449 */     return this.filledAmount;
/*      */   }
/*      */   
/*      */   public double getClosePrice()
/*      */   {
/*  454 */     return this.closePrice;
/*      */   }
/*      */   
/*      */   public String getComment() {
/*  458 */     return this.comment;
/*      */   }
/*      */   
/*      */   public long getCreationTime() {
/*  462 */     return this.creationTime;
/*      */   }
/*      */   
/*      */   public long getCloseTime() {
/*  466 */     return this.closeTime;
/*      */   }
/*      */   
/*      */   public long getFillTime() {
/*  470 */     return this.fillTime;
/*      */   }
/*      */   
/*      */   public Instrument getInstrument() {
/*  474 */     return this.instrument;
/*      */   }
/*      */   
/*      */   public String getLabel() {
/*  478 */     return this.label;
/*      */   }
/*      */   
/*      */   public double getOpenPrice() {
/*  482 */     return this.openPrice;
/*      */   }
/*      */   
/*      */   public IOrder.State getState() {
/*  486 */     return this.state;
/*      */   }
/*      */   
/*      */   public void setState(IOrder.State state) {
/*  490 */     this.state = state;
/*      */   }
/*      */   
/*      */   public double getStopLossPrice() {
/*  494 */     return this.slPrice;
/*      */   }
/*      */   
/*      */   public double getTakeProfitPrice() {
/*  498 */     return this.tpPrice;
/*      */   }
/*      */   
/*      */   public OfferSide getStopLossSide() {
/*  502 */     return this.slSide;
/*      */   }
/*      */   
/*      */   public double getTrailingStep() {
/*  506 */     return this.slTrailStep;
/*      */   }
/*      */   
/*      */   public String getId() {
/*  510 */     return this.groupId;
/*      */   }
/*      */   
/*      */   private String getGroupId() {
/*  514 */     if (this.taskManager.isGlobal()) {
/*  515 */       return this.taskManager.getUserId() + this.instrument.toString();
/*      */     }
/*  517 */     return this.groupId;
/*      */   }
/*      */   
/*      */   public double getRequestedAmount()
/*      */   {
/*  522 */     return this.requestedAmount;
/*      */   }
/*      */   
/*      */   public IEngine.OrderCommand getOrderCommand() {
/*  526 */     return this.orderCommand;
/*      */   }
/*      */   
/*      */   public boolean isLong() {
/*  530 */     return (this.orderCommand != null) && (this.orderCommand.isLong());
/*      */   }
/*      */   
/*      */   public void setGoodTillTime(long goodTillTime) throws JFException {
/*  534 */     String warning = this.taskManager.getOrderValidator().validateGoodTillTime(this, goodTillTime, this.goodTillTimeChangeTime, getAmount() == getRequestedAmount(), this.openingOrderId);
/*  535 */     if (checkWarning(warning)) {
/*  536 */       return;
/*      */     }
/*  538 */     this.goodTillTimeChangeTime = System.currentTimeMillis();
/*      */     
/*  540 */     this.lastServerRequest = ServerRequest.SET_EXPIRATION;
/*  541 */     TransportClient transportClient = this.taskManager.getTransportClient();
/*      */     
/*  543 */     OrderState state = JForexAPI.isPlaceBidOffer(this.orderCommand) ? OrderState.EXECUTING : OrderState.PENDING;
/*      */     
/*      */ 
/*  546 */     OrderMessage om = JForexAPI.modifyGTT(this.taskManager, this.instrument, state, this.label, getAmount(), getGroupId(), this.openingOrderId, goodTillTime > 0L ? goodTillTime : -1L, isLong());
/*  547 */     if (LOGGER.isDebugEnabled()) {
/*  548 */       LOGGER.debug("Changing expiration time of bid/offer order [" + om + "]");
/*      */     }
/*  550 */     sendRequest(transportClient, om);
/*      */   }
/*      */   
/*      */   public long getGoodTillTime()
/*      */   {
/*  555 */     return this.goodTillTime > System.currentTimeMillis() + TimeUnit.DAYS.toMillis(32850L) ? 0L : this.goodTillTime;
/*      */   }
/*      */   
/*      */   public void setStopLossPrice(double price)
/*      */     throws JFException
/*      */   {
/*  561 */     setStopLossPrice(price, isLong() ? OfferSide.BID : OfferSide.ASK, this.slTrailStep);
/*      */   }
/*      */   
/*      */   public void setStopLossPrice(double price, OfferSide side) throws JFException {
/*  565 */     setStopLossPrice(price, side, this.slTrailStep);
/*      */   }
/*      */   
/*      */   public void setStopLossPrice(double price, OfferSide side, double trailingStepInPips) throws JFException {
/*  569 */     price = StratUtils.round(price, 7);
/*  570 */     trailingStepInPips = StratUtils.round(trailingStepInPips, 7);
/*  571 */     String warning = this.taskManager.getOrderValidator().validateStopLossPrice(this, price, side, trailingStepInPips, this.taskManager.isGlobal(), this.stopLossChangeTime);
/*      */     
/*  573 */     if (checkWarning(warning)) {
/*  574 */       return;
/*      */     }
/*  576 */     this.stopLossChangeTime = System.currentTimeMillis();
/*      */     
/*      */ 
/*  579 */     if (price > 0.0D)
/*      */     {
/*  581 */       this.lastServerRequest = ServerRequest.SET_SL;
/*      */       
/*  583 */       double absoluteTrailingPrice = 0.0D;
/*  584 */       if (trailingStepInPips > 0.0D) {
/*  585 */         absoluteTrailingPrice = StratUtils.round(trailingStepInPips * this.instrument.getPipValue(), 7);
/*      */       }
/*  587 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*  588 */       if (this.slPrice > 0.0D)
/*      */       {
/*  590 */         OrderMessage om = JForexAPI.modifyStopLoss(this.taskManager, this.label, this.instrument, getGroupId(), this.slOrderId, isLong(), price, getAmount(), side, absoluteTrailingPrice);
/*      */         
/*  592 */         if (LOGGER.isDebugEnabled()) {
/*  593 */           LOGGER.debug("Modifying stop loss order [" + om + "]");
/*      */         }
/*  595 */         sendRequest(transportClient, om);
/*      */       } else {
/*  597 */         OrderMessage om = JForexAPI.createStopLoss(this.taskManager, this.label, getGroupId(), this.openingOrderId, this.instrument, price, getAmount(), absoluteTrailingPrice, isLong(), side);
/*  598 */         if (LOGGER.isDebugEnabled()) {
/*  599 */           LOGGER.debug("Submitting stop loss order [" + om + "]");
/*      */         }
/*  601 */         sendRequest(transportClient, om);
/*  602 */         DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  603 */         format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  604 */         NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Order STOP LOSS " + (isLong() ? "SELL" : "BUY") + " " + BigDecimal.valueOf(getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ MKT IF " + (side == null ? "ASK" : isLong() ? "BID" : side.name()) + (isLong() ? " <=" : " =>") + " " + BigDecimal.valueOf(price).toPlainString() + " is sent at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*  612 */     else if (this.slOrderId != null)
/*      */     {
/*  614 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*  615 */       OrderMessage om = JForexAPI.cancelOrder(this.taskManager, this.label, this.instrument, getGroupId(), this.slOrderId, this.parentOrderId);
/*  616 */       if (LOGGER.isDebugEnabled()) {
/*  617 */         LOGGER.debug("Canceling stop loss order [" + om + "]");
/*      */       }
/*  619 */       sendRequest(transportClient, om);
/*  620 */       DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  621 */       format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  622 */       NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Canceling order #" + this.slOrderId + " STOP LOSS " + (isLong() ? "SELL" : "BUY") + " " + BigDecimal.valueOf(getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ MKT IF " + this.slSide.name() + (isLong() ? " <=" : " =>") + " " + BigDecimal.valueOf(this.slPrice).toPlainString() + " at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTakeProfitPrice(double price)
/*      */     throws JFException
/*      */   {
/*  632 */     price = StratUtils.round(price, 7);
/*  633 */     String warning = this.taskManager.getOrderValidator().validateTakeProfitPrice(this, price, isLong() ? OfferSide.BID : OfferSide.ASK, this.taskManager.isGlobal(), this.takeProfitChangeTime);
/*      */     
/*  635 */     if (checkWarning(warning)) {
/*  636 */       return;
/*      */     }
/*      */     
/*  639 */     this.takeProfitChangeTime = System.currentTimeMillis();
/*      */     
/*  641 */     price = StratUtils.round(price, 7);
/*  642 */     TransportClient transportClient = this.taskManager.getTransportClient();
/*  643 */     if (price > 0.0D)
/*      */     {
/*  645 */       this.lastServerRequest = ServerRequest.SET_TP;
/*  646 */       if (this.tpPrice > 0.0D) {
/*  647 */         OrderMessage om = JForexAPI.modifyTakeProfit(this.taskManager, this.label, this.instrument, getGroupId(), this.tpOrderId, isLong(), price, getAmount());
/*  648 */         if (LOGGER.isDebugEnabled()) {
/*  649 */           LOGGER.debug("Modifying take profit order [" + om + "]");
/*      */         }
/*  651 */         sendRequest(transportClient, om);
/*      */       }
/*      */       else {
/*  654 */         OrderMessage om = JForexAPI.createTakeProfit(this.taskManager, this.label, getGroupId(), this.openingOrderId, this.instrument, price, getAmount(), isLong());
/*  655 */         if (LOGGER.isDebugEnabled()) {
/*  656 */           LOGGER.debug("Submitting take profit order [" + om + "]");
/*      */         }
/*  658 */         sendRequest(transportClient, om);
/*  659 */         DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  660 */         format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  661 */         NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Order TAKE PROFIT " + (isLong() ? "SELL" : "BUY") + " " + BigDecimal.valueOf(getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ LIMIT IF " + (isLong() ? "BID =>" : "ASK <=") + " " + BigDecimal.valueOf(price).toPlainString() + " is sent at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*  668 */     else if (this.tpOrderId != null) {
/*  669 */       OrderMessage om = JForexAPI.cancelOrder(this.taskManager, this.label, this.instrument, getGroupId(), this.tpOrderId, this.parentOrderId);
/*  670 */       if (LOGGER.isDebugEnabled()) {
/*  671 */         LOGGER.debug("Canceling take profit order [" + om + "]");
/*      */       }
/*  673 */       sendRequest(transportClient, om);
/*  674 */       DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  675 */       format.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  676 */       NotificationUtilsProvider.getNotificationUtils().postInfoMessage("Cancelling order #" + this.tpOrderId + " TAKE PROFIT " + (isLong() ? "SELL" : "BUY") + " " + BigDecimal.valueOf(getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString() + " " + this.instrument + " @ LIMIT IF " + (isLong() ? "BID =>" : "ASK <=") + " " + BigDecimal.valueOf(this.slPrice).toPlainString() + " at " + format.format(Long.valueOf(System.currentTimeMillis())) + " by the strategy \"" + this.taskManager.getJFRunnableName() + "\": from the " + (this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isStopLoss(OrderMessage orderMessage)
/*      */   {
/*  693 */     if ((OrderDirection.CLOSE == orderMessage.getDirection()) && (null != orderMessage.getPriceStop())) {
/*  694 */       if (OrderSide.SELL == orderMessage.getSide()) {
/*  695 */         return (StopDirection.LESS_ASK == orderMessage.getStopDirection()) || (StopDirection.LESS_BID == orderMessage.getStopDirection());
/*      */       }
/*  697 */       return (StopDirection.GREATER_ASK == orderMessage.getStopDirection()) || (StopDirection.GREATER_BID == orderMessage.getStopDirection());
/*      */     }
/*      */     
/*  700 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isTakeProfit(OrderMessage orderMessage)
/*      */   {
/*  711 */     if ((OrderDirection.CLOSE == orderMessage.getDirection()) && (null != orderMessage.getPriceStop())) {
/*  712 */       if (OrderSide.BUY == orderMessage.getSide()) {
/*  713 */         return (StopDirection.LESS_ASK == orderMessage.getStopDirection()) || (StopDirection.LESS_BID == orderMessage.getStopDirection());
/*      */       }
/*  715 */       return (StopDirection.GREATER_ASK == orderMessage.getStopDirection()) || (StopDirection.GREATER_BID == orderMessage.getStopDirection());
/*      */     }
/*      */     
/*  718 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, OrderMessageExt> getOrdersToAttach()
/*      */   {
/*  724 */     return this.ordersToAttach;
/*      */   }
/*      */   
/*      */   public String getOpeningOrderId() {
/*  728 */     return this.openingOrderId;
/*      */   }
/*      */   
/*      */   public PlatformMessageImpl update(OrderGroupMessage groupMessage)
/*      */   {
/*  733 */     if (LOGGER.isDebugEnabled()) {
/*  734 */       LOGGER.debug("processing OrderGroupMessage [" + groupMessage + "]");
/*      */     }
/*      */     
/*  737 */     groupMessage = new OrderGroupMessage(groupMessage);
/*      */     
/*      */ 
/*      */ 
/*  741 */     if (this.label == null) {
/*  742 */       this.label = extractLabel(groupMessage);
/*      */     }
/*      */     
/*  745 */     OrderMessage openingOrder = null;
/*      */     
/*  747 */     OrderMessage slOrder = null;
/*      */     
/*  749 */     OrderMessage tpOrder = null;
/*  750 */     PlatformMessageImpl platformMessageImpl = null;
/*      */     
/*  752 */     this.filledAmount = 0.0D;
/*  753 */     this.pendingOrderId = null;
/*  754 */     this.pendingOrderCommand = null;
/*      */     
/*  756 */     List<OrderMessageExt> ordersList = groupMessage.getOrders();
/*  757 */     this.groupId = groupMessage.getOrderGroupId();
/*      */     
/*  759 */     if (this.instrument == null) {
/*  760 */       this.instrument = Instrument.fromString(ProtocolUtils.getInstrument(groupMessage));
/*      */     }
/*      */     
/*  763 */     if (this.taskManager.isGlobal()) {
/*  764 */       ExposureData exposure = OrdersProvider.getInstance().getExposureForInstrument(this.instrument);
/*  765 */       if (exposure.commission != null) {
/*  766 */         this.commission = exposure.commission.doubleValue();
/*      */       }
/*      */     }
/*  769 */     else if (groupMessage.getSummaryCommission() != null) {
/*  770 */       this.commission = groupMessage.getSummaryCommission().doubleValue();
/*      */     }
/*      */     
/*  773 */     Map<String, Boolean> fakeParts = new HashMap();
/*  774 */     if (!ordersList.isEmpty())
/*      */     {
/*  776 */       if (ordersList.size() > 1) {
/*  777 */         Collections.sort(ordersList, this.taskManager.getOrderMessageComparator());
/*      */       }
/*  779 */       groupMessage.setOrders(ordersList);
/*  780 */       if (this.taskManager.isGlobal())
/*      */       {
/*  782 */         for (OrderMessageExt orderMessage : groupMessage.getOrders()) {
/*  783 */           OrderState orderState = orderMessage.getState();
/*  784 */           if (orderMessage.getDirection() == OrderDirection.OPEN) {
/*  785 */             if (orderState == OrderState.FILLED)
/*      */             {
/*  787 */               BigDecimal amountPriceSum = BigDecimal.ZERO;
/*  788 */               BigDecimal amountTotal = BigDecimal.ZERO;
/*  789 */               BigDecimal price = orderMessage.getPriceClient();
/*  790 */               if (!ObjectUtils.isNullOrEmpty(this.ordersToAttach)) {
/*  791 */                 for (OrderMessage filledMessage : this.ordersToAttach.values()) {
/*  792 */                   amountPriceSum = amountPriceSum.add(filledMessage.getPriceClient().multiply(filledMessage.getAmount()));
/*  793 */                   amountTotal = amountTotal.add(filledMessage.getAmount());
/*      */                 }
/*  795 */                 amountPriceSum = amountPriceSum.add(orderMessage.getPriceClient().multiply(orderMessage.getAmount()));
/*  796 */                 price = amountPriceSum.divide(amountTotal.add(orderMessage.getAmount()), 6, 6);
/*      */               }
/*      */               
/*  799 */               if (this.ordersToAttach == null) {
/*  800 */                 this.ordersToAttach = new HashMap();
/*      */               }
/*  802 */               if (!this.ordersToAttach.containsKey(orderMessage.getOrderId())) {
/*  803 */                 this.ordersToAttach.put(orderMessage.getOrderId(), new OrderMessageExt(orderMessage));
/*      */               }
/*  805 */               orderMessage.setPriceClient(price);
/*      */               
/*  807 */               orderMessage.setAmount(orderMessage.getAmount().add(amountTotal));
/*  808 */               orderMessage.setOrigAmount(orderMessage.getOrigAmount().add(amountTotal));
/*      */               
/*  810 */               IEngine.OrderCommand orderMessageOrderCommand = detectOrderCommand(orderMessage);
/*  811 */               if ((orderMessageOrderCommand != IEngine.OrderCommand.BUY) && (orderMessageOrderCommand != IEngine.OrderCommand.SELL) && (orderMessage.getOrigAmount().subtract(orderMessage.getAmount()).compareTo(BigDecimal.ZERO) > 0)) {
/*  812 */                 OrderMessageExt pendingMessage = new OrderMessageExt(orderMessage);
/*  813 */                 pendingMessage.setAmount(orderMessage.getOrigAmount().subtract(orderMessage.getAmount()));
/*  814 */                 if (orderMessageOrderCommand.isConditional()) {
/*  815 */                   pendingMessage.setState(OrderState.PENDING);
/*      */                 } else {
/*  817 */                   pendingMessage.setState(OrderState.EXECUTING);
/*      */                 }
/*      */                 
/*  820 */                 pendingMessage.setOrderId(this.openingOrderId);
/*  821 */                 fakeParts.put(pendingMessage.getOrderId(), Boolean.valueOf(true));
/*  822 */                 List<OrderMessageExt> newOrders = new ArrayList();
/*  823 */                 newOrders.addAll(groupMessage.getOrders());
/*  824 */                 newOrders.add(pendingMessage);
/*  825 */                 groupMessage.setOrders(newOrders);
/*      */               }
/*  827 */             } else if (!ObjectUtils.isNullOrEmpty(this.ordersToAttach))
/*      */             {
/*  829 */               BigDecimal amountPriceSum = BigDecimal.ZERO;
/*  830 */               BigDecimal amountTotal = BigDecimal.ZERO;
/*  831 */               OrderMessageExt lastFilledOrder = null;
/*  832 */               for (OrderMessageExt filledMessage : this.ordersToAttach.values()) {
/*  833 */                 amountPriceSum = amountPriceSum.add(filledMessage.getPriceClient().multiply(filledMessage.getAmount()));
/*  834 */                 amountTotal = amountTotal.add(filledMessage.getAmount());
/*  835 */                 lastFilledOrder = filledMessage;
/*      */               }
/*  837 */               if (lastFilledOrder != null) {
/*  838 */                 BigDecimal price = amountPriceSum.divide(amountTotal, 6, 6);
/*  839 */                 lastFilledOrder = new OrderMessageExt(lastFilledOrder);
/*  840 */                 lastFilledOrder.setPriceClient(price);
/*  841 */                 lastFilledOrder.setAmount(amountTotal);
/*  842 */                 lastFilledOrder.setOrigAmount(amountTotal);
/*  843 */                 List<OrderMessageExt> newOrders = new ArrayList();
/*  844 */                 newOrders.add(lastFilledOrder);
/*  845 */                 newOrders.addAll(groupMessage.getOrders());
/*  846 */                 groupMessage.setOrders(newOrders);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  853 */       double calculatedRequestedAmount = 0.0D;
/*  854 */       for (OrderMessageExt orderMessage : groupMessage.getOrders()) {
/*  855 */         OrderState orderState = orderMessage.getState();
/*  856 */         if (orderMessage.getDirection() == OrderDirection.OPEN) {
/*  857 */           openingOrder = orderMessage;
/*  858 */           calculatedRequestedAmount += ProtocolUtils.getAmountInMillions(orderMessage).doubleValue();
/*      */           
/*  860 */           this.slippage = (orderMessage.getPriceTrailingLimit() == null ? NaN.0D : orderMessage.getPriceTrailingLimit().doubleValue());
/*      */           
/*  862 */           if (orderState == OrderState.EXECUTING) {
/*  863 */             if (this.state == IOrder.State.CREATED) {
/*  864 */               this.state = IOrder.State.OPENED;
/*  865 */               this.creationTime = orderMessage.getCreatedDate().getTime();
/*  866 */               String text = orderMessage.getNotes();
/*  867 */               if (this.orderCommand == null)
/*      */               {
/*  869 */                 this.orderCommand = detectOrderCommand(orderMessage);
/*      */               }
/*  871 */               if (this.orderCommand.isConditional()) {
/*  872 */                 this.openPrice = orderMessage.getPriceStop().doubleValue();
/*  873 */               } else if (JForexAPI.isPlaceBidOffer(this.orderCommand)) {
/*  874 */                 this.openPrice = openingOrder.getPriceClient().doubleValue();
/*      */               }
/*      */               
/*  877 */               platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_SUBMIT_OK, this.creationTime);
/*  878 */               LOGGER.debug("transiting order from CREATED state to OPENED as a response to EXECUTING order update message");
/*  879 */               this.closeAttemptTime = 0L;
/*  880 */               if ((this.orderCommand != IEngine.OrderCommand.BUY) && (this.orderCommand != IEngine.OrderCommand.SELL))
/*      */               {
/*  882 */                 this.lastServerRequest = ServerRequest.NONE;
/*      */               }
/*  884 */               if (orderMessage.isPlaceOffer()) {
/*  885 */                 setPendingOrderData(orderMessage);
/*      */               }
/*  887 */             } else if ((this.state == IOrder.State.OPENED) && (orderMessage.isPlaceOffer()))
/*      */             {
/*  889 */               if ((this.taskManager.isGlobal()) && (this.openingOrderId != null) && (this.openingOrderId.equals(orderMessage.getOrderId())) && (!isFakePart(orderMessage, fakeParts)))
/*      */               {
/*      */ 
/*  892 */                 this.filledAmount = this.filledAmountInitial;
/*  893 */                 setPendingOrderData(orderMessage);
/*  894 */                 return null; }
/*  895 */               if ((!this.taskManager.isGlobal()) && (groupMessage.getOrders().size() == 1) && (this.openingOrderId != null) && (this.openingOrderId.equals(orderMessage.getOrderId())) && (Math.abs(ProtocolUtils.getAmountInMillions(orderMessage).doubleValue() - this.requestedAmount) > 1.0E-6D))
/*      */               {
/*      */ 
/*      */ 
/*  899 */                 this.filledAmount = this.filledAmountInitial;
/*  900 */                 setPendingOrderData(orderMessage);
/*  901 */                 return null;
/*      */               }
/*  903 */               platformMessageImpl = checkExecTimeout(platformMessageImpl, orderMessage);
/*  904 */               double newOpenPrice = this.openPrice;
/*  905 */               if ((openingOrder.getPriceClient() != null) && (openingOrder.getPriceClient() != null)) {
/*  906 */                 newOpenPrice = openingOrder.getPriceClient().doubleValue();
/*      */               }
/*  908 */               platformMessageImpl = checkPrice(platformMessageImpl, orderMessage, newOpenPrice);
/*  909 */               switch (this.lastServerRequest) {
/*      */               case SUBMIT: 
/*      */               case SET_REQ_AMOUNT: 
/*      */               case SET_OPEN_PRICE: 
/*      */               case SET_EXPIRATION: 
/*      */               case SET_SL: 
/*      */               case SET_TP: 
/*  916 */                 this.lastServerRequest = ServerRequest.NONE;
/*      */               }
/*  918 */               setPendingOrderData(orderMessage);
/*      */             } else {
/*  920 */               if ((this.state == IOrder.State.FILLED) && (orderMessage.isPlaceOffer()) && (this.taskManager.isGlobal()) && (this.openingOrderId != null) && (this.openingOrderId.equals(orderMessage.getOrderId())) && (!isFakePart(orderMessage, fakeParts)))
/*      */               {
/*      */ 
/*  923 */                 this.filledAmount = this.filledAmountInitial;
/*  924 */                 setPendingOrderData(orderMessage);
/*  925 */                 return null; }
/*  926 */               if ((this.state == IOrder.State.FILLED) && (orderMessage.isPlaceOffer()) && (groupMessage.getOrders().size() == 1) && (!this.taskManager.isGlobal()) && (this.openingOrderId != null) && (this.openingOrderId.equals(orderMessage.getOrderId())) && (Math.abs(ProtocolUtils.getAmountInMillions(orderMessage).doubleValue() - (this.requestedAmount - this.filledAmountInitial)) > 1.0E-6D))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*  931 */                 this.filledAmount = this.filledAmountInitial;
/*  932 */                 setPendingOrderData(orderMessage);
/*  933 */                 return null; }
/*  934 */               if (this.state == IOrder.State.FILLED)
/*  935 */                 setPendingOrderData(orderMessage);
/*      */             }
/*  937 */           } else if (orderState == OrderState.FILLED)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  942 */             this.filledAmount += ProtocolUtils.getAmountInMillions(orderMessage).doubleValue();
/*      */             
/*  944 */             if (this.state == IOrder.State.OPENED) {
/*  945 */               String text = orderMessage.getNotes();
/*  946 */               long timestamp = orderMessage.getTimestamp().longValue();
/*  947 */               setFillTime(orderMessage);
/*  948 */               platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_FILL_OK, timestamp);
/*  949 */               if ((Double.compare(this.filledAmount, this.requestedAmount) == 0) && (this.requestedAmount > 0.0D)) {
/*  950 */                 platformMessageImpl.addReason(IMessage.Reason.ORDER_FULLY_FILLED);
/*      */               }
/*  952 */               LOGGER.debug("transiting order from OPENED to FILLED state as a response to FILLED order update message");
/*  953 */             } else if ((this.state == IOrder.State.CREATED) && ((this.lastServerRequest == ServerRequest.MERGE_TARGET) || (groupMessage.isOcoMerge())))
/*      */             {
/*  955 */               this.creationTime = orderMessage.getTimestamp().longValue();
/*  956 */               setFillTime(orderMessage);
/*  957 */               LOGGER.debug("transiting order from CREATED merge target to FILLED state as a response to FILLED order update message");
/*  958 */             } else if (this.state == IOrder.State.CREATED)
/*      */             {
/*  960 */               String text = orderMessage.getNotes();
/*  961 */               this.creationTime = orderMessage.getCreatedDate().getTime();
/*  962 */               setFillTime(orderMessage);
/*  963 */               platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CHANGED_OK, this.creationTime);
/*  964 */               LOGGER.debug("updating new order with data from FILLED order update message");
/*      */ 
/*      */ 
/*      */             }
/*  968 */             else if (this.filledAmountInitial > this.filledAmount)
/*      */             {
/*  970 */               if (groupMessage.getTimestamp() != null) {
/*  971 */                 this.closeTime = groupMessage.getTimestamp().longValue();
/*      */               } else {
/*  973 */                 LOGGER.warn("partial close message doesn't have timestamp set");
/*      */               }
/*  975 */               if (groupMessage.getPriceOpen() != null) {
/*  976 */                 this.closePrice = groupMessage.getPriceOpen().doubleValue();
/*      */               }
/*  978 */               addCloseOrder(orderMessage);
/*  979 */               String text = orderMessage.getNotes();
/*  980 */               platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CLOSE_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/*  981 */               LOGGER.debug("partially closing order as a response to FILLED order update message");
/*      */ 
/*      */             }
/*  984 */             else if ((this.filledAmountInitial < this.filledAmount) || (this.openPrice != orderMessage.getPriceClient().doubleValue()))
/*      */             {
/*      */ 
/*  987 */               long timestamp = orderMessage.getTimestamp().longValue();
/*  988 */               setFillTime(orderMessage);
/*  989 */               String text = orderMessage.getNotes();
/*  990 */               platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CHANGED_OK, timestamp);
/*  991 */               if ((this.filledAmountInitial < this.filledAmount) && (Double.compare(this.filledAmount, this.requestedAmount) == 0) && (this.requestedAmount > 0.0D)) {
/*  992 */                 platformMessageImpl.addReason(IMessage.Reason.ORDER_FULLY_FILLED);
/*      */               }
/*  994 */               if (this.openPrice != orderMessage.getPriceClient().doubleValue()) {
/*  995 */                 platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_PRICE);
/*      */               }
/*  997 */               LOGGER.debug("updating new order with data from FILLED order update message");
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1003 */             if ((this.filledAmountInitial < this.filledAmount) && (groupMessage.getPriceOpen() != null))
/*      */             {
/* 1005 */               long partialFillTime = orderMessage.getTimestamp().longValue();
/* 1006 */               double partialFillPrice = groupMessage.getPriceOpen().doubleValue();
/* 1007 */               double partialFillAmount = this.filledAmount - this.filledAmountInitial;
/* 1008 */               this.fillHistory.add(new com.dukascopy.api.impl.FillOrder(partialFillTime, partialFillPrice, partialFillAmount));
/*      */             }
/*      */             
/* 1011 */             switch (this.lastServerRequest) {
/*      */             case SUBMIT: 
/*      */             case SET_REQ_AMOUNT: 
/*      */             case SET_OPEN_PRICE: 
/*      */             case SET_EXPIRATION: 
/*      */             case SET_SL: 
/*      */             case SET_TP: 
/* 1018 */               this.lastServerRequest = ServerRequest.NONE;
/*      */             }
/*      */             
/* 1021 */             this.filledAmountInitial = this.filledAmount;
/* 1022 */             this.openPrice = orderMessage.getPriceClient().doubleValue();
/* 1023 */             this.state = IOrder.State.FILLED;
/* 1024 */             this.closeAttemptTime = 0L;
/* 1025 */             BigDecimal newOriginalAmount = ProtocolUtils.getOrigAmountInMillions(orderMessage);
/* 1026 */             if (!ObjectUtils.isNullOrEmpty(newOriginalAmount)) {
/* 1027 */               setOriginalAmount(newOriginalAmount.doubleValue());
/*      */             }
/* 1029 */           } else if (orderState == OrderState.PENDING) {
/* 1030 */             if (this.state == IOrder.State.CREATED) {
/* 1031 */               this.state = IOrder.State.OPENED;
/* 1032 */               this.creationTime = orderMessage.getCreatedDate().getTime();
/* 1033 */               this.openPrice = orderMessage.getPriceStop().doubleValue();
/* 1034 */               String text = orderMessage.getNotes();
/*      */               
/* 1036 */               platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_SUBMIT_OK, this.creationTime);
/* 1037 */               LOGGER.debug("transiting order from CREATED to OPENED state as a response to PENDING order update message");
/* 1038 */               this.closeAttemptTime = 0L;
/* 1039 */             } else if (this.state == IOrder.State.OPENED)
/*      */             {
/* 1041 */               double newOpenPrice = orderMessage.getPriceStop().doubleValue();
/* 1042 */               platformMessageImpl = checkPrice(platformMessageImpl, orderMessage, newOpenPrice);
/* 1043 */               platformMessageImpl = checkExecTimeout(platformMessageImpl, orderMessage);
/* 1044 */             } else if ((this.state == IOrder.State.FILLED) && (groupMessage.getOrders().size() == 1))
/*      */             {
/* 1046 */               if (this.filledAmountInitial > this.filledAmount)
/*      */               {
/* 1048 */                 if (groupMessage.getTimestamp() != null) {
/* 1049 */                   this.closeTime = groupMessage.getTimestamp().longValue();
/*      */                 } else {
/* 1051 */                   LOGGER.warn("filled partial close message doesn't have timestamp set");
/*      */                 }
/* 1053 */                 if (groupMessage.getPriceOpen() != null) {
/* 1054 */                   this.closePrice = groupMessage.getPriceOpen().doubleValue();
/*      */                 }
/* 1056 */                 addCloseOrder(orderMessage);
/* 1057 */                 String text = orderMessage.getNotes();
/* 1058 */                 platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CLOSE_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/* 1059 */                 this.closeAttemptTime = 0L;
/* 1060 */                 LOGGER.debug("closing filled part of the order that also has pending part as a response to group update with only PENDING part");
/* 1061 */                 this.state = IOrder.State.OPENED;
/* 1062 */                 this.openPrice = orderMessage.getPriceStop().doubleValue();
/*      */               }
/*      */             }
/* 1065 */             switch (this.lastServerRequest) {
/*      */             case SUBMIT: 
/*      */             case SET_REQ_AMOUNT: 
/*      */             case SET_OPEN_PRICE: 
/*      */             case SET_EXPIRATION: 
/*      */             case SET_SL: 
/*      */             case SET_TP: 
/* 1072 */               this.lastServerRequest = ServerRequest.NONE;
/*      */             }
/* 1074 */             setPendingOrderData(orderMessage);
/* 1075 */             this.parentOrderId = orderMessage.getParentOrderId();
/* 1076 */             String newLabel = extractLabel(groupMessage);
/* 1077 */             if (!ObjectUtils.isEqual(this.label, newLabel)) {
/* 1078 */               PlatformOrderImpl existentOrder = this.taskManager.getOrdersInternalCollection().getOrderByLabel(newLabel);
/* 1079 */               if (existentOrder == null) {
/* 1080 */                 this.label = newLabel;
/* 1081 */                 if (platformMessageImpl == null) {
/* 1082 */                   String text = orderMessage.getNotes();
/* 1083 */                   platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CHANGED_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1084 */                   platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_LABEL);
/* 1085 */                   LOGGER.debug("updating OPENED order with data from PENDING order update message");
/*      */                 }
/*      */               }
/*      */             }
/* 1089 */           } else if ((orderState == OrderState.REJECTED) && (this.taskManager.isGlobal())) {
/* 1090 */             if (this.awaitingResubmit)
/*      */             {
/* 1092 */               this.awaitingResubmit = false;
/*      */             } else {
/* 1094 */               PlatformOrderImpl orderImpl = this.taskManager.getOrdersInternalCollection().removeById(this.groupId);
/* 1095 */               if (orderImpl == null) {
/* 1096 */                 this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/*      */               }
/* 1098 */               if (getState() != IOrder.State.CANCELED)
/*      */               {
/* 1100 */                 if (orderMessage.getTimestamp() != null) {
/* 1101 */                   this.closeTime = orderMessage.getTimestamp().longValue();
/*      */                 } else {
/* 1103 */                   LOGGER.warn("rejected message doesn't have timestamp set");
/*      */                 }
/* 1105 */                 if ((this.state == IOrder.State.OPENED) && (!this.orderCommand.isConditional()) && (!JForexAPI.isPlaceBidOffer(this.orderCommand)))
/*      */                 {
/* 1107 */                   this.state = IOrder.State.CANCELED;
/* 1108 */                   LOGGER.debug("transiting order to CANCELED state as a response to order update message");
/* 1109 */                   platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_FILL_REJECTED, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1110 */                 } else if (this.state == IOrder.State.FILLED)
/*      */                 {
/* 1112 */                   LOGGER.debug("canceling PENDING part as a response to order update message");
/* 1113 */                   calculatedRequestedAmount -= ProtocolUtils.getAmountInMillions(orderMessage).doubleValue();
/* 1114 */                   platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CHANGED_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/*      */                 } else {
/* 1116 */                   this.state = IOrder.State.CANCELED;
/* 1117 */                   LOGGER.debug("transiting order to CANCELED state as a response to order update message");
/* 1118 */                   platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CLOSE_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1119 */                   this.closeAttemptTime = 0L;
/*      */                 }
/* 1121 */                 this.lastServerRequest = ServerRequest.NONE;
/*      */               }
/*      */             }
/* 1124 */           } else if ((orderState == OrderState.CANCELLED) && (this.taskManager.isGlobal()) && (!ProtocolUtils.isBidOfferCancellReplace(orderMessage)))
/*      */           {
/* 1126 */             PlatformOrderImpl orderImpl = this.taskManager.getOrdersInternalCollection().removeById(this.groupId);
/* 1127 */             if (orderImpl == null) {
/* 1128 */               this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/*      */             }
/* 1130 */             if (getState() != IOrder.State.CANCELED)
/*      */             {
/* 1132 */               if (orderMessage.getTimestamp() != null) {
/* 1133 */                 this.closeTime = orderMessage.getTimestamp().longValue();
/*      */               } else {
/* 1135 */                 LOGGER.warn("cancel message doesn't have timestamp set");
/*      */               }
/* 1137 */               LOGGER.debug("transiting order to CANCELED state as a response to order update message");
/* 1138 */               if ((this.state == IOrder.State.OPENED) && (!this.orderCommand.isConditional()) && (!JForexAPI.isPlaceBidOffer(this.orderCommand)))
/*      */               {
/* 1140 */                 this.state = IOrder.State.CANCELED;
/* 1141 */                 LOGGER.debug("transiting order to CANCELED state as a response to order update message");
/* 1142 */                 platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_FILL_REJECTED, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1143 */               } else if (this.state == IOrder.State.FILLED)
/*      */               {
/* 1145 */                 LOGGER.debug("canceling PENDING part as a response to order update message");
/* 1146 */                 calculatedRequestedAmount -= ProtocolUtils.getAmountInMillions(orderMessage).doubleValue();
/* 1147 */                 platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CHANGED_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/*      */               } else {
/* 1149 */                 this.state = IOrder.State.CANCELED;
/* 1150 */                 LOGGER.debug("transiting order to CANCELED state as a response to order update message");
/* 1151 */                 platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CLOSE_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1152 */                 this.closeAttemptTime = 0L;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1158 */           if (this.state == IOrder.State.FILLED) {
/* 1159 */             this.orderCommand = (orderMessage.getSide() == OrderSide.BUY ? IEngine.OrderCommand.BUY : IEngine.OrderCommand.SELL);
/*      */           } else {
/* 1161 */             IEngine.OrderCommand newOrderCommand = detectOrderCommand(orderMessage);
/*      */             
/*      */ 
/* 1164 */             if (newOrderCommand == null) {
/* 1165 */               newOrderCommand = orderMessage.getSide() == OrderSide.BUY ? IEngine.OrderCommand.BUY : IEngine.OrderCommand.SELL;
/*      */             }
/* 1167 */             if (!ObjectUtils.isEqual(this.orderCommand, newOrderCommand)) {
/* 1168 */               String text = orderMessage.getNotes();
/* 1169 */               if (orderMessage.getTimestamp() == null) {
/* 1170 */                 LOGGER.warn("order update doesn't have timestamp set");
/*      */               }
/* 1172 */               if (platformMessageImpl == null) {
/* 1173 */                 platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CHANGED_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/*      */               }
/* 1175 */               platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_TYPE);
/* 1176 */               this.orderCommand = newOrderCommand;
/*      */             }
/*      */           }
/* 1179 */         } else if ((orderMessage.getDirection() == OrderDirection.CLOSE) && 
/* 1180 */           (orderState == OrderState.EXECUTING))
/*      */         {
/*      */ 
/* 1183 */           platformMessageImpl = null;
/* 1184 */           LOGGER.debug("closing in progress, do nothing");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1192 */         if (isStopLoss(orderMessage)) {
/* 1193 */           slOrder = orderMessage;
/*      */         }
/* 1195 */         if (isTakeProfit(orderMessage)) {
/* 1196 */           tpOrder = orderMessage;
/*      */         }
/*      */       }
/*      */       
/* 1200 */       if ((this.requestedAmount != calculatedRequestedAmount) && (this.requestedAmount > 0.0D))
/*      */       {
/* 1202 */         LOGGER.debug("canceling PENDING part as a response to order update message");
/* 1203 */         if (groupMessage.getTimestamp() == null) {
/* 1204 */           LOGGER.warn("order group message doesn't have timestamp set");
/*      */         }
/* 1206 */         if (platformMessageImpl == null) {
/* 1207 */           platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CHANGED_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/*      */         }
/* 1209 */         platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_AMOUNT);
/*      */       }
/*      */       
/* 1212 */       this.requestedAmount = StratUtils.round(calculatedRequestedAmount, 8);
/*      */       
/* 1214 */       if (openingOrder != null) {
/* 1215 */         this.openingOrderId = openingOrder.getOrderId();
/* 1216 */         this.parentOrderId = openingOrder.getParentOrderId();
/*      */         
/*      */ 
/* 1219 */         if (openingOrder.getTag() != null) {
/* 1220 */           this.comment = openingOrder.getTag();
/*      */         }
/* 1222 */         this.instrument = Instrument.fromString(openingOrder.getInstrument());
/*      */         
/*      */ 
/* 1225 */         String notes = null;
/* 1226 */         double newTpPrice; if (tpOrder != null) {
/* 1227 */           double newTpPrice = tpOrder.getPriceStop().doubleValue();
/* 1228 */           this.tpOrderId = tpOrder.getOrderId();
/* 1229 */           if (notes == null) {
/* 1230 */             notes = tpOrder.getNotes();
/*      */           }
/*      */         } else {
/* 1233 */           newTpPrice = 0.0D;
/* 1234 */           this.tpOrderId = null;
/*      */         }
/*      */         
/*      */         double newSlPrice;
/*      */         OfferSide newSlSide;
/*      */         double newSlTrailStep;
/* 1240 */         if (slOrder != null) {
/* 1241 */           double newSlPrice = slOrder.getPriceStop().doubleValue();
/* 1242 */           this.slOrderId = slOrder.getOrderId();
/* 1243 */           StopDirection slStopDirection = slOrder.getStopDirection();
/* 1244 */           OfferSide newSlSide; OfferSide newSlSide; if ((slStopDirection == StopDirection.GREATER_ASK) || (slStopDirection == StopDirection.LESS_ASK)) {
/* 1245 */             newSlSide = OfferSide.ASK;
/*      */           } else
/* 1247 */             newSlSide = OfferSide.BID;
/*      */           double newSlTrailStep;
/* 1249 */           if (slOrder.getPriceLimit() != null) {
/* 1250 */             double newSlTrailStep = slOrder.getPriceLimit().doubleValue();
/* 1251 */             newSlTrailStep /= this.instrument.getPipValue();
/*      */           } else {
/* 1253 */             newSlTrailStep = 0.0D;
/*      */           }
/* 1255 */           if (notes == null) {
/* 1256 */             notes = slOrder.getNotes();
/*      */           }
/*      */         } else {
/* 1259 */           newSlPrice = 0.0D;
/* 1260 */           this.slOrderId = null;
/* 1261 */           newSlSide = null;
/* 1262 */           newSlTrailStep = 0.0D;
/*      */         }
/*      */         
/* 1265 */         if ((newTpPrice != this.tpPrice) || (newSlPrice != this.slPrice) || (newSlSide != this.slSide) || (newSlTrailStep != this.slTrailStep)) {
/* 1266 */           if (groupMessage.getTimestamp() == null) {
/* 1267 */             LOGGER.warn("order group message doesn't have timestamp set");
/*      */           }
/* 1269 */           if (platformMessageImpl == null) {
/* 1270 */             platformMessageImpl = new PlatformMessageImpl(notes, this, IMessage.Type.ORDER_CHANGED_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/*      */           }
/* 1272 */           LOGGER.debug("updating order because of changes in sl/tp");
/* 1273 */           if (newTpPrice != this.tpPrice) {
/* 1274 */             platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_TP);
/*      */           } else {
/* 1276 */             platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_SL);
/*      */           }
/* 1278 */           this.tpPrice = newTpPrice;
/* 1279 */           this.slPrice = newSlPrice;
/* 1280 */           this.slSide = newSlSide;
/* 1281 */           this.slTrailStep = newSlTrailStep;
/*      */         }
/*      */         
/* 1284 */         if ((openingOrder.isPlaceOffer()) && (openingOrder.getExecTimeoutMillis() != null) && (this.goodTillTime != openingOrder.getExecTimeoutMillis().longValue())) {
/* 1285 */           this.goodTillTime = openingOrder.getExecTimeoutMillis().longValue();
/* 1286 */           if (platformMessageImpl == null) {
/* 1287 */             if (groupMessage.getTimestamp() == null) {
/* 1288 */               LOGGER.warn("order group message doesn't have timestamp set");
/*      */             }
/* 1290 */             platformMessageImpl = new PlatformMessageImpl(openingOrder.getNotes(), this, IMessage.Type.ORDER_CHANGED_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/* 1291 */             LOGGER.debug("updating order because of changes in gtt");
/*      */           }
/*      */         }
/*      */       }
/* 1295 */     } else if ((this.lastServerRequest == ServerRequest.MERGE_TARGET) || ((this.state == IOrder.State.CREATED) && (groupMessage.isOcoMerge()) && (groupMessage.getAmount() != null) && (groupMessage.getAmount().compareTo(BigDecimal.ZERO) == 0)))
/*      */     {
/*      */ 
/*      */ 
/* 1299 */       this.instrument = Instrument.fromString(ProtocolUtils.getInstrument(groupMessage));
/* 1300 */     } else if (this.taskManager.isGlobal()) {
/* 1301 */       this.label = groupMessage.getOrderGroupId();
/* 1302 */       double oldPrice = this.openPrice;
/* 1303 */       IEngine.OrderCommand oldOrderCommand = this.orderCommand;
/* 1304 */       this.orderCommand = (groupMessage.getSide() == com.dukascopy.dds3.transport.msg.types.PositionSide.SHORT ? IEngine.OrderCommand.SELL : IEngine.OrderCommand.BUY);
/* 1305 */       if (groupMessage.getAmount() != null) {
/* 1306 */         this.filledAmount = ProtocolUtils.getAmountInMillions(groupMessage).doubleValue();
/*      */       } else {
/* 1308 */         this.filledAmount = 0.0D;
/*      */       }
/* 1310 */       this.requestedAmount = this.filledAmount;
/* 1311 */       this.openPrice = groupMessage.getPricePosOpen().doubleValue();
/* 1312 */       this.instrument = Instrument.fromString(ProtocolUtils.getInstrument(groupMessage));
/*      */       
/* 1314 */       if ((oldOrderCommand != this.orderCommand) || (this.filledAmount != this.filledAmountInitial) || (oldPrice != this.openPrice)) {
/* 1315 */         this.fillTime = groupMessage.getTimestamp().longValue();
/* 1316 */         platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CHANGED_OK, this.fillTime);
/* 1317 */         LOGGER.debug("updating global position with data from order group update message");
/* 1318 */         this.lastServerRequest = ServerRequest.NONE;
/*      */       }
/*      */       
/* 1321 */       this.filledAmountInitial = this.filledAmount;
/* 1322 */       this.state = IOrder.State.FILLED;
/* 1323 */       if (this.filledAmount == 0.0D)
/*      */       {
/* 1325 */         this.taskManager.getOrdersInternalCollection().removeById(this.groupId);
/*      */       }
/*      */     } else {
/* 1328 */       PlatformOrderImpl orderImpl = this.taskManager.getOrdersInternalCollection().removeById(this.groupId);
/* 1329 */       if (orderImpl == null) {
/* 1330 */         orderImpl = this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/*      */       }
/* 1332 */       if ((orderImpl != null) && (orderImpl.getState() != IOrder.State.CANCELED))
/*      */       {
/*      */ 
/* 1335 */         if (groupMessage.getTimestamp() != null) {
/* 1336 */           this.closeTime = groupMessage.getTimestamp().longValue();
/*      */         } else {
/* 1338 */           LOGGER.warn("order group message doesn't have timestamp set");
/*      */         }
/* 1340 */         if (groupMessage.getPriceOpen() != null) {
/* 1341 */           this.closePrice = groupMessage.getPriceOpen().doubleValue();
/*      */         }
/* 1343 */         IOrder.State previousState = this.state;
/* 1344 */         if (orderImpl.getState() == IOrder.State.FILLED) {
/* 1345 */           this.state = IOrder.State.CLOSED;
/* 1346 */           LOGGER.debug("transiting order from FILLED to CLOSED state as a response to empty order group update message");
/*      */         } else {
/* 1348 */           this.state = IOrder.State.CANCELED;
/* 1349 */           LOGGER.debug("transiting order to CANCELED state as a response to empty order group update message");
/*      */         }
/*      */         
/* 1352 */         if (this.lastServerRequest == ServerRequest.MERGE_TARGET) {
/* 1353 */           platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDERS_MERGE_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/* 1354 */           this.instrument = Instrument.fromString(ProtocolUtils.getInstrument(groupMessage));
/* 1355 */           this.state = IOrder.State.CLOSED;
/*      */         } else {
/* 1357 */           if ((previousState == IOrder.State.OPENED) && (!this.orderCommand.isConditional()) && (!JForexAPI.isPlaceBidOffer(this.orderCommand)))
/*      */           {
/* 1359 */             platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_FILL_REJECTED, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/*      */           } else {
/* 1361 */             platformMessageImpl = new PlatformMessageImpl(null, this, IMessage.Type.ORDER_CLOSE_OK, groupMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : groupMessage.getTimestamp().longValue());
/* 1362 */             if (this.closedBySL) {
/* 1363 */               platformMessageImpl.addReason(IMessage.Reason.ORDER_CLOSED_BY_SL);
/* 1364 */             } else if (this.closedByTP) {
/* 1365 */               platformMessageImpl.addReason(IMessage.Reason.ORDER_CLOSED_BY_TP);
/* 1366 */             } else if (groupMessage.isOcoMerge()) {
/* 1367 */               platformMessageImpl.addReason(IMessage.Reason.ORDER_CLOSED_BY_MERGE);
/*      */             }
/*      */             
/* 1370 */             this.closeAttemptTime = 0L;
/*      */           }
/* 1372 */           this.lastServerRequest = ServerRequest.NONE;
/*      */         }
/* 1374 */         if (ObjectUtils.isEqual(this.state, IOrder.State.CLOSED)) {
/* 1375 */           addCloseOrder(this.filledAmountInitial);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1380 */         this.lastServerRequest = ServerRequest.NONE;
/*      */       }
/*      */     }
/* 1383 */     if (platformMessageImpl != null) {
/* 1384 */       if (!this.updated) {
/* 1385 */         this.updatedMessage = platformMessageImpl;
/*      */       }
/* 1387 */       this.updated = true;
/* 1388 */       synchronized (this) {
/* 1389 */         notifyAll();
/*      */       }
/*      */     }
/* 1392 */     return platformMessageImpl;
/*      */   }
/*      */   
/*      */   public PlatformMessageImpl update(MergePositionsMessage mergeMessage) {
/* 1396 */     if (this.filledAmount == 0.0D) {
/* 1397 */       this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/* 1398 */       this.state = IOrder.State.CLOSED;
/* 1399 */       this.closeTime = (this.creationTime = mergeMessage.getTimestamp().longValue());
/*      */     }
/* 1401 */     StringBuilder notification = new StringBuilder("Positions: ");
/* 1402 */     for (String positionId : mergeMessage.getPositionList()) {
/* 1403 */       notification.append(positionId).append("; ");
/*      */     }
/* 1405 */     notification.setLength(notification.length() - 2);
/* 1406 */     notification.append(" MERGED");
/* 1407 */     if (this.state == IOrder.State.CLOSED) {
/* 1408 */       notification.append(", result position closed");
/*      */     } else {
/* 1410 */       notification.append(" to position: ").append(mergeMessage.getNewOrdGrId());
/*      */     }
/* 1412 */     this.lastServerRequest = ServerRequest.NONE;
/* 1413 */     PlatformMessageImpl platformMessageImpl = new PlatformMessageImpl(notification.toString(), this, IMessage.Type.ORDERS_MERGE_OK, mergeMessage.getTimestamp().longValue());
/* 1414 */     if (!this.updated) {
/* 1415 */       this.updatedMessage = platformMessageImpl;
/*      */     }
/* 1417 */     this.updated = true;
/* 1418 */     synchronized (this) {
/* 1419 */       notifyAll();
/*      */     }
/* 1421 */     return platformMessageImpl;
/*      */   }
/*      */   
/*      */ 
/*      */   public PlatformMessageImpl update(NotificationMessage notificationMessage)
/*      */   {
/* 1427 */     NotificationMessageCode code = notificationMessage.getCode();
/* 1428 */     String text = notificationMessage.getText();
/*      */     
/* 1430 */     if ((this.taskManager.isGlobal()) && ((code == NotificationMessageCode.REJECT_AND_RESUBMIT) || ((code == NotificationMessageCode.REJECTED_COUNTERPARTY) && (JForexAPI.isPlaceBidOffer(this.orderCommand)) && (notificationMessage.getOrderId().equals(this.openingOrderId)))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1435 */       this.awaitingResubmit = true;
/* 1436 */       return new PlatformMessageImpl(code + "-" + text, this, IMessage.Type.NOTIFICATION, notificationMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : notificationMessage.getTimestamp().longValue());
/*      */     }
/*      */     
/* 1439 */     if ((code == NotificationMessageCode.REJECTED_COUNTERPARTY) && (((JForexAPI.isPlaceBidOffer(this.orderCommand)) && (notificationMessage.getOrderId().equals(this.openingOrderId))) || ((this.state == IOrder.State.FILLED) && (notificationMessage.getOrderId().equals(this.pendingOrderId)))))
/*      */     {
/* 1441 */       return null;
/*      */     }
/*      */     
/* 1444 */     if ((ObjectUtils.isEqual(code, NotificationMessageCode.ORDER_FILLED)) && (ObjectUtils.isEqual(this.state, IOrder.State.FILLED))) {
/* 1445 */       this.closedByTP = text.contains("TAKE PROFIT");
/* 1446 */       this.closedBySL = text.contains("STOP LOSS");
/*      */     }
/* 1448 */     IMessage.Type type = responseMessageGenerator.generateResponse(this.lastServerRequest, this.state, code, text);
/*      */     
/* 1450 */     if (type != null) {
/* 1451 */       PlatformMessageImpl platformMessageImpl = new PlatformMessageImpl(code + "-" + text, this, type, notificationMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : notificationMessage.getTimestamp().longValue());
/* 1452 */       switch (type) {
/*      */       case ORDER_CLOSE_REJECTED: 
/* 1454 */         this.closeAttemptTime = 0L;
/*      */       case ORDER_CHANGED_REJECTED: 
/* 1456 */         this.stopLossChangeTime = 0L;
/* 1457 */         this.takeProfitChangeTime = 0L;
/* 1458 */         this.requestedAmountChangeTime = 0L;
/* 1459 */         this.labelChangeTime = 0L;
/* 1460 */         this.openPriceChangeTime = 0L;
/*      */       case ORDER_SUBMIT_REJECTED: 
/*      */       case ORDERS_MERGE_REJECTED: 
/* 1463 */         if (!this.updated) {
/* 1464 */           this.updatedMessage = platformMessageImpl;
/*      */         }
/* 1466 */         this.updated = true;
/* 1467 */         synchronized (this) {
/* 1468 */           notifyAll();
/*      */         }
/* 1470 */         this.lastServerRequest = ServerRequest.NONE;
/* 1471 */         break;
/*      */       case ORDER_FILL_REJECTED: 
/* 1473 */         platformMessageImpl = null;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1478 */       return null;
/*      */     }
/*      */     
/*      */     PlatformMessageImpl platformMessageImpl;
/* 1482 */     switch (type) {
/*      */     case ORDER_SUBMIT_REJECTED: 
/* 1484 */       if (getState() == IOrder.State.CREATED) {
/* 1485 */         this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/* 1486 */         this.state = IOrder.State.CANCELED;
/* 1487 */         if (notificationMessage.getTimestamp() != null) {
/* 1488 */           this.closeTime = notificationMessage.getTimestamp().longValue();
/*      */         }
/*      */       }
/*      */       
/*      */       break;
/*      */     case ORDER_FILL_REJECTED: 
/* 1494 */       platformMessageImpl = null;
/* 1495 */       break;
/*      */     
/*      */     case ORDERS_MERGE_REJECTED: 
/* 1498 */       this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/* 1499 */       this.state = IOrder.State.CANCELED;
/* 1500 */       if (notificationMessage.getTimestamp() != null) {
/* 1501 */         this.closeTime = notificationMessage.getTimestamp().longValue();
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1507 */     return platformMessageImpl;
/*      */   }
/*      */   
/*      */   public PlatformMessageImpl update(ErrorResponseMessage errorResponseMessage) {
/* 1511 */     PlatformMessageImpl platformMessageImpl = null;
/* 1512 */     if (this.state == IOrder.State.CREATED) {
/* 1513 */       this.taskManager.getOrdersInternalCollection().removeByLabel(this.label);
/* 1514 */       this.state = IOrder.State.CANCELED;
/* 1515 */       platformMessageImpl = new PlatformMessageImpl(errorResponseMessage.getReason(), this, IMessage.Type.ORDER_SUBMIT_REJECTED, errorResponseMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : errorResponseMessage.getTimestamp().longValue());
/*      */     }
/* 1517 */     if (platformMessageImpl != null) {
/* 1518 */       if (!this.updated) {
/* 1519 */         this.updatedMessage = platformMessageImpl;
/*      */       }
/* 1521 */       this.updated = true;
/* 1522 */       synchronized (this) {
/* 1523 */         notifyAll();
/*      */       }
/*      */     }
/* 1526 */     return platformMessageImpl;
/*      */   }
/*      */   
/*      */   private IEngine.OrderCommand detectOrderCommand(OrderMessage orderMessage) {
/* 1530 */     OrderSide orderSide = orderMessage.getSide();
/* 1531 */     StopDirection stopDirection = orderMessage.getStopDirection();
/*      */     
/* 1533 */     IEngine.OrderCommand orderCommand = null;
/*      */     
/* 1535 */     if (stopDirection == StopDirection.GREATER_ASK) {
/* 1536 */       if (orderSide == OrderSide.BUY) {
/* 1537 */         orderCommand = IEngine.OrderCommand.BUYSTOP;
/* 1538 */       } else if (orderSide == OrderSide.SELL) {
/* 1539 */         orderCommand = IEngine.OrderCommand.SELLLIMIT_BYASK;
/*      */       } else {
/* 1541 */         LOGGER.error("Assertion error in detecting OrderCommand[1] " + orderSide);
/*      */       }
/*      */     }
/* 1544 */     else if (stopDirection == StopDirection.LESS_ASK) {
/* 1545 */       if (orderSide == OrderSide.BUY) {
/* 1546 */         orderCommand = IEngine.OrderCommand.BUYLIMIT;
/* 1547 */       } else if (orderSide == OrderSide.SELL) {
/* 1548 */         orderCommand = IEngine.OrderCommand.SELLSTOP_BYASK;
/*      */       } else {
/* 1550 */         LOGGER.error("Assertion error in detecting OrderCommand[2] " + orderSide);
/*      */       }
/*      */     }
/* 1553 */     else if (stopDirection == StopDirection.GREATER_BID) {
/* 1554 */       if (orderSide == OrderSide.BUY) {
/* 1555 */         orderCommand = IEngine.OrderCommand.BUYSTOP_BYBID;
/* 1556 */       } else if (orderSide == OrderSide.SELL) {
/* 1557 */         orderCommand = IEngine.OrderCommand.SELLLIMIT;
/*      */       } else {
/* 1559 */         LOGGER.error("Assertion error in detecting OrderCommand[3] " + orderSide);
/*      */       }
/*      */     }
/* 1562 */     else if (stopDirection == StopDirection.LESS_BID) {
/* 1563 */       if (orderSide == OrderSide.BUY) {
/* 1564 */         orderCommand = IEngine.OrderCommand.BUYLIMIT_BYBID;
/* 1565 */       } else if (orderSide == OrderSide.SELL) {
/* 1566 */         orderCommand = IEngine.OrderCommand.SELLSTOP;
/*      */       } else {
/* 1568 */         LOGGER.error("Assertion error in detecting OrderCommand[4] " + orderSide);
/*      */       }
/*      */     }
/* 1571 */     else if (stopDirection == null) {
/* 1572 */       if (orderMessage.isPlaceOffer()) {
/* 1573 */         if (orderSide == OrderSide.BUY) {
/* 1574 */           orderCommand = IEngine.OrderCommand.PLACE_BID;
/* 1575 */         } else if (orderSide == OrderSide.SELL) {
/* 1576 */           orderCommand = IEngine.OrderCommand.PLACE_OFFER;
/*      */         } else {
/* 1578 */           LOGGER.error("Assertion error in detecting OrderCommand[8] " + orderSide);
/*      */         }
/*      */       }
/* 1581 */       else if (orderSide == OrderSide.BUY) {
/* 1582 */         orderCommand = IEngine.OrderCommand.BUY;
/* 1583 */       } else if (orderSide == OrderSide.SELL) {
/* 1584 */         orderCommand = IEngine.OrderCommand.SELL;
/*      */       } else {
/* 1586 */         LOGGER.error("Assertion error in detecting OrderCommand[5] " + orderSide);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else {
/* 1592 */       LOGGER.error("Assertion error in detecting OrderCommand[6] " + stopDirection);
/*      */     }
/*      */     
/* 1595 */     return orderCommand;
/*      */   }
/*      */   
/*      */   public static String extractLabel(OrderGroupMessage orderGroupMessage) {
/* 1599 */     String label = null;
/* 1600 */     OrderMessage openingOrder = ProtocolUtils.getOpeningOrder(orderGroupMessage);
/* 1601 */     if (openingOrder != null) {
/* 1602 */       label = openingOrder.getExternalSysId();
/* 1603 */       if (label == null) {
/* 1604 */         LOGGER.error("PROBLEM WITH OPENING ORDER " + openingOrder);
/*      */       }
/*      */     } else {
/* 1607 */       for (OrderMessage orderMessage : orderGroupMessage.getOrders()) {
/* 1608 */         if ((orderMessage != null) && (orderMessage.getExternalSysId() != null)) {
/* 1609 */           label = orderMessage.getExternalSysId();
/* 1610 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1614 */     if (label == null) {
/* 1615 */       label = orderGroupMessage.getExternalSysId();
/*      */     }
/* 1617 */     return label;
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/* 1622 */     return "[" + getLabel() + "]-" + getState() + " / " + getInstrument() + " / " + getOpenPrice() + " / " + getRequestedAmount() + " / " + getAmount();
/*      */   }
/*      */   
/*      */   public int hashCode()
/*      */   {
/* 1627 */     int prime = 31;
/* 1628 */     int result = 1;
/* 1629 */     result = 31 * result + (this.groupId == null ? 0 : this.groupId.hashCode());
/* 1630 */     result = 31 * result + (this.label == null ? 0 : this.label.hashCode());
/* 1631 */     return result;
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj)
/*      */   {
/* 1636 */     if (this == obj)
/* 1637 */       return true;
/* 1638 */     if (obj == null)
/* 1639 */       return false;
/* 1640 */     if (getClass() != obj.getClass())
/* 1641 */       return false;
/* 1642 */     PlatformOrderImpl other = (PlatformOrderImpl)obj;
/* 1643 */     if (this.groupId == null) {
/* 1644 */       if (other.groupId != null)
/* 1645 */         return false;
/* 1646 */     } else if (!this.groupId.equals(other.groupId))
/* 1647 */       return false;
/* 1648 */     if (this.label == null) {
/* 1649 */       if (other.label != null)
/* 1650 */         return false;
/* 1651 */     } else if (!this.label.equals(other.label))
/* 1652 */       return false;
/* 1653 */     return true;
/*      */   }
/*      */   
/*      */   public String toStringDetail() {
/* 1657 */     StringBuilder buff = new StringBuilder(128);
/* 1658 */     buff.append("label=").append(getLabel()).append(";").append("getId()=").append(getId()).append(";").append("groupId=").append(getGroupId()).append(";").append("openingOrderId=").append(getOpeningOrderId()).append(";").append("pendingOrderId=").append(this.pendingOrderId).append(";").append("pendingOrderCommand=").append(this.pendingOrderCommand).append(";").append("parentOrderId=").append(this.parentOrderId).append(";").append("tpOrderId=").append(this.tpOrderId).append(";").append("slOrderId=").append(this.slOrderId).append(";").append("state=").append(getState()).append(";").append("instrument=").append(getInstrument()).append(";").append("openPrice=").append(getOpenPrice()).append(";").append("requestedAmount=").append(getRequestedAmount()).append(";").append("amount=").append(getAmount()).append(";").append("lastServerRequest=").append(this.lastServerRequest).append(";").append("awaitingResubmit=").append(this.awaitingResubmit).append(";").append("localCreationTime=").append(this.localCreationTime).append(";");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1676 */     if (this.updatedMessage != null) {
/* 1677 */       buff.append("updatedMessage.type=").append(this.updatedMessage.getType()).append(";");
/* 1678 */       buff.append("updatedMessage.creationTime=").append(this.updatedMessage.getCreationTime()).append(";");
/*      */       
/* 1680 */       IOrder order = this.updatedMessage.getOrder();
/* 1681 */       if (order != null) {
/* 1682 */         buff.append("updatedMessage.getOrder().getLabel()=").append(order.getLabel()).append(";");
/* 1683 */         buff.append("updatedMessage.getOrder().getId()=").append(order.getId()).append(";");
/*      */       }
/*      */     }
/* 1686 */     if (!ObjectUtils.isNullOrEmpty(this.fillHistory)) {
/* 1687 */       buff.append("\nfill history:");
/* 1688 */       for (IFillOrder iFillOrder : getFillHistory()) {
/* 1689 */         buff.append("\n\t").append(iFillOrder);
/*      */       }
/*      */     }
/* 1692 */     if (!ObjectUtils.isNullOrEmpty(this.closeHistory)) {
/* 1693 */       buff.append("\nclose history:");
/* 1694 */       for (ICloseOrder iCloseOrder : getCloseHistory()) {
/* 1695 */         buff.append("\n\t").append(iCloseOrder);
/*      */       }
/*      */     }
/*      */     
/* 1699 */     return buff.toString();
/*      */   }
/*      */   
/*      */   public boolean updated()
/*      */   {
/* 1704 */     return this.updated;
/*      */   }
/*      */   
/*      */   public boolean updated(String... states) throws JFException
/*      */   {
/* 1709 */     if ((ObjectUtils.isNullOrEmpty(states)) || (states.length == 0))
/*      */     {
/* 1711 */       return this.updated;
/*      */     }
/* 1713 */     Set<IOrder.State> orderStates = new java.util.HashSet();
/* 1714 */     if (!ObjectUtils.isNullOrEmpty(states)) {
/* 1715 */       for (String state : states) {
/* 1716 */         orderStates.add(IOrder.State.valueOf(state));
/*      */       }
/*      */     }
/* 1719 */     if (orderStates.contains(this.state)) {
/* 1720 */       return this.updated;
/*      */     }
/* 1722 */     boolean stateValid = false;
/* 1723 */     for (IOrder.State expectedState : orderStates) {
/* 1724 */       if ((expectedState.ordinal() > this.state.ordinal()) && (!ObjectUtils.isEqual(this.state, IOrder.State.CLOSED))) {
/* 1725 */         stateValid = true;
/* 1726 */         break;
/*      */       }
/*      */     }
/* 1729 */     if (!stateValid) {
/* 1730 */       throw new JFException(JFException.Error.ORDER_STATE_IMMUTABLE, " state is " + getState());
/*      */     }
/* 1732 */     return false;
/*      */   }
/*      */   
/*      */   public synchronized void waitForUpdate(long timeoutMillis) {
/* 1736 */     if ((this.state != IOrder.State.CLOSED) && (this.state != IOrder.State.CANCELED)) {
/* 1737 */       this.updated = false;
/* 1738 */       if (this.taskManager.isThreadOk(Thread.currentThread().getId())) {
/*      */         try {
/* 1740 */           this.taskManager.waitForUpdate(this, timeoutMillis, TimeUnit.MILLISECONDS);
/*      */         } catch (InterruptedException e) {
/* 1742 */           LOGGER.warn(e.getMessage(), e);
/*      */         }
/*      */       }
/*      */       else {
/* 1746 */         long startTime = System.currentTimeMillis();
/*      */         long currentTime;
/* 1748 */         while ((!this.taskManager.isStrategyStopping()) && (!updated()) && ((currentTime = System.currentTimeMillis()) - startTime < timeoutMillis)) {
/*      */           try {
/* 1750 */             wait(timeoutMillis - (currentTime - startTime));
/*      */           } catch (InterruptedException e) {
/* 1752 */             LOGGER.warn(e.getMessage(), e);
/* 1753 */             this.updatedMessage = null;
/* 1754 */             return;
/*      */           }
/*      */         }
/*      */       }
/* 1758 */       this.updatedMessage = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized IMessage waitForUpdate(long timeout, TimeUnit unit)
/*      */   {
/* 1764 */     if ((this.state != IOrder.State.CLOSED) && (this.state != IOrder.State.CANCELED)) {
/* 1765 */       this.updated = false;
/* 1766 */       if (this.taskManager.isThreadOk(Thread.currentThread().getId())) {
/*      */         try {
/* 1768 */           this.taskManager.waitForUpdate(this, timeout, unit);
/*      */         } catch (InterruptedException ie) {
/* 1770 */           LOGGER.warn("Interrupted");
/*      */         }
/*      */       }
/*      */       else {
/* 1774 */         long startTime = System.currentTimeMillis();
/* 1775 */         long timeoutMillis = unit.toMillis(timeout);
/*      */         long currentTime;
/* 1777 */         while ((!this.taskManager.isStrategyStopping()) && (!updated()) && ((currentTime = System.currentTimeMillis()) - startTime < timeoutMillis)) {
/*      */           try {
/* 1779 */             wait(timeoutMillis - (currentTime - startTime));
/*      */           } catch (InterruptedException e) {
/* 1781 */             LOGGER.warn(e.getMessage(), e);
/* 1782 */             this.updatedMessage = null;
/* 1783 */             return null;
/*      */           }
/*      */         }
/*      */       }
/* 1787 */       IMessage message = this.updatedMessage;
/* 1788 */       this.updatedMessage = null;
/* 1789 */       return message;
/*      */     }
/* 1791 */     return null;
/*      */   }
/*      */   
/*      */   public IMessage waitForUpdate(IOrder.State... states) throws JFException
/*      */   {
/* 1796 */     return waitForUpdate(Long.MAX_VALUE, TimeUnit.MILLISECONDS, states);
/*      */   }
/*      */   
/*      */   public IMessage waitForUpdate(long timeoutMills, IOrder.State... states) throws JFException
/*      */   {
/* 1801 */     return waitForUpdate(timeoutMills, TimeUnit.MILLISECONDS, states);
/*      */   }
/*      */   
/*      */   public synchronized IMessage waitForUpdate(long timeout, TimeUnit unit, IOrder.State... states) throws JFException
/*      */   {
/* 1806 */     if (states != null) {
/* 1807 */       for (IOrder.State s : states) {
/* 1808 */         if (s.equals(this.state)) {
/* 1809 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1814 */     if ((this.state != IOrder.State.CLOSED) && (this.state != IOrder.State.CANCELED)) {
/* 1815 */       this.updated = false;
/* 1816 */       if (this.taskManager.isThreadOk(Thread.currentThread().getId())) {
/*      */         try {
/* 1818 */           this.taskManager.waitForUpdate(this, timeout, unit, states);
/*      */         } catch (InterruptedException ie) {
/* 1820 */           LOGGER.warn("Interrupted");
/*      */         }
/*      */       }
/*      */       else {
/* 1824 */         long startTime = System.currentTimeMillis();
/* 1825 */         long timeoutMillis = unit.toMillis(timeout);
/*      */         long currentTime;
/* 1827 */         while ((!this.taskManager.isStrategyStopping()) && (!updated()) && ((currentTime = System.currentTimeMillis()) - startTime < timeoutMillis)) {
/*      */           try {
/* 1829 */             wait(timeoutMillis - (currentTime - startTime));
/*      */           } catch (InterruptedException e) {
/* 1831 */             LOGGER.warn(e.getMessage(), e);
/* 1832 */             this.updatedMessage = null;
/* 1833 */             return null;
/*      */           }
/*      */         }
/*      */       }
/* 1837 */       IMessage message = this.updatedMessage;
/* 1838 */       this.updatedMessage = null;
/* 1839 */       return message;
/*      */     }
/* 1841 */     return null;
/*      */   }
/*      */   
/*      */   public synchronized double getProfitLossInPips()
/*      */   {
/*      */     double closePrice;
/* 1847 */     if (this.state == IOrder.State.FILLED) {
/* 1848 */       closePrice = isLong() ? FeedDataProvider.getDefaultInstance().getLastBid(this.instrument) : FeedDataProvider.getDefaultInstance().getLastAsk(this.instrument);
/*      */     } else {
/*      */       double closePrice;
/* 1851 */       if (this.state == IOrder.State.CLOSED) {
/* 1852 */         closePrice = this.closePrice;
/*      */       } else
/* 1854 */         return 0.0D; }
/*      */     double closePrice;
/* 1856 */     double plInPips = StratUtils.roundHalfEven((closePrice - this.openPrice) / this.instrument.getPipValue(), 1);
/* 1857 */     if (!isLong()) {
/* 1858 */       plInPips *= -1.0D;
/*      */     }
/* 1860 */     return plInPips;
/*      */   }
/*      */   
/*      */   public synchronized double getProfitLossInUSD()
/*      */   {
/* 1865 */     return getProfitLoss(Instrument.EURUSD.getSecondaryJFCurrency());
/*      */   }
/*      */   
/*      */   public synchronized double getProfitLossInAccountCurrency()
/*      */   {
/* 1870 */     return getProfitLoss(this.taskManager.getAccountCurrency());
/*      */   }
/*      */   
/*      */   private double getProfitLoss(ICurrency currency)
/*      */   {
/*      */     double amount;
/* 1876 */     if (this.state == IOrder.State.FILLED) {
/* 1877 */       double closePrice = isLong() ? FeedDataProvider.getDefaultInstance().getLastBid(this.instrument) : FeedDataProvider.getDefaultInstance().getLastAsk(this.instrument);
/*      */       
/*      */ 
/* 1880 */       amount = this.filledAmount; } else { double amount;
/* 1881 */       if (this.state == IOrder.State.CLOSED) {
/* 1882 */         double closePrice = this.closePrice;
/* 1883 */         amount = this.filledAmountInitial;
/*      */       } else {
/* 1885 */         return 0.0D; } }
/*      */     double amount;
/* 1887 */     double closePrice; double commoditiesPerContract = com.dukascopy.dds2.greed.util.InstrumentUtils.getCommoditiesPerContract(this.instrument.toString()).doubleValue();
/* 1888 */     double commoditiesAmount = amount * commoditiesPerContract;
/* 1889 */     double profLossInSecondaryCCY = (closePrice - this.openPrice) * commoditiesAmount * 1000000.0D;
/* 1890 */     if (!isLong()) {
/* 1891 */       profLossInSecondaryCCY *= -1.0D;
/*      */     }
/* 1893 */     return StratUtils.roundHalfEven(CurrencyConverter.getCurrencyConverter().convert(profLossInSecondaryCCY, this.instrument.getSecondaryJFCurrency(), currency, isLong() ? OfferSide.BID : OfferSide.ASK), 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public double getCommissionInUSD()
/*      */   {
/* 1906 */     return StratUtils.roundHalfEven(CurrencyConverter.getCurrencyConverter().convert(this.commission, this.taskManager.getAccountCurrency(), Instrument.EURUSD.getSecondaryJFCurrency(), null), 2);
/*      */   }
/*      */   
/*      */   public double getCommission()
/*      */   {
/* 1911 */     return StratUtils.roundHalfEven(this.commission, 2);
/*      */   }
/*      */   
/*      */   public double getOriginalAmount() {
/* 1915 */     return this.originalAmount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setOriginalAmount(double originalAmount)
/*      */   {
/* 1922 */     if (Double.compare(originalAmount, this.originalAmount) > 0) {
/* 1923 */       this.originalAmount = originalAmount;
/*      */     }
/*      */   }
/*      */   
/*      */   public List<IFillOrder> getFillHistory()
/*      */   {
/* 1929 */     return ObjectUtils.getSortedCopyList(this.fillHistory);
/*      */   }
/*      */   
/*      */   public List<ICloseOrder> getCloseHistory()
/*      */   {
/* 1934 */     return ObjectUtils.getSortedCopyList(this.closeHistory);
/*      */   }
/*      */   
/*      */   public synchronized void resetTimes() {
/* 1938 */     this.stopLossChangeTime = 0L;
/* 1939 */     this.takeProfitChangeTime = 0L;
/* 1940 */     this.requestedAmountChangeTime = 0L;
/* 1941 */     this.labelChangeTime = 0L;
/* 1942 */     this.openPriceChangeTime = 0L;
/*      */   }
/*      */   
/*      */   private void setPendingOrderData(OrderMessage pendingOrderMessage) {
/* 1946 */     this.pendingOrderId = pendingOrderMessage.getOrderId();
/* 1947 */     this.pendingOrderCommand = detectOrderCommand(pendingOrderMessage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PlatformMessageImpl checkPrice(PlatformMessageImpl platformMessageImpl, OrderMessage orderMessage, double newOpenPrice)
/*      */   {
/* 1957 */     if (newOpenPrice != this.openPrice) {
/* 1958 */       this.openPrice = newOpenPrice;
/* 1959 */       String text = orderMessage.getNotes();
/* 1960 */       if (orderMessage.getTimestamp() == null) {
/* 1961 */         LOGGER.warn("pending order update doesn't have timestamp set");
/*      */       }
/* 1963 */       platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CHANGED_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1964 */       platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_PRICE);
/*      */       
/* 1966 */       LOGGER.debug("updating OPENED order with data from PENDING order update message");
/*      */     }
/* 1968 */     return platformMessageImpl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PlatformMessageImpl checkExecTimeout(PlatformMessageImpl platformMessageImpl, OrderMessage orderMessage)
/*      */   {
/* 1977 */     long currentTime = FeedDataProvider.getDefaultInstance().getCurrentTime();
/* 1978 */     long newGoodTillTime = 0L;
/* 1979 */     if (orderMessage.getExecTimeoutMillis() != null) {
/* 1980 */       newGoodTillTime = orderMessage.getExecTimeoutMillis().longValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1985 */     if ((newGoodTillTime != this.goodTillTime) && (
/* 1986 */       (newGoodTillTime - currentTime <= GTC_THRESHOLD) || (this.goodTillTime - currentTime <= GTC_THRESHOLD))) {
/* 1987 */       String text = orderMessage.getNotes();
/* 1988 */       if (orderMessage.getTimestamp() == null) {
/* 1989 */         LOGGER.warn("order update doesn't have timestamp set");
/*      */       }
/* 1991 */       platformMessageImpl = new PlatformMessageImpl(text, this, IMessage.Type.ORDER_CHANGED_OK, orderMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : orderMessage.getTimestamp().longValue());
/* 1992 */       platformMessageImpl.addReason(IMessage.Reason.ORDER_CHANGED_GTT);
/* 1993 */       this.goodTillTime = newGoodTillTime;
/* 1994 */       LOGGER.debug("updating order as a response to EXECUTING order update message");
/*      */     }
/*      */     
/* 1997 */     return platformMessageImpl;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean compare(IOrder order)
/*      */   {
/* 2003 */     return ((this.comment == null) || (order.getComment() != null) || (this.comment.equalsIgnoreCase(order.getComment()))) && (this.instrument.toString().equalsIgnoreCase(order.getInstrument().toString())) && (this.requestedAmount == order.getRequestedAmount()) && (this.label.equalsIgnoreCase(order.getLabel())) && (this.tpPrice == order.getTakeProfitPrice()) && (this.slPrice == order.getStopLossPrice()) && ((this.slSide == null) || (order.getStopLossSide() == null) || (this.slSide.equals(order.getStopLossSide()))) && (this.openPrice == order.getOpenPrice()) && (this.closePrice == order.getClosePrice()) && (this.state.equals(order.getState()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PlatformOrderImpl clone()
/*      */     throws CloneNotSupportedException
/*      */   {
/* 2017 */     super.clone();
/* 2018 */     PlatformOrderImpl cloneOrder = new PlatformOrderImpl(this.taskManager, this.comment, this.instrument, this.requestedAmount, this.filledAmount, this.label, this.tpPrice, this.slPrice, this.slSide, this.slTrailStep, this.openPrice, this.closePrice, this.state, this.groupId, this.openingOrderId, this.pendingOrderId, this.pendingOrderCommand, this.slOrderId, this.tpOrderId, this.goodTillTime, this.creationTime, this.fillTime, this.closeTime, this.orderCommand, this.commission, getFillHistory(), getCloseHistory());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2048 */     cloneOrder.slippage = this.slippage;
/* 2049 */     cloneOrder.lastServerRequest = this.lastServerRequest;
/*      */     
/* 2051 */     return cloneOrder;
/*      */   }
/*      */   
/*      */   private void addCloseOrder(OrderMessage orderMessage) {
/* 2055 */     double origAmount = 0.0D;
/* 2056 */     BigDecimal originalAmountBd = orderMessage.getOrigAmount();
/* 2057 */     if (originalAmountBd != null) {
/* 2058 */       origAmount = originalAmountBd.divide(BigDecimal.valueOf(1000000L)).doubleValue();
/*      */     }
/* 2060 */     this.closeHistory.add(new CloseOrder(this.closeTime, this.closePrice, origAmount));
/*      */   }
/*      */   
/*      */   private void addCloseOrder(double closedAmount) {
/* 2064 */     this.closeHistory.add(new CloseOrder(this.closeTime, this.closePrice, closedAmount));
/*      */   }
/*      */   
/*      */   private void setFillTime(OrderMessage orderMessage) {
/* 2068 */     if ((orderMessage != null) && (orderMessage.getTimestamp() != null)) {
/* 2069 */       Long timestamp = orderMessage.getTimestamp();
/* 2070 */       if ((!orderMessage.isRollover()) || (this.fillTime == 0L))
/*      */       {
/* 2072 */         this.fillTime = timestamp.longValue();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendRequest(TransportClient transportClient, OrderMessage om)
/*      */   {
/* 2082 */     com.dukascopy.dds4.transport.msg.system.ProtocolMessage protocolMessage = transportClient.controlRequest(om);
/* 2083 */     if ((protocolMessage instanceof ErrorResponseMessage)) {
/* 2084 */       ErrorResponseMessage error = (ErrorResponseMessage)protocolMessage;
/* 2085 */       this.taskManager.onErrorMessage(error, this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkWarning(String warning)
/*      */   {
/* 2094 */     if (!ObjectUtils.isNullOrEmpty(warning)) {
/* 2095 */       LOGGER.warn(warning);
/* 2096 */       NotificationUtilsProvider.getNotificationUtils().postWarningMessage(warning, true);
/* 2097 */       this.taskManager.onMessage(new PlatformMessageImpl(warning, this, IMessage.Type.ORDER_CHANGED_REJECTED, FeedDataProvider.getDefaultInstance().getCurrentTime()));
/*      */       
/* 2099 */       return true;
/*      */     }
/* 2101 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isFakePart(OrderMessageExt order, Map<String, Boolean> fakeParts) {
/* 2105 */     boolean fakePart = fakeParts.containsKey(order.getOrderId()) ? ((Boolean)fakeParts.get(order.getOrderId())).booleanValue() : false;
/* 2106 */     return fakePart;
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformOrderImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */