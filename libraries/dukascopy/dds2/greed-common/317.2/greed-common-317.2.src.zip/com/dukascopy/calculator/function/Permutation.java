/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Permutation
/*    */   extends DFunction
/*    */ {
/*    */   public Permutation()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.permutation.function.tooltip";
/* 15 */     this.fshortcut = 'P';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x, double y)
/*    */   {
/* 26 */     if ((x < 0.0D) || (Math.round(x) - x != 0.0D))
/* 27 */       throw new ArithmeticException("Permutation error");
/* 28 */     if ((y < 0.0D) || (y > x) || (Math.round(y) - y != 0.0D))
/* 29 */       throw new ArithmeticException("Permutation error");
/* 30 */     if (y == 0.0D) {
/* 31 */       return 1.0D;
/*    */     }
/* 33 */     return x * function(x - 1.0D, y - 1.0D);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x, OObject y)
/*    */   {
/* 44 */     return x.permutation(y);
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 48 */     return fname;
/*    */   }
/*    */   
/*    */   public String shortName() {
/* 52 */     return "<i>n</i>P<i>r</i>";
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 56 */     Permutation o = new Permutation();
/* 57 */     StringBuilder s = new StringBuilder("<html>");
/* 58 */     s.append(o.name());
/* 59 */     s.append("</html>");
/* 60 */     JOptionPane.showMessageDialog(null, s.toString());
/*    */   }
/*    */   
/* 63 */   private static final String[] fname = { "<b>P</b>" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Permutation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */