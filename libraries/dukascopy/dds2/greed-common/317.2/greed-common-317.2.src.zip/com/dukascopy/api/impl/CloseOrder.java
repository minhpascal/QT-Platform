/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.ICloseOrder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloseOrder
/*    */   extends PartialOrder
/*    */   implements ICloseOrder
/*    */ {
/*    */   public CloseOrder(long time, double price, double amount)
/*    */   {
/* 15 */     super(time, price, amount);
/*    */   }
/*    */   
/*    */   public CloseOrder(PartialOrder partialOrder) {
/* 19 */     super(partialOrder.getTime(), partialOrder.getPrice(), partialOrder.getAmount());
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\CloseOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */