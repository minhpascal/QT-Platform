/*     */ package com.dukascopy.api.impl.connect.validation;
/*     */ 
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.IEngine.OrderCommand;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.impl.connect.ILotAmountProvider;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class PluginOrderValidator extends OrderValidator implements IOrderValidator
/*     */ {
/*     */   private final boolean isAutoTradingAllowed;
/*     */   
/*     */   public PluginOrderValidator(IThreadValidator threadValidator, ILotAmountProvider lotAmountProvider, boolean isAutoTradingAllowed)
/*     */   {
/*  19 */     super(threadValidator, lotAmountProvider);
/*  20 */     this.isAutoTradingAllowed = isAutoTradingAllowed;
/*     */   }
/*     */   
/*     */   private void checkTradability() throws JFException {
/*  24 */     if (!this.isAutoTradingAllowed) {
/*  25 */       throw new JFException("Trading prohibited! To enable trading from the plugin select the \"Allow auto trading\" in the plugin parameters.");
/*     */     }
/*     */   }
/*     */   
/*     */   private String getTradability() {
/*  30 */     if (!this.isAutoTradingAllowed) {
/*  31 */       return "Trading prohibited! To enable trading from the plugin select the \"Allow auto trading\" in the plugin parameters.";
/*     */     }
/*  33 */     return "";
/*     */   }
/*     */   
/*     */   public String validateLabel(String label) throws JFException
/*     */   {
/*  38 */     return super.validateLabel(label);
/*     */   }
/*     */   
/*     */   public String validateComment(String comment)
/*     */   {
/*  43 */     return super.validateComment(comment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateOrderParameters(String label, boolean isGlobal, Instrument instrument, ICurrency accountCurrency, IEngine.OrderCommand orderCommand, double amount, double price, double stopLossPrice, double takeProfitPrice, long goodTillTime)
/*     */     throws JFException
/*     */   {
/*  58 */     return super.validateOrderParameters(label, isGlobal, instrument, accountCurrency, orderCommand, amount, price, stopLossPrice, takeProfitPrice, goodTillTime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String validateOrderParameters(String label, boolean isGlobal, Instrument instrument, ICurrency accountCurrency, IEngine.OrderCommand orderCommand, double amount, double price, double stopLossPrice, double takeProfitPrice, long goodTillTime, IFeedDataProvider feedDataProvider)
/*     */     throws JFException
/*     */   {
/*  74 */     checkTradability();
/*  75 */     return super.validateOrderParameters(label, isGlobal, instrument, accountCurrency, orderCommand, amount, price, stopLossPrice, takeProfitPrice, goodTillTime, feedDataProvider);
/*     */   }
/*     */   
/*     */   public String validateMergeOrders(String label, boolean isGlobal, Collection<IOrder> orders) throws JFException
/*     */   {
/*  80 */     checkTradability();
/*  81 */     return super.validateMergeOrders(label, isGlobal, orders);
/*     */   }
/*     */   
/*     */   public String validateOrder(IOrder order)
/*     */   {
/*  86 */     return super.validateOrder(order);
/*     */   }
/*     */   
/*     */   public String validateMinMaxAmount(double amount, Instrument instrument)
/*     */   {
/*  91 */     return super.validateMinMaxAmount(amount, instrument);
/*     */   }
/*     */   
/*     */   public String validateStopLossTakeProfitPrice(boolean stopLoss, double price, Instrument instrument)
/*     */   {
/*  96 */     String warning = super.validateStopLossTakeProfitPrice(stopLoss, price, instrument);
/*  97 */     if (warning == null) {
/*  98 */       warning = getTradability();
/*     */     }
/* 100 */     return warning;
/*     */   }
/*     */   
/*     */   public String validateRequestedAmount(IOrder order, double requestedAmount, long requestedAmountChangeTime, String openingOrderId, String pendingOrderId)
/*     */     throws JFException
/*     */   {
/* 106 */     checkTradability();
/* 107 */     return super.validateRequestedAmount(order, requestedAmount, requestedAmountChangeTime, openingOrderId, pendingOrderId);
/*     */   }
/*     */   
/*     */   public String validateLabel(IOrder order, String label, long labelChangeTime, boolean fulfilled, String openingOrderId, String pendingOrderId)
/*     */     throws JFException
/*     */   {
/* 113 */     checkTradability();
/* 114 */     return super.validateLabel(order, label, labelChangeTime, fulfilled, openingOrderId, pendingOrderId);
/*     */   }
/*     */   
/*     */   public String validateOpenPrice(IOrder order, double price, long openPriceChangeTime, boolean fulfilled, String openingOrderId) throws JFException
/*     */   {
/* 119 */     checkTradability();
/* 120 */     return super.validateOpenPrice(order, price, openPriceChangeTime, fulfilled, openingOrderId);
/*     */   }
/*     */   
/*     */   public String validateClose(IOrder order, double amount, double price, double slippage, long closeAttemptTime) throws JFException
/*     */   {
/* 125 */     checkTradability();
/* 126 */     return super.validateClose(order, amount, price, slippage, closeAttemptTime);
/*     */   }
/*     */   
/*     */   public String validateStopLossPrice(IOrder order, double price, OfferSide side, double trailingStepInPips, boolean global, long stopLossChangeTime)
/*     */     throws JFException
/*     */   {
/* 132 */     checkTradability();
/* 133 */     return super.validateStopLossPrice(order, price, side, trailingStepInPips, global, stopLossChangeTime);
/*     */   }
/*     */   
/*     */   public String validateTakeProfitPrice(IOrder order, double price, OfferSide side, boolean global, long takeProfitChangeTime) throws JFException
/*     */   {
/* 138 */     checkTradability();
/* 139 */     return super.validateTakeProfitPrice(order, price, side, global, takeProfitChangeTime);
/*     */   }
/*     */   
/*     */   public void validateGoodTillTime(long goodTillTime, IEngine.OrderCommand orderCommand) throws JFException
/*     */   {
/* 144 */     checkTradability();
/* 145 */     super.validateGoodTillTime(goodTillTime, orderCommand);
/*     */   }
/*     */   
/*     */   public String validateGoodTillTime(IOrder order, long goodTillTime, long goodTillTimeChangeTime, boolean fulfilled, String openingOrderId)
/*     */     throws JFException
/*     */   {
/* 151 */     checkTradability();
/* 152 */     return super.validateGoodTillTime(order, goodTillTime, goodTillTimeChangeTime, fulfilled, openingOrderId);
/*     */   }
/*     */   
/*     */   public void validateCloseOrders(boolean isGlobal, Collection<IOrder> orders) throws JFException
/*     */   {
/* 157 */     checkTradability();
/* 158 */     super.validateCloseOrders(isGlobal, orders);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\validation\PluginOrderValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */