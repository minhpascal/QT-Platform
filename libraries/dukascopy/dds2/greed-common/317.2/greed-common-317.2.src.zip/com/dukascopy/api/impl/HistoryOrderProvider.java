/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.OrderHistoricalData;
/*     */ import com.dukascopy.charts.data.datacache.OrderHistoricalData.CloseData;
/*     */ import com.dukascopy.charts.data.datacache.OrderHistoricalData.OpenData;
/*     */ import com.dukascopy.charts.data.datacache.OrdersListener;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HistoryOrderProvider
/*     */   implements IHistoryOrderProvider
/*     */ {
/*     */   private IFeedDataProvider feedDataProvider;
/*     */   private ICurrency accountCurrency;
/*     */   
/*     */   public HistoryOrderProvider(IFeedDataProvider feedDataProvider, ICurrency accountCurrency)
/*     */   {
/*  34 */     this.feedDataProvider = feedDataProvider;
/*  35 */     this.accountCurrency = accountCurrency;
/*     */   }
/*     */   
/*     */   public List<IOrder> getOrdersHistory(Instrument instrument, long from, long to) throws JFException
/*     */   {
/*     */     try {
/*  41 */       List<IOrder> orders = new ArrayList();
/*  42 */       LoadingProgressListenerImpl loadingProgressListener = new LoadingProgressListenerImpl(null);
/*  43 */       this.feedDataProvider.loadOrdersHistoricalDataSynched(instrument, from, to, new OrdersListenerImpl(from, to, orders), loadingProgressListener);
/*  44 */       if (loadingProgressListener.getException() != null) {
/*  45 */         throw new JFException("Error while loading orders history", loadingProgressListener.getException());
/*     */       }
/*  47 */       return orders;
/*     */     }
/*     */     catch (DataCacheException e) {
/*  50 */       throw new JFException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public IOrder getOrderHistoryById(String id) throws JFException
/*     */   {
/*     */     try
/*     */     {
/*  58 */       List<IOrder> orders = new ArrayList();
/*  59 */       LoadingProgressListenerImpl loadingProgressListener = new LoadingProgressListenerImpl(null);
/*  60 */       this.feedDataProvider.loadOrderHistoricalDataByIdSynched(id, new OrdersListenerImpl(Long.MIN_VALUE, Long.MAX_VALUE, orders), loadingProgressListener);
/*     */       
/*  62 */       if (loadingProgressListener.getException() != null) {
/*  63 */         throw new JFException("Error while loading orders history", loadingProgressListener.getException());
/*     */       }
/*  65 */       IOrder order = null;
/*  66 */       if (!ObjectUtils.isNullOrEmpty(orders)) {}
/*  67 */       return (IOrder)orders.get(0);
/*     */ 
/*     */     }
/*     */     catch (DataCacheException e)
/*     */     {
/*  72 */       throw new JFException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void readOrdersHistory(Instrument instrument, long from, long to, OrdersListener ordersListener, ILoadingProgressListener loadingProgress) throws JFException
/*     */   {
/*     */     try {
/*  79 */       this.feedDataProvider.loadOrdersHistoricalData(instrument, from, to, ordersListener, loadingProgress);
/*     */     } catch (DataCacheException e) {
/*  81 */       throw new JFException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public HistoryOrder processOrders(Instrument instrument, OrderHistoricalData orderData, long from, long to)
/*     */   {
/*  87 */     long openTime = orderData.getEntryOrder().getFillTime();
/*  88 */     OrderHistoricalData.CloseData[] closeDatas = (OrderHistoricalData.CloseData[])orderData.getCloseDataMap().values().toArray(new OrderHistoricalData.CloseData[orderData.getCloseDataMap().size()]);
/*  89 */     BigDecimal closePriceMulAmount = BigDecimal.ZERO;
/*  90 */     BigDecimal sumClosedAmounts = BigDecimal.ZERO;
/*  91 */     long closeTime = orderData.getMergedToTime() == Long.MIN_VALUE ? orderData.getHistoryEnd() : orderData.getMergedToTime();
/*  92 */     for (OrderHistoricalData.CloseData closeData : closeDatas) {
/*  93 */       if (closeData.getTime() > closeTime) {
/*  94 */         closeTime = closeData.getTime();
/*     */       }
/*  96 */       closePriceMulAmount = closePriceMulAmount.add(closeData.getPrice().multiply(closeData.getAmount()));
/*  97 */       sumClosedAmounts = sumClosedAmounts.add(closeData.getAmount());
/*     */     }
/*  99 */     if ((to >= openTime) && (from <= closeTime)) {
/* 100 */       double closePrice = 0.0D;
/* 101 */       if (sumClosedAmounts.compareTo(BigDecimal.ZERO) != 0) {
/* 102 */         closePrice = closePriceMulAmount.divide(sumClosedAmounts, 7, 6).doubleValue();
/* 103 */       } else if (closeDatas.length == 1)
/*     */       {
/* 105 */         closePrice = closeDatas[0].getPrice().doubleValue();
/* 106 */       } else if ((closeDatas.length == 0) && (orderData.getMergedToGroupId() != null))
/*     */       {
/* 108 */         closePrice = orderData.getEntryOrder().getOpenPrice().doubleValue();
/*     */       }
/* 110 */       return createHistoryOrder(instrument, orderData, closeTime, closePrice);
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private HistoryOrder createHistoryOrder(Instrument instrument, OrderHistoricalData orderData, long closeTime, double closePrice) {
/* 116 */     return new HistoryOrder(instrument, orderData, this.accountCurrency, closeTime, closePrice);
/*     */   }
/*     */   
/*     */   private class LoadingProgressListenerImpl implements ILoadingProgressListener
/*     */   {
/* 121 */     private Throwable exception = null;
/*     */     
/*     */     private LoadingProgressListenerImpl() {}
/*     */     
/*     */     public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*     */     
/*     */     public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*     */     {
/* 129 */       this.exception = e;
/*     */     }
/*     */     
/*     */     public boolean stopJob()
/*     */     {
/* 134 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Throwable getException()
/*     */     {
/* 141 */       return this.exception;
/*     */     }
/*     */   }
/*     */   
/*     */   private class OrdersListenerImpl implements OrdersListener
/*     */   {
/*     */     private List<IOrder> orders;
/*     */     private final long from;
/*     */     private final long to;
/*     */     
/*     */     public OrdersListenerImpl(long arg3, List<IOrder> arg5) {
/* 152 */       this.from = from;
/* 153 */       this.to = to;
/* 154 */       this.orders = orders;
/*     */     }
/*     */     
/*     */ 
/*     */     public void newOrder(Instrument instrument, OrderHistoricalData orderData)
/*     */     {
/* 160 */       if (!orderData.isClosed()) {
/* 161 */         return;
/*     */       }
/* 163 */       HistoryOrder order = HistoryOrderProvider.this.processOrders(instrument, orderData, this.from, this.to);
/* 164 */       if (order != null) {
/* 165 */         this.orders.add(order);
/*     */       }
/*     */     }
/*     */     
/*     */     public void orderChange(Instrument instrument, OrderHistoricalData orderData) {}
/*     */     
/*     */     public void orderMerge(Instrument instrument, OrderHistoricalData resultingOrderData, List<OrderHistoricalData> mergedOrdersData) {}
/*     */     
/*     */     public void ordersInvalidated(Instrument instrument) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\HistoryOrderProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */