/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IChart;
/*    */ import com.dukascopy.api.IClientChartController;
/*    */ import com.dukascopy.api.IClientChartPresentationManager;
/*    */ import com.dukascopy.api.IClientGUI;
/*    */ import com.dukascopy.charts.main.interfaces.IContextChartsController;
/*    */ import java.awt.Container;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.SwingUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientGUI
/*    */   implements IClientGUI
/*    */ {
/*    */   private final int chartId;
/*    */   private final IChart chart;
/*    */   private final IClientChartController clientChartController;
/*    */   private final IContextChartsController contextChartsController;
/*    */   private final IClientChartPresentationManager clientChartPresentationManager;
/*    */   private JPanel chartPanel;
/*    */   
/*    */   public ClientGUI(IChart chart, IContextChartsController contextChartsController)
/*    */   {
/* 33 */     this.chart = chart;
/* 34 */     this.contextChartsController = contextChartsController;
/* 35 */     this.chartId = contextChartsController.getChartId(chart);
/* 36 */     this.clientChartController = new ClientChartController(contextChartsController.getChartsController(), this.chartId);
/* 37 */     this.clientChartPresentationManager = new ClientChartPresentationManager(contextChartsController.getChartsController(), this.chartId, chart);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getChartId()
/*    */   {
/* 45 */     return this.chartId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public IChart getChart()
/*    */   {
/* 53 */     return this.chart;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public JPanel getChartPanel()
/*    */   {
/* 61 */     if (this.chartPanel == null) {
/* 62 */       this.chartPanel = this.contextChartsController.getChartPanel(this.chart);
/* 63 */       Container mainPanel = SwingUtilities.getAncestorNamed(IClientGUI.class.getName(), this.chartPanel);
/* 64 */       if ((mainPanel != null) && ((mainPanel instanceof JPanel)))
/* 65 */         this.chartPanel = ((JPanel)JPanel.class.cast(mainPanel));
/*    */     }
/* 67 */     return this.chartPanel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public IClientChartPresentationManager getChartPresentationManager()
/*    */   {
/* 75 */     return this.clientChartPresentationManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public IClientChartController getClientChartController()
/*    */   {
/* 83 */     return this.clientChartController;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ClientGUI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */