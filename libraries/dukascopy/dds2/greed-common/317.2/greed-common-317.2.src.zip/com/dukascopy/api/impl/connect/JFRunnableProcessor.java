/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IMessage;
/*     */ import com.dukascopy.api.IOrder.State;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.impl.execution.ScienceQueue;
/*     */ import com.dukascopy.api.impl.execution.ScienceRejectedExecutionHandler;
/*     */ import com.dukascopy.api.impl.execution.ScienceThreadFactory;
/*     */ import com.dukascopy.api.impl.execution.ScienceThreadPoolExecutor;
/*     */ import com.dukascopy.api.impl.execution.Task;
/*     */ import com.dukascopy.api.impl.execution.TaskCustom;
/*     */ import com.dukascopy.api.impl.execution.TaskOrderNotify;
/*     */ import com.dukascopy.api.plugins.IMessageListener;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*     */ import com.dukascopy.dds4.transport.msg.system.ErrorResponseMessage;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public abstract class JFRunnableProcessor<CONTEXT extends com.dukascopy.api.IContext, RUNNABLE extends com.dukascopy.api.IJFRunnable<CONTEXT>>
/*     */ {
/*  33 */   private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(JFRunnableProcessor.class);
/*     */   
/*  35 */   private ScienceThreadPoolExecutor executorService = null;
/*     */   
/*     */   private IMessageListener messageListener;
/*     */   protected final RUNNABLE jfRunnable;
/*     */   protected final JForexTaskManager<CONTEXT, RUNNABLE, ?> taskManager;
/*     */   private final boolean fullAccessGranted;
/*  41 */   private boolean onBarImplemented = true;
/*     */   
/*     */ 
/*     */   public JFRunnableProcessor(JForexTaskManager<CONTEXT, RUNNABLE, ?> taskManager, IMessageListener messageListener, RUNNABLE jfRunnable, boolean fullAccessGranted)
/*     */   {
/*  46 */     this.messageListener = messageListener;
/*  47 */     this.jfRunnable = jfRunnable;
/*  48 */     this.taskManager = taskManager;
/*  49 */     this.fullAccessGranted = fullAccessGranted;
/*     */     
/*  51 */     ScienceQueue strategyQueue = new ScienceQueue();
/*     */     
/*  53 */     this.executorService = new ScienceThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, strategyQueue);
/*  54 */     this.executorService.setThreadFactory(new ScienceThreadFactory(jfRunnable.getClass().getClassLoader(), jfRunnable.getClass().getSimpleName()));
/*  55 */     this.executorService.prestartAllCoreThreads();
/*     */   }
/*     */   
/*     */   public IMessageListener getMessageListener() {
/*  59 */     return this.messageListener;
/*     */   }
/*     */   
/*     */   public void setMessageListener(IMessageListener messageListener) {
/*  63 */     this.messageListener = messageListener;
/*     */   }
/*     */   
/*     */   public void onMessage(IMessage message, boolean asynch) {
/*  67 */     Task<?> task = new com.dukascopy.api.impl.execution.TaskMessage(this.taskManager, this.messageListener, message, this.taskManager.getExceptionHandler());
/*  68 */     executeTask(task, asynch);
/*     */   }
/*     */   
/*     */   public void updateOrder(OrderGroupMessage orderGroup) {
/*  72 */     Task<?> task = new com.dukascopy.api.impl.execution.TaskOrderGroupUpdate(this.taskManager, this.messageListener, orderGroup);
/*  73 */     executeTask(task, false);
/*     */   }
/*     */   
/*     */   public void updateOrder(OrderMessageExt orderMessage) {
/*  77 */     Task<?> task = new com.dukascopy.api.impl.execution.TaskOrderUpdate(this.taskManager, this.messageListener, orderMessage);
/*  78 */     executeTask(task, false);
/*     */   }
/*     */   
/*     */   public void updateOrder(NotificationMessage notificationMessage) {
/*  82 */     Task<?> task = new TaskOrderNotify(this.taskManager, this.messageListener, notificationMessage);
/*  83 */     executeTask(task, false);
/*     */   }
/*     */   
/*     */   public void updateOrder(MergePositionsMessage mergePositionsMessage) {
/*  87 */     Task<?> task = new com.dukascopy.api.impl.execution.TaskOrdersMerged(this.taskManager, this.messageListener, mergePositionsMessage);
/*  88 */     executeTask(task, false);
/*     */   }
/*     */   
/*     */   public void updateOrder(PlatformOrderImpl order, ErrorResponseMessage errorResponseMessage) {
/*  92 */     if (order != null) {
/*  93 */       Task<?> task = new com.dukascopy.api.impl.execution.TaskOrderError(this.taskManager, this.messageListener, errorResponseMessage, order, this.taskManager.getExceptionHandler());
/*  94 */       executeTask(task, true);
/*     */     } else {
/*  96 */       LOGGER.warn("WARNING[onErrorMessage]:" + errorResponseMessage);
/*     */     }
/*     */   }
/*     */   
/*     */   public void waitForUpdate(PlatformOrderImpl platformOrderImpl, long timeout, TimeUnit unit) throws InterruptedException {
/* 101 */     this.executorService.runExceptTicksAndBars(platformOrderImpl, timeout, unit);
/*     */   }
/*     */   
/*     */   public void waitForUpdate(PlatformOrderImpl platformOrderImpl, long timeout, TimeUnit unit, IOrder.State... expectedStates) throws InterruptedException, com.dukascopy.api.JFException
/*     */   {
/* 106 */     List<String> states = new java.util.ArrayList();
/* 107 */     if ((expectedStates != null) && (expectedStates.length > 0)) {
/* 108 */       for (IOrder.State expectedState : expectedStates) {
/* 109 */         states.add(expectedState.name());
/*     */       }
/*     */     }
/* 112 */     this.executorService.runExceptTicksAndBars(platformOrderImpl, timeout, unit, (String[])states.toArray(new String[states.size()]));
/*     */   }
/*     */   
/*     */   public long getRunnableId() {
/* 116 */     return ((ScienceThreadFactory)this.executorService.getThreadFactory()).getThreadId();
/*     */   }
/*     */   
/*     */   public long onStart(CONTEXT platformConfigImpl) {
/* 120 */     ScienceRejectedExecutionHandler rejectedExecutionHandler = new ScienceRejectedExecutionHandler(platformConfigImpl, ((ScienceThreadFactory)this.executorService.getThreadFactory()).getThread());
/*     */     
/* 122 */     this.executorService.setRejectedExecutionHandler(rejectedExecutionHandler);
/*     */     
/* 124 */     Task<?> task = new com.dukascopy.api.impl.execution.TaskStart(platformConfigImpl, this.jfRunnable);
/*     */     try
/*     */     {
/* 127 */       task.call();
/*     */     } catch (Exception ex) {
/* 129 */       String msg = representError(this.messageListener, ex);
/* 130 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, ex, false);
/* 131 */       this.taskManager.getExceptionHandler().onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_START, ex);
/* 132 */       return 0L;
/*     */     }
/*     */     
/* 135 */     return getRunnableId();
/*     */   }
/*     */   
/*     */   public void onStop() {
/* 139 */     if (this.executorService == null) {
/* 140 */       return;
/*     */     }
/*     */     
/* 143 */     this.executorService.getQueue().clear();
/*     */     
/* 145 */     Task<?> stopCallable = new com.dukascopy.api.impl.execution.TaskStop(this.jfRunnable);
/*     */     
/* 147 */     if (Thread.currentThread().getId() == getRunnableId()) {
/*     */       try {
/* 149 */         stopCallable.call();
/*     */       } catch (Exception e) {
/* 151 */         String msg = representError(this.messageListener, e);
/* 152 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, e, false);
/* 153 */         LOGGER.error(e.getMessage(), e);
/*     */       }
/*     */     } else {
/* 156 */       Future<?> future = this.executorService.submit(stopCallable);
/*     */       try {
/* 158 */         future.get(5L, TimeUnit.SECONDS);
/*     */       } catch (TimeoutException e) {
/* 160 */         ((ScienceThreadFactory)this.executorService.getThreadFactory()).getThread().interrupt();
/*     */         try {
/* 162 */           future.get(5L, TimeUnit.SECONDS);
/*     */         } catch (Exception e1) {
/* 164 */           LOGGER.error(e.getMessage(), e);
/*     */         }
/*     */       } catch (Exception e) {
/* 167 */         String msg = representError(this.messageListener, e);
/* 168 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, e, false);
/* 169 */         LOGGER.error(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 173 */     this.executorService.shutdown();
/*     */   }
/*     */   
/*     */   public void halt() {
/* 177 */     this.executorService.shutdownNow();
/*     */     try {
/* 179 */       this.executorService.awaitTermination(5L, TimeUnit.SECONDS);
/*     */     }
/*     */     catch (InterruptedException e) {}
/*     */     
/* 183 */     if (!this.executorService.isTerminated()) {
/* 184 */       LOGGER.warn("Killing strategy thread [" + this.messageListener.getClass().getSimpleName() + "]");
/* 185 */       NotificationUtilsProvider.getNotificationUtils().postWarningMessage("Killing strategy thread [" + this.messageListener.getClass().getSimpleName() + "]");
/* 186 */       this.executorService.kill();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isStopping() {
/* 191 */     return this.taskManager.isStrategyStopping();
/*     */   }
/*     */   
/*     */   public <T> Future<T> executeTask(Callable<T> callable, boolean asynch) {
/* 195 */     if ((this.taskManager.isThreadOk(Thread.currentThread().getId())) && (!asynch)) {
/* 196 */       FutureTask<T> future = new FutureTask(callable);
/* 197 */       future.run();
/* 198 */       return future; }
/* 199 */     if (!this.taskManager.isStrategyStopping()) {
/* 200 */       if ((callable instanceof Task)) {
/* 201 */         return this.executorService.submit(callable);
/*     */       }
/* 203 */       return this.executorService.submit(new TaskCustom(this.taskManager, callable, false));
/*     */     }
/*     */     
/* 206 */     return null;
/*     */   }
/*     */   
/*     */   public Future<Void> executeStop(JForexTaskManager<CONTEXT, RUNNABLE, ?>.StopCallable callable) {
/* 210 */     return this.executorService.submit(new TaskCustom(this.taskManager, callable, true));
/*     */   }
/*     */   
/*     */   public static String representError(Object str, Throwable ex) {
/*     */     Throwable throwable;
/*     */     Throwable throwable;
/* 216 */     if (ex.getCause() != null) {
/* 217 */       throwable = ex.getCause();
/*     */     } else {
/* 219 */       throwable = ex;
/*     */     }
/*     */     
/* 222 */     String msg = throwable.toString();
/*     */     
/* 224 */     StackTraceElement[] elements = throwable.getStackTrace();
/* 225 */     StackTraceElement element = elements[0];
/* 226 */     if (str != null) {
/* 227 */       for (StackTraceElement stackTraceElement : elements) {
/* 228 */         if (stackTraceElement.getClassName().equals(str.getClass().getName())) {
/* 229 */           element = stackTraceElement;
/* 230 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 234 */     if (element != null) {
/* 235 */       msg = msg + " @ " + element;
/*     */     }
/*     */     
/* 238 */     return msg;
/*     */   }
/*     */   
/*     */   public JForexTaskManager<CONTEXT, RUNNABLE, ?> getTaskManager()
/*     */   {
/* 243 */     return this.taskManager;
/*     */   }
/*     */   
/*     */   public RUNNABLE getJfRunnable() {
/* 247 */     return this.jfRunnable;
/*     */   }
/*     */   
/*     */   public boolean isOnBarImplemented() {
/* 251 */     return this.onBarImplemented;
/*     */   }
/*     */   
/*     */   public void setOnBarImplemented(boolean onBarImplemented) {
/* 255 */     this.onBarImplemented = onBarImplemented;
/*     */   }
/*     */   
/*     */   public boolean isFullAccessGranted() {
/* 259 */     return this.fullAccessGranted;
/*     */   }
/*     */   
/*     */   public void setSubscribedInstruments(Set<Instrument> requiredInstruments, boolean lock) {
/* 263 */     this.taskManager.setSubscribedInstruments(requiredInstruments, lock);
/*     */   }
/*     */   
/*     */   public Set<Instrument> getSubscribedInstruments() {
/* 267 */     return this.taskManager.getSubscribedInstruments();
/*     */   }
/*     */   
/*     */   public com.dukascopy.api.IAccount getAccount() {
/* 271 */     return this.taskManager.getAccount();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JFRunnableProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */