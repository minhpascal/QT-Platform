package com.dukascopy.charts.data.datacache.intraperiod.listener;

import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;

public class LastPriceRangeLiveFeedListener
  extends LastAbstractPriceAggregationLiveFeedListener<PriceRangeData>
  implements IPriceRangeLiveFeedListener
{}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\listener\LastPriceRangeLiveFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */