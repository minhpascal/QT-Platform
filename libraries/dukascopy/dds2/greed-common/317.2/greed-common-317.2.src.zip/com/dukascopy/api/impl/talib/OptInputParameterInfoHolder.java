package com.dukascopy.api.impl.talib;

import com.tictactec.ta.lib.meta.annotation.OptInputParameterType;

public class OptInputParameterInfoHolder
  extends Holder
{
  public String paramName;
  public String displayName;
  public int flags;
  public OptInputParameterType type;
  public Class<? extends Object> dataSet;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\talib\OptInputParameterInfoHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */