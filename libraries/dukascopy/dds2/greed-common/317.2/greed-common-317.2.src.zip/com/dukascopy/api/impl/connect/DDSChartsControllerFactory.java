/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*    */ import java.lang.reflect.Method;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DDSChartsControllerFactory
/*    */ {
/* 20 */   private static final Logger LOGGER = LoggerFactory.getLogger(DDSChartsControllerFactory.class);
/*    */   
/* 22 */   private static DDSChartsControllerFactory instance = null;
/*    */   private final Method getInstanceMethod;
/*    */   
/*    */   public static DDSChartsControllerFactory instance() {
/* 26 */     if (instance == null) {
/* 27 */       instance = new DDSChartsControllerFactory();
/*    */     }
/* 29 */     return instance;
/*    */   }
/*    */   
/*    */   protected DDSChartsControllerFactory() {
/*    */     try {
/* 34 */       Class<?> ddsChartsControllerClass = Thread.currentThread().getContextClassLoader().loadClass("com.dukascopy.charts.main.DDSChartsControllerImpl");
/* 35 */       this.getInstanceMethod = ddsChartsControllerClass.getMethod("getInstance", new Class[0]);
/*    */     } catch (Exception e) {
/* 37 */       LOGGER.error(e.getMessage(), e);
/* 38 */       throw new RuntimeException("Cannot initialize DDSChartsController Factory:" + e.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public DDSChartsController getDefaultInstance()
/*    */   {
/*    */     try
/*    */     {
/* 48 */       return (DDSChartsController)DDSChartsController.class.cast(this.getInstanceMethod.invoke(null, new Object[0]));
/*    */     } catch (Exception e) {
/* 50 */       LOGGER.error(e.getMessage(), e);
/* 51 */       throw new RuntimeException("Cannot create DDSChartsController:" + e.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\DDSChartsControllerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */