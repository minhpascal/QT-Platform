/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationLevel;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ public class PrintStreamNotificationUtils
/*     */   implements INotificationUtils
/*     */ {
/*     */   private final PrintStream out;
/*     */   private final PrintStream err;
/*     */   
/*     */   public PrintStreamNotificationUtils(PrintStream out, PrintStream err)
/*     */   {
/*  16 */     this.out = out;
/*  17 */     this.err = err;
/*     */   }
/*     */   
/*     */   public void postInfoMessage(String message)
/*     */   {
/*  22 */     postInfoMessage(message, null, false);
/*     */   }
/*     */   
/*     */   public void postInfoMessage(String message, Object... arguments)
/*     */   {
/*  27 */     postInfoMessage(message, null, false);
/*     */   }
/*     */   
/*     */   public void postInfoMessage(String message, boolean localMessage)
/*     */   {
/*  32 */     postInfoMessage(message, null, localMessage);
/*     */   }
/*     */   
/*     */   public void postInfoMessage(String message, Throwable t)
/*     */   {
/*  37 */     postInfoMessage(message, t, false);
/*     */   }
/*     */   
/*     */   public void postInfoMessage(String message, Throwable t, boolean localMessage)
/*     */   {
/*  42 */     this.out.println(message);
/*  43 */     if (t != null) {
/*  44 */       this.out.print(t.getMessage() + ": ");
/*  45 */       t.printStackTrace(this.err);
/*     */     }
/*  47 */     if ((!localMessage) && (ActivityLogger.getInstance() != null)) {
/*  48 */       ActivityLogger.getInstance().add(message);
/*     */     }
/*     */   }
/*     */   
/*     */   public void postWarningMessage(String message)
/*     */   {
/*  54 */     postErrorMessage(message, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void postWarningMessage(String message, String defaultMessage)
/*     */   {
/*  60 */     postErrorMessage(message, null, false);
/*     */   }
/*     */   
/*     */   public void postWarningMessage(String message, String defaultMessage, boolean localMessage)
/*     */   {
/*  65 */     postErrorMessage(message, null, localMessage);
/*     */   }
/*     */   
/*     */   public void postWarningMessage(String message, boolean localMessage)
/*     */   {
/*  70 */     postErrorMessage(message, null, localMessage);
/*     */   }
/*     */   
/*     */   public void postWarningMessage(String message, Throwable t)
/*     */   {
/*  75 */     postErrorMessage(message, t, false);
/*     */   }
/*     */   
/*     */   public void postWarningMessage(String message, Throwable t, boolean localMessage)
/*     */   {
/*  80 */     postErrorMessage(message, t, localMessage);
/*     */   }
/*     */   
/*     */   public void postErrorMessage(String message)
/*     */   {
/*  85 */     postErrorMessage(message, null, false);
/*     */   }
/*     */   
/*     */   public void postErrorMessage(String message, boolean localMessage)
/*     */   {
/*  90 */     postErrorMessage(message, null, localMessage);
/*     */   }
/*     */   
/*     */   public void postErrorMessage(String message, Throwable t)
/*     */   {
/*  95 */     postErrorMessage(message, t, false);
/*     */   }
/*     */   
/*     */   public void postErrorMessage(String message, Throwable t, boolean localMessage)
/*     */   {
/* 100 */     this.err.println(message);
/* 101 */     if (t != null) {
/* 102 */       this.err.print(t.getMessage() + ": ");
/* 103 */       t.printStackTrace(this.err);
/*     */     }
/* 105 */     if ((!localMessage) && (ActivityLogger.getInstance() != null)) {
/* 106 */       ActivityLogger.getInstance().add(message);
/*     */     }
/*     */   }
/*     */   
/*     */   public void postFatalMessage(String message)
/*     */   {
/* 112 */     postErrorMessage(message, null, false);
/*     */   }
/*     */   
/*     */   public void postFatalMessage(String message, String defaultMessage)
/*     */   {
/* 117 */     postErrorMessage(message, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void postFatalMessage(String message, boolean localMessage)
/*     */   {
/* 123 */     postErrorMessage(message, null, localMessage);
/*     */   }
/*     */   
/*     */   public void postFatalMessage(String message, Throwable t)
/*     */   {
/* 128 */     postErrorMessage(message, t, false);
/*     */   }
/*     */   
/*     */   public void postFatalMessage(String message, Throwable t, boolean localMessage)
/*     */   {
/* 133 */     postErrorMessage(message, t, localMessage);
/*     */   }
/*     */   
/*     */   public void postMessage(String message, NotificationLevel level)
/*     */   {
/* 138 */     switch (level) {
/*     */     case INFO: 
/* 140 */       postInfoMessage(message);
/* 141 */       break;
/*     */     case WARNING: 
/* 143 */       postWarningMessage(message);
/* 144 */       break;
/*     */     case ERROR: 
/* 146 */       postErrorMessage(message);
/* 147 */       break;
/*     */     case INFOCLIENT: 
/* 149 */       postInfoMessage(message);
/* 150 */       break;
/*     */     case NOTIFCLIENT: 
/* 152 */       postInfoMessage(message);
/* 153 */       break;
/*     */     default: 
/* 155 */       throw new IllegalArgumentException("Unknown Notification Level: " + level);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PrintStreamNotificationUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */