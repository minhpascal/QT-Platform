/*    */ package com.dukascopy.api.impl.connect.strategy.remote;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.strategy.StrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.remote.IRemoteStrategyDescriptor;
/*    */ import com.dukascopy.dds2.greed.util.ParameterUtils;
/*    */ import com.dukascopy.dds3.transport.msg.jss.StrategyProcessDescriptor;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class RemoteStrategyDescriptor extends StrategyDescriptor implements IRemoteStrategyDescriptor
/*    */ {
/*    */   public RemoteStrategyDescriptor(StrategyProcessDescriptor descriptor)
/*    */   {
/* 13 */     this(descriptor, null);
/*    */   }
/*    */   
/*    */   public RemoteStrategyDescriptor(StrategyProcessDescriptor d, String message) {
/* 17 */     super(d.getFileName(), d.getStartTime() == null ? 0L : d.getStartTime().longValue(), ParameterUtils.getParameters(d), UUID.fromString(d.getPid()), message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\remote\RemoteStrategyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */