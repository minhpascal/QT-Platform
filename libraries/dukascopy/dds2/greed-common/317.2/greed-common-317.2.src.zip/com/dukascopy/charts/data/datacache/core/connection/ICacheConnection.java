package com.dukascopy.charts.data.datacache.core.connection;

import java.io.File;
import java.io.IOException;

public abstract interface ICacheConnection
  extends AutoCloseable
{
  public abstract boolean isFileExists();
  
  public abstract void seek(long paramLong)
    throws IOException;
  
  public abstract long length()
    throws IOException;
  
  public abstract long getFilePointer()
    throws IOException;
  
  public abstract String getFilePath();
  
  public abstract String getFileAbsolutePath();
  
  public abstract String getFileName();
  
  public abstract boolean isFile();
  
  public abstract boolean isDirectory();
  
  public abstract boolean isForFile(File paramFile);
  
  public abstract void scheduleToDeleteFileOnExit();
  
  public abstract void close();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\ICacheConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */