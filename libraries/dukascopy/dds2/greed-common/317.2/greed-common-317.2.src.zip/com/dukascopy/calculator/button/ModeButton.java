/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ import com.dukascopy.calculator.function.Mode;
/*    */ import java.awt.event.ActionEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModeButton
/*    */   extends CalculatorButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ModeButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 17 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 18 */     setPobject(new Mode());
/* 19 */     setText();
/* 20 */     setTextSize();
/* 21 */     addActionListener(this);
/*    */     
/* 23 */     setShortcut('?');
/* 24 */     setToolTipKey("sc.calculator.change.mode");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent actionEvent)
/*    */   {
/* 36 */     synchronized (this.mainCalculatorPanel) {
/* 37 */       if (getMainCalculatorPanel().getOn()) {
/* 38 */         getMainCalculatorPanel().setMode(getMainCalculatorPanel().getMode() + 1);
/* 39 */         getMainCalculatorPanel().setShift(false);
/* 40 */         getMainCalculatorPanel().updateDisplay(true, true);
/*    */       }
/* 42 */       getMainCalculatorPanel().requestFocusInWindow();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\ModeButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */