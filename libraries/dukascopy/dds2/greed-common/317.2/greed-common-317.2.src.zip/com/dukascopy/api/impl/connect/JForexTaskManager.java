/*      */ package com.dukascopy.api.impl.connect;
/*      */ 
/*      */ import com.dukascopy.api.IClientGUIListener;
/*      */ import com.dukascopy.api.IConsole;
/*      */ import com.dukascopy.api.IContext;
/*      */ import com.dukascopy.api.IEngine.OrderCommand;
/*      */ import com.dukascopy.api.IIndicators;
/*      */ import com.dukascopy.api.IJFRunnable;
/*      */ import com.dukascopy.api.IMessage;
/*      */ import com.dukascopy.api.INewsMessage.Action;
/*      */ import com.dukascopy.api.IOrder;
/*      */ import com.dukascopy.api.IOrder.State;
/*      */ import com.dukascopy.api.IPartialOrder;
/*      */ import com.dukascopy.api.IStrategyBroadcastMessage;
/*      */ import com.dukascopy.api.IStrategyListener;
/*      */ import com.dukascopy.api.IUserInterface;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.JFCurrency;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.impl.History;
/*      */ import com.dukascopy.api.impl.JFRunnableMessages;
/*      */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*      */ import com.dukascopy.api.impl.execution.handler.CommonNotificationHandler;
/*      */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*      */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.OrderHistoricalData;
/*      */ import com.dukascopy.charts.data.datacache.OrderHistoricalData.CloseData;
/*      */ import com.dukascopy.charts.data.datacache.OrderHistoricalData.OpenData;
/*      */ import com.dukascopy.charts.data.orders.ExposureData;
/*      */ import com.dukascopy.charts.data.orders.OrdersProvider;
/*      */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*      */ import com.dukascopy.dds2.greed.util.ProtocolUtils;
/*      */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessage;
/*      */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessageInit;
/*      */ import com.dukascopy.dds3.transport.msg.feeder.InstrumentStatusUpdateMessage;
/*      */ import com.dukascopy.dds3.transport.msg.news.CalendarEvent;
/*      */ import com.dukascopy.dds3.transport.msg.news.NewsCommandMessage;
/*      */ import com.dukascopy.dds3.transport.msg.news.NewsStoryMessage;
/*      */ import com.dukascopy.dds3.transport.msg.news.TextNews;
/*      */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderMessage;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*      */ import com.dukascopy.dds3.transport.msg.ord.OrderSyncMessage;
/*      */ import com.dukascopy.dds3.transport.msg.types.NotificationLevel;
/*      */ import com.dukascopy.dds3.transport.msg.types.NotificationMessageCode;
/*      */ import com.dukascopy.dds3.transport.msg.types.OrderDirection;
/*      */ import com.dukascopy.dds3.transport.msg.types.OrderSide;
/*      */ import com.dukascopy.dds3.transport.msg.types.OrderState;
/*      */ import com.dukascopy.dds3.transport.msg.types.PositionSide;
/*      */ import com.dukascopy.dds3.transport.msg.types.StopDirection;
/*      */ import com.dukascopy.dds4.transport.client.TransportClient;
/*      */ import com.dukascopy.dds4.transport.msg.system.ErrorResponseMessage;
/*      */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.File;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.slf4j.Logger;
/*      */ 
/*      */ public abstract class JForexTaskManager<CONTEXT extends IContext, RUNNABLE extends IJFRunnable<CONTEXT>, UI extends IUserInterface> implements com.dukascopy.api.impl.connect.validation.IThreadValidator, ITaskExecutor
/*      */ {
/*   84 */   protected static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(JForexTaskManager.class);
/*      */   private static final String UID_FORMAT = "%1$s:%2$s:%3$s";
/*   86 */   protected static final BigDecimal ONE_MILLION = BigDecimal.valueOf(1000000L);
/*   87 */   protected static final List<com.dukascopy.api.Period> oldBasicPeriods = DataCacheUtils.getOldBasicPeriods();
/*      */   
/*      */ 
/*   90 */   private long strategyId = Long.MIN_VALUE;
/*      */   
/*      */   protected volatile JFRunnableProcessor<CONTEXT, RUNNABLE> runningJfRunnable;
/*      */   private String runnableKey;
/*   94 */   private final AtomicBoolean strategyStopping = new AtomicBoolean(false);
/*      */   
/*      */   protected CONTEXT apiContext;
/*      */   
/*      */   protected final IFeedDataProvider feedDataProvider;
/*      */   protected final JForexEngineImpl forexEngineImpl;
/*      */   protected final History history;
/*      */   protected final IConsole console;
/*      */   protected final DDSChartsController ddsChartsController;
/*      */   protected final UI userInterface;
/*      */   protected final IClientGUIListener clientGUIListener;
/*      */   protected volatile ISystemListenerExtended systemListener;
/*  106 */   private final Set<IStrategyListener> strategyListeners = Collections.synchronizedSet(new HashSet());
/*      */   
/*      */   private final TransportClient transportClient;
/*      */   
/*  110 */   private final OrdersInternalCollection ordersInternalCollection = new OrdersInternalCollection(this);
/*      */   
/*      */   private final IStrategyExceptionHandler exceptionHandler;
/*      */   
/*      */   protected volatile PlatformAccountImpl account;
/*      */   protected volatile AccountInfoMessage lastAccountInfo;
/*  116 */   private Set<Instrument> requiredInstruments = new HashSet();
/*      */   
/*      */   private final Environment environment;
/*      */   
/*      */   private Boolean connected;
/*      */   
/*      */   private final String externalIP;
/*      */   
/*      */   private final String internalIP;
/*      */   private final String sessionID;
/*      */   private PropertyChangeSupport propertyChangeSupport;
/*      */   private StrategyEventsCallback strategyEventsCallback;
/*      */   private CommonNotificationHandler custodianNotificationHandler;
/*      */   protected ILotAmountProvider lotAmountProvider;
/*      */   protected final Properties serverProperties;
/*      */   
/*      */   public static enum Environment
/*      */   {
/*  134 */     LOCAL_JFOREX,  LOCAL_EMBEDDED,  REMOTE;
/*      */     
/*      */     private Environment() {} }
/*      */   
/*  138 */   public static enum StrategyType { JFX,  MT4,  MT5;
/*      */     private StrategyType() {}
/*  140 */     public int getType() { return ordinal(); }
/*      */   }
/*      */   
/*      */ 
/*  144 */   private static final long FIRST_START_TIMEOUT = TimeUnit.SECONDS.toMillis(2L);
/*  145 */   protected static final long CANDLE_TIMEOUT = TimeUnit.SECONDS.toMillis(5L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Comparator<OrderMessage> orderMessageComparator;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JForexTaskManager(Environment environment, boolean live, String accountName, IConsole console, TransportClient transportClient, DDSChartsController ddsChartsController, ILotAmountProvider lotAmountProvider, UI userInterface, IStrategyExceptionHandler exceptionHandler, AccountInfoMessage lastAccountInfo, AccountInfoMessageInit lastAccountInfoInit, String externalIP, String internalIP, String sessionID, Properties serverProperties, IClientGUIListener clientGUIListener)
/*      */   {
/*  192 */     if (lastAccountInfo == null) {
/*  193 */       throw new NullPointerException("Account info is null");
/*      */     }
/*  195 */     this.feedDataProvider = FeedDataProvider.getDefaultInstance();
/*  196 */     this.history = new History(OrdersProvider.getInstance(), JFCurrency.getInstance(lastAccountInfo.getCurrency()), this.feedDataProvider);
/*  197 */     this.console = console;
/*  198 */     this.transportClient = transportClient;
/*  199 */     this.ddsChartsController = ddsChartsController;
/*  200 */     this.lotAmountProvider = lotAmountProvider;
/*  201 */     this.userInterface = userInterface;
/*  202 */     this.clientGUIListener = clientGUIListener;
/*  203 */     this.exceptionHandler = exceptionHandler;
/*  204 */     this.lastAccountInfo = lastAccountInfo;
/*  205 */     this.account = new PlatformAccountImpl(lastAccountInfo, lastAccountInfoInit, accountName);
/*  206 */     PlatformAccountImpl.setConnected((isOnline()) && (isConnected()));
/*  207 */     this.forexEngineImpl = new JForexEngineImpl(this, accountName, live);
/*  208 */     this.environment = environment;
/*  209 */     this.externalIP = externalIP;
/*  210 */     this.internalIP = internalIP;
/*  211 */     this.sessionID = sessionID;
/*  212 */     this.strategyEventsCallback = null;
/*  213 */     this.custodianNotificationHandler = new CommonNotificationHandler(this);
/*  214 */     this.serverProperties = (serverProperties == null ? new Properties() : serverProperties);
/*  215 */     this.orderMessageComparator = new OrderMessageComparator(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract com.dukascopy.api.impl.connect.validation.IOrderValidator getOrderValidator();
/*      */   
/*      */ 
/*      */ 
/*      */   public abstract long startJfRunnable(RUNNABLE paramRUNNABLE, IStrategyListener paramIStrategyListener, String paramString1, boolean paramBoolean, String paramString2, List<File> paramList);
/*      */   
/*      */ 
/*      */ 
/*      */   protected abstract CONTEXT createContext(JFRunnableProcessor<CONTEXT, RUNNABLE> paramJFRunnableProcessor);
/*      */   
/*      */ 
/*      */ 
/*      */   public void processMessage(ProtocolMessage message)
/*      */   {
/*  235 */     if ((message instanceof AccountInfoMessage)) {
/*  236 */       updateAccountInfo((AccountInfoMessage)message);
/*  237 */     } else if ((message instanceof NewsStoryMessage))
/*  238 */       onNewsMessage((NewsStoryMessage)message);
/*  239 */     if ((message instanceof NewsCommandMessage)) {
/*  240 */       onNewsCommandMessage((NewsCommandMessage)message);
/*  241 */     } else if ((message instanceof NotificationMessage)) {
/*  242 */       onNotifyMessage((NotificationMessage)message);
/*  243 */     } else if ((message instanceof OrderGroupMessage)) {
/*  244 */       onOrderGroupReceived((OrderGroupMessage)message);
/*  245 */     } else if ((message instanceof OrderMessageExt)) {
/*  246 */       onOrderReceived((OrderMessageExt)message);
/*  247 */     } else if ((message instanceof MergePositionsMessage)) {
/*  248 */       onOrdersMergedMessage((MergePositionsMessage)message);
/*  249 */     } else if ((message instanceof InstrumentStatusUpdateMessage)) {
/*  250 */       InstrumentStatusUpdateMessage instrumentStatusMessage = (InstrumentStatusUpdateMessage)message;
/*  251 */       Instrument instrument = Instrument.fromString(instrumentStatusMessage.getInstrument());
/*  252 */       boolean tradable = ObjectUtils.isEqual(com.dukascopy.dds3.transport.msg.types.TradabilityState.TRADING_ALLOWED, instrumentStatusMessage.getState());
/*  253 */       onIntrumentUpdate(instrument, tradable, instrumentStatusMessage.getTimestamp() == null ? FeedDataProvider.getDefaultInstance().getCurrentTime() : instrumentStatusMessage.getTimestamp().longValue());
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateAccountInfo(AccountInfoMessage protocolMessage) {
/*  258 */     this.lastAccountInfo = protocolMessage;
/*  259 */     this.account.updateFromMessage(protocolMessage);
/*      */   }
/*      */   
/*      */   private void initExistingOrders() {
/*  263 */     BigDecimal oneMillion = BigDecimal.valueOf(1000000L);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  294 */     for (Instrument instrument : this.feedDataProvider.getInstrumentsCurrentlySubscribed()) {
/*  295 */       Collection<OrderHistoricalData> orders = OrdersProvider.getInstance().getOrdersForInstrument(instrument).values();
/*  296 */       for (OrderHistoricalData order : orders) {
/*  297 */         if ((!order.isClosed()) && ((!isGlobal()) || (!order.isOpened()))) {
/*  298 */           IOrder.State state = null;
/*  299 */           String orderGroupId = order.getOrderGroupId();
/*  300 */           String label = null;
/*  301 */           IEngine.OrderCommand orderCommand = null;
/*  302 */           BigDecimal requestedAmount = BigDecimal.ZERO;
/*  303 */           BigDecimal originalAmount = BigDecimal.ZERO;
/*  304 */           double filledAmount = 0.0D;
/*  305 */           String pendingOrderId = null;
/*  306 */           IEngine.OrderCommand pendingOrderCommand = null;
/*  307 */           String openingOrderId = null;
/*  308 */           double price = 0.0D;
/*  309 */           String stopLossOrderId = null;
/*  310 */           double stopLossPrice = 0.0D;
/*  311 */           OfferSide stopLossSide = null;
/*  312 */           double trailingStep = 0.0D;
/*  313 */           String takeProfitOrderId = null;
/*  314 */           double takeProfitPrice = 0.0D;
/*  315 */           long goodTillTime = 0L;
/*  316 */           String comment = null;
/*  317 */           long creationTime = 0L;
/*  318 */           long closeTime = 0L;
/*  319 */           long fillTime = 0L;
/*  320 */           double closePrice = 0.0D;
/*  321 */           double commission = order.getCommission().doubleValue();
/*  322 */           List<com.dukascopy.api.IFillOrder> fillHistory = new ArrayList();
/*  323 */           List<com.dukascopy.api.ICloseOrder> closeHistory = new ArrayList();
/*  324 */           if (order.getPendingOrders().size() == 1) {
/*  325 */             OrderHistoricalData.OpenData pendingOrderData = (OrderHistoricalData.OpenData)order.getPendingOrders().get(0);
/*  326 */             state = IOrder.State.OPENED;
/*  327 */             label = pendingOrderData.getLabel();
/*  328 */             openingOrderId = pendingOrderId = pendingOrderData.getOrderId();
/*  329 */             orderCommand = pendingOrderCommand = pendingOrderData.getSide();
/*      */             
/*      */ 
/*  332 */             requestedAmount = pendingOrderData.getAmount().divide(oneMillion, 10, 7);
/*  333 */             if (pendingOrderData.getOriginalAmount() != null) {
/*  334 */               originalAmount = pendingOrderData.getOriginalAmount().divide(oneMillion, 10, 7);
/*      */             }
/*      */             
/*  337 */             if (pendingOrderData.getOpenPrice().compareTo(OrderHistoricalData.NEG_ONE) != 0) {
/*  338 */               price = pendingOrderData.getOpenPrice().doubleValue();
/*      */             }
/*  340 */             if (pendingOrderData.getStopLossPrice().compareTo(OrderHistoricalData.NEG_ONE) != 0) {
/*  341 */               stopLossPrice = pendingOrderData.getStopLossPrice().doubleValue();
/*  342 */               stopLossOrderId = pendingOrderData.getStopLossOrderId();
/*  343 */               stopLossSide = pendingOrderData.isStopLossByBid() ? OfferSide.BID : OfferSide.ASK;
/*  344 */               if (pendingOrderData.getTrailingStep() != null) {
/*  345 */                 trailingStep = pendingOrderData.getTrailingStep().divide(BigDecimal.valueOf(instrument.getPipValue()), 7).doubleValue();
/*      */               }
/*      */             }
/*      */             
/*  349 */             if (pendingOrderData.getTakeProfitPrice().compareTo(OrderHistoricalData.NEG_ONE) != 0) {
/*  350 */               takeProfitOrderId = pendingOrderData.getTakeProfitOrderId();
/*  351 */               takeProfitPrice = pendingOrderData.getTakeProfitPrice().doubleValue();
/*      */             }
/*  353 */             goodTillTime = pendingOrderData.getGoodTillTime();
/*  354 */             comment = pendingOrderData.getComment();
/*  355 */             creationTime = pendingOrderData.getCreationTime();
/*      */           }
/*  357 */           OrderHistoricalData.OpenData entryOrder = order.getEntryOrder();
/*  358 */           if (entryOrder != null) {
/*  359 */             state = IOrder.State.FILLED;
/*  360 */             label = entryOrder.getLabel();
/*  361 */             orderCommand = entryOrder.getSide();
/*  362 */             requestedAmount = requestedAmount.add(entryOrder.getAmount().divide(oneMillion, 10, 7));
/*  363 */             filledAmount = entryOrder.getAmount().divide(oneMillion, 10, 7).doubleValue();
/*  364 */             if (entryOrder.getOriginalAmount() != null) {
/*  365 */               originalAmount = entryOrder.getOriginalAmount().divide(oneMillion, 10, 7);
/*      */             }
/*  367 */             openingOrderId = entryOrder.getOrderId();
/*  368 */             if (entryOrder.getOpenPrice().compareTo(OrderHistoricalData.NEG_ONE) != 0) {
/*  369 */               price = entryOrder.getOpenPrice().doubleValue();
/*      */             }
/*  371 */             if (entryOrder.getStopLossPrice().compareTo(OrderHistoricalData.NEG_ONE) != 0) {
/*  372 */               stopLossPrice = entryOrder.getStopLossPrice().doubleValue();
/*  373 */               stopLossOrderId = entryOrder.getStopLossOrderId();
/*  374 */               stopLossSide = entryOrder.isStopLossByBid() ? OfferSide.BID : OfferSide.ASK;
/*  375 */               if (entryOrder.getTrailingStep() != null) {
/*  376 */                 trailingStep = entryOrder.getTrailingStep().divide(BigDecimal.valueOf(instrument.getPipValue()), 7).doubleValue();
/*      */               }
/*      */             }
/*      */             
/*  380 */             if (entryOrder.getTakeProfitPrice().compareTo(OrderHistoricalData.NEG_ONE) != 0) {
/*  381 */               takeProfitOrderId = entryOrder.getTakeProfitOrderId();
/*  382 */               takeProfitPrice = entryOrder.getTakeProfitPrice().doubleValue();
/*      */             }
/*  384 */             comment = entryOrder.getComment();
/*  385 */             creationTime = entryOrder.getCreationTime();
/*  386 */             fillTime = entryOrder.getFillTime();
/*      */           }
/*      */           
/*  389 */           fillHistory.addAll(JForexAPI.getFillOrders(order.getFillDataMap().values()));
/*  390 */           closeHistory.addAll(JForexAPI.getCloseOrders(order.getCloseDataMap().values()));
/*      */           
/*  392 */           if (!ObjectUtils.isNullOrEmpty(closeHistory)) {
/*  393 */             IPartialOrder lastCloseData = (IPartialOrder)closeHistory.get(closeHistory.size() - 1);
/*  394 */             closeTime = lastCloseData.getTime();
/*  395 */             if (Double.compare(lastCloseData.getPrice(), OrderHistoricalData.NEG_ONE.doubleValue()) != 0) {
/*  396 */               closePrice = lastCloseData.getPrice();
/*      */             }
/*      */             
/*      */ 
/*  400 */             if ((entryOrder != null) && (entryOrder.getAmount().equals(entryOrder.getOriginalAmount()))) {
/*  401 */               for (IPartialOrder close : closeHistory) {
/*  402 */                 filledAmount -= close.getAmount();
/*  403 */                 requestedAmount.subtract(new BigDecimal(close.getAmount()).multiply(oneMillion));
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*  408 */           PlatformOrderImpl platformOrder = new PlatformOrderImpl(this, comment, instrument, requestedAmount.doubleValue(), filledAmount, label, takeProfitPrice, stopLossPrice, stopLossSide, trailingStep, price, closePrice, state, orderGroupId, openingOrderId, pendingOrderId, pendingOrderCommand, stopLossOrderId, takeProfitOrderId, goodTillTime, creationTime, fillTime, closeTime, orderCommand, commission, fillHistory, closeHistory);
/*      */           
/*      */ 
/*      */ 
/*  412 */           platformOrder.setOriginalAmount(originalAmount.doubleValue());
/*  413 */           this.ordersInternalCollection.add(platformOrder);
/*      */         }
/*      */       }
/*  416 */       if (isGlobal()) {
/*  417 */         ExposureData exposure = OrdersProvider.getInstance().getExposureForInstrument(instrument);
/*  418 */         if (exposure.amount.compareTo(BigDecimal.ZERO) > 0) {
/*  419 */           String orderGroupId = this.lastAccountInfo.getUserId() + instrument;
/*  420 */           PlatformOrderImpl platformOrder = new PlatformOrderImpl(this, null, instrument, exposure.amount.divide(oneMillion, 10, 7).doubleValue(), exposure.amount.divide(oneMillion, 10, 7).doubleValue(), orderGroupId, 0.0D, 0.0D, null, 0.0D, exposure.price.doubleValue(), 0.0D, IOrder.State.FILLED, orderGroupId, null, null, null, null, null, 0L, 0L, exposure.time, 0L, exposure.side, exposure.commission.doubleValue(), Collections.emptyList(), Collections.emptyList());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  426 */           this.ordersInternalCollection.add(platformOrder);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public <T> Future<T> executeTask(Callable<T> callable)
/*      */   {
/*  434 */     if (this.runningJfRunnable != null) {
/*  435 */       return this.runningJfRunnable.executeTask(callable, false);
/*      */     }
/*  437 */     return null;
/*      */   }
/*      */   
/*      */   public void onNewsMessage(NewsStoryMessage newsStoryMessage) {
/*      */     try {
/*  442 */       com.dukascopy.dds3.transport.msg.news.NewsContent newsContent = newsStoryMessage.getContent();
/*  443 */       String copyright = newsStoryMessage.getCopyright();
/*  444 */       Set<String> currencies = newsStoryMessage.getCurrencies();
/*  445 */       Set<com.dukascopy.dds4.transport.msg.types.GeoRegion> geoRegions = newsStoryMessage.getGeoRegions();
/*  446 */       String header = newsStoryMessage.getHeader();
/*  447 */       Set<com.dukascopy.dds4.transport.msg.types.MarketSector> marketSectors = newsStoryMessage.getMarketSectors();
/*  448 */       Set<com.dukascopy.dds4.transport.msg.types.StockIndex> stockIndicies = newsStoryMessage.getIndicies();
/*  449 */       String newsId = newsStoryMessage.getNewsId();
/*  450 */       long publishTime = newsStoryMessage.getPublishDate();
/*  451 */       com.dukascopy.dds3.transport.msg.news.NewsSource source = newsStoryMessage.getNewsSource();
/*  452 */       boolean endOfStory = newsStoryMessage.isEndOfStory();
/*  453 */       boolean isHot = newsStoryMessage.isHot();
/*      */       
/*  455 */       PlatformNewsMessageImpl message = null;
/*      */       
/*  457 */       switch (source) {
/*      */       case DJ_LIVE_CALENDAR: 
/*  459 */         CalendarEvent calendarEvent = (CalendarEvent)newsContent;
/*  460 */         message = new PlatformCalendarMessageImpl(calendarEvent, copyright, header, newsId, publishTime, endOfStory, isHot, currencies, geoRegions, marketSectors, stockIndicies);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  473 */         break;
/*      */       case DUKASCOPY_WEBINAR: 
/*      */       case FXSPIDER_NEWS: 
/*      */       case DJ_NEWSWIRES: 
/*  477 */         TextNews plainContent = (TextNews)newsContent;
/*  478 */         message = new PlatformNewsMessageImpl(plainContent == null ? null : plainContent.getText(), copyright, header, newsId, publishTime, endOfStory, isHot, currencies, geoRegions, marketSectors, stockIndicies, source);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  492 */         break;
/*      */       default: 
/*  494 */         LOGGER.warn("Unknown news source");
/*      */       }
/*      */       
/*  497 */       if (message != null) {
/*  498 */         syncMessage(message);
/*      */       }
/*      */     } catch (Exception ex) {
/*  501 */       LOGGER.error(ex.getMessage(), ex);
/*      */     }
/*      */   }
/*      */   
/*      */   public void onNewsCommandMessage(NewsCommandMessage newsCommandMessage) {
/*      */     try {
/*  507 */       INewsMessage.Action action = null;
/*  508 */       com.dukascopy.dds3.transport.msg.news.CommandType commandType = newsCommandMessage.getAction();
/*  509 */       switch (commandType) {
/*      */       case DELETE: 
/*  511 */         action = INewsMessage.Action.DELETE;
/*  512 */         break;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  517 */       if (action != null) {
/*  518 */         PlatformNewsMessageImpl message = new PlatformNewsMessageImpl("", "", "", newsCommandMessage.getEntityId(), 0L, false, false, Collections.emptySet(), Collections.emptySet(), Collections.emptySet(), Collections.emptySet(), newsCommandMessage.getSource(), action);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  532 */         syncMessage(message);
/*      */       }
/*      */     } catch (Exception ex) {
/*  535 */       LOGGER.error(ex.getMessage(), ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void onBroadcastMessage(String transactionId, IStrategyBroadcastMessage message)
/*      */   {
/*  542 */     if (!getUID().equals(transactionId)) {
/*  543 */       syncMessage(message);
/*      */     }
/*      */   }
/*      */   
/*      */   public void onErrorMessage(ErrorResponseMessage errorResponseMessage, PlatformOrderImpl platformOrderImpl) {
/*  548 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  549 */       this.runningJfRunnable.updateOrder(platformOrderImpl, errorResponseMessage);
/*      */     }
/*      */   }
/*      */   
/*      */   public void onNotifyMessage(NotificationMessage notificationMessage) {
/*  554 */     if ((this.runningJfRunnable == null) || (isStrategyStopping())) {
/*  555 */       return;
/*      */     }
/*  557 */     this.runningJfRunnable.updateOrder(notificationMessage);
/*  558 */     this.custodianNotificationHandler.handleNotificationMessage(notificationMessage);
/*      */   }
/*      */   
/*      */   public void onOrderGroupReceived(OrderGroupMessage orderGroupMessage) {
/*  562 */     if ((this.runningJfRunnable == null) || (isStrategyStopping())) {
/*  563 */       return;
/*      */     }
/*  565 */     this.runningJfRunnable.updateOrder(orderGroupMessage);
/*      */   }
/*      */   
/*      */   public void onOrderReceived(OrderMessageExt orderMessage) {
/*  569 */     if ((this.runningJfRunnable == null) || (isStrategyStopping())) {
/*  570 */       return;
/*      */     }
/*  572 */     this.runningJfRunnable.updateOrder(orderMessage);
/*      */   }
/*      */   
/*      */   public void onOrdersMergedMessage(MergePositionsMessage mergePositionsMessage) {
/*  576 */     if ((this.runningJfRunnable == null) || (isStrategyStopping())) {
/*  577 */       return;
/*      */     }
/*  579 */     this.runningJfRunnable.updateOrder(mergePositionsMessage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void onMessage(PlatformMessageImpl platformMessageImpl)
/*      */   {
/*  592 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  593 */       this.runningJfRunnable.onMessage(platformMessageImpl, true);
/*      */     }
/*      */   }
/*      */   
/*      */   private void syncMessage(IMessage message) {
/*  598 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  599 */       this.runningJfRunnable.onMessage(message, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void waitForUpdate(PlatformOrderImpl platformOrderImpl, long timeout, TimeUnit unit)
/*      */     throws InterruptedException
/*      */   {
/*  606 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  607 */       this.runningJfRunnable.waitForUpdate(platformOrderImpl, timeout, unit);
/*      */     }
/*      */   }
/*      */   
/*      */   public void waitForUpdate(PlatformOrderImpl platformOrderImpl, long timeout, TimeUnit unit, IOrder.State... expectedStates) throws InterruptedException, com.dukascopy.api.JFException {
/*  612 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  613 */       this.runningJfRunnable.waitForUpdate(platformOrderImpl, timeout, unit, expectedStates);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean flushQueue(long timeout)
/*      */   {
/*  619 */     Object lock = new Object();
/*  620 */     synchronized (lock) {
/*  621 */       Future<?> future = isStrategyStopping() ? null : executeTask(new com.dukascopy.api.impl.execution.TaskFlush(lock));
/*      */       try {
/*  623 */         lock.wait(timeout);
/*  624 */         return (future == null) || (future.isDone()) || (future.isCancelled());
/*      */       } catch (InterruptedException e) {
/*  626 */         return false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long exuteStart(final JFRunnableProcessor<CONTEXT, RUNNABLE> jfRunnableProcessor, final IStrategyListener listener, final String runnableKey, final String jfxPackMD5, final List<File> custIndFiles)
/*      */   {
/*  638 */     long rc = 0L;
/*  639 */     Future<Long> future = jfRunnableProcessor.executeTask(new Callable()
/*      */     {
/*      */       public Long call() throws Exception {
/*  642 */         JForexTaskManager.this.apiContext = JForexTaskManager.this.createContext(jfRunnableProcessor);
/*  643 */         JForexTaskManager.this.strategyId = jfRunnableProcessor.getRunnableId();
/*  644 */         JForexTaskManager.this.runningJfRunnable = jfRunnableProcessor;
/*  645 */         JForexTaskManager.this.propertyChangeSupport = new PropertyChangeSupport(JForexTaskManager.this.runningJfRunnable.getJfRunnable());
/*      */         
/*      */ 
/*  648 */         JForexTaskManager.this.waitFromStart(JForexTaskManager.FIRST_START_TIMEOUT);
/*      */         
/*  650 */         JForexTaskManager.this.initExistingOrders();
/*      */         
/*      */ 
/*  653 */         IIndicators indicators = null;
/*  654 */         if ((custIndFiles != null) && (custIndFiles.size() > 0)) {
/*  655 */           indicators = JForexTaskManager.this.apiContext.getIndicators();
/*  656 */           for (File customIndicatorFile : custIndFiles) {
/*  657 */             indicators.registerCustomIndicator(customIndicatorFile);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  662 */         JFRunnableMessages.runnableIsStarted(JForexTaskManager.this.runningJfRunnable.getJfRunnable(), JForexTaskManager.this.environment == JForexTaskManager.Environment.REMOTE, jfxPackMD5);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  668 */         JForexTaskManager.this.requiredInstruments = new HashSet(0);
/*  669 */         JForexTaskManager.this.runnableKey = runnableKey;
/*  670 */         JForexTaskManager.this.beforeStart();
/*      */         try {
/*  672 */           JForexTaskManager.this.strategyId = jfRunnableProcessor.onStart(JForexTaskManager.this.apiContext);
/*      */         } catch (Throwable t) {
/*  674 */           JForexTaskManager.this.strategyId = Long.MIN_VALUE;
/*  675 */           JForexTaskManager.LOGGER.error(t.getMessage(), t);
/*      */         }
/*      */         
/*  678 */         if ((JForexTaskManager.this.strategyId > 0L) && (!JForexTaskManager.this.apiContext.isStopped())) {
/*  679 */           if (listener != null) {
/*  680 */             JForexTaskManager.this.strategyListeners.add(listener);
/*      */           }
/*  682 */           JForexTaskManager.this.fireOnStart();
/*      */         } else {
/*  684 */           JForexTaskManager.this.stopStrategy();
/*      */         }
/*      */         
/*  687 */         return Long.valueOf(JForexTaskManager.this.strategyId); } }, false);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  692 */       rc = ((Long)future.get()).longValue();
/*      */     } catch (Exception e) {
/*  694 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*  696 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void beforeStart() {}
/*      */   
/*      */ 
/*      */   protected void afterStop() {}
/*      */   
/*      */ 
/*      */   public Future<Void> stopStrategy()
/*      */   {
/*  708 */     Future<Void> stopResult = null;
/*      */     
/*  710 */     if (!this.strategyStopping.compareAndSet(false, true)) {
/*  711 */       return stopResult;
/*      */     }
/*      */     
/*  714 */     if (this.runningJfRunnable != null) {
/*  715 */       JFRunnableMessages.stoppingStrategy(this.runningJfRunnable.getJfRunnable(), this.environment == Environment.REMOTE);
/*      */       
/*  717 */       JForexTaskManager<CONTEXT, RUNNABLE, UI>.StopCallable cc = new StopCallable();
/*      */       try {
/*  719 */         final IJFRunnable<CONTEXT> jfRunnable = this.runningJfRunnable.getJfRunnable();
/*  720 */         stopResult = this.runningJfRunnable.executeStop(cc);
/*  721 */         afterStop();
/*  722 */         Thread haltThread = new Thread("Strategy " + jfRunnable.getClass().getSimpleName() + " stop timer")
/*      */         {
/*      */           public void run() {
/*      */             try {
/*  726 */               Thread.sleep(15000L);
/*      */             } catch (InterruptedException e) {
/*  728 */               JForexTaskManager.LOGGER.error(e.getMessage(), e);
/*      */             }
/*      */             
/*  731 */             JForexTaskManager.this.runningJfRunnable.halt();
/*      */             
/*  733 */             long strategyId = JForexTaskManager.this.strategyId;
/*  734 */             if (strategyId != Long.MIN_VALUE)
/*      */             {
/*  736 */               JForexTaskManager.this.fireOnStop(jfRunnable);
/*      */             }
/*      */           }
/*  739 */         };
/*  740 */         haltThread.start();
/*      */       } catch (Exception e) {
/*  742 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     }
/*      */     
/*  746 */     return stopResult;
/*      */   }
/*      */   
/*      */   protected void fireOnStart()
/*      */   {
/*  751 */     ISystemListenerExtended systemListener = this.systemListener;
/*  752 */     if (systemListener != null) {
/*  753 */       systemListener.onStart(this.strategyId);
/*      */     }
/*  755 */     IStrategyListener[] listeners = (IStrategyListener[])this.strategyListeners.toArray(new IStrategyListener[this.strategyListeners.size()]);
/*  756 */     for (IStrategyListener listener : listeners) {
/*  757 */       listener.onStart(this.strategyId);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void fireOnStop(IJFRunnable<CONTEXT> jfRunnable)
/*      */   {
/*  764 */     this.propertyChangeSupport = null;
/*  765 */     ISystemListenerExtended systemListener = this.systemListener;
/*  766 */     if (systemListener != null) {
/*  767 */       systemListener.onStop(this.strategyId);
/*      */     }
/*      */     
/*  770 */     IStrategyListener[] listeners = (IStrategyListener[])this.strategyListeners.toArray(new IStrategyListener[this.strategyListeners.size()]);
/*  771 */     for (IStrategyListener listener : listeners) {
/*  772 */       listener.onStop(this.strategyId);
/*      */     }
/*      */     
/*  775 */     com.dukascopy.dds2.greed.agent.strategy.notification.StrategyRateDataNotificationFactory.getIsntance().unsubscribeFromAll(jfRunnable);
/*      */     
/*  777 */     this.strategyId = Long.MIN_VALUE;
/*  778 */     this.ordersInternalCollection.dispose();
/*  779 */     JFRunnableMessages.strategyIsStopped(jfRunnable, "Stopped by Engine", this.environment == Environment.REMOTE);
/*      */   }
/*      */   
/*      */   public boolean isStrategyStopping() {
/*  783 */     return this.strategyStopping.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isThreadOk(long id)
/*      */   {
/*  791 */     return this.strategyId == id;
/*      */   }
/*      */   
/*      */   public void onIntrumentUpdate(Instrument instrument, boolean tradable, long creationTime) {
/*  795 */     InstrumentStatusMessageImpl instrumentStatusMessage = new InstrumentStatusMessageImpl(instrument, tradable, creationTime);
/*  796 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  797 */       this.runningJfRunnable.onMessage(instrumentStatusMessage, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void onConnect(boolean value) {
/*  802 */     if ((this.connected == null) || (this.connected.booleanValue() != value)) {
/*  803 */       ConnectionStatusMessageImpl connectionStatusMessage = new ConnectionStatusMessageImpl(value, this.feedDataProvider.getCurrentTime());
/*  804 */       if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  805 */         this.runningJfRunnable.onMessage(connectionStatusMessage, false);
/*      */       }
/*  807 */       this.connected = Boolean.valueOf(value);
/*      */     }
/*  809 */     PlatformAccountImpl.setConnected((isOnline()) && (isConnected()));
/*      */   }
/*      */   
/*      */   public boolean isConnected() {
/*  813 */     return (this.connected == null) || (this.connected.booleanValue());
/*      */   }
/*      */   
/*      */   public void setSystemListener(ISystemListenerExtended systemListener) {
/*  817 */     this.systemListener = systemListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ILotAmountProvider getLotAmountProvider()
/*      */   {
/*  826 */     if (this.lotAmountProvider == null) {
/*  827 */       this.lotAmountProvider = new DefaultLotAmountProvider();
/*      */     }
/*  829 */     return this.lotAmountProvider;
/*      */   }
/*      */   
/*      */   public void setLotAmountProvider(ILotAmountProvider lotAmountProvider) {
/*  833 */     this.lotAmountProvider = lotAmountProvider;
/*      */   }
/*      */   
/*      */   public void setStrategyEventsCallback(StrategyEventsCallback strategyEventsListener) {
/*  837 */     this.strategyEventsCallback = strategyEventsListener;
/*      */   }
/*      */   
/*      */   public StrategyEventsCallback getStrategyEventsCallback() {
/*  841 */     return this.strategyEventsCallback;
/*      */   }
/*      */   
/*      */   public TransportClient getTransportClient() {
/*  845 */     return this.transportClient;
/*      */   }
/*      */   
/*      */   public OrdersInternalCollection getOrdersInternalCollection() {
/*  849 */     return this.ordersInternalCollection;
/*      */   }
/*      */   
/*      */   public IStrategyExceptionHandler getExceptionHandler() {
/*  853 */     return this.exceptionHandler;
/*      */   }
/*      */   
/*      */   public long getStrategyId() {
/*  857 */     return this.strategyId;
/*      */   }
/*      */   
/*      */   public boolean isGlobal() {
/*  861 */     return this.lastAccountInfo.isGlobal();
/*      */   }
/*      */   
/*      */   public com.dukascopy.api.ICurrency getAccountCurrency() {
/*  865 */     return JFCurrency.getInstance(this.lastAccountInfo.getCurrency());
/*      */   }
/*      */   
/*      */   public String getUserId() {
/*  869 */     return this.lastAccountInfo.getUserId();
/*      */   }
/*      */   
/*      */   public String getAccountLoginId() {
/*  873 */     return this.lastAccountInfo.getAccountLoginId();
/*      */   }
/*      */   
/*      */   public com.dukascopy.api.IAccount getAccount() {
/*  877 */     return this.account;
/*      */   }
/*      */   
/*      */   public IConsole getConsole() {
/*  881 */     return this.console;
/*      */   }
/*      */   
/*      */   public BigDecimal getUsableMargin() {
/*  885 */     return this.lastAccountInfo.getUsableMargin();
/*      */   }
/*      */   
/*      */   public Integer getLeverage() {
/*  889 */     return this.lastAccountInfo.getLeverage();
/*      */   }
/*      */   
/*      */   public String getStrategyKey() {
/*  893 */     return this.runnableKey;
/*      */   }
/*      */   
/*      */   public String getUID() {
/*  897 */     return String.format("%1$s:%2$s:%3$s", new Object[] { Integer.valueOf(hashCode()), this.sessionID, this.runnableKey });
/*      */   }
/*      */   
/*      */   public void setSubscribedInstruments(Set<Instrument> requiredInstruments, boolean lock) {
/*  901 */     if (requiredInstruments == null) {
/*  902 */       requiredInstruments = new HashSet(0);
/*      */     }
/*  904 */     this.requiredInstruments = requiredInstruments;
/*  905 */     ISystemListenerExtended systemListener = this.systemListener;
/*  906 */     if (systemListener != null) {
/*  907 */       systemListener.subscribeToInstruments(requiredInstruments, lock);
/*      */     }
/*      */   }
/*      */   
/*      */   public Set<Instrument> getSubscribedInstruments() {
/*  912 */     ISystemListenerExtended systemListener = this.systemListener;
/*  913 */     if (systemListener != null) {
/*  914 */       return systemListener.getSubscribedInstruments();
/*      */     }
/*  916 */     return new HashSet(0);
/*      */   }
/*      */   
/*      */   public Set<Instrument> getRequiredInstruments()
/*      */   {
/*  921 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/*  922 */       return this.requiredInstruments;
/*      */     }
/*  924 */     return new HashSet(0);
/*      */   }
/*      */   
/*      */   public String getJFRunnableName()
/*      */   {
/*  929 */     return this.runningJfRunnable.getJfRunnable().getClass().getSimpleName();
/*      */   }
/*      */   
/*      */   public StrategyType getStrategyType() {
/*  933 */     if (com.dukascopy.connector.engine.MQL4ConnectorStrategy.class.isAssignableFrom(this.runningJfRunnable.getJfRunnable().getClass())) {
/*  934 */       return StrategyType.MT4;
/*      */     }
/*  936 */     return StrategyType.JFX;
/*      */   }
/*      */   
/*      */   public Environment getEnvironment() {
/*  940 */     return this.environment;
/*      */   }
/*      */   
/*      */   public String getSessionID() {
/*  944 */     return this.sessionID;
/*      */   }
/*      */   
/*      */   public String getInternalIP() {
/*  948 */     return this.internalIP;
/*      */   }
/*      */   
/*      */   public String getExternalIP() {
/*  952 */     return this.externalIP;
/*      */   }
/*      */   
/*      */   public void orderSynch(OrderSyncMessage orderSyncMessage) {
/*  956 */     if ((this.runningJfRunnable == null) || (isStrategyStopping())) {
/*  957 */       return;
/*      */     }
/*  959 */     Collection<String> positionIds = ProtocolUtils.getPositionIds(orderSyncMessage);
/*  960 */     Collection<String> orderIds = ProtocolUtils.getOrderIds(orderSyncMessage);
/*      */     
/*  962 */     if (!isGlobal()) {
/*  963 */       assert (orderIds.isEmpty());
/*  964 */       List<IOrder> orders = this.ordersInternalCollection.allAsOrders();
/*  965 */       for (IOrder iOrder : orders) {
/*  966 */         final PlatformOrderImpl order = (PlatformOrderImpl)iOrder;
/*  967 */         final String positionId = order.getId();
/*  968 */         if (!positionIds.contains(positionId))
/*      */         {
/*  970 */           LOGGER.warn("Order group id [" + positionId + "] doesn't exist anymore");
/*  971 */           if (order.getState() == IOrder.State.CREATED) {
/*  972 */             NotificationMessage message = new NotificationMessage();
/*  973 */             message.setTimestamp(Long.valueOf(new Date().getTime()));
/*  974 */             message.setExternalSysId(order.getLabel());
/*  975 */             message.setUserId(getUserId());
/*  976 */             message.setText("Your order has been rejected");
/*  977 */             message.setCode(NotificationMessageCode.SYSTEM_UNAVAILABLE);
/*  978 */             message.setLevel(NotificationLevel.ERROR);
/*  979 */             this.runningJfRunnable.updateOrder(message);
/*  980 */           } else if (order.getState() == IOrder.State.OPENED) {
/*  981 */             OrderGroupMessage message = new OrderGroupMessage();
/*  982 */             message.setTimestamp(Long.valueOf(new Date().getTime()));
/*  983 */             message.setUserId(getUserId());
/*  984 */             message.setAccountLoginId(getAccountLoginId());
/*  985 */             message.setAmount(BigDecimal.ZERO);
/*  986 */             message.setOrderGroupId(positionId);
/*  987 */             message.setOcoMerge(false);
/*  988 */             message.setInstrument(order.getInstrument().toString());
/*  989 */             this.runningJfRunnable.updateOrder(message);
/*  990 */           } else if (order.getState() == IOrder.State.FILLED) {
/*  991 */             final OrderHistoricalData[] histOrder = new OrderHistoricalData[1];
/*      */             try {
/*  993 */               this.feedDataProvider.loadOrdersHistoricalData(order.getInstrument(), order.getFillTime() - 5L, this.feedDataProvider.getCurrentTime(), new com.dukascopy.charts.data.datacache.OrdersListener()
/*      */               
/*      */ 
/*      */ 
/*  997 */                 new com.dukascopy.charts.data.datacache.ILoadingProgressListener
/*      */                 {
/*      */                   public void newOrder(Instrument instrument, OrderHistoricalData orderData) {
/*  996 */                     if (orderData.getOrderGroupId().equals(positionId))
/*  997 */                       histOrder[0] = orderData; } public void orderChange(Instrument instrument, OrderHistoricalData orderData) {} public void orderMerge(Instrument instrument, OrderHistoricalData resultingOrderData, List<OrderHistoricalData> mergedOrdersData) {} public void ordersInvalidated(Instrument instrument) {} }, new com.dukascopy.charts.data.datacache.ILoadingProgressListener()
/*      */                 {
/*      */                   public void dataLoaded(long start, long end, long currentPosition, String information) {}
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   public void loadingFinished(boolean allDataLoaded, long start, long end, long currentPosition, Throwable e)
/*      */                   {
/* 1019 */                     OrderGroupMessage message = new OrderGroupMessage();
/* 1020 */                     OrderHistoricalData.CloseData closeData = null;
/* 1021 */                     if (histOrder[0] != null) {
/* 1022 */                       for (OrderHistoricalData.CloseData closeData_ : histOrder[0].getCloseDataMap().values()) {
/* 1023 */                         closeData = closeData_;
/*      */                       }
/*      */                     }
/* 1026 */                     message.setTimestamp(Long.valueOf(closeData == null ? new Date().getTime() : closeData.getTime()));
/* 1027 */                     message.setUserId(JForexTaskManager.this.getUserId());
/* 1028 */                     message.setAccountLoginId(JForexTaskManager.this.getAccountLoginId());
/* 1029 */                     message.setAmount(BigDecimal.ZERO);
/* 1030 */                     message.setOrderGroupId(positionId);
/* 1031 */                     BigDecimal priceOpen = closeData == null ? BigDecimal.ZERO : closeData.getPrice();
/* 1032 */                     message.setPriceOpen(priceOpen);
/* 1033 */                     message.setPricePosOpen(priceOpen);
/* 1034 */                     message.setOcoMerge(false);
/* 1035 */                     message.setInstrument(order.getInstrument().toString());
/* 1036 */                     JForexTaskManager.this.runningJfRunnable.updateOrder(message);
/*      */                   }
/*      */                   
/*      */                   public boolean stopJob()
/*      */                   {
/* 1041 */                     return false;
/*      */                   }
/*      */                 });
/*      */             } catch (DataCacheException e) {
/* 1045 */               LOGGER.error(e.getMessage(), e);
/* 1046 */               OrderGroupMessage message = new OrderGroupMessage();
/* 1047 */               message.setTimestamp(Long.valueOf(System.currentTimeMillis()));
/* 1048 */               message.setUserId(getUserId());
/* 1049 */               message.setAccountLoginId(getAccountLoginId());
/* 1050 */               message.setAmount(BigDecimal.ZERO);
/* 1051 */               message.setOrderGroupId(positionId);
/* 1052 */               message.setPriceOpen(BigDecimal.ZERO);
/* 1053 */               message.setPricePosOpen(BigDecimal.ZERO);
/* 1054 */               message.setOcoMerge(false);
/* 1055 */               message.setInstrument(order.getInstrument().toString());
/* 1056 */               this.runningJfRunnable.updateOrder(message);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/* 1062 */       List<IOrder> orders = this.ordersInternalCollection.allAsOrders();
/* 1063 */       for (IOrder iOrder : orders) {
/* 1064 */         PlatformOrderImpl order = (PlatformOrderImpl)iOrder;
/* 1065 */         String positionId = order.getId();
/* 1066 */         String openingOrderId = order.getOpeningOrderId();
/* 1067 */         if ((!positionIds.contains(positionId)) && (!orderIds.contains(openingOrderId)))
/*      */         {
/* 1069 */           if (ObjectUtils.isNullOrEmpty(order.getInstrument())) {
/* 1070 */             LOGGER.error("Order: {} has not assigned instrument", order);
/*      */ 
/*      */           }
/* 1073 */           else if (positionId.endsWith(order.getInstrument().toString()))
/*      */           {
/* 1075 */             LOGGER.warn("Position id [" + positionId + "] doesn't exist anymore");
/* 1076 */             OrderGroupMessage message = new OrderGroupMessage();
/* 1077 */             message.setTimestamp(Long.valueOf(System.currentTimeMillis()));
/* 1078 */             message.setUserId(getUserId());
/* 1079 */             message.setAmount(BigDecimal.ZERO);
/* 1080 */             message.setOrderGroupId(positionId);
/* 1081 */             message.setOcoMerge(false);
/* 1082 */             message.setSide(order.getOrderCommand().isLong() ? PositionSide.LONG : PositionSide.SHORT);
/* 1083 */             message.setInstrument(order.getInstrument().toString());
/* 1084 */             message.setPriceOpen(BigDecimal.ZERO);
/* 1085 */             message.setPricePosOpen(BigDecimal.ZERO);
/* 1086 */             this.runningJfRunnable.updateOrder(message);
/*      */           } else {
/* 1088 */             LOGGER.warn("Order id [" + openingOrderId + "] doesn't exist anymore");
/*      */             
/* 1090 */             if (order.getState() == IOrder.State.CREATED) {
/* 1091 */               NotificationMessage message = new NotificationMessage();
/* 1092 */               message.setTimestamp(Long.valueOf(System.currentTimeMillis()));
/* 1093 */               message.setExternalSysId(order.getLabel());
/* 1094 */               message.setUserId(getUserId());
/* 1095 */               message.setText("Your order has been rejected");
/* 1096 */               message.setCode(NotificationMessageCode.INVALID_ORDER);
/* 1097 */               message.setLevel(NotificationLevel.ERROR);
/* 1098 */               this.runningJfRunnable.updateOrder(message);
/* 1099 */             } else if (order.getState() == IOrder.State.OPENED) {
/* 1100 */               OrderMessageExt message = new OrderMessageExt();
/* 1101 */               message.setTimestamp(Long.valueOf(System.currentTimeMillis()));
/* 1102 */               message.setUserId(getUserId());
/* 1103 */               message.setAccountLoginId(getAccountLoginId());
/* 1104 */               message.setPlaceOffer((order.getOrderCommand() == IEngine.OrderCommand.PLACE_BID) || (order.getOrderCommand() == IEngine.OrderCommand.PLACE_OFFER));
/* 1105 */               message.setMcOrder(false);
/* 1106 */               message.setState(OrderState.CANCELLED);
/* 1107 */               message.setAmount(BigDecimal.valueOf(order.getAmount()));
/* 1108 */               message.setExternalSysId(order.getLabel());
/* 1109 */               message.setOrderId(openingOrderId);
/* 1110 */               message.setPriceClient(BigDecimal.valueOf(order.getOpenPrice()));
/* 1111 */               message.setCreatedDate(new Date(order.getCreationTime()));
/* 1112 */               message.setDirection(OrderDirection.OPEN);
/* 1113 */               message.setOco(false);
/* 1114 */               message.setInstrument(order.getInstrument().toString());
/* 1115 */               message.setSide(order.isLong() ? OrderSide.BUY : OrderSide.SELL);
/* 1116 */               StopDirection stopDirection = null;
/* 1117 */               switch (order.getOrderCommand()) {
/*      */               case BUYSTOP: 
/* 1119 */                 stopDirection = StopDirection.GREATER_ASK;
/* 1120 */                 break;
/*      */               case SELLSTOP: 
/* 1122 */                 stopDirection = StopDirection.LESS_BID;
/* 1123 */                 break;
/*      */               case BUYSTOP_BYBID: 
/* 1125 */                 stopDirection = StopDirection.GREATER_BID;
/* 1126 */                 break;
/*      */               case SELLSTOP_BYASK: 
/* 1128 */                 stopDirection = StopDirection.LESS_ASK;
/*      */               }
/*      */               
/* 1131 */               if (stopDirection != null) {
/* 1132 */                 message.setStopDirection(stopDirection);
/*      */               }
/* 1134 */               message.setPriceStop(BigDecimal.valueOf(order.getOpenPrice()));
/* 1135 */               message.setParentOrderId(positionId);
/* 1136 */               this.runningJfRunnable.updateOrder(message);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void addConfigurationChangeListener(String parameter, PropertyChangeListener listener) {
/* 1145 */     if (this.propertyChangeSupport != null) {
/* 1146 */       this.propertyChangeSupport.addPropertyChangeListener(parameter, listener);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeConfigurationChangeListener(String parameter, PropertyChangeListener listener) {
/* 1151 */     if (this.propertyChangeSupport != null) {
/* 1152 */       this.propertyChangeSupport.removePropertyChangeListener(parameter, listener);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addStrategyListener(IStrategyListener strategyListener) {
/* 1157 */     if (strategyListener != null) {
/* 1158 */       synchronized (this.strategyListeners) {
/* 1159 */         this.strategyListeners.add(strategyListener);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeStrategyListener(IStrategyListener strategyListener) {
/* 1165 */     if (strategyListener != null) {
/* 1166 */       synchronized (this.strategyListeners) {
/* 1167 */         this.strategyListeners.remove(strategyListener);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void fireConfigurationPropertyChange(PropertyChangeEvent event) {
/* 1173 */     if (this.propertyChangeSupport != null) {
/* 1174 */       this.propertyChangeSupport.firePropertyChange(event);
/*      */     }
/*      */   }
/*      */   
/*      */   public com.dukascopy.api.IEngine getEngine()
/*      */   {
/* 1180 */     return this.forexEngineImpl;
/*      */   }
/*      */   
/*      */   public Comparator<OrderMessage> getOrderMessageComparator() {
/* 1184 */     return this.orderMessageComparator;
/*      */   }
/*      */   
/*      */   private void waitFromStart(long timeout) {
/* 1188 */     long firstTickLocal = FeedDataProvider.getDefaultInstance().getFirstTickLocalTime();
/* 1189 */     if ((firstTickLocal == Long.MIN_VALUE) || (firstTickLocal + timeout > System.currentTimeMillis())) {
/*      */       try {
/* 1191 */         if (firstTickLocal == Long.MIN_VALUE) {
/* 1192 */           Thread.sleep(timeout);
/*      */         } else {
/* 1194 */           long sleepingTime = Math.max(0L, firstTickLocal + timeout - System.currentTimeMillis());
/* 1195 */           sleepingTime = Math.min(timeout, sleepingTime);
/* 1196 */           Thread.sleep(sleepingTime);
/*      */         }
/*      */       }
/*      */       catch (InterruptedException e) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1205 */   private boolean isOnline() { return (this.transportClient != null) && (this.transportClient.isOnline()); }
/*      */   
/*      */   public static abstract class Builder<CONTEXT extends IContext, RUNNABLE extends IJFRunnable<CONTEXT>, UI extends IUserInterface, MANAGER extends JForexTaskManager<CONTEXT, RUNNABLE, UI>> { public abstract MANAGER build(JForexTaskManager.Environment paramEnvironment, boolean paramBoolean, String paramString1, IConsole paramIConsole, TransportClient paramTransportClient, DDSChartsController paramDDSChartsController, ILotAmountProvider paramILotAmountProvider, IStrategyExceptionHandler paramIStrategyExceptionHandler, AccountInfoMessage paramAccountInfoMessage, AccountInfoMessageInit paramAccountInfoMessageInit, String paramString2, String paramString3, String paramString4, Properties paramProperties, IClientGUIListener paramIClientGUIListener);
/*      */   }
/*      */   
/*      */   class StopCallable implements Callable<Void> { StopCallable() {}
/*      */     
/* 1212 */     public Void call() throws Exception { if (JForexTaskManager.this.runningJfRunnable != null) {
/* 1213 */         IJFRunnable<CONTEXT> jfRunnable = JForexTaskManager.this.runningJfRunnable.getJfRunnable();
/*      */         try {
/* 1215 */           JForexTaskManager.this.runningJfRunnable.onStop();
/*      */           
/*      */ 
/*      */ 
/* 1219 */           JForexTaskManager.this.fireOnStop(jfRunnable);
/*      */         } catch (Throwable t) {
/* 1221 */           JForexTaskManager.LOGGER.error(t.getMessage(), t);
/* 1222 */           String msg = com.dukascopy.dds2.greed.strategy.ErrorHelper.representError(jfRunnable, t);
/* 1223 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/*      */         }
/*      */       }
/* 1226 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private class OrderMessageComparator
/*      */     implements Comparator<OrderMessage>
/*      */   {
/*      */     private OrderMessageComparator() {}
/*      */     
/*      */     public int compare(OrderMessage o1, OrderMessage o2)
/*      */     {
/* 1238 */       if (o1 == null) {
/* 1239 */         if (o2 == null) {
/* 1240 */           return 0;
/*      */         }
/* 1242 */         return -1;
/*      */       }
/*      */       
/* 1245 */       if (o2 == null) {
/* 1246 */         return 1;
/*      */       }
/* 1248 */       return getWeight(o1) - getWeight(o2);
/*      */     }
/*      */     
/*      */ 
/*      */     private int getWeight(OrderMessage orderMessage)
/*      */     {
/* 1254 */       OrderState orderState = orderMessage.getState();
/* 1255 */       if (orderMessage.getDirection() == OrderDirection.OPEN) {
/* 1256 */         switch (JForexTaskManager.5.$SwitchMap$com$dukascopy$dds3$transport$msg$types$OrderState[orderState.ordinal()]) {
/*      */         case 1: 
/* 1258 */           return 1;
/*      */         case 2: 
/* 1260 */           return 2;
/*      */         case 3: 
/* 1262 */           return 3;
/*      */         }
/* 1264 */         return 0;
/*      */       }
/*      */       
/* 1267 */       return 4;
/*      */     }
/*      */   }
/*      */   
/*      */   public IFeedDataProvider getFeedDataProvider() {
/* 1272 */     return this.feedDataProvider;
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexTaskManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */