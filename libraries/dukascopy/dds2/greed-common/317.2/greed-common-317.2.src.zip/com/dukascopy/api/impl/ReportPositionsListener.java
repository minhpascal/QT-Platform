/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IReportPosition;
/*    */ import com.dukascopy.charts.data.datacache.IReportPositionsListener;
/*    */ import com.dukascopy.dds3.transport.msg.ord.data.PositionData;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportPositionsListener
/*    */   implements IReportPositionsListener
/*    */ {
/*    */   private List<IReportPosition> reportPositions;
/*    */   
/*    */   public ReportPositionsListener()
/*    */   {
/* 27 */     this.reportPositions = new ArrayList();
/*    */   }
/*    */   
/*    */ 
/*    */   public IReportPosition onPositionData(PositionData positionData)
/*    */   {
/* 33 */     IReportPosition reportPosition = null;
/* 34 */     if (positionData != null) {
/* 35 */       reportPosition = new ReportPosition(positionData);
/* 36 */       this.reportPositions.add(reportPosition);
/*    */     }
/* 38 */     return reportPosition;
/*    */   }
/*    */   
/*    */   public List<IReportPosition> getReportPositions()
/*    */   {
/* 43 */     return new ArrayList(this.reportPositions);
/*    */   }
/*    */   
/*    */ 
/*    */   public void clear()
/*    */   {
/* 49 */     this.reportPositions.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\ReportPositionsListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */