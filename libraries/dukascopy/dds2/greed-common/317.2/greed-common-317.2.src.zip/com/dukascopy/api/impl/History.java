/*      */ package com.dukascopy.api.impl;
/*      */ 
/*      */ import com.dukascopy.api.Filter;
/*      */ import com.dukascopy.api.IBar;
/*      */ import com.dukascopy.api.ICurrency;
/*      */ import com.dukascopy.api.IHistory;
/*      */ import com.dukascopy.api.IOrder;
/*      */ import com.dukascopy.api.ITick;
/*      */ import com.dukascopy.api.ITimedData;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.JFException;
/*      */ import com.dukascopy.api.LoadingDataListener;
/*      */ import com.dukascopy.api.LoadingOrdersListener;
/*      */ import com.dukascopy.api.LoadingProgressListener;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.Period;
/*      */ import com.dukascopy.api.PriceRange;
/*      */ import com.dukascopy.api.ReversalAmount;
/*      */ import com.dukascopy.api.TickBarSize;
/*      */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*      */ import com.dukascopy.api.feed.IFeedDescriptor;
/*      */ import com.dukascopy.api.feed.IFeedListener;
/*      */ import com.dukascopy.api.feed.IPointAndFigure;
/*      */ import com.dukascopy.api.feed.IPointAndFigureFeedListener;
/*      */ import com.dukascopy.api.feed.IPriceAggregationBar;
/*      */ import com.dukascopy.api.feed.IRangeBar;
/*      */ import com.dukascopy.api.feed.IRangeBarFeedListener;
/*      */ import com.dukascopy.api.feed.IRenkoBar;
/*      */ import com.dukascopy.api.feed.IRenkoBarFeedListener;
/*      */ import com.dukascopy.api.feed.ITailoredFeedDescriptor;
/*      */ import com.dukascopy.api.feed.ITailoredFeedListener;
/*      */ import com.dukascopy.api.feed.ITickBar;
/*      */ import com.dukascopy.api.feed.ITickBarFeedListener;
/*      */ import com.dukascopy.api.feed.util.PointAndFigureFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.RenkoFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TickBarFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TicksFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TimePeriodAggregationFeedDescriptor;
/*      */ import com.dukascopy.api.impl.connect.IFeedPointAndFigureListener;
/*      */ import com.dukascopy.api.impl.connect.IFeedRangeBarListener;
/*      */ import com.dukascopy.api.impl.connect.IFeedRenkoListener;
/*      */ import com.dukascopy.api.impl.connect.IFeedTickBarListener;
/*      */ import com.dukascopy.api.impl.util.HistoryUtils;
/*      */ import com.dukascopy.api.impl.util.HistoryUtils.Loadable;
/*      */ import com.dukascopy.api.util.DateUtils;
/*      */ import com.dukascopy.charts.data.datacache.CandleData;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*      */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*      */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*      */ import com.dukascopy.charts.data.datacache.OrderHistoricalData;
/*      */ import com.dukascopy.charts.data.datacache.OrdersListener;
/*      */ import com.dukascopy.charts.data.datacache.TickData;
/*      */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*      */ import com.dukascopy.charts.data.datacache.intraperiod.IIntraperiodBarsGenerator;
/*      */ import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.nisonrenko.RenkoData;
/*      */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.TimeDataUtils;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.dataprovider.IPriceAggregationDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.TickBarData;
/*      */ import com.dukascopy.charts.data.orders.IOrdersProvider;
/*      */ import com.dukascopy.charts.math.dataprovider.priceaggregation.buffer.IPriceAggregationShiftableBuffer;
/*      */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*      */ import java.math.BigDecimal;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ public class History implements IHistory
/*      */ {
/*   91 */   private static final Logger LOGGER = LoggerFactory.getLogger(History.class);
/*      */   
/*   93 */   private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss SSS");
/*      */   
/*   95 */   static { DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT")); }
/*      */   
/*      */ 
/*   98 */   protected static final BigDecimal ONE_MILLION = BigDecimal.valueOf(1000000L);
/*      */   
/*  100 */   protected AtomicBoolean ordersHistoryRequestSent = new AtomicBoolean();
/*      */   
/*      */   protected IOrdersProvider ordersProvider;
/*      */   
/*      */   protected ICurrency accountCurrency;
/*      */   
/*      */   protected IFeedDataProvider feedDataProvider;
/*      */   protected IPriceAggregationDataProvider priceAggregationDataProvider;
/*      */   protected IHistoryOrderProvider historyOrderProvider;
/*      */   
/*      */   public History(IOrdersProvider ordersProvider, ICurrency accountCurrency, IFeedDataProvider feedDataProvider)
/*      */   {
/*  112 */     this.ordersProvider = ordersProvider;
/*  113 */     this.accountCurrency = accountCurrency;
/*  114 */     this.feedDataProvider = feedDataProvider;
/*      */     
/*  116 */     if (feedDataProvider != null) {
/*  117 */       this.priceAggregationDataProvider = feedDataProvider.getPriceAggregationDataProvider();
/*      */     }
/*  119 */     this.historyOrderProvider = new HistoryOrderProvider(feedDataProvider, accountCurrency);
/*      */   }
/*      */   
/*      */   public History(IFeedDataProvider feedDataProvider) {
/*  123 */     this(null, null, feedDataProvider);
/*      */   }
/*      */   
/*      */   public long getTimeOfLastTick(Instrument instrument) throws JFException
/*      */   {
/*  128 */     if (!isInstrumentSubscribed(instrument)) {
/*  129 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*  131 */     long time = this.feedDataProvider.getLastTickTime(instrument);
/*  132 */     return time == Long.MIN_VALUE ? -1L : time;
/*      */   }
/*      */   
/*      */   public ITick getLastTick(Instrument instrument) throws JFException
/*      */   {
/*  137 */     if (!isInstrumentSubscribed(instrument)) {
/*  138 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*  140 */     TickData tick = this.feedDataProvider.getLastTick(instrument);
/*  141 */     if (tick != null) {
/*  142 */       return new TickData(tick.time, tick.ask, tick.bid, tick.askVol, tick.bidVol, tick.asks, tick.bids, tick.askVolumes, tick.bidVolumes);
/*      */     }
/*  144 */     return null;
/*      */   }
/*      */   
/*      */   public long getStartTimeOfCurrentBar(Instrument instrument, Period period)
/*      */     throws JFException
/*      */   {
/*  150 */     if (!isInstrumentSubscribed(instrument)) {
/*  151 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*  153 */     long timeOfCurrentCandle = getCurrentTime(instrument);
/*  154 */     return timeOfCurrentCandle == Long.MIN_VALUE ? -1L : DataCacheUtils.getCandleStartFast(period, timeOfCurrentCandle);
/*      */   }
/*      */   
/*      */   protected long getCurrentTime(Instrument instrument) {
/*  158 */     return this.feedDataProvider.getCurrentTime(instrument);
/*      */   }
/*      */   
/*      */   protected long getCurrentTimeBlocking(Instrument instrument) {
/*  162 */     long timeout = 120000L;
/*  163 */     long currentTime = Long.MIN_VALUE;
/*  164 */     long start = System.currentTimeMillis();
/*      */     
/*  166 */     while (start + timeout > System.currentTimeMillis()) {
/*  167 */       currentTime = getCurrentTime(instrument);
/*  168 */       if (currentTime != Long.MIN_VALUE) {
/*      */         break;
/*      */       }
/*      */       try
/*      */       {
/*  173 */         Thread.sleep(500L);
/*      */       }
/*      */       catch (InterruptedException e) {}
/*      */     }
/*      */     
/*      */ 
/*  179 */     return currentTime;
/*      */   }
/*      */   
/*      */   public IBar getBar(Instrument instrument, Period period, OfferSide side, int shift) throws JFException
/*      */   {
/*  184 */     if (!isInstrumentSubscribed(instrument)) {
/*  185 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  188 */       if (shift < 0) {
/*  189 */         throw new JFException("Parameter 'shift' is < 0");
/*      */       }
/*  191 */       if (shift == 0) {
/*  192 */         return getCurrentBar(instrument, period, side);
/*      */       }
/*      */       
/*  195 */       return getHistoryBarBlocking(instrument, period, side, shift);
/*      */     } catch (DataCacheException e) {
/*  197 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected CandleData getCurrentBar(Instrument instrument, Period period, OfferSide side) throws DataCacheException {
/*  202 */     CandleData candle = this.feedDataProvider.getInProgressCandleBlocking(instrument, period, side);
/*  203 */     if (candle == null) {
/*  204 */       return null;
/*      */     }
/*  206 */     return new CandleData(candle.time, candle.open, candle.close, candle.low, candle.high, candle.vol);
/*      */   }
/*      */   
/*      */   public IBar getHistoryBarBlocking(Instrument instrument, Period period, OfferSide side, int shift) throws JFException
/*      */   {
/*      */     try {
/*  212 */       if (shift <= 0) {
/*  213 */         throw new JFException("Parameter 'shift' must be > 0");
/*      */       }
/*      */       
/*  216 */       long timeOfCurrentCandle = getCurrentTimeBlocking(instrument);
/*  217 */       if (timeOfCurrentCandle == Long.MIN_VALUE) {
/*  218 */         return null;
/*      */       }
/*  220 */       long currentBarStartTime = DataCacheUtils.getCandleStart(period, timeOfCurrentCandle);
/*  221 */       long requestedBarStartTime = DataCacheUtils.getTimeForNCandlesBack(period, DataCacheUtils.getPreviousCandleStart(period, currentBarStartTime), shift);
/*      */       
/*      */ 
/*      */ 
/*  225 */       List<IBar> bars = getBars(instrument, period, side, requestedBarStartTime, requestedBarStartTime);
/*  226 */       if (bars.isEmpty()) {
/*  227 */         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss SSS");
/*  228 */         dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  229 */         throw new JFException("Could not load bar for instrument [" + instrument + "], period [" + period + "], side [" + side + "], start time [" + dateFormat.format(new Date(requestedBarStartTime)) + "], current bar start time [" + dateFormat.format(new Date(currentBarStartTime)) + "]");
/*      */       }
/*  231 */       return (IBar)bars.get(0);
/*      */     }
/*      */     catch (DataCacheException e) {
/*  234 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void readTicks(final Instrument instrument, final long from, long to, final LoadingDataListener tickListener, LoadingProgressListener loadingProgress) throws JFException
/*      */   {
/*  240 */     validateIntervalByPeriod(Period.TICK, from, to);
/*      */     
/*  242 */     if (isInstrumentSubscribed(instrument)) {
/*  243 */       long timeOfCurrentCandle = getCurrentTime(instrument);
/*  244 */       if ((timeOfCurrentCandle != Long.MIN_VALUE) && (to > timeOfCurrentCandle)) {
/*  245 */         throw new JFException("\"to\" parameter can't be greater than time of the last tick for this instrument");
/*      */       }
/*      */     }
/*      */     else {
/*  249 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  252 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  255 */           History.this.readTicksSecured(instrument, from, tickListener, this.val$tickListener, this.val$loadingProgress);
/*  256 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  260 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void readTicksSecured(Instrument instrument, long from, long to, LoadingDataListener tickListener, LoadingProgressListener loadingProgress) throws JFException {
/*      */     try {
/*  266 */       this.feedDataProvider.loadTicksData(instrument, from, to, new LiveFeedListenerWrapper(tickListener), new LoadingProgressListenerWrapper(loadingProgress, false));
/*      */     } catch (DataCacheException e) {
/*  268 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void readBars(final Instrument instrument, final Period period, final OfferSide side, final long from, long to, final LoadingDataListener barListener, LoadingProgressListener loadingProgress) throws JFException
/*      */   {
/*  274 */     validateIntervalByPeriod(period, from, to);
/*      */     
/*  276 */     if (isInstrumentSubscribed(instrument)) {
/*  277 */       long timeOfLastCandle = getCurrentTime(instrument);
/*  278 */       if (timeOfLastCandle != Long.MIN_VALUE) {
/*  279 */         timeOfLastCandle = DataCacheUtils.getCandleStartFast(period, timeOfLastCandle);
/*  280 */         if (to >= timeOfLastCandle) {
/*  281 */           throw new JFException("\"to\" parameter can't be greater than time of the last formed bar for this instrument");
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  286 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  289 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  292 */           History.this.readBarsSecured(instrument, period, side, from, barListener, this.val$barListener, this.val$loadingProgress);
/*  293 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  297 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void readBarsSecured(Instrument instrument, Period period, OfferSide side, long from, long to, LoadingDataListener barListener, LoadingProgressListener loadingProgress) throws JFException {
/*      */     try {
/*  303 */       this.feedDataProvider.loadCandlesData(instrument, period, side, from, to, new LiveFeedListenerWrapper(barListener), new LoadingProgressListenerWrapper(loadingProgress, false));
/*      */     } catch (Throwable e) {
/*  305 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void readBars(final Instrument instrument, final Period period, final OfferSide side, final Filter filter, final int numberOfCandlesBefore, final long time, int numberOfCandlesAfter, final LoadingDataListener barListener, final LoadingProgressListener loadingProgress) throws JFException
/*      */   {
/*  311 */     if (!isIntervalValid(period, numberOfCandlesBefore, time, numberOfCandlesAfter)) {
/*  312 */       throw new JFException("Number of bars to load = 0 or time is not correct time for the period specified");
/*      */     }
/*  314 */     if (isInstrumentSubscribed(instrument)) {
/*  315 */       long timeOfLastCandle = getCurrentTime(instrument);
/*  316 */       if (timeOfLastCandle != Long.MIN_VALUE) {
/*  317 */         timeOfLastCandle = DataCacheUtils.getCandleStartFast(period, timeOfLastCandle);
/*  318 */         if (time > timeOfLastCandle) {
/*  319 */           throw new JFException("\"to\" parameter can't be greater than time of the last formed bar for this instrument");
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  324 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  327 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  330 */           History.this.readBarsSecured(instrument, period, side, filter, numberOfCandlesBefore, time, barListener, loadingProgress, this.val$loadingProgress);
/*  331 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  335 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void readBarsSecured(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter, LoadingDataListener barListener, LoadingProgressListener loadingProgress) throws JFException {
/*      */     try {
/*  341 */       this.feedDataProvider.loadCandlesDataBeforeAfter(instrument, period, side, numberOfCandlesBefore, numberOfCandlesAfter, time, filter, new LiveFeedListenerWrapper(barListener), new LoadingProgressListenerWrapper(loadingProgress, false));
/*      */     } catch (DataCacheException e) {
/*  343 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public List<ITick> getTicks(final Instrument instrument, final long from, long to) throws JFException
/*      */   {
/*  349 */     validateIntervalByPeriod(Period.TICK, from, to);
/*      */     
/*  351 */     if (isInstrumentSubscribed(instrument)) {
/*  352 */       long timeOfCurrentCandle = getCurrentTime(instrument);
/*  353 */       if ((timeOfCurrentCandle != Long.MIN_VALUE) && 
/*  354 */         (to > timeOfCurrentCandle)) {
/*  355 */         throw new JFException("\"to\" parameter can't be greater than time of the last tick for this instrument");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  360 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  363 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<ITick> run() throws Exception {
/*  366 */           return History.this.getTicksSecured(instrument, from, this.val$to);
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  370 */       HistoryUtils.throwJFException(e); }
/*  371 */     return null;
/*      */   }
/*      */   
/*      */   protected List<ITick> getTicksSecured(Instrument instrument, long from, long to) throws JFException
/*      */   {
/*      */     try {
/*  377 */       final List<ITick> ticks = new ArrayList();
/*  378 */       final int[] result = { 0 };
/*  379 */       final Throwable[] exceptions = new Throwable[1];
/*  380 */       ILoadingProgressListener loadingProgressListener = new ILoadingProgressListener()
/*      */       {
/*      */         public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*      */         
/*      */ 
/*      */         public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */         {
/*  387 */           result[0] = (allDataLoaded ? 1 : 2);
/*  388 */           exceptions[0] = e;
/*      */         }
/*      */         
/*      */         public boolean stopJob()
/*      */         {
/*  393 */           return false;
/*      */         }
/*  395 */       };
/*  396 */       this.feedDataProvider.loadTicksDataSynched(instrument, from, to, new LiveFeedListener()
/*      */       {
/*      */ 
/*  399 */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) { ticks.add(new TickData(time, ask, bid, askVol, bidVol, null, null, null, null)); } public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {} }, loadingProgressListener);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  407 */       if (result[0] == 2) {
/*  408 */         throw new JFException("Error while loading ticks", exceptions[0]);
/*      */       }
/*  410 */       return ticks;
/*      */     }
/*      */     catch (DataCacheException e) {
/*  413 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public ITick getLastTickBefore(final Instrument instrument, final long to) throws JFException {
/*  418 */     if (isInstrumentSubscribed(instrument)) {
/*  419 */       long timeOfCurrentCandle = getCurrentTime(instrument);
/*  420 */       if ((timeOfCurrentCandle != Long.MIN_VALUE) && (to > timeOfCurrentCandle)) {
/*  421 */         throw new JFException("\"to\" parameter can't be greater than time of the last tick for this instrument");
/*      */       }
/*      */     }
/*      */     else {
/*  425 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  428 */       (ITick)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public ITick run() throws Exception {
/*  431 */           return History.this.getLastTickBeforeSecured(instrument, to);
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  435 */       HistoryUtils.throwJFException(e); }
/*  436 */     return null;
/*      */   }
/*      */   
/*      */   protected ITick getLastTickBeforeSecured(Instrument instrument, long to) throws JFException
/*      */   {
/*      */     try {
/*  442 */       long interval = 15000L;
/*  443 */       long from = to - interval;
/*  444 */       final TickData[] tick = new TickData[1];
/*  445 */       int daysAdded = 0;
/*  446 */       while ((tick[0] == null) && (daysAdded < 5)) {
/*  447 */         final int[] result = { 0 };
/*  448 */         final Throwable[] exceptions = new Throwable[1];
/*  449 */         ILoadingProgressListener loadingProgressListener = new ILoadingProgressListener()
/*      */         {
/*      */           public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*      */           
/*      */ 
/*      */           public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */           {
/*  456 */             result[0] = (allDataLoaded ? 1 : 2);
/*  457 */             exceptions[0] = e;
/*      */           }
/*      */           
/*      */           public boolean stopJob()
/*      */           {
/*  462 */             return false;
/*      */           }
/*  464 */         };
/*  465 */         this.feedDataProvider.loadTicksDataSynched(instrument, from, to, new LiveFeedListener()
/*      */         {
/*      */           public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {
/*  468 */             if (tick[0] == null) {
/*  469 */               tick[0] = new TickData(time, ask, bid, askVol, bidVol, null, null, null, null);
/*      */             } else {
/*  471 */               tick[0].time = time;
/*  472 */               tick[0].ask = ask;
/*  473 */               tick[0].bid = bid;
/*  474 */               tick[0].askVol = askVol;
/*  475 */               tick[0].bidVol = bidVol; } } public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {} }, loadingProgressListener);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  484 */         if (result[0] == 2) {
/*  485 */           throw new JFException("Error while loading ticks", exceptions[0]);
/*      */         }
/*  487 */         if (from < this.feedDataProvider.getTimeOfFirstCandle(instrument, Period.TICK)) {
/*  488 */           return null;
/*      */         }
/*  490 */         if (interval * 2L > 86400000L) {
/*  491 */           interval += 86400000L;
/*  492 */           daysAdded++;
/*      */         } else {
/*  494 */           interval *= 2L;
/*      */         }
/*  496 */         from = to - interval;
/*      */       }
/*  498 */       return tick[0];
/*      */     } catch (DataCacheException e) {
/*  500 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public List<IBar> getBars(final Instrument instrument, final Period period, final OfferSide side, final long from, long to) throws JFException
/*      */   {
/*  506 */     validateIntervalByPeriod(period, from, to);
/*      */     
/*  508 */     if (isInstrumentSubscribed(instrument)) {
/*  509 */       long timeOfLastCandle = getCurrentTime(instrument);
/*  510 */       if (timeOfLastCandle != Long.MIN_VALUE) {
/*  511 */         timeOfLastCandle = DataCacheUtils.getCandleStartFast(period, timeOfLastCandle);
/*  512 */         if (to > timeOfLastCandle) {
/*  513 */           throw new JFException("\"to\" parameter can't be greater than the time of the last formed bar for this instrument");
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  518 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  521 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IBar> run() throws Exception {
/*  524 */           return History.this.getBarsSecured(instrument, period, side, Filter.NO_FILTER, from, this.val$to);
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  528 */       HistoryUtils.throwJFException(e); }
/*  529 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IBar> getBarsSecured(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to)
/*      */     throws JFException
/*      */   {
/*      */     try
/*      */     {
/*  542 */       final List<IBar> bars = new ArrayList();
/*  543 */       final int[] result = { 0 };
/*  544 */       final Throwable[] exceptions = new Throwable[1];
/*  545 */       CandleData currentBar = getCurrentBar(instrument, period, side);
/*  546 */       ILoadingProgressListener loadingProgressListener = new ILoadingProgressListener()
/*      */       {
/*      */         public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*      */         
/*      */ 
/*      */         public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */         {
/*  553 */           result[0] = (allDataLoaded ? 1 : 2);
/*  554 */           exceptions[0] = e;
/*      */         }
/*      */         
/*      */         public boolean stopJob()
/*      */         {
/*  559 */           return false;
/*      */         }
/*  561 */       };
/*  562 */       this.feedDataProvider.loadCandlesFromToSynched(instrument, period, side, filter, from, to, new LiveFeedListener()
/*      */       {
/*      */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  569 */         public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) { bars.add(new CandleData(time, open, close, low, high, vol)); } }, loadingProgressListener);
/*      */       
/*      */ 
/*      */ 
/*  573 */       if (result[0] == 2) {
/*  574 */         throw new JFException("Error while loading bars", exceptions[0]);
/*      */       }
/*  576 */       if (currentBar != null)
/*      */       {
/*  578 */         if ((to == currentBar.getTime()) && ((bars.isEmpty()) || (((IBar)bars.get(bars.size() - 1)).getTime() <= currentBar.getTime()))) {
/*  579 */           if ((bars.size() > 0) && (((IBar)bars.get(bars.size() - 1)).getTime() == currentBar.getTime()))
/*      */           {
/*  581 */             bars.remove(bars.size() - 1);
/*      */           }
/*      */           
/*  584 */           if (this.feedDataProvider.getFilterManager().matchedFilter(period, filter, currentBar)) {
/*  585 */             bars.add(currentBar);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  590 */       return bars;
/*      */     }
/*      */     catch (DataCacheException e) {
/*  593 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected int getNumOfCandlesForwardForTimeCalculations(int before, int after)
/*      */   {
/*  599 */     if ((before > 0) && (after > 0)) {
/*  600 */       return after + 1;
/*      */     }
/*  602 */     if ((before == 0) && (after > 0)) {
/*  603 */       return after;
/*      */     }
/*  605 */     if ((before > 0) && (after == 0)) {
/*  606 */       return 1;
/*      */     }
/*      */     
/*  609 */     return 0;
/*      */   }
/*      */   
/*      */   public List<IBar> getBars(final Instrument instrument, final Period period, final OfferSide side, final Filter filter, final int numberOfCandlesBefore, final long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/*  614 */     if (!isIntervalValid(period, numberOfCandlesBefore, time, numberOfCandlesAfter)) {
/*  615 */       throw new JFException("Number of bars to load = 0 or time is not correct time for the period specified");
/*      */     }
/*  617 */     if (isInstrumentSubscribed(instrument)) {
/*  618 */       long timeOfLastCandle = getCurrentTime(instrument);
/*  619 */       if (timeOfLastCandle != Long.MIN_VALUE) {
/*  620 */         timeOfLastCandle = DataCacheUtils.getCandleStartFast(period, timeOfLastCandle);
/*      */         
/*  622 */         long to = DataCacheUtils.getTimeForNCandlesForwardFast(period, time, getNumOfCandlesForwardForTimeCalculations(numberOfCandlesBefore, numberOfCandlesAfter));
/*  623 */         if ((time > timeOfLastCandle) || (to > timeOfLastCandle)) {
/*  624 */           throw new JFException("\"to\" parameter can't be greater than time of the last formed bar for this instrument. Requested time [" + DateUtils.format(time) + "/" + time + "], last formed bar time [" + DateUtils.format(timeOfLastCandle) + "/" + timeOfLastCandle + "], \"to\" parameter [" + DateUtils.format(to) + "/" + to + "].");
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  631 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/*  634 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IBar> run() throws Exception {
/*  637 */           return History.this.getBarsSecured(instrument, period, side, filter, numberOfCandlesBefore, time, this.val$numberOfCandlesAfter);
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  641 */       Exception ex = e.getException();
/*  642 */       if ((ex instanceof JFException))
/*  643 */         throw ((JFException)ex);
/*  644 */       if ((ex instanceof RuntimeException)) {
/*  645 */         throw ((RuntimeException)ex);
/*      */       }
/*  647 */       LOGGER.error(ex.getMessage(), ex);
/*  648 */       throw new JFException(ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IBar> getBarsSecured(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter)
/*      */     throws JFException
/*      */   {
/*      */     try
/*      */     {
/*  664 */       IBar currentBar = getCurrentBar(instrument, period, side);
/*  665 */       final List<IBar> bars = new ArrayList();
/*  666 */       final int[] result = { 0 };
/*  667 */       final Throwable[] exceptions = new Throwable[1];
/*  668 */       ILoadingProgressListener loadingProgressListener = new ILoadingProgressListener()
/*      */       {
/*      */         public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*      */         
/*      */ 
/*      */         public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */         {
/*  675 */           result[0] = (allDataLoaded ? 1 : 2);
/*  676 */           exceptions[0] = e;
/*      */         }
/*      */         
/*      */         public boolean stopJob()
/*      */         {
/*  681 */           return false;
/*      */         }
/*  683 */       };
/*  684 */       this.feedDataProvider.loadCandlesDataBeforeAfterSynched(instrument, period, side, numberOfCandlesBefore, numberOfCandlesAfter, time, filter, new LiveFeedListener()
/*      */       {
/*      */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  691 */         public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) { bars.add(new CandleData(time, open, close, low, high, vol)); } }, loadingProgressListener);
/*      */       
/*      */ 
/*      */ 
/*  695 */       if ((currentBar != null) && (!bars.isEmpty())) { ListIterator<IBar> iterator;
/*  696 */         if (((IBar)bars.get(bars.size() - 1)).getTime() > currentBar.getTime()) {
/*  697 */           for (iterator = bars.listIterator(bars.size()); iterator.hasPrevious();) {
/*  698 */             IBar bar = (IBar)iterator.previous();
/*  699 */             if (bar.getTime() <= currentBar.getTime()) break;
/*  700 */             iterator.remove();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  706 */         if (((IBar)bars.get(bars.size() - 1)).getTime() == currentBar.getTime())
/*      */         {
/*  708 */           bars.remove(bars.size() - 1);
/*  709 */           bars.add(currentBar);
/*      */         }
/*      */       }
/*  712 */       if (bars.size() < numberOfCandlesBefore + numberOfCandlesAfter) {
/*  713 */         if (currentBar != null)
/*      */         {
/*  715 */           if ((time == currentBar.getTime()) && (numberOfCandlesBefore != 0) && ((bars.isEmpty()) || (((IBar)bars.get(bars.size() - 1)).getTime() < currentBar.getTime()))) {
/*  716 */             bars.add(currentBar);
/*  717 */           } else if ((time == currentBar.getTime()) && (numberOfCandlesBefore == 0) && (numberOfCandlesAfter > 0) && (bars.isEmpty())) {
/*  718 */             bars.add(currentBar);
/*  719 */           } else if ((time < currentBar.getTime()) && (numberOfCandlesAfter > 0) && ((bars.isEmpty()) || (((IBar)bars.get(bars.size() - 1)).getTime() < currentBar.getTime())))
/*      */           {
/*  721 */             if (((IBar)bars.get(0)).getTime() != this.feedDataProvider.getTimeOfFirstCandle(instrument, period)) {
/*  722 */               bars.add(currentBar);
/*      */             }
/*      */           }
/*      */         }
/*  726 */       } else if ((currentBar != null) && (time == currentBar.getTime())) {
/*  727 */         IBar lastBar = (IBar)bars.get(bars.size() - 1);
/*  728 */         if (lastBar.getTime() != currentBar.getTime())
/*      */         {
/*  730 */           boolean currentBarMatchedFilter = this.feedDataProvider.getFilterManager().matchedFilter(period, filter, currentBar.getTime(), currentBar.getOpen(), currentBar.getClose(), currentBar.getLow(), currentBar.getHigh(), currentBar.getVolume());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  741 */           if (currentBarMatchedFilter)
/*      */           {
/*  743 */             bars.remove(0);
/*  744 */             bars.add(currentBar);
/*      */           }
/*      */         }
/*      */       }
/*  748 */       if (result[0] == 2) {
/*  749 */         throw new JFException("Error while loading bars", exceptions[0]);
/*      */       }
/*  751 */       return bars;
/*      */     }
/*      */     catch (DataCacheException e) {
/*  754 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void readOrdersHistory(final Instrument instrument, final long from, long to, final LoadingOrdersListener ordersListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/*  761 */     if (from > to) {
/*  762 */       throw new JFException("Interval from [" + DATE_FORMAT.format(new Date(from)) + "] to [" + DATE_FORMAT.format(new Date(to)) + "] GMT is not valid");
/*      */     }
/*  764 */     if (this.ordersHistoryRequestSent.compareAndSet(false, true)) {
/*      */       try {
/*      */         try {
/*  767 */           AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */           {
/*      */             public Object run() throws Exception {
/*  770 */               History.this.historyOrderProvider.readOrdersHistory(instrument, from, ordersListener, new History.LoadingOrdersListenerWrapper(History.this, this.val$ordersListener, from, ordersListener), new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, true));
/*  771 */               return null;
/*      */             }
/*      */           });
/*      */         } catch (PrivilegedActionException e) {
/*  775 */           Exception ex = e.getException();
/*  776 */           if ((ex instanceof JFException))
/*  777 */             throw ((JFException)ex);
/*  778 */           if ((ex instanceof RuntimeException)) {
/*  779 */             throw ((RuntimeException)ex);
/*      */           }
/*  781 */           LOGGER.error(ex.getMessage(), ex);
/*  782 */           throw new JFException(ex);
/*      */         }
/*      */       }
/*      */       finally {
/*  786 */         this.ordersHistoryRequestSent.set(false);
/*      */       }
/*      */     } else {
/*  789 */       throw new JFException("Only one request for orders history can be sent at one time");
/*      */     }
/*      */   }
/*      */   
/*      */   public List<IOrder> getOrdersHistory(final Instrument instrument, final long from, long to) throws JFException
/*      */   {
/*  795 */     if (from > to) {
/*  796 */       throw new JFException("Interval from [" + DATE_FORMAT.format(new Date(from)) + "] to [" + DATE_FORMAT.format(new Date(to)) + "] GMT is not valid");
/*      */     }
/*  798 */     if (this.ordersHistoryRequestSent.compareAndSet(false, true)) {
/*      */       try
/*      */       {
/*  801 */         (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */         {
/*      */           public List<IOrder> run() throws Exception {
/*  804 */             return History.this.historyOrderProvider.getOrdersHistory(instrument, from, this.val$to);
/*      */           }
/*      */         });
/*      */       } catch (PrivilegedActionException e) {
/*  808 */         Exception ex = e.getException();
/*  809 */         if ((ex instanceof JFException))
/*  810 */           throw ((JFException)ex);
/*  811 */         if ((ex instanceof RuntimeException)) {
/*  812 */           throw ((RuntimeException)ex);
/*      */         }
/*  814 */         LOGGER.error(ex.getMessage(), ex);
/*  815 */         throw new JFException(ex);
/*      */       }
/*      */       finally
/*      */       {
/*  819 */         this.ordersHistoryRequestSent.set(false);
/*      */       }
/*      */     }
/*  822 */     throw new JFException("Only one request for orders history can be sent at one time");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IOrder getHistoricalOrderById(final String id)
/*      */     throws JFException
/*      */   {
/*  832 */     if (ObjectUtils.isNullOrEmpty(id)) {
/*  833 */       throw new JFException("Order ID is not specified");
/*      */     }
/*  835 */     if (this.ordersHistoryRequestSent.compareAndSet(false, true)) {
/*      */       try
/*      */       {
/*  838 */         (IOrder)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */         {
/*      */           public IOrder run() throws Exception {
/*  841 */             return History.this.historyOrderProvider.getOrderHistoryById(id);
/*      */           }
/*      */         });
/*      */       } catch (PrivilegedActionException e) {
/*  845 */         Exception ex = e.getException();
/*  846 */         if ((ex instanceof JFException))
/*  847 */           throw ((JFException)ex);
/*  848 */         if ((ex instanceof RuntimeException)) {
/*  849 */           throw ((RuntimeException)ex);
/*      */         }
/*  851 */         LOGGER.error(ex.getMessage(), ex);
/*  852 */         throw new JFException(ex);
/*      */       }
/*      */       finally
/*      */       {
/*  856 */         this.ordersHistoryRequestSent.set(false);
/*      */       }
/*      */     }
/*  859 */     throw new JFException("Only one request for orders history can be sent at one time");
/*      */   }
/*      */   
/*      */ 
/*      */   public void validateIntervalByPeriod(Period period, long from, long to)
/*      */     throws JFException
/*      */   {
/*  866 */     if (!isIntervalValid(period, from, to)) {
/*  867 */       throw new JFException("Interval from [" + DATE_FORMAT.format(new Date(from)) + "] to [" + DATE_FORMAT.format(new Date(to)) + "] GMT is not valid for period [" + period + "]");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isIntervalValid(Period period, long from, long to) {
/*  872 */     boolean ret = from <= to;
/*  873 */     if ((ret) && (!period.isTickBasedPeriod())) {
/*      */       try {
/*  875 */         ret = (ret) && (DataCacheUtils.isIntervalValid(period, from, to));
/*      */       } catch (Throwable e) {
/*  877 */         LOGGER.debug(e.getMessage(), e);
/*  878 */         ret = false;
/*      */       }
/*      */     }
/*  881 */     return ret;
/*      */   }
/*      */   
/*      */   protected boolean isIntervalValid(Period period, int before, long time, int after) {
/*  885 */     return (!period.isTickBasedPeriod()) && (DataCacheUtils.getCandleStartFast(period, time) == time) && ((before > 0) || (after > 0));
/*      */   }
/*      */   
/*      */   public long getBarStart(Period period, long time) throws JFException
/*      */   {
/*      */     try {
/*  891 */       return DataCacheUtils.getCandleStart(period, time);
/*      */     } catch (DataCacheException e) {
/*  893 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public long getNextBarStart(Period period, long barTime) throws JFException
/*      */   {
/*      */     try {
/*  900 */       return DataCacheUtils.getNextCandleStart(period, barTime);
/*      */     } catch (DataCacheException e) {
/*  902 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public long getPreviousBarStart(Period period, long barTime) throws JFException
/*      */   {
/*      */     try {
/*  909 */       return DataCacheUtils.getPreviousCandleStart(period, barTime);
/*      */     } catch (DataCacheException e) {
/*  911 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public long getTimeForNBarsBack(Period period, long to, int numberOfBars) throws JFException
/*      */   {
/*      */     try {
/*  918 */       return DataCacheUtils.getTimeForNCandlesBack(period, to, numberOfBars);
/*      */     } catch (DataCacheException e) {
/*  920 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public long getTimeForNBarsForward(Period period, long from, int numberOfBars) throws JFException
/*      */   {
/*      */     try {
/*  927 */       return DataCacheUtils.getTimeForNCandlesForward(period, from, numberOfBars);
/*      */     } catch (DataCacheException e) {
/*  929 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isInstrumentSubscribed(Instrument instrument) {
/*  934 */     return this.feedDataProvider.isSubscribedToInstrument(instrument);
/*      */   }
/*      */   
/*      */   public double getEquity()
/*      */   {
/*  939 */     return this.ordersProvider.recalculateEquity();
/*      */   }
/*      */   
/*      */   private static class LiveFeedListenerWrapper implements LiveFeedListener
/*      */   {
/*      */     private LoadingDataListener loadingDataListener;
/*      */     
/*      */     public LiveFeedListenerWrapper(LoadingDataListener loadingDataListener) {
/*  947 */       this.loadingDataListener = loadingDataListener;
/*      */     }
/*      */     
/*      */     public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol)
/*      */     {
/*  952 */       this.loadingDataListener.newBar(instrument, period, side, time, open, close, low, high, vol);
/*      */     }
/*      */     
/*      */     public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol)
/*      */     {
/*  957 */       this.loadingDataListener.newTick(instrument, time, ask, bid, askVol, bidVol);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected IPointAndFigure getPointAndFigure(final PointAndFigureFeedDescriptor feedDescriptor, final int shift)
/*      */     throws JFException
/*      */   {
/*  966 */     HistoryUtils.validatePointAndFigureParams(feedDescriptor);
/*  967 */     HistoryUtils.validateShift(shift);
/*      */     try
/*      */     {
/*  970 */       (IPointAndFigure)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public IPointAndFigure run() throws Exception {
/*  973 */           IPointAndFigure inProgressBar = History.this.feedDataProvider.getIntraperiodBarsGenerator().getOrLoadInProgressPointAndFigure(feedDescriptor, feedDescriptor.getDataInterpolationDescriptor());
/*  974 */           if (inProgressBar == null) {
/*  975 */             return null;
/*      */           }
/*  977 */           if (shift == 0) {
/*  978 */             return inProgressBar;
/*      */           }
/*      */           
/*  981 */           HistoryUtils.Loadable<PointAndFigureData> loadable = new HistoryUtils.Loadable()
/*      */           {
/*      */             public List<PointAndFigureData> load(long from, long to) throws Exception {
/*  984 */               List<PointAndFigureData> result = History.this.priceAggregationDataProvider.loadPointAndFigureTimeInterval(History.19.this.val$feedDescriptor, false, from, to, true);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  991 */               return result;
/*      */             }
/*      */             
/*      */             public long correctTime(long time)
/*      */             {
/*  996 */               return time;
/*      */             }
/*      */             
/*      */             public long getStep() {
/* 1000 */               return 86400000L;
/*      */             }
/*      */             
/*      */             public long getFirstDataTime() {
/* 1004 */               return History.this.feedDataProvider.getTimeOfFirstBar(History.19.this.val$feedDescriptor.getInstrument(), History.19.this.val$feedDescriptor.getPriceRange(), History.19.this.val$feedDescriptor.getReversalAmount(), History.19.this.val$feedDescriptor.getDataInterpolationDescriptor());
/*      */             }
/* 1006 */           };
/* 1007 */           return (IPointAndFigure)HistoryUtils.getByShift(loadable, inProgressBar.getTime(), shift);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/* 1012 */       HistoryUtils.throwJFException(e); }
/* 1013 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IPointAndFigure> getPointAndFigures(final PointAndFigureFeedDescriptor feedDescriptor, final long from, long to)
/*      */     throws JFException
/*      */   {
/* 1023 */     HistoryUtils.validatePointAndFigureParams(feedDescriptor);
/* 1024 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getDataInterpolationDescriptor().getInterpolateFromPeriod(feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount()), from, to);
/*      */     try
/*      */     {
/* 1027 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IPointAndFigure> run() throws Exception {
/* 1030 */           IPointAndFigure inProgressBar = History.this.getPointAndFigure(feedDescriptor, 0);
/*      */           
/* 1032 */           long loadFrom = from;
/* 1033 */           long loadTo = this.val$to;
/*      */           
/* 1035 */           boolean addInProgressBar = false;
/*      */           
/* 1037 */           Long correctedToTime = History.this.checkAndGetTimeBeforeInProgressBar(inProgressBar, loadTo, null);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1043 */           if (correctedToTime != null) {
/* 1044 */             loadTo = correctedToTime.longValue();
/* 1045 */             addInProgressBar = true;
/*      */           }
/*      */           
/* 1048 */           if (loadFrom > loadTo) {
/* 1049 */             loadFrom = loadTo;
/*      */           }
/*      */           
/* 1052 */           List<PointAndFigureData> data = History.this.priceAggregationDataProvider.loadPointAndFigureTimeInterval(feedDescriptor, false, loadFrom, loadTo, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1059 */           List<IPointAndFigure> result = HistoryUtils.convert(data);
/*      */           
/* 1061 */           if (addInProgressBar) {
/* 1062 */             result.add(inProgressBar);
/*      */           }
/*      */           
/* 1065 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1069 */       HistoryUtils.throwJFException(e); }
/* 1070 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IPointAndFigure> getPointAndFigures(final PointAndFigureFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 1081 */     HistoryUtils.validatePointAndFigureParams(feedDescriptor);
/* 1082 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 1085 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IPointAndFigure> run() throws Exception {
/* 1088 */           List<PointAndFigureData> data = History.this.priceAggregationDataProvider.loadPointAndFigureData(feedDescriptor, numberOfBarsBefore, time, this.val$numberOfBarsAfter, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1096 */           List<IPointAndFigure> result = HistoryUtils.convert(data);
/*      */           
/*      */ 
/* 1099 */           IPointAndFigure inProgressBar = History.this.getPointAndFigure(feedDescriptor, 0);
/* 1100 */           if ((result != null) && (result.isEmpty())) {
/* 1101 */             IPointAndFigure lastBar = (IPointAndFigure)result.get(result.size() - 1);
/* 1102 */             if ((lastBar instanceof PointAndFigureData)) {
/* 1103 */               PointAndFigureData pnfData = (PointAndFigureData)lastBar;
/* 1104 */               if (pnfData.getElementTimeFinishedCurrentBar() == inProgressBar.getTime()) {
/* 1105 */                 result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, 0L);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 1110 */             Period suitablePeriod = TimeDataUtils.getSuitablePeriod(feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount());
/* 1111 */             long maxIntervalBetweenTwoBars = suitablePeriod.isTickBasedPeriod() ? TimeUnit.HOURS.toMillis(1L) : suitablePeriod.getInterval() * 2L;
/* 1112 */             result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, maxIntervalBetweenTwoBars);
/*      */           }
/*      */           
/* 1115 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1119 */       HistoryUtils.throwJFException(e); }
/* 1120 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IPointAndFigure getPointAndFigure(Instrument instrument, OfferSide offerSide, PriceRange boxSize, ReversalAmount reversalAmount, int shift)
/*      */     throws JFException
/*      */   {
/* 1132 */     return getPointAndFigure(new PointAndFigureFeedDescriptor(instrument, boxSize, reversalAmount, offerSide), shift);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IPointAndFigure> getPointAndFigures(Instrument instrument, OfferSide offerSide, PriceRange priceRange, ReversalAmount reversalAmount, long from, long to)
/*      */     throws JFException
/*      */   {
/* 1151 */     return getPointAndFigures(new PointAndFigureFeedDescriptor(instrument, priceRange, reversalAmount, offerSide), from, to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ITickBar getTickBar(final TickBarFeedDescriptor feedDescriptor, final int shift)
/*      */     throws JFException
/*      */   {
/* 1166 */     HistoryUtils.validateTickBarParams(feedDescriptor);
/* 1167 */     HistoryUtils.validateShift(shift);
/*      */     try
/*      */     {
/* 1170 */       (ITickBar)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public ITickBar run() throws Exception {
/* 1173 */           ITickBar inProgressBar = History.this.feedDataProvider.getIntraperiodBarsGenerator().getOrLoadInProgressTickBar(feedDescriptor);
/* 1174 */           if (inProgressBar == null) {
/* 1175 */             return null;
/*      */           }
/* 1177 */           if (shift == 0) {
/* 1178 */             if (inProgressBar.getFormedElementsCount() >= feedDescriptor.getTickBarSize().getSize())
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 1183 */               return null;
/*      */             }
/*      */             
/* 1186 */             return inProgressBar;
/*      */           }
/*      */           
/*      */ 
/* 1190 */           HistoryUtils.Loadable<TickBarData> loadable = new HistoryUtils.Loadable()
/*      */           {
/*      */             public List<TickBarData> load(long from, long to) throws Exception {
/* 1193 */               List<TickBarData> result = History.this.priceAggregationDataProvider.loadTickBarTimeInterval(History.22.this.val$feedDescriptor, from, to, true);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1199 */               return result;
/*      */             }
/*      */             
/*      */             public long correctTime(long time) {
/* 1203 */               return time;
/*      */             }
/*      */             
/*      */             public long getStep() {
/* 1207 */               return History.22.this.val$feedDescriptor.getTickBarSize().getSize() * 60 * 60 * 1000;
/*      */             }
/*      */             
/*      */             public long getFirstDataTime() {
/* 1211 */               return History.this.feedDataProvider.getTimeOfFirstBar(History.22.this.val$feedDescriptor.getInstrument(), History.22.this.val$feedDescriptor.getTickBarSize());
/*      */             }
/* 1213 */           };
/* 1214 */           long time = inProgressBar.getTime();
/* 1215 */           if (inProgressBar.getFormedElementsCount() >= feedDescriptor.getTickBarSize().getSize()) {
/* 1216 */             time = DataCacheUtils.getNextPriceAggregationBarStart(inProgressBar.getEndTime());
/*      */           }
/* 1218 */           return (ITickBar)HistoryUtils.getByShift(loadable, time, shift);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/* 1223 */       HistoryUtils.throwJFException(e); }
/* 1224 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<ITickBar> getTickBars(final TickBarFeedDescriptor feedDescriptor, final long from, long to)
/*      */     throws JFException
/*      */   {
/* 1233 */     HistoryUtils.validateTickBarParams(feedDescriptor);
/* 1234 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getDataInterpolationDescriptor().getInterpolateFromPeriod(null, null), from, to);
/*      */     try
/*      */     {
/* 1237 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<ITickBar> run() throws Exception {
/* 1240 */           List<TickBarData> data = History.this.priceAggregationDataProvider.loadTickBarTimeInterval(feedDescriptor, from, this.val$to, true);
/* 1241 */           List<ITickBar> result = HistoryUtils.convert(data);
/* 1242 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1246 */       HistoryUtils.throwJFException(e); }
/* 1247 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<ITickBar> getTickBars(final TickBarFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 1258 */     HistoryUtils.validateTickBarParams(feedDescriptor);
/* 1259 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 1262 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<ITickBar> run() throws Exception {
/* 1265 */           List<TickBarData> data = History.this.priceAggregationDataProvider.loadTickBarData(feedDescriptor, numberOfBarsBefore, time, this.val$numberOfBarsAfter, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1273 */           List<ITickBar> result = HistoryUtils.convert(data);
/*      */           
/*      */ 
/* 1276 */           ITickBar inProgressBar = History.this.getTickBar(feedDescriptor, 0);
/* 1277 */           if ((result != null) && (result.isEmpty()) && (inProgressBar != null)) {
/* 1278 */             ITickBar lastBar = (ITickBar)result.get(result.size() - 1);
/* 1279 */             if ((lastBar instanceof TickBarData)) {
/* 1280 */               TickBarData tbData = (TickBarData)lastBar;
/* 1281 */               if (tbData.getElementTimeFinishedCurrentBar() == inProgressBar.getTime()) {
/* 1282 */                 result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, 0L);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 1287 */             Period suitablePeriod = TimeDataUtils.getSuitablePeriod(1);
/* 1288 */             long maxIntervalBetweenTwoBars = suitablePeriod.isTickBasedPeriod() ? TimeUnit.HOURS.toMillis(1L) : suitablePeriod.getInterval() * 2L;
/* 1289 */             result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, maxIntervalBetweenTwoBars);
/*      */           }
/*      */           
/* 1292 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1296 */       HistoryUtils.throwJFException(e); }
/* 1297 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ITickBar getTickBar(Instrument instrument, OfferSide offerSide, TickBarSize tickBarSize, int shift)
/*      */     throws JFException
/*      */   {
/* 1308 */     return getTickBar(new TickBarFeedDescriptor(instrument, tickBarSize, offerSide), shift);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ITickBar> getTickBars(Instrument instrument, OfferSide offerSide, TickBarSize tickBarSize, long from, long to)
/*      */     throws JFException
/*      */   {
/* 1325 */     return getTickBars(new TickBarFeedDescriptor(instrument, tickBarSize, offerSide), from, to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IRangeBar getRangeBar(final RangeBarFeedDescriptor feedDescriptor, final int shift)
/*      */     throws JFException
/*      */   {
/* 1338 */     HistoryUtils.validateRangeBarParams(feedDescriptor);
/* 1339 */     HistoryUtils.validateShift(shift);
/*      */     try
/*      */     {
/* 1342 */       (IRangeBar)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public IRangeBar run() throws Exception {
/* 1345 */           IRangeBar inProgressBar = History.this.feedDataProvider.getIntraperiodBarsGenerator().getOrLoadInProgressPriceRange(feedDescriptor, feedDescriptor.getDataInterpolationDescriptor());
/* 1346 */           if (inProgressBar == null) {
/* 1347 */             return null;
/*      */           }
/* 1349 */           if (shift == 0) {
/* 1350 */             return inProgressBar;
/*      */           }
/*      */           
/* 1353 */           HistoryUtils.Loadable<PriceRangeData> loadable = new HistoryUtils.Loadable()
/*      */           {
/*      */             public List<PriceRangeData> load(long from, long to) throws Exception {
/* 1356 */               List<PriceRangeData> result = History.this.priceAggregationDataProvider.loadPriceRangeTimeInterval(History.25.this.val$feedDescriptor, false, from, to, true);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1363 */               return result;
/*      */             }
/*      */             
/*      */             public long correctTime(long time)
/*      */             {
/* 1368 */               return time;
/*      */             }
/*      */             
/*      */             public long getStep() {
/* 1372 */               return 86400000L;
/*      */             }
/*      */             
/*      */             public long getFirstDataTime() {
/* 1376 */               return History.this.feedDataProvider.getTimeOfFirstBar(History.25.this.val$feedDescriptor.getInstrument(), History.25.this.val$feedDescriptor.getPriceRange(), History.25.this.val$feedDescriptor.getDataInterpolationDescriptor());
/*      */             }
/* 1378 */           };
/* 1379 */           return (IRangeBar)HistoryUtils.getByShift(loadable, inProgressBar.getTime(), shift);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/* 1384 */       HistoryUtils.throwJFException(e); }
/* 1385 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IRangeBar> getRangeBars(final RangeBarFeedDescriptor feedDescriptor, final long from, long to)
/*      */     throws JFException
/*      */   {
/* 1395 */     HistoryUtils.validateRangeBarParams(feedDescriptor);
/* 1396 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getDataInterpolationDescriptor().getInterpolateFromPeriod(feedDescriptor.getPriceRange(), null), from, to);
/*      */     try
/*      */     {
/* 1399 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IRangeBar> run() throws Exception {
/* 1402 */           IRangeBar inProgressBar = History.this.getRangeBar(feedDescriptor, 0);
/*      */           
/* 1404 */           long loadFrom = from;
/* 1405 */           long loadTo = this.val$to;
/*      */           
/* 1407 */           Long correctedToTime = History.this.checkAndGetTimeBeforeInProgressBar(inProgressBar, loadTo, null);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1413 */           boolean addInProgressBar = false;
/* 1414 */           if (correctedToTime != null) {
/* 1415 */             loadTo = correctedToTime.longValue();
/* 1416 */             addInProgressBar = true;
/*      */           }
/* 1418 */           if (loadFrom > loadTo) {
/* 1419 */             loadFrom = loadTo;
/*      */           }
/*      */           
/* 1422 */           List<PriceRangeData> data = History.this.priceAggregationDataProvider.loadPriceRangeTimeInterval(feedDescriptor, false, loadFrom, loadTo, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1429 */           List<IRangeBar> result = HistoryUtils.convert(data);
/*      */           
/* 1431 */           if (addInProgressBar) {
/* 1432 */             result.add(inProgressBar);
/*      */           }
/*      */           
/* 1435 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1439 */       HistoryUtils.throwJFException(e); }
/* 1440 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IRangeBar> getRangeBars(final RangeBarFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 1450 */     HistoryUtils.validateRangeBarParams(feedDescriptor);
/* 1451 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 1454 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IRangeBar> run() throws Exception {
/* 1457 */           List<PriceRangeData> data = History.this.priceAggregationDataProvider.loadPriceRangeData(feedDescriptor, numberOfBarsBefore, time, this.val$numberOfBarsAfter, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1465 */           List<IRangeBar> result = HistoryUtils.convert(data);
/*      */           
/*      */ 
/* 1468 */           IRangeBar inProgressBar = History.this.getRangeBar(feedDescriptor, 0);
/* 1469 */           if ((result != null) && (result.isEmpty())) {
/* 1470 */             IRangeBar lastBar = (IRangeBar)result.get(result.size() - 1);
/* 1471 */             if ((lastBar instanceof PriceRangeData)) {
/* 1472 */               PriceRangeData rangeData = (PriceRangeData)lastBar;
/* 1473 */               if (rangeData.getElementTimeFinishedCurrentBar() == inProgressBar.getTime()) {
/* 1474 */                 result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, 0L);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 1479 */             Period suitablePeriod = TimeDataUtils.getSuitablePeriod(feedDescriptor.getPriceRange());
/* 1480 */             long maxIntervalBetweenTwoBars = suitablePeriod.isTickBasedPeriod() ? TimeUnit.HOURS.toMillis(1L) : suitablePeriod.getInterval() * 2L;
/* 1481 */             result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, maxIntervalBetweenTwoBars);
/*      */           }
/*      */           
/* 1484 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1488 */       HistoryUtils.throwJFException(e); }
/* 1489 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IRangeBar getRangeBar(Instrument instrument, OfferSide offerSide, PriceRange priceRange, int shift)
/*      */     throws JFException
/*      */   {
/* 1500 */     return getRangeBar(new RangeBarFeedDescriptor(instrument, priceRange, offerSide), shift);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IRangeBar> getRangeBars(Instrument instrument, OfferSide offerSide, PriceRange priceRange, long from, long to)
/*      */     throws JFException
/*      */   {
/* 1517 */     return getRangeBars(new RangeBarFeedDescriptor(instrument, priceRange, offerSide), from, to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IPointAndFigure> getPointAndFigures(Instrument instrument, OfferSide offerSide, PriceRange priceRange, ReversalAmount reversalAmount, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 1536 */     return getPointAndFigures(new PointAndFigureFeedDescriptor(instrument, priceRange, reversalAmount, offerSide), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IRangeBar> getRangeBars(Instrument instrument, OfferSide offerSide, PriceRange priceRange, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 1555 */     return getRangeBars(new RangeBarFeedDescriptor(instrument, priceRange, offerSide), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ITickBar> getTickBars(Instrument instrument, OfferSide offerSide, TickBarSize tickBarSize, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 1573 */     return getTickBars(new TickBarFeedDescriptor(instrument, tickBarSize, offerSide), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readPointAndFigures(final PointAndFigureFeedDescriptor feedDescriptor, final long from, long to, final IFeedPointAndFigureListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1590 */     HistoryUtils.validatePointAndFigureParams(feedDescriptor, listener, loadingProgress);
/* 1591 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getDataInterpolationDescriptor().getInterpolateFromPeriod(feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount()), from, to);
/*      */     try
/*      */     {
/* 1594 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception {
/* 1597 */           History.this.priceAggregationDataProvider.loadPointAndFigureTimeInterval(feedDescriptor, false, from, listener, new IPointAndFigureLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1608 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(PointAndFigureData pointAndFigure)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 1606 */                   History.28.this.val$listener.onPointAndFigureBar(History.28.this.val$feedDescriptor, pointAndFigure);
/*      */                 } catch (JFException e) {
/* 1608 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1615 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1619 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readPointAndFigures(final PointAndFigureFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter, final IFeedPointAndFigureListener listener, final LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1632 */     HistoryUtils.validatePointAndFigureParams(feedDescriptor, listener, loadingProgress);
/* 1633 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 1636 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception {
/* 1639 */           History.this.priceAggregationDataProvider.loadPointAndFigureData(feedDescriptor, numberOfBarsBefore, time, listener, new IPointAndFigureLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1650 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(PointAndFigureData pointAndFigure)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 1648 */                   History.29.this.val$listener.onPointAndFigureBar(History.29.this.val$feedDescriptor, pointAndFigure);
/*      */                 } catch (JFException e) {
/* 1650 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1657 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1661 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readPointAndFigures(final Instrument instrument, final OfferSide offerSide, final PriceRange priceRange, final ReversalAmount reversalAmount, long from, long to, final IPointAndFigureFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1677 */     HistoryUtils.validatePointAndFigureListeners(listener, loadingProgress);
/*      */     
/* 1679 */     readPointAndFigures(new PointAndFigureFeedDescriptor(instrument, priceRange, reversalAmount, offerSide), from, to, new IFeedPointAndFigureListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onPointAndFigureBar(ITailoredFeedDescriptor<IPointAndFigure> feedDescriptor, IPointAndFigure bar) {
/* 1693 */         listener.onBar(instrument, offerSide, priceRange, reversalAmount, bar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readPointAndFigures(final Instrument instrument, final OfferSide offerSide, final PriceRange priceRange, final ReversalAmount reversalAmount, int numberOfBarsBefore, long time, int numberOfBarsAfter, final IPointAndFigureFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1713 */     HistoryUtils.validatePointAndFigureListeners(listener, loadingProgress);
/*      */     
/* 1715 */     readPointAndFigures(new PointAndFigureFeedDescriptor(instrument, priceRange, reversalAmount, offerSide), numberOfBarsBefore, time, numberOfBarsAfter, new IFeedPointAndFigureListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onPointAndFigureBar(ITailoredFeedDescriptor<IPointAndFigure> feedDescriptor, IPointAndFigure bar) {
/* 1728 */         listener.onBar(instrument, offerSide, priceRange, reversalAmount, bar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readTickBars(final TickBarFeedDescriptor feedDescriptor, final long from, long to, final IFeedTickBarListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1743 */     HistoryUtils.validateTickBarParams(feedDescriptor, listener, loadingProgress);
/* 1744 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getDataInterpolationDescriptor().getInterpolateFromPeriod(null, null), from, to);
/*      */     try
/*      */     {
/* 1747 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception {
/* 1750 */           History.this.priceAggregationDataProvider.loadTickBarTimeInterval(feedDescriptor, from, listener, new ITickBarLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1760 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(TickBarData tickBar)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/* 1758 */                   History.32.this.val$listener.onTickBar(History.32.this.val$feedDescriptor, tickBar);
/*      */                 } catch (JFException e) {
/* 1760 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1767 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1771 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readTickBars(final TickBarFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter, final IFeedTickBarListener listener, final LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1784 */     HistoryUtils.validateTickBarParams(feedDescriptor, listener, loadingProgress);
/* 1785 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 1788 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception {
/* 1791 */           History.this.priceAggregationDataProvider.loadTickBarData(feedDescriptor, numberOfBarsBefore, time, listener, new ITickBarLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1803 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */ 
/*      */               public void newPriceData(TickBarData tickBar)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 1801 */                   History.33.this.val$listener.onTickBar(History.33.this.val$feedDescriptor, tickBar);
/*      */                 } catch (JFException e) {
/* 1803 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1810 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1814 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readTickBars(final Instrument instrument, final OfferSide offerSide, final TickBarSize tickBarSize, long from, long to, final ITickBarFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1830 */     HistoryUtils.validateTickBarListeners(listener, loadingProgress);
/*      */     
/* 1832 */     readTickBars(new TickBarFeedDescriptor(instrument, tickBarSize, offerSide), from, to, new IFeedTickBarListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onTickBar(ITailoredFeedDescriptor<ITickBar> feedDescriptor, ITickBar tickBar) {
/* 1844 */         listener.onBar(instrument, offerSide, tickBarSize, tickBar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readTickBars(final Instrument instrument, final OfferSide offerSide, final TickBarSize tickBarSize, int numberOfBarsBefore, long time, int numberOfBarsAfter, final ITickBarFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1862 */     HistoryUtils.validateTickBarListeners(listener, loadingProgress);
/*      */     
/* 1864 */     readTickBars(new TickBarFeedDescriptor(instrument, tickBarSize, offerSide), numberOfBarsBefore, time, numberOfBarsAfter, new IFeedTickBarListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onTickBar(ITailoredFeedDescriptor<ITickBar> feedDescriptor, ITickBar tickBar) {
/* 1877 */         listener.onBar(instrument, offerSide, tickBarSize, tickBar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readRangeBars(final RangeBarFeedDescriptor feedDescriptor, final long from, long to, final IFeedRangeBarListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1891 */     HistoryUtils.validateRangeBarParams(feedDescriptor, listener, loadingProgress);
/* 1892 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getDataInterpolationDescriptor().getInterpolateFromPeriod(feedDescriptor.getPriceRange(), null), from, to);
/*      */     try
/*      */     {
/* 1895 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception
/*      */         {
/* 1899 */           History.this.priceAggregationDataProvider.loadPriceRangeTimeInterval(feedDescriptor, false, from, listener, new IPriceRangeLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1910 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(PriceRangeData bar)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 1908 */                   History.36.this.val$listener.onRangeBar(History.36.this.val$feedDescriptor, bar);
/*      */                 } catch (JFException e) {
/* 1910 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1918 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1922 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readRangeBars(final RangeBarFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter, final IFeedRangeBarListener listener, final LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1934 */     HistoryUtils.validateRangeBarParams(feedDescriptor, listener, loadingProgress);
/* 1935 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 1938 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception
/*      */         {
/* 1942 */           History.this.priceAggregationDataProvider.loadPriceRangeData(feedDescriptor, numberOfBarsBefore, time, listener, new IPriceRangeLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1953 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(PriceRangeData bar)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 1951 */                   History.37.this.val$listener.onRangeBar(History.37.this.val$feedDescriptor, bar);
/*      */                 } catch (JFException e) {
/* 1953 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1961 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1965 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readRangeBars(final Instrument instrument, final OfferSide offerSide, final PriceRange priceRange, long from, long to, final IRangeBarFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 1980 */     HistoryUtils.validateRangeBarListeners(listener, loadingProgress);
/*      */     
/* 1982 */     readRangeBars(new RangeBarFeedDescriptor(instrument, priceRange, offerSide), from, to, new IFeedRangeBarListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onRangeBar(ITailoredFeedDescriptor<IRangeBar> feedDescriptor, IRangeBar rangeBar) {
/* 1994 */         listener.onBar(instrument, offerSide, priceRange, rangeBar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readRangeBars(final Instrument instrument, final OfferSide offerSide, final PriceRange priceRange, int numberOfBarsBefore, long time, int numberOfBarsAfter, final IRangeBarFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2013 */     HistoryUtils.validateRangeBarListeners(listener, loadingProgress);
/*      */     
/* 2015 */     readRangeBars(new RangeBarFeedDescriptor(instrument, priceRange, offerSide), numberOfBarsBefore, time, numberOfBarsAfter, new IFeedRangeBarListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onRangeBar(ITailoredFeedDescriptor<IRangeBar> feedDescriptor, IRangeBar rangeBar) {
/* 2029 */         listener.onBar(instrument, offerSide, priceRange, rangeBar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */   private ITick getTickSecured(final Instrument instrument, int shift)
/*      */     throws JFException
/*      */   {
/* 2036 */     ITick lastTick = this.feedDataProvider.getLastTick(instrument);
/* 2037 */     if (lastTick == null) {
/* 2038 */       return null;
/*      */     }
/* 2040 */     if (shift == 0) {
/* 2041 */       return lastTick;
/*      */     }
/*      */     try
/*      */     {
/* 2045 */       HistoryUtils.Loadable<ITick> loadable = new HistoryUtils.Loadable()
/*      */       {
/*      */         public List<ITick> load(long from, long to) throws Exception {
/* 2048 */           final List<ITick> bars = new ArrayList(3600);
/* 2049 */           History.this.feedDataProvider.loadTicksDataSynched(instrument, from, to, new LiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2056 */             new LoadingProgressAdapter
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {
/* 2056 */                 bars.add(new TickData(time, ask, bid, askVol, bidVol)); } public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {} }, new LoadingProgressAdapter() {});
/* 2064 */           return bars;
/*      */         }
/*      */         
/*      */         public long correctTime(long time) {
/* 2068 */           return time;
/*      */         }
/*      */         
/*      */         public long getStep() {
/* 2072 */           return 3600000L;
/*      */         }
/*      */         
/*      */         public long getFirstDataTime() {
/* 2076 */           return History.this.feedDataProvider.getTimeOfFirstTick(instrument);
/*      */         }
/*      */         
/* 2079 */       };
/* 2080 */       return (ITick)HistoryUtils.getByShift(loadable, lastTick.getTime(), shift);
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/*      */ 
/* 2086 */       throw new JFException(t);
/*      */     }
/*      */   }
/*      */   
/*      */   public ITick getTick(final Instrument instrument, final int shift)
/*      */     throws JFException
/*      */   {
/* 2093 */     if (instrument == null) {
/* 2094 */       throw new JFException("Instrument is null");
/*      */     }
/*      */     
/* 2097 */     HistoryUtils.validateShift(shift);
/*      */     try
/*      */     {
/* 2100 */       (ITick)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public ITick run() throws Exception {
/* 2103 */           ITick tick = History.this.getTickSecured(instrument, shift);
/* 2104 */           return tick;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2108 */       HistoryUtils.throwJFException(e); }
/* 2109 */     return null;
/*      */   }
/*      */   
/*      */   public void validateTimeInterval(Instrument instrument, long from, long to)
/*      */     throws JFException
/*      */   {
/* 2115 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, instrument, from, to);
/*      */   }
/*      */   
/*      */   public void validateTimeInterval(Instrument instrument, Period period, long from, long to) throws JFException {
/* 2119 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, instrument, period, from, to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void validateBeforeTimeAfter(Instrument instrument, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 2128 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, instrument, numberOfBarsBefore, time, numberOfBarsAfter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IBar> getBars(final Instrument instrument, final Period period, final OfferSide side, final Filter filter, final long from, long to)
/*      */     throws JFException
/*      */   {
/* 2142 */     HistoryUtils.validate(instrument, period, side, filter);
/* 2143 */     validateInstrumentSubscribed(instrument, period, to);
/*      */     
/* 2145 */     validateTimeInterval(instrument, period, from, to);
/* 2146 */     validateIntervalByPeriod(period, from, to);
/*      */     try
/*      */     {
/* 2149 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IBar> run() throws Exception {
/* 2152 */           return History.this.getBarsSecured(instrument, period, side, filter, from, this.val$to);
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2156 */       HistoryUtils.throwJFException(e); }
/* 2157 */     return null;
/*      */   }
/*      */   
/*      */   private void validateInstrumentSubscribed(Instrument instrument, Period period, long to) throws JFException
/*      */   {
/* 2162 */     if (isInstrumentSubscribed(instrument)) {
/* 2163 */       long timeOfLastCandle = getCurrentTime(instrument);
/* 2164 */       if (timeOfLastCandle != Long.MIN_VALUE) {
/* 2165 */         timeOfLastCandle = DataCacheUtils.getCandleStartFast(period, timeOfLastCandle);
/* 2166 */         if (to > timeOfLastCandle) {
/* 2167 */           throw new JFException("\"to\" parameter can't be greater than the time of the last formed bar for this instrument");
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 2172 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readBars(final Instrument instrument, final Period period, final OfferSide side, final Filter filter, final long from, long to, final LoadingDataListener barListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2189 */     HistoryUtils.validate(instrument, period, side, filter);
/* 2190 */     validateInstrumentSubscribed(instrument, period, to);
/* 2191 */     validateTimeInterval(instrument, period, from, to);
/* 2192 */     validateIntervalByPeriod(period, from, to);
/*      */     try
/*      */     {
/* 2195 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/* 2198 */           History.this.readBarsSecured(instrument, period, side, filter, from, barListener, this.val$barListener, this.val$loadingProgress);
/* 2199 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2203 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void readBarsSecured(Instrument instrument, Period period, OfferSide offerSide, Filter filter, long from, long to, LoadingDataListener barListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2219 */     if ((filter == null) || (Filter.NO_FILTER.equals(filter))) {
/* 2220 */       readBarsSecured(instrument, period, offerSide, from, to, barListener, loadingProgress);
/*      */     } else {
/*      */       try
/*      */       {
/* 2224 */         this.feedDataProvider.loadCandlesFromTo(instrument, period, offerSide, filter, from, to, new LiveFeedListenerWrapper(barListener), new LoadingProgressListenerWrapper(loadingProgress, false));
/*      */       } catch (DataCacheException e) {
/* 2226 */         throw new JFException(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected IRenkoBar getRenkoBar(final RenkoFeedDescriptor feedDescriptor, final int shift)
/*      */     throws JFException
/*      */   {
/* 2235 */     HistoryUtils.validateRenkoBarParams(feedDescriptor);
/* 2236 */     HistoryUtils.validateShift(shift);
/*      */     try
/*      */     {
/* 2239 */       (IRenkoBar)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public IRenkoBar run() throws Exception {
/* 2242 */           IRenkoBar lastCompletedRenko = History.this.feedDataProvider.getIntraperiodBarsGenerator().getOrLoadLastCompletedRenko(feedDescriptor);
/* 2243 */           if (lastCompletedRenko == null) {
/* 2244 */             return null;
/*      */           }
/* 2246 */           if (shift == 0) {
/* 2247 */             return null;
/*      */           }
/* 2249 */           if (shift == 1) {
/* 2250 */             return lastCompletedRenko;
/*      */           }
/*      */           
/* 2253 */           HistoryUtils.Loadable<RenkoData> loadable = new HistoryUtils.Loadable()
/*      */           {
/*      */             public List<RenkoData> load(long from, long to) throws Exception {
/* 2256 */               List<RenkoData> result = History.this.priceAggregationDataProvider.loadRenkoTimeInterval(History.44.this.val$feedDescriptor, false, from, to, true);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2263 */               return result;
/*      */             }
/*      */             
/*      */             public long correctTime(long time)
/*      */             {
/* 2268 */               return time;
/*      */             }
/*      */             
/*      */             public long getStep() {
/* 2272 */               return 86400000L;
/*      */             }
/*      */             
/*      */             public long getFirstDataTime() {
/* 2276 */               return History.this.feedDataProvider.getTimeOfFirstCandle(History.44.this.val$feedDescriptor.getInstrument(), History.44.this.val$feedDescriptor.getRenkoSession());
/*      */             }
/* 2278 */           };
/* 2279 */           return (IRenkoBar)HistoryUtils.getByShift(loadable, lastCompletedRenko.getTime(), shift - 1);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/* 2284 */       HistoryUtils.throwJFException(e); }
/* 2285 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IRenkoBar> getRenkoBars(final RenkoFeedDescriptor feedDescriptor, final long from, long to)
/*      */     throws JFException
/*      */   {
/* 2295 */     HistoryUtils.validateRenkoBarParams(feedDescriptor);
/* 2296 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getRenkoSession(), from, to);
/*      */     try
/*      */     {
/* 2299 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IRenkoBar> run() throws Exception {
/* 2302 */           IRenkoBar inProgressBar = History.this.getRenkoBar(feedDescriptor, 0);
/*      */           
/* 2304 */           long loadFrom = from;
/* 2305 */           long loadTo = this.val$to;
/*      */           
/* 2307 */           boolean addInProgressBar = false;
/*      */           
/* 2309 */           Long correctedToTime = History.this.checkAndGetTimeBeforeInProgressBar(inProgressBar, loadTo, null);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2315 */           if (correctedToTime != null) {
/* 2316 */             loadTo = correctedToTime.longValue();
/* 2317 */             addInProgressBar = true;
/*      */           }
/*      */           
/* 2320 */           if (loadFrom > loadTo) {
/* 2321 */             loadFrom = loadTo;
/*      */           }
/*      */           
/* 2324 */           List<RenkoData> data = History.this.priceAggregationDataProvider.loadRenkoTimeInterval(feedDescriptor, false, loadFrom, loadTo, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2331 */           List<IRenkoBar> result = HistoryUtils.convert(data);
/*      */           
/* 2333 */           if (addInProgressBar) {
/* 2334 */             result.add(inProgressBar);
/*      */           }
/*      */           
/* 2337 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2341 */       HistoryUtils.throwJFException(e); }
/* 2342 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<IRenkoBar> getRenkoBars(final RenkoFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 2353 */     HistoryUtils.validateRenkoBarParams(feedDescriptor);
/* 2354 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 2357 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<IRenkoBar> run() throws Exception {
/* 2360 */           List<RenkoData> data = History.this.priceAggregationDataProvider.loadRenkoData(feedDescriptor, numberOfBarsBefore, time, this.val$numberOfBarsAfter, true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2368 */           List<IRenkoBar> result = HistoryUtils.convert(data);
/*      */           
/*      */ 
/* 2371 */           IRenkoBar inProgressBar = History.this.getRenkoBar(feedDescriptor, 0);
/* 2372 */           if ((result != null) && (result.isEmpty())) {
/* 2373 */             IRenkoBar lastBar = (IRenkoBar)result.get(result.size() - 1);
/* 2374 */             if ((lastBar instanceof RenkoData)) {
/* 2375 */               RenkoData renkoData = (RenkoData)lastBar;
/* 2376 */               if (renkoData.getElementTimeFinishedCurrentBar() == inProgressBar.getTime()) {
/* 2377 */                 result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, 0L);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 2382 */             Period suitablePeriod = TimeDataUtils.getSuitablePeriod(feedDescriptor.getPriceRange());
/* 2383 */             long maxIntervalBetweenTwoBars = suitablePeriod.isTickBasedPeriod() ? TimeUnit.HOURS.toMillis(1L) : suitablePeriod.getInterval() * 2L;
/* 2384 */             result = History.this.prepareResult(inProgressBar, result, numberOfBarsBefore, time, this.val$numberOfBarsAfter, maxIntervalBetweenTwoBars);
/*      */           }
/*      */           
/* 2387 */           return result;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2391 */       HistoryUtils.throwJFException(e); }
/* 2392 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IRenkoBar getRenkoBar(Instrument instrument, OfferSide offerSide, PriceRange brickSize, int shift)
/*      */     throws JFException
/*      */   {
/* 2403 */     return getRenkoBar(new RenkoFeedDescriptor(instrument, brickSize, offerSide), shift);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IRenkoBar> getRenkoBars(Instrument instrument, OfferSide offerSide, PriceRange brickSize, long from, long to)
/*      */     throws JFException
/*      */   {
/* 2420 */     return getRenkoBars(new RenkoFeedDescriptor(instrument, brickSize, offerSide), from, to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IRenkoBar> getRenkoBars(Instrument instrument, OfferSide offerSide, PriceRange brickSize, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/* 2438 */     return getRenkoBars(new RenkoFeedDescriptor(instrument, brickSize, offerSide), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected <T extends IPriceAggregationBar> boolean isTimeBelongsToBar(long time, T bar)
/*      */   {
/* 2448 */     long from = bar.getTime();
/*      */     long to;
/* 2450 */     long to; if ((bar instanceof RenkoData)) {
/* 2451 */       RenkoData renko = (RenkoData)bar;
/* 2452 */       long to; if (renko.getInProgressBar() != null) {
/* 2453 */         to = renko.getInProgressBar().getEndTime();
/*      */       }
/*      */       else {
/* 2456 */         to = bar.getEndTime();
/*      */       }
/*      */     }
/*      */     else {
/* 2460 */       to = bar.getEndTime();
/*      */     }
/*      */     
/* 2463 */     boolean result = (from <= time) && (time <= to);
/* 2464 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected <T extends IPriceAggregationBar> List<T> prepareResult(T inProgressBar, List<T> bars, int numberOfBarsBefore, long time, int numberOfBarsAfter, long maxIntervalBetweenTwoBars)
/*      */   {
/* 2476 */     if (numberOfBarsBefore + numberOfBarsAfter <= 0) {
/* 2477 */       return new ArrayList();
/*      */     }
/*      */     
/* 2480 */     if (inProgressBar == null) {
/* 2481 */       return bars;
/*      */     }
/*      */     
/* 2484 */     if (isTimeBelongsToBar(time, inProgressBar)) {
/* 2485 */       if (bars.isEmpty()) {
/* 2486 */         return Collections.singletonList(inProgressBar);
/*      */       }
/*      */       
/* 2489 */       if (numberOfBarsBefore > 0) { int fromIndex;
/*      */         int fromIndex;
/* 2491 */         if (bars.size() >= numberOfBarsBefore) {
/* 2492 */           fromIndex = bars.size() - numberOfBarsBefore + 1;
/*      */         }
/*      */         else {
/* 2495 */           fromIndex = 0;
/*      */         }
/* 2497 */         List<T> result = bars.subList(fromIndex, bars.size());
/* 2498 */         result.add(inProgressBar);
/* 2499 */         return result;
/*      */       }
/* 2501 */       if (numberOfBarsAfter > 0) {
/* 2502 */         return Collections.singletonList(inProgressBar);
/*      */       }
/*      */       
/* 2505 */       return new ArrayList();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2510 */     if (!bars.isEmpty()) {
/* 2511 */       int timeIndex = TimeDataUtils.timeIndex(bars, time);
/*      */       
/* 2513 */       if (timeIndex < 0) {
/* 2514 */         if (((IPriceAggregationBar)bars.get(bars.size() - 1)).getEndTime() + maxIntervalBetweenTwoBars >= inProgressBar.getTime()) {
/* 2515 */           int fromIndex = bars.size() - Math.min(numberOfBarsBefore + numberOfBarsAfter, bars.size());
/* 2516 */           List<T> result = bars.subList(fromIndex, bars.size());
/* 2517 */           return result;
/*      */         }
/*      */         
/* 2520 */         return bars;
/*      */       }
/*      */       
/*      */ 
/* 2524 */       int fromIndex = Math.max(0, timeIndex - (numberOfBarsBefore == 0 ? 0 : numberOfBarsBefore - 1));
/* 2525 */       int toIndex = Math.min(bars.size(), timeIndex + (numberOfBarsBefore == 0 ? numberOfBarsAfter : numberOfBarsAfter + 1));
/* 2526 */       List<T> result = bars.subList(fromIndex, toIndex);
/* 2527 */       if ((toIndex - timeIndex - (numberOfBarsBefore == 0 ? 0 : 1) < numberOfBarsAfter) && ((bars.get(bars.size() - 1) instanceof AbstractPriceAggregationData)))
/*      */       {
/*      */ 
/*      */ 
/* 2531 */         AbstractPriceAggregationData lastData = (AbstractPriceAggregationData)bars.get(bars.size() - 1);
/* 2532 */         if (lastData.getElementTimeFinishedCurrentBar() == inProgressBar.getTime()) {
/* 2533 */           result.add(inProgressBar);
/*      */         }
/*      */       }
/* 2536 */       return result;
/*      */     }
/*      */     
/* 2539 */     if (time + maxIntervalBetweenTwoBars >= inProgressBar.getTime()) {
/* 2540 */       return Collections.singletonList(inProgressBar);
/*      */     }
/*      */     
/* 2543 */     return bars;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readRenkoBars(final RenkoFeedDescriptor feedDescriptor, final long from, long to, final IFeedRenkoListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2556 */     HistoryUtils.validateRenkoBarParams(feedDescriptor, listener, loadingProgress);
/* 2557 */     HistoryUtils.validateTimeInterval(this.feedDataProvider, feedDescriptor.getInstrument(), feedDescriptor.getRenkoSession(), from, to);
/*      */     try
/*      */     {
/* 2560 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception
/*      */         {
/* 2564 */           History.this.priceAggregationDataProvider.loadRenkoTimeInterval(feedDescriptor, false, from, listener, new IRenkoLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2575 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(RenkoData bar)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 2573 */                   History.47.this.val$listener.onRenkoBar(History.47.this.val$feedDescriptor, bar);
/*      */                 } catch (JFException e) {
/* 2575 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2583 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2587 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readRenkoBars(final RenkoFeedDescriptor feedDescriptor, final int numberOfBarsBefore, final long time, int numberOfBarsAfter, final IFeedRenkoListener listener, final LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2600 */     HistoryUtils.validateRenkoBarParams(feedDescriptor, listener, loadingProgress);
/* 2601 */     HistoryUtils.validateBeforeTimeAfter(this.feedDataProvider, feedDescriptor.getInstrument(), numberOfBarsBefore, time, numberOfBarsAfter);
/*      */     try
/*      */     {
/* 2604 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Void run() throws Exception
/*      */         {
/* 2608 */           History.this.priceAggregationDataProvider.loadRenkoData(feedDescriptor, numberOfBarsBefore, time, listener, new IRenkoLiveFeedListener()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2619 */             new History.LoadingProgressListenerWrapper
/*      */             {
/*      */ 
/*      */               public void newPriceData(RenkoData renko)
/*      */               {
/*      */ 
/*      */                 try
/*      */                 {
/*      */ 
/* 2617 */                   History.48.this.val$listener.onRenkoBar(History.48.this.val$feedDescriptor, renko);
/*      */                 } catch (JFException e) {
/* 2619 */                   History.LOGGER.error(e.getLocalizedMessage(), e); } } }, new History.LoadingProgressListenerWrapper(History.this, this.val$loadingProgress, false), true);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2628 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 2632 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readRenkoBars(final Instrument instrument, final OfferSide offerSide, final PriceRange brickSize, long from, long to, final IRenkoBarFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2647 */     HistoryUtils.validateRenkoListeners(listener, loadingProgress);
/*      */     
/* 2649 */     readRenkoBars(new RenkoFeedDescriptor(instrument, brickSize, offerSide), from, to, new IFeedRenkoListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onRenkoBar(ITailoredFeedDescriptor<IRenkoBar> feedDescriptor, IRenkoBar bar) {
/* 2661 */         listener.onBar(instrument, offerSide, brickSize, bar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readRenkoBars(final Instrument instrument, final OfferSide offerSide, final PriceRange brickSize, int numberOfBarsBefore, long time, int numberOfBarsAfter, final IRenkoBarFeedListener listener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2680 */     HistoryUtils.validateRenkoListeners(listener, loadingProgress);
/*      */     
/* 2682 */     readRenkoBars(new RenkoFeedDescriptor(instrument, brickSize, offerSide), numberOfBarsBefore, time, numberOfBarsAfter, new IFeedRenkoListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onRenkoBar(ITailoredFeedDescriptor<IRenkoBar> feedDescriptor, IRenkoBar bar) {
/* 2694 */         listener.onBar(instrument, offerSide, brickSize, bar); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */   protected class LoadingProgressListenerWrapper
/*      */     implements ILoadingProgressListener
/*      */   {
/*      */     private LoadingProgressListener loadingProgressListener;
/*      */     private boolean ordersHistoryRequest;
/*      */     
/*      */     public LoadingProgressListenerWrapper(LoadingProgressListener loadingProgressListener, boolean ordersHistoryRequest)
/*      */     {
/* 2706 */       this.loadingProgressListener = loadingProgressListener;
/* 2707 */       this.ordersHistoryRequest = ordersHistoryRequest;
/*      */     }
/*      */     
/*      */     public void dataLoaded(long startTime, long endTime, long currentTime, String information)
/*      */     {
/* 2712 */       this.loadingProgressListener.dataLoaded(startTime, endTime, currentTime, information);
/*      */     }
/*      */     
/*      */     public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */     {
/* 2717 */       if (e != null) {
/* 2718 */         History.LOGGER.error(e.getMessage(), e);
/*      */       }
/* 2720 */       this.loadingProgressListener.loadingFinished(allDataLoaded, startTime, endTime, currentTime);
/* 2721 */       if (this.ordersHistoryRequest) {
/* 2722 */         History.this.ordersHistoryRequestSent.set(false);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean stopJob()
/*      */     {
/* 2728 */       return this.loadingProgressListener.stopJob();
/*      */     }
/*      */   }
/*      */   
/*      */   protected class LoadingOrdersListenerWrapper implements OrdersListener {
/*      */     private LoadingOrdersListener listener;
/*      */     private long from;
/*      */     private long to;
/*      */     
/*      */     public LoadingOrdersListenerWrapper(LoadingOrdersListener listener, long from, long to) {
/* 2738 */       this.listener = listener;
/* 2739 */       this.from = from;
/* 2740 */       this.to = to;
/*      */     }
/*      */     
/*      */     public void newOrder(Instrument instrument, OrderHistoricalData orderData)
/*      */     {
/* 2745 */       if (!orderData.isClosed()) {
/* 2746 */         return;
/*      */       }
/* 2748 */       HistoryOrder order = History.this.historyOrderProvider.processOrders(instrument, orderData, this.from, this.to);
/* 2749 */       if (order != null) {
/* 2750 */         this.listener.newOrder(instrument, order);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void orderChange(Instrument instrument, OrderHistoricalData orderData) {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void orderMerge(Instrument instrument, OrderHistoricalData resultingOrderData, List<OrderHistoricalData> mergedOrdersData) {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void ordersInvalidated(Instrument instrument) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ITimedData getFeedData(IFeedDescriptor feedDescriptor, int shift)
/*      */     throws JFException
/*      */   {
/* 2773 */     switch (feedDescriptor.getDataType()) {
/* 2774 */     case POINT_AND_FIGURE:  return getPointAndFigure(new PointAndFigureFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor()), shift);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 2785 */       return getRangeBar(new RangeBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor()), shift);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case RENKO: 
/* 2795 */       return getRenkoBar(new RenkoFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getRenkoSession(), feedDescriptor.getRenkoCreationPoint(), feedDescriptor.getPeriod()), shift);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TICK_BAR: 
/* 2806 */       return getTickBar(new TickBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getTickBarSize(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod()), shift);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 2815 */       return getBar(feedDescriptor.getInstrument(), feedDescriptor.getPeriod(), feedDescriptor.getOfferSide(), shift);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case TICKS: 
/* 2821 */       return getTick(feedDescriptor.getInstrument(), shift);
/*      */     }
/*      */     
/*      */     
/* 2825 */     throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ITimedData> getFeedData(IFeedDescriptor feedDescriptor, long from, long to)
/*      */     throws JFException
/*      */   {
/* 2836 */     switch (feedDescriptor.getDataType()) {
/* 2837 */     case POINT_AND_FIGURE:  return getPointAndFigures(new PointAndFigureFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor()), from, to);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 2849 */       return getRangeBars(new RangeBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor()), from, to);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case RENKO: 
/* 2860 */       return getRenkoBars(new RenkoFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getRenkoSession(), feedDescriptor.getRenkoCreationPoint(), feedDescriptor.getPeriod()), from, to);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TICK_BAR: 
/* 2872 */       return getTickBars(new TickBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getTickBarSize(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod()), from, to);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 2882 */       return getBars(feedDescriptor.getInstrument(), feedDescriptor.getPeriod(), feedDescriptor.getOfferSide(), feedDescriptor.getFilter(), from, to);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TICKS: 
/* 2890 */       return getTicks(feedDescriptor.getInstrument(), from, to);
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 2895 */     throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ITimedData> getFeedData(IFeedDescriptor feedDescriptor, int numberOfFeedBarsBefore, long time, int numberOfFeedBarsAfter)
/*      */     throws JFException
/*      */   {
/* 2907 */     switch (feedDescriptor.getDataType()) {
/* 2908 */     case POINT_AND_FIGURE:  return getPointAndFigures(new PointAndFigureFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor()), numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 2921 */       return getRangeBars(new RangeBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor()), numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case RENKO: 
/* 2933 */       return getRenkoBars(new RenkoFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getRenkoSession(), feedDescriptor.getRenkoCreationPoint(), feedDescriptor.getPeriod()), numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TICK_BAR: 
/* 2946 */       return getTickBars(new TickBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getTickBarSize(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod()), numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 2957 */       return getBars(feedDescriptor.getInstrument(), feedDescriptor.getPeriod(), feedDescriptor.getOfferSide(), feedDescriptor.getFilter(), numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case TICKS: 
/* 2966 */       return getTicks(feedDescriptor.getInstrument(), numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/* 2972 */     throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readBars(IFeedDescriptor feedDescriptor, long from, long to, LoadingDataListener barListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 2983 */     readBars(feedDescriptor.getInstrument(), feedDescriptor.getPeriod(), feedDescriptor.getOfferSide(), feedDescriptor.getFilter(), from, to, barListener, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readBars(IFeedDescriptor feedDescriptor, int numberOfCandlesBefore, long time, int numberOfCandlesAfter, LoadingDataListener barListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3003 */     readBars(feedDescriptor.getInstrument(), feedDescriptor.getPeriod(), feedDescriptor.getOfferSide(), feedDescriptor.getFilter(), numberOfCandlesBefore, time, numberOfCandlesAfter, barListener, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readTicks(IFeedDescriptor feedDescriptor, long from, long to, LoadingDataListener tickListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3023 */     readTicks(feedDescriptor.getInstrument(), from, to, tickListener, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readFeedData(IFeedDescriptor feedDescriptor, long from, long to, final IFeedListener feedListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3040 */     switch (feedDescriptor.getDataType()) {
/*      */     case POINT_AND_FIGURE: 
/* 3042 */       final PointAndFigureFeedDescriptor pointAndFeedDescriptor = new PointAndFigureFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3050 */       readPointAndFigures(pointAndFeedDescriptor, from, to, new IFeedPointAndFigureListener()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         public void onPointAndFigureBar(ITailoredFeedDescriptor<IPointAndFigure> feedDescriptor, IPointAndFigure bar) {
/* 3056 */           feedListener.onFeedData(pointAndFeedDescriptor, bar); } }, loadingProgress);
/*      */       
/*      */ 
/*      */ 
/* 3060 */       break;
/*      */     
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 3063 */       final RangeBarFeedDescriptor rangeBarFeedDescriptor = new RangeBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3071 */       readRangeBars(rangeBarFeedDescriptor, from, to, new IFeedRangeBarListener()
/*      */       {
/*      */ 
/*      */ 
/*      */         public void onRangeBar(ITailoredFeedDescriptor<IRangeBar> feedDescriptor, IRangeBar rangeBar) {
/* 3076 */           feedListener.onFeedData(rangeBarFeedDescriptor, rangeBar); } }, loadingProgress);
/*      */       
/*      */ 
/*      */ 
/* 3080 */       break;
/*      */     
/*      */     case RENKO: 
/* 3083 */       final RenkoFeedDescriptor renkoFeedDescriptor = new RenkoFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getRenkoSession(), feedDescriptor.getRenkoCreationPoint(), feedDescriptor.getPeriod());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3091 */       readRenkoBars(renkoFeedDescriptor, from, to, new IFeedRenkoListener()
/*      */       {
/*      */ 
/*      */         public void onRenkoBar(ITailoredFeedDescriptor<IRenkoBar> feedDescriptor, IRenkoBar bar) {
/* 3095 */           feedListener.onFeedData(renkoFeedDescriptor, bar); } }, loadingProgress);
/*      */       
/*      */ 
/*      */ 
/* 3099 */       break;
/*      */     
/*      */     case TICK_BAR: 
/* 3102 */       final TickBarFeedDescriptor tickBarFeedDescriptor = new TickBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getTickBarSize(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3108 */       readTickBars(tickBarFeedDescriptor, from, to, new IFeedTickBarListener()
/*      */       {
/*      */ 
/*      */ 
/*      */         public void onTickBar(ITailoredFeedDescriptor<ITickBar> feedDescriptor, ITickBar tickBar) {
/* 3113 */           feedListener.onFeedData(tickBarFeedDescriptor, tickBar); } }, loadingProgress);
/*      */       
/*      */ 
/*      */ 
/* 3117 */       break;
/*      */     
/*      */     case TICKS: 
/* 3120 */       readTicks(feedDescriptor, from, to, new LoadingDataListener()
/*      */       {
/*      */ 
/* 3123 */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) { feedListener.onFeedData(new TicksFeedDescriptor(instrument), new TickData(time, ask, bid, askVol, bidVol)); } public void newBar(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {} }, loadingProgress);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3129 */       break;
/*      */     
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 3132 */       readBars(feedDescriptor, from, to, new LoadingDataListener()
/*      */       {
/*      */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/*      */         
/*      */ 
/*      */ 
/* 3138 */         public void newBar(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) { feedListener.onFeedData(new TimePeriodAggregationFeedDescriptor(instrument, period, side), new CandleData(time, open, close, low, high, vol)); } }, loadingProgress);
/*      */       
/*      */ 
/* 3141 */       break;
/*      */     default: 
/* 3143 */       throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readFeedData(IFeedDescriptor feedDescriptor, int numberOfFeedDataBefore, long time, int numberOfFeedDataAfter, final IFeedListener feedListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3156 */     switch (feedDescriptor.getDataType()) {
/*      */     case POINT_AND_FIGURE: 
/* 3158 */       final PointAndFigureFeedDescriptor pointAndFeedDescriptor = new PointAndFigureFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3166 */       readPointAndFigures(pointAndFeedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new IFeedPointAndFigureListener()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         public void onPointAndFigureBar(ITailoredFeedDescriptor<IPointAndFigure> feedDescriptor, IPointAndFigure bar) {
/* 3172 */           feedListener.onFeedData(pointAndFeedDescriptor, bar); } }, loadingProgress);
/*      */       
/*      */ 
/* 3175 */       break;
/*      */     
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 3178 */       final RangeBarFeedDescriptor rangeBarFeedDescriptor = new RangeBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3185 */       readRangeBars(rangeBarFeedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new IFeedRangeBarListener()
/*      */       {
/*      */ 
/*      */ 
/*      */         public void onRangeBar(ITailoredFeedDescriptor<IRangeBar> feedDescriptor, IRangeBar rangeBar) {
/* 3190 */           feedListener.onFeedData(rangeBarFeedDescriptor, rangeBar); } }, loadingProgress);
/*      */       
/*      */ 
/* 3193 */       break;
/*      */     
/*      */     case RENKO: 
/* 3196 */       final RenkoFeedDescriptor renkoFeedDescriptor = new RenkoFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getRenkoSession(), feedDescriptor.getRenkoCreationPoint(), feedDescriptor.getPeriod());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3204 */       readRenkoBars(renkoFeedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new IFeedRenkoListener()
/*      */       {
/*      */ 
/*      */ 
/*      */         public void onRenkoBar(ITailoredFeedDescriptor<IRenkoBar> feedDescriptor, IRenkoBar bar) {
/* 3209 */           feedListener.onFeedData(renkoFeedDescriptor, bar); } }, loadingProgress);
/*      */       
/*      */ 
/* 3212 */       break;
/*      */     
/*      */     case TICK_BAR: 
/* 3215 */       final TickBarFeedDescriptor tickBarFeedDescriptor = new TickBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getTickBarSize(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3222 */       readTickBars(tickBarFeedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new IFeedTickBarListener()
/*      */       {
/*      */ 
/*      */ 
/*      */         public void onTickBar(ITailoredFeedDescriptor<ITickBar> feedDescriptor, ITickBar tickBar) {
/* 3227 */           feedListener.onFeedData(tickBarFeedDescriptor, tickBar); } }, loadingProgress);
/*      */       
/*      */ 
/* 3230 */       break;
/*      */     
/*      */     case TICKS: 
/* 3233 */       readTicks(feedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new LoadingDataListener()
/*      */       {
/*      */ 
/* 3236 */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) { feedListener.onFeedData(new TicksFeedDescriptor(instrument), new TickData(time, ask, bid, askVol, bidVol)); } public void newBar(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {} }, loadingProgress);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3242 */       break;
/*      */     
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 3245 */       readBars(feedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new LoadingDataListener()
/*      */       {
/*      */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/*      */         
/*      */ 
/*      */ 
/* 3251 */         public void newBar(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) { feedListener.onFeedData(new TimePeriodAggregationFeedDescriptor(instrument, period, side), new CandleData(time, open, close, low, high, vol)); } }, loadingProgress);
/*      */       
/*      */ 
/* 3254 */       break;
/*      */     default: 
/* 3256 */       throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readTicks(final Instrument instrument, final int numberOfOneSecondIntervalsBefore, final long time, int numberOfOneSecondIntervalsAfter, final LoadingDataListener tickListener, final LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3270 */     validateBeforeTimeAfter(instrument, numberOfOneSecondIntervalsBefore, time, numberOfOneSecondIntervalsAfter);
/*      */     
/* 3272 */     if (isInstrumentSubscribed(instrument)) {
/* 3273 */       long timeOfCurrentCandle = getCurrentTime(instrument);
/* 3274 */       if ((timeOfCurrentCandle != Long.MIN_VALUE) && (time > timeOfCurrentCandle)) {
/* 3275 */         throw new JFException("\"time\" parameter can't be greater than time of the last tick for this instrument");
/*      */       }
/*      */     }
/*      */     else {
/* 3279 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/* 3282 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/* 3285 */           History.this.readTicksSecured(instrument, numberOfOneSecondIntervalsBefore, time, tickListener, loadingProgress, this.val$loadingProgress);
/* 3286 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 3290 */       HistoryUtils.throwJFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readTicksSecured(Instrument instrument, int numberOfOneSecondIntervalsBefore, long time, int numberOfOneSecondIntervalsAfter, LoadingDataListener tickListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/*      */     try
/*      */     {
/* 3303 */       this.feedDataProvider.loadTicksDataBeforeAfter(instrument, numberOfOneSecondIntervalsBefore, numberOfOneSecondIntervalsAfter, time, Filter.NO_FILTER, new LiveFeedListenerWrapper(tickListener), new LoadingProgressListenerWrapper(loadingProgress, false));
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (DataCacheException e)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3313 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private List<ITick> getTicksSecured(Instrument instrument, int numberOfOneSecondIntervalsBefore, long time, int numberOfOneSecondIntervalsAfter)
/*      */     throws JFException
/*      */   {
/*      */     try
/*      */     {
/* 3324 */       final List<ITick> ticks = new ArrayList();
/* 3325 */       final int[] result = { 0 };
/* 3326 */       final Throwable[] exceptions = new Throwable[1];
/* 3327 */       ILoadingProgressListener loadingProgressListener = new ILoadingProgressListener()
/*      */       {
/*      */         public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*      */         
/*      */         public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*      */         {
/* 3333 */           result[0] = (allDataLoaded ? 1 : 2);
/* 3334 */           exceptions[0] = e;
/*      */         }
/*      */         
/*      */         public boolean stopJob() {
/* 3338 */           return false;
/*      */         }
/* 3340 */       };
/* 3341 */       this.feedDataProvider.loadTicksDataBeforeAfterSynched(instrument, numberOfOneSecondIntervalsBefore, numberOfOneSecondIntervalsAfter, time, Filter.NO_FILTER, new LiveFeedListener()
/*      */       {
/*      */ 
/* 3344 */         public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) { ticks.add(new TickData(time, ask, bid, askVol, bidVol, null, null, null, null)); } public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {} }, loadingProgressListener);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3351 */       if (result[0] == 2) {
/* 3352 */         throw new JFException("Error while loading ticks", exceptions[0]);
/*      */       }
/* 3354 */       return ticks;
/*      */     }
/*      */     catch (DataCacheException e) {
/* 3357 */       throw new JFException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readTicks(IFeedDescriptor feedDescriptor, int numberOfOneSecondIntervalsBefore, long time, int numberOfOneSecondIntervalsAfter, LoadingDataListener tickListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3369 */     readTicks(feedDescriptor.getInstrument(), numberOfOneSecondIntervalsBefore, time, numberOfOneSecondIntervalsAfter, tickListener, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<ITick> getTicks(final Instrument instrument, final int numberOfOneSecondIntervalsBefore, final long time, int numberOfOneSecondIntervalsAfter)
/*      */     throws JFException
/*      */   {
/* 3386 */     validateBeforeTimeAfter(instrument, numberOfOneSecondIntervalsBefore, time, numberOfOneSecondIntervalsAfter);
/*      */     
/* 3388 */     if (isInstrumentSubscribed(instrument)) {
/* 3389 */       long timeOfCurrentCandle = getCurrentTime(instrument);
/* 3390 */       if ((timeOfCurrentCandle != Long.MIN_VALUE) && (time > timeOfCurrentCandle)) {
/* 3391 */         throw new JFException("\"time\" parameter can't be greater than time of the last tick for this instrument");
/*      */       }
/*      */     }
/*      */     else {
/* 3395 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/*      */     try {
/* 3398 */       (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public List<ITick> run() throws Exception {
/* 3401 */           return History.this.getTicksSecured(instrument, numberOfOneSecondIntervalsBefore, time, this.val$numberOfOneSecondIntervalsAfter);
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 3405 */       HistoryUtils.throwJFException(e); }
/* 3406 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <T extends IPriceAggregationBar, D extends T> Long checkAndGetTimeBeforeInProgressBar(T inProgressBar, long time, IPriceAggregationShiftableBuffer<D> cache)
/*      */   {
/* 3415 */     if ((inProgressBar != null) && (isTimeBelongsToBar(time, inProgressBar))) {
/* 3416 */       if ((cache != null) && (cache.getLast() != null)) {
/* 3417 */         return Long.valueOf(((IPriceAggregationBar)cache.getLast()).getEndTime());
/*      */       }
/*      */       
/* 3420 */       return Long.valueOf(inProgressBar.getTime() - 1L);
/*      */     }
/*      */     
/* 3423 */     return null;
/*      */   }
/*      */   
/*      */   protected Period getBasePeriod(IFeedDescriptor feedDescriptor) {
/* 3427 */     Period basePer = null;
/* 3428 */     if (Period.isInfinity(feedDescriptor.getPeriod())) {
/* 3429 */       basePer = Period.INFINITY;
/*      */     }
/*      */     else {
/* 3432 */       basePer = TimeDataUtils.getDefaultSessionPeriod();
/*      */     }
/* 3434 */     return basePer;
/*      */   }
/*      */   
/*      */   public <T extends ITimedData> T getFeedData(ITailoredFeedDescriptor<T> feedDescriptor, int shift) throws JFException
/*      */   {
/* 3439 */     return getFeedData(feedDescriptor, shift);
/*      */   }
/*      */   
/*      */   public <T extends ITimedData> List<T> getFeedData(ITailoredFeedDescriptor<T> feedDescriptor, long from, long to) throws JFException
/*      */   {
/* 3444 */     return getFeedData(feedDescriptor, from, to);
/*      */   }
/*      */   
/*      */   public <T extends ITimedData> List<T> getFeedData(ITailoredFeedDescriptor<T> feedDescriptor, int numberOfFeedBarsBefore, long time, int numberOfFeedBarsAfter)
/*      */     throws JFException
/*      */   {
/* 3450 */     return getFeedData(feedDescriptor, numberOfFeedBarsBefore, time, numberOfFeedBarsAfter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends ITimedData> void readFeedData(final ITailoredFeedDescriptor<T> feedDescriptor, long from, long to, final ITailoredFeedListener<T> feedListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3461 */     readFeedData(feedDescriptor, from, to, new IFeedListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onFeedData(IFeedDescriptor feedDescriptorGeneral, ITimedData feedData) {
/* 3468 */         feedListener.onFeedData(feedDescriptor, feedData); } }, loadingProgress);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends ITimedData> void readFeedData(final ITailoredFeedDescriptor<T> feedDescriptor, int numberOfFeedDataBefore, long time, int numberOfFeedDataAfter, final ITailoredFeedListener<T> feedListener, LoadingProgressListener loadingProgress)
/*      */     throws JFException
/*      */   {
/* 3484 */     readFeedData(feedDescriptor, numberOfFeedDataBefore, time, numberOfFeedDataAfter, new IFeedListener()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onFeedData(IFeedDescriptor feedDescriptorGeneral, ITimedData feedData) {
/* 3492 */         feedListener.onFeedData(feedDescriptor, feedData); } }, loadingProgress);
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\History.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */