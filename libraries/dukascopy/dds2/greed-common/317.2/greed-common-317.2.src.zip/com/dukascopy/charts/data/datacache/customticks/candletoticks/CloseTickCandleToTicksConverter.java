/*    */ package com.dukascopy.charts.data.datacache.customticks.candletoticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ 
/*    */ public class CloseTickCandleToTicksConverter implements ICandleToTicksConverter
/*    */ {
/*    */   private final double spreadInPipsAsk;
/*    */   private final double spreadInPipsBid;
/*    */   private Period period;
/*    */   
/*    */   public CloseTickCandleToTicksConverter(Instrument instrument, OfferSide offerSide, Period period)
/*    */   {
/* 18 */     this.spreadInPipsAsk = ((OfferSide.ASK.equals(offerSide) ? 0.0D : 2.0D) * instrument.getPipValue());
/* 19 */     this.spreadInPipsBid = ((OfferSide.ASK.equals(offerSide) ? -2.0D : 0.0D) * instrument.getPipValue());
/* 20 */     this.period = period;
/*    */   }
/*    */   
/*    */ 
/*    */   public TickData[] splitCandle(long time, double open, double high, double low, double close, double volume)
/*    */   {
/* 26 */     long tickTime = DataCacheUtils.getNextCandleStartFast(this.period, time) - 1L;
/* 27 */     double ask = StratUtils.round(close + this.spreadInPipsAsk, 5);
/* 28 */     double bid = StratUtils.round(close + this.spreadInPipsBid, 5);
/*    */     
/* 30 */     return new TickData[] { new TickData(tickTime, ask, bid, volume, volume, null, null, null, null) };
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\candletoticks\CloseTickCandleToTicksConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */