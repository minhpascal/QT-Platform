/*     */ package com.dukascopy.charts.data.datacache.ccheck;
/*     */ 
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.Unit;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.time.ITimeManager;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MissingFileScheduler
/*     */ {
/*     */   private MissingFileEntryManager manager;
/*     */   private IPACacheManager paManager;
/*     */   private Timer timer;
/*     */   private ThreadFactory threadFactory;
/*     */   private LinkedBlockingQueue<Runnable> queue;
/*     */   private ExecutorService executor;
/*     */   
/*     */   public MissingFileScheduler(MissingFileEntryManager manager, IPACacheManager paManager)
/*     */   {
/*  35 */     this.manager = manager;
/*  36 */     this.paManager = paManager;
/*  37 */     this.timer = new Timer("CacheTimer", true);
/*  38 */     this.threadFactory = new ThreadFactory()
/*     */     {
/*     */       public Thread newThread(Runnable r) {
/*  41 */         Thread thread = new Thread(r, "MFEntryThread");
/*  42 */         return thread;
/*     */       }
/*  44 */     };
/*  45 */     this.queue = new LinkedBlockingQueue();
/*     */     
/*  47 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  51 */     this.executor = new ThreadPoolExecutor(1, 1, 20L, TimeUnit.MINUTES, this.queue, this.threadFactory, new ThreadPoolExecutor.DiscardOldestPolicy());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */     TimerTask timerTask = new TimerTask()
/*     */     {
/*     */       public void run() {
/*  63 */         MissingFileScheduler.this.executor.execute(new MFCheckAllCacheAction(MissingFileScheduler.this.manager));
/*     */       }
/*     */       
/*  66 */     };
/*  67 */     long currentTime = System.currentTimeMillis();
/*     */     
/*  69 */     FeedDataProvider fdp = FeedDataProvider.getDefaultInstance();
/*  70 */     if ((fdp != null) && (fdp.getTimeManager() != null)) {
/*  71 */       Long sTime = fdp.getTimeManager().getServerTime();
/*  72 */       if (sTime != null) {
/*  73 */         currentTime = sTime.longValue();
/*     */       }
/*     */     }
/*     */     
/*  77 */     long offset00 = Unit.Day.getInterval() - (currentTime - DataCacheUtils.getCandleStartFast(Period.DAILY, currentTime));
/*  78 */     long offset22 = offset00;
/*  79 */     if (offset00 >= Unit.Hour.getInterval() * 2L) {
/*  80 */       offset22 = offset00 - Unit.Hour.getInterval() * 2L;
/*     */     }
/*     */     else {
/*  83 */       offset22 += Unit.Hour.getInterval() * 22L;
/*     */     }
/*     */     
/*  86 */     this.timer.schedule(timerTask, offset22, Unit.Day.getInterval());
/*     */   }
/*     */   
/*     */   public void runTask(Runnable runnable) {
/*  90 */     this.executor.execute(runnable);
/*     */   }
/*     */   
/*     */   public void runMFEntryFileCheckoutAndCacheFileDeletionAction() {
/*  94 */     this.executor.execute(new MFEntryProcessingAction(this.manager, this.paManager));
/*     */   }
/*     */   
/*     */   public void runChunkNotLoadedAction(FileNotLoadedMFAction action) {
/*  98 */     this.executor.execute(action);
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 102 */     this.executor.shutdown();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MissingFileScheduler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */