/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class AuthorizationServerResponse
/*     */   extends AbstractAuthorizationServerResponse
/*     */ {
/*  11 */   private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationServerResponse.class);
/*     */   private String fastestAPIAndTicket;
/*     */   
/*     */   public AuthorizationServerResponse(AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode)
/*     */   {
/*  16 */     this.responseMessage = null;
/*  17 */     this.responseCode = authorizationServerResponseCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AuthorizationServerResponse(String responseMessage, AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode)
/*     */   {
/*  24 */     this.responseMessage = responseMessage;
/*  25 */     this.responseCode = authorizationServerResponseCode;
/*     */     
/*  27 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AuthorizationServerResponse(String responseMessage, int authorizationServerResponseCode)
/*     */   {
/*  34 */     this.responseMessage = responseMessage;
/*  35 */     this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.fromValue(authorizationServerResponseCode);
/*     */     
/*  37 */     init();
/*     */   }
/*     */   
/*     */   public boolean isEmptyResponse() {
/*  41 */     if ((isOK()) && (AuthorizationClient.AuthorizationServerResponseCode.EMPTY_RESPONSE == this.responseCode)) {
/*  42 */       return true;
/*     */     }
/*     */     
/*  45 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isTicketExpired() {
/*  49 */     if ((AuthorizationClient.AuthorizationServerResponseCode.TICKET_EXPIRED == this.responseCode) || (AuthorizationClient.AuthorizationServerResponseCode.MINUS_ONE_OLD_ERROR == this.responseCode))
/*     */     {
/*  51 */       return true;
/*     */     }
/*     */     
/*  54 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isSystemError() {
/*  58 */     if ((AuthorizationClient.AuthorizationServerResponseCode.SYSTEM_ERROR == this.responseCode) || (AuthorizationClient.AuthorizationServerResponseCode.SYSTEM_ERROR_OLD == this.responseCode))
/*     */     {
/*  60 */       return true;
/*     */     }
/*     */     
/*  63 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isWrongVersion() {
/*  67 */     if ((AuthorizationClient.AuthorizationServerResponseCode.WRONG_VERSION_RESPONSE == this.responseCode) || (AuthorizationClient.AuthorizationServerResponseCode.WRONG_VERSION_RESPONSE_OLD == this.responseCode))
/*     */     {
/*  69 */       return true;
/*     */     }
/*     */     
/*  72 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isNoAPIServers() {
/*  76 */     if ((AuthorizationClient.AuthorizationServerResponseCode.SERVICE_UNAVAILABLE == this.responseCode) || (AuthorizationClient.AuthorizationServerResponseCode.SERVICE_UNAVAILABLE_OLD == this.responseCode))
/*     */     {
/*     */ 
/*  79 */       return true;
/*     */     }
/*     */     
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   protected void validateResponse(String authorizationResponse)
/*     */   {
/*  87 */     if ((authorizationResponse == null) || (authorizationResponse.length() == 0)) {
/*  88 */       this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.EMPTY_RESPONSE;
/*     */     } else {
/*  90 */       Matcher matcher = AuthorizationClient.RESULT_PATTERN.matcher(authorizationResponse);
/*  91 */       if (!matcher.matches()) {
/*  92 */         LOGGER.error("Authorization procedure returned unexpected result [" + authorizationResponse + "]");
/*  93 */         this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFastestAPIAndTicket() {
/*  99 */     return this.fastestAPIAndTicket;
/*     */   }
/*     */   
/*     */   public void setFastestAPIAndTicket(String fastestAPIAndTicket) {
/* 103 */     this.fastestAPIAndTicket = null;
/*     */     try
/*     */     {
/* 106 */       if (fastestAPIAndTicket != null) {
/* 107 */         fastestAPIAndTicket = fastestAPIAndTicket.trim();
/*     */       }
/*     */       
/* 110 */       Matcher matcher = AuthorizationClient.RESULT_PATTERN.matcher(fastestAPIAndTicket);
/* 111 */       if (matcher.matches()) {
/* 112 */         this.fastestAPIAndTicket = fastestAPIAndTicket;
/*     */       } else {
/* 114 */         LOGGER.error("Wrong fastest API format:", fastestAPIAndTicket);
/*     */       }
/*     */     } catch (Throwable e) {
/* 117 */       LOGGER.error("Wrong fastest API format:");
/* 118 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\AuthorizationServerResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */