/*    */ package com.dukascopy.charts.data.datacache.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadingProgressListenerImpl
/*    */   implements ILoadingProgressListener
/*    */ {
/* 14 */   private boolean stopJob = false;
/* 15 */   private Throwable exception = null;
/*    */   
/*    */ 
/*    */ 
/*    */   public void dataLoaded(long start, long end, long currentPosition, String information) {}
/*    */   
/*    */ 
/*    */   public void loadingFinished(boolean allDataLoaded, long start, long end, long currentPosition, Throwable e)
/*    */   {
/* 24 */     this.exception = e;
/*    */   }
/*    */   
/*    */   public boolean stopJob()
/*    */   {
/* 29 */     return this.stopJob;
/*    */   }
/*    */   
/*    */   public void setStopJob(boolean stopJob) {
/* 33 */     this.stopJob = stopJob;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Throwable getException()
/*    */   {
/* 40 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\listener\LoadingProgressListenerImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */