/*    */ package com.dukascopy.api.impl.connect.plugin;
/*    */ 
/*    */ import com.dukascopy.api.Configurable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginConfigurer
/*    */ {
/*    */   @Configurable("Allow auto trading")
/* 12 */   public boolean allowAutoTrading = true;
/*    */   
/*    */   @Configurable("Activate plugin on platform startup")
/* 15 */   public boolean launchOnStartup = false;
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\plugin\PluginConfigurer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */