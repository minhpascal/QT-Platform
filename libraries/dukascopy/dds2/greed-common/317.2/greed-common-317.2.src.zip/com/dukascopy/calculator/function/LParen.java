/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LParen
/*    */   extends PObject
/*    */ {
/*    */   public LParen()
/*    */   {
/* 12 */     this.ftooltip = "sc.calculator.left.parenthesis.bracket";
/* 13 */     this.fshortcut = '(';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 17 */     return fname;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 21 */     PObject o = new LParen();
/* 22 */     StringBuilder s = new StringBuilder("<html>");
/* 23 */     s.append(o.name());
/* 24 */     s.append("</html>");
/* 25 */     JOptionPane.showMessageDialog(null, s.toString());
/*    */   }
/*    */   
/* 28 */   private static final String[] fname = { "(" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\LParen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */