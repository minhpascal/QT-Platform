/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.byshift;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.intraperiod.IIntraperiodBarsGenerator;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadClosestPriceRangeAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadToCachePriceRangeAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PANthPriceRangeFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PALoadByTimeIntervalPriceRangeAction;
/*     */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeCreator;
/*     */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PALoadByShiftPriceRange
/*     */   extends PAAbstractLoadByShift<PriceRangeData, IPriceRangeLiveFeedListener, IPriceRangeCreator, PALoadToCachePriceRangeAction, PALoadByTimeIntervalPriceRangeAction, PALoadClosestPriceRangeAction, PANthPriceRangeFromSeedBarAction>
/*     */ {
/*     */   public PALoadByShiftPriceRange(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int shift, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, IPriceRangeLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  53 */     super(cacheManager, instrument, interpolationDescriptor, side, jfPeriod, shift, fireUncompletedLastBasePeriodBars, infinitBasePeriod, version, listener, loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PriceRangeData getInProgressBar()
/*     */   {
/*  71 */     RangeBarFeedDescriptor descriptor = new RangeBarFeedDescriptor(getInstrument(), getJfPeriod().getPriceRange(), getSide(), getJfPeriod().getPeriod());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     return getCacheManager().getFeedDataProvider().getIntraperiodBarsGenerator().getOrLoadInProgressPriceRange(descriptor, getInterpolationDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PALoadClosestPriceRangeAction createLoadClosestAction(long currentTime, IPriceRangeLiveFeedListener lastCompletedBarListener)
/*     */     throws DataCacheException
/*     */   {
/*  88 */     PALoadClosestPriceRangeAction action = new PALoadClosestPriceRangeAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), currentTime, isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), lastCompletedBarListener, getLoadingProgressListener());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     return action;
/*     */   }
/*     */   
/*     */   protected IPriceRangeLiveFeedListener createLiveFeedListener(final List<PriceRangeData> result)
/*     */   {
/* 106 */     IPriceRangeLiveFeedListener listener = new IPriceRangeLiveFeedListener()
/*     */     {
/*     */       public void newPriceData(PriceRangeData PriceRange) {
/* 109 */         result.add(PriceRange);
/*     */       }
/* 111 */     };
/* 112 */     return listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PANthPriceRangeFromSeedBarAction createLoadNthAction(int numOfBarsBefore, PriceRangeData timedBar, int numOfBarsAfter, boolean lookLeft, IPriceRangeLiveFeedListener listener)
/*     */   {
/* 123 */     PANthPriceRangeFromSeedBarAction action = new PANthPriceRangeFromSeedBarAction(getCacheManager(), getVersion(), numOfBarsBefore, timedBar, numOfBarsAfter, getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), lookLeft, getLoadingProgressListener(), listener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     return action;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\byshift\PALoadByShiftPriceRange.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */