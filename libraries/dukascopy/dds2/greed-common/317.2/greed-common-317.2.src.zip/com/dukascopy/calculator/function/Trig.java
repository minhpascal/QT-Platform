/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.AngleType;
/*    */ 
/*    */ 
/*    */ public abstract class Trig
/*    */   extends RFunction
/*    */ {
/*    */   protected double scale;
/*    */   protected double iscale;
/*    */   protected AngleType angleType;
/*    */   
/*    */   public Trig(AngleType angleType)
/*    */   {
/* 15 */     setScale(angleType);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setScale(AngleType angleType)
/*    */   {
/* 23 */     switch (angleType) {
/*    */     case RADIANS: 
/* 25 */       this.scale = 1.0D;
/* 26 */       this.iscale = 1.0D;
/* 27 */       break;
/*    */     case DEGREES: 
/* 29 */       this.scale = 0.017453292519943295D;
/* 30 */       this.iscale = 57.29577951308232D;
/*    */     }
/*    */     
/* 33 */     this.angleType = angleType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final AngleType getAngleType()
/*    */   {
/* 41 */     return this.angleType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Trig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */