/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VJFStrategyWrapper
/*    */   extends StrategyWrapper
/*    */ {
/*    */   private String name;
/*    */   private String id;
/*    */   
/*    */   public VJFStrategyWrapper(String name)
/*    */   {
/* 20 */     this(null, name);
/*    */   }
/*    */   
/*    */   public VJFStrategyWrapper(String id, String name) {
/* 24 */     this.name = name;
/* 25 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 30 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 34 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 38 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String id) {
/* 42 */     this.id = id;
/*    */   }
/*    */   
/*    */   public File getSourceFile()
/*    */   {
/* 47 */     return null;
/*    */   }
/*    */   
/*    */   public String getOutputKey()
/*    */   {
/* 52 */     return this.id != null ? this.id : this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\VJFStrategyWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */