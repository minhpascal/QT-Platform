/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ import java.awt.event.ActionEvent;
/*    */ 
/*    */ public class InfoButton extends CalculatorButton
/*    */ {
/*    */   static final String version = "2:0.3";
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InfoButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 13 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 14 */     setPobject(new com.dukascopy.calculator.function.Info());
/*    */     
/* 16 */     int size = mainCalculatorPanel.minSize();
/* 17 */     if (size < 3) size = 3;
/* 18 */     if (size > 9) { size = 9;
/*    */     }
/*    */     
/*    */ 
/* 22 */     addActionListener(this);
/*    */     
/* 24 */     setShortcut(getPobject().shortcut());
/* 25 */     setToolTipKey(getPobject().tooltip());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent actionEvent)
/*    */   {
/* 35 */     if (getMainCalculatorPanel().getMode() != 0)
/* 36 */       return;
/* 37 */     javax.swing.JOptionPane.showMessageDialog(this.mainCalculatorPanel, "<html>Java Scientific Calculator 2:0.3, http://jscicalc.sourceforge.net/<br><br>Copyright &#169; 2004&#8211;5, 2007&#8211;8, John D Lamb &#60;J.D.Lamb@btinternet.com&#62;<br>This is free software; see the source for copying conditions.  There is NO warranty;<br>not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.</html>", "About", 1);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 56 */     getMainCalculatorPanel().requestFocusInWindow();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\InfoButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */