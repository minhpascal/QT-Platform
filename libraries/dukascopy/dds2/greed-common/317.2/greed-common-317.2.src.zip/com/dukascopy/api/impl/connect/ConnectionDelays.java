/*   */ package com.dukascopy.api.impl.connect;
/*   */ 
/*   */ import java.util.concurrent.TimeUnit;
/*   */ 
/*   */ public class ConnectionDelays {
/* 6 */   public static final long LONG_DELAY = TimeUnit.SECONDS.toMillis(60L);
/* 7 */   public static final long SHORT_DELAY = TimeUnit.SECONDS.toMillis(5L);
/*   */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ConnectionDelays.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */