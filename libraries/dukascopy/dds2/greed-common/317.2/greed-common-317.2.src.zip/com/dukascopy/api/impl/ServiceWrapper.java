/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.converter.ConverterManager;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceWrapper
/*    */ {
/* 11 */   private static int newFilesCounter = 1;
/*    */   
/*    */   protected int newFileIndex;
/*    */   protected boolean isNewUnsaved;
/* 15 */   protected boolean isModified = false;
/* 16 */   protected File srcFile = null;
/* 17 */   protected File binFile = null;
/*    */   protected byte[] sourceAsBytes;
/*    */   protected byte[] binaryAsBytes;
/*    */   
/*    */   public abstract String getName();
/*    */   
/*    */   public boolean isNewUnsaved() {
/* 24 */     return this.isNewUnsaved;
/*    */   }
/*    */   
/*    */   public void setNewUnsaved(boolean isNewUnsaved) {
/* 28 */     this.isNewUnsaved = isNewUnsaved;
/* 29 */     if (isNewUnsaved) {
/* 30 */       this.newFileIndex = (newFilesCounter++);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isModified() {
/* 35 */     return this.isModified;
/*    */   }
/*    */   
/*    */   public void setIsModified(boolean isModified) {
/* 39 */     this.isModified = isModified;
/*    */   }
/*    */   
/*    */   public boolean isEditable() {
/* 43 */     return (this.srcFile != null) && (this.srcFile.exists());
/*    */   }
/*    */   
/*    */   public boolean isRunnable() {
/* 47 */     return (getBinaryFile() != null) && (getBinaryFile().exists());
/*    */   }
/*    */   
/*    */   public boolean isRemotelyRunnable() {
/* 51 */     return false;
/*    */   }
/*    */   
/*    */   public final void setBinaryFile(File binaryFile) {
/* 55 */     this.binFile = binaryFile;
/*    */   }
/*    */   
/*    */   public final File getBinaryFile() {
/* 59 */     if ((this.srcFile != null) && (this.srcFile.exists())) {
/* 60 */       File file = null;
/*    */       
/*    */ 
/*    */ 
/* 64 */       if ((this.srcFile.getAbsolutePath().endsWith(".mq4")) || (this.srcFile.getAbsolutePath().endsWith(".mq5"))) {
/* 65 */         String javaClassName = ConverterManager.getJavaClassName(this.srcFile.getName().substring(0, this.srcFile.getName().lastIndexOf(".")));
/* 66 */         file = new File(this.srcFile.getParent() + File.separator + javaClassName + ".jfx");
/*    */       } else {
/* 68 */         file = new File(this.srcFile.getParent(), this.srcFile.getName().substring(0, this.srcFile.getName().lastIndexOf('.')) + ".jfx");
/*    */       }
/* 70 */       if (file.exists()) {
/* 71 */         this.binFile = file;
/*    */       }
/*    */     }
/* 74 */     return this.binFile;
/*    */   }
/*    */   
/*    */   public final void setSourceFile(File sourceFile) {
/* 78 */     this.srcFile = sourceFile;
/*    */   }
/*    */   
/*    */   public File getSourceFile() {
/* 82 */     return this.srcFile;
/*    */   }
/*    */   
/*    */   public byte[] getSourceAsBytes() {
/* 86 */     return this.sourceAsBytes;
/*    */   }
/*    */   
/*    */   public void setSourceAsBytes(byte[] sourceAsBytes) {
/* 90 */     this.sourceAsBytes = sourceAsBytes;
/*    */   }
/*    */   
/*    */   public byte[] getBinaryAsBytes() {
/* 94 */     return this.binaryAsBytes;
/*    */   }
/*    */   
/*    */   public void setBinaryAsBytes(byte[] binaryAsBytes) {
/* 98 */     this.binaryAsBytes = binaryAsBytes;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\ServiceWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */