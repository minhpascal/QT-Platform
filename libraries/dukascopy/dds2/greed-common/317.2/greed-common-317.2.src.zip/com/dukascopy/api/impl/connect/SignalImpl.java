/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IOrder;
/*    */ import com.dukascopy.api.ISignal.Type;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SignalImpl implements com.dukascopy.api.ISignal
/*    */ {
/*    */   private final IOrder order;
/*    */   private final ISignal.Type type;
/*    */   private final List<IOrder> oldOrders;
/*    */   
/*    */   public SignalImpl(IOrder order, ISignal.Type type)
/*    */   {
/* 15 */     this.order = order;
/* 16 */     this.type = type;
/* 17 */     this.oldOrders = null;
/*    */   }
/*    */   
/*    */   public SignalImpl(IOrder order, ISignal.Type type, List<IOrder> oldOrders) {
/* 21 */     this.order = order;
/* 22 */     this.type = type;
/* 23 */     this.oldOrders = oldOrders;
/*    */   }
/*    */   
/*    */   public IOrder getOrder()
/*    */   {
/* 28 */     return this.order;
/*    */   }
/*    */   
/*    */   public List<IOrder> getOldOrders()
/*    */   {
/* 33 */     return this.oldOrders;
/*    */   }
/*    */   
/*    */   public ISignal.Type getType()
/*    */   {
/* 38 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\SignalImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */