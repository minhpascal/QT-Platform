/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log
/*    */   extends RFunction
/*    */ {
/*    */   public Log()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.base.10.logarithm";
/* 15 */     this.fshortcut = 'l';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 24 */     return Math.log(x) / Math.log(10.0D);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 33 */     return x.log10();
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 37 */     return fname;
/*    */   }
/*    */   
/* 40 */   private static final String[] fname = { "l", "o", "g", " " };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Log.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */