/*     */ package com.dukascopy.charts.data.datacache.ccheck;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.SimpleFileVisitor;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MFFileVisitor
/*     */   extends SimpleFileVisitor<Path>
/*     */ {
/*  32 */   private static final Logger LOGGER = LoggerFactory.getLogger(MFFileVisitor.class);
/*     */   
/*  34 */   private static Pattern ticksPattern = Pattern.compile("^\\d\\dh_ticks.bi\\d+?$");
/*  35 */   private static Pattern minPattern = Pattern.compile("^((ASK)|(BID))_candles_min_\\d.bi\\d+?$");
/*  36 */   private static Pattern hourPattern = Pattern.compile("^((ASK)|(BID))_candles_hour_\\d.bi\\d+?$");
/*  37 */   private static Pattern dayPattern = Pattern.compile("^((ASK)|(BID))_candles_day_\\d.bi\\d+?$");
/*  38 */   private static Pattern intraperiodFolderPattern = Pattern.compile("^intraperiod\\d*+$");
/*     */   
/*     */   private IFilterManager filterManager;
/*  41 */   private int instrumentDirLevel = -1;
/*     */   private Map<Period, IMFEntryListener> listeners;
/*     */   
/*     */   public MFFileVisitor(IFilterManager filterManager, Map<Period, IMFEntryListener> listeners)
/*     */   {
/*  46 */     this.filterManager = filterManager;
/*  47 */     this.listeners = listeners;
/*     */   }
/*     */   
/*     */ 
/*     */   public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
/*     */     throws IOException
/*     */   {
/*  54 */     if (this.instrumentDirLevel == -1) {
/*  55 */       this.instrumentDirLevel = getInstrumentDirLevel(dir);
/*     */     }
/*     */     
/*  58 */     if (("pacache".equals(dir.toFile().getName())) || (intraperiodFolderPattern.matcher(dir.toFile().getName()).matches()))
/*     */     {
/*     */ 
/*  61 */       return FileVisitResult.SKIP_SUBTREE;
/*     */     }
/*     */     
/*  64 */     return FileVisitResult.CONTINUE;
/*     */   }
/*     */   
/*     */ 
/*     */   public FileVisitResult visitFile(Path file, BasicFileAttributes attr)
/*     */   {
/*     */     try
/*     */     {
/*  72 */       if ((matches(file)) && (attr.size() == 0L)) {
/*  73 */         Period period = getPeriodFromFilename(file.toFile().getName());
/*     */         
/*  75 */         long chunkStartTime = DataCacheUtils.getChunkFileStartTime(file, period);
/*     */         
/*  77 */         long expectedChunkStartTime = DataCacheUtils.getChunkStartFast(period, chunkStartTime);
/*  78 */         if (expectedChunkStartTime != chunkStartTime) {
/*  79 */           throw new DataCacheException("Chunk start time is not correct! Expected [" + DateUtils.format(expectedChunkStartTime) + " / " + expectedChunkStartTime + "], but was [" + DateUtils.format(chunkStartTime) + " / " + chunkStartTime + "]");
/*     */         }
/*     */         
/*     */ 
/*  83 */         if ((!Period.TICK.equals(period)) || (!this.filterManager.isWeekendTime(chunkStartTime, period))) {
/*  84 */           Instrument instrument = extractInstrumentFromFilePath(file);
/*  85 */           if (instrument == null) {
/*  86 */             throw new DataCacheException("Couldn't extract instrument from chunk file path! File path [" + file + "], instrument directory level [" + this.instrumentDirLevel + "]");
/*     */           }
/*     */           
/*  89 */           OfferSide side = null;
/*  90 */           if (!Period.TICK.equals(period)) {
/*  91 */             side = extractOfferSideFromFilePath(file);
/*  92 */             if (side == null) {
/*  93 */               throw new DataCacheException("Couldn't extract offer side from chunk file path! File path [" + file + "]");
/*     */             }
/*     */           }
/*     */           
/*  97 */           MFEntry entry = new MFEntry(chunkStartTime, instrument, side);
/*  98 */           ((IMFEntryListener)this.listeners.get(period)).newEntry(entry);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (DataCacheException e) {
/* 103 */       LOGGER.error(e.getMessage(), e);
/* 104 */       return FileVisitResult.TERMINATE;
/*     */     }
/*     */     
/* 107 */     return FileVisitResult.CONTINUE;
/*     */   }
/*     */   
/*     */ 
/*     */   private OfferSide extractOfferSideFromFilePath(Path file)
/*     */   {
/* 113 */     if (OfferSide.ASK.toString().equalsIgnoreCase(file.toFile().getName().substring(0, 3))) {
/* 114 */       return OfferSide.ASK;
/*     */     }
/* 116 */     if (OfferSide.BID.toString().equalsIgnoreCase(file.toFile().getName().substring(0, 3))) {
/* 117 */       return OfferSide.BID;
/*     */     }
/*     */     
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   public Instrument extractInstrumentFromFilePath(Path filePath)
/*     */   {
/* 125 */     int numOfElements = filePath.getNameCount();
/*     */     
/* 127 */     if (this.instrumentDirLevel < 0) {
/* 128 */       this.instrumentDirLevel = getInstrumentDirLevel(filePath);
/*     */     }
/*     */     
/* 131 */     if (numOfElements >= this.instrumentDirLevel) {
/* 132 */       String instrName = filePath.getName(this.instrumentDirLevel).toFile().getName();
/* 133 */       Instrument instrument = isInstrumentDir(instrName);
/*     */       
/* 135 */       if (instrument == null) {
/* 136 */         LOGGER.warn("Couldn't extract Instrument from file path! File path [" + filePath + "]");
/*     */       }
/* 138 */       return instrument;
/*     */     }
/*     */     
/* 141 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private int getInstrumentDirLevel(Path dir)
/*     */   {
/* 147 */     int numOfElements = dir.getNameCount();
/*     */     
/* 149 */     for (int x = 0; x < numOfElements; x++) {
/* 150 */       Path fileName = dir.getName(x);
/* 151 */       if (isInstrumentDir(fileName.toFile().getName()) != null) {
/* 152 */         return x;
/*     */       }
/*     */     }
/*     */     
/* 156 */     return -1;
/*     */   }
/*     */   
/*     */   private Instrument isInstrumentDir(String dirName)
/*     */   {
/* 161 */     for (Instrument value : ) {
/* 162 */       if (value.name().equalsIgnoreCase(dirName)) {
/* 163 */         return value;
/*     */       }
/*     */     }
/* 166 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public FileVisitResult visitFileFailed(Path file, IOException e)
/*     */   {
/* 172 */     LOGGER.error("File path [" + file + "], " + e.getMessage(), e);
/* 173 */     return FileVisitResult.CONTINUE;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean matches(Path file)
/*     */   {
/* 179 */     String filename = file.toFile().getName();
/*     */     
/* 181 */     if ((ticksPattern.matcher(filename).matches()) || (minPattern.matcher(filename).matches()) || (hourPattern.matcher(filename).matches()) || (dayPattern.matcher(filename).matches()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */       return true;
/*     */     }
/* 189 */     return false;
/*     */   }
/*     */   
/*     */   private Period getPeriodFromFilename(String filename)
/*     */   {
/* 194 */     if (ticksPattern.matcher(filename).matches()) {
/* 195 */       return Period.TICK;
/*     */     }
/* 197 */     if (minPattern.matcher(filename).matches()) {
/* 198 */       return Period.ONE_MIN;
/*     */     }
/* 200 */     if (hourPattern.matcher(filename).matches()) {
/* 201 */       return Period.ONE_HOUR;
/*     */     }
/* 203 */     if (dayPattern.matcher(filename).matches()) {
/* 204 */       return Period.DAILY;
/*     */     }
/* 206 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFFileVisitor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */