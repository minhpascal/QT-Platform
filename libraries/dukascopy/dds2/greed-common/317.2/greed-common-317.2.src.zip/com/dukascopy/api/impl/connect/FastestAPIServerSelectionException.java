/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ public class FastestAPIServerSelectionException extends Exception
/*    */ {
/*    */   public FastestAPIServerSelectionException(String message) {
/*  6 */     super(message);
/*    */   }
/*    */   
/*    */   public FastestAPIServerSelectionException(Throwable cause) {
/* 10 */     super(cause);
/*    */   }
/*    */   
/*    */   public FastestAPIServerSelectionException(String message, Throwable cause) {
/* 14 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\FastestAPIServerSelectionException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */