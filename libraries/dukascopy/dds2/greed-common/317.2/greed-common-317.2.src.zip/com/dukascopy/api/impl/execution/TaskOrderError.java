/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IMessage;
/*    */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.impl.connect.PlatformOrderImpl;
/*    */ import com.dukascopy.api.plugins.IMessageListener;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*    */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*    */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*    */ import com.dukascopy.dds4.transport.msg.system.ErrorResponseMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskOrderError
/*    */   implements Task
/*    */ {
/* 24 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskOrderError.class);
/*    */   private IMessageListener strategy;
/*    */   private ErrorResponseMessage errorResponseMessage;
/*    */   private PlatformOrderImpl order;
/*    */   private IStrategyExceptionHandler exceptionHandler;
/*    */   private JForexTaskManager taskManager;
/*    */   private StrategyEventsCallback strategyEventsCallback;
/*    */   
/*    */   public TaskOrderError(JForexTaskManager taskManager, IMessageListener strategy, ErrorResponseMessage errorResponseMessage, PlatformOrderImpl order, IStrategyExceptionHandler exceptionHandler)
/*    */   {
/* 34 */     this.strategy = strategy;
/* 35 */     this.errorResponseMessage = errorResponseMessage;
/* 36 */     this.order = order;
/* 37 */     this.exceptionHandler = exceptionHandler;
/* 38 */     this.taskManager = taskManager;
/* 39 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 44 */     return Task.Type.MESSAGE;
/*    */   }
/*    */   
/*    */   public Object call() throws Exception
/*    */   {
/* 49 */     if (this.taskManager.isStrategyStopping()) {
/* 50 */       return null;
/*    */     }
/* 52 */     if (LOGGER.isDebugEnabled()) {
/* 53 */       LOGGER.debug("Starting order [" + this.order.getLabel() + "] update process, error response message [" + this.errorResponseMessage + "]");
/*    */     }
/*    */     try {
/* 56 */       IMessage platformMessageImpl = this.order.update(this.errorResponseMessage);
/*    */       
/* 58 */       if (platformMessageImpl != null) {
/* 59 */         this.strategy.onMessage(platformMessageImpl);
/* 60 */         if (this.strategyEventsCallback != null) {
/* 61 */           this.strategyEventsCallback.onMessage(platformMessageImpl);
/*    */         }
/*    */       }
/*    */     } catch (Throwable t) {
/* 65 */       String msg = ErrorHelper.representError(this.strategy, t);
/* 66 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 67 */       LOGGER.error(t.getMessage(), t);
/* 68 */       this.exceptionHandler.onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_MESSAGE, t);
/*    */     }
/* 70 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskOrderError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */