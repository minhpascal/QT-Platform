/*    */ package com.dukascopy.api.impl.util;
/*    */ 
/*    */ import com.dukascopy.json.JSONObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransportUserAgent
/*    */ {
/*    */   private String clientType;
/*    */   private String clientVersion;
/*    */   private String javaVersion;
/*    */   private String jvmVersion;
/*    */   private String osName;
/*    */   private String ip;
/*    */   private String userName;
/*    */   
/*    */   public String getClientVersion()
/*    */   {
/* 23 */     return this.clientVersion;
/*    */   }
/*    */   
/* 26 */   public void setClientVersion(String clientVersion) { this.clientVersion = clientVersion; }
/*    */   
/*    */   public String getJavaVersion() {
/* 29 */     return this.javaVersion;
/*    */   }
/*    */   
/* 32 */   public void setJavaVersion(String javaVersion) { this.javaVersion = javaVersion; }
/*    */   
/*    */   public String getJvmVersion() {
/* 35 */     return this.jvmVersion;
/*    */   }
/*    */   
/* 38 */   public void setJvmVersion(String jvmVersion) { this.jvmVersion = jvmVersion; }
/*    */   
/*    */   public String getOsName() {
/* 41 */     return this.osName;
/*    */   }
/*    */   
/* 44 */   public void setOsName(String osName) { this.osName = osName; }
/*    */   
/*    */   public String getIp() {
/* 47 */     return this.ip;
/*    */   }
/*    */   
/* 50 */   public void setIp(String ip) { this.ip = ip; }
/*    */   
/*    */   public String getUserName() {
/* 53 */     return this.userName;
/*    */   }
/*    */   
/* 56 */   public void setUserName(String userName) { this.userName = userName; }
/*    */   
/*    */   public String getClientType() {
/* 59 */     return this.clientType;
/*    */   }
/*    */   
/* 62 */   public void setClientType(String clientType) { this.clientType = clientType; }
/*    */   
/*    */   public String toJsonString()
/*    */   {
/* 66 */     JSONObject json = new JSONObject(false);
/* 67 */     json.put("clientVersion", this.clientVersion);
/* 68 */     json.put("javaVersion", this.javaVersion);
/* 69 */     json.put("jvmVersion", this.jvmVersion);
/* 70 */     json.put("osName", this.osName);
/* 71 */     json.put("ip", this.ip);
/* 72 */     json.put("userName", this.userName);
/* 73 */     json.put("clientType", this.clientType);
/* 74 */     return json.toString();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 78 */     StringBuilder builder = new StringBuilder();
/* 79 */     builder.append("TransportUserAgent [clientType=");
/* 80 */     builder.append(this.clientType);
/* 81 */     builder.append(", clientVersion=");
/* 82 */     builder.append(this.clientVersion);
/* 83 */     builder.append(", javaVersion=");
/* 84 */     builder.append(this.javaVersion);
/* 85 */     builder.append(", jvmVersion=");
/* 86 */     builder.append(this.jvmVersion);
/* 87 */     builder.append(", osName=");
/* 88 */     builder.append(this.osName);
/* 89 */     builder.append(", ip=");
/* 90 */     builder.append(this.ip);
/* 91 */     builder.append(", userName=");
/* 92 */     builder.append(this.userName);
/* 93 */     builder.append("]");
/* 94 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\TransportUserAgent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */