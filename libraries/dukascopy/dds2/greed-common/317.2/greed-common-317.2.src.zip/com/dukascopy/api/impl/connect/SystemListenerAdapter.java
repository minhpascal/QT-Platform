/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemListenerAdapter
/*    */   implements ISystemListenerExtended
/*    */ {
/*    */   public void onStart(long processId) {}
/*    */   
/*    */   public void onStop(long processId) {}
/*    */   
/*    */   public void onConnect() {}
/*    */   
/*    */   public void onDisconnect() {}
/*    */   
/*    */   public void subscribeToInstruments(Set<Instrument> instruments, boolean lock) {}
/*    */   
/*    */   public Set<Instrument> getSubscribedInstruments()
/*    */   {
/* 48 */     return new HashSet(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\SystemListenerAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */