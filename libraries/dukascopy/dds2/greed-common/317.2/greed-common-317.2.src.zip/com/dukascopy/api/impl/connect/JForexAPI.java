/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IEngine.OrderCommand;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.impl.CloseOrder;
/*     */ import com.dukascopy.api.impl.FillOrder;
/*     */ import com.dukascopy.api.impl.PartialOrder;
/*     */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.OrderHistoricalData.PartialData;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.MathConstants;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*     */ import com.dukascopy.dds3.transport.msg.types.OrderDirection;
/*     */ import com.dukascopy.dds3.transport.msg.types.OrderSide;
/*     */ import com.dukascopy.dds3.transport.msg.types.OrderState;
/*     */ import com.dukascopy.dds3.transport.msg.types.StopDirection;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JForexAPI
/*     */ {
/*     */   public static OrderMessage modifyAmount(JForexTaskManager taskManager, Instrument instrument, String externalSysId, String groupId, String orderId, double amount, boolean isLong)
/*     */   {
/*  41 */     return createUpdateOrderMessage(taskManager, instrument, externalSysId, groupId, orderId, amount, isLong);
/*     */   }
/*     */   
/*     */   public static OrderMessage modifyLabel(JForexTaskManager taskManager, Instrument instrument, String newLabel, String groupId, String orderId, double amount, boolean isLong) {
/*  45 */     return createUpdateOrderMessage(taskManager, instrument, newLabel, groupId, orderId, amount, isLong);
/*     */   }
/*     */   
/*     */ 
/*     */   public static OrderMessage cancelOrder(JForexTaskManager taskManager, String externalSysId, Instrument instrument, String groupId, String orderId, String parentOrderId)
/*     */   {
/*  51 */     if ((ObjectUtils.isNullOrEmpty(groupId)) || ((ObjectUtils.isNullOrEmpty(orderId)) && (ObjectUtils.isNullOrEmpty(parentOrderId))) || (ObjectUtils.isNullOrEmpty(externalSysId)) || (ObjectUtils.isNullOrEmpty(instrument)))
/*     */     {
/*  53 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  56 */     OrderMessageExt order = new OrderMessageExt();
/*  57 */     order.setParentOrderId(parentOrderId);
/*  58 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, OrderState.CANCELLED, order);
/*     */   }
/*     */   
/*     */ 
/*     */   public static OrderMessage modifyPrice(JForexTaskManager taskManager, String externalSysId, Instrument instrument, String groupId, String orderId, double price, double amount, OrderDirection orderDirection, StopDirection stopDirection, boolean isLong)
/*     */   {
/*  64 */     OrderMessageExt order = new OrderMessageExt();
/*  65 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, price, amount, orderDirection, stopDirection, isLong ? OrderSide.BUY : OrderSide.SELL, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static OrderMessage modifyTakeProfit(JForexTaskManager taskManager, String externalSysId, Instrument instrument, String groupId, String orderId, boolean isParentOrderLong, double price, double amount)
/*     */   {
/*  72 */     OrderMessageExt order = new OrderMessageExt();
/*     */     StopDirection stopDirection;
/*  74 */     StopDirection stopDirection; if (isParentOrderLong) {
/*  75 */       stopDirection = StopDirection.GREATER_BID;
/*     */     } else {
/*  77 */       stopDirection = StopDirection.LESS_ASK;
/*     */     }
/*  79 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, price, amount, OrderDirection.CLOSE, stopDirection, isParentOrderLong ? OrderSide.SELL : OrderSide.BUY, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static OrderMessage modifyStopLoss(JForexTaskManager taskManager, String externalSysId, Instrument instrument, String groupId, String orderId, boolean isParentOrderLong, double price, double amount, OfferSide side, double trailingPriceAbsolute)
/*     */   {
/*  86 */     OrderMessageExt order = new OrderMessageExt();
/*     */     StopDirection stopDirection;
/*  88 */     StopDirection stopDirection; if (isParentOrderLong) { StopDirection stopDirection;
/*  89 */       if ((side == null) || (side == OfferSide.BID)) {
/*  90 */         stopDirection = StopDirection.LESS_BID;
/*     */       } else
/*  92 */         stopDirection = StopDirection.LESS_ASK;
/*     */     } else {
/*     */       StopDirection stopDirection;
/*  95 */       if ((side == null) || (side == OfferSide.ASK)) {
/*  96 */         stopDirection = StopDirection.GREATER_ASK;
/*     */       } else {
/*  98 */         stopDirection = StopDirection.GREATER_BID;
/*     */       }
/*     */     }
/* 101 */     order.setPriceLimit(BigDecimal.valueOf(trailingPriceAbsolute));
/*     */     
/*     */ 
/* 104 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, price, amount, OrderDirection.CLOSE, stopDirection, isParentOrderLong ? OrderSide.SELL : OrderSide.BUY, order);
/*     */   }
/*     */   
/*     */ 
/*     */   public static OrderMessage modifyBidOfferPrice(JForexTaskManager taskManager, Instrument instrument, String externalSysId, String groupId, String orderId, double price, double amount, boolean isLong)
/*     */   {
/* 110 */     OrderMessageExt order = new OrderMessageExt();
/* 111 */     order.setPriceClient(BigDecimal.valueOf(price));
/* 112 */     order.setPlaceOffer(true);
/*     */     
/*     */ 
/* 115 */     return setGeneralData(taskManager, instrument, externalSysId, groupId, orderId, amount, isLong ? OrderSide.BUY : OrderSide.SELL, order);
/*     */   }
/*     */   
/*     */ 
/*     */   public static OrderMessageExt createStopLoss(JForexTaskManager taskManager, String externalSysId, String groupId, String openingOrderId, Instrument instrument, double price, double amount, double trailingPriceAbsolute, boolean isParentOrderLong, OfferSide stopLossSide)
/*     */   {
/*     */     StopDirection stopDirection;
/*     */     
/*     */     StopDirection stopDirection;
/*     */     
/* 125 */     if (isParentOrderLong) { StopDirection stopDirection;
/* 126 */       if ((stopLossSide == null) || (stopLossSide == OfferSide.BID)) {
/* 127 */         stopDirection = StopDirection.LESS_BID;
/*     */       } else
/* 129 */         stopDirection = StopDirection.LESS_ASK;
/*     */     } else {
/*     */       StopDirection stopDirection;
/* 132 */       if ((stopLossSide == null) || (stopLossSide == OfferSide.ASK)) {
/* 133 */         stopDirection = StopDirection.GREATER_ASK;
/*     */       } else {
/* 135 */         stopDirection = StopDirection.GREATER_BID;
/*     */       }
/*     */     }
/* 138 */     OrderSide slSide = isParentOrderLong ? OrderSide.SELL : OrderSide.BUY;
/* 139 */     OrderMessageExt order = createSLTPBase(taskManager, externalSysId, groupId, openingOrderId, instrument, price, amount, slSide, stopDirection);
/*     */     
/* 141 */     if (trailingPriceAbsolute > 0.0D) {
/* 142 */       order.setPriceLimit(BigDecimal.valueOf(trailingPriceAbsolute));
/*     */     }
/* 144 */     return order;
/*     */   }
/*     */   
/*     */   public static OrderMessageExt modifyGTT(JForexTaskManager taskManager, Instrument instrument, OrderState state, String externalSysId, double amount, String groupId, String orderId, long goodTilltime, boolean isLong)
/*     */   {
/* 149 */     OrderMessageExt order = new OrderMessageExt();
/*     */     
/*     */ 
/* 152 */     if (-1L != goodTilltime) {
/* 153 */       order.setExecTimeoutMillis(Long.valueOf(goodTilltime));
/*     */     } else {
/* 155 */       order.setExecTimeoutMillis(Long.valueOf(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(36500L)));
/*     */     }
/* 157 */     order = setGeneralData(amount, OrderDirection.OPEN, isLong ? OrderSide.BUY : OrderSide.SELL, order);
/* 158 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, state, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static OrderMessageExt closePosition(JForexTaskManager taskManager, IEngine.OrderCommand openOrderCommand, Instrument instrument, String orderGroupId, String label, double amount, double price, double slippage)
/*     */   {
/* 165 */     OrderSide closeSide = openOrderCommand.isLong() ? OrderSide.SELL : OrderSide.BUY;
/* 166 */     OrderMessageExt order = new OrderMessageExt();
/* 167 */     order.setOrderGroupId(orderGroupId);
/* 168 */     order.setState(OrderState.CREATED);
/* 169 */     if (price > 0.0D) {
/* 170 */       order.setPriceClient(BigDecimal.valueOf(price));
/*     */     } else {
/* 172 */       order.setPriceClient(null);
/*     */     }
/*     */     
/* 175 */     if (slippage >= 0.0D) {
/* 176 */       order.setPriceTrailingLimit(BigDecimal.valueOf(slippage));
/*     */     } else {
/* 178 */       order.setPriceTrailingLimit(null);
/*     */     }
/* 180 */     order = setGeneralData(amount, OrderDirection.CLOSE, closeSide, order);
/* 181 */     order = setGeneralData(label, instrument, order);
/* 182 */     return setManagerData(taskManager, order);
/*     */   }
/*     */   
/*     */ 
/*     */   public static OrderGroupMessage massClose(List<OrderMessageExt> closingOrders)
/*     */   {
/* 188 */     OrderGroupMessage massCloseGroup = new OrderGroupMessage();
/* 189 */     massCloseGroup.setOrders(closingOrders);
/* 190 */     String id = StratUtils.generateLabel();
/* 191 */     massCloseGroup.setExternalSysId(id);
/* 192 */     return massCloseGroup;
/*     */   }
/*     */   
/*     */   public static MergePositionsMessage merge(JForexTaskManager taskManager, String externalSysId, Set<String> mergedGroupsIDs) {
/* 196 */     MergePositionsMessage mergeResult = new MergePositionsMessage();
/* 197 */     mergeResult.setPositionList(mergedGroupsIDs);
/* 198 */     mergeResult.setExternalSysId(externalSysId);
/* 199 */     mergeResult.setStrategyId(taskManager.getStrategyKey());
/* 200 */     return mergeResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static OrderGroupMessage placeBidOffer(JForexTaskManager taskManager, String externalSysId, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double stopLossPrice, double takeProfitPrice, long goodTillTime, String comment)
/*     */   {
/* 207 */     OrderGroupMessage orderGroup = createGroup(externalSysId, instrument);
/* 208 */     OrderMessageExt openingOrder = createOpeningOrder(taskManager, externalSysId, instrument, orderCommand, amount, price, -1.0D, goodTillTime, comment);
/*     */     
/* 210 */     openingOrder.setPlaceOffer(true);
/*     */     
/* 212 */     List<OrderMessageExt> orders = new ArrayList();
/* 213 */     orders.add(openingOrder);
/*     */     
/* 215 */     if (stopLossPrice > 0.0D)
/*     */     {
/* 217 */       OrderMessageExt slOrder = createStopLoss(taskManager, externalSysId, null, null, instrument, stopLossPrice, amount, 0.0D, orderCommand.isLong(), null);
/* 218 */       orders.add(slOrder);
/*     */     }
/* 220 */     if (takeProfitPrice > 0.0D)
/*     */     {
/* 222 */       OrderMessageExt tpOrder = createTakeProfit(taskManager, externalSysId, null, null, instrument, takeProfitPrice, amount, orderCommand.isLong());
/* 223 */       orders.add(tpOrder);
/*     */     }
/*     */     
/* 226 */     orderGroup.setOrders(orders);
/* 227 */     return orderGroup;
/*     */   }
/*     */   
/*     */ 
/*     */   public static OrderMessageExt createTakeProfit(JForexTaskManager taskManager, String externalSysId, String groupId, String openingOrderId, Instrument instrument, double price, double amount, boolean isParentOrderlong)
/*     */   {
/*     */     StopDirection stopDirection;
/*     */     
/*     */     StopDirection stopDirection;
/* 236 */     if (isParentOrderlong) {
/* 237 */       stopDirection = StopDirection.GREATER_BID;
/*     */     } else {
/* 239 */       stopDirection = StopDirection.LESS_ASK;
/*     */     }
/* 241 */     OrderSide tpSide = isParentOrderlong ? OrderSide.SELL : OrderSide.BUY;
/* 242 */     OrderMessageExt closingOrder = createSLTPBase(taskManager, externalSysId, groupId, openingOrderId, instrument, price, amount, tpSide, stopDirection);
/*     */     
/* 244 */     closingOrder.setPriceTrailingLimit(BigDecimal.ZERO);
/* 245 */     return closingOrder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt createSLTPBase(JForexTaskManager taskManager, String externalSysId, String groupId, String openingOrderId, Instrument instrument, double price, double amount, OrderSide orderSide, StopDirection stopDirection)
/*     */   {
/* 252 */     OrderMessageExt order = new OrderMessageExt();
/* 253 */     if (groupId != null) {
/* 254 */       order.setOrderGroupId(groupId);
/*     */     }
/* 256 */     if (openingOrderId != null) {
/* 257 */       order.setIfdParentOrderId(openingOrderId);
/*     */     }
/* 259 */     order.setState(OrderState.CREATED);
/* 260 */     order = setGeneralData(price, amount, OrderDirection.CLOSE, stopDirection, orderSide, order);
/* 261 */     order = setGeneralData(externalSysId, instrument, order);
/* 262 */     return setManagerData(taskManager, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OrderGroupMessage submitOrder(JForexTaskManager taskManager, String externalSysId, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice, long goodTillTime, String comment)
/*     */   {
/* 272 */     OrderGroupMessage orderGroup = createGroup(externalSysId, instrument);
/*     */     
/* 274 */     OrderMessageExt openingOrder = createOpeningOrder(taskManager, externalSysId, instrument, orderCommand, amount, price, slippage, goodTillTime, comment);
/*     */     
/*     */ 
/* 277 */     StopDirection stopDirection = getStopDirection(orderCommand);
/* 278 */     if (stopDirection != null) {
/* 279 */       openingOrder.setPriceStop(BigDecimal.valueOf(price));
/* 280 */       openingOrder.setStopDirection(stopDirection);
/*     */     }
/*     */     
/* 283 */     List<OrderMessageExt> orders = new ArrayList();
/*     */     
/* 285 */     orders.add(openingOrder);
/*     */     
/* 287 */     if (stopLossPrice > 0.0D)
/*     */     {
/* 289 */       OrderMessageExt slOrder = createStopLoss(taskManager, externalSysId, null, null, instrument, stopLossPrice, amount, 0.0D, orderCommand.isLong(), null);
/*     */       
/* 291 */       orders.add(slOrder);
/*     */     }
/* 293 */     if (takeProfitPrice > 0.0D)
/*     */     {
/* 295 */       OrderMessageExt tpOrder = createTakeProfit(taskManager, externalSysId, null, null, instrument, takeProfitPrice, amount, orderCommand.isLong());
/*     */       
/* 297 */       orders.add(tpOrder);
/*     */     }
/* 299 */     orderGroup.setOrders(orders);
/* 300 */     return orderGroup;
/*     */   }
/*     */   
/*     */   public static StopDirection getStopDirection(IEngine.OrderCommand orderCommand) {
/* 304 */     switch (orderCommand) {
/*     */     case BUYLIMIT: 
/* 306 */       return StopDirection.LESS_ASK;
/*     */     case BUYLIMIT_BYBID: 
/* 308 */       return StopDirection.LESS_BID;
/*     */     case BUYSTOP: 
/* 310 */       return StopDirection.GREATER_ASK;
/*     */     case BUYSTOP_BYBID: 
/* 312 */       return StopDirection.GREATER_BID;
/*     */     case SELLLIMIT: 
/* 314 */       return StopDirection.GREATER_BID;
/*     */     case SELLLIMIT_BYASK: 
/* 316 */       return StopDirection.GREATER_ASK;
/*     */     case SELLSTOP: 
/* 318 */       return StopDirection.LESS_BID;
/*     */     case SELLSTOP_BYASK: 
/* 320 */       return StopDirection.LESS_ASK;
/*     */     }
/* 322 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isMarket(IEngine.OrderCommand orderCommand)
/*     */   {
/* 328 */     return (ObjectUtils.isEqual(orderCommand, IEngine.OrderCommand.BUY)) || (ObjectUtils.isEqual(orderCommand, IEngine.OrderCommand.SELL));
/*     */   }
/*     */   
/*     */   public static boolean isPlaceBidOffer(IEngine.OrderCommand orderCommand) {
/* 332 */     return (ObjectUtils.isEqual(orderCommand, IEngine.OrderCommand.PLACE_BID)) || (ObjectUtils.isEqual(orderCommand, IEngine.OrderCommand.PLACE_OFFER));
/*     */   }
/*     */   
/*     */   public static boolean isLimit(IEngine.OrderCommand orderCommand) {
/* 336 */     return (!isMarket(orderCommand)) && (!isPlaceBidOffer(orderCommand));
/*     */   }
/*     */   
/*     */   public static <T extends OrderHistoricalData.PartialData> List<CloseOrder> getCloseOrders(Collection<T> historyData) {
/* 340 */     List<CloseOrder> closeOrders = new ArrayList();
/* 341 */     Set<PartialOrder> partialOrders = getPartialOrders(historyData);
/* 342 */     if (!ObjectUtils.isNullOrEmpty(partialOrders)) {
/* 343 */       for (PartialOrder partialOrder : partialOrders) {
/* 344 */         closeOrders.add(new CloseOrder(partialOrder));
/*     */       }
/*     */     }
/* 347 */     return closeOrders;
/*     */   }
/*     */   
/*     */   public static <T extends OrderHistoricalData.PartialData> List<FillOrder> getFillOrders(Collection<T> historyData) {
/* 351 */     List<FillOrder> fillOrders = new ArrayList();
/* 352 */     Set<PartialOrder> partialOrders = getPartialOrders(historyData);
/* 353 */     if (!ObjectUtils.isNullOrEmpty(partialOrders)) {
/* 354 */       for (PartialOrder partialOrder : partialOrders) {
/* 355 */         fillOrders.add(new FillOrder(partialOrder));
/*     */       }
/*     */     }
/* 358 */     return fillOrders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static <T extends OrderHistoricalData.PartialData> Set<PartialOrder> getPartialOrders(Collection<T> historyData)
/*     */   {
/* 365 */     Set<PartialOrder> partialOrders = new HashSet();
/* 366 */     if (!ObjectUtils.isNullOrEmpty(historyData)) {
/* 367 */       for (T partialData : historyData) {
/* 368 */         double amount = 0.0D;
/* 369 */         if (partialData.getAmount() != null) {
/* 370 */           amount = partialData.getAmount().divide(MathConstants.ONE_MILLION).doubleValue();
/*     */         }
/* 372 */         double price = 0.0D;
/* 373 */         if (partialData.getPrice() != null) {
/* 374 */           price = partialData.getPrice().doubleValue();
/*     */         }
/* 376 */         PartialOrder partialOrder = new PartialOrder(partialData.getTime(), price, amount);
/* 377 */         partialOrders.add(partialOrder);
/*     */       }
/*     */     }
/* 380 */     return partialOrders;
/*     */   }
/*     */   
/*     */ 
/*     */   private static OrderGroupMessage createGroup(String externalSysId, Instrument instrument)
/*     */   {
/* 386 */     OrderGroupMessage orderGroup = new OrderGroupMessage();
/* 387 */     orderGroup.setTimestamp(Long.valueOf(new Date().getTime()));
/* 388 */     orderGroup.setExternalSysId(externalSysId);
/* 389 */     orderGroup.setInstrument(instrument.toString());
/* 390 */     return orderGroup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt createOpeningOrder(JForexTaskManager taskManager, String externalSysId, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, long goodTillTime, String comment)
/*     */   {
/* 397 */     OrderMessageExt order = new OrderMessageExt();
/* 398 */     order.setTag(comment);
/* 399 */     order.setState(OrderState.CREATED);
/* 400 */     if ((orderCommand == IEngine.OrderCommand.PLACE_BID) || (orderCommand == IEngine.OrderCommand.PLACE_OFFER)) {
/* 401 */       order.setPriceClient(BigDecimal.valueOf(price));
/*     */     } else { double priceClient;
/*     */       double priceClient;
/* 404 */       if (orderCommand.isLong()) {
/* 405 */         priceClient = FeedDataProvider.getDefaultInstance().getLastAsk(instrument);
/*     */       } else {
/* 407 */         priceClient = FeedDataProvider.getDefaultInstance().getLastBid(instrument);
/*     */       }
/* 409 */       if (!Double.isNaN(priceClient)) {
/* 410 */         order.setPriceClient(BigDecimal.valueOf(priceClient));
/*     */       }
/* 412 */       if ((orderCommand == IEngine.OrderCommand.BUY) || (orderCommand == IEngine.OrderCommand.SELL))
/*     */       {
/* 414 */         if (price > 0.0D) {
/* 415 */           if (Double.isNaN(priceClient)) {
/* 416 */             throw new IllegalStateException("Instrument not tradable");
/*     */           }
/* 418 */           BigDecimal priceClientBD = BigDecimal.valueOf(priceClient);
/* 419 */           BigDecimal worstPrice = BigDecimal.valueOf(price);
/* 420 */           if ((!Double.isNaN(slippage)) && (slippage > 0.0D)) {
/* 421 */             if (orderCommand.isLong()) {
/* 422 */               worstPrice = worstPrice.add(BigDecimal.valueOf(slippage));
/*     */             } else {
/* 424 */               worstPrice = worstPrice.subtract(BigDecimal.valueOf(slippage));
/*     */             }
/*     */           }
/* 427 */           if ((orderCommand.isLong()) && (worstPrice.compareTo(priceClientBD) > 0)) {
/* 428 */             slippage = worstPrice.subtract(priceClientBD).doubleValue();
/* 429 */           } else if ((!orderCommand.isLong()) && (worstPrice.compareTo(priceClientBD) < 0)) {
/* 430 */             slippage = priceClientBD.subtract(worstPrice).doubleValue();
/*     */           } else {
/* 432 */             order.setPriceClient(BigDecimal.valueOf(price));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 438 */       if ((!Double.isNaN(slippage)) && (slippage >= 0.0D)) {
/* 439 */         order.setPriceTrailingLimit(BigDecimal.valueOf(slippage));
/*     */       } else {
/* 441 */         order.setPriceTrailingLimit(null);
/*     */       }
/*     */     }
/* 444 */     if ((goodTillTime > 0L) && (!isMarket(orderCommand))) {
/* 445 */       order.setExecTimeoutMillis(Long.valueOf(goodTillTime));
/*     */     }
/*     */     
/* 448 */     order = setGeneralData(amount, OrderDirection.OPEN, orderCommand.isLong() ? OrderSide.BUY : OrderSide.SELL, order);
/* 449 */     order = setGeneralData(externalSysId, instrument, order);
/* 450 */     return setManagerData(taskManager, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setManagerData(JForexTaskManager taskManager, OrderMessageExt order)
/*     */   {
/* 461 */     order.setStrategyId(taskManager.getStrategyKey());
/* 462 */     order.setExternalIp(taskManager.getExternalIP());
/* 463 */     order.setInternalIp(taskManager.getInternalIP());
/* 464 */     order.setSessionId(taskManager.getSessionID());
/* 465 */     order.setStrategyType(Integer.valueOf(taskManager.getStrategyType().getType()));
/* 466 */     return order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(String externalSysId, Instrument instrument, OrderMessageExt order)
/*     */   {
/* 479 */     order.setExternalSysId(externalSysId);
/* 480 */     order.setInstrument(instrument.toString());
/* 481 */     return order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(String groupId, String orderId, OrderState orderState, OrderMessageExt order)
/*     */   {
/* 495 */     order.setOrderGroupId(groupId);
/* 496 */     order.setOrderId(orderId);
/* 497 */     order.setState(orderState);
/* 498 */     return order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(JForexTaskManager taskManager, String externalSysId, Instrument instrument, String groupId, String orderId, OrderState orderState, OrderMessageExt order)
/*     */   {
/* 519 */     order = setGeneralData(groupId, orderId, orderState, order);
/* 520 */     order = setGeneralData(externalSysId, instrument, order);
/* 521 */     return setManagerData(taskManager, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(double amount, OrderDirection orderDirection, OrderSide orderSide, OrderMessageExt order)
/*     */   {
/* 536 */     order.setAmount(BigDecimal.valueOf(amount).multiply(MathConstants.ONE_MILLION));
/* 537 */     order.setDirection(orderDirection);
/* 538 */     order.setSide(orderSide);
/* 539 */     return order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(double price, double amount, OrderDirection orderDirection, StopDirection stopDirection, OrderSide orderSide, OrderMessageExt order)
/*     */   {
/* 558 */     order = setGeneralData(amount, orderDirection, orderSide, order);
/* 559 */     order.setPriceStop(BigDecimal.valueOf(price));
/* 560 */     order.setStopDirection(stopDirection);
/* 561 */     return order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(JForexTaskManager taskManager, String externalSysId, Instrument instrument, String groupId, String orderId, double price, double amount, OrderDirection orderDirection, StopDirection stopDirection, OrderSide orderSide, OrderMessageExt order)
/*     */   {
/* 591 */     order = setGeneralData(price, amount, orderDirection, stopDirection, orderSide, order);
/* 592 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, OrderState.PENDING, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt setGeneralData(JForexTaskManager taskManager, Instrument instrument, String externalSysId, String groupId, String orderId, double amount, OrderSide orderSide, OrderMessageExt order)
/*     */   {
/* 615 */     order = setGeneralData(amount, OrderDirection.OPEN, orderSide, order);
/* 616 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, OrderState.EXECUTING, order);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static OrderMessageExt createUpdateOrderMessage(JForexTaskManager taskManager, Instrument instrument, String externalSysId, String groupId, String orderId, double amount, boolean isLong)
/*     */   {
/* 631 */     OrderMessageExt order = new OrderMessageExt();
/* 632 */     order = setGeneralData(amount, OrderDirection.OPEN, isLong ? OrderSide.BUY : OrderSide.SELL, order);
/* 633 */     return setGeneralData(taskManager, externalSysId, instrument, groupId, orderId, OrderState.PENDING, order);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexAPI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */