/*     */ package com.dukascopy.charts.data.datacache.customperiod.tick;
/*     */ 
/*     */ import com.dukascopy.api.Filter;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.CurvesDataLoader.IntraperiodExistsPolicy;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.LoadCustomPeriodNumberOfCandlesAction;
/*     */ import com.dukascopy.charts.data.datacache.LoadDataAction;
/*     */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.TimeDataUtils;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.ITimeInterval;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadCandlesFromTicksAction
/*     */   implements Runnable
/*     */ {
/*  32 */   private static final Logger LOGGER = LoggerFactory.getLogger(LoadCustomPeriodNumberOfCandlesAction.class);
/*     */   
/*     */ 
/*     */   private final Instrument instrument;
/*     */   
/*     */   private final OfferSide offerSide;
/*     */   
/*     */   private final Filter filter;
/*     */   
/*     */   private final Period desiredPeriod;
/*     */   
/*     */   private final IFeedDataProvider feedDataProvider;
/*     */   
/*     */   private final CurvesDataLoader.IntraperiodExistsPolicy intraperiodExistsPolicy;
/*     */   
/*     */   private final ILoadingProgressListener originalLoadingProgress;
/*     */   
/*     */   private final LiveFeedListener originalLiveFeedListener;
/*     */   
/*     */   private final int numberOfCandlesBefore;
/*     */   
/*     */   private final int numberOfCandlesAfter;
/*     */   
/*     */   private final long fromTime;
/*     */   
/*     */   private final long toTime;
/*     */   
/*     */   private final long time;
/*     */   
/*     */ 
/*     */   public LoadCandlesFromTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, OfferSide offerSide, Filter filter, Period desiredPeriod, CurvesDataLoader.IntraperiodExistsPolicy intraperiodExistsPolicy, ILoadingProgressListener originalLoadingProgress, LiveFeedListener originalLiveFeedListener, int numberOfCandlesBefore, int numberOfCandlesAfter, long fromTime, long toTime, long time)
/*     */   {
/*  64 */     this.feedDataProvider = feedDataProvider;
/*  65 */     this.instrument = instrument;
/*  66 */     this.desiredPeriod = desiredPeriod;
/*  67 */     this.offerSide = offerSide;
/*  68 */     this.filter = filter;
/*  69 */     this.intraperiodExistsPolicy = intraperiodExistsPolicy;
/*  70 */     this.originalLoadingProgress = originalLoadingProgress;
/*  71 */     this.originalLiveFeedListener = originalLiveFeedListener;
/*     */     
/*  73 */     this.numberOfCandlesBefore = numberOfCandlesBefore;
/*  74 */     this.numberOfCandlesAfter = numberOfCandlesAfter;
/*  75 */     this.time = time;
/*  76 */     this.fromTime = fromTime;
/*  77 */     this.toTime = toTime;
/*     */     
/*     */ 
/*  80 */     long tickHistoryStartTime = feedDataProvider.getTimeOfFirstTick(instrument);
/*  81 */     if ((tickHistoryStartTime < 0L) || (tickHistoryStartTime >= Long.MAX_VALUE)) {
/*  82 */       throw new IllegalArgumentException("No tick history for " + instrument + " to create custom period candles of " + desiredPeriod);
/*     */     }
/*     */     
/*  85 */     long firstPossibleStartTime = tickHistoryStartTime;
/*  86 */     if (!Period.TICK.equals(desiredPeriod)) {
/*  87 */       firstPossibleStartTime = DataCacheUtils.getCandleStartFast(desiredPeriod, tickHistoryStartTime);
/*     */     }
/*     */     
/*  90 */     if (this.fromTime > 0L) {
/*  91 */       if (firstPossibleStartTime > this.fromTime) {
/*  92 */         throw new IllegalArgumentException("Desired candles (" + desiredPeriod + ") from time is earlier than tick history (" + instrument + ") start time '" + DateUtils.format(this.fromTime) + "' < '" + DateUtils.format(firstPossibleStartTime));
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 100 */       long candlesStartTime = DataCacheUtils.getTimeForNCandlesBackFast(desiredPeriod, time, numberOfCandlesBefore);
/* 101 */       if (firstPossibleStartTime > candlesStartTime) {
/* 102 */         throw new IllegalArgumentException("Desired candles (" + desiredPeriod + ") time is earlier than tick history (" + instrument + ") start time '" + DateUtils.format(candlesStartTime) + "' < '" + DateUtils.format(firstPossibleStartTime));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoadCandlesFromTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, OfferSide offerSide, Filter filter, Period desiredPeriod, CurvesDataLoader.IntraperiodExistsPolicy intraperiodExistsPolicy, ILoadingProgressListener originalLoadingProgress, LiveFeedListener originalLiveFeedListener, int numberOfCandlesBefore, int numberOfCandlesAfter, long time)
/*     */   {
/* 124 */     this(feedDataProvider, instrument, offerSide, filter, desiredPeriod, intraperiodExistsPolicy, originalLoadingProgress, originalLiveFeedListener, numberOfCandlesBefore, numberOfCandlesAfter, -1L, -1L, time);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoadCandlesFromTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, OfferSide offerSide, Filter filter, Period desiredPeriod, CurvesDataLoader.IntraperiodExistsPolicy intraperiodExistsPolicy, ILoadingProgressListener originalLoadingProgress, LiveFeedListener originalLiveFeedListener, long fromTime, long toTime)
/*     */   {
/* 153 */     this(feedDataProvider, instrument, offerSide, filter, desiredPeriod, intraperiodExistsPolicy, originalLoadingProgress, originalLiveFeedListener, -1, -1, fromTime, toTime, -1L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 173 */     if ((getFromTime() > -1L) && (getToTime() > -1L)) {
/* 174 */       long correctedToTheNextCandleToTime = DataCacheUtils.getNextCandleStartFast(getDesiredPeriod(), getToTime());
/* 175 */       performLoadingForFromToTimes(getFromTime(), correctedToTheNextCandleToTime);
/*     */     }
/* 177 */     else if ((getTime() > -1L) && (getNumberOfCandlesAfter() > -1) && (getNumberOfCandlesBefore() > -1)) {
/* 178 */       performLoadingForCandlesCount();
/*     */     }
/*     */     else {
/* 181 */       throw new IllegalArgumentException("Wrong params are set");
/*     */     }
/*     */   }
/*     */   
/*     */   private void performLoadingForFromToTimes(long fromTime, long toTime) {
/* 186 */     Exception exception = null;
/* 187 */     CustomPeriodFromTicksCreator customPeriodFromTicksCreator = null;
/* 188 */     boolean loadingProcessStopped = false;
/*     */     try
/*     */     {
/* 191 */       customPeriodFromTicksCreator = new FlowCustomPeriodFromTicksCreator(getInstrument(), getOfferSide(), getDesiredPeriod(), getFilter(), false, new Long(fromTime), null, this.feedDataProvider.getFilterManager());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */       customPeriodFromTicksCreator.addListener(getOriginalLiveFeedListener());
/*     */       
/* 204 */       CustomPeriodTickLiveFeedListener ticLiveFeedListener = new CustomPeriodTickLiveFeedListener(customPeriodFromTicksCreator);
/* 205 */       TickLoadingProgressListener tickAfterLoadingProgressListener = createTickLoadingProgressListener(getOriginalLoadingProgress());
/*     */       
/* 207 */       long timeOfFirstCandle = getFeedDataProvider().getTimeOfFirstCandle(getInstrument(), Period.TICK);
/* 208 */       long startTime = fromTime > timeOfFirstCandle ? fromTime : timeOfFirstCandle;
/*     */       
/* 210 */       while (startTime < toTime) {
/* 211 */         if (getOriginalLoadingProgress().stopJob()) {
/* 212 */           loadingProcessStopped = true; return;
/*     */         }
/*     */         
/*     */ 
/* 216 */         long endTime = startTime + getIncreaseTimeInterval();
/* 217 */         endTime = endTime < toTime ? endTime : toTime;
/*     */         
/* 219 */         loadDataForTimeInterval(startTime, endTime, ticLiveFeedListener, tickAfterLoadingProgressListener);
/* 220 */         startTime = endTime;
/*     */       }
/*     */       
/* 223 */       checkAndProcessLastCandle(this.offerSide, this.desiredPeriod, this.filter, customPeriodFromTicksCreator, getToTime(), this.feedDataProvider.getFilterManager()); return;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */       exception = e;
/* 270 */       LOGGER.error(e.getMessage(), e);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 277 */         postFinishDataLoading(customPeriodFromTicksCreator, null, exception, loadingProcessStopped);
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/* 283 */         LOGGER.error(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkAndProcessLastCandle(OfferSide offerSide, Period desiredPeriod, Filter filter, CustomPeriodFromTicksCreator customPeriodFromTicksCreator, long lastCandleTime, IFilterManager filterManager)
/*     */     throws DataCacheException
/*     */   {
/* 298 */     CandleData lastCandle = customPeriodFromTicksCreator.getLastData();
/* 299 */     CandleData notFinishedCandle = customPeriodFromTicksCreator.getCurrentCandleDataUnderAnalysis();
/*     */     
/* 301 */     if (Filter.WEEKENDS.equals(filter)) {
/* 302 */       while (filterManager.isWeekendTime(lastCandleTime, desiredPeriod)) {
/* 303 */         lastCandleTime = DataCacheUtils.getPreviousCandleStartFast(desiredPeriod, lastCandleTime);
/*     */       }
/*     */     }
/*     */     
/* 307 */     long nextCandleTime = DataCacheUtils.getNextCandleStartFast(desiredPeriod, lastCandleTime);
/*     */     
/* 309 */     if ((lastCandle != null) && (lastCandle.getTime() < lastCandleTime))
/*     */     {
/*     */ 
/*     */ 
/* 313 */       processFakeTickToCompleteLastCandle(customPeriodFromTicksCreator, lastCandle.getClose(), nextCandleTime);
/*     */     }
/* 315 */     else if ((lastCandle == null) && (notFinishedCandle != null) && (notFinishedCandle.getTime() <= lastCandleTime))
/*     */     {
/*     */ 
/*     */ 
/* 319 */       processFakeTickToCompleteLastCandle(customPeriodFromTicksCreator, notFinishedCandle.getClose(), nextCandleTime);
/*     */     }
/* 321 */     else if ((lastCandle == null) && (notFinishedCandle == null))
/*     */     {
/*     */ 
/*     */ 
/* 325 */       if ((Filter.NO_FILTER.equals(filter)) || ((Filter.WEEKENDS.equals(filter)) && (!filterManager.isWeekendTime(lastCandleTime, desiredPeriod))))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */         TickData lastBeforeTimeTick = getFirstTickOfTimeOrLastTickBeforeTime(lastCandleTime, desiredPeriod);
/* 333 */         if (lastBeforeTimeTick != null) {
/* 334 */           double price = OfferSide.ASK.equals(offerSide) ? lastBeforeTimeTick.getAsk() : lastBeforeTimeTick.getBid();
/*     */           
/*     */ 
/* 337 */           processFakeTickToCompleteLastCandle(customPeriodFromTicksCreator, price, nextCandleTime);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void processFakeTickToCompleteLastCandle(CustomPeriodFromTicksCreator customPeriodFromTicksCreator, double price, long time)
/*     */   {
/* 348 */     TickData fakeTick = new TickData(time, price, price, 0.0D, 0.0D);
/* 349 */     customPeriodFromTicksCreator.analyseTickData(fakeTick);
/*     */   }
/*     */   
/*     */   private void performLoadingForCandlesCount()
/*     */   {
/* 354 */     Exception exception = null;
/*     */     
/* 356 */     CustomPeriodFromTicksCreator customPeriodAfterCreator = null;
/* 357 */     CustomPeriodFromTicksCreator customPeriodBeforeCreator = null;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 363 */       long timeForBeforeCreator = getTime();
/* 364 */       if (this.numberOfCandlesBefore > 0) {
/* 365 */         customPeriodBeforeCreator = loadDataBeforeTime(this.instrument, this.offerSide, this.filter, this.desiredPeriod, this.numberOfCandlesBefore, timeForBeforeCreator, this.feedDataProvider.getFilterManager());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 375 */         checkAndProcessLastCandle(this.offerSide, this.desiredPeriod, this.filter, customPeriodBeforeCreator, timeForBeforeCreator, this.feedDataProvider.getFilterManager());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 388 */       long timeForAfterCreator = getTime();
/* 389 */       if (this.numberOfCandlesBefore > 0) {
/* 390 */         timeForAfterCreator = DataCacheUtils.getNextCandleStart(this.desiredPeriod, getTime());
/*     */       }
/* 392 */       if (this.numberOfCandlesAfter > 0) {
/* 393 */         customPeriodAfterCreator = loadDataAfterTime(this.instrument, this.offerSide, this.filter, this.desiredPeriod, this.numberOfCandlesAfter, timeForAfterCreator, this.feedDataProvider.getFilterManager());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */         long lastCandleTime = DataCacheUtils.getTimeForNCandlesForwardFast(this.desiredPeriod, timeForAfterCreator, this.numberOfCandlesAfter);
/* 404 */         checkAndProcessLastCandle(this.offerSide, this.desiredPeriod, this.filter, customPeriodAfterCreator, lastCandleTime, this.feedDataProvider.getFilterManager());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       return;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 415 */       exception = e;
/* 416 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 421 */         postData(customPeriodBeforeCreator, customPeriodAfterCreator, exception);
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/* 427 */         LOGGER.error(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CustomPeriodFromTicksCreator loadDataBeforeTime(Instrument instrument, OfferSide offerSide, Filter filter, Period desiredPeriod, int numberOfCandlesBefore, long time, IFilterManager filterManager)
/*     */     throws DataCacheException
/*     */   {
/* 442 */     if (numberOfCandlesBefore <= 0) {
/* 443 */       return null;
/*     */     }
/*     */     
/*     */     long from;
/*     */     long from;
/* 448 */     if ((filter == null) || (Filter.NO_FILTER.equals(filter))) {
/* 449 */       from = DataCacheUtils.getTimeForNCandlesBackFast(desiredPeriod, time, numberOfCandlesBefore);
/*     */     }
/*     */     else
/*     */     {
/* 453 */       long to = DataCacheUtils.getNextCandleStartFast(desiredPeriod, time) - 1L;
/*     */       
/* 455 */       CustomPeriodFromTicksCreator customPeriodBeforeInverseCreator = new CustomPeriodFromTicksCreator(instrument, offerSide, numberOfCandlesBefore, desiredPeriod, filter, true, Long.valueOf(to), null, filterManager);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 467 */       CustomPeriodTickLiveFeedListener tickInverseLiveFeedListener = new CustomPeriodTickLiveFeedListener(customPeriodBeforeInverseCreator);
/* 468 */       TickLoadingProgressListener tickInverseLoadingProgressListener = createTickLoadingProgressListener(getOriginalLoadingProgress());
/*     */       
/* 470 */       long firstCandleTime = getFeedDataProvider().getTimeOfFirstCandle(getInstrument(), Period.TICK);
/* 471 */       loadDataBeforeTime(to, firstCandleTime, tickInverseLiveFeedListener, tickInverseLoadingProgressListener);
/*     */       long from;
/* 473 */       if (customPeriodBeforeInverseCreator.getLoadedCandleCount() > 0) {
/* 474 */         from = customPeriodBeforeInverseCreator.getLastData().time;
/*     */       }
/*     */       else {
/* 477 */         from = DataCacheUtils.getTimeForNCandlesBackFast(desiredPeriod, time, numberOfCandlesBefore);
/*     */       }
/*     */     }
/*     */     
/* 481 */     CustomPeriodFromTicksCreator creator = loadDataAfterTime(instrument, offerSide, filter, desiredPeriod, numberOfCandlesBefore, from, filterManager);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 491 */     return creator;
/*     */   }
/*     */   
/*     */   private TickData getFirstTickOfTimeOrLastTickBeforeTime(long timeTo, Period period) throws DataCacheException
/*     */   {
/* 496 */     long from = timeTo;
/*     */     
/* 498 */     ILoadingProgressListener loadingProgressListener = new LoadingProgressAdapter() {};
/* 499 */     FirstTickLiveFeedListener firstTickLoadingProgressListener = new FirstTickLiveFeedListener();
/*     */     
/* 501 */     long to = DataCacheUtils.getNextCandleStartFast(period, timeTo) - 1L;
/*     */     
/* 503 */     LoadDataAction action = createLoadDataAction(from, to, firstTickLoadingProgressListener, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 510 */     action.run();
/*     */     
/* 512 */     if (firstTickLoadingProgressListener.getFirstTick() != null) {
/* 513 */       return firstTickLoadingProgressListener.getFirstTick();
/*     */     }
/*     */     
/*     */ 
/* 517 */     long firstCandleTime = this.feedDataProvider.getTimeOfFirstCandle(getInstrument(), Period.TICK);
/*     */     
/* 519 */     long HOUR = 3600000L;
/*     */     
/* 521 */     loadingProgressListener = new LoadingProgressAdapter() {};
/* 522 */     LastTickLiveFeedListener lastTickLoadingProgressListener = new LastTickLiveFeedListener();
/*     */     
/* 524 */     to = timeTo;
/*     */     
/* 526 */     while ((firstCandleTime < to) && (lastTickLoadingProgressListener.getLastTick() == null))
/*     */     {
/*     */ 
/*     */ 
/* 530 */       from = to - 3600000L;
/*     */       
/*     */ 
/* 533 */       action = createLoadDataAction(from, to, lastTickLoadingProgressListener, loadingProgressListener);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 540 */       action.run();
/*     */       
/* 542 */       to = from;
/*     */     }
/*     */     
/* 545 */     return lastTickLoadingProgressListener.getLastTick();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void postData(CustomPeriodFromTicksCreator customPeriodBeforeCreator, CustomPeriodFromTicksCreator customPeriodAfterCreator, Exception exception)
/*     */   {
/* 553 */     CandleData[] consequentCustomPeriodArray = constructConsequentCustomPeriodArray(customPeriodAfterCreator, customPeriodBeforeCreator);
/*     */     
/*     */ 
/* 556 */     if (consequentCustomPeriodArray != null) {
/* 557 */       for (int i = 0; i < consequentCustomPeriodArray.length; i++) {
/* 558 */         CandleData data = consequentCustomPeriodArray[i];
/* 559 */         if (data != null)
/*     */         {
/*     */ 
/* 562 */           getOriginalLiveFeedListener().newCandle(getInstrument(), getDesiredPeriod(), getOfferSide(), data.getTime(), data.getOpen(), data.getClose(), data.getLow(), data.getHigh(), data.getVolume());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 576 */     postFinishDataLoading(customPeriodBeforeCreator, customPeriodAfterCreator, exception, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void postFinishDataLoading(CustomPeriodFromTicksCreator customPeriodBeforeCreator, CustomPeriodFromTicksCreator customPeriodAfterCreator, Exception exception, boolean loadingProcessStopped)
/*     */   {
/* 589 */     long startTime = getTime();
/* 590 */     if ((customPeriodBeforeCreator != null) && (customPeriodBeforeCreator.getLastTime() != null)) {
/* 591 */       startTime = customPeriodBeforeCreator.getLastTime().longValue();
/*     */     }
/* 593 */     else if (customPeriodBeforeCreator == null) {
/* 594 */       startTime = getFromTime();
/*     */     }
/* 596 */     else if ((customPeriodAfterCreator != null) && (customPeriodAfterCreator.getFirstTime() != null)) {
/* 597 */       startTime = customPeriodAfterCreator.getFirstTime().longValue();
/*     */     }
/*     */     
/* 600 */     long endTime = getTime();
/* 601 */     if ((customPeriodAfterCreator != null) && (customPeriodAfterCreator.getLastTime() != null)) {
/* 602 */       endTime = customPeriodAfterCreator.getLastTime().longValue();
/*     */     }
/* 604 */     else if ((customPeriodBeforeCreator != null) && (customPeriodBeforeCreator.getFirstTime() != null)) {
/* 605 */       endTime = customPeriodBeforeCreator.getFirstTime().longValue();
/*     */     }
/* 607 */     else if (customPeriodBeforeCreator == null) {
/* 608 */       endTime = getToTime();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 614 */     getOriginalLoadingProgress().loadingFinished((exception == null) && (!loadingProcessStopped), startTime, endTime, endTime, exception);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CandleData[] constructConsequentCustomPeriodArray(CustomPeriodFromTicksCreator customPeriodAfterCreator, CustomPeriodFromTicksCreator customPeriodBeforeCreator)
/*     */   {
/* 629 */     if ((customPeriodAfterCreator != null) && (customPeriodBeforeCreator != null)) {
/* 630 */       CandleData[] result = new CandleData[customPeriodBeforeCreator.getLoadedCandleCount() + customPeriodAfterCreator.getLoadedCandleCount()];
/*     */       
/* 632 */       CandleData[] afterArray = customPeriodAfterCreator.getResult();
/* 633 */       CandleData[] beforeArray = customPeriodBeforeCreator.getResult();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 638 */       if (customPeriodBeforeCreator.getInverseOrder()) {
/* 639 */         beforeArray = reverse(beforeArray);
/*     */       }
/* 641 */       if (customPeriodAfterCreator.getInverseOrder()) {
/* 642 */         afterArray = reverse(afterArray);
/*     */       }
/*     */       
/* 645 */       TimeDataUtils.copyArray(beforeArray, 0, result, 0, customPeriodBeforeCreator.getLoadedCandleCount());
/* 646 */       TimeDataUtils.copyArray(afterArray, 0, result, customPeriodBeforeCreator.getLoadedCandleCount(), customPeriodAfterCreator.getLoadedCandleCount());
/*     */       
/* 648 */       return result;
/*     */     }
/* 650 */     if (customPeriodAfterCreator != null) {
/* 651 */       CandleData[] result = new CandleData[customPeriodAfterCreator.getLoadedCandleCount()];
/* 652 */       CandleData[] afterArray = customPeriodAfterCreator.getResult();
/*     */       
/* 654 */       if (customPeriodAfterCreator.getInverseOrder())
/*     */       {
/*     */ 
/*     */ 
/* 658 */         afterArray = reverse(afterArray);
/*     */       }
/*     */       
/* 661 */       TimeDataUtils.copyArray(afterArray, 0, result, 0, customPeriodAfterCreator.getLoadedCandleCount());
/* 662 */       return result;
/*     */     }
/* 664 */     if (customPeriodBeforeCreator != null) {
/* 665 */       CandleData[] result = new CandleData[customPeriodBeforeCreator.getLoadedCandleCount()];
/*     */       
/* 667 */       CandleData[] beforeArray = customPeriodBeforeCreator.getResult();
/*     */       
/* 669 */       if (customPeriodBeforeCreator.getInverseOrder())
/*     */       {
/*     */ 
/*     */ 
/* 673 */         beforeArray = reverse(beforeArray);
/*     */       }
/*     */       
/* 676 */       TimeDataUtils.copyArray(beforeArray, 0, result, 0, customPeriodBeforeCreator.getLoadedCandleCount());
/*     */       
/* 678 */       return result;
/*     */     }
/*     */     
/* 681 */     return null;
/*     */   }
/*     */   
/*     */   private CandleData[] reverse(CandleData[] array) {
/* 685 */     CandleData[] reversedArray = new CandleData[array.length];
/* 686 */     TimeDataUtils.reverseArray(array, reversedArray);
/* 687 */     return reversedArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadDataBeforeTime(long time, long firstCandleTime, CustomPeriodTickLiveFeedListener tickLiveFeedListener, TickLoadingProgressListener tickLoadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 697 */     if (tickLiveFeedListener.getCustomPeriodFromTicksCreator().getDesiredCandlesCount() <= 0) {
/* 698 */       return;
/*     */     }
/*     */     
/* 701 */     long fromTime = time;
/* 702 */     boolean customPeriodsConstructed = false;
/*     */     
/*     */     do
/*     */     {
/* 706 */       if (tickLoadingProgressListener.stopJob()) {
/*     */         break;
/*     */       }
/*     */       
/* 710 */       long toTime = fromTime;
/* 711 */       fromTime -= getIncreaseTimeInterval();
/*     */       
/* 713 */       if ((fromTime > firstCandleTime) && (toTime < firstCandleTime)) {
/* 714 */         toTime = firstCandleTime;
/*     */       }
/*     */       
/* 717 */       if (fromTime < firstCandleTime) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 724 */       loadDataForTimeInterval(fromTime, toTime, tickLiveFeedListener, tickLoadingProgressListener);
/*     */     }
/* 726 */     while ((!tickLiveFeedListener.isCustomPeriodsCreationFinished()) && 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 731 */       (!customPeriodsConstructed));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CustomPeriodFromTicksCreator loadDataAfterTime(Instrument instrument, OfferSide offerSide, Filter filter, Period desiredPeriod, int numberOfCandlesAfter, long time, IFilterManager filterManager)
/*     */     throws DataCacheException
/*     */   {
/* 749 */     if (Filter.WEEKENDS.equals(filter))
/*     */     {
/*     */ 
/*     */ 
/* 753 */       ITimeInterval weekend = filterManager.getWeekend(time);
/* 754 */       if (weekend != null) {
/* 755 */         time = weekend.getEnd();
/*     */       }
/*     */     }
/* 758 */     TickData tick = getFirstTickOfTimeOrLastTickBeforeTime(time, desiredPeriod);
/*     */     
/* 760 */     Double firstDesiredCandleValue = null;
/* 761 */     if (tick != null) {
/* 762 */       double value = OfferSide.ASK.equals(getOfferSide()) ? tick.getAsk() : tick.getBid();
/*     */       
/*     */ 
/*     */ 
/* 766 */       firstDesiredCandleValue = new Double(value);
/*     */     }
/*     */     
/* 769 */     CustomPeriodFromTicksCreator customPeriodAfterCreator = new CustomPeriodFromTicksCreator(instrument, offerSide, numberOfCandlesAfter, desiredPeriod, filter, false, Long.valueOf(time), firstDesiredCandleValue, filterManager);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 780 */     CustomPeriodTickLiveFeedListener tickAfterLiveFeedListener = new CustomPeriodTickLiveFeedListener(customPeriodAfterCreator);
/* 781 */     TickLoadingProgressListener tickAfterLoadingProgressListener = createTickLoadingProgressListener(getOriginalLoadingProgress());
/*     */     
/* 783 */     loadDataAfterTime(instrument, time, tickAfterLiveFeedListener, tickAfterLoadingProgressListener);
/*     */     
/* 785 */     return customPeriodAfterCreator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadDataAfterTime(Instrument instrument, long time, CustomPeriodTickLiveFeedListener tickLiveFeedListener, TickLoadingProgressListener tickLoadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 799 */     if (tickLiveFeedListener.getCustomPeriodFromTicksCreator().getDesiredCandlesCount() <= 0) {
/* 800 */       return;
/*     */     }
/*     */     
/* 803 */     long toTime = time;
/* 804 */     boolean customPeriodsConstructed = false;
/*     */     do
/*     */     {
/* 807 */       if (tickLoadingProgressListener.stopJob()) {
/*     */         break;
/*     */       }
/*     */       
/* 811 */       long fromTime = toTime;
/* 812 */       toTime += getIncreaseTimeInterval();
/* 813 */       long lastKnownTime = this.feedDataProvider.getCurrentTime(instrument);
/*     */       
/* 815 */       if ((fromTime < lastKnownTime) && (toTime > lastKnownTime)) {
/* 816 */         toTime = lastKnownTime;
/*     */       }
/*     */       
/* 819 */       if (fromTime > lastKnownTime) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 827 */       loadDataForTimeInterval(fromTime, toTime, tickLiveFeedListener, tickLoadingProgressListener);
/*     */     }
/* 829 */     while ((!tickLiveFeedListener.isCustomPeriodsCreationFinished()) && 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 834 */       (!customPeriodsConstructed));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadDataForTimeInterval(long fromTime, long toTime, CustomPeriodTickLiveFeedListener tickLiveFeedListener, TickLoadingProgressListener tickLoadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 846 */     LoadDataAction loadDataAction = createLoadDataAction(fromTime, toTime, tickLiveFeedListener, tickLoadingProgressListener);
/* 847 */     loadDataAction.run();
/*     */     
/* 849 */     tickLiveFeedListener.analyseTickDataPortion();
/* 850 */     getOriginalLoadingProgress().dataLoaded(fromTime, toTime, toTime, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LoadDataAction createLoadDataAction(long fromTime, long toTime, LiveFeedListener liveFeedListener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 860 */     LoadDataAction loadDataAction = new LoadDataAction(getFeedDataProvider(), getInstrument(), fromTime, toTime, liveFeedListener, loadingProgressListener, null, false, this.intraperiodExistsPolicy, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 872 */     return loadDataAction;
/*     */   }
/*     */   
/*     */ 
/*     */   private long getIncreaseTimeInterval()
/*     */   {
/* 878 */     return 3600000L;
/*     */   }
/*     */   
/*     */   private TickLoadingProgressListener createTickLoadingProgressListener(ILoadingProgressListener delegate) {
/* 882 */     TickLoadingProgressListener tickLoadingProgressListener = new TickLoadingProgressListener(delegate);
/* 883 */     return tickLoadingProgressListener;
/*     */   }
/*     */   
/*     */   protected Instrument getInstrument() {
/* 887 */     return this.instrument;
/*     */   }
/*     */   
/*     */   protected OfferSide getOfferSide() {
/* 891 */     return this.offerSide;
/*     */   }
/*     */   
/*     */   protected Filter getFilter() {
/* 895 */     return this.filter;
/*     */   }
/*     */   
/*     */   protected Period getDesiredPeriod() {
/* 899 */     return this.desiredPeriod;
/*     */   }
/*     */   
/*     */   protected int getNumberOfCandlesBefore() {
/* 903 */     return this.numberOfCandlesBefore;
/*     */   }
/*     */   
/*     */   protected int getNumberOfCandlesAfter() {
/* 907 */     return this.numberOfCandlesAfter;
/*     */   }
/*     */   
/*     */   protected long getTime() {
/* 911 */     return this.time;
/*     */   }
/*     */   
/*     */   protected IFeedDataProvider getFeedDataProvider() {
/* 915 */     return this.feedDataProvider;
/*     */   }
/*     */   
/*     */ 
/*     */   protected CurvesDataLoader.IntraperiodExistsPolicy getIntraperiodExistsPolicy()
/*     */   {
/* 921 */     return this.intraperiodExistsPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ILoadingProgressListener getOriginalLoadingProgress()
/*     */   {
/* 927 */     return this.originalLoadingProgress;
/*     */   }
/*     */   
/*     */ 
/*     */   protected LiveFeedListener getOriginalLiveFeedListener()
/*     */   {
/* 933 */     return this.originalLiveFeedListener;
/*     */   }
/*     */   
/*     */   protected long getFromTime() {
/* 937 */     return this.fromTime;
/*     */   }
/*     */   
/*     */   protected long getToTime() {
/* 941 */     return this.toTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customperiod\tick\LoadCandlesFromTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */