/*    */ package com.dukascopy.charts.data.datacache.change;
/*    */ 
/*    */ import com.dukascopy.api.util.DateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheChangeItem
/*    */ {
/*    */   private String instrumentFolderName;
/*    */   private String periodByChunk;
/*    */   private String relativePathToFile;
/*    */   private long chunkStart;
/*    */   
/*    */   public CacheChangeItem() {}
/*    */   
/*    */   public CacheChangeItem(String instrumentFolderName, String periodByChunk, String relativePathToFile, long chunkStart)
/*    */   {
/* 29 */     this.instrumentFolderName = instrumentFolderName;
/* 30 */     this.periodByChunk = periodByChunk;
/* 31 */     this.relativePathToFile = relativePathToFile;
/* 32 */     this.chunkStart = chunkStart;
/*    */   }
/*    */   
/* 35 */   public String getInstrumentFolderName() { return this.instrumentFolderName; }
/*    */   
/*    */   public void setInstrumentFolderName(String instrumentFolderName) {
/* 38 */     this.instrumentFolderName = instrumentFolderName;
/*    */   }
/*    */   
/* 41 */   public String getPeriodByChunk() { return this.periodByChunk; }
/*    */   
/*    */   public void setPeriodByChunk(String periodByChunk) {
/* 44 */     this.periodByChunk = periodByChunk;
/*    */   }
/*    */   
/* 47 */   public String getRelativePathToFile() { return this.relativePathToFile; }
/*    */   
/*    */   public void setRelativePathToFile(String relativePathToFile) {
/* 50 */     this.relativePathToFile = relativePathToFile;
/*    */   }
/*    */   
/* 53 */   public long getChunkStart() { return this.chunkStart; }
/*    */   
/*    */   public void setChunkStart(long chunkStart) {
/* 56 */     this.chunkStart = chunkStart;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 61 */     return "[" + this.instrumentFolderName + ", " + this.periodByChunk + ", " + DateUtils.format(this.chunkStart) + ", " + this.relativePathToFile + "]";
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 65 */     int prime = 31;
/* 66 */     int result = 1;
/* 67 */     result = 31 * result + (int)(this.chunkStart ^ this.chunkStart >>> 32);
/* 68 */     result = 31 * result + (this.instrumentFolderName == null ? 0 : this.instrumentFolderName.hashCode());
/* 69 */     result = 31 * result + (this.periodByChunk == null ? 0 : this.periodByChunk.hashCode());
/* 70 */     result = 31 * result + (this.relativePathToFile == null ? 0 : this.relativePathToFile.hashCode());
/* 71 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 75 */     if (this == obj)
/* 76 */       return true;
/* 77 */     if (obj == null)
/* 78 */       return false;
/* 79 */     if (getClass() != obj.getClass())
/* 80 */       return false;
/* 81 */     CacheChangeItem other = (CacheChangeItem)obj;
/* 82 */     if (this.chunkStart != other.chunkStart)
/* 83 */       return false;
/* 84 */     if (this.instrumentFolderName == null) {
/* 85 */       if (other.instrumentFolderName != null)
/* 86 */         return false;
/* 87 */     } else if (!this.instrumentFolderName.equals(other.instrumentFolderName))
/* 88 */       return false;
/* 89 */     if (this.periodByChunk == null) {
/* 90 */       if (other.periodByChunk != null)
/* 91 */         return false;
/* 92 */     } else if (!this.periodByChunk.equals(other.periodByChunk))
/* 93 */       return false;
/* 94 */     if (this.relativePathToFile == null) {
/* 95 */       if (other.relativePathToFile != null)
/* 96 */         return false;
/* 97 */     } else if (!this.relativePathToFile.equals(other.relativePathToFile))
/* 98 */       return false;
/* 99 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\change\CacheChangeItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */