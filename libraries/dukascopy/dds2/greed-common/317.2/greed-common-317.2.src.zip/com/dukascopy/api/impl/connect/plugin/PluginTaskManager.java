/*     */ package com.dukascopy.api.impl.connect.plugin;
/*     */ 
/*     */ import com.dukascopy.api.IClientGUIListener;
/*     */ import com.dukascopy.api.IConsole;
/*     */ import com.dukascopy.api.IStrategyListener;
/*     */ import com.dukascopy.api.impl.connect.ILotAmountProvider;
/*     */ import com.dukascopy.api.impl.connect.JFRunnableProcessor;
/*     */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*     */ import com.dukascopy.api.impl.connect.JForexTaskManager.Environment;
/*     */ import com.dukascopy.api.impl.connect.strategy.local.SdkStrategyManager;
/*     */ import com.dukascopy.api.impl.connect.validation.IOrderValidator;
/*     */ import com.dukascopy.api.impl.connect.validation.PluginOrderValidator;
/*     */ import com.dukascopy.api.plugins.IPluginContext;
/*     */ import com.dukascopy.api.plugins.Plugin;
/*     */ import com.dukascopy.api.plugins.PluginGuiListener;
/*     */ import com.dukascopy.api.strategy.local.ILocalStrategyManager;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessage;
/*     */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessageInit;
/*     */ import com.dukascopy.dds4.transport.client.TransportClient;
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class PluginTaskManager extends JForexTaskManager<IPluginContext, Plugin, IPluginUserInterface>
/*     */ {
/*     */   private final boolean isAutoTradingAllowed;
/*     */   private final PluginGuiListener guiListener;
/*     */   private final ILocalStrategyManager localStrategyManager;
/*     */   private IOrderValidator orderValidator;
/*     */   
/*     */   public static class Builder extends com.dukascopy.api.impl.connect.JForexTaskManager.Builder<IPluginContext, Plugin, IPluginUserInterface, PluginTaskManager>
/*     */   {
/*     */     private final boolean isAutoTradingAllowed;
/*     */     private final PluginGuiListener guiListener;
/*     */     private final IPluginUserInterface userInterface;
/*     */     private final ILocalStrategyManager localStrategyManager;
/*     */     
/*     */     private Builder(boolean isAutoTradingAllowed, PluginGuiListener guiListener, IPluginUserInterface userInterface, ILocalStrategyManager localStrategyManager)
/*     */     {
/*  42 */       this.userInterface = userInterface;
/*  43 */       this.isAutoTradingAllowed = isAutoTradingAllowed;
/*  44 */       this.guiListener = guiListener;
/*  45 */       this.localStrategyManager = localStrategyManager;
/*     */     }
/*     */     
/*     */     public static Builder newPlatformInstance(boolean isAutoTradingAllowed, IPluginUserInterface userInterface, ILocalStrategyManager localStrategyManager) {
/*  49 */       new Builder(isAutoTradingAllowed, new PluginGuiListener() {}, userInterface, localStrategyManager);
/*     */     }
/*     */     
/*     */     public static Builder newSdkInstance(PluginGuiListener guiListener) {
/*  53 */       return new Builder(true, guiListener, new com.dukascopy.api.impl.connect.PluginUISdk(), SdkStrategyManager.getInstance());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public PluginTaskManager build(JForexTaskManager.Environment environment, boolean live, String accountName, IConsole console, TransportClient transportClient, DDSChartsController ddsChartsController, ILotAmountProvider lotAmountProvider, IStrategyExceptionHandler exceptionHandler, AccountInfoMessage lastAccountInfo, AccountInfoMessageInit lastAccountInfoInit, String externalIP, String internalIP, String sessionID, Properties serverProperties, IClientGUIListener clientGUIListener)
/*     */     {
/*  73 */       return new PluginTaskManager(environment, live, accountName, console, transportClient, ddsChartsController, lotAmountProvider, this.userInterface, exceptionHandler, lastAccountInfo, lastAccountInfoInit, externalIP, internalIP, sessionID, serverProperties, clientGUIListener, this.isAutoTradingAllowed, this.guiListener, this.localStrategyManager, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PluginTaskManager(JForexTaskManager.Environment environment, boolean live, String accountName, IConsole console, TransportClient transportClient, DDSChartsController ddsChartsController, ILotAmountProvider lotAmountProvider, IPluginUserInterface userInterface, IStrategyExceptionHandler exceptionHandler, AccountInfoMessage lastAccountInfo, AccountInfoMessageInit lastAccountInfoInit, String externalIP, String internalIP, String sessionID, Properties serverProperties, IClientGUIListener clientGUIListener, boolean isAutoTradingAllowed, PluginGuiListener guiListener, ILocalStrategyManager localStrategyManager)
/*     */   {
/*  98 */     super(environment, live, accountName, console, transportClient, ddsChartsController, lotAmountProvider, userInterface, exceptionHandler, lastAccountInfo, lastAccountInfoInit, externalIP, internalIP, sessionID, serverProperties, clientGUIListener);
/*     */     
/* 100 */     this.isAutoTradingAllowed = isAutoTradingAllowed;
/* 101 */     this.guiListener = guiListener;
/* 102 */     this.localStrategyManager = localStrategyManager;
/*     */   }
/*     */   
/*     */   public IOrderValidator getOrderValidator()
/*     */   {
/* 107 */     if (this.orderValidator == null) {
/* 108 */       this.orderValidator = new PluginOrderValidator(this, getLotAmountProvider(), this.isAutoTradingAllowed);
/*     */     }
/* 110 */     return this.orderValidator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long startJfRunnable(Plugin plugin, IStrategyListener listener, String strategyKey, boolean fullAccessGranted, String jfxPackMD5, List<File> custIndFiles)
/*     */   {
/* 122 */     PluginProcessor pluginProcessor = new PluginProcessor(this, plugin, fullAccessGranted);
/* 123 */     return exuteStart(pluginProcessor, listener, strategyKey, jfxPackMD5, custIndFiles);
/*     */   }
/*     */   
/*     */   protected IPluginContext createContext(JFRunnableProcessor<IPluginContext, Plugin> jfRunnableProcessor)
/*     */   {
/* 128 */     return new PluginContext(jfRunnableProcessor, this.forexEngineImpl, this.history, this.console, this.ddsChartsController, (IPluginUserInterface)this.userInterface, this.clientGUIListener, this.serverProperties, this.guiListener, this.isAutoTradingAllowed, this.localStrategyManager);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void afterStop()
/*     */   {
/* 134 */     if (this.apiContext != null) {
/* 135 */       ((PluginContext)this.apiContext).dispose();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\plugin\PluginTaskManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */