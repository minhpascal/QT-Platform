/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RCL
/*    */   extends Container
/*    */ {
/*    */   public void setValue(double d)
/*    */   {
/* 22 */     this.d = d;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(OObject c)
/*    */   {
/* 30 */     this.c = c;
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 34 */     return fname;
/*    */   }
/*    */   
/* 37 */   private static final String[] fname = { "R", "C", "L" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\RCL.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */