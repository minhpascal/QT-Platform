/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.AngleType;
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.complex.Complex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ATan
/*    */   extends Trig
/*    */ {
/*    */   public ATan(AngleType angleType)
/*    */   {
/* 17 */     super(angleType);
/* 18 */     this.ftooltip = "sc.calculator.inverse.tangent.function";
/* 19 */     this.fshortcut = 't';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 28 */     return Math.atan(x) * this.iscale;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 37 */     if ((x instanceof Complex)) {
/* 38 */       Complex c = (Complex)x;
/* 39 */       if ((this.scale != 1.0D) && (StrictMath.abs(c.imaginary()) > 1.0E-6D))
/* 40 */         throw new RuntimeException("Error");
/* 41 */       return c.atan().scale(this.iscale);
/*    */     }
/* 43 */     return x.atan(this.angleType);
/*    */   }
/*    */   
/*    */   public String[] name_array()
/*    */   {
/* 48 */     return fname;
/*    */   }
/*    */   
/* 51 */   private static final String[] fname = { "t", "a", "n", "<sup>&#8722;</sup>", "<sup>1</sup>", " " };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\ATan.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */