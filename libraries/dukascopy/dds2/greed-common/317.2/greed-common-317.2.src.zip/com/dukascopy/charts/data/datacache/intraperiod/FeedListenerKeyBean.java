/*    */ package com.dukascopy.charts.data.datacache.intraperiod;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*    */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeedListenerKeyBean
/*    */ {
/*    */   private JForexPeriod jfPeriod;
/*    */   private Instrument instrument;
/*    */   private OfferSide offerSide;
/*    */   private DataInterpolationDescriptor interpolationDescriptor;
/*    */   
/*    */   public FeedListenerKeyBean(JForexPeriod jfPeriod, Instrument instrument, OfferSide offerSide, DataInterpolationDescriptor interpolationDescriptor)
/*    */   {
/* 29 */     this.jfPeriod = jfPeriod;
/* 30 */     this.instrument = instrument;
/* 31 */     this.offerSide = offerSide;
/* 32 */     this.interpolationDescriptor = interpolationDescriptor;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 37 */     int prime = 31;
/* 38 */     int result = 1;
/* 39 */     result = 31 * result + (this.instrument == null ? 0 : this.instrument.hashCode());
/*    */     
/* 41 */     result = 31 * result + (this.interpolationDescriptor == null ? 0 : this.interpolationDescriptor.hashCode());
/*    */     
/*    */ 
/*    */ 
/* 45 */     result = 31 * result + (this.jfPeriod == null ? 0 : this.jfPeriod.hashCode());
/*    */     
/* 47 */     result = 31 * result + (this.offerSide == null ? 0 : this.offerSide.hashCode());
/*    */     
/* 49 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 54 */     if (this == obj)
/* 55 */       return true;
/* 56 */     if (obj == null)
/* 57 */       return false;
/* 58 */     if (getClass() != obj.getClass())
/* 59 */       return false;
/* 60 */     FeedListenerKeyBean other = (FeedListenerKeyBean)obj;
/* 61 */     if (this.instrument == null) {
/* 62 */       if (other.instrument != null)
/* 63 */         return false;
/* 64 */     } else if (!this.instrument.equals(other.instrument))
/* 65 */       return false;
/* 66 */     if (this.interpolationDescriptor != other.interpolationDescriptor)
/* 67 */       return false;
/* 68 */     if (this.jfPeriod == null) {
/* 69 */       if (other.jfPeriod != null)
/* 70 */         return false;
/* 71 */     } else if (!this.jfPeriod.equals(other.jfPeriod))
/* 72 */       return false;
/* 73 */     if (this.offerSide != other.offerSide)
/* 74 */       return false;
/* 75 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\FeedListenerKeyBean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */