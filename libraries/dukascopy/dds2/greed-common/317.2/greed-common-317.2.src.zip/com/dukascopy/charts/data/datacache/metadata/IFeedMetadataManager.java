package com.dukascopy.charts.data.datacache.metadata;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.Period;
import com.dukascopy.api.PriceRange;
import com.dukascopy.api.ReversalAmount;
import com.dukascopy.api.TickBarSize;
import java.util.List;
import java.util.Set;

public abstract interface IFeedMetadataManager
{
  public abstract long getTimeOfFirstCandle(Instrument paramInstrument, Period paramPeriod);
  
  public abstract long getTimeOfFirstBar(Instrument paramInstrument, PriceRange paramPriceRange);
  
  public abstract long getTimeOfFirstBar(Instrument paramInstrument, PriceRange paramPriceRange, ReversalAmount paramReversalAmount);
  
  public abstract long getTimeOfFirstBar(Instrument paramInstrument, TickBarSize paramTickBarSize);
  
  public abstract long getTimeOfFirstTick(Instrument paramInstrument);
  
  public abstract List<Instrument> getSupportedInstruments();
  
  public abstract Set<String> getSupportedInstrumentsAsStr();
  
  public abstract void preloadCache();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\metadata\IFeedMetadataManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */