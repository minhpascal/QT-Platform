/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.IBar;
/*     */ import com.dukascopy.api.IContext;
/*     */ import com.dukascopy.api.IDownloadableStrategy.ComponentType;
/*     */ import com.dukascopy.api.IEngine.StrategyMode;
/*     */ import com.dukascopy.api.IMessage;
/*     */ import com.dukascopy.api.ISignal;
/*     */ import com.dukascopy.api.ITick;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.impl.connect.InternalStrategyController;
/*     */ import com.dukascopy.api.impl.connect.JForexEngineImpl;
/*     */ import com.dukascopy.api.impl.connect.StrategyTaskManager;
/*     */ import com.dukascopy.api.impl.util.CompiledComponentDownloader;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*     */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.InternalTesterCustodian;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.StrategyRunner;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterCustodian;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DownloadableStrategy implements com.dukascopy.api.IDownloadableStrategy
/*     */ {
/*  30 */   private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(DownloadableStrategy.class);
/*     */   protected final CompiledComponentDownloader downloader;
/*     */   private IContext mainContext;
/*     */   private com.dukascopy.api.IStrategy strategy;
/*     */   private InternalStrategyController internalStrategyController;
/*     */   private IEngine.StrategyMode mode;
/*     */   private String name;
/*     */   private String id;
/*     */   private IDownloadableStrategy.ComponentType type;
/*     */   private Map<String, Object> configurables;
/*     */   private byte[] codeBytes;
/*     */   
/*     */   public DownloadableStrategy(String id, String name, IContext context, IDownloadableStrategy.ComponentType type, IEngine.StrategyMode mode, Map<String, Object> configurables)
/*     */     throws JFException
/*     */   {
/*  45 */     this.name = name;
/*  46 */     this.id = id;
/*  47 */     this.mainContext = context;
/*  48 */     this.type = type;
/*  49 */     this.mode = mode;
/*  50 */     this.configurables = configurables;
/*  51 */     this.downloader = CompiledComponentDownloader.getInstance();
/*  52 */     this.codeBytes = null;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  56 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/*  61 */     return this.id;
/*     */   }
/*     */   
/*     */   public IDownloadableStrategy.ComponentType getComponentType()
/*     */   {
/*  66 */     return this.type;
/*     */   }
/*     */   
/*     */   public IEngine.StrategyMode getStrategyMode() {
/*  70 */     return this.mode;
/*     */   }
/*     */   
/*     */   public List<ISignal> onTick(Instrument instrument, ITick tick) throws JFException
/*     */   {
/*  75 */     return this.internalStrategyController.onTick(instrument, tick);
/*     */   }
/*     */   
/*     */   public List<ISignal> onBar(Instrument instrument, com.dukascopy.api.Period period, IBar askBar, IBar bidBar)
/*     */     throws JFException
/*     */   {
/*  81 */     return this.internalStrategyController.onBar(instrument, period, askBar, bidBar);
/*     */   }
/*     */   
/*     */   public List<ISignal> onMessage(IMessage message) throws JFException
/*     */   {
/*  86 */     return this.internalStrategyController.onMessage(message);
/*     */   }
/*     */   
/*     */   public void onAccount(com.dukascopy.api.IAccount account) throws JFException
/*     */   {
/*  91 */     this.internalStrategyController.onAccount(account);
/*     */   }
/*     */   
/*     */   public void onStop() throws JFException
/*     */   {
/*  96 */     this.internalStrategyController.onStop();
/*     */   }
/*     */   
/*     */   public void start() throws JFException
/*     */   {
/* 101 */     LOGGER.debug(MessageFormat.format("Downloading block {0} with type {1}", new Object[] { this.name, this.type }));
/*     */     try {
/* 103 */       java.security.AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*     */         public Object run() throws Exception {
/* 105 */           if ((DownloadableStrategy.this.type == IDownloadableStrategy.ComponentType.BLOCK_STRATEGY) || (DownloadableStrategy.this.type == IDownloadableStrategy.ComponentType.BLOCK_OWN_STRATEGY)) {
/* 106 */             DownloadableStrategy.this.codeBytes = DownloadableStrategy.this.downloader.downloadFile(DownloadableStrategy.this.id, DownloadableStrategy.this.type);
/*     */           } else {
/* 108 */             throw new JFException("Unknown component type " + DownloadableStrategy.this.type);
/*     */           }
/* 110 */           return null;
/*     */         }
/*     */       });
/*     */     } catch (PrivilegedActionException e) {
/* 114 */       throw new RuntimeException(e);
/*     */     }
/* 116 */     if (this.codeBytes == null) {
/* 117 */       throw new JFException(MessageFormat.format("Component {0} is empty", new Object[] { this.id }));
/*     */     }
/*     */     final JFXPack jfxPack;
/*     */     try
/*     */     {
/* 122 */       jfxPack = JFXPack.loadFromPack(this.codeBytes);
/*     */     } catch (Exception e) {
/* 124 */       throw new JFException(MessageFormat.format("Unable to init component {0}", new Object[] { this.id }), e);
/*     */     }
/*     */     try
/*     */     {
/* 128 */       java.security.AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */       {
/*     */         public Void run() throws JFException {
/* 131 */           if (jfxPack.isFullAccessRequested()) {
/* 132 */             jfxPack.setFullAccess(true);
/*     */           }
/*     */           
/* 135 */           DownloadableStrategy.this.strategy = ((com.dukascopy.api.IStrategy)jfxPack.getTarget());
/*     */           
/* 137 */           com.dukascopy.api.IEngine mainEngine = DownloadableStrategy.this.mainContext.getEngine();
/*     */           
/* 139 */           if ((mainEngine instanceof JForexEngineImpl)) {
/* 140 */             DownloadableStrategy.this.setupRealtime((JForexEngineImpl)mainEngine, DownloadableStrategy.this.configurables);
/* 141 */           } else if ((mainEngine instanceof TesterCustodian)) {
/* 142 */             DownloadableStrategy.this.setupTest((TesterCustodian)mainEngine, DownloadableStrategy.this.configurables);
/*     */           } else {
/* 144 */             throw new JFException("Unknown engine type");
/*     */           }
/*     */           
/* 147 */           return null;
/*     */         }
/*     */       });
/*     */     } catch (PrivilegedActionException e) {
/* 151 */       throw new JFException(MessageFormat.format("Unable to init component {0}", new Object[] { this.id }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void setupRealtime(JForexEngineImpl mainEngine, Map<String, Object> configurables)
/*     */     throws JFException
/*     */   {
/* 159 */     StrategyTaskManager taskManager = (StrategyTaskManager)mainEngine.getTaskManager();
/* 160 */     com.dukascopy.api.impl.connect.JForexInternalEngineImpl engine = new com.dukascopy.api.impl.connect.JForexInternalEngineImpl(taskManager, mainEngine.getAccount(), mainEngine.getType() == com.dukascopy.api.IEngine.Type.LIVE, mainEngine, this.mode);
/* 161 */     com.dukascopy.api.impl.connect.StrategyProcessor strategyProcessor = new com.dukascopy.api.impl.connect.StrategyProcessor(taskManager, this.strategy, true);
/* 162 */     IContext context = new com.dukascopy.api.impl.connect.JForexContextImpl(strategyProcessor, engine, (History)this.mainContext.getHistory(), this.mainContext.getConsole(), null, this.mainContext.getUserInterface(), null, null);
/*     */     
/* 164 */     this.internalStrategyController = new InternalStrategyController(this.strategy, context, mainEngine);
/* 165 */     this.internalStrategyController.startStrategy(configurables);
/* 166 */     this.internalStrategyController.onAccount(taskManager.getAccount());
/*     */   }
/*     */   
/*     */   private void setupTest(TesterCustodian mainEngine, Map<String, Object> configurables) throws JFException {
/* 170 */     StrategyRunner strategyRunner = (StrategyRunner)mainEngine.getStrategyRunner();
/*     */     
/* 172 */     Map<Instrument, Double> minTradableAmounts = new com.dukascopy.dds2.greed.agent.strategy.tester.MinTradableAmounts(Double.valueOf(1000.0D));
/*     */     
/*     */ 
/* 175 */     com.dukascopy.dds2.greed.agent.strategy.tester.TesterOrdersProvider testerOrdersProvider = mainEngine.getTesterOrdersProvider();
/*     */     
/* 177 */     com.dukascopy.api.system.IStrategyExceptionHandler strategyExceptionHandler = new com.dukascopy.api.system.IStrategyExceptionHandler()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void onException(long strategyId, IStrategyExceptionHandler.Source source, Throwable t) {}
/*     */ 
/*     */ 
/* 184 */     };
/* 185 */     Map<Instrument, ITick> firstTicks = new java.util.HashMap();
/* 186 */     for (Instrument instrument : this.mainContext.getSubscribedInstruments()) {
/* 187 */       firstTicks.put(instrument, mainEngine.getLastTicks()[instrument.ordinal()]);
/*     */     }
/*     */     
/* 190 */     com.dukascopy.dds2.greed.agent.strategy.tester.TesterReport testerReportData = strategyRunner.getReportData();
/*     */     
/* 192 */     InternalTesterCustodian engine = new InternalTesterCustodian(strategyRunner.getInstruments(), minTradableAmounts, NotificationUtilsProvider.getNotificationUtils(), strategyRunner.getFrom(), strategyRunner.getAccount(), firstTicks, testerReportData, strategyRunner, testerOrdersProvider, strategyExceptionHandler, mainEngine, this.mode);
/*     */     
/*     */ 
/*     */ 
/* 196 */     engine.setStrategy(this.strategy);
/*     */     
/* 198 */     IContext context = new com.dukascopy.dds2.greed.agent.strategy.tester.TesterConfig(engine, NotificationUtilsProvider.getNotificationUtils(), true, new java.util.HashMap(0), new com.dukascopy.dds2.greed.agent.strategy.tester.ExecutionControl() { public void pause() {} public void setSpeed(int value) {} }, testerOrdersProvider, new com.dukascopy.charts.data.datacache.ILoadingProgressListener()
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public boolean stopJob() {
/* 214 */         return false; } public void loadingFinished(boolean allDataLoaded, long start, long end, long currentPosition, Throwable e) {} public void dataLoaded(long start, long end, long currentPosition, String information) {} }, strategyRunner, strategyRunner.getAccount(), this.strategy, (com.dukascopy.dds2.greed.agent.strategy.tester.TesterHistory)this.mainContext.getHistory());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */     this.internalStrategyController = new InternalStrategyController(this.strategy, context, mainEngine);
/* 230 */     this.internalStrategyController.startStrategy(configurables);
/* 231 */     this.internalStrategyController.onAccount(strategyRunner.getAccount());
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\DownloadableStrategy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */