/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.AngleType;
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.complex.Complex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cos
/*    */   extends Trig
/*    */ {
/*    */   public Cos(AngleType angleType)
/*    */   {
/* 16 */     super(angleType);
/* 17 */     this.ftooltip = "sc.calculator.cosine.function";
/* 18 */     this.fshortcut = 'c';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 27 */     return Math.cos(x * this.scale);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 36 */     if ((x instanceof Complex)) {
/* 37 */       Complex c = (Complex)x;
/* 38 */       if ((this.scale != 1.0D) && (StrictMath.abs(c.imaginary()) > 1.0E-6D))
/* 39 */         throw new RuntimeException("Error");
/* 40 */       return c.scale(this.scale).cos();
/*    */     }
/* 42 */     return x.cos(this.angleType);
/*    */   }
/*    */   
/*    */   public String[] name_array()
/*    */   {
/* 47 */     return fname;
/*    */   }
/*    */   
/* 50 */   private static final String[] fname = { "c", "o", "s", " " };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Cos.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */