/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ public class Combination extends Dyadic<com.dukascopy.calculator.function.DFunction> {
/*    */   public Combination(OObject expression1, OObject expression2) {
/*  7 */     super(new com.dukascopy.calculator.function.Combination(), expression1, expression2);
/*    */   }
/*    */   
/*    */   public Product negate() {
/* 11 */     Product p = new Product(this, false);
/* 12 */     return p.negate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Combination.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */