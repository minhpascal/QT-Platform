/*    */ package com.dukascopy.charts.data.datacache.customperiod.tick;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.charts.data.datacache.listener.LoadingProgressListenerImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StopOnFirstTickLiveFeedListener
/*    */   extends FirstTickLiveFeedListener
/*    */ {
/*    */   private final LoadingProgressListenerImpl loadingProgressListener;
/*    */   
/*    */   public StopOnFirstTickLiveFeedListener(LoadingProgressListenerImpl loadingProgressListener)
/*    */   {
/* 19 */     this.loadingProgressListener = loadingProgressListener;
/*    */   }
/*    */   
/*    */   public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol)
/*    */   {
/* 24 */     super.newTick(instrument, time, ask, bid, askVol, bidVol);
/* 25 */     this.loadingProgressListener.setStopJob(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customperiod\tick\StopOnFirstTickLiveFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */