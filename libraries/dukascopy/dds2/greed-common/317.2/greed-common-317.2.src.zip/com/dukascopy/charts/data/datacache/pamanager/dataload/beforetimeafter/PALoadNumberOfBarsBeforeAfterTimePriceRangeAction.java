/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.beforetimeafter;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadClosestPriceRangeAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadToCachePriceRangeAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PANthPriceRangeFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PALoadByTimeIntervalPriceRangeAction;
/*     */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeCreator;
/*     */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PALoadNumberOfBarsBeforeAfterTimePriceRangeAction
/*     */   extends PAAbstractLoadNumOfBarsBeforeAfterTimeAction<PriceRangeData, IPriceRangeLiveFeedListener, IPriceRangeCreator, PALoadToCachePriceRangeAction, PALoadByTimeIntervalPriceRangeAction>
/*     */ {
/*     */   public PALoadNumberOfBarsBeforeAfterTimePriceRangeAction(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int numOfBarsBefore, long time, int numOfBarsAfter, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, IPriceRangeLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  53 */     super(cacheManager, instrument, interpolationDescriptor, side, jfPeriod, numOfBarsBefore, time, numOfBarsAfter, fireUncompletedLastBasePeriodBars, infinitBasePeriod, version, listener, loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected IPriceRangeLiveFeedListener createOneBarListener(final List<PriceRangeData> oneBarList)
/*     */   {
/*  73 */     new IPriceRangeLiveFeedListener()
/*     */     {
/*     */       public void newPriceData(PriceRangeData data) {
/*  76 */         oneBarList.add(data);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   protected PALoadByTimeIntervalPriceRangeAction createLoadIntervalAction(long timeFrom, long timeTo, ILoadingProgressListener loadingProgressListener) throws DataCacheException
/*     */   {
/*  83 */     return new PALoadByTimeIntervalPriceRangeAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), timeFrom, timeTo, isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), (IPriceRangeLiveFeedListener)getListener(), loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PALoadClosestPriceRangeAction createLoadClosestAction(IPriceRangeLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 101 */     PALoadClosestPriceRangeAction action = new PALoadClosestPriceRangeAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), getTime(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), listener, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     return action;
/*     */   }
/*     */   
/*     */ 
/*     */   protected PANthPriceRangeFromSeedBarAction createNthBarFromSeedAction(PriceRangeData timedBar, IPriceRangeLiveFeedListener oneBarListener, boolean lookLeft, ILoadingProgressListener loadingProgressListener)
/*     */   {
/* 120 */     PANthPriceRangeFromSeedBarAction action = new PANthPriceRangeFromSeedBarAction(getCacheManager(), getVersion(), getNumOfBarsBefore(), timedBar, getNumOfBarsAfter(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), lookLeft, loadingProgressListener, oneBarListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */     return action;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\beforetimeafter\PALoadNumberOfBarsBeforeAfterTimePriceRangeAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */