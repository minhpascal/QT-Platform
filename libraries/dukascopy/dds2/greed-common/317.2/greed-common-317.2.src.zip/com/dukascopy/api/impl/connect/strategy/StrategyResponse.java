/*    */ package com.dukascopy.api.impl.connect.strategy;
/*    */ 
/*    */ import com.dukascopy.api.strategy.IStrategyResponse;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class StrategyResponse<T> implements IStrategyResponse<T>
/*    */ {
/*    */   private final T value;
/*    */   private final boolean isError;
/*    */   private final String errorMessage;
/*    */   
/*    */   public static <T> IStrategyResponse<T> newOkResponse(T value)
/*    */   {
/* 14 */     return new StrategyResponse(value, false, null);
/*    */   }
/*    */   
/*    */   public static <T> IStrategyResponse<T> newOkResponse(T value, Class<T> clazz) {
/* 18 */     return new StrategyResponse(value, false, null);
/*    */   }
/*    */   
/*    */   public static <T> IStrategyResponse<T> newErrorRespnose(String message) {
/* 22 */     return new StrategyResponse(null, true, message);
/*    */   }
/*    */   
/*    */   public static <T> IStrategyResponse<T> newErrorResponse(Exception e, Map<?, IStrategyResponse<T>> map) {
/* 26 */     return newErrorRespnose(e.getMessage());
/*    */   }
/*    */   
/*    */   private StrategyResponse(T t, boolean isError, String message) {
/* 30 */     this.value = t;
/* 31 */     this.isError = isError;
/* 32 */     this.errorMessage = message;
/*    */   }
/*    */   
/*    */   public T getResult()
/*    */   {
/* 37 */     return (T)this.value;
/*    */   }
/*    */   
/*    */   public boolean isError()
/*    */   {
/* 42 */     return this.isError;
/*    */   }
/*    */   
/*    */   public String getErrorMessage()
/*    */   {
/* 47 */     return this.errorMessage;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     return "RemoteResponse " + this.value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 59 */     int prime = 31;
/* 60 */     int result = 1;
/* 61 */     result = 31 * result + (this.errorMessage == null ? 0 : this.errorMessage.hashCode());
/* 62 */     result = 31 * result + (this.value == null ? 0 : this.value.hashCode());
/* 63 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 68 */     if (this == obj)
/* 69 */       return true;
/* 70 */     if (obj == null)
/* 71 */       return false;
/* 72 */     if (getClass() != obj.getClass())
/* 73 */       return false;
/* 74 */     StrategyResponse<?> other = (StrategyResponse)obj;
/* 75 */     if (this.errorMessage == null) {
/* 76 */       if (other.errorMessage != null)
/* 77 */         return false;
/* 78 */     } else if (!this.errorMessage.equals(other.errorMessage))
/* 79 */       return false;
/* 80 */     if (this.value == null) {
/* 81 */       if (other.value != null)
/* 82 */         return false;
/* 83 */     } else if (!this.value.equals(other.value))
/* 84 */       return false;
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\StrategyResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */