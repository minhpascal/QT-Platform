/*     */ package com.dukascopy.api.impl.connect.strategy.local;
/*     */ 
/*     */ import com.dukascopy.api.IStrategy;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.impl.connect.DCClientImpl;
/*     */ import com.dukascopy.api.impl.connect.strategy.StrategyResponse;
/*     */ import com.dukascopy.api.strategy.IStrategyParameter;
/*     */ import com.dukascopy.api.strategy.IStrategyResponse;
/*     */ import com.dukascopy.api.strategy.local.ILocalStrategyDescriptor;
/*     */ import com.dukascopy.api.strategy.local.LocalStrategyListener;
/*     */ import com.dukascopy.api.system.ClientFactory;
/*     */ import com.dukascopy.api.system.IClient;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.bean.IJFRunnablesListener;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.bean.StrategyNewBean;
/*     */ import com.dukascopy.dds2.greed.util.ParameterUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.commons.lang3.concurrent.ConcurrentUtils;
/*     */ 
/*     */ public class SdkStrategyManager
/*     */   extends LocalStrategyManager
/*     */ {
/*     */   private static SdkStrategyManager LocalStrategyManager;
/*     */   private IClient client;
/*  34 */   private final Map<UUID, File> stratFileMap = new HashMap();
/*     */   
/*     */   public static SdkStrategyManager getInstance() {
/*  37 */     if (LocalStrategyManager == null) {
/*  38 */       LocalStrategyManager = new SdkStrategyManager();
/*     */     }
/*  40 */     return LocalStrategyManager;
/*     */   }
/*     */   
/*     */   protected void setup()
/*     */   {
/*     */     try
/*     */     {
/*  47 */       this.client = ClientFactory.getDefaultInstance();
/*     */     } catch (Exception e) {
/*  49 */       throw new RuntimeException(e);
/*     */     }
/*     */     
/*  52 */     this.jfRunnablesListener = new IJFRunnablesListener()
/*     */     {
/*     */       public void onStrategyStart(long processId, StrategyNewBean bean)
/*     */       {
/*  56 */         for (LocalStrategyListener l : SdkStrategyManager.this.strategyListeners) {
/*  57 */           if (bean.getBinaryFile() == null) {
/*  58 */             synchronized (SdkStrategyManager.this.stratFileMap) {
/*  59 */               bean.setBinaryFile((File)SdkStrategyManager.this.stratFileMap.get(SdkStrategyManager.this.getUUID(processId)));
/*     */             }
/*     */           }
/*  62 */           l.onStrategyRun(new LocalStrategyDescriptor(processId, bean));
/*     */         }
/*     */       }
/*     */       
/*     */       public void onStrategyStop(long processId, StrategyNewBean bean)
/*     */       {
/*  68 */         UUID requestId = SdkStrategyManager.this.getUUID(processId);
/*  69 */         SdkStrategyManager.this.processResponse(SdkStrategyManager.this.stratStopMap, requestId, new Callable()
/*     */         {
/*     */           public IStrategyResponse<Void> call() throws Exception {
/*  72 */             return StrategyResponse.newOkResponse(null);
/*     */           }
/*     */         });
/*  75 */         for (LocalStrategyListener l : SdkStrategyManager.this.strategyListeners) {
/*  76 */           l.onStrategyStop(new LocalStrategyDescriptor(processId, bean));
/*     */         }
/*     */         
/*     */       }
/*  80 */     };
/*  81 */     ((DCClientImpl)this.client).addJFRunnablesListener(this.jfRunnablesListener);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void dispose()
/*     */   {
/*  87 */     ((DCClientImpl)this.client).removeJFRunnablesListener(this.jfRunnablesListener);
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile) throws IOException
/*     */   {
/*     */     try {
/*  93 */       return startStrategy(strategyFile, null);
/*     */     } catch (JFException e) {}
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile, Object[] params) throws IOException, JFException
/*     */   {
/*     */     StrategyNewBean bean;
/*     */     try
/*     */     {
/* 103 */       bean = StrategyNewBean.createRunnableBean(strategyFile);
/* 104 */       if ((params != null) && (params.length > 0)) {
/* 105 */         bean.setConfigurables(params);
/*     */       }
/*     */     } catch (Exception e1) {
/* 108 */       throw new JFException(e1);
/*     */     }
/* 110 */     synchronized (this.stratFileMap) {
/* 111 */       long id = this.client.startStrategy((IStrategy)bean.getJFRunnable());
/* 112 */       UUID uuid = getUUID(id);
/* 113 */       this.stratFileMap.put(uuid, strategyFile);
/* 114 */       return ConcurrentUtils.constantFuture(StrategyResponse.newOkResponse(uuid));
/*     */     }
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<Void>> stopStrategy(UUID processId)
/*     */   {
/* 120 */     this.client.stopStrategy(processId.getMostSignificantBits());
/* 121 */     return ConcurrentUtils.constantFuture(StrategyResponse.newOkResponse(null, Void.class));
/*     */   }
/*     */   
/*     */   public Future<IStrategyResponse<Set<ILocalStrategyDescriptor>>> getStartedStrategies()
/*     */   {
/* 126 */     String requestId = null;
/* 127 */     Set<ILocalStrategyDescriptor> strats = new HashSet();
/* 128 */     for (Map.Entry<Long, IStrategy> entry : this.client.getStartedStrategies().entrySet()) {
/* 129 */       IStrategy strat = (IStrategy)entry.getValue();
/* 130 */       List<IStrategyParameter> params = ParameterUtils.getParameters(strat);
/* 131 */       UUID uuid = getUUID(((Long)entry.getKey()).longValue());
/*     */       
/* 133 */       strats.add(new LocalStrategyDescriptor(strat.getClass().getSimpleName(), 0L, params, uuid, requestId, (File)this.stratFileMap.get(uuid)));
/*     */     }
/* 135 */     return ConcurrentUtils.constantFuture(StrategyResponse.newOkResponse(strats));
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\local\SdkStrategyManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */