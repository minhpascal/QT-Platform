package com.dukascopy.charts.data.datacache.listener;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.OfferSide;
import com.dukascopy.api.Period;

public abstract interface CandleFeedListener
{
  public abstract void newCandle(Instrument paramInstrument, Period paramPeriod, OfferSide paramOfferSide, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\listener\CandleFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */