/*    */ package com.dukascopy.charts.data.datacache.intraperiod.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*    */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationLiveFeedListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LastAbstractPriceAggregationLiveFeedListener<T extends AbstractPriceAggregationData>
/*    */   implements IPriceAggregationLiveFeedListener<T>
/*    */ {
/*    */   private T lastData;
/*    */   
/*    */   public void newPriceData(T pointAndFigure)
/*    */   {
/* 19 */     this.lastData = pointAndFigure;
/*    */   }
/*    */   
/*    */   public T getLastData() {
/* 23 */     return this.lastData;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\listener\LastAbstractPriceAggregationLiveFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */