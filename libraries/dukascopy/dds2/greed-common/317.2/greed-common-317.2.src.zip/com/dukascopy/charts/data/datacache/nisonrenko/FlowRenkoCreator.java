/*    */ package com.dukascopy.charts.data.datacache.nisonrenko;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlowRenkoCreator
/*    */   extends RenkoCreator
/*    */ {
/*    */   public FlowRenkoCreator(Instrument instrument, OfferSide offerSide, JForexPeriod jfPeriod, boolean isInfinity)
/*    */   {
/* 22 */     super(instrument, offerSide, jfPeriod, -1, true, true, isInfinity);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isAllDesiredDataLoaded()
/*    */   {
/* 35 */     return false;
/*    */   }
/*    */   
/*    */   protected void resetResulArray()
/*    */   {
/* 40 */     this.result = new RenkoData[1];
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 45 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\nisonrenko\FlowRenkoCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */