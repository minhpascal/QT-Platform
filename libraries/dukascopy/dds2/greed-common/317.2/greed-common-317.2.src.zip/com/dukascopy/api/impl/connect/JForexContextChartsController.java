/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IChart;
/*     */ import com.dukascopy.api.IClientGUI;
/*     */ import com.dukascopy.api.IClientGUIListener;
/*     */ import com.dukascopy.api.IStrategyListener;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import com.dukascopy.charts.main.interfaces.IClientChartTabsAndFramesController;
/*     */ import com.dukascopy.charts.main.interfaces.IContextChartsController;
/*     */ import com.dukascopy.charts.persistence.ChartBean;
/*     */ import com.dukascopy.charts.persistence.IdManager;
/*     */ import com.dukascopy.charts.utils.ChartUtils;
/*     */ import com.dukascopy.charts.wrapper.DelegatableChartWrapper;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.swing.JPanel;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JForexContextChartsController
/*     */   implements IContextChartsController
/*     */ {
/*  46 */   private static final Logger LOGGER = LoggerFactory.getLogger(JForexContextChartsController.class);
/*     */   
/*     */   private final String callerId;
/*     */   
/*     */   private final DDSChartsController chartsController;
/*     */   
/*     */   private final JForexTaskManager jForexTaskManager;
/*     */   
/*     */   private final JForexTaskManager.Environment environment;
/*     */   
/*     */   private final IClientGUIListener clientGUIListener;
/*     */   
/*     */   private final Map<IChart, IClientGUI> clientGuiByCharts;
/*     */   private final Map<IChart, DelegatableChartWrapper> delegatableChartWrappers;
/*     */   
/*     */   public JForexContextChartsController(DDSChartsController chartsController, JForexTaskManager jForexTaskManager, IClientGUIListener clientGUIListener, String callerId)
/*     */   {
/*  63 */     this.callerId = callerId;
/*  64 */     this.chartsController = chartsController;
/*  65 */     this.jForexTaskManager = jForexTaskManager;
/*  66 */     this.environment = (jForexTaskManager != null ? jForexTaskManager.getEnvironment() : JForexTaskManager.Environment.LOCAL_EMBEDDED);
/*     */     
/*  68 */     this.clientGUIListener = clientGUIListener;
/*  69 */     this.clientGuiByCharts = new ConcurrentHashMap();
/*  70 */     this.delegatableChartWrappers = new ConcurrentHashMap();
/*     */     
/*  72 */     applyStopStrategyChartWrappersNotification();
/*     */   }
/*     */   
/*     */ 
/*     */   private void applyStopStrategyChartWrappersNotification()
/*     */   {
/*  78 */     if (this.jForexTaskManager != null) {
/*  79 */       this.jForexTaskManager.addStrategyListener(new IStrategyListener()
/*     */       {
/*     */ 
/*     */         public void onStop(long strategyId)
/*     */         {
/*  84 */           for (Map.Entry<IChart, DelegatableChartWrapper> entry : JForexContextChartsController.this.delegatableChartWrappers.entrySet()) {
/*  85 */             ((DelegatableChartWrapper)entry.getValue()).shutdown();
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         public void onStart(long strategyId) {}
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IChart getChart(Instrument instrument)
/*     */   {
/* 102 */     if (this.chartsController != null) {
/* 103 */       IChart chart = this.chartsController.getIChartBy(instrument);
/* 104 */       return getOrCreate(chart);
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<IChart> getCharts(Instrument instrument)
/*     */   {
/* 115 */     if (this.chartsController == null) {
/* 116 */       return Collections.emptySet();
/*     */     }
/* 118 */     Set<IChart> charts = this.chartsController.getICharts(instrument);
/* 119 */     if (ObjectUtils.isNullOrEmpty(charts)) {
/* 120 */       return Collections.emptySet();
/*     */     }
/* 122 */     Set<IChart> result = new HashSet();
/* 123 */     for (IChart chart : charts) {
/* 124 */       IChart wrapper = getOrCreate(chart);
/* 125 */       result.add(wrapper);
/*     */     }
/* 127 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<IChart> getCharts()
/*     */   {
/* 133 */     if (this.chartsController == null) {
/* 134 */       return Collections.emptySet();
/*     */     }
/* 136 */     Set<IChart> charts = this.chartsController.getICharts();
/* 137 */     if (ObjectUtils.isNullOrEmpty(charts)) {
/* 138 */       return charts;
/*     */     }
/* 140 */     Set<IChart> result = new HashSet();
/* 141 */     for (IChart chart : charts) {
/* 142 */       IChart wrapper = getOrCreate(chart);
/* 143 */       result.add(wrapper);
/*     */     }
/* 145 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IChart getLastActiveChart()
/*     */   {
/* 153 */     IChart chart = null;
/* 154 */     if (this.chartsController != null) {
/* 155 */       chart = this.chartsController.getLastActiveIChart();
/* 156 */       return getOrCreate(chart);
/*     */     }
/* 158 */     return chart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IChart openChart(final IFeedDescriptor feedDescriptor)
/*     */   {
/* 166 */     if (feedDescriptor == null) {
/* 167 */       throw new IllegalArgumentException("Specified FeedDescriptor is null.");
/*     */     }
/* 169 */     if (this.chartsController != null) {
/*     */       try {
/* 171 */         (IChart)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public IChart run() throws Exception
/*     */           {
/* 175 */             int chartId = -1;
/*     */             
/* 177 */             if ((ObjectUtils.isEqual(JForexContextChartsController.this.environment, JForexTaskManager.Environment.LOCAL_JFOREX)) && (JForexContextChartsController.this.chartsController.getTabsAndFramesController() != null)) {
/* 178 */               IClientChartTabsAndFramesController tabsAndFramesController = JForexContextChartsController.this.chartsController.getTabsAndFramesController();
/* 179 */               chartId = tabsAndFramesController.addChart(feedDescriptor);
/* 180 */             } else if (ObjectUtils.isEqual(JForexContextChartsController.this.environment, JForexTaskManager.Environment.LOCAL_EMBEDDED)) {
/* 181 */               chartId = IdManager.getInstance().getNextChartId();
/* 182 */               IdManager.getInstance().reserveChartId(chartId);
/* 183 */               JForexContextChartsController.this.chartsController.changeFilter(feedDescriptor.getFilter());
/* 184 */               JForexPeriod jForexPeriod = JForexPeriod.createJForexPeriod(feedDescriptor);
/* 185 */               OfferSide offerSide = feedDescriptor.getOfferSide() == null ? OfferSide.BID : feedDescriptor.getOfferSide();
/* 186 */               final ChartBean chartBean = new ChartBean(chartId, feedDescriptor.getInstrument(), jForexPeriod, offerSide);
/* 187 */               chartBean.setReadOnly(true);
/* 188 */               Runnable dataLoadingStarter = new Runnable() {
/*     */                 public void run() {
/* 190 */                   JForexContextChartsController.this.chartsController.startLoadingData(Integer.valueOf(chartBean.getId()), chartBean.getAutoShiftActiveAsBoolean(), chartBean.getChartShiftInPx());
/*     */                 }
/* 192 */               };
/* 193 */               chartBean.setStartLoadingDataRunnable(dataLoadingStarter);
/* 194 */               JPanel chartPanel = JForexContextChartsController.this.chartsController.createNewChartOrGetById(chartBean);
/* 195 */               ChartUtils.setWaterMarkSign(chartPanel);
/*     */             }
/* 197 */             IChart chart = JForexContextChartsController.this.chartsController.getIChartBy(Integer.valueOf(chartId));
/* 198 */             chart = JForexContextChartsController.this.getOrCreate(chart);
/* 199 */             if (JForexContextChartsController.this.clientGUIListener != null) {
/* 200 */               IClientGUI clientGUI = JForexContextChartsController.this.getClientGUI(chart);
/* 201 */               JForexContextChartsController.this.clientGUIListener.onOpenChart(clientGUI);
/*     */             }
/* 203 */             return chart;
/*     */           }
/*     */         });
/*     */       } catch (PrivilegedActionException e) {
/* 207 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/* 210 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeChart(final IChart chart)
/*     */   {
/* 218 */     if (chart == null) {
/* 219 */       throw new IllegalArgumentException("Specified charts is null.");
/*     */     }
/*     */     
/* 222 */     if (this.chartsController != null) {
/*     */       try {
/* 224 */         AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public Void run() throws Exception {
/* 227 */             if ((ObjectUtils.isEqual(JForexContextChartsController.this.environment, JForexTaskManager.Environment.LOCAL_JFOREX)) && (JForexContextChartsController.this.chartsController.getTabsAndFramesController() != null)) {
/* 228 */               IClientChartTabsAndFramesController tabsAndFramesController = JForexContextChartsController.this.chartsController.getTabsAndFramesController();
/* 229 */               tabsAndFramesController.closeChart(JForexContextChartsController.this.getChartId(chart));
/*     */             } else {
/* 231 */               JForexContextChartsController.this.chartsController.removeChart(Integer.valueOf(JForexContextChartsController.this.getChartId(chart)));
/* 232 */               if (JForexContextChartsController.this.clientGUIListener != null) {
/* 233 */                 JForexContextChartsController.this.clientGUIListener.onCloseChart(chart);
/*     */               }
/*     */             }
/* 236 */             return null;
/*     */           }
/*     */         });
/*     */       } catch (PrivilegedActionException e) {
/* 240 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JPanel getChartPanel(IChart chart)
/*     */   {
/* 250 */     JPanel chartPanel = null;
/* 251 */     if ((ObjectUtils.isEqual(this.environment, JForexTaskManager.Environment.LOCAL_EMBEDDED)) && (this.chartsController != null)) {
/* 252 */       chartPanel = this.chartsController.getChartPanel(Integer.valueOf(getChartId(chart)));
/* 253 */     } else if (ObjectUtils.isEqual(this.environment, JForexTaskManager.Environment.LOCAL_JFOREX)) {
/* 254 */       LOGGER.warn("There is no access to embedded chart panel from JForex Platform");
/*     */     } else {
/* 256 */       LOGGER.warn("It's not designed to open chart's panels on Remote Server");
/*     */     }
/* 258 */     return chartPanel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IClientGUI getClientGUI(IChart chart)
/*     */   {
/* 267 */     IClientGUI clientGUI = null;
/* 268 */     if ((ObjectUtils.isEqual(this.environment, JForexTaskManager.Environment.LOCAL_EMBEDDED)) && (this.chartsController != null)) {
/* 269 */       if (chart != null) {
/* 270 */         clientGUI = (IClientGUI)this.clientGuiByCharts.get(chart);
/* 271 */         if (clientGUI == null) {
/* 272 */           clientGUI = new ClientGUI(chart, this);
/* 273 */           this.clientGuiByCharts.put(chart, clientGUI);
/*     */         }
/*     */       }
/* 276 */     } else if (ObjectUtils.isEqual(this.environment, JForexTaskManager.Environment.LOCAL_JFOREX)) {
/* 277 */       LOGGER.warn("There is no access to embedded chart panel from JForex Platform");
/*     */     } else {
/* 279 */       LOGGER.warn("It's not designed to open chart's panels on Remote Server");
/*     */     }
/* 281 */     return clientGUI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DDSChartsController getChartsController()
/*     */   {
/* 289 */     return this.chartsController;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getChartId(IChart chart)
/*     */   {
/*     */     IChart testee;
/*     */     
/* 297 */     if (chart != null) {
/* 298 */       testee = chart;
/* 299 */       if ((chart instanceof DelegatableChartWrapper)) {
/* 300 */         testee = ((DelegatableChartWrapper)DelegatableChartWrapper.class.cast(chart)).getDelegate();
/*     */       }
/* 302 */       Set<Integer> ids = this.chartsController.getChartControllerIdies();
/*     */       
/* 304 */       for (Integer id : ids) {
/* 305 */         IChart iChart = this.chartsController.getIChartBy(id);
/* 306 */         if (iChart.equals(testee)) {
/* 307 */           return id.intValue();
/*     */         }
/*     */       }
/*     */     }
/* 311 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JForexTaskManager.Environment getEnvironment()
/*     */   {
/* 319 */     return this.environment;
/*     */   }
/*     */   
/*     */   private IChart getOrCreate(IChart chart) {
/* 323 */     DelegatableChartWrapper wrapper = null;
/* 324 */     if (chart != null) {
/* 325 */       wrapper = (DelegatableChartWrapper)this.delegatableChartWrappers.get(chart);
/* 326 */       if (wrapper == null)
/*     */       {
/*     */ 
/*     */ 
/* 330 */         wrapper = new DelegatableChartWrapper(chart, this.callerId, this.jForexTaskManager);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 335 */         this.delegatableChartWrappers.put(chart, wrapper);
/*     */       }
/*     */     }
/* 338 */     return wrapper;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexContextChartsController.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */