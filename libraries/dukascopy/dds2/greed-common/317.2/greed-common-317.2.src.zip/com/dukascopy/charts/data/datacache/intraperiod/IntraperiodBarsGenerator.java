/*      */ package com.dukascopy.charts.data.datacache.intraperiod;
/*      */ 
/*      */ import com.dukascopy.api.DataType;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.Period;
/*      */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*      */ import com.dukascopy.api.feed.IFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.PointAndFigureFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.RenkoFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TickBarFeedDescriptor;
/*      */ import com.dukascopy.charts.data.datacache.CandleData;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*      */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*      */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*      */ import com.dukascopy.charts.data.datacache.TickData;
/*      */ import com.dukascopy.charts.data.datacache.intraperiod.listener.LastPointAndFigureLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.intraperiod.listener.LastPriceRangeLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.intraperiod.listener.LastRenkoLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.intraperiod.listener.LastTickBarLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.nisonrenko.FlowRenkoCreator;
/*      */ import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoCreator;
/*      */ import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.nisonrenko.RenkoData;
/*      */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*      */ import com.dukascopy.charts.data.datacache.pamanager.dataload.intra.PALoadInProgressPointAndFigureAction;
/*      */ import com.dukascopy.charts.data.datacache.pamanager.dataload.intra.PALoadInProgressPriceRangeAction;
/*      */ import com.dukascopy.charts.data.datacache.pamanager.dataload.intra.PALoadInProgressRenkoAction;
/*      */ import com.dukascopy.charts.data.datacache.pamanager.dataload.intra.PALoadInProgressTickBarAction;
/*      */ import com.dukascopy.charts.data.datacache.pnf.FlowPointAndFigureCreator;
/*      */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureCreator;
/*      */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
/*      */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureLiveFeedAdapter;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationCreator;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.dataprovider.IPriceAggregationDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.FlowPriceRangeCreator;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeCreator;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
/*      */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeLiveFeedAdapter;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.FlowTickBarCreator;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarCreator;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.TickBarData;
/*      */ import com.dukascopy.charts.data.datacache.tickbar.TickBarLiveFeedAdapter;
/*      */ import com.dukascopy.charts.math.dataprovider.priceaggregation.buffer.ITimedDataShiftableBuffer;
/*      */ import com.dukascopy.charts.math.dataprovider.priceaggregation.buffer.SynchronizedTimedDataShiftableBuffer;
/*      */ import com.dukascopy.charts.utils.map.IThreeKeyMap;
/*      */ import com.dukascopy.charts.utils.map.ITwoKeyMap;
/*      */ import com.dukascopy.charts.utils.map.SynchronizedThreeKeyMap;
/*      */ import com.dukascopy.charts.utils.map.SynchronizedTwoKeyMap;
/*      */ import com.dukascopy.charts.utils.map.entry.ITwoKeyEntry;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterFeedDataProvider;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ArrayBlockingQueue;
/*      */ import java.util.concurrent.BlockingQueue;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class IntraperiodBarsGenerator
/*      */   implements IIntraperiodBarsGenerator
/*      */ {
/*   90 */   private static final Logger LOGGER = LoggerFactory.getLogger(IntraperiodBarsGenerator.class);
/*      */   
/*   92 */   private static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
/*      */   
/*   94 */   static { DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT")); }
/*      */   
/*      */ 
/*      */ 
/*      */   private final IPACacheManager paCacheManager;
/*      */   
/*  100 */   private final ITwoKeyMap<RangeBarFeedDescriptor, DataInterpolationDescriptor, IPriceRangeCreator> inProgressPriceRangeCreatorsMap = new SynchronizedTwoKeyMap();
/*  101 */   private final ITwoKeyMap<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, IPointAndFigureCreator> inProgressPointAndFigureCreatorsMap = new SynchronizedTwoKeyMap();
/*  102 */   private final Map<TickBarFeedDescriptor, ITickBarCreator> inProgressTickBarCreatorsMap = Collections.synchronizedMap(new HashMap());
/*  103 */   private final Map<RenkoFeedDescriptor, IRenkoCreator> inProgressRenkoCreatorsMap = Collections.synchronizedMap(new HashMap());
/*      */   
/*      */ 
/*  106 */   private final ITwoKeyMap<RangeBarFeedDescriptor, DataInterpolationDescriptor, List<IPriceRangeLiveFeedListener>> inProgressPriceRangeLiveFeedListenersMap = new SynchronizedTwoKeyMap();
/*  107 */   private final ITwoKeyMap<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, List<IPointAndFigureLiveFeedListener>> inProgressPointAndFigureListenersMap = new SynchronizedTwoKeyMap();
/*  108 */   private final Map<TickBarFeedDescriptor, List<ITickBarLiveFeedListener>> inProgressTickBarLiveFeedListenersMap = Collections.synchronizedMap(new HashMap());
/*  109 */   private final Map<RenkoFeedDescriptor, List<IRenkoLiveFeedListener>> inProgressRenkoLiveFeedListenersMap = Collections.synchronizedMap(new HashMap());
/*      */   
/*      */ 
/*  112 */   private final ITwoKeyMap<RangeBarFeedDescriptor, DataInterpolationDescriptor, List<IPriceRangeLiveFeedListener>> priceRangeNotificationListenersMap = new SynchronizedTwoKeyMap();
/*  113 */   private final ITwoKeyMap<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, List<IPointAndFigureLiveFeedListener>> pointAndFigureNotificationListenersMap = new SynchronizedTwoKeyMap();
/*  114 */   private final Map<TickBarFeedDescriptor, List<ITickBarLiveFeedListener>> tickBarNotificationListenersMap = Collections.synchronizedMap(new HashMap());
/*  115 */   private final Map<RenkoFeedDescriptor, List<IRenkoLiveFeedListener>> renkoNotificationListenersMap = Collections.synchronizedMap(new HashMap());
/*      */   
/*      */ 
/*  118 */   private final ITwoKeyMap<RangeBarFeedDescriptor, DataInterpolationDescriptor, IPriceRangeLiveFeedListener> priceRangeCompletedInProgressBarsListenersMap = new SynchronizedTwoKeyMap();
/*  119 */   private final ITwoKeyMap<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, IPointAndFigureLiveFeedListener> pointAndFigureCompletedInProgressBarsListenersMap = new SynchronizedTwoKeyMap();
/*  120 */   private final Map<TickBarFeedDescriptor, ITickBarLiveFeedListener> tickBarCompletedInProgressBarsListenersMap = Collections.synchronizedMap(new HashMap());
/*  121 */   private final Map<RenkoFeedDescriptor, IRenkoLiveFeedListener> renkoBarCompletedInProgressBarsListenersMap = Collections.synchronizedMap(new HashMap());
/*      */   
/*  123 */   private final Map<FeedListenerKeyBean, LinkedList<IPriceAggregationLiveFeedListener>> listenersWaitingForInProgressBarMap = new HashMap();
/*      */   
/*      */ 
/*  126 */   private final Map<RenkoFeedDescriptor, LiveFeedListener> renkoCompletedInProgressCandlesListener = Collections.synchronizedMap(new HashMap());
/*  127 */   private final Map<RenkoFeedDescriptor, LiveFeedListener> renkoInProgressCandlesListener = Collections.synchronizedMap(new HashMap());
/*      */   
/*      */ 
/*  130 */   private final ITwoKeyMap<IFeedDescriptor, DataInterpolationDescriptor, List<LastBarLoadingProgressListener>> lastBarLoadingProgressListeners = new SynchronizedTwoKeyMap();
/*      */   
/*      */   private final IPriceAggregationDataProvider priceAggregationDataProvider;
/*      */   private final ExecutorService actionsExecutorService;
/*  134 */   private final BlockingQueue<Runnable> queue = new ArrayBlockingQueue(15 + Instrument.values().length * 3, true);
/*      */   
/*  136 */   private final Map<Instrument, ITimedDataShiftableBuffer<TickData>> lastReceivedTicksMap = new HashMap();
/*  137 */   private final IThreeKeyMap<Instrument, OfferSide, Period, ITimedDataShiftableBuffer<CandleData>> lastReceivedCandlesMap = new SynchronizedThreeKeyMap();
/*      */   
/*      */   public IntraperiodBarsGenerator(IPriceAggregationDataProvider priceAggregationDataProvider)
/*      */   {
/*  141 */     this.priceAggregationDataProvider = priceAggregationDataProvider;
/*  142 */     this.actionsExecutorService = new ThreadPoolExecutor(5, 10, 60L, TimeUnit.SECONDS, this.queue);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  149 */     this.paCacheManager = this.priceAggregationDataProvider.getFeedDataProvider().getPACacheManager();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void processTickForTickBars(Instrument instrument, TickData tickData)
/*      */   {
/*  156 */     for (Map.Entry<TickBarFeedDescriptor, ITickBarCreator> entry : this.inProgressTickBarCreatorsMap.entrySet()) {
/*  157 */       if (((TickBarFeedDescriptor)entry.getKey()).getInstrument().equals(instrument)) {
/*  158 */         if ((entry.getValue() != null) && (((ITickBarCreator)entry.getValue()).getLastData() != null))
/*      */         {
/*      */ 
/*      */ 
/*  162 */           analyseTick((ITickBarCreator)entry.getValue(), tickData, (TickBarFeedDescriptor)entry.getKey());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void analyseTick(ITickBarCreator creator, TickData tick, TickBarFeedDescriptor descriptor)
/*      */   {
/*  172 */     boolean currentBarFormingFinished = creator.analyse(tick);
/*  173 */     if (!currentBarFormingFinished) {
/*  174 */       fireInProgressTickBarUpdated(descriptor, (TickBarData)createClone(creator.getLastData()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processTickForPointAndFigures(Instrument instrument, TickData tickData)
/*      */   {
/*  183 */     Set<ITwoKeyEntry<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, IPointAndFigureCreator>> entrySet = this.inProgressPointAndFigureCreatorsMap.entrySet();
/*      */     
/*  185 */     for (ITwoKeyEntry<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, IPointAndFigureCreator> entry : entrySet) {
/*  186 */       if (((PointAndFigureFeedDescriptor)entry.getKey1()).getInstrument().equals(instrument)) {
/*  187 */         IPointAndFigureCreator creator = (IPointAndFigureCreator)entry.getValue();
/*  188 */         if ((creator != null) && (creator.getLastData() != null))
/*      */         {
/*      */ 
/*      */ 
/*  192 */           analyseTick(creator, tickData, (PointAndFigureFeedDescriptor)entry.getKey1(), (DataInterpolationDescriptor)entry.getKey2());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void analyseTick(IPointAndFigureCreator creator, TickData tick, PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/*  203 */     boolean currentBarFormingFinished = creator.analyse(tick);
/*  204 */     if (!currentBarFormingFinished) {
/*  205 */       fireInProgressPointAndFigureUpdated(descriptor, interpolationDescriptor, (PointAndFigureData)createClone(creator.getLastData()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processTickForPriceRanges(Instrument instrument, TickData tickData)
/*      */   {
/*  214 */     Set<ITwoKeyEntry<RangeBarFeedDescriptor, DataInterpolationDescriptor, IPriceRangeCreator>> entrySet = this.inProgressPriceRangeCreatorsMap.entrySet();
/*      */     
/*  216 */     for (ITwoKeyEntry<RangeBarFeedDescriptor, DataInterpolationDescriptor, IPriceRangeCreator> entry : entrySet) {
/*  217 */       if (((RangeBarFeedDescriptor)entry.getKey1()).getInstrument().equals(instrument)) {
/*  218 */         IPriceRangeCreator creator = (IPriceRangeCreator)entry.getValue();
/*  219 */         if ((creator != null) && (creator.getLastData() != null))
/*      */         {
/*      */ 
/*      */ 
/*  223 */           analyseTick(creator, tickData, (RangeBarFeedDescriptor)entry.getKey1(), (DataInterpolationDescriptor)entry.getKey2());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void analyseTick(IPriceRangeCreator creator, TickData tick, RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/*  234 */     boolean currentBarFormingFinished = creator.analyse(tick);
/*  235 */     if (!currentBarFormingFinished) {
/*  236 */       fireInProgressPriceRangeUpdated(descriptor, interpolationDescriptor, (PriceRangeData)createClone(creator.getLastData()));
/*      */     }
/*      */   }
/*      */   
/*      */   public void processTick(Instrument instrument, TickData tickData)
/*      */   {
/*  242 */     synchronized (this.lastReceivedTicksMap) {
/*  243 */       ITimedDataShiftableBuffer<TickData> buffer = (ITimedDataShiftableBuffer)this.lastReceivedTicksMap.get(instrument);
/*  244 */       if (buffer == null) {
/*  245 */         buffer = new SynchronizedTimedDataShiftableBuffer(50);
/*  246 */         this.lastReceivedTicksMap.put(instrument, buffer);
/*      */       }
/*  248 */       buffer.addToEnd(tickData);
/*      */     }
/*      */     try
/*      */     {
/*  252 */       processTickForPriceRanges(instrument, tickData);
/*      */     } catch (Throwable t) {
/*  254 */       LOGGER.error(t.getMessage(), t);
/*      */     }
/*      */     try
/*      */     {
/*  258 */       processTickForPointAndFigures(instrument, tickData);
/*      */     } catch (Throwable t) {
/*  260 */       LOGGER.error(t.getMessage(), t);
/*      */     }
/*      */     try
/*      */     {
/*  264 */       processTickForTickBars(instrument, tickData);
/*      */     } catch (Throwable t) {
/*  266 */       LOGGER.error(t.getMessage(), t);
/*      */     }
/*      */     try
/*      */     {
/*  270 */       processTickForRenko(instrument, tickData);
/*      */     } catch (Throwable t) {
/*  272 */       LOGGER.error(t.getMessage(), t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressPriceRange(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/*  282 */     startToFillInProgressPriceRange(descriptor, interpolationDescriptor, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressPriceRange(final RangeBarFeedDescriptor descriptor, final DataInterpolationDescriptor interpolationDescriptor, IPriceRangeLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/*  291 */     synchronized (this.inProgressPriceRangeCreatorsMap) {
/*  292 */       IPriceRangeCreator creator = (IPriceRangeCreator)this.inProgressPriceRangeCreatorsMap.get(descriptor, interpolationDescriptor);
/*  293 */       if (creator == null)
/*      */       {
/*      */ 
/*      */ 
/*  297 */         creator = new FlowPriceRangeCreator(descriptor.getInstrument(), descriptor.getPriceRange(), descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()));
/*      */         
/*  299 */         creator.addListener(new PriceRangeLiveFeedAdapter()
/*      */         {
/*      */           public void newPriceData(PriceRangeData bar) {
/*  302 */             IntraperiodBarsGenerator.this.fireInProgressPriceRangeFormed(descriptor, interpolationDescriptor, (PriceRangeData)IntraperiodBarsGenerator.createClone(bar));
/*      */           }
/*      */           
/*  305 */         });
/*  306 */         this.inProgressPriceRangeCreatorsMap.put(descriptor, interpolationDescriptor, creator);
/*      */         
/*  308 */         final JForexPeriod jfPeriod = new JForexPeriod(DataType.PRICE_RANGE_AGGREGATION, descriptor.getPeriod(), descriptor.getPriceRange());
/*      */         
/*  310 */         this.priceRangeCompletedInProgressBarsListenersMap.put(descriptor, interpolationDescriptor, new IPriceRangeLiveFeedListener()
/*      */         {
/*      */           public void newPriceData(PriceRangeData priceRange) {
/*  313 */             if (!(IntraperiodBarsGenerator.this.priceAggregationDataProvider.getFeedDataProvider() instanceof TesterFeedDataProvider)) {
/*  314 */               IntraperiodBarsGenerator.this.paCacheManager.addCompletedIntradayBar(descriptor.getInstrument(), jfPeriod, descriptor.getOfferSide(), interpolationDescriptor, priceRange);
/*      */             }
/*      */             
/*      */           }
/*  318 */         });
/*  319 */         addPriceRangeListener(descriptor, interpolationDescriptor, (IPriceRangeLiveFeedListener)this.priceRangeCompletedInProgressBarsListenersMap.get(descriptor, interpolationDescriptor));
/*      */         
/*      */         try
/*      */         {
/*  323 */           this.paCacheManager.subscribePriceRangeCacheDayLoading(descriptor.getInstrument(), jfPeriod, interpolationDescriptor, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */         }
/*      */         catch (DataCacheException e) {
/*  326 */           e.printStackTrace();
/*      */         }
/*      */         
/*  329 */         asynchLoadLastPriceRange(descriptor, interpolationDescriptor, creator, inProgressBarLoadedListener);
/*      */ 
/*      */       }
/*  332 */       else if (inProgressBarLoadedListener != null)
/*      */       {
/*  334 */         if (creator.getLastData() == null) {
/*  335 */           FeedListenerKeyBean key = new FeedListenerKeyBean(new JForexPeriod(DataType.PRICE_RANGE_AGGREGATION, descriptor.getPeriod(), descriptor.getPriceRange()), descriptor.getInstrument(), descriptor.getOfferSide(), interpolationDescriptor);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  341 */           LinkedList<IPriceAggregationLiveFeedListener> listeners = (LinkedList)this.listenersWaitingForInProgressBarMap.get(key);
/*  342 */           if (listeners == null) {
/*  343 */             listeners = new LinkedList();
/*  344 */             this.listenersWaitingForInProgressBarMap.put(key, listeners);
/*      */           }
/*  346 */           listeners.add(inProgressBarLoadedListener);
/*  347 */           return;
/*      */         }
/*      */         
/*  350 */         inProgressBarLoadedListener.newPriceData((PriceRangeData)creator.getLastData());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void asynchLoadLastPriceRange(final RangeBarFeedDescriptor descriptor, final DataInterpolationDescriptor interpolationDescriptor, final IPriceRangeCreator creator, final IPriceRangeLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/*  362 */     Runnable runnable = new Runnable()
/*      */     {
/*      */       public void run() {
/*      */         try {
/*  366 */           IWaitable waitable = new IWaitable()
/*      */           {
/*      */             public boolean mustWait() {
/*  369 */               return IntraperiodBarsGenerator.this.isInProgressPriceRangeLoadingNow(IntraperiodBarsGenerator.3.this.val$descriptor, IntraperiodBarsGenerator.3.this.val$interpolationDescriptor);
/*      */             }
/*      */             
/*  372 */           };
/*  373 */           boolean canContinue = IntraperiodBarsGenerator.this.waitForTicks(descriptor.getInstrument(), waitable);
/*  374 */           if (!canContinue) {
/*  375 */             return;
/*      */           }
/*      */           
/*  378 */           LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/*      */           
/*  380 */           List<LastBarLoadingProgressListener> listenerList = (List)IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.get(descriptor, interpolationDescriptor);
/*  381 */           if (listenerList == null) {
/*  382 */             listenerList = new ArrayList();
/*  383 */             IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.put(descriptor, interpolationDescriptor, listenerList);
/*      */           }
/*  385 */           listenerList.add(loadingProgressListener);
/*      */           
/*  387 */           PriceRangeData lastBar = IntraperiodBarsGenerator.this.loadLastPriceRange(descriptor, interpolationDescriptor, loadingProgressListener);
/*      */           
/*  389 */           synchronized (IntraperiodBarsGenerator.this.inProgressPriceRangeCreatorsMap)
/*      */           {
/*  391 */             if (loadingProgressListener.stopJob()) {
/*  392 */               listenerList.remove(loadingProgressListener);
/*  393 */               return;
/*      */             }
/*      */             
/*  396 */             listenerList.remove(loadingProgressListener);
/*      */             
/*  398 */             if (IntraperiodBarsGenerator.this.inProgressPriceRangeCreatorsMap.get(descriptor, interpolationDescriptor) == null) {
/*  399 */               return;
/*      */             }
/*      */             
/*  402 */             if (lastBar == null) {
/*  403 */               throw new RuntimeException("Unable to load last range bar for <" + descriptor.getInstrument() + ">");
/*      */             }
/*  405 */             creator.setupLastData(lastBar);
/*      */             
/*  407 */             IntraperiodBarsGenerator.this.processLastReceivedTicksWhileLastBarWasLoading(lastBar.getEndTime(), descriptor.getInstrument(), new ITickProcessor()
/*      */             {
/*      */ 
/*      */               public void processTick(TickData tick)
/*      */               {
/*      */ 
/*  413 */                 IntraperiodBarsGenerator.this.analyseTick(IntraperiodBarsGenerator.3.this.val$creator, tick, IntraperiodBarsGenerator.3.this.val$descriptor, IntraperiodBarsGenerator.3.this.val$interpolationDescriptor);
/*      */               }
/*      */               
/*      */ 
/*  417 */             });
/*  418 */             FeedListenerKeyBean key = new FeedListenerKeyBean(new JForexPeriod(DataType.PRICE_RANGE_AGGREGATION, descriptor.getPeriod(), descriptor.getPriceRange()), descriptor.getInstrument(), descriptor.getOfferSide(), interpolationDescriptor);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  423 */             IntraperiodBarsGenerator.this.informListeners(key, creator.getLastData());
/*      */           }
/*      */           
/*      */ 
/*  427 */           if (inProgressBarLoadedListener != null) {
/*  428 */             inProgressBarLoadedListener.newPriceData((PriceRangeData)creator.getLastData());
/*      */           }
/*      */         }
/*      */         catch (Throwable t) {
/*  432 */           IntraperiodBarsGenerator.LOGGER.error("Failed to load in progress bar " + t.getLocalizedMessage(), t);
/*  433 */           IntraperiodBarsGenerator.this.stopToFillInProgressPriceRange(descriptor, interpolationDescriptor);
/*      */         }
/*      */       }
/*  436 */     };
/*  437 */     invoke(runnable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PriceRangeData loadLastPriceRange(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, LastBarLoadingProgressListener progressListener)
/*      */   {
/*  448 */     LastPriceRangeLiveFeedListener lastBarListener = new LastPriceRangeLiveFeedListener();
/*      */     
/*  450 */     JForexPeriod jfPeriod = new JForexPeriod(DataType.PRICE_RANGE_AGGREGATION, descriptor.getPeriod(), descriptor.getPriceRange());
/*      */     try
/*      */     {
/*  453 */       PALoadInProgressPriceRangeAction loadIntraperiodBarAction = new PALoadInProgressPriceRangeAction(this.paCacheManager, descriptor.getInstrument(), interpolationDescriptor, descriptor.getOfferSide(), jfPeriod, true, Period.isInfinity(descriptor.getPeriod()), 5, lastBarListener, progressListener);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  465 */       loadIntraperiodBarAction.run();
/*      */     } catch (DataCacheException e) {
/*  467 */       e.printStackTrace();
/*      */     }
/*      */     
/*  470 */     PriceRangeData lastBar = (PriceRangeData)lastBarListener.getLastData();
/*      */     
/*  472 */     return lastBar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void stopToFillInProgressPriceRange(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/*  480 */     synchronized (this.inProgressPriceRangeCreatorsMap) {
/*  481 */       this.inProgressPriceRangeCreatorsMap.remove(descriptor, interpolationDescriptor);
/*      */       
/*  483 */       List<LastBarLoadingProgressListener> list = (List)this.lastBarLoadingProgressListeners.get(descriptor, interpolationDescriptor);
/*  484 */       if (list != null) {
/*  485 */         for (LastBarLoadingProgressListener l : list) {
/*  486 */           l.setStopJob(true);
/*      */         }
/*  488 */         list.clear();
/*      */       }
/*      */       
/*      */ 
/*  492 */       JForexPeriod jfPeriod = new JForexPeriod(DataType.PRICE_RANGE_AGGREGATION, descriptor.getPeriod(), descriptor.getPriceRange());
/*  493 */       this.paCacheManager.unsubscribeCacheDayLoading(descriptor.getInstrument(), jfPeriod, interpolationDescriptor, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */       
/*      */ 
/*  496 */       this.paCacheManager.flushDelayedWriteTasks();
/*  497 */       removePriceRangeNotificationListener((IPriceRangeLiveFeedListener)this.priceRangeCompletedInProgressBarsListenersMap.remove(descriptor, interpolationDescriptor));
/*      */       
/*  499 */       FeedListenerKeyBean key = new FeedListenerKeyBean(jfPeriod, descriptor.getInstrument(), descriptor.getOfferSide(), interpolationDescriptor);
/*  500 */       this.listenersWaitingForInProgressBarMap.remove(key);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressPointAndFigure(final PointAndFigureFeedDescriptor descriptor, final DataInterpolationDescriptor interpolationDescriptor, IPointAndFigureLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/*  510 */     synchronized (this.inProgressPointAndFigureCreatorsMap)
/*      */     {
/*  512 */       IPointAndFigureCreator creator = (IPointAndFigureCreator)this.inProgressPointAndFigureCreatorsMap.get(descriptor, interpolationDescriptor);
/*      */       
/*  514 */       if (creator == null)
/*      */       {
/*      */ 
/*      */ 
/*  518 */         creator = new FlowPointAndFigureCreator(descriptor.getInstrument(), descriptor.getPriceRange(), descriptor.getReversalAmount(), descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()));
/*      */         
/*  520 */         creator.addListener(new PointAndFigureLiveFeedAdapter()
/*      */         {
/*      */           public void newPriceData(PointAndFigureData bar) {
/*  523 */             IntraperiodBarsGenerator.this.fireInProgressPointAndFigureFormed(descriptor, interpolationDescriptor, (PointAndFigureData)IntraperiodBarsGenerator.createClone(bar));
/*      */           }
/*      */           
/*  526 */         });
/*  527 */         this.inProgressPointAndFigureCreatorsMap.put(descriptor, interpolationDescriptor, creator);
/*      */         
/*  529 */         final JForexPeriod jfPeriod = new JForexPeriod(DataType.POINT_AND_FIGURE, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getReversalAmount());
/*  530 */         this.pointAndFigureCompletedInProgressBarsListenersMap.put(descriptor, interpolationDescriptor, new IPointAndFigureLiveFeedListener()
/*      */         {
/*      */           public void newPriceData(PointAndFigureData pointAndFigure) {
/*  533 */             IntraperiodBarsGenerator.this.paCacheManager.addCompletedIntradayBar(descriptor.getInstrument(), jfPeriod, descriptor.getOfferSide(), interpolationDescriptor, pointAndFigure);
/*      */           }
/*      */           
/*  536 */         });
/*  537 */         addPointAndFigureListener(descriptor, interpolationDescriptor, (IPointAndFigureLiveFeedListener)this.pointAndFigureCompletedInProgressBarsListenersMap.get(descriptor, interpolationDescriptor));
/*      */         try
/*      */         {
/*  540 */           this.paCacheManager.subscribePointAndFigureCacheDayLoading(descriptor.getInstrument(), jfPeriod, interpolationDescriptor, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */         } catch (DataCacheException e) {
/*  542 */           e.printStackTrace();
/*      */         }
/*      */         
/*      */ 
/*  546 */         asynchLoadLastPointAndFigure(descriptor, interpolationDescriptor, creator, inProgressBarLoadedListener);
/*      */ 
/*      */       }
/*  549 */       else if (inProgressBarLoadedListener != null)
/*      */       {
/*  551 */         if (creator.getLastData() == null) {
/*  552 */           FeedListenerKeyBean key = new FeedListenerKeyBean(new JForexPeriod(DataType.POINT_AND_FIGURE, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getReversalAmount()), descriptor.getInstrument(), descriptor.getOfferSide(), interpolationDescriptor);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  558 */           LinkedList<IPriceAggregationLiveFeedListener> listeners = (LinkedList)this.listenersWaitingForInProgressBarMap.get(key);
/*  559 */           if (listeners == null) {
/*  560 */             listeners = new LinkedList();
/*  561 */             this.listenersWaitingForInProgressBarMap.put(key, listeners);
/*      */           }
/*  563 */           listeners.add(inProgressBarLoadedListener);
/*  564 */           return;
/*      */         }
/*      */         
/*  567 */         inProgressBarLoadedListener.newPriceData((PointAndFigureData)creator.getLastData());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressPointAndFigure(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/*  579 */     startToFillInProgressPointAndFigure(descriptor, interpolationDescriptor, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void asynchLoadLastPointAndFigure(final PointAndFigureFeedDescriptor descriptor, final DataInterpolationDescriptor interpolationDescriptor, final IPointAndFigureCreator creator, final IPointAndFigureLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/*  588 */     Runnable runnable = new Runnable()
/*      */     {
/*      */       public void run() {
/*      */         try {
/*  592 */           IWaitable waitable = new IWaitable()
/*      */           {
/*      */             public boolean mustWait() {
/*  595 */               return IntraperiodBarsGenerator.this.isInProgressPointAndFigureLoadingNow(IntraperiodBarsGenerator.6.this.val$descriptor, IntraperiodBarsGenerator.6.this.val$interpolationDescriptor);
/*      */             }
/*      */             
/*  598 */           };
/*  599 */           boolean canContinue = IntraperiodBarsGenerator.this.waitForTicks(descriptor.getInstrument(), waitable);
/*  600 */           if (!canContinue) {
/*  601 */             return;
/*      */           }
/*      */           
/*  604 */           LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/*  605 */           List<LastBarLoadingProgressListener> listenerList = (List)IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.get(descriptor, interpolationDescriptor);
/*  606 */           if (listenerList == null) {
/*  607 */             listenerList = new ArrayList();
/*  608 */             IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.put(descriptor, interpolationDescriptor, listenerList);
/*      */           }
/*  610 */           listenerList.add(loadingProgressListener);
/*      */           
/*  612 */           PointAndFigureData lastBar = IntraperiodBarsGenerator.this.loadLastPointAndFigure(descriptor, interpolationDescriptor, loadingProgressListener);
/*      */           
/*  614 */           synchronized (IntraperiodBarsGenerator.this.inProgressPointAndFigureCreatorsMap)
/*      */           {
/*  616 */             if (loadingProgressListener.stopJob()) {
/*  617 */               listenerList.remove(loadingProgressListener);
/*  618 */               return;
/*      */             }
/*      */             
/*  621 */             listenerList.remove(loadingProgressListener);
/*      */             
/*  623 */             if (IntraperiodBarsGenerator.this.inProgressPointAndFigureCreatorsMap.get(descriptor, interpolationDescriptor) == null) {
/*  624 */               return;
/*      */             }
/*      */             
/*  627 */             if (lastBar == null) {
/*  628 */               throw new RuntimeException("Unable to load last p&f for <" + descriptor.getInstrument() + ">");
/*      */             }
/*      */             
/*  631 */             creator.setupLastData(lastBar);
/*      */             
/*  633 */             IntraperiodBarsGenerator.this.processLastReceivedTicksWhileLastBarWasLoading(lastBar.getEndTime(), descriptor.getInstrument(), new ITickProcessor()
/*      */             {
/*      */ 
/*      */               public void processTick(TickData tick)
/*      */               {
/*      */ 
/*  639 */                 IntraperiodBarsGenerator.this.analyseTick(IntraperiodBarsGenerator.6.this.val$creator, tick, IntraperiodBarsGenerator.6.this.val$descriptor, IntraperiodBarsGenerator.6.this.val$interpolationDescriptor);
/*      */               }
/*      */               
/*      */ 
/*  643 */             });
/*  644 */             FeedListenerKeyBean key = new FeedListenerKeyBean(new JForexPeriod(DataType.POINT_AND_FIGURE, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getReversalAmount()), descriptor.getInstrument(), descriptor.getOfferSide(), interpolationDescriptor);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  650 */             IntraperiodBarsGenerator.this.informListeners(key, creator.getLastData());
/*      */           }
/*      */           
/*      */ 
/*  654 */           if (inProgressBarLoadedListener != null) {
/*  655 */             inProgressBarLoadedListener.newPriceData((PointAndFigureData)creator.getLastData());
/*      */           }
/*      */         }
/*      */         catch (Throwable t) {
/*  659 */           IntraperiodBarsGenerator.LOGGER.error("Failed to load in progress bar " + t.getLocalizedMessage(), t);
/*  660 */           IntraperiodBarsGenerator.this.stopToFillInProgressPointAndFigure(descriptor, interpolationDescriptor);
/*      */         }
/*      */       }
/*  663 */     };
/*  664 */     invoke(runnable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PointAndFigureData loadLastPointAndFigure(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, LastBarLoadingProgressListener progressListener)
/*      */   {
/*  673 */     LastPointAndFigureLiveFeedListener lastBarListener = new LastPointAndFigureLiveFeedListener();
/*      */     
/*  675 */     JForexPeriod jfPeriod = new JForexPeriod(DataType.POINT_AND_FIGURE, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getReversalAmount());
/*      */     try
/*      */     {
/*  678 */       PALoadInProgressPointAndFigureAction loadIntraperiodBarAction = new PALoadInProgressPointAndFigureAction(this.paCacheManager, descriptor.getInstrument(), interpolationDescriptor, descriptor.getOfferSide(), jfPeriod, true, Period.isInfinity(descriptor.getPeriod()), 5, lastBarListener, progressListener);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  691 */       loadIntraperiodBarAction.run();
/*      */     }
/*      */     catch (DataCacheException e) {
/*  694 */       e.printStackTrace();
/*      */     }
/*      */     
/*  697 */     PointAndFigureData lastBar = (PointAndFigureData)lastBarListener.getLastData();
/*      */     
/*  699 */     return lastBar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void stopToFillInProgressPointAndFigure(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/*  706 */     synchronized (this.inProgressPointAndFigureCreatorsMap) {
/*  707 */       this.inProgressPointAndFigureCreatorsMap.remove(descriptor, interpolationDescriptor);
/*      */       
/*  709 */       List<LastBarLoadingProgressListener> list = (List)this.lastBarLoadingProgressListeners.get(descriptor, interpolationDescriptor);
/*  710 */       if (list != null) {
/*  711 */         for (LastBarLoadingProgressListener l : list) {
/*  712 */           l.setStopJob(true);
/*      */         }
/*  714 */         list.clear();
/*      */       }
/*      */       
/*      */ 
/*  718 */       JForexPeriod jfPeriod = new JForexPeriod(DataType.POINT_AND_FIGURE, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getReversalAmount());
/*  719 */       this.paCacheManager.unsubscribeCacheDayLoading(descriptor.getInstrument(), jfPeriod, interpolationDescriptor, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*  720 */       this.paCacheManager.flushDelayedWriteTasks();
/*  721 */       removePointAndFigureNotificationListener((IPointAndFigureLiveFeedListener)this.pointAndFigureCompletedInProgressBarsListenersMap.remove(descriptor, interpolationDescriptor));
/*      */       
/*  723 */       FeedListenerKeyBean key = new FeedListenerKeyBean(jfPeriod, descriptor.getInstrument(), descriptor.getOfferSide(), interpolationDescriptor);
/*  724 */       this.listenersWaitingForInProgressBarMap.remove(key);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressTickBar(TickBarFeedDescriptor descriptor)
/*      */   {
/*  732 */     startToFillInProgressTickBar(descriptor, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressTickBar(final TickBarFeedDescriptor descriptor, ITickBarLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/*  740 */     synchronized (this.inProgressTickBarCreatorsMap) {
/*  741 */       ITickBarCreator creator = (ITickBarCreator)this.inProgressTickBarCreatorsMap.get(descriptor);
/*  742 */       if (creator == null)
/*      */       {
/*      */ 
/*      */ 
/*  746 */         creator = new FlowTickBarCreator(descriptor.getInstrument(), descriptor.getTickBarSize(), descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()));
/*      */         
/*  748 */         creator.addListener(new TickBarLiveFeedAdapter()
/*      */         {
/*      */           public void newPriceData(TickBarData bar) {
/*  751 */             IntraperiodBarsGenerator.this.fireInProgressTickBarFormed(descriptor, (TickBarData)IntraperiodBarsGenerator.createClone(bar));
/*      */           }
/*      */           
/*  754 */         });
/*  755 */         this.inProgressTickBarCreatorsMap.put(descriptor, creator);
/*  756 */         final JForexPeriod jfPeriod = new JForexPeriod(DataType.TICK_BAR, descriptor.getPeriod(), descriptor.getTickBarSize());
/*      */         
/*  758 */         this.tickBarCompletedInProgressBarsListenersMap.put(descriptor, new ITickBarLiveFeedListener()
/*      */         {
/*      */           public void newPriceData(TickBarData tickBar)
/*      */           {
/*  762 */             IntraperiodBarsGenerator.this.paCacheManager.addCompletedIntradayBar(descriptor.getInstrument(), jfPeriod, descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS, tickBar);
/*      */           }
/*      */           
/*      */ 
/*  766 */         });
/*  767 */         addTickBarListener(descriptor, (ITickBarLiveFeedListener)this.tickBarCompletedInProgressBarsListenersMap.get(descriptor));
/*      */         try {
/*  769 */           this.paCacheManager.subscribeTickBarCacheDayLoading(descriptor.getInstrument(), jfPeriod, DataInterpolationDescriptor.ALL_TICKS, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */         } catch (DataCacheException e) {
/*  771 */           e.printStackTrace();
/*      */         }
/*      */         
/*  774 */         asynchLoadLastTickBar(descriptor, creator, inProgressBarLoadedListener);
/*      */ 
/*      */       }
/*  777 */       else if (inProgressBarLoadedListener != null)
/*      */       {
/*  779 */         if (creator.getLastData() == null) {
/*  780 */           FeedListenerKeyBean key = new FeedListenerKeyBean(new JForexPeriod(DataType.TICK_BAR, descriptor.getPeriod(), descriptor.getTickBarSize()), descriptor.getInstrument(), descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  786 */           LinkedList<IPriceAggregationLiveFeedListener> listeners = (LinkedList)this.listenersWaitingForInProgressBarMap.get(key);
/*  787 */           if (listeners == null) {
/*  788 */             listeners = new LinkedList();
/*  789 */             this.listenersWaitingForInProgressBarMap.put(key, listeners);
/*      */           }
/*  791 */           listeners.add(inProgressBarLoadedListener);
/*  792 */           return;
/*      */         }
/*      */         
/*  795 */         inProgressBarLoadedListener.newPriceData((TickBarData)creator.getLastData());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void asynchLoadLastTickBar(final TickBarFeedDescriptor descriptor, final ITickBarCreator creator, final ITickBarLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/*  806 */     Runnable runnable = new Runnable()
/*      */     {
/*      */       public void run() {
/*      */         try {
/*  810 */           IWaitable waitable = new IWaitable()
/*      */           {
/*      */             public boolean mustWait() {
/*  813 */               return IntraperiodBarsGenerator.this.isInProgressTickBarLoadingNow(IntraperiodBarsGenerator.9.this.val$descriptor);
/*      */             }
/*      */             
/*  816 */           };
/*  817 */           boolean canContinue = IntraperiodBarsGenerator.this.waitForTicks(descriptor.getInstrument(), waitable);
/*  818 */           if (!canContinue) {
/*  819 */             return;
/*      */           }
/*      */           
/*  822 */           LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/*  823 */           List<LastBarLoadingProgressListener> listenerList = (List)IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.get(descriptor, DataInterpolationDescriptor.DEFAULT);
/*  824 */           if (listenerList == null) {
/*  825 */             listenerList = new ArrayList();
/*  826 */             IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.put(descriptor, DataInterpolationDescriptor.DEFAULT, listenerList);
/*      */           }
/*  828 */           listenerList.add(loadingProgressListener);
/*      */           
/*  830 */           TickBarData lastBar = IntraperiodBarsGenerator.this.loadLastTickBar(descriptor, loadingProgressListener);
/*      */           
/*  832 */           synchronized (IntraperiodBarsGenerator.this.inProgressTickBarCreatorsMap)
/*      */           {
/*  834 */             if (loadingProgressListener.stopJob()) {
/*  835 */               listenerList.remove(loadingProgressListener);
/*  836 */               return;
/*      */             }
/*      */             
/*  839 */             listenerList.remove(loadingProgressListener);
/*      */             
/*  841 */             if (IntraperiodBarsGenerator.this.inProgressTickBarCreatorsMap.get(descriptor) == null) {
/*  842 */               return;
/*      */             }
/*      */             
/*  845 */             if (lastBar == null) {
/*  846 */               throw new RuntimeException("Unable to load last tick bar for <" + descriptor.getInstrument() + ">");
/*      */             }
/*      */             
/*  849 */             creator.setupLastData(lastBar);
/*      */             
/*  851 */             IntraperiodBarsGenerator.this.processLastReceivedTicksWhileLastBarWasLoading(lastBar.getEndTime(), descriptor.getInstrument(), new ITickProcessor()
/*      */             {
/*      */ 
/*      */               public void processTick(TickData tick)
/*      */               {
/*      */ 
/*  857 */                 IntraperiodBarsGenerator.this.analyseTick(IntraperiodBarsGenerator.9.this.val$creator, tick, IntraperiodBarsGenerator.9.this.val$descriptor);
/*      */               }
/*      */               
/*      */ 
/*  861 */             });
/*  862 */             FeedListenerKeyBean key = new FeedListenerKeyBean(new JForexPeriod(DataType.TICK_BAR, descriptor.getPeriod(), descriptor.getTickBarSize()), descriptor.getInstrument(), descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  868 */             IntraperiodBarsGenerator.this.informListeners(key, creator.getLastData());
/*      */           }
/*      */           
/*  871 */           if (inProgressBarLoadedListener != null) {
/*  872 */             inProgressBarLoadedListener.newPriceData((TickBarData)creator.getLastData());
/*      */           }
/*      */         }
/*      */         catch (Throwable t) {
/*  876 */           IntraperiodBarsGenerator.LOGGER.error("Failed to load in progress bar " + t.getLocalizedMessage(), t);
/*  877 */           IntraperiodBarsGenerator.this.stopToFillInProgressTickBar(descriptor);
/*      */         }
/*      */         
/*      */       }
/*  881 */     };
/*  882 */     invoke(runnable);
/*      */   }
/*      */   
/*      */   private void informListeners(FeedListenerKeyBean key, AbstractPriceAggregationData lastBar) {
/*  886 */     LinkedList<IPriceAggregationLiveFeedListener> listeners = (LinkedList)this.listenersWaitingForInProgressBarMap.get(key);
/*  887 */     if ((listeners != null) && (!listeners.isEmpty())) {
/*  888 */       while (!listeners.isEmpty()) {
/*  889 */         IPriceAggregationLiveFeedListener listener = (IPriceAggregationLiveFeedListener)listeners.poll();
/*  890 */         listener.newPriceData(lastBar);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processLastReceivedTicksWhileLastBarWasLoading(long lastBarEndTime, Instrument instrument, ITickProcessor tickProcessor)
/*      */   {
/*  900 */     synchronized (this.lastReceivedTicksMap) {
/*  901 */       ITimedDataShiftableBuffer<TickData> buffer = (ITimedDataShiftableBuffer)this.lastReceivedTicksMap.get(instrument);
/*  902 */       List<TickData> collectedTicksWhileLoadingInProgressBar = null;
/*  903 */       if (buffer != null) {
/*  904 */         collectedTicksWhileLoadingInProgressBar = buffer.getAfterTime(lastBarEndTime, false);
/*      */       }
/*      */       
/*  907 */       if (collectedTicksWhileLoadingInProgressBar != null) {
/*  908 */         for (TickData tick : collectedTicksWhileLoadingInProgressBar) {
/*  909 */           tickProcessor.processTick(tick);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processLastReceivedCandleWhileLastBarWasLoading(long lastBarEndTime, Instrument instrument, OfferSide offerSide, Period period, ICandleProcessor candleProcessor)
/*      */   {
/*  922 */     synchronized (this.lastReceivedCandlesMap) {
/*  923 */       ITimedDataShiftableBuffer<CandleData> buffer = (ITimedDataShiftableBuffer)this.lastReceivedCandlesMap.get(instrument, offerSide, period);
/*  924 */       List<CandleData> collectedCandlesWhileLoadingInProgressBar = null;
/*  925 */       if (buffer != null) {
/*  926 */         collectedCandlesWhileLoadingInProgressBar = buffer.getAfterTime(lastBarEndTime, false);
/*      */       }
/*      */       
/*  929 */       if (collectedCandlesWhileLoadingInProgressBar != null) {
/*  930 */         for (CandleData candle : collectedCandlesWhileLoadingInProgressBar) {
/*  931 */           candleProcessor.processCandle(candle);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private TickBarData loadLastTickBar(TickBarFeedDescriptor descriptor, LastBarLoadingProgressListener progressListener)
/*      */   {
/*  942 */     LastTickBarLiveFeedListener lastBarListener = new LastTickBarLiveFeedListener();
/*      */     
/*  944 */     JForexPeriod jfPeriod = new JForexPeriod(DataType.TICK_BAR, descriptor.getPeriod(), descriptor.getTickBarSize());
/*      */     try
/*      */     {
/*  947 */       PALoadInProgressTickBarAction loadIntraperiodBarAction = new PALoadInProgressTickBarAction(this.paCacheManager, descriptor.getInstrument(), DataInterpolationDescriptor.ALL_TICKS, descriptor.getOfferSide(), jfPeriod, true, Period.isInfinity(descriptor.getPeriod()), 5, lastBarListener, progressListener);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  959 */       loadIntraperiodBarAction.run();
/*      */     }
/*      */     catch (DataCacheException e) {
/*  962 */       e.printStackTrace();
/*      */     }
/*      */     
/*  965 */     TickBarData lastBar = (TickBarData)lastBarListener.getLastData();
/*      */     
/*  967 */     return lastBar;
/*      */   }
/*      */   
/*      */ 
/*      */   private void stopToFillInProgressTickBar(TickBarFeedDescriptor descriptor)
/*      */   {
/*  973 */     synchronized (this.inProgressTickBarCreatorsMap) {
/*  974 */       this.inProgressTickBarCreatorsMap.remove(descriptor);
/*      */       
/*  976 */       List<LastBarLoadingProgressListener> list = (List)this.lastBarLoadingProgressListeners.get(descriptor, DataInterpolationDescriptor.DEFAULT);
/*  977 */       if (list != null) {
/*  978 */         for (LastBarLoadingProgressListener l : list) {
/*  979 */           l.setStopJob(true);
/*      */         }
/*  981 */         list.clear();
/*      */       }
/*      */       
/*  984 */       removeTickBarNotificationListener((ITickBarLiveFeedListener)this.tickBarCompletedInProgressBarsListenersMap.get(descriptor));
/*      */       
/*  986 */       JForexPeriod jfPeriod = new JForexPeriod(DataType.TICK_BAR, descriptor.getPeriod(), descriptor.getTickBarSize());
/*  987 */       this.paCacheManager.flushDelayedWriteTasks();
/*  988 */       this.paCacheManager.unsubscribeCacheDayLoading(descriptor.getInstrument(), jfPeriod, DataInterpolationDescriptor.ALL_TICKS, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */       
/*  990 */       FeedListenerKeyBean key = new FeedListenerKeyBean(jfPeriod, descriptor.getInstrument(), descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS);
/*  991 */       this.listenersWaitingForInProgressBarMap.remove(key);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PointAndFigureData getInProgressPointAndFigure(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1000 */     IPointAndFigureCreator creator = getInProgressPointAndFigureCreator(descriptor, interpolationDescriptor);
/* 1001 */     if (creator == null) {
/* 1002 */       return null;
/*      */     }
/* 1004 */     return (PointAndFigureData)createClone(creator.getLastData());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private IPointAndFigureCreator getInProgressPointAndFigureCreator(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1011 */     IPointAndFigureCreator creator = (IPointAndFigureCreator)this.inProgressPointAndFigureCreatorsMap.get(descriptor, interpolationDescriptor);
/* 1012 */     return creator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PriceRangeData getInProgressPriceRange(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1020 */     PriceRangeData result = null;
/* 1021 */     IPriceRangeCreator creator = getInProgressPriceRangeCreator(descriptor, interpolationDescriptor);
/* 1022 */     if (creator != null) {
/* 1023 */       result = (PriceRangeData)createClone(creator.getLastData());
/*      */     }
/* 1025 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private IPriceRangeCreator getInProgressPriceRangeCreator(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1032 */     return (IPriceRangeCreator)this.inProgressPriceRangeCreatorsMap.get(descriptor, interpolationDescriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public TickBarData getInProgressTickBar(TickBarFeedDescriptor descriptor)
/*      */   {
/* 1040 */     ITickBarCreator creator = getInProgressTickBarCreator(descriptor);
/* 1041 */     if (creator == null) {
/* 1042 */       return null;
/*      */     }
/* 1044 */     return (TickBarData)createClone(creator.getLastData());
/*      */   }
/*      */   
/*      */ 
/*      */   private ITickBarCreator getInProgressTickBarCreator(TickBarFeedDescriptor descriptor)
/*      */   {
/* 1050 */     ITickBarCreator creator = (ITickBarCreator)this.inProgressTickBarCreatorsMap.get(descriptor);
/* 1051 */     return creator;
/*      */   }
/*      */   
/*      */   public static <T extends AbstractPriceAggregationData> T createClone(T bar) {
/* 1055 */     return bar == null ? null : bar.clone();
/*      */   }
/*      */   
/*      */   public static <T extends AbstractPriceAggregationData> void arrayClone(T[] source, T[] target) {
/* 1059 */     for (int i = 0; i < source.length; i++) {
/* 1060 */       target[i] = createClone(source[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   public static <T extends AbstractPriceAggregationData> void replaceWithClones(T[] array) {
/* 1065 */     for (int i = 0; i < array.length; i++) {
/* 1066 */       T element = array[i];
/* 1067 */       array[i] = createClone(element);
/*      */     }
/*      */   }
/*      */   
/*      */   private void invoke(Runnable task) {
/* 1072 */     this.actionsExecutorService.submit(task);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isInProgressPriceRangeLoadingNow(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1080 */     IPriceRangeCreator creator = getInProgressPriceRangeCreator(descriptor, interpolationDescriptor);
/* 1081 */     return isInProgressBarLoadingNow(creator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isInProgressTickBarLoadingNow(TickBarFeedDescriptor descriptor)
/*      */   {
/* 1088 */     ITickBarCreator creator = getInProgressTickBarCreator(descriptor);
/* 1089 */     return isInProgressBarLoadingNow(creator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isInProgressPointAndFigureLoadingNow(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1097 */     IPointAndFigureCreator creator = getInProgressPointAndFigureCreator(descriptor, interpolationDescriptor);
/* 1098 */     return isInProgressBarLoadingNow(creator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean isInProgressBarLoadingNow(IPriceAggregationCreator<?, ?, ?> creator)
/*      */   {
/* 1105 */     if ((creator != null) && (creator.getLastData() == null)) {
/* 1106 */       return true;
/*      */     }
/*      */     
/* 1109 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireInProgressTickBarFormed(TickBarFeedDescriptor descriptor, TickBarData bar)
/*      */   {
/* 1118 */     List<ITickBarLiveFeedListener> listeners = new ArrayList();
/* 1119 */     listeners.addAll((Collection)this.tickBarNotificationListenersMap.get(descriptor));
/* 1120 */     for (ITickBarLiveFeedListener listener : listeners) {
/* 1121 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void fireInProgressTickBarUpdated(TickBarFeedDescriptor descriptor, TickBarData bar)
/*      */   {
/* 1129 */     List<ITickBarLiveFeedListener> listeners = new ArrayList();
/* 1130 */     listeners.addAll((Collection)this.inProgressTickBarLiveFeedListenersMap.get(descriptor));
/* 1131 */     for (ITickBarLiveFeedListener listener : listeners) {
/* 1132 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireInProgressPointAndFigureFormed(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, PointAndFigureData bar)
/*      */   {
/* 1141 */     List<IPointAndFigureLiveFeedListener> listeners = new ArrayList();
/* 1142 */     listeners.addAll((Collection)this.pointAndFigureNotificationListenersMap.get(descriptor, interpolationDescriptor));
/* 1143 */     for (IPointAndFigureLiveFeedListener listener : listeners) {
/* 1144 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireInProgressPointAndFigureUpdated(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, PointAndFigureData bar)
/*      */   {
/* 1153 */     List<IPointAndFigureLiveFeedListener> listeners = new ArrayList();
/* 1154 */     listeners.addAll((Collection)this.inProgressPointAndFigureListenersMap.get(descriptor, interpolationDescriptor));
/* 1155 */     for (IPointAndFigureLiveFeedListener listener : listeners) {
/* 1156 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireInProgressPriceRangeUpdated(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, PriceRangeData bar)
/*      */   {
/* 1165 */     List<IPriceRangeLiveFeedListener> listeners = new ArrayList();
/* 1166 */     listeners.addAll((Collection)this.inProgressPriceRangeLiveFeedListenersMap.get(descriptor, interpolationDescriptor));
/* 1167 */     for (IPriceRangeLiveFeedListener listener : listeners) {
/* 1168 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireInProgressPriceRangeFormed(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, PriceRangeData bar)
/*      */   {
/* 1177 */     List<IPriceRangeLiveFeedListener> listeners = new ArrayList();
/* 1178 */     listeners.addAll((Collection)this.priceRangeNotificationListenersMap.get(descriptor, interpolationDescriptor));
/* 1179 */     for (IPriceRangeLiveFeedListener listener : listeners) {
/* 1180 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressPriceRangeListener(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPriceRangeLiveFeedListener listener, IPriceRangeLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/* 1192 */     synchronized (this.inProgressPriceRangeLiveFeedListenersMap) {
/* 1193 */       List<IPriceRangeLiveFeedListener> listeners = (List)this.inProgressPriceRangeLiveFeedListenersMap.get(descriptor, interpolationDescriptor);
/* 1194 */       if (listeners == null) {
/* 1195 */         listeners = new ArrayList();
/* 1196 */         this.inProgressPriceRangeLiveFeedListenersMap.put(descriptor, interpolationDescriptor, listeners);
/*      */       }
/* 1198 */       listeners.add(listener);
/*      */     }
/* 1200 */     startToFillInProgressPriceRange(descriptor, interpolationDescriptor, inProgressBarLoadedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressPriceRangeListener(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPriceRangeLiveFeedListener listener)
/*      */   {
/* 1209 */     addInProgressPriceRangeListener(descriptor, interpolationDescriptor, listener, null);
/*      */   }
/*      */   
/*      */   public void removeInProgressPriceRangeListener(IPriceRangeLiveFeedListener listener)
/*      */   {
/* 1214 */     removePriceRangeLiveFeedListener(this.inProgressPriceRangeLiveFeedListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPriceRangeNotificationListener(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPriceRangeLiveFeedListener listener)
/*      */   {
/* 1223 */     addPriceRangeListener(descriptor, interpolationDescriptor, listener);
/* 1224 */     startToFillInProgressPriceRange(descriptor, interpolationDescriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addPriceRangeListener(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPriceRangeLiveFeedListener listener)
/*      */   {
/* 1232 */     List<IPriceRangeLiveFeedListener> listeners = (List)this.priceRangeNotificationListenersMap.get(descriptor, interpolationDescriptor);
/* 1233 */     if (listeners == null) {
/* 1234 */       listeners = new ArrayList();
/* 1235 */       this.priceRangeNotificationListenersMap.put(descriptor, interpolationDescriptor, listeners);
/*      */     }
/* 1237 */     listeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removePriceRangeNotificationListener(IPriceRangeLiveFeedListener listener)
/*      */   {
/* 1242 */     removePriceRangeLiveFeedListener(this.priceRangeNotificationListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressPointAndFigureListener(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPointAndFigureLiveFeedListener listener)
/*      */   {
/* 1252 */     addInProgressPointAndFigureListener(descriptor, interpolationDescriptor, listener, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressPointAndFigureListener(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPointAndFigureLiveFeedListener listener, IPointAndFigureLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/* 1262 */     synchronized (this.inProgressPointAndFigureListenersMap) {
/* 1263 */       List<IPointAndFigureLiveFeedListener> listeners = (List)this.inProgressPointAndFigureListenersMap.get(descriptor, interpolationDescriptor);
/* 1264 */       if (listeners == null) {
/* 1265 */         listeners = new ArrayList();
/* 1266 */         this.inProgressPointAndFigureListenersMap.put(descriptor, interpolationDescriptor, listeners);
/*      */       }
/* 1268 */       listeners.add(listener);
/*      */     }
/* 1270 */     startToFillInProgressPointAndFigure(descriptor, interpolationDescriptor, inProgressBarLoadedListener);
/*      */   }
/*      */   
/*      */   public void removeInProgressPointAndFigureListener(IPointAndFigureLiveFeedListener listener)
/*      */   {
/* 1275 */     removePointAndFigureLiveFeedListener(this.inProgressPointAndFigureListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPointAndFigureNotificationListener(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPointAndFigureLiveFeedListener listener)
/*      */   {
/* 1284 */     addPointAndFigureListener(descriptor, interpolationDescriptor, listener);
/* 1285 */     startToFillInProgressPointAndFigure(descriptor, interpolationDescriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addPointAndFigureListener(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor, IPointAndFigureLiveFeedListener listener)
/*      */   {
/* 1293 */     List<IPointAndFigureLiveFeedListener> listeners = (List)this.pointAndFigureNotificationListenersMap.get(descriptor, interpolationDescriptor);
/* 1294 */     if (listeners == null) {
/* 1295 */       listeners = new ArrayList();
/* 1296 */       this.pointAndFigureNotificationListenersMap.put(descriptor, interpolationDescriptor, listeners);
/*      */     }
/* 1298 */     listeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removePointAndFigureNotificationListener(IPointAndFigureLiveFeedListener listener)
/*      */   {
/* 1303 */     removePointAndFigureLiveFeedListener(this.pointAndFigureNotificationListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressTickBarListener(TickBarFeedDescriptor descriptor, ITickBarLiveFeedListener listener)
/*      */   {
/* 1312 */     addInProgressTickBarListener(descriptor, listener, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressTickBarListener(TickBarFeedDescriptor descriptor, ITickBarLiveFeedListener listener, ITickBarLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/* 1321 */     synchronized (this.inProgressTickBarLiveFeedListenersMap) {
/* 1322 */       List<ITickBarLiveFeedListener> listeners = (List)this.inProgressTickBarLiveFeedListenersMap.get(descriptor);
/* 1323 */       if (listeners == null) {
/* 1324 */         listeners = new ArrayList();
/* 1325 */         this.inProgressTickBarLiveFeedListenersMap.put(descriptor, listeners);
/*      */       }
/* 1327 */       listeners.add(listener);
/*      */     }
/*      */     
/* 1330 */     startToFillInProgressTickBar(descriptor, inProgressBarLoadedListener);
/*      */   }
/*      */   
/*      */   public void removeInProgressTickBarListener(ITickBarLiveFeedListener listener)
/*      */   {
/* 1335 */     removeTickBarLiveFeedListener(this.inProgressTickBarLiveFeedListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTickBarNotificationListener(TickBarFeedDescriptor descriptor, ITickBarLiveFeedListener listener)
/*      */   {
/* 1343 */     addTickBarListener(descriptor, listener);
/* 1344 */     startToFillInProgressTickBar(descriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void addTickBarListener(TickBarFeedDescriptor descriptor, ITickBarLiveFeedListener listener)
/*      */   {
/* 1351 */     List<ITickBarLiveFeedListener> listeners = (List)this.tickBarNotificationListenersMap.get(descriptor);
/* 1352 */     if (listeners == null) {
/* 1353 */       listeners = new ArrayList();
/* 1354 */       this.tickBarNotificationListenersMap.put(descriptor, listeners);
/*      */     }
/* 1356 */     listeners.add(listener);
/*      */   }
/*      */   
/*      */   public void removeTickBarNotificationListener(ITickBarLiveFeedListener listener)
/*      */   {
/* 1361 */     removeTickBarLiveFeedListener(this.tickBarNotificationListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void removePriceRangeLiveFeedListener(ITwoKeyMap<RangeBarFeedDescriptor, DataInterpolationDescriptor, List<IPriceRangeLiveFeedListener>> map, IPriceRangeLiveFeedListener listener)
/*      */   {
/* 1369 */     if ((listener == null) || (map == null)) {
/* 1370 */       return;
/*      */     }
/*      */     
/* 1373 */     Set<ITwoKeyEntry<RangeBarFeedDescriptor, DataInterpolationDescriptor, List<IPriceRangeLiveFeedListener>>> entrySet = map.entrySet();
/* 1374 */     for (ITwoKeyEntry<RangeBarFeedDescriptor, DataInterpolationDescriptor, List<IPriceRangeLiveFeedListener>> entry : entrySet) {
/* 1375 */       List<IPriceRangeLiveFeedListener> list = (List)entry.getValue();
/* 1376 */       if (list != null)
/*      */       {
/*      */ 
/* 1379 */         if (list.contains(listener)) {
/* 1380 */           synchronized (map) {
/* 1381 */             list.remove(listener);
/*      */           }
/*      */           
/* 1384 */           if (list.isEmpty())
/*      */           {
/* 1386 */             stopToFillInProgressPriceRange((RangeBarFeedDescriptor)entry.getKey1(), (DataInterpolationDescriptor)entry.getKey2());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void removePointAndFigureLiveFeedListener(ITwoKeyMap<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, List<IPointAndFigureLiveFeedListener>> map, IPointAndFigureLiveFeedListener listener)
/*      */   {
/* 1396 */     if ((listener == null) || (map == null)) {
/* 1397 */       return;
/*      */     }
/*      */     
/* 1400 */     Set<ITwoKeyEntry<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, List<IPointAndFigureLiveFeedListener>>> entrySet = map.entrySet();
/* 1401 */     for (ITwoKeyEntry<PointAndFigureFeedDescriptor, DataInterpolationDescriptor, List<IPointAndFigureLiveFeedListener>> entry : entrySet) {
/* 1402 */       List<IPointAndFigureLiveFeedListener> list = (List)entry.getValue();
/* 1403 */       if (list != null)
/*      */       {
/*      */ 
/* 1406 */         if (list.contains(listener)) {
/* 1407 */           synchronized (map) {
/* 1408 */             list.remove(listener);
/*      */           }
/*      */           
/* 1411 */           if (list.isEmpty())
/*      */           {
/* 1413 */             stopToFillInProgressPointAndFigure((PointAndFigureFeedDescriptor)entry.getKey1(), (DataInterpolationDescriptor)entry.getKey2());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void removeTickBarLiveFeedListener(Map<TickBarFeedDescriptor, List<ITickBarLiveFeedListener>> map, ITickBarLiveFeedListener listener)
/*      */   {
/* 1423 */     if ((listener == null) || (map == null)) {
/* 1424 */       return;
/*      */     }
/*      */     
/* 1427 */     for (Map.Entry<TickBarFeedDescriptor, List<ITickBarLiveFeedListener>> entry : map.entrySet()) {
/* 1428 */       List<ITickBarLiveFeedListener> list = (List)entry.getValue();
/* 1429 */       if (list != null)
/*      */       {
/*      */ 
/* 1432 */         if (list.contains(listener)) {
/* 1433 */           synchronized (map) {
/* 1434 */             list.remove(listener);
/*      */           }
/*      */           
/* 1437 */           if (list.isEmpty())
/*      */           {
/* 1439 */             stopToFillInProgressTickBar((TickBarFeedDescriptor)entry.getKey());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PointAndFigureData getOrLoadInProgressPointAndFigure(PointAndFigureFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1451 */     PointAndFigureData bar = getInProgressPointAndFigure(descriptor, interpolationDescriptor);
/* 1452 */     if (bar == null)
/*      */     {
/* 1454 */       LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/* 1455 */       List<LastBarLoadingProgressListener> listenerList = (List)this.lastBarLoadingProgressListeners.get(descriptor, interpolationDescriptor);
/* 1456 */       if (listenerList == null) {
/* 1457 */         listenerList = new ArrayList();
/* 1458 */         this.lastBarLoadingProgressListeners.put(descriptor, interpolationDescriptor, listenerList);
/*      */       }
/* 1460 */       listenerList.add(loadingProgressListener);
/*      */       
/* 1462 */       bar = loadLastPointAndFigure(descriptor, interpolationDescriptor, loadingProgressListener);
/*      */       
/* 1464 */       listenerList.add(loadingProgressListener);
/*      */     }
/* 1466 */     return bar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PriceRangeData getOrLoadInProgressPriceRange(RangeBarFeedDescriptor descriptor, DataInterpolationDescriptor interpolationDescriptor)
/*      */   {
/* 1474 */     PriceRangeData bar = getInProgressPriceRange(descriptor, interpolationDescriptor);
/* 1475 */     if (bar == null)
/*      */     {
/* 1477 */       LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/*      */       
/* 1479 */       List<LastBarLoadingProgressListener> listenerList = (List)this.lastBarLoadingProgressListeners.get(descriptor, interpolationDescriptor);
/* 1480 */       if (listenerList == null) {
/* 1481 */         listenerList = new ArrayList();
/* 1482 */         this.lastBarLoadingProgressListeners.put(descriptor, interpolationDescriptor, listenerList);
/*      */       }
/* 1484 */       listenerList.add(loadingProgressListener);
/*      */       
/* 1486 */       bar = loadLastPriceRange(descriptor, interpolationDescriptor, loadingProgressListener);
/*      */       
/* 1488 */       listenerList.remove(loadingProgressListener);
/*      */     }
/* 1490 */     return bar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TickBarData getOrLoadInProgressTickBar(TickBarFeedDescriptor descriptor)
/*      */   {
/* 1497 */     TickBarData bar = getInProgressTickBar(descriptor);
/* 1498 */     if (bar == null)
/*      */     {
/* 1500 */       LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/* 1501 */       List<LastBarLoadingProgressListener> listenerList = (List)this.lastBarLoadingProgressListeners.get(descriptor, DataInterpolationDescriptor.DEFAULT);
/* 1502 */       if (listenerList == null) {
/* 1503 */         listenerList = new ArrayList();
/* 1504 */         this.lastBarLoadingProgressListeners.put(descriptor, DataInterpolationDescriptor.DEFAULT, listenerList);
/*      */       }
/* 1506 */       listenerList.add(loadingProgressListener);
/*      */       
/* 1508 */       bar = loadLastTickBar(descriptor, loadingProgressListener);
/*      */       
/* 1510 */       listenerList.remove(loadingProgressListener);
/*      */     }
/* 1512 */     return bar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean waitUntilTickArrives(Instrument instrument, IWaitable waitable)
/*      */   {
/* 1521 */     int count = 1000;
/* 1522 */     while ((this.priceAggregationDataProvider.getFeedDataProvider().getLastTickTime(instrument) <= 0L) && (count > 0) && 
/* 1523 */       (waitable.mustWait()))
/*      */     {
/*      */       try
/*      */       {
/* 1527 */         Thread.sleep(100L);
/*      */       } catch (InterruptedException e) {
/* 1529 */         LOGGER.error(e.getLocalizedMessage(), e);
/*      */       }
/* 1531 */       count--;
/*      */     }
/* 1533 */     return this.priceAggregationDataProvider.getFeedDataProvider().getLastTickTime(instrument) > 0L;
/*      */   }
/*      */   
/*      */   private boolean waitForTicks(Instrument instrument, IWaitable waitable) {
/* 1537 */     boolean ticksExist = waitUntilTickArrives(instrument, waitable);
/* 1538 */     if (!ticksExist) {
/* 1539 */       if (waitable.mustWait()) {
/* 1540 */         throw new RuntimeException("There is no ticks for insrtument <" + instrument + ">");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1546 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1550 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/* 1557 */     this.actionsExecutorService.shutdown();
/*      */     try
/*      */     {
/* 1560 */       if (!this.actionsExecutorService.awaitTermination(15L, TimeUnit.SECONDS)) {
/* 1561 */         this.actionsExecutorService.shutdownNow();
/*      */       }
/*      */     } catch (InterruptedException e) {
/* 1564 */       LOGGER.error(e.getMessage(), e);
/* 1565 */       this.actionsExecutorService.shutdownNow();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void processTickForRenko(Instrument instrument, TickData tickData)
/*      */   {
/* 1573 */     for (Map.Entry<RenkoFeedDescriptor, IRenkoCreator> entry : this.inProgressRenkoCreatorsMap.entrySet()) {
/* 1574 */       IRenkoCreator creator = (IRenkoCreator)entry.getValue();
/* 1575 */       if ((creator != null) && (creator.getLastData() != null))
/*      */       {
/*      */ 
/*      */ 
/* 1579 */         if (((RenkoFeedDescriptor)entry.getKey()).getInstrument().equals(instrument)) {
/* 1580 */           if (Period.TICK.equals(((RenkoFeedDescriptor)entry.getKey()).getRenkoSession())) {
/* 1581 */             analyseTick(creator, tickData, (RenkoFeedDescriptor)entry.getKey());
/*      */           }
/*      */           else {
/* 1584 */             fireInProgressRenkoUpdated((RenkoFeedDescriptor)entry.getKey(), (RenkoData)creator.getLastData());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void analyseTick(IRenkoCreator creator, TickData tick, RenkoFeedDescriptor descriptor)
/*      */   {
/* 1595 */     creator.analyse(tick);
/*      */     
/* 1597 */     RenkoData lastCompleted = (RenkoData)creator.getLastData();
/* 1598 */     if (lastCompleted != null) {
/* 1599 */       fireInProgressRenkoUpdated(descriptor, lastCompleted);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void analyseCandleForRenko(IRenkoCreator creator, CandleData candle, RenkoFeedDescriptor descriptor)
/*      */   {
/* 1608 */     creator.analyse(candle);
/*      */     
/* 1610 */     if (creator.getLastData() != null) {
/* 1611 */       fireInProgressRenkoUpdated(descriptor, (RenkoData)creator.getLastData());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressRenko(RenkoFeedDescriptor descriptor)
/*      */   {
/* 1619 */     startToFillInProgressRenko(descriptor, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void startToFillInProgressRenko(final RenkoFeedDescriptor descriptor, IRenkoLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/* 1629 */     synchronized (this.inProgressRenkoCreatorsMap)
/*      */     {
/* 1631 */       IRenkoCreator creator = (IRenkoCreator)this.inProgressRenkoCreatorsMap.get(descriptor);
/*      */       
/* 1633 */       if (creator == null)
/*      */       {
/*      */ 
/*      */ 
/* 1637 */         final JForexPeriod jfPeriod = new JForexPeriod(DataType.RENKO, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getRenkoSession(), descriptor.getRenkoCreationPoint());
/* 1638 */         creator = new FlowRenkoCreator(descriptor.getInstrument(), descriptor.getOfferSide(), jfPeriod, Period.isInfinity(descriptor.getPeriod()));
/*      */         
/* 1640 */         creator.addListener(new IRenkoLiveFeedListener()
/*      */         {
/*      */           public void newPriceData(RenkoData renko) {
/* 1643 */             IntraperiodBarsGenerator.this.fireInProgressRenkoFormed(descriptor, renko);
/*      */           }
/*      */           
/* 1646 */         });
/* 1647 */         this.inProgressRenkoCreatorsMap.put(descriptor, creator);
/*      */         
/*      */ 
/* 1650 */         this.renkoBarCompletedInProgressBarsListenersMap.put(descriptor, new IRenkoLiveFeedListener()
/*      */         {
/*      */           public void newPriceData(RenkoData renko)
/*      */           {
/* 1654 */             IntraperiodBarsGenerator.this.paCacheManager.addCompletedIntradayBar(descriptor.getInstrument(), jfPeriod, descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS, renko);
/*      */           }
/*      */           
/*      */ 
/* 1658 */         });
/* 1659 */         addRenkoListener(descriptor, (IRenkoLiveFeedListener)this.renkoBarCompletedInProgressBarsListenersMap.get(descriptor));
/*      */         
/*      */         try
/*      */         {
/* 1663 */           this.paCacheManager.subscribeRenkoCacheDayLoading(descriptor.getInstrument(), jfPeriod, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */         } catch (DataCacheException e) {
/* 1665 */           e.printStackTrace();
/*      */         }
/*      */         
/* 1668 */         asynchLoadLastRenko(descriptor, creator, inProgressBarLoadedListener);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1673 */         if (!Period.TICK.equals(jfPeriod.getRenkoSession()))
/*      */         {
/* 1675 */           final IRenkoCreator finalCreator = creator;
/*      */           
/* 1677 */           LiveFeedListener completedCandleListener = new LiveFeedListener()
/*      */           {
/*      */             public void newCandle(Instrument instrument, Period period, OfferSide offerSide, long time, double open, double close, double low, double high, double vol)
/*      */             {
/* 1681 */               if (vol == 0.0D) {
/* 1682 */                 return;
/*      */               }
/*      */               
/* 1685 */               finalCreator.analyse(new CandleData(time, open, close, low, high, vol));
/*      */             }
/*      */             
/*      */             public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {
/* 1689 */               finalCreator.analyse(new TickData(time, ask, bid, askVol, bidVol));
/*      */             }
/* 1691 */           };
/* 1692 */           this.renkoCompletedInProgressCandlesListener.put(descriptor, completedCandleListener);
/*      */           
/* 1694 */           LiveFeedListener inProgressListener = new LiveFeedListener()
/*      */           {
/*      */             public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {}
/*      */             
/*      */ 
/*      */ 
/*      */             public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/* 1701 */           };
/* 1702 */           this.renkoInProgressCandlesListener.put(descriptor, inProgressListener);
/*      */           
/*      */           try
/*      */           {
/* 1706 */             this.paCacheManager.getFeedDataProvider().addInProgressCandleListener(descriptor.getInstrument(), descriptor.getRenkoSession(), descriptor.getOfferSide(), inProgressListener);
/* 1707 */             this.paCacheManager.getFeedDataProvider().subscribeToPeriodNotifications(descriptor.getInstrument(), descriptor.getRenkoSession(), descriptor.getOfferSide(), completedCandleListener);
/*      */           }
/*      */           catch (DataCacheException e) {
/* 1710 */             LOGGER.error(e.getMessage(), e);
/* 1711 */             stopToFillInProgressRenko(descriptor);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 1716 */       else if (inProgressBarLoadedListener != null) {
/* 1717 */         if (creator.getLastData() == null) {
/* 1718 */           JForexPeriod jfPeriod = new JForexPeriod(DataType.RENKO, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getRenkoSession(), descriptor.getRenkoCreationPoint());
/* 1719 */           FeedListenerKeyBean key = new FeedListenerKeyBean(jfPeriod, descriptor.getInstrument(), descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1725 */           LinkedList<IPriceAggregationLiveFeedListener> listeners = (LinkedList)this.listenersWaitingForInProgressBarMap.get(key);
/* 1726 */           if (listeners == null) {
/* 1727 */             listeners = new LinkedList();
/* 1728 */             this.listenersWaitingForInProgressBarMap.put(key, listeners);
/*      */           }
/* 1730 */           listeners.add(inProgressBarLoadedListener);
/* 1731 */           return;
/*      */         }
/*      */         
/* 1734 */         inProgressBarLoadedListener.newPriceData((RenkoData)creator.getLastData());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressRenkoListener(RenkoFeedDescriptor descriptor, IRenkoLiveFeedListener listener)
/*      */   {
/* 1746 */     addInProgressRenkoListener(descriptor, listener, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInProgressRenkoListener(RenkoFeedDescriptor descriptor, IRenkoLiveFeedListener listener, IRenkoLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/* 1755 */     synchronized (this.inProgressRenkoLiveFeedListenersMap) {
/* 1756 */       List<IRenkoLiveFeedListener> listeners = (List)this.inProgressRenkoLiveFeedListenersMap.get(descriptor);
/* 1757 */       if (listeners == null) {
/* 1758 */         listeners = new ArrayList();
/* 1759 */         this.inProgressRenkoLiveFeedListenersMap.put(descriptor, listeners);
/*      */       }
/* 1761 */       listeners.add(listener);
/*      */     }
/* 1763 */     startToFillInProgressRenko(descriptor, inProgressBarLoadedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRenkoNotificationListener(RenkoFeedDescriptor descriptor, IRenkoLiveFeedListener listener)
/*      */   {
/* 1771 */     addRenkoListener(descriptor, listener);
/* 1772 */     startToFillInProgressRenko(descriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void addRenkoListener(RenkoFeedDescriptor descriptor, IRenkoLiveFeedListener listener)
/*      */   {
/* 1779 */     List<IRenkoLiveFeedListener> listeners = (List)this.renkoNotificationListenersMap.get(descriptor);
/* 1780 */     if (listeners == null) {
/* 1781 */       listeners = new ArrayList();
/* 1782 */       this.renkoNotificationListenersMap.put(descriptor, listeners);
/*      */     }
/* 1784 */     listeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RenkoData getOrLoadLastCompletedRenko(RenkoFeedDescriptor descriptor)
/*      */   {
/* 1794 */     RenkoData bar = getLastCompletedRenko(descriptor);
/* 1795 */     if (bar == null)
/*      */     {
/* 1797 */       LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/* 1798 */       List<LastBarLoadingProgressListener> listenerList = (List)this.lastBarLoadingProgressListeners.get(descriptor, DataInterpolationDescriptor.DEFAULT);
/* 1799 */       if (listenerList == null) {
/* 1800 */         listenerList = new ArrayList();
/* 1801 */         this.lastBarLoadingProgressListeners.put(descriptor, DataInterpolationDescriptor.DEFAULT, listenerList);
/*      */       }
/* 1803 */       listenerList.add(loadingProgressListener);
/*      */       
/* 1805 */       bar = loadLastCompletedRenko(descriptor, loadingProgressListener);
/*      */       
/* 1807 */       listenerList.remove(loadingProgressListener);
/*      */     }
/* 1809 */     return bar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private RenkoData loadLastCompletedRenko(RenkoFeedDescriptor descriptor, LastBarLoadingProgressListener progressListener)
/*      */   {
/* 1817 */     LastRenkoLiveFeedListener lastBarListener = new LastRenkoLiveFeedListener();
/*      */     try
/*      */     {
/* 1820 */       JForexPeriod jfPeriod = new JForexPeriod(DataType.RENKO, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getRenkoSession(), descriptor.getRenkoCreationPoint());
/* 1821 */       PALoadInProgressRenkoAction loadIntraperiodBarAction = new PALoadInProgressRenkoAction(this.paCacheManager, descriptor.getInstrument(), DataInterpolationDescriptor.ALL_TICKS, descriptor.getOfferSide(), jfPeriod, true, Period.isInfinity(descriptor.getPeriod()), 5, lastBarListener, progressListener);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1833 */       loadIntraperiodBarAction.run();
/*      */     }
/*      */     catch (DataCacheException e) {
/* 1836 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */     
/* 1839 */     RenkoData lastBar = (RenkoData)lastBarListener.getLastData();
/*      */     
/*      */ 
/* 1842 */     return lastBar;
/*      */   }
/*      */   
/*      */   public void removeInProgressRenkoListener(IRenkoLiveFeedListener listener)
/*      */   {
/* 1847 */     removeRenkoLiveFeedListener(this.inProgressRenkoLiveFeedListenersMap, listener);
/*      */   }
/*      */   
/*      */   public void removeRenkoNotificationListener(IRenkoLiveFeedListener listener)
/*      */   {
/* 1852 */     removeRenkoLiveFeedListener(this.renkoNotificationListenersMap, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void removeRenkoLiveFeedListener(Map<RenkoFeedDescriptor, List<IRenkoLiveFeedListener>> map, IRenkoLiveFeedListener listener)
/*      */   {
/* 1859 */     if ((listener == null) || (map == null)) {
/* 1860 */       return;
/*      */     }
/*      */     
/* 1863 */     for (Map.Entry<RenkoFeedDescriptor, List<IRenkoLiveFeedListener>> entry : map.entrySet()) {
/* 1864 */       List<IRenkoLiveFeedListener> list = (List)entry.getValue();
/* 1865 */       if (list != null)
/*      */       {
/*      */ 
/* 1868 */         if (list.contains(listener)) {
/* 1869 */           synchronized (map) {
/* 1870 */             list.remove(listener);
/*      */           }
/*      */           
/* 1873 */           if (list.isEmpty())
/*      */           {
/* 1875 */             stopToFillInProgressRenko((RenkoFeedDescriptor)entry.getKey());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public RenkoData getInProgressRenko(RenkoFeedDescriptor descriptor)
/*      */   {
/* 1885 */     return null;
/*      */   }
/*      */   
/*      */   public RenkoData getLastCompletedRenko(RenkoFeedDescriptor descriptor)
/*      */   {
/* 1890 */     RenkoData result = null;
/* 1891 */     IRenkoCreator creator = getInProgressRenkoCreator(descriptor);
/* 1892 */     if (creator != null) {
/* 1893 */       RenkoData lastCompletedRenko = (RenkoData)creator.getLastCompletedData();
/* 1894 */       if (lastCompletedRenko != null) {
/* 1895 */         result = (RenkoData)createClone(lastCompletedRenko);
/*      */       }
/*      */     }
/* 1898 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private IRenkoCreator getInProgressRenkoCreator(RenkoFeedDescriptor descriptor)
/*      */   {
/* 1905 */     return (IRenkoCreator)this.inProgressRenkoCreatorsMap.get(descriptor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isInProgressRenkoLoadingNow(RenkoFeedDescriptor descriptor)
/*      */   {
/* 1912 */     IRenkoCreator creator = getInProgressRenkoCreator(descriptor);
/* 1913 */     return isInProgressBarLoadingNow(creator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void asynchLoadLastRenko(final RenkoFeedDescriptor descriptor, final IRenkoCreator creator, final IRenkoLiveFeedListener inProgressBarLoadedListener)
/*      */   {
/* 1922 */     Runnable runnable = new Runnable()
/*      */     {
/* 1924 */       JForexPeriod jfPeriod = new JForexPeriod(DataType.RENKO, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getRenkoSession(), descriptor.getRenkoCreationPoint());
/*      */       
/*      */       public void run()
/*      */       {
/*      */         try {
/* 1929 */           IWaitable waitable = new IWaitable()
/*      */           {
/*      */             public boolean mustWait() {
/* 1932 */               return IntraperiodBarsGenerator.this.isInProgressRenkoLoadingNow(IntraperiodBarsGenerator.14.this.val$descriptor);
/*      */             }
/*      */             
/* 1935 */           };
/* 1936 */           boolean canContinue = IntraperiodBarsGenerator.this.waitForTicks(descriptor.getInstrument(), waitable);
/* 1937 */           if (!canContinue) {
/* 1938 */             return;
/*      */           }
/*      */           
/*      */ 
/* 1942 */           LastBarLoadingProgressListener loadingProgressListener = new LastBarLoadingProgressListener();
/* 1943 */           List<LastBarLoadingProgressListener> listenerList = (List)IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.get(descriptor, DataInterpolationDescriptor.DEFAULT);
/* 1944 */           if (listenerList == null) {
/* 1945 */             listenerList = new ArrayList();
/* 1946 */             IntraperiodBarsGenerator.this.lastBarLoadingProgressListeners.put(descriptor, DataInterpolationDescriptor.DEFAULT, listenerList);
/*      */           }
/* 1948 */           listenerList.add(loadingProgressListener);
/*      */           
/* 1950 */           RenkoData lastBar = IntraperiodBarsGenerator.this.loadLastCompletedRenko(descriptor, loadingProgressListener);
/*      */           
/* 1952 */           synchronized (IntraperiodBarsGenerator.this.inProgressRenkoCreatorsMap)
/*      */           {
/* 1954 */             if (loadingProgressListener.stopJob()) {
/* 1955 */               listenerList.remove(loadingProgressListener);
/* 1956 */               return;
/*      */             }
/*      */             
/* 1959 */             listenerList.remove(loadingProgressListener);
/*      */             
/* 1961 */             if (IntraperiodBarsGenerator.this.inProgressRenkoCreatorsMap.get(descriptor) == null) {
/* 1962 */               return;
/*      */             }
/*      */             
/* 1965 */             if (lastBar == null) {
/* 1966 */               throw new RuntimeException("Unable to load last renko for <" + descriptor.getInstrument() + ">");
/*      */             }
/*      */             
/* 1969 */             creator.setupLastData(lastBar);
/*      */             
/* 1971 */             if (Period.TICK.equals(descriptor.getRenkoSession()))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 1976 */               final ITickProcessor tickProcessor = new ITickProcessor()
/*      */               {
/*      */                 public void processTick(TickData tick) {
/* 1979 */                   IntraperiodBarsGenerator.this.analyseTick(IntraperiodBarsGenerator.14.this.val$creator, tick, IntraperiodBarsGenerator.14.this.val$descriptor);
/*      */                 }
/*      */                 
/* 1982 */               };
/* 1983 */               long currentInstrumentTime = IntraperiodBarsGenerator.this.paCacheManager.getFeedDataProvider().getCurrentTime(descriptor.getInstrument());
/* 1984 */               final long[] lastGivenTickTime = { Long.MIN_VALUE };
/*      */               
/* 1986 */               if (currentInstrumentTime > creator.getCreateBarsFromTime())
/*      */               {
/* 1988 */                 LiveFeedListener tickListener = new LiveFeedListener() {
/*      */                   public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {}
/*      */                   
/*      */                   public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {
/* 1992 */                     tickProcessor.processTick(new TickData(time, ask, bid, askVol, bidVol));
/* 1993 */                     lastGivenTickTime[0] = time;
/*      */                   }
/*      */                   
/* 1996 */                 };
/* 1997 */                 IntraperiodBarsGenerator.this.paCacheManager.getFeedDataProvider().loadTicksDataSynched(descriptor.getInstrument(), creator.getCreateBarsFromTime(), currentInstrumentTime, tickListener, new LoadingProgressAdapter() {});
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2006 */               IntraperiodBarsGenerator.this.processLastReceivedTicksWhileLastBarWasLoading(lastGivenTickTime[0] > Long.MIN_VALUE ? lastGivenTickTime[0] + 1L : creator.getCreateBarsFromTime(), descriptor.getInstrument(), tickProcessor);
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 2016 */               final ICandleProcessor candleProcessor = new ICandleProcessor()
/*      */               {
/*      */                 public void processCandle(CandleData candle)
/*      */                 {
/* 2020 */                   if (candle.getVolume() == 0.0D) {
/* 2021 */                     return;
/*      */                   }
/* 2023 */                   IntraperiodBarsGenerator.this.analyseCandleForRenko(IntraperiodBarsGenerator.14.this.val$creator, candle, IntraperiodBarsGenerator.14.this.val$descriptor);
/*      */                 }
/*      */                 
/* 2026 */               };
/* 2027 */               long currentInstrumentTime = IntraperiodBarsGenerator.this.paCacheManager.getFeedDataProvider().getCurrentTime(descriptor.getInstrument());
/* 2028 */               final long[] lastGivenCandleTime = { Long.MIN_VALUE };
/*      */               
/* 2030 */               if ((currentInstrumentTime > Long.MIN_VALUE) && (DataCacheUtils.getCandleStartFast(descriptor.getRenkoSession(), currentInstrumentTime) > creator.getCreateBarsFromTime()))
/*      */               {
/*      */ 
/*      */ 
/* 2034 */                 long loadTo = DataCacheUtils.getCandleStartFast(descriptor.getRenkoSession(), currentInstrumentTime);
/* 2035 */                 CandleData inProgressCandle = IntraperiodBarsGenerator.this.paCacheManager.getFeedDataProvider().getInProgressCandle(descriptor.getInstrument(), descriptor.getRenkoSession(), descriptor.getOfferSide());
/* 2036 */                 if (inProgressCandle != null) {
/* 2037 */                   loadTo = DataCacheUtils.getPreviousCandleStartFast(descriptor.getRenkoSession(), inProgressCandle.getTime());
/*      */                 }
/*      */                 
/*      */ 
/* 2041 */                 if (loadTo >= creator.getCreateBarsFromTime())
/*      */                 {
/* 2043 */                   LiveFeedListener candleListener = new LiveFeedListener() {
/*      */                     public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {
/* 2045 */                       candleProcessor.processCandle(new CandleData(time, open, close, low, high, vol));
/* 2046 */                       lastGivenCandleTime[0] = time;
/*      */                     }
/*      */                     
/*      */ 
/*      */ 
/*      */                     public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/* 2052 */                   };
/* 2053 */                   IntraperiodBarsGenerator.this.paCacheManager.getFeedDataProvider().loadCandlesDataSynched(descriptor.getInstrument(), descriptor.getRenkoSession(), descriptor.getOfferSide(), creator.getCreateBarsFromTime(), loadTo, candleListener, new LoadingProgressAdapter() {});
/*      */                 }
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2064 */               long loadAdditionalFrom = lastGivenCandleTime[0] > Long.MIN_VALUE ? DataCacheUtils.getNextCandleStartFast(descriptor.getRenkoSession(), lastGivenCandleTime[0]) : creator.getCreateBarsFromTime();
/* 2065 */               IntraperiodBarsGenerator.this.processLastReceivedCandleWhileLastBarWasLoading(loadAdditionalFrom, descriptor.getInstrument(), descriptor.getOfferSide(), descriptor.getRenkoSession(), candleProcessor);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2074 */             FeedListenerKeyBean key = new FeedListenerKeyBean(this.jfPeriod, descriptor.getInstrument(), descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2080 */             IntraperiodBarsGenerator.this.informListeners(key, creator.getLastData());
/*      */           }
/*      */           
/* 2083 */           if (inProgressBarLoadedListener != null) {
/* 2084 */             inProgressBarLoadedListener.newPriceData((RenkoData)creator.getLastData());
/*      */           }
/*      */         }
/*      */         catch (Throwable t) {
/* 2088 */           IntraperiodBarsGenerator.LOGGER.error("Failed to load in progress bar " + t.getLocalizedMessage(), t);
/* 2089 */           IntraperiodBarsGenerator.this.stopToFillInProgressRenko(descriptor);
/*      */         }
/*      */       }
/* 2092 */     };
/* 2093 */     invoke(runnable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void stopToFillInProgressRenko(RenkoFeedDescriptor descriptor)
/*      */   {
/* 2100 */     synchronized (this.inProgressRenkoCreatorsMap) {
/* 2101 */       this.inProgressRenkoCreatorsMap.remove(descriptor);
/*      */       
/* 2103 */       List<LastBarLoadingProgressListener> list = (List)this.lastBarLoadingProgressListeners.get(descriptor, DataInterpolationDescriptor.DEFAULT);
/* 2104 */       if (list != null) {
/* 2105 */         for (LastBarLoadingProgressListener l : list) {
/* 2106 */           l.setStopJob(true);
/*      */         }
/* 2108 */         list.clear();
/*      */       }
/*      */       
/* 2111 */       JForexPeriod jfPeriod = new JForexPeriod(DataType.RENKO, descriptor.getPeriod(), descriptor.getPriceRange(), descriptor.getRenkoSession(), descriptor.getRenkoCreationPoint());
/* 2112 */       this.paCacheManager.unsubscribeCacheDayLoading(descriptor.getInstrument(), jfPeriod, DataInterpolationDescriptor.ALL_TICKS, descriptor.getOfferSide(), Period.isInfinity(descriptor.getPeriod()), true);
/*      */       
/* 2114 */       this.paCacheManager.flushDelayedWriteTasks();
/* 2115 */       removeRenkoNotificationListener((IRenkoLiveFeedListener)this.renkoBarCompletedInProgressBarsListenersMap.remove(descriptor));
/*      */       
/* 2117 */       FeedListenerKeyBean key = new FeedListenerKeyBean(jfPeriod, descriptor.getInstrument(), descriptor.getOfferSide(), DataInterpolationDescriptor.ALL_TICKS);
/* 2118 */       this.listenersWaitingForInProgressBarMap.remove(key);
/*      */       
/*      */ 
/* 2121 */       if (!Period.TICK.equals(descriptor.getRenkoSession())) {
/* 2122 */         LiveFeedListener listener = (LiveFeedListener)this.renkoCompletedInProgressCandlesListener.remove(descriptor);
/* 2123 */         if (listener != null) {
/* 2124 */           this.paCacheManager.getFeedDataProvider().unsubscribeFromPeriodNotifications(descriptor.getInstrument(), descriptor.getRenkoSession(), descriptor.getOfferSide(), listener);
/*      */         }
/* 2126 */         LiveFeedListener inProgressListener = (LiveFeedListener)this.renkoInProgressCandlesListener.remove(descriptor);
/* 2127 */         if (inProgressListener != null) {
/* 2128 */           this.paCacheManager.getFeedDataProvider().removeInProgressCandleListener(descriptor.getInstrument(), descriptor.getRenkoSession(), descriptor.getOfferSide(), inProgressListener);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireInProgressRenkoFormed(RenkoFeedDescriptor descriptor, RenkoData bar)
/*      */   {
/* 2139 */     fireRenko(descriptor, bar, this.renkoNotificationListenersMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void fireInProgressRenkoUpdated(RenkoFeedDescriptor descriptor, RenkoData bar)
/*      */   {
/* 2146 */     List<IRenkoLiveFeedListener> listeners = new ArrayList();
/* 2147 */     listeners.addAll((Collection)this.inProgressRenkoLiveFeedListenersMap.get(descriptor));
/* 2148 */     for (IRenkoLiveFeedListener listener : listeners) {
/* 2149 */       listener.newPriceData(bar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireRenko(RenkoFeedDescriptor descriptor, RenkoData bar, Map<RenkoFeedDescriptor, List<IRenkoLiveFeedListener>> map)
/*      */   {
/* 2158 */     List<IRenkoLiveFeedListener> listeners = new ArrayList();
/* 2159 */     listeners.addAll((Collection)map.get(descriptor));
/* 2160 */     for (IRenkoLiveFeedListener l : listeners) {
/* 2161 */       l.newPriceData(bar);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\IntraperiodBarsGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */