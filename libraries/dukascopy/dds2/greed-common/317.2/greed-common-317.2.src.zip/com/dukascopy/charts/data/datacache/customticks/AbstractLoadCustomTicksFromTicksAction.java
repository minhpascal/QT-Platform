/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.api.util.DateUtils;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.metadata.IFeedMetadataManager;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractLoadCustomTicksFromTicksAction
/*    */   extends AbstractLoadCustomTicksAction
/*    */ {
/* 23 */   private static final Logger LOGGER = LoggerFactory.getLogger(AbstractLoadCustomTicksFromTicksAction.class);
/*    */   
/*    */ 
/*    */   protected final IFeedDataProvider feedDataProvider;
/*    */   
/*    */ 
/*    */   protected final Instrument instrument;
/*    */   
/*    */ 
/*    */   protected final ILoadingProgressListener loadingProgressListener;
/*    */   
/*    */ 
/*    */ 
/*    */   public AbstractLoadCustomTicksFromTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 38 */     super(from, to);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 43 */     this.feedDataProvider = feedDataProvider;
/* 44 */     this.instrument = instrument;
/* 45 */     this.loadingProgressListener = loadingProgressListener;
/*    */     
/* 47 */     validateFromTo();
/*    */   }
/*    */   
/*    */   protected void validateFromTo() {
/* 51 */     long lastTickTime = this.feedDataProvider.getLastTickTime(this.instrument);
/* 52 */     if (this.to > lastTickTime) {
/* 53 */       throw new IllegalArgumentException("to(" + DateUtils.format(this.to) + ") > last tick time (" + lastTickTime + ")");
/*    */     }
/*    */     
/* 56 */     long firstTickTime = this.feedDataProvider.getFeedMetadataManager().getTimeOfFirstTick(this.instrument);
/* 57 */     if (this.from < firstTickTime) {
/* 58 */       throw new IllegalArgumentException("from(" + DateUtils.format(this.from) + ") < first tick time (" + firstTickTime + ")");
/*    */     }
/*    */   }
/*    */   
/*    */   public void run()
/*    */   {
/* 64 */     LiveFeedListener feedListener = new LiveFeedListener()
/*    */     {
/*    */       public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {}
/*    */       
/*    */       public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol)
/*    */       {
/* 70 */         AbstractLoadCustomTicksFromTicksAction.this.tickReceived(time, ask, bid, askVol, bidVol);
/*    */       }
/*    */     };
/*    */     try
/*    */     {
/* 75 */       this.feedDataProvider.loadTicksDataBlockingSynched(this.instrument, this.from, this.to, feedListener, this.loadingProgressListener);
/*    */ 
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/*    */ 
/* 83 */       LOGGER.error(e.getLocalizedMessage(), e);
/* 84 */       this.loadingProgressListener.loadingFinished(false, this.from, this.to, this.from, e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void tickReceived(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\AbstractLoadCustomTicksFromTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */