/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadDifferentPriceTicksAction
/*    */   extends AbstractLoadCustomTicksFromTicksAction
/*    */ {
/*    */   private final TickFeedListener feedListener;
/*    */   private TickData previousTick;
/*    */   
/*    */   public LoadDifferentPriceTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 31 */     super(feedDataProvider, instrument, from, to, loadingProgressListener);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 38 */     this.feedListener = feedListener;
/*    */   }
/*    */   
/*    */   protected void tickReceived(long time, double ask, double bid, double askVol, double bidVol)
/*    */   {
/* 43 */     if ((this.previousTick == null) || (this.previousTick.getAsk() != ask) || (this.previousTick.getBid() != bid))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/* 48 */       this.feedListener.newTick(this.instrument, time, ask, bid, askVol, bidVol);
/*    */     }
/* 50 */     this.previousTick = new TickData(time, ask, bid, askVol, bidVol);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadDifferentPriceTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */