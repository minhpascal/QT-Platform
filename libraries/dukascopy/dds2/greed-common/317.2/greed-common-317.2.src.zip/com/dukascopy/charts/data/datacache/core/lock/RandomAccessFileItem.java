/*    */ package com.dukascopy.charts.data.datacache.core.lock;
/*    */ 
/*    */ import java.io.RandomAccessFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomAccessFileItem
/*    */ {
/*    */   private RandomAccessFile randomAccessFile;
/*    */   private boolean isInUse;
/*    */   
/*    */   public RandomAccessFileItem(RandomAccessFile randomAccessFile)
/*    */   {
/* 19 */     this(randomAccessFile, false);
/*    */   }
/*    */   
/*    */   public RandomAccessFileItem(RandomAccessFile randomAccessFile, boolean isInUse) {
/* 23 */     this.randomAccessFile = randomAccessFile;
/* 24 */     this.isInUse = isInUse;
/*    */   }
/*    */   
/*    */   public RandomAccessFile getRandomAccessFile() {
/* 28 */     return this.randomAccessFile;
/*    */   }
/*    */   
/*    */   public void setRandomAccessFile(RandomAccessFile randomAccessFile) {
/* 32 */     this.randomAccessFile = randomAccessFile;
/*    */   }
/*    */   
/*    */   public boolean isInUse() {
/* 36 */     return this.isInUse;
/*    */   }
/*    */   
/*    */   public void setInUse(boolean isInUse) {
/* 40 */     this.isInUse = isInUse;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 45 */     int prime = 31;
/* 46 */     int result = 1;
/* 47 */     result = 31 * result + (this.isInUse ? 1231 : 1237);
/* 48 */     result = 31 * result + (this.randomAccessFile == null ? 0 : this.randomAccessFile.hashCode());
/* 49 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 54 */     if (this == obj)
/* 55 */       return true;
/* 56 */     if (obj == null)
/* 57 */       return false;
/* 58 */     if (getClass() != obj.getClass())
/* 59 */       return false;
/* 60 */     RandomAccessFileItem other = (RandomAccessFileItem)obj;
/* 61 */     if (this.isInUse != other.isInUse)
/* 62 */       return false;
/* 63 */     if (this.randomAccessFile == null) {
/* 64 */       if (other.randomAccessFile != null)
/* 65 */         return false;
/* 66 */     } else if (!this.randomAccessFile.equals(other.randomAccessFile))
/* 67 */       return false;
/* 68 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\lock\RandomAccessFileItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */