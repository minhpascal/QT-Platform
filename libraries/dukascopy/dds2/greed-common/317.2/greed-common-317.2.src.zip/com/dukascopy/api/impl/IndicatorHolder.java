/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.indicators.IIndicator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IndicatorHolder
/*    */ {
/*    */   private IIndicator indicator;
/*    */   private IndicatorContext indicatorContext;
/*    */   
/*    */   public IndicatorHolder(IIndicator indicator, IndicatorContext indicatorContext)
/*    */   {
/* 17 */     this.indicator = indicator;
/* 18 */     this.indicatorContext = indicatorContext;
/*    */   }
/*    */   
/*    */   public IIndicator getIndicator() {
/* 22 */     return this.indicator;
/*    */   }
/*    */   
/*    */   public IndicatorContext getIndicatorContext() {
/* 26 */     return this.indicatorContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\IndicatorHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */