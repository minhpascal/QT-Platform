package com.dukascopy.charts.data.datacache.intraperiod;

import com.dukascopy.charts.data.datacache.TickData;

public abstract interface ITickProcessor
{
  public abstract void processTick(TickData paramTickData);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\ITickProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */