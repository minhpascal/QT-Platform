/*    */ package com.dukascopy.api.impl.execution.post;
/*    */ 
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ import com.dukascopy.api.ITick;
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.feed.ITickFeedListener;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.impl.execution.Task.Type;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostTickTask
/*    */   extends AbstractPostBarTask
/*    */ {
/* 25 */   private static final Logger LOGGER = LoggerFactory.getLogger(PostTickTask.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private final ITickFeedListener tickFeedListener;
/*    */   
/*    */ 
/*    */   private final ITick tick;
/*    */   
/*    */ 
/*    */   private long addedTime;
/*    */   
/*    */ 
/*    */ 
/*    */   public PostTickTask(JForexTaskManager<?, ?, ?> taskManager, IJFRunnable<?> strategy, IStrategyExceptionHandler exceptionHandler, ITickFeedListener tickFeedListener, Instrument instrument, ITick tick)
/*    */   {
/* 41 */     super(taskManager, strategy, exceptionHandler, instrument, OfferSide.BID);
/* 42 */     this.tickFeedListener = tickFeedListener;
/* 43 */     this.addedTime = System.currentTimeMillis();
/* 44 */     this.tick = tick;
/*    */   }
/*    */   
/*    */   protected Logger getLogger()
/*    */   {
/* 49 */     return LOGGER;
/*    */   }
/*    */   
/*    */   protected void postData() throws Throwable
/*    */   {
/* 54 */     this.tickFeedListener.onTick(this.instrument, this.tick);
/*    */   }
/*    */   
/*    */   protected IStrategyExceptionHandler.Source getSource()
/*    */   {
/* 59 */     return IStrategyExceptionHandler.Source.ON_TICK;
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 64 */     return Task.Type.TICK;
/*    */   }
/*    */   
/*    */   public ITick getTick() {
/* 68 */     return this.tick;
/*    */   }
/*    */   
/*    */   public long getAddedTime() {
/* 72 */     return this.addedTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\post\PostTickTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */