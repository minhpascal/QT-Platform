/*    */ package com.dukascopy.charts.data.datacache.ccheck;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MFInnerDataComparator
/*    */   implements Comparator<MFEntry>
/*    */ {
/*    */   public int compare(MFEntry o1, MFEntry o2)
/*    */   {
/* 17 */     if (o1.getChunkTime() < o2.getChunkTime()) {
/* 18 */       return -1;
/*    */     }
/* 20 */     if (o1.getChunkTime() > o2.getChunkTime()) {
/* 21 */       return 1;
/*    */     }
/*    */     
/* 24 */     int instrCompResult = o1.getInstrument().toString().compareTo(o2.getInstrument().toString());
/*    */     
/* 26 */     if (instrCompResult == 0) {
/* 27 */       if ((o1.getSide() == null) && (o2.getSide() == null)) {
/* 28 */         return 0;
/*    */       }
/* 30 */       if ((o1.getSide() != null) && (o2.getSide() == null)) {
/* 31 */         return -1;
/*    */       }
/* 33 */       if ((o1.getSide() == null) && (o2.getSide() != null)) {
/* 34 */         return 1;
/*    */       }
/* 36 */       return o1.getSide().compareTo(o2.getSide());
/*    */     }
/*    */     
/* 39 */     return instrCompResult;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFInnerDataComparator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */