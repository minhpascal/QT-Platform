package com.dukascopy.calculator.function;

import com.dukascopy.calculator.OObject;

public abstract class MFunction
  extends PObject
{
  public abstract double function(double paramDouble1, double paramDouble2);
  
  public abstract OObject function(OObject paramOObject1, OObject paramOObject2);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\MFunction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */