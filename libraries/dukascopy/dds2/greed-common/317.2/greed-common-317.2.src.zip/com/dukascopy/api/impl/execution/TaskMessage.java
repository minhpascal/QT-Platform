/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IMessage;
/*    */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.plugins.IMessageListener;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*    */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*    */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskMessage
/*    */   implements Task<Object>
/*    */ {
/* 22 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskMessage.class);
/*    */   
/*    */   private final JForexTaskManager<?, ?, ?> taskManager;
/*    */   private final IMessageListener messageListener;
/*    */   private final IMessage message;
/*    */   private final IStrategyExceptionHandler exceptionHandler;
/* 28 */   private boolean release = false;
/*    */   private StrategyEventsCallback strategyEventsCallback;
/*    */   
/*    */   public TaskMessage(JForexTaskManager<?, ?, ?> taskManager, IMessageListener messageListener, IMessage message, IStrategyExceptionHandler exceptionHandler) {
/* 32 */     this.messageListener = messageListener;
/* 33 */     this.message = message;
/* 34 */     this.exceptionHandler = exceptionHandler;
/* 35 */     this.taskManager = taskManager;
/* 36 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 41 */     return Task.Type.MESSAGE;
/*    */   }
/*    */   
/*    */   public boolean release() {
/* 45 */     return this.release;
/*    */   }
/*    */   
/*    */   public void setRelease(boolean release) {
/* 49 */     this.release = release;
/*    */   }
/*    */   
/*    */   public Object call() throws Exception
/*    */   {
/* 54 */     if ((this.taskManager.isStrategyStopping()) || (this.messageListener == null)) {
/* 55 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 59 */       this.messageListener.onMessage(this.message);
/* 60 */       if (this.strategyEventsCallback != null) {
/* 61 */         this.strategyEventsCallback.onMessage(this.message);
/*    */       }
/*    */     } catch (Throwable t) {
/* 64 */       String msg = ErrorHelper.representError(this.messageListener, t);
/* 65 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 66 */       LOGGER.error(t.getMessage(), t);
/* 67 */       this.exceptionHandler.onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_MESSAGE, t);
/*    */     }
/* 69 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */