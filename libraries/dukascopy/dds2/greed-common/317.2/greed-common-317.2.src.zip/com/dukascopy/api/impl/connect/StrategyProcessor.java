/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IAccount;
/*    */ import com.dukascopy.api.IBar;
/*    */ import com.dukascopy.api.IContext;
/*    */ import com.dukascopy.api.IMessage;
/*    */ import com.dukascopy.api.IStrategy;
/*    */ import com.dukascopy.api.ITick;
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.api.impl.execution.Task;
/*    */ import com.dukascopy.api.impl.execution.TaskAccount;
/*    */ import com.dukascopy.api.impl.execution.TaskOnBar;
/*    */ import com.dukascopy.api.impl.execution.TaskTick;
/*    */ import com.dukascopy.api.plugins.IMessageListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrategyProcessor
/*    */   extends JFRunnableProcessor<IContext, IStrategy>
/*    */ {
/*    */   public StrategyProcessor(JForexTaskManager taskManager, IStrategy strategy, boolean fullAccessGranted)
/*    */   {
/* 28 */     super(taskManager, new IMessageListener()
/*    */     {
/*    */ 
/*    */       public void onMessage(IMessage message) throws JFException {
/* 32 */         StrategyProcessor.this.onMessage(message); } }, strategy, fullAccessGranted);
/*    */   }
/*    */   
/*    */ 
/*    */   public void updateAccountInfo(IAccount account)
/*    */   {
/* 38 */     Task task = new TaskAccount(this.taskManager, (IStrategy)this.jfRunnable, account, this.taskManager.getExceptionHandler());
/* 39 */     executeTask(task, false);
/*    */   }
/*    */   
/*    */   public void onMarket(Instrument instrument, ITick tick) {
/* 43 */     Task task = new TaskTick(this.taskManager, (IStrategy)this.jfRunnable, instrument, tick, this.taskManager.getExceptionHandler());
/* 44 */     executeTask(task, false);
/*    */   }
/*    */   
/*    */   public void onBar(Instrument instrument, Period period, IBar askBar, IBar bidBar)
/*    */   {
/* 49 */     Task task = new TaskOnBar(this.taskManager, this, instrument, period, askBar, bidBar, this.taskManager.getExceptionHandler());
/* 50 */     executeTask(task, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\StrategyProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */