/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.DataType;
/*     */ import com.dukascopy.api.Filter;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.Unit;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.api.impl.IndicatorWrapper;
/*     */ import com.dukascopy.api.system.tester.ITesterChartController;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.TimeDataUtils;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.BalanceHistoricalTesterIndicator;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.EquityHistoricalTesterIndicator;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.ProfLossHistoricalTesterIndicator;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.TesterIndicatorWrapper;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TesterChartControllerImpl
/*     */   extends ClientChartController
/*     */   implements ITesterChartController
/*     */ {
/*     */   private LinkedList<TesterIndicatorWrapper> indicatorsWrappers;
/*     */   
/*     */   public TesterChartControllerImpl(DDSChartsController ddsChartsController, int chartPanelId, LinkedList<TesterIndicatorWrapper> indicatorsWrappers)
/*     */   {
/*  32 */     super(ddsChartsController, chartPanelId);
/*  33 */     this.indicatorsWrappers = indicatorsWrappers;
/*     */   }
/*     */   
/*     */   public void changePeriod(DataType dataType, Period period)
/*     */   {
/*  38 */     if (isValid()) {
/*  39 */       JForexPeriod jForexPeriod = new JForexPeriod(dataType, period);
/*  40 */       this.ddsChartsController.changeJForexPeriod(Integer.valueOf(this.chartPanelId), jForexPeriod);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFeedDescriptor(IFeedDescriptor feedDescriptor)
/*     */   {
/*  46 */     if (feedDescriptor == null) {
/*  47 */       throw new IllegalArgumentException("feedDescriptor is null ");
/*     */     }
/*  49 */     if (isValid()) {
/*  50 */       JForexPeriod jForexPeriod = createJForexPeriod(feedDescriptor);
/*  51 */       this.ddsChartsController.changeJForexPeriod(Integer.valueOf(this.chartPanelId), jForexPeriod);
/*  52 */       this.ddsChartsController.changeFilter(feedDescriptor.getFilter());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setChartAutoShift()
/*     */   {
/*  58 */     if (isValid()) {
/*  59 */       this.ddsChartsController.shiftChartToFront(Integer.valueOf(this.chartPanelId));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void zoomIn()
/*     */   {
/*  66 */     if (isValid()) {
/*  67 */       this.ddsChartsController.zoomIn(Integer.valueOf(this.chartPanelId));
/*     */     }
/*     */   }
/*     */   
/*     */   public void zoomOut()
/*     */   {
/*  73 */     if (isValid()) {
/*  74 */       this.ddsChartsController.zoomOut(Integer.valueOf(this.chartPanelId));
/*     */     }
/*     */   }
/*     */   
/*     */   public void switchOfferSide(OfferSide offerSide)
/*     */   {
/*  80 */     if (isValid()) {
/*  81 */       this.ddsChartsController.switchBidAskTo(Integer.valueOf(this.chartPanelId), offerSide);
/*     */     }
/*     */   }
/*     */   
/*     */   public void showEquityIndicator(boolean show)
/*     */   {
/*  87 */     boolean notFound = true;
/*  88 */     for (TesterIndicatorWrapper testerIndicatorWrapper : this.indicatorsWrappers) {
/*  89 */       if ((testerIndicatorWrapper.getIndicator() instanceof EquityHistoricalTesterIndicator)) {
/*  90 */         notFound = false;
/*  91 */         showTesterIndicator(this.chartPanelId, testerIndicatorWrapper, show);
/*  92 */         break;
/*     */       }
/*     */     }
/*  95 */     if (notFound) {
/*  96 */       throw new IllegalStateException("Equity indicator wasn't enabled, see ITesterIndicatorsParameters.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void showProfitLossIndicator(boolean show)
/*     */   {
/* 102 */     boolean notFound = true;
/* 103 */     for (TesterIndicatorWrapper testerIndicatorWrapper : this.indicatorsWrappers) {
/* 104 */       if ((testerIndicatorWrapper.getIndicator() instanceof ProfLossHistoricalTesterIndicator)) {
/* 105 */         notFound = false;
/* 106 */         showTesterIndicator(this.chartPanelId, testerIndicatorWrapper, show);
/* 107 */         break;
/*     */       }
/*     */     }
/* 110 */     if (notFound) {
/* 111 */       throw new IllegalStateException("ProfitLoss indicator wasn't enabled, see ITesterIndicatorsParameters.");
/*     */     }
/*     */   }
/*     */   
/*     */   public void showBalanceIndicator(boolean show)
/*     */   {
/* 117 */     boolean notFound = true;
/* 118 */     for (TesterIndicatorWrapper testerIndicatorWrapper : this.indicatorsWrappers) {
/* 119 */       if ((testerIndicatorWrapper.getIndicator() instanceof BalanceHistoricalTesterIndicator)) {
/* 120 */         notFound = false;
/* 121 */         showTesterIndicator(this.chartPanelId, testerIndicatorWrapper, show);
/* 122 */         break;
/*     */       }
/*     */     }
/* 125 */     if (notFound) {
/* 126 */       throw new IllegalStateException("Balance indicator wasn't enabled, see ITesterIndicatorsParameters.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter getFilter()
/*     */   {
/* 135 */     return this.ddsChartsController.getFilter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilter(Filter filter)
/*     */   {
/* 143 */     this.ddsChartsController.changeFilter(filter);
/*     */   }
/*     */   
/*     */   private void showTesterIndicator(int chartPanelId, TesterIndicatorWrapper testerIndicatorWrapper, boolean show) {
/* 147 */     List<IndicatorWrapper> wrappers = this.ddsChartsController.getIndicators(Integer.valueOf(chartPanelId));
/* 148 */     if (show) {
/* 149 */       if ((wrappers == null) || (!wrappers.contains(testerIndicatorWrapper))) {
/* 150 */         this.ddsChartsController.addIndicator(Integer.valueOf(chartPanelId), testerIndicatorWrapper);
/*     */       }
/*     */     }
/* 153 */     else if ((wrappers != null) && (wrappers.contains(testerIndicatorWrapper))) {
/* 154 */       this.ddsChartsController.deleteIndicator(Integer.valueOf(chartPanelId), testerIndicatorWrapper);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JForexPeriod createJForexPeriod(IFeedDescriptor feedDescriptor)
/*     */   {
/* 165 */     if (feedDescriptor.getDataType() == null)
/* 166 */       throw new IllegalArgumentException("DataType is null ");
/*     */     JForexPeriod jForexPeriod;
/* 168 */     switch (feedDescriptor.getDataType()) {
/*     */     case TICKS: 
/* 170 */       jForexPeriod = new JForexPeriod(feedDescriptor.getDataType(), Period.TICK);
/*     */       
/*     */ 
/*     */ 
/* 174 */       break;
/*     */     case TIME_PERIOD_AGGREGATION: 
/* 176 */       if (feedDescriptor.getPeriod() == null) {
/* 177 */         throw new IllegalArgumentException("Period is null ");
/*     */       }
/* 179 */       jForexPeriod = new JForexPeriod(feedDescriptor.getDataType(), feedDescriptor.getPeriod());
/*     */       
/*     */ 
/*     */ 
/* 183 */       break;
/*     */     case PRICE_RANGE_AGGREGATION: 
/* 185 */       if (feedDescriptor.getPriceRange() == null) {
/* 186 */         throw new IllegalArgumentException("PriceRange is null ");
/*     */       }
/* 188 */       Period period = checkPeriod(feedDescriptor.getPeriod());
/* 189 */       jForexPeriod = new JForexPeriod(feedDescriptor.getDataType(), period, feedDescriptor.getPriceRange());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 194 */       break;
/*     */     
/*     */     case POINT_AND_FIGURE: 
/* 197 */       if (feedDescriptor.getPriceRange() == null) {
/* 198 */         throw new IllegalArgumentException("PriceRange is null ");
/*     */       }
/* 200 */       if (feedDescriptor.getReversalAmount() == null) {
/* 201 */         throw new IllegalArgumentException("ReversalAmount is null ");
/*     */       }
/* 203 */       Period period = checkPeriod(feedDescriptor.getPeriod());
/* 204 */       jForexPeriod = new JForexPeriod(feedDescriptor.getDataType(), period, feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */       break;
/*     */     
/*     */     case TICK_BAR: 
/* 213 */       if (feedDescriptor.getTickBarSize() == null) {
/* 214 */         throw new IllegalArgumentException("TickBarSize is null ");
/*     */       }
/* 216 */       Period period = checkPeriod(feedDescriptor.getPeriod());
/* 217 */       jForexPeriod = new JForexPeriod(feedDescriptor.getDataType(), period, feedDescriptor.getTickBarSize());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 222 */       break;
/*     */     
/*     */     case RENKO: 
/* 225 */       if (feedDescriptor.getPriceRange() == null) {
/* 226 */         throw new IllegalArgumentException("PriceRange is null ");
/*     */       }
/* 228 */       Period period = checkPeriod(feedDescriptor.getPeriod());
/* 229 */       jForexPeriod = new JForexPeriod(feedDescriptor.getDataType(), period, feedDescriptor.getPriceRange());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 234 */       break;
/*     */     default: 
/* 236 */       throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*     */     }
/* 238 */     return jForexPeriod;
/*     */   }
/*     */   
/*     */   private Period checkPeriod(Period period) {
/* 242 */     if ((period == null) || (period.getUnit() == null) || (!Unit.Day.equals(period.getUnit())) || (period.getNumOfUnits() < 1) || (period.getNumOfUnits() > 7))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */       period = TimeDataUtils.getDefaultSessionPeriod();
/*     */     }
/* 250 */     return period;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\TesterChartControllerImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */