/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IClientGUIListener;
/*     */ import com.dukascopy.api.IConsole;
/*     */ import com.dukascopy.api.IContext;
/*     */ import com.dukascopy.api.IStrategy;
/*     */ import com.dukascopy.api.IStrategyListener;
/*     */ import com.dukascopy.api.IUserInterface;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.impl.connect.validation.IOrderValidator;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.LiveCandleListener;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessage;
/*     */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessageInit;
/*     */ import com.dukascopy.dds4.transport.client.TransportClient;
/*     */ import com.dukascopy.dds4.transport.msg.system.CurrencyMarket;
/*     */ import com.dukascopy.dds4.transport.msg.system.CurrencyOffer;
/*     */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*     */ import java.io.File;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class StrategyTaskManager extends JForexTaskManager<IContext, IStrategy, IUserInterface> implements LiveCandleListener
/*     */ {
/*     */   private IOrderValidator orderValidator;
/*     */   
/*     */   public static class Builder extends JForexTaskManager.Builder<IContext, IStrategy, IUserInterface, StrategyTaskManager>
/*     */   {
/*     */     private IUserInterface userInterface;
/*     */     
/*     */     private Builder(IUserInterface userInterface)
/*     */     {
/*  40 */       this.userInterface = userInterface;
/*     */     }
/*     */     
/*     */     public static Builder newPlatformInstance(IUserInterface userInterface) {
/*  44 */       return new Builder(userInterface);
/*     */     }
/*     */     
/*     */     public static Builder newSdkInstance() {
/*  48 */       return new Builder(new FacelessUserInterface());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StrategyTaskManager build(JForexTaskManager.Environment environment, boolean live, String accountName, IConsole console, TransportClient transportClient, IStrategyExceptionHandler exceptionHandler, AccountInfoMessage lastAccountInfo, AccountInfoMessageInit lastAccountInfoInit, String externalIP, String internalIP, String sessionID)
/*     */     {
/*  64 */       return build(environment, live, accountName, console, transportClient, null, new DefaultLotAmountProvider(), exceptionHandler, lastAccountInfo, lastAccountInfoInit, externalIP, internalIP, sessionID, new Properties(), null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public StrategyTaskManager build(JForexTaskManager.Environment environment, boolean live, String accountName, IConsole console, TransportClient transportClient, DDSChartsController ddsChartsController, ILotAmountProvider lotAmountProvider, IStrategyExceptionHandler exceptionHandler, AccountInfoMessage lastAccountInfo, AccountInfoMessageInit lastAccountInfoInit, String externalIP, String internalIP, String sessionID, Properties serverProperties, IClientGUIListener clientGUIListener)
/*     */     {
/*  84 */       return new StrategyTaskManager(environment, live, accountName, console, transportClient, ddsChartsController, lotAmountProvider, this.userInterface, exceptionHandler, lastAccountInfo, lastAccountInfoInit, externalIP, internalIP, sessionID, serverProperties, clientGUIListener, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private StrategyTaskManager(JForexTaskManager.Environment environment, boolean live, String accountName, IConsole console, TransportClient transportClient, DDSChartsController ddsChartsController, ILotAmountProvider lotAmountProvider, IUserInterface userInterface, IStrategyExceptionHandler exceptionHandler, AccountInfoMessage lastAccountInfo, AccountInfoMessageInit lastAccountInfoInit, String externalIP, String internalIP, String sessionID, Properties serverProperties, IClientGUIListener clientGUIListener)
/*     */   {
/* 106 */     super(environment, live, accountName, console, transportClient, ddsChartsController, lotAmountProvider, userInterface, exceptionHandler, lastAccountInfo, lastAccountInfoInit, externalIP, internalIP, sessionID, serverProperties, clientGUIListener);
/*     */   }
/*     */   
/*     */ 
/*     */   public void processMessage(ProtocolMessage message)
/*     */   {
/* 112 */     if ((message instanceof CurrencyMarket)) {
/* 113 */       onMarketState((CurrencyMarket)message);
/*     */     } else {
/* 115 */       super.processMessage(message);
/*     */     }
/*     */   }
/*     */   
/*     */   public IOrderValidator getOrderValidator()
/*     */   {
/* 121 */     if (this.orderValidator == null) {
/* 122 */       this.orderValidator = new com.dukascopy.api.impl.connect.validation.OrderValidator(this, this.lotAmountProvider);
/*     */     }
/* 124 */     return this.orderValidator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long startJfRunnable(IStrategy strategy, IStrategyListener listener, String strategyKey, boolean fullAccessGranted, String jfxPackMD5, List<File> custIndFiles)
/*     */   {
/* 135 */     StrategyProcessor strategyProcessor = new StrategyProcessor(this, strategy, fullAccessGranted);
/* 136 */     return exuteStart(strategyProcessor, listener, strategyKey, jfxPackMD5, custIndFiles);
/*     */   }
/*     */   
/*     */   public com.dukascopy.api.ITick onMarketState(CurrencyMarket market) {
/* 140 */     if ((this.runningJfRunnable == null) || (isStrategyStopping())) {
/* 141 */       return null;
/*     */     }
/*     */     
/* 144 */     Instrument instrument = Instrument.fromString(market.getInstrument());
/* 145 */     com.dukascopy.charts.data.datacache.TickData tick = this.feedDataProvider.getLastTick(instrument);
/* 146 */     if (tick == null) {
/* 147 */       CurrencyOffer askCurrencyOffer = market.getBestAsk();
/* 148 */       CurrencyOffer bidCurrencyOffer = market.getBestBid();
/* 149 */       if ((askCurrencyOffer != null) || (bidCurrencyOffer != null)) {
/* 150 */         LOGGER.warn("Got tick for instrument [" + instrument + "] that was not processed by FeedDataProvider... Instrument subscription status [" + this.feedDataProvider.isSubscribedToInstrument(instrument) + "] MarketState [" + market + "]");
/*     */       }
/* 152 */       return null;
/*     */     }
/* 154 */     double totalAskVolume = market.getTotalLiquidityAsk() != null ? market.getTotalLiquidityAsk().divide(ONE_MILLION).doubleValue() : 0.0D;
/* 155 */     double totalBidVolume = market.getTotalLiquidityBid() != null ? market.getTotalLiquidityBid().divide(ONE_MILLION).doubleValue() : 0.0D;
/* 156 */     tick = new StratTickData(tick, totalAskVolume, totalBidVolume);
/*     */     
/*     */ 
/*     */ 
/* 160 */     ((StrategyProcessor)this.runningJfRunnable).onMarket(instrument, tick);
/* 161 */     return tick;
/*     */   }
/*     */   
/*     */   public void updateAccountInfo(AccountInfoMessage protocolMessage) {
/* 165 */     super.updateAccountInfo(protocolMessage);
/* 166 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping())) {
/* 167 */       ((StrategyProcessor)this.runningJfRunnable).updateAccountInfo(this.account);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void fireOnStart()
/*     */   {
/* 175 */     ((StrategyProcessor)this.runningJfRunnable).updateAccountInfo(this.account);
/* 176 */     super.fireOnStart();
/*     */   }
/*     */   
/*     */   protected void beforeStart()
/*     */   {
/* 181 */     FeedDataProvider.getDefaultInstance().subscribeToAllCandlePeriods(this);
/*     */   }
/*     */   
/*     */   protected void afterStop()
/*     */   {
/* 186 */     FeedDataProvider.getDefaultInstance().unsubscribeFromAllCandlePeriods(this);
/*     */   }
/*     */   
/*     */   public void newCandle(Instrument instrument, Period period, CandleData askCandle, CandleData bidCandle)
/*     */   {
/* 191 */     CandleData askBar = new CandleData(askCandle.time, askCandle.open, askCandle.close, askCandle.low, askCandle.high, askCandle.vol);
/* 192 */     CandleData bidBar = new CandleData(bidCandle.time, bidCandle.open, bidCandle.close, bidCandle.low, bidCandle.high, bidCandle.vol);
/* 193 */     handleCandles(instrument, period, askBar, bidBar);
/*     */   }
/*     */   
/*     */   private void handleCandles(Instrument instrument, Period period, CandleData askBar, CandleData bidBar) {
/* 197 */     if ((this.runningJfRunnable != null) && (!isStrategyStopping()) && (oldBasicPeriods.contains(period)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 202 */       ((StrategyProcessor)this.runningJfRunnable).onBar(instrument, period, askBar, bidBar);
/*     */     }
/*     */   }
/*     */   
/*     */   protected IContext createContext(JFRunnableProcessor<IContext, IStrategy> jfRunnableProcessor)
/*     */   {
/* 208 */     return new JForexContextImpl(jfRunnableProcessor, this.forexEngineImpl, this.history, this.console, this.ddsChartsController, this.userInterface, this.clientGUIListener, this.serverProperties);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\StrategyTaskManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */