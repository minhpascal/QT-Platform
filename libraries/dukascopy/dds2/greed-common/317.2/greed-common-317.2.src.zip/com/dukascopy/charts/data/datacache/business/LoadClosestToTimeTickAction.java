/*     */ package com.dukascopy.charts.data.datacache.business;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.business.listener.ITickDataListener;
/*     */ import com.dukascopy.charts.data.datacache.customperiod.tick.LastTickLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.customperiod.tick.StopOnFirstTickLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.listener.LoadingProgressListenerImpl;
/*     */ import com.dukascopy.charts.data.datacache.metadata.IFeedMetadataManager;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadClosestToTimeTickAction
/*     */   implements Runnable
/*     */ {
/*  29 */   private static final Logger LOGGER = LoggerFactory.getLogger(LoadClosestToTimeTickAction.class);
/*     */   
/*  31 */   private static final long TICKS_LOADING_INTERVAL = TimeUnit.HOURS.toMillis(1L);
/*     */   
/*     */ 
/*     */   private final IFeedDataProvider feedDataProvider;
/*     */   
/*     */ 
/*     */   private final Instrument instrument;
/*     */   
/*     */ 
/*     */   private final long time;
/*     */   
/*     */   private final long searchTillTime;
/*     */   
/*     */   private final ITickDataListener tickListener;
/*     */   
/*     */   private final ILoadingProgressListener loadingProgressListener;
/*     */   
/*     */ 
/*     */   public LoadClosestToTimeTickAction(IFeedDataProvider feedDataProvider, Instrument instrument, long time, long searchTillTime, ITickDataListener tickListener, ILoadingProgressListener loadingProgressListener)
/*     */   {
/*  51 */     this.feedDataProvider = feedDataProvider;
/*  52 */     this.instrument = instrument;
/*  53 */     this.time = time;
/*  54 */     this.searchTillTime = searchTillTime;
/*  55 */     this.tickListener = tickListener;
/*  56 */     this.loadingProgressListener = loadingProgressListener;
/*     */     
/*  58 */     validateInputParams();
/*     */   }
/*     */   
/*     */   private void validateInputParams() {
/*  62 */     long ticksStartTime = this.feedDataProvider.getFeedMetadataManager().getTimeOfFirstTick(this.instrument);
/*  63 */     long ticksEndTime = this.feedDataProvider.getLastTickTime(this.instrument);
/*     */     
/*  65 */     if (ticksEndTime <= 0L) {
/*  66 */       TickData lastTick = this.feedDataProvider.loadLastTick(this.instrument);
/*  67 */       if (lastTick != null) {
/*  68 */         ticksEndTime = lastTick.getTime();
/*     */       }
/*     */     }
/*     */     
/*  72 */     if ((ticksStartTime <= 0L) || (ticksEndTime <= 0L)) {
/*  73 */       throw new IllegalArgumentException("Data bounds for instrument <" + this.instrument + "> can not be detected!");
/*     */     }
/*     */     
/*  76 */     long from = Math.min(this.time, this.searchTillTime);
/*  77 */     long to = Math.max(this.time, this.searchTillTime);
/*     */     
/*  79 */     if (from < ticksStartTime) {
/*  80 */       throw new IllegalArgumentException("From is earlier than data start time - " + DateUtils.format(from) + " < " + DateUtils.format(ticksStartTime));
/*     */     }
/*     */     
/*  83 */     if (ticksEndTime < to) {
/*  84 */       throw new IllegalArgumentException("To is later than data end time - " + DateUtils.format(ticksEndTime) + " < " + DateUtils.format(to));
/*     */     }
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*  90 */     if (this.loadingProgressListener.stopJob()) {
/*  91 */       return;
/*     */     }
/*     */     try
/*     */     {
/*     */       TickData result;
/*     */       TickData result;
/*  97 */       if (this.time <= this.searchTillTime) {
/*  98 */         result = loadTickForward(this.time, this.searchTillTime);
/*     */       }
/*     */       else {
/* 101 */         result = loadTickBackward(this.searchTillTime, this.time);
/*     */       }
/*     */       
/* 104 */       if (this.loadingProgressListener.stopJob()) {
/* 105 */         return;
/*     */       }
/*     */       
/* 108 */       this.tickListener.onTick(result);
/*     */     } catch (DataCacheException e) {
/* 110 */       LOGGER.error(e.getLocalizedMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private TickData loadTickBackward(long from, long to) throws DataCacheException {
/* 115 */     LastTickLiveFeedListener lastTickLiveFeedListener = new LastTickLiveFeedListener();
/*     */     
/* 117 */     long currentTo = to;
/*     */     
/* 119 */     while ((lastTickLiveFeedListener.getLastTick() == null) && (currentTo >= from))
/*     */     {
/* 121 */       long currentFrom = currentTo - TICKS_LOADING_INTERVAL;
/*     */       
/* 123 */       if (currentFrom < from) {
/* 124 */         currentFrom = from;
/*     */       }
/*     */       
/* 127 */       this.feedDataProvider.loadTicksDataSynched(this.instrument, currentFrom, currentTo, lastTickLiveFeedListener, this.loadingProgressListener);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */       currentTo = currentFrom - 1L;
/*     */     }
/*     */     
/* 139 */     return lastTickLiveFeedListener.getLastTick();
/*     */   }
/*     */   
/*     */   private TickData loadTickForward(long from, long to) throws DataCacheException {
/* 143 */     LoadingProgressListenerImpl loadingProgressListenerImpl = new LoadingProgressListenerImpl()
/*     */     {
/*     */       public boolean stopJob() {
/* 146 */         return (super.stopJob()) || (LoadClosestToTimeTickAction.this.loadingProgressListener.stopJob());
/*     */       }
/* 148 */     };
/* 149 */     StopOnFirstTickLiveFeedListener firstTickListener = new StopOnFirstTickLiveFeedListener(loadingProgressListenerImpl);
/*     */     
/* 151 */     long currentFrom = from;
/*     */     
/* 153 */     while ((firstTickListener.getFirstTick() == null) && (currentFrom <= to))
/*     */     {
/* 155 */       long currentTo = currentFrom + TICKS_LOADING_INTERVAL;
/*     */       
/* 157 */       if (currentTo > to) {
/* 158 */         currentTo = to;
/*     */       }
/*     */       
/* 161 */       this.feedDataProvider.loadTicksDataSynched(this.instrument, currentFrom, currentTo, firstTickListener, loadingProgressListenerImpl);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */       currentFrom = currentTo + 1L;
/*     */     }
/*     */     
/* 173 */     return firstTickListener.getFirstTick();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\business\LoadClosestToTimeTickAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */