package com.dukascopy.api.impl;

import com.dukascopy.api.IOrder;
import com.dukascopy.api.Instrument;
import com.dukascopy.api.JFException;
import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
import com.dukascopy.charts.data.datacache.OrderHistoricalData;
import com.dukascopy.charts.data.datacache.OrdersListener;
import java.util.List;

public abstract interface IHistoryOrderProvider
{
  public abstract List<IOrder> getOrdersHistory(Instrument paramInstrument, long paramLong1, long paramLong2)
    throws JFException;
  
  public abstract IOrder getOrderHistoryById(String paramString)
    throws JFException;
  
  public abstract void readOrdersHistory(Instrument paramInstrument, long paramLong1, long paramLong2, OrdersListener paramOrdersListener, ILoadingProgressListener paramILoadingProgressListener)
    throws JFException;
  
  public abstract HistoryOrder processOrders(Instrument paramInstrument, OrderHistoricalData paramOrderHistoricalData, long paramLong1, long paramLong2);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\IHistoryOrderProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */