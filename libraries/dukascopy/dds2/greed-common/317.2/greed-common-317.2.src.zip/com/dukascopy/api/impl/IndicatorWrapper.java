/*      */ package com.dukascopy.api.impl;
/*      */ 
/*      */ import com.dukascopy.api.IChartObject;
/*      */ import com.dukascopy.api.IIndicators.AppliedPrice;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.Period;
/*      */ import com.dukascopy.api.indicators.BooleanOptInputDescription;
/*      */ import com.dukascopy.api.indicators.ColorListDescription;
/*      */ import com.dukascopy.api.indicators.DoubleListDescription;
/*      */ import com.dukascopy.api.indicators.DoubleRangeDescription;
/*      */ import com.dukascopy.api.indicators.IDrawingIndicator;
/*      */ import com.dukascopy.api.indicators.IIndicator;
/*      */ import com.dukascopy.api.indicators.IIndicatorAppearanceInfo;
/*      */ import com.dukascopy.api.indicators.IIndicatorDrawingSupport;
/*      */ import com.dukascopy.api.indicators.IMinMax;
/*      */ import com.dukascopy.api.indicators.IndicatorInfo;
/*      */ import com.dukascopy.api.indicators.InputParameterInfo;
/*      */ import com.dukascopy.api.indicators.IntegerListDescription;
/*      */ import com.dukascopy.api.indicators.IntegerRangeDescription;
/*      */ import com.dukascopy.api.indicators.OptInputParameterInfo;
/*      */ import com.dukascopy.api.indicators.OutputParameterInfo;
/*      */ import com.dukascopy.api.indicators.OutputParameterInfo.DrawingStyle;
/*      */ import com.dukascopy.api.indicators.OutputParameterInfo.Type;
/*      */ import com.dukascopy.api.indicators.PeriodListDescription;
/*      */ import com.dukascopy.api.indicators.StringOptInputDescription;
/*      */ import com.dukascopy.charts.math.indicators.IndicatorsProvider;
/*      */ import com.dukascopy.charts.persistence.IdManager;
/*      */ import com.dukascopy.converter.lib.TimeOptInputDescription;
/*      */ import com.dukascopy.dds2.greed.gui.component.JColorComboBox;
/*      */ import com.dukascopy.dds2.greed.util.IndicatorHelper.PeriodParameterMapper;
/*      */ import java.awt.Color;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Stroke;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.InvalidParameterException;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ public class IndicatorWrapper
/*      */   implements Cloneable, IIndicatorAppearanceInfo
/*      */ {
/*   47 */   private static final Logger LOGGER = LoggerFactory.getLogger(IndicatorWrapper.class);
/*      */   
/*      */   public static final float DEFAULT_OUTPUT_OPACITY_ALPHA = 1.0F;
/*   50 */   public static final Color DEFAULT_OUTPUT_COLOR = Color.BLACK;
/*      */   
/*      */   public static final int DEFAULT_OUTPUT_WIDTH = 1;
/*      */   
/*      */   protected IndicatorHolder indicatorHolder;
/*      */   
/*      */   private OfferSide[] sidesForTicks;
/*      */   
/*      */   private IIndicators.AppliedPrice[] appliedPricesForCandles;
/*      */   
/*      */   private Object[] optParams;
/*      */   
/*      */   private Color[] outputColors;
/*      */   
/*      */   private Color[] outputColors2;
/*      */   
/*      */   private OutputParameterInfo.DrawingStyle[] drawingStyles;
/*      */   
/*      */   private int[] lineWidths;
/*      */   
/*      */   private int[] outputShifts;
/*      */   
/*      */   private boolean[] showValuesOnChart;
/*      */   private boolean[] showPopupInfo;
/*      */   private boolean[] showOutputs;
/*      */   private float[] opacityAlphas;
/*      */   private int id;
/*      */   private String name;
/*      */   private Method selfdrawingMethod;
/*      */   private Method minMaxMethod;
/*      */   private Integer subPanelId;
/*      */   private Integer chartPanelId;
/*      */   private List<IChartObject> chartObjects;
/*   83 */   private boolean changeTreeSelection = true;
/*      */   
/*      */   private List<LevelInfo> levelInfoList;
/*      */   
/*      */   private boolean recalculateOnNewCandleOnly;
/*      */   
/*      */ 
/*      */   public IndicatorWrapper() {}
/*      */   
/*      */ 
/*      */   public IndicatorWrapper(String name)
/*      */   {
/*   95 */     this(IndicatorsProvider.getInstance().getIndicatorHolder(name), -1);
/*      */   }
/*      */   
/*      */   public IndicatorWrapper(IndicatorHolder indicatorHolder) {
/*   99 */     this(indicatorHolder, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IndicatorWrapper(IndicatorHolder indicatorHolder, Object[] optParams, Color[] outputColors, OutputParameterInfo.DrawingStyle[] outputDrawingStyles, int[] outputWidths, int[] outputShifts)
/*      */   {
/*  110 */     this(indicatorHolder, -1, optParams, outputColors, outputDrawingStyles, outputWidths, outputShifts);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IndicatorWrapper(IndicatorHolder indicatorHolder, int id, Object[] optParams, Color[] outputColors, OutputParameterInfo.DrawingStyle[] outputDrawingStyles, int[] outputWidths, int[] outputShifts)
/*      */   {
/*  133 */     init(indicatorHolder, id);
/*  134 */     this.sidesForTicks = extractSidesForTicks(indicatorHolder.getIndicator());
/*  135 */     this.appliedPricesForCandles = extractAppliedPrices(indicatorHolder.getIndicator());
/*      */     
/*  137 */     int numberOfOutputs = indicatorHolder.getIndicator().getIndicatorInfo().getNumberOfOutputs();
/*      */     
/*  139 */     this.recalculateOnNewCandleOnly = indicatorHolder.getIndicator().getIndicatorInfo().isRecalculateOnNewCandleOnly();
/*      */     
/*  141 */     this.optParams = (optParams == null ? extractOptParams(indicatorHolder.getIndicator()) : optParams);
/*  142 */     IndicatorHelper.PeriodParameterMapper.performMapping(this.name, this.optParams);
/*      */     
/*  144 */     if (outputColors == null) {
/*  145 */       this.outputColors = new Color[numberOfOutputs];
/*  146 */       this.outputColors2 = new Color[numberOfOutputs];
/*  147 */       initColors();
/*      */     }
/*  149 */     else if (outputColors.length < numberOfOutputs) {
/*  150 */       Color[] colors = new Color[numberOfOutputs];
/*  151 */       Arrays.fill(colors, DEFAULT_OUTPUT_COLOR);
/*  152 */       System.arraycopy(outputColors, 0, colors, 0, outputColors.length);
/*  153 */       this.outputColors = colors;
/*      */     }
/*      */     else {
/*  156 */       this.outputColors = outputColors;
/*      */     }
/*      */     
/*  159 */     if (outputDrawingStyles == null) {
/*  160 */       this.drawingStyles = new OutputParameterInfo.DrawingStyle[numberOfOutputs];
/*  161 */       initDrawingStyles();
/*      */     }
/*  163 */     else if (outputDrawingStyles.length < numberOfOutputs) {
/*  164 */       OutputParameterInfo.DrawingStyle[] drawingStyles = new OutputParameterInfo.DrawingStyle[numberOfOutputs];
/*  165 */       for (int i = 0; i < numberOfOutputs; i++) {
/*  166 */         drawingStyles[i] = indicatorHolder.getIndicator().getOutputParameterInfo(i).getDrawingStyle();
/*      */       }
/*  168 */       System.arraycopy(outputDrawingStyles, 0, drawingStyles, 0, outputDrawingStyles.length);
/*  169 */       this.drawingStyles = drawingStyles;
/*      */     }
/*      */     else {
/*  172 */       this.drawingStyles = outputDrawingStyles;
/*      */     }
/*      */     
/*  175 */     if (outputWidths == null) {
/*  176 */       this.lineWidths = new int[numberOfOutputs];
/*  177 */       initLineWidths();
/*      */     }
/*  179 */     else if (outputWidths.length < numberOfOutputs) {
/*  180 */       int[] widths = new int[numberOfOutputs];
/*  181 */       Arrays.fill(widths, 1);
/*  182 */       System.arraycopy(outputWidths, 0, widths, 0, outputWidths.length);
/*  183 */       this.lineWidths = widths;
/*      */     }
/*      */     else {
/*  186 */       this.lineWidths = outputWidths;
/*      */     }
/*      */     
/*  189 */     if (outputShifts == null) {
/*  190 */       this.outputShifts = new int[numberOfOutputs];
/*  191 */       initOutputShifts();
/*      */     }
/*      */     else {
/*  194 */       this.outputShifts = outputShifts;
/*      */     }
/*      */     
/*  197 */     this.opacityAlphas = extractOpacityAlphas(indicatorHolder.getIndicator());
/*      */     
/*  199 */     extractMethods();
/*      */   }
/*      */   
/*      */   protected IndicatorWrapper(IndicatorHolder indicatorHolder, int id) {
/*  203 */     this(indicatorHolder, id, null, null, null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IndicatorWrapper(String name, int id, OfferSide[] sidesForTicks, IIndicators.AppliedPrice[] appliedPricesForCandles, Object[] optParams, Color[] outputColors, Color[] outputColors2, boolean[] valuesOnChart, boolean[] showPopupInfo, boolean[] showOutputs, float[] opacityAlphas, OutputParameterInfo.DrawingStyle[] drawingStyles, int[] lineWidths, int[] outputShifts, Integer subPanelId, List<IChartObject> chartObjects, List<LevelInfo> levelInfoList, IndicatorHolder indicatorHolder)
/*      */     throws InvalidParameterException
/*      */   {
/*  226 */     init(indicatorHolder, id);
/*  227 */     validate(sidesForTicks, appliedPricesForCandles, optParams, outputColors);
/*      */     
/*  229 */     IndicatorHelper.PeriodParameterMapper.performMapping(name, optParams);
/*      */     
/*  231 */     this.sidesForTicks = sidesForTicks;
/*  232 */     this.appliedPricesForCandles = appliedPricesForCandles;
/*  233 */     this.optParams = optParams;
/*  234 */     this.outputColors = outputColors;
/*  235 */     this.outputColors2 = (outputColors2 == null ? this.outputColors : outputColors2);
/*  236 */     this.showValuesOnChart = valuesOnChart;
/*  237 */     this.showPopupInfo = showPopupInfo;
/*  238 */     this.showOutputs = showOutputs;
/*  239 */     this.subPanelId = subPanelId;
/*  240 */     this.chartObjects = chartObjects;
/*  241 */     this.levelInfoList = levelInfoList;
/*  242 */     this.recalculateOnNewCandleOnly = indicatorHolder.getIndicator().getIndicatorInfo().isRecalculateOnNewCandleOnly();
/*      */     
/*  244 */     if (drawingStyles == null) {
/*  245 */       this.drawingStyles = new OutputParameterInfo.DrawingStyle[outputColors.length];
/*  246 */       initDrawingStyles();
/*      */     } else {
/*  248 */       this.drawingStyles = drawingStyles;
/*      */     }
/*  250 */     if (lineWidths == null) {
/*  251 */       this.lineWidths = new int[outputColors.length];
/*  252 */       Arrays.fill(this.lineWidths, 1);
/*      */     } else {
/*  254 */       this.lineWidths = lineWidths;
/*      */     }
/*      */     
/*  257 */     if (outputShifts == null) {
/*  258 */       this.outputShifts = new int[outputColors.length];
/*  259 */       Arrays.fill(this.outputShifts, 0);
/*      */     } else {
/*  261 */       this.outputShifts = outputShifts;
/*      */     }
/*      */     
/*  264 */     if (null == opacityAlphas) {
/*  265 */       this.opacityAlphas = new float[outputColors.length];
/*  266 */       Arrays.fill(this.opacityAlphas, 1.0F);
/*      */     } else {
/*  268 */       this.opacityAlphas = opacityAlphas;
/*      */     }
/*      */     
/*  271 */     extractMethods();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IndicatorWrapper(String name, OfferSide[] sidesForTicks, IIndicators.AppliedPrice[] appliedPricesForCandles, Object[] optParams, Color[] outputColors, Color[] outputColors2, boolean[] valuesOnChart, boolean[] showPopupInfo, boolean[] showOutputs, float[] opacityAlphas, OutputParameterInfo.DrawingStyle[] drawingStyles, int[] lineWidths, int[] outputShifts, IndicatorHolder holder)
/*      */     throws InvalidParameterException
/*      */   {
/*  290 */     this(name, -1, sidesForTicks, appliedPricesForCandles, optParams, outputColors, outputColors2, valuesOnChart, showPopupInfo, showOutputs, opacityAlphas, drawingStyles, lineWidths, outputShifts, null, null, null, holder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isChangeTreeSelection()
/*      */   {
/*  317 */     return this.changeTreeSelection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChangeTreeSelection(boolean changeTreeSelection)
/*      */   {
/*  326 */     this.changeTreeSelection = changeTreeSelection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validate(OfferSide[] sidesForTicks, IIndicators.AppliedPrice[] appliedPricesForCandles, Object[] optParams, Color[] outputColors)
/*      */   {
/*  342 */     if ((this.indicatorHolder == null) || (sidesForTicks == null) || (sidesForTicks.length != this.indicatorHolder.getIndicator().getIndicatorInfo().getNumberOfInputs()) || (appliedPricesForCandles == null) || (appliedPricesForCandles.length != this.indicatorHolder.getIndicator().getIndicatorInfo().getNumberOfInputs()) || (optParams == null) || (optParams.length != this.indicatorHolder.getIndicator().getIndicatorInfo().getNumberOfOptionalInputs()) || (outputColors == null) || (outputColors.length != this.indicatorHolder.getIndicator().getIndicatorInfo().getNumberOfOutputs()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  352 */       throw new InvalidParameterException("Some of the parameters are wrong");
/*      */     }
/*  354 */     for (OfferSide offerSide : sidesForTicks) {
/*  355 */       if (offerSide == null) {
/*  356 */         throw new InvalidParameterException("Wrong offer side parameter value");
/*      */       }
/*      */     }
/*  359 */     for (IIndicators.AppliedPrice appliedPrice : appliedPricesForCandles) {
/*  360 */       if (appliedPrice == null) {
/*  361 */         throw new InvalidParameterException("Wrong applied price parameter value");
/*      */       }
/*      */     }
/*  364 */     for (Object optParam : optParams) {
/*  365 */       if ((optParam == null) || ((!(optParam instanceof Integer)) && (!(optParam instanceof Double)) && (!(optParam instanceof Boolean)) && (!(optParam instanceof Color)) && (!(optParam instanceof String)) && (!(optParam instanceof Period))))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  376 */         throw new InvalidParameterException("Wrong optional parameter value");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init(IndicatorHolder indicatorHolder, int id)
/*      */   {
/*  389 */     if (id < 0) {
/*  390 */       this.id = IdManager.getNextIndicatorId();
/*      */     } else {
/*  392 */       this.id = id;
/*      */     }
/*  394 */     IIndicator indicator = indicatorHolder.getIndicator();
/*  395 */     this.name = indicator.getIndicatorInfo().getName();
/*  396 */     this.indicatorHolder = indicatorHolder;
/*  397 */     setChartPanelId(Integer.valueOf(id));
/*      */     
/*  399 */     int outpCount = indicator.getIndicatorInfo().getNumberOfOutputs();
/*  400 */     this.showValuesOnChart = new boolean[outpCount];
/*  401 */     this.showPopupInfo = new boolean[outpCount];
/*  402 */     this.showOutputs = new boolean[outpCount];
/*  403 */     this.opacityAlphas = new float[outpCount];
/*  404 */     for (int i = 0; i < outpCount; i++) {
/*  405 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/*  406 */       setShowValueOnChart(i, info.isShowValueOnChart());
/*  407 */       setShowPopupInfo(i, info.isShowPopupInfo());
/*  408 */       setShowOutput(i, info.isShowOutput());
/*  409 */       setOpacityAlpha(i, info.getOpacityAlpha());
/*      */     }
/*      */   }
/*      */   
/*      */   private void initColors() {
/*  414 */     for (int i = 0; i < this.outputColors.length; i++) {
/*  415 */       OutputParameterInfo outputParameterInfo = this.indicatorHolder.getIndicator().getOutputParameterInfo(i);
/*  416 */       if ((outputParameterInfo.getColor() == null) && (this.outputColors.length <= JColorComboBox.COLORS.length)) {
/*  417 */         this.outputColors[i] = JColorComboBox.COLORS[i];
/*  418 */         this.outputColors2[i] = JColorComboBox.COLORS[i];
/*      */       }
/*      */       else {
/*  421 */         this.outputColors[i] = outputParameterInfo.getColor();
/*  422 */         this.outputColors2[i] = outputParameterInfo.getColor2();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void initDrawingStyles() {
/*  428 */     for (int i = 0; i < this.drawingStyles.length; i++) {
/*  429 */       OutputParameterInfo outputParameterInfo = this.indicatorHolder.getIndicator().getOutputParameterInfo(i);
/*  430 */       this.drawingStyles[i] = outputParameterInfo.getDrawingStyle();
/*      */     }
/*      */   }
/*      */   
/*      */   private void initOutputShifts() {
/*  435 */     for (int i = 0; i < this.outputShifts.length; i++) {
/*  436 */       OutputParameterInfo outputParameterInfo = this.indicatorHolder.getIndicator().getOutputParameterInfo(i);
/*  437 */       this.outputShifts[i] = outputParameterInfo.getShift();
/*      */     }
/*      */   }
/*      */   
/*      */   private void initLineWidths() {
/*  442 */     for (int i = 0; i < this.lineWidths.length; i++) {
/*  443 */       OutputParameterInfo outputParameterInfo = this.indicatorHolder.getIndicator().getOutputParameterInfo(i);
/*  444 */       this.lineWidths[i] = (outputParameterInfo.getLineWidth() <= 0 ? 1 : outputParameterInfo.getLineWidth());
/*      */     }
/*      */   }
/*      */   
/*      */   private void extractMethods() {
/*  449 */     Class<? extends IIndicator> indicatorClass = this.indicatorHolder.getIndicator().getClass();
/*  450 */     if (IDrawingIndicator.class.isAssignableFrom(indicatorClass)) {
/*      */       try {
/*  452 */         this.selfdrawingMethod = indicatorClass.getMethod("drawOutput", new Class[] { Graphics.class, Integer.TYPE, Object.class, Color.class, Stroke.class, IIndicatorDrawingSupport.class, List.class, Map.class });
/*      */       }
/*      */       catch (NoSuchMethodException e) {}catch (Exception e)
/*      */       {
/*  456 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     } else {
/*      */       try {
/*  460 */         this.selfdrawingMethod = indicatorClass.getMethod("drawOutput", new Class[] { Graphics.class, Integer.TYPE, Object.class, Color.class, IIndicatorDrawingSupport.class, List.class, Map.class });
/*      */       }
/*      */       catch (NoSuchMethodException e) {}catch (Exception e)
/*      */       {
/*  464 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     }
/*  467 */     if (IMinMax.class.isAssignableFrom(indicatorClass)) {
/*      */       try {
/*  469 */         this.minMaxMethod = indicatorClass.getMethod("getMinMax", new Class[] { Integer.TYPE, Object.class, Integer.TYPE, Integer.TYPE });
/*      */       }
/*      */       catch (NoSuchMethodException e) {}catch (Exception e)
/*      */       {
/*  473 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private OfferSide[] extractSidesForTicks(IIndicator indicator) {
/*  479 */     OfferSide[] sidesForTicks = new OfferSide[indicator.getIndicatorInfo().getNumberOfInputs()];
/*  480 */     for (int i = 0; i < sidesForTicks.length; i++) {
/*  481 */       sidesForTicks[i] = OfferSide.BID;
/*      */     }
/*  483 */     return sidesForTicks;
/*      */   }
/*      */   
/*      */   private IIndicators.AppliedPrice[] extractAppliedPrices(IIndicator indicator) {
/*  487 */     IIndicators.AppliedPrice[] appliedPricesForCandles = new IIndicators.AppliedPrice[indicator.getIndicatorInfo().getNumberOfInputs()];
/*  488 */     for (int i = 0; i < appliedPricesForCandles.length; i++) {
/*  489 */       InputParameterInfo inputParameterInfo = indicator.getInputParameterInfo(i);
/*  490 */       appliedPricesForCandles[i] = inputParameterInfo.getAppliedPrice();
/*  491 */       if (appliedPricesForCandles[i] == null) {
/*  492 */         appliedPricesForCandles[i] = IIndicators.AppliedPrice.CLOSE;
/*      */       }
/*      */     }
/*  495 */     return appliedPricesForCandles;
/*      */   }
/*      */   
/*      */   private Object[] extractOptParams(IIndicator indicator) {
/*  499 */     Object[] optParams = new Object[indicator.getIndicatorInfo().getNumberOfOptionalInputs()];
/*  500 */     for (int i = 0; i < optParams.length; i++) {
/*  501 */       OptInputParameterInfo info = indicator.getOptInputParameterInfo(i);
/*  502 */       if ((info.getDescription() instanceof IntegerListDescription)) {
/*  503 */         IntegerListDescription integerList = (IntegerListDescription)info.getDescription();
/*  504 */         optParams[i] = Integer.valueOf(integerList.getDefaultValue());
/*  505 */       } else if ((info.getDescription() instanceof IntegerRangeDescription)) {
/*  506 */         IntegerRangeDescription integerRange = (IntegerRangeDescription)info.getDescription();
/*  507 */         optParams[i] = Integer.valueOf(integerRange.getDefaultValue());
/*  508 */       } else if ((info.getDescription() instanceof DoubleListDescription)) {
/*  509 */         DoubleListDescription realList = (DoubleListDescription)info.getDescription();
/*  510 */         optParams[i] = Double.valueOf(realList.getDefaultValue());
/*  511 */       } else if ((info.getDescription() instanceof DoubleRangeDescription)) {
/*  512 */         DoubleRangeDescription realRange = (DoubleRangeDescription)info.getDescription();
/*  513 */         optParams[i] = Double.valueOf(realRange.getDefaultValue());
/*  514 */       } else if ((info.getDescription() instanceof BooleanOptInputDescription)) {
/*  515 */         BooleanOptInputDescription booleanOptDescription = (BooleanOptInputDescription)info.getDescription();
/*  516 */         optParams[i] = Boolean.valueOf(booleanOptDescription.getDefaultValue());
/*  517 */       } else if ((info.getDescription() instanceof ColorListDescription)) {
/*  518 */         ColorListDescription colorOptDescription = (ColorListDescription)info.getDescription();
/*  519 */         optParams[i] = colorOptDescription.getDefaultValue();
/*  520 */       } else if ((info.getDescription() instanceof PeriodListDescription)) {
/*  521 */         PeriodListDescription periodOptDescription = (PeriodListDescription)info.getDescription();
/*  522 */         optParams[i] = periodOptDescription.getDefaultValue();
/*  523 */       } else if ((info.getDescription() instanceof StringOptInputDescription)) {
/*  524 */         StringOptInputDescription stringDesc = (StringOptInputDescription)info.getDescription();
/*  525 */         optParams[i] = stringDesc.getDefaultValue();
/*  526 */       } else if ((info.getDescription() instanceof TimeOptInputDescription)) {
/*  527 */         TimeOptInputDescription stringDesc = (TimeOptInputDescription)info.getDescription();
/*  528 */         optParams[i] = stringDesc.getDefaultValue();
/*      */       } else {
/*  530 */         throw new IllegalArgumentException("Unsupported Description type - " + info.getDescription());
/*      */       }
/*      */     }
/*  533 */     return optParams;
/*      */   }
/*      */   
/*      */   private float[] extractOpacityAlphas(IIndicator indicator) {
/*  537 */     float[] opacityAlphas = new float[indicator.getIndicatorInfo().getNumberOfOutputs()];
/*  538 */     for (int i = 0; i < opacityAlphas.length; i++) {
/*  539 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/*  540 */       if ((info.getOpacityAlpha() >= 0.0F) && (info.getOpacityAlpha() <= 1.0F)) {
/*  541 */         opacityAlphas[i] = info.getOpacityAlpha();
/*      */       }
/*      */       else {
/*  544 */         opacityAlphas[i] = 1.0F;
/*      */       }
/*      */     }
/*  547 */     return opacityAlphas;
/*      */   }
/*      */   
/*      */   public int getId() {
/*  551 */     return this.id;
/*      */   }
/*      */   
/*      */   public String getName() {
/*  555 */     return this.name;
/*      */   }
/*      */   
/*      */   public String getNameWithParams() {
/*  559 */     StringBuffer indicatorDescription = new StringBuffer(this.name);
/*  560 */     if (this.optParams.length > 0) {
/*  561 */       indicatorDescription.append(":");
/*      */     }
/*      */     
/*  564 */     for (int i = 0; i < this.optParams.length; i++) {
/*  565 */       Object optParam = this.optParams[i];
/*  566 */       if (i == 0) {
/*  567 */         indicatorDescription.append(" (");
/*      */       }
/*  569 */       OptInputParameterInfo info = this.indicatorHolder.getIndicator().getOptInputParameterInfo(i);
/*  570 */       if ((info.getDescription() instanceof IntegerListDescription)) {
/*  571 */         IntegerListDescription integerList = (IntegerListDescription)info.getDescription();
/*      */         
/*  573 */         int index = -1;
/*  574 */         for (int j = 0; j < integerList.getValues().length; j++) {
/*  575 */           if (integerList.getValues()[j] == ((Integer)optParam).intValue()) {
/*  576 */             index = j;
/*  577 */             break;
/*      */           }
/*      */         }
/*  580 */         if (index == -1) {
/*  581 */           index = ((Integer)optParam).intValue();
/*      */         }
/*      */         
/*  584 */         if (index > integerList.getValues().length - 1) {
/*  585 */           index = integerList.getValues().length - 1;
/*      */         }
/*  587 */         indicatorDescription.append(integerList.getValueNames()[index]);
/*      */       }
/*  589 */       else if ((info.getDescription() instanceof ColorListDescription)) {
/*  590 */         ColorListDescription colorList = (ColorListDescription)info.getDescription();
/*      */         
/*  592 */         int index = -1;
/*  593 */         for (int j = 0; j < colorList.getValues().length; j++) {
/*  594 */           if ((colorList.getValues()[j] != null) && (colorList.getValues()[j].equals((Color)optParam))) {
/*  595 */             index = j;
/*  596 */             break;
/*      */           }
/*      */         }
/*      */         
/*  600 */         if (index == -1) {
/*  601 */           index = 0;
/*      */         }
/*  603 */         else if (index > colorList.getValues().length - 1) {
/*  604 */           index = colorList.getValues().length - 1;
/*      */         }
/*      */         
/*  607 */         indicatorDescription.append(colorList.getValueNames()[index]);
/*      */       }
/*      */       else {
/*  610 */         indicatorDescription.append(optParam);
/*      */       }
/*      */       
/*  613 */       if (i < this.optParams.length - 1) {
/*  614 */         indicatorDescription.append(", ");
/*      */       } else {
/*  616 */         indicatorDescription.append(")");
/*      */       }
/*      */     }
/*  619 */     return indicatorDescription.toString();
/*      */   }
/*      */   
/*      */   public void setOfferSideForTicks(int paramIndex, OfferSide side) {
/*  623 */     this.sidesForTicks[paramIndex] = side;
/*      */   }
/*      */   
/*      */   public void setAppliedPriceForCandles(int paramIndex, IIndicators.AppliedPrice type) {
/*  627 */     this.appliedPricesForCandles[paramIndex] = type;
/*      */   }
/*      */   
/*      */   public OfferSide[] getOfferSidesForTicks() {
/*  631 */     return this.sidesForTicks;
/*      */   }
/*      */   
/*      */   public IIndicators.AppliedPrice[] getAppliedPricesForCandles() {
/*  635 */     return this.appliedPricesForCandles;
/*      */   }
/*      */   
/*      */   public void setOptParam(int paramIndex, Object value) {
/*  639 */     this.optParams[paramIndex] = value;
/*      */   }
/*      */   
/*      */   public Object[] getOptParams() {
/*  643 */     return this.optParams;
/*      */   }
/*      */   
/*      */   public boolean isRecalculateOnNewCandleOnly() {
/*  647 */     return this.recalculateOnNewCandleOnly;
/*      */   }
/*      */   
/*      */   public void setRecalculateOnNewCandleOnly(boolean recalculateOnNewCandleOnly) {
/*  651 */     this.recalculateOnNewCandleOnly = recalculateOnNewCandleOnly;
/*      */   }
/*      */   
/*      */   public String getPropsStr() {
/*  655 */     if (this.optParams.length == 0) {
/*  656 */       return null;
/*      */     }
/*  658 */     StringBuilder str = new StringBuilder();
/*      */     
/*  660 */     for (int i = 0; i < this.optParams.length; i++) {
/*  661 */       Object param = this.optParams[i];
/*  662 */       if ((param instanceof Integer)) {
/*  663 */         OptInputParameterInfo info = this.indicatorHolder.getIndicator().getOptInputParameterInfo(i);
/*  664 */         if ((info.getDescription() instanceof IntegerListDescription)) {
/*  665 */           IntegerListDescription integerList = (IntegerListDescription)info.getDescription();
/*      */           
/*  667 */           int index = -1;
/*  668 */           for (int j = 0; j < integerList.getValues().length; j++) {
/*  669 */             if (integerList.getValues()[j] == ((Integer)param).intValue()) {
/*  670 */               index = j;
/*  671 */               break;
/*      */             }
/*      */           }
/*  674 */           if (index == -1) {
/*  675 */             index = ((Integer)param).intValue();
/*      */           }
/*      */           
/*  678 */           if (index > integerList.getValues().length - 1) {
/*  679 */             index = integerList.getValues().length - 1;
/*      */           }
/*  681 */           str.append(integerList.getValueNames()[index]).append(", ");
/*      */         } else {
/*  683 */           str.append(param.toString()).append(", ");
/*      */         }
/*  685 */       } else if ((param instanceof Double)) {
/*  686 */         getDecimalFormat(i).format(param);
/*  687 */         str.append(getDecimalFormat(i).format(((Double)param).doubleValue())).append(", ");
/*  688 */       } else if ((param instanceof Boolean)) {
/*  689 */         str.append(String.valueOf(param)).append(", ");
/*      */       }
/*  691 */       else if ((param instanceof Period)) {
/*  692 */         str.append(((Period)param).name()).append(", ");
/*      */       }
/*  694 */       else if ((param instanceof String)) {
/*  695 */         str.append(param).append(", ");
/*      */       }
/*      */     }
/*  698 */     if (str.length() >= 2) {
/*  699 */       str.setLength(str.length() - 2);
/*      */     }
/*  701 */     return str.toString();
/*      */   }
/*      */   
/*      */   public void setOutputColor(int paramIndex, Color color) {
/*  705 */     this.outputColors[paramIndex] = color;
/*      */   }
/*      */   
/*      */   public Color[] getOutputColors() {
/*  709 */     return this.outputColors;
/*      */   }
/*      */   
/*      */   public void setOutputColor2(int paramIndex, Color color) {
/*  713 */     this.outputColors2[paramIndex] = color;
/*      */   }
/*      */   
/*      */   public Color[] getOutputColors2() {
/*  717 */     if (this.outputColors2 == null) {
/*  718 */       this.outputColors2 = ((Color[])getOutputColors().clone());
/*      */     }
/*  720 */     return this.outputColors2;
/*      */   }
/*      */   
/*      */   public boolean[] getShowValuesOnChart() {
/*  724 */     return this.showValuesOnChart;
/*      */   }
/*      */   
/*      */   public boolean showValueOnChart(int outputIdx) {
/*  728 */     return this.showValuesOnChart[outputIdx];
/*      */   }
/*      */   
/*      */   public void setShowValueOnChart(int outputIdx, boolean showValue) {
/*  732 */     this.showValuesOnChart[outputIdx] = showValue;
/*      */   }
/*      */   
/*      */   public boolean[] getShowPopupInfo() {
/*  736 */     return this.showPopupInfo;
/*      */   }
/*      */   
/*      */   public boolean showPopupInfo(int outputIdx) {
/*  740 */     return this.showPopupInfo[outputIdx];
/*      */   }
/*      */   
/*      */   public void setShowPopupInfo(int outputIdx, boolean show) {
/*  744 */     this.showPopupInfo[outputIdx] = show;
/*      */   }
/*      */   
/*      */   public boolean[] getShowOutputs() {
/*  748 */     return this.showOutputs;
/*      */   }
/*      */   
/*      */   public boolean showOutput(int outputIdx) {
/*  752 */     return this.showOutputs[outputIdx];
/*      */   }
/*      */   
/*      */   public void setShowOutput(int outputIdx, boolean showValue) {
/*  756 */     this.showOutputs[outputIdx] = showValue;
/*      */   }
/*      */   
/*      */   public float[] getOpacityAlphas() {
/*  760 */     return this.opacityAlphas;
/*      */   }
/*      */   
/*      */   public float getOpacityAlpha(int outputIdx) {
/*  764 */     return this.opacityAlphas[outputIdx];
/*      */   }
/*      */   
/*      */   public void setOpacityAlpha(int outputIdx, float alphaValue) {
/*  768 */     this.opacityAlphas[outputIdx] = alphaValue;
/*      */   }
/*      */   
/*      */   public void setDrawingStyle(int paramIndex, OutputParameterInfo.DrawingStyle drawingStyle) {
/*  772 */     this.drawingStyles[paramIndex] = drawingStyle;
/*      */   }
/*      */   
/*      */   public OutputParameterInfo.DrawingStyle[] getDrawingStyles() {
/*  776 */     return this.drawingStyles;
/*      */   }
/*      */   
/*      */   public void setOutputShift(int paramIndex, int shift) {
/*  780 */     this.outputShifts[paramIndex] = shift;
/*      */   }
/*      */   
/*      */   public int[] getOutputShifts() {
/*  784 */     if (this.outputShifts == null) {
/*  785 */       this.outputShifts = new int[this.indicatorHolder.getIndicator().getIndicatorInfo().getNumberOfOutputs()];
/*      */     }
/*  787 */     return this.outputShifts;
/*      */   }
/*      */   
/*      */   public void setLineWidth(int paramIndex, int width) {
/*  791 */     this.lineWidths[paramIndex] = width;
/*      */   }
/*      */   
/*      */   public int[] getLineWidths() {
/*  795 */     return this.lineWidths;
/*      */   }
/*      */   
/*      */   public IIndicator getIndicator() {
/*  799 */     return this.indicatorHolder.getIndicator();
/*      */   }
/*      */   
/*      */   public IndicatorHolder getIndicatorHolder() {
/*  803 */     return this.indicatorHolder;
/*      */   }
/*      */   
/*      */   public Method getSelfdrawingMethod() {
/*  807 */     return this.selfdrawingMethod;
/*      */   }
/*      */   
/*      */   public Method getMinMaxMethod() {
/*  811 */     return this.minMaxMethod;
/*      */   }
/*      */   
/*      */   public void synchronizeDrawingStyles() {
/*      */     try {
/*  816 */       initDrawingStyles();
/*      */     }
/*      */     catch (Exception e) {
/*  819 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void copySettingsFrom(IndicatorWrapper sourceIndicatorWrapper) {
/*  824 */     if (!sourceIndicatorWrapper.getIndicator().getIndicatorInfo().getName().toUpperCase().equals(this.indicatorHolder.getIndicator().getIndicatorInfo().getName().toUpperCase())) {
/*  825 */       throw new IllegalArgumentException("Cannot copy setting into indicator from some other type/formula indicator");
/*      */     }
/*  827 */     this.sidesForTicks = new OfferSide[sourceIndicatorWrapper.sidesForTicks.length];
/*  828 */     System.arraycopy(sourceIndicatorWrapper.sidesForTicks, 0, this.sidesForTicks, 0, this.sidesForTicks.length);
/*  829 */     this.appliedPricesForCandles = new IIndicators.AppliedPrice[sourceIndicatorWrapper.appliedPricesForCandles.length];
/*  830 */     System.arraycopy(sourceIndicatorWrapper.appliedPricesForCandles, 0, this.appliedPricesForCandles, 0, this.appliedPricesForCandles.length);
/*  831 */     this.optParams = new Object[sourceIndicatorWrapper.optParams.length];
/*  832 */     System.arraycopy(sourceIndicatorWrapper.optParams, 0, this.optParams, 0, this.optParams.length);
/*      */     
/*  834 */     this.outputColors = new Color[sourceIndicatorWrapper.outputColors.length];
/*  835 */     System.arraycopy(sourceIndicatorWrapper.outputColors, 0, this.outputColors, 0, this.outputColors.length);
/*  836 */     this.outputColors2 = new Color[sourceIndicatorWrapper.outputColors2.length];
/*  837 */     System.arraycopy(sourceIndicatorWrapper.outputColors2, 0, this.outputColors2, 0, this.outputColors2.length);
/*  838 */     this.drawingStyles = new OutputParameterInfo.DrawingStyle[sourceIndicatorWrapper.drawingStyles.length];
/*  839 */     System.arraycopy(sourceIndicatorWrapper.drawingStyles, 0, this.drawingStyles, 0, this.drawingStyles.length);
/*  840 */     this.lineWidths = new int[sourceIndicatorWrapper.lineWidths.length];
/*  841 */     System.arraycopy(sourceIndicatorWrapper.lineWidths, 0, this.lineWidths, 0, this.lineWidths.length);
/*  842 */     this.showValuesOnChart = new boolean[sourceIndicatorWrapper.showValuesOnChart.length];
/*  843 */     System.arraycopy(sourceIndicatorWrapper.showValuesOnChart, 0, this.showValuesOnChart, 0, this.showValuesOnChart.length);
/*  844 */     this.showPopupInfo = new boolean[sourceIndicatorWrapper.showPopupInfo.length];
/*  845 */     System.arraycopy(sourceIndicatorWrapper.showPopupInfo, 0, this.showPopupInfo, 0, this.showPopupInfo.length);
/*  846 */     this.showOutputs = new boolean[sourceIndicatorWrapper.showOutputs.length];
/*  847 */     System.arraycopy(sourceIndicatorWrapper.showOutputs, 0, this.showOutputs, 0, this.showOutputs.length);
/*  848 */     this.opacityAlphas = new float[sourceIndicatorWrapper.opacityAlphas.length];
/*  849 */     System.arraycopy(sourceIndicatorWrapper.opacityAlphas, 0, this.opacityAlphas, 0, this.opacityAlphas.length);
/*  850 */     this.outputShifts = new int[sourceIndicatorWrapper.outputShifts.length];
/*  851 */     System.arraycopy(sourceIndicatorWrapper.outputShifts, 0, this.outputShifts, 0, this.outputShifts.length);
/*      */     
/*  853 */     setRecalculateOnNewCandleOnly(sourceIndicatorWrapper.isRecalculateOnNewCandleOnly());
/*      */     
/*  855 */     IIndicator sourceIndicator = sourceIndicatorWrapper.getIndicator();
/*  856 */     IIndicator destIndicator = getIndicator();
/*  857 */     int numOfInputs = destIndicator.getIndicatorInfo().getNumberOfInputs();
/*  858 */     for (int i = 0; i < numOfInputs; i++) {
/*  859 */       destIndicator.getInputParameterInfo(i).setPeriod(sourceIndicator.getInputParameterInfo(i).getPeriod());
/*      */     }
/*      */   }
/*      */   
/*      */   public IndicatorWrapper clone()
/*      */   {
/*      */     try {
/*  866 */       IndicatorWrapper clone = (IndicatorWrapper)super.clone();
/*  867 */       clone.indicatorHolder = IndicatorsProvider.getInstance().getIndicatorHolder(this.indicatorHolder.getIndicator().getIndicatorInfo().getName());
/*  868 */       clone.sidesForTicks = new OfferSide[this.sidesForTicks.length];
/*  869 */       System.arraycopy(this.sidesForTicks, 0, clone.sidesForTicks, 0, this.sidesForTicks.length);
/*  870 */       clone.appliedPricesForCandles = new IIndicators.AppliedPrice[this.appliedPricesForCandles.length];
/*  871 */       System.arraycopy(this.appliedPricesForCandles, 0, clone.appliedPricesForCandles, 0, this.appliedPricesForCandles.length);
/*  872 */       clone.optParams = new Object[this.optParams.length];
/*  873 */       System.arraycopy(this.optParams, 0, clone.optParams, 0, this.optParams.length);
/*  874 */       clone.outputColors = new Color[this.outputColors.length];
/*  875 */       System.arraycopy(this.outputColors, 0, clone.outputColors, 0, this.outputColors.length);
/*  876 */       clone.drawingStyles = new OutputParameterInfo.DrawingStyle[this.drawingStyles.length];
/*  877 */       System.arraycopy(this.drawingStyles, 0, clone.drawingStyles, 0, this.drawingStyles.length);
/*  878 */       clone.lineWidths = new int[this.lineWidths.length];
/*  879 */       System.arraycopy(this.lineWidths, 0, clone.lineWidths, 0, this.lineWidths.length);
/*  880 */       clone.showValuesOnChart = new boolean[this.showValuesOnChart.length];
/*  881 */       System.arraycopy(this.showValuesOnChart, 0, clone.showValuesOnChart, 0, this.showValuesOnChart.length);
/*  882 */       clone.showPopupInfo = new boolean[this.showPopupInfo.length];
/*  883 */       System.arraycopy(this.showPopupInfo, 0, clone.showPopupInfo, 0, this.showPopupInfo.length);
/*  884 */       clone.showOutputs = new boolean[this.showOutputs.length];
/*  885 */       System.arraycopy(this.showOutputs, 0, clone.showOutputs, 0, this.showOutputs.length);
/*  886 */       clone.opacityAlphas = new float[this.opacityAlphas.length];
/*  887 */       System.arraycopy(this.opacityAlphas, 0, clone.opacityAlphas, 0, this.opacityAlphas.length);
/*  888 */       clone.outputShifts = new int[this.outputShifts.length];
/*  889 */       System.arraycopy(this.outputShifts, 0, clone.outputShifts, 0, this.outputShifts.length);
/*      */       
/*  891 */       if (clone.getIndicatorHolder() != null) {
/*  892 */         IIndicator originalIndicator = getIndicator();
/*  893 */         IIndicator cloneIndicator = clone.getIndicator();
/*  894 */         int numOfInputs = originalIndicator.getIndicatorInfo().getNumberOfInputs();
/*  895 */         for (int i = 0; i < numOfInputs; i++) {
/*  896 */           cloneIndicator.getInputParameterInfo(i).setPeriod(originalIndicator.getInputParameterInfo(i).getPeriod());
/*      */         }
/*      */       }
/*      */       
/*  900 */       return clone;
/*      */     }
/*      */     catch (Exception e) {}
/*  903 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  909 */     int prime = 31;
/*  910 */     int result = 1;
/*  911 */     result = 31 * result + this.id;
/*  912 */     return result;
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj)
/*      */   {
/*  917 */     if (this == obj)
/*  918 */       return true;
/*  919 */     if (obj == null)
/*  920 */       return false;
/*  921 */     if (getClass() != obj.getClass())
/*  922 */       return false;
/*  923 */     IndicatorWrapper other = (IndicatorWrapper)obj;
/*  924 */     if (this.id != other.id)
/*  925 */       return false;
/*  926 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isOverlappingIndicator(int outputIdx)
/*      */   {
/*  932 */     OutputParameterInfo outputParameterInfo = this.indicatorHolder.getIndicator().getOutputParameterInfo(outputIdx);
/*  933 */     if (outputParameterInfo.getType() != OutputParameterInfo.Type.DOUBLE) {
/*  934 */       return false;
/*      */     }
/*  936 */     if (this.drawingStyles[outputIdx] == OutputParameterInfo.DrawingStyle.HISTOGRAM) {
/*  937 */       return false;
/*      */     }
/*  939 */     return true;
/*      */   }
/*      */   
/*      */   public boolean shouldBeShownOnSubWin() {
/*  943 */     return !this.indicatorHolder.getIndicator().getIndicatorInfo().isOverChart();
/*      */   }
/*      */   
/*      */   public boolean isLevelsEnabled() {
/*  947 */     if (shouldBeShownOnSubWin()) {
/*  948 */       return true;
/*      */     }
/*  950 */     for (OutputParameterInfo.DrawingStyle drawingStyle : getDrawingStyles()) {
/*  951 */       if ((drawingStyle == null) || (!drawingStyle.isOutputAsLine())) {
/*  952 */         return false;
/*      */       }
/*      */     }
/*  955 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public Integer getSubPanelId()
/*      */   {
/*  961 */     return this.subPanelId;
/*      */   }
/*      */   
/*      */   public void setSubPanelId(Integer subPanelId) {
/*  965 */     this.subPanelId = subPanelId;
/*      */   }
/*      */   
/*      */   public List<IChartObject> getChartObjects() {
/*  969 */     return this.chartObjects;
/*      */   }
/*      */   
/*      */   public void setChartObjects(List<IChartObject> chartObjects) {
/*  973 */     this.chartObjects = chartObjects;
/*      */   }
/*      */   
/*      */   public List<LevelInfo> getLevelInfoList() {
/*  977 */     if (this.levelInfoList == null) {
/*  978 */       this.levelInfoList = new ArrayList();
/*      */       
/*  980 */       String indicatorName = this.indicatorHolder.getIndicator().getIndicatorInfo().getName();
/*  981 */       if (indicatorName.equalsIgnoreCase("RSI")) {
/*  982 */         this.levelInfoList.add(new LevelInfo("", 30.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  983 */         this.levelInfoList.add(new LevelInfo("", 70.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  984 */       } else if (indicatorName.equalsIgnoreCase("STOCH")) {
/*  985 */         this.levelInfoList.add(new LevelInfo("", 20.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  986 */         this.levelInfoList.add(new LevelInfo("", 80.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  987 */       } else if (indicatorName.equalsIgnoreCase("RVI")) {
/*  988 */         this.levelInfoList.add(new LevelInfo("", 0.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  989 */       } else if (indicatorName.equalsIgnoreCase("CCI")) {
/*  990 */         this.levelInfoList.add(new LevelInfo("", 100.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  991 */         this.levelInfoList.add(new LevelInfo("", 0.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  992 */         this.levelInfoList.add(new LevelInfo("", -100.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  993 */       } else if (indicatorName.equalsIgnoreCase("WILLR")) {
/*  994 */         this.levelInfoList.add(new LevelInfo("", -20.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  995 */         this.levelInfoList.add(new LevelInfo("", -80.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  996 */       } else if (indicatorName.equalsIgnoreCase("MFI")) {
/*  997 */         this.levelInfoList.add(new LevelInfo("", 80.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  998 */         this.levelInfoList.add(new LevelInfo("", 20.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*  999 */       } else if (indicatorName.equalsIgnoreCase("OBV")) {
/* 1000 */         this.levelInfoList.add(new LevelInfo("", 0.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/* 1001 */       } else if (indicatorName.equalsIgnoreCase("PERSBBANDS")) {
/* 1002 */         this.levelInfoList.add(new LevelInfo("", 0.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/* 1003 */         this.levelInfoList.add(new LevelInfo("", 50.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/* 1004 */         this.levelInfoList.add(new LevelInfo("", 100.0D, OutputParameterInfo.DrawingStyle.DASH_LINE, Color.BLACK, 1, 1.0F));
/*      */       }
/*      */     }
/* 1007 */     return this.levelInfoList;
/*      */   }
/*      */   
/*      */   public void setLevelInfoList(List<LevelInfo> levelInfoList) {
/* 1011 */     this.levelInfoList = levelInfoList;
/*      */   }
/*      */   
/*      */   public DecimalFormat getDecimalFormat(int optInputIndex) {
/* 1015 */     String format = "0";
/* 1016 */     OptInputParameterInfo optInputParameterInfo = this.indicatorHolder.getIndicator().getOptInputParameterInfo(optInputIndex);
/* 1017 */     if ((optInputParameterInfo.getDescription() instanceof DoubleRangeDescription)) {
/* 1018 */       DoubleRangeDescription doubleRangeDescription = (DoubleRangeDescription)optInputParameterInfo.getDescription();
/* 1019 */       if (doubleRangeDescription.getPrecision() > 0) {
/* 1020 */         format = format + ".";
/* 1021 */         for (int i = 0; i < doubleRangeDescription.getPrecision(); i++) {
/* 1022 */           format = format + "0";
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1027 */       format = format + ".00";
/*      */     }
/*      */     
/* 1030 */     DecimalFormat decimalFormat = new DecimalFormat(format);
/* 1031 */     return decimalFormat;
/*      */   }
/*      */   
/*      */ 
/*      */   public void synchronizeOutputWithIndicator()
/*      */   {
/*      */     try
/*      */     {
/* 1039 */       IIndicator indicator = getIndicator();
/* 1040 */       for (int i = 0; i < indicator.getIndicatorInfo().getNumberOfOutputs(); i++)
/*      */       {
/* 1042 */         OutputParameterInfo indicatorOutputInfo = indicator.getOutputParameterInfo(i);
/*      */         
/* 1044 */         setOutputColor(i, indicatorOutputInfo.getColor());
/* 1045 */         setOutputColor2(i, indicatorOutputInfo.getColor2());
/* 1046 */         setOpacityAlpha(i, indicatorOutputInfo.getOpacityAlpha());
/* 1047 */         setDrawingStyle(i, indicatorOutputInfo.getDrawingStyle());
/* 1048 */         setLineWidth(i, indicatorOutputInfo.getLineWidth());
/* 1049 */         setOutputShift(i, indicatorOutputInfo.getShift());
/* 1050 */         setShowValueOnChart(i, indicatorOutputInfo.isShowValueOnChart());
/* 1051 */         setShowOutput(i, indicatorOutputInfo.isShowOutput());
/* 1052 */         setShowPopupInfo(i, indicatorOutputInfo.isShowPopupInfo());
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1056 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void synchronizeIndicatorEditableParameters()
/*      */   {
/*      */     try
/*      */     {
/* 1065 */       IIndicator indicator = getIndicator();
/* 1066 */       indicator.getIndicatorInfo().setRecalculateOnNewCandleOnly(isRecalculateOnNewCandleOnly());
/* 1067 */       for (int i = 0; i < indicator.getIndicatorInfo().getNumberOfOutputs(); i++) {
/* 1068 */         OutputParameterInfo outputParameterInfo = indicator.getOutputParameterInfo(i);
/*      */         
/* 1070 */         outputParameterInfo.setColor(getOutputColors()[i]);
/* 1071 */         outputParameterInfo.setColor2(getOutputColors2()[i]);
/* 1072 */         outputParameterInfo.setDrawingStyle(getDrawingStyles()[i]);
/* 1073 */         outputParameterInfo.setLineWidth(getLineWidths()[i]);
/* 1074 */         outputParameterInfo.setOpacityAlpha(getOpacityAlphas()[i]);
/* 1075 */         outputParameterInfo.setShift(getOutputShifts()[i]);
/* 1076 */         outputParameterInfo.setShowValueOnChart(getShowValuesOnChart()[i]);
/* 1077 */         outputParameterInfo.setShowOutput(getShowOutputs()[i]);
/* 1078 */         outputParameterInfo.setShowPopupInfo(getShowPopupInfo()[i]);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1082 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Integer getChartPanelId()
/*      */   {
/* 1090 */     return this.chartPanelId;
/*      */   }
/*      */   
/*      */   public void setChartPanelId(Integer chartPanelId) {
/* 1094 */     this.chartPanelId = chartPanelId;
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/* 1099 */     return String.format("%s optParams=%s, drawingStyles=%s, widths=%s, colors=%s", new Object[] { getName(), Arrays.toString(getOptParams()), Arrays.toString(getDrawingStyles()), Arrays.toString(getLineWidths()), Arrays.toString(getOutputColors()) });
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\IndicatorWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */