/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.time.ITimeManager;
/*     */ import com.dukascopy.json.JSONArray;
/*     */ import com.dukascopy.json.JSONObject;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Calendar;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActivityLogger
/*     */   extends Thread
/*     */ {
/*  31 */   private static final Logger LOGGER = LoggerFactory.getLogger(ActivityLogger.class);
/*     */   private static final String THREAD_NAME = "ActivityLogger";
/*  33 */   private static final long PERIOD = TimeUnit.SECONDS.toMillis(10L);
/*     */   
/*     */   private static final String DIGEST_ALGORITHM = "MD5";
/*     */   
/*     */   private static final String CHARSET = "UTF-8";
/*     */   
/*     */   private static final String AUTH_REQUEST_FORMAT = "check=%1$s&%2$s=%3$s";
/*     */   
/*     */   private static final String LOGIN_PARAM_KEY = "login";
/*     */   
/*     */   private static final String LOGIN_ID_PARAM_KEY = "loginId";
/*     */   private static final String REQUEST_URL_FORMAT = "%1$s?%2$s&tzOffsetSeconds=%3$s";
/*     */   private static final String APPLICATION_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
/*     */   private static final String CONTENT_TYPE_REQUEST_PROPERTY = "Content-Type";
/*     */   private static final String CONTENT_LENGTH_REQUEST_PROPERTY = "Content-Length";
/*     */   private static final String POST_REQUEST_METHOD = "POST";
/*     */   private static final String DATA_KEY = "data=";
/*     */   private static final String SECRETTO = "secretto";
/*     */   private static final String DATUM_TYPE = "datumType";
/*     */   private static final String DATUM_MESSAGE = "message";
/*     */   private static final String TIMESTAMP_KEY = "timestamp";
/*     */   private static final String CLIENT_TIME_KEY = "clientTime";
/*     */   private static final String MESSAGE_KEY = "message";
/*     */   private static ActivityLogger instance;
/*     */   private final String serviceUrl;
/*     */   private final long timeZoneOffset;
/*     */   private final String login;
/*     */   private final String loginId;
/*  61 */   private JSONArray jaForImmediateSend = new JSONArray();
/*     */   private boolean stop;
/*     */   
/*     */   private ActivityLogger(String serviceUrl, String login, String loginId) {
/*  65 */     super("ActivityLogger");
/*     */     
/*  67 */     this.serviceUrl = serviceUrl;
/*  68 */     this.login = login;
/*  69 */     this.loginId = loginId;
/*     */     
/*  71 */     Calendar calendar = Calendar.getInstance();
/*  72 */     this.timeZoneOffset = (-(calendar.get(15) + calendar.get(16)));
/*     */     
/*  74 */     Runtime.getRuntime().addShutdownHook(new Thread()
/*     */     {
/*     */       public void run() {
/*  77 */         ActivityLogger.this.flush();
/*     */       }
/*     */       
/*  80 */     });
/*  81 */     setDaemon(true);
/*  82 */     start();
/*     */   }
/*     */   
/*     */   public static synchronized void init(String serviceUrl, String login) {
/*  86 */     init(serviceUrl, login, null);
/*     */   }
/*     */   
/*     */   public static synchronized void init(String serviceUrl, String login, String loginId) {
/*  90 */     if (instance != null) {
/*  91 */       instance.stopLogger();
/*     */     }
/*  93 */     instance = new ActivityLogger(serviceUrl, login, loginId);
/*     */   }
/*     */   
/*     */   public static synchronized ActivityLogger getInstance() {
/*  97 */     return instance;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/* 102 */     while ((!this.stop) && (!isInterrupted())) {
/*     */       try {
/* 104 */         Thread.sleep(PERIOD);
/* 105 */         flush();
/*     */       }
/*     */       catch (InterruptedException e) {
/* 108 */         interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush() {
/*     */     try {
/* 115 */       sendLog();
/*     */     } catch (IOException e) {
/* 117 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void add(String message) {
/* 122 */     add(message, String.valueOf(getServerTime()));
/*     */   }
/*     */   
/*     */   public void sendLog() throws IOException {
/*     */     String messageString;
/* 127 */     synchronized (this) {
/* 128 */       int size = this.jaForImmediateSend.length();
/* 129 */       if (0 == size) {
/* 130 */         return;
/*     */       }
/* 132 */       messageString = this.jaForImmediateSend.toString();
/* 133 */       this.jaForImmediateSend = new JSONArray();
/*     */     }
/*     */     
/* 136 */     String jameson = "";
/*     */     try {
/* 138 */       jameson = URLEncoder.encode(messageString, "UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/* 140 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */     
/* 143 */     if (LOGGER.isDebugEnabled()) {
/* 144 */       LOGGER.debug("jah : {}", messageString);
/*     */     }
/*     */     
/* 147 */     String authorization = buildAuthorizationRequest(this.login, this.loginId);
/* 148 */     if (null == authorization) {
/* 149 */       authorization = "";
/*     */     }
/*     */     
/* 152 */     String requestUrl = String.format("%1$s?%2$s&tzOffsetSeconds=%3$s", new Object[] { this.serviceUrl, authorization, Long.toString(TimeUnit.MILLISECONDS.toSeconds(this.timeZoneOffset)) });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */     doPostLog(requestUrl, jameson);
/*     */   }
/*     */   
/*     */   private synchronized void stopLogger() {
/* 162 */     flush();
/* 163 */     this.stop = true;
/* 164 */     interrupt();
/*     */     try {
/* 166 */       join();
/*     */     }
/*     */     catch (InterruptedException e) {
/* 169 */       interrupt();
/*     */     }
/*     */   }
/*     */   
/*     */   private static String buildAuthorizationRequest(String login, String loginId) {
/* 174 */     String check = encode(login != null ? login : loginId);
/*     */     
/* 176 */     if (check == null) {
/* 177 */       LOGGER.warn("Unable to generate [{}] hash", "MD5");
/* 178 */       return null;
/*     */     }
/*     */     
/* 181 */     return String.format("check=%1$s&%2$s=%3$s", new Object[] { check, login != null ? "login" : "loginId", login != null ? login : loginId });
/*     */   }
/*     */   
/*     */ 
/*     */   private static String encode(String key)
/*     */   {
/*     */     MessageDigest digest;
/*     */     
/*     */     try
/*     */     {
/* 191 */       digest = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException nsae) {
/* 193 */       LOGGER.error(nsae.getMessage(), nsae);
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     char[] encodedChars = null;
/*     */     try {
/* 199 */       byte[] encodedBytes = digest.digest((key + "secretto").getBytes("UTF-8"));
/* 200 */       encodedChars = new String(encodedBytes, "UTF-8").toCharArray();
/*     */     } catch (UnsupportedEncodingException uee) {
/* 202 */       LOGGER.error(uee.getMessage(), uee);
/* 203 */       return null;
/*     */     }
/* 205 */     return new String(toHexString(encodedChars));
/*     */   }
/*     */   
/*     */   private static char[] toHexString(char[] chars) {
/* 209 */     StringBuilder result = new StringBuilder("");
/* 210 */     for (char symbol : chars) {
/* 211 */       String charHexStr = Integer.toHexString(symbol);
/* 212 */       if (charHexStr.length() == 1) {
/* 213 */         charHexStr = '0' + charHexStr;
/*     */       }
/* 215 */       result.append(charHexStr);
/*     */     }
/* 217 */     return result.toString().toCharArray();
/*     */   }
/*     */   
/*     */   private static int doPostLog(String requestUrl, String message) throws IOException {
/* 221 */     URL url = new URL(requestUrl);
/*     */     
/* 223 */     HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
/* 224 */     urlConnection.setDoInput(true);
/* 225 */     urlConnection.setDoOutput(true);
/* 226 */     urlConnection.setUseCaches(false);
/* 227 */     urlConnection.setRequestMethod("POST");
/* 228 */     urlConnection.setRequestProperty("Content-Length", "data=".length() + Integer.toString(message.getBytes("UTF-8").length));
/* 229 */     urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/*     */     
/* 231 */     DataOutputStream outStream = new DataOutputStream(urlConnection.getOutputStream());
/* 232 */     outStream.writeBytes("data=");
/* 233 */     outStream.writeBytes(message);
/* 234 */     outStream.flush();
/* 235 */     outStream.close();
/* 236 */     int responseCode = urlConnection.getResponseCode();
/* 237 */     urlConnection.disconnect();
/*     */     
/* 239 */     if (LOGGER.isDebugEnabled()) {
/* 240 */       LOGGER.debug("Trade Log ({}) : {}", Integer.valueOf(responseCode), requestUrl);
/*     */     }
/*     */     
/* 243 */     return responseCode;
/*     */   }
/*     */   
/*     */   private synchronized void add(String message, String serverTimestamp) {
/* 247 */     JSONObject json = new JSONObject();
/* 248 */     json.put("datumType", "message");
/* 249 */     json.put("message", message);
/* 250 */     json.put("timestamp", serverTimestamp);
/* 251 */     json.put("clientTime", getClientTime());
/* 252 */     this.jaForImmediateSend.put(json);
/*     */   }
/*     */   
/*     */   private String getClientTime() {
/* 256 */     return Long.toString(System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   private long getServerTime() {
/* 260 */     Long serverTime = null;
/* 261 */     FeedDataProvider feedDataProvider = FeedDataProvider.getDefaultInstance();
/*     */     
/* 263 */     if (feedDataProvider != null) {
/* 264 */       ITimeManager timeManager = feedDataProvider.getTimeManager();
/* 265 */       if (timeManager != null) {
/* 266 */         serverTime = timeManager.getServerTimeWithLatency();
/* 267 */         LOGGER.trace("Server time: " + serverTime);
/*     */       } else {
/* 269 */         LOGGER.warn("TimeManager is not initialized. Unable to get server time.");
/*     */       }
/*     */     } else {
/* 272 */       LOGGER.warn("FeedDataProvider is not initialized. Unable to get server time.");
/*     */     }
/*     */     
/* 275 */     if (serverTime == null) {
/* 276 */       serverTime = Long.valueOf(feedDataProvider != null ? feedDataProvider.getEstimatedServerOrLocalTime() : System.currentTimeMillis());
/*     */     }
/*     */     
/* 279 */     return serverTime.longValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ActivityLogger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */