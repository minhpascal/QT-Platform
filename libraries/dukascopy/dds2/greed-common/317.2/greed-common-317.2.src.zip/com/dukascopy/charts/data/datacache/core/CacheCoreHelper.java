/*    */ package com.dukascopy.charts.data.datacache.core;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheCoreHelper
/*    */ {
/*    */   public static void ensureFileCreated(File file)
/*    */     throws IOException
/*    */   {
/* 17 */     if (!file.exists()) {
/* 18 */       File parent = file.getParentFile();
/* 19 */       if (parent != null) {
/* 20 */         parent.mkdirs();
/*    */       }
/*    */       
/* 23 */       if ((!file.createNewFile()) && (!file.exists()))
/*    */       {
/*    */ 
/*    */ 
/* 27 */         throw new FileNotFoundException("Unable to create file " + file);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\CacheCoreHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */