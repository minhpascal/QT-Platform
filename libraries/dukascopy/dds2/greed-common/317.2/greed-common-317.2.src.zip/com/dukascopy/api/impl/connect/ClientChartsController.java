/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientChartsController
/*    */   extends JForexContextChartsController
/*    */ {
/*    */   public ClientChartsController(DDSChartsController chartsController, String callerId)
/*    */   {
/* 20 */     super(chartsController, null, null, callerId);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ClientChartsController.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */