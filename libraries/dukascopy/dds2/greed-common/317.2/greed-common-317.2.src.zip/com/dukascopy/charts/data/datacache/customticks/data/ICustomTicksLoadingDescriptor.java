package com.dukascopy.charts.data.datacache.customticks.data;

import com.dukascopy.api.OfferSide;
import com.dukascopy.api.Period;

public abstract interface ICustomTicksLoadingDescriptor
{
  public abstract CustomTicksLoadingMethod getLoadingMethod();
  
  public abstract void setLoadingMethod(CustomTicksLoadingMethod paramCustomTicksLoadingMethod);
  
  public abstract Period getPeriod();
  
  public abstract void setPeriod(Period paramPeriod);
  
  public abstract OfferSide getOfferSide();
  
  public abstract void setOfferSide(OfferSide paramOfferSide);
  
  public abstract void setPriceDifferenceInPips(long paramLong);
  
  public abstract long getPriceDifferenceInPips();
  
  public abstract void setTimeIntervalBetweenTicks(long paramLong);
  
  public abstract long getTimeIntervalBetweenTicks();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\data\ICustomTicksLoadingDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */