/*     */ package com.dukascopy.charts.data.datacache.feed;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.Data;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.dds3.transport.msg.acc.FeedCommission;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeedCommissionManager
/*     */   implements IFeedCommissionManager
/*     */ {
/*  34 */   private static final Logger LOGGER = LoggerFactory.getLogger(FeedCommissionManager.class);
/*     */   
/*  36 */   protected static final TimeZone GMT_TIME_ZONE = TimeZone.getTimeZone("GMT 0");
/*  37 */   protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
/*     */   
/*  39 */   static { DATE_FORMAT.setTimeZone(GMT_TIME_ZONE); }
/*     */   
/*     */ 
/*     */   private static final String NULL_TOKEN = "null";
/*     */   
/*  44 */   private final double ZERO_COMMISSION = 0.0D;
/*     */   
/*     */   private List<String[]> feedCommissions;
/*  47 */   private final FeedCommissionMap feedCommissionMap = new FeedCommissionMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeedCommissionManager(List<String[]> feedCommissionsFromAuthServer)
/*     */   {
/*  56 */     setupFeedCommissionsFromAuthServer(feedCommissionsFromAuthServer);
/*     */   }
/*     */   
/*     */   public void addFeedCommissions(Map<String, FeedCommission> feedCommissions)
/*     */   {
/*  61 */     addFeedCommissions(feedCommissions, null);
/*     */   }
/*     */   
/*     */   public void addFeedCommissions(Map<String, FeedCommission> feedCommissions, Long time)
/*     */   {
/*  66 */     if ((feedCommissions == null) || (feedCommissions.isEmpty())) {
/*  67 */       return;
/*     */     }
/*     */     
/*  70 */     List<IInstrumentFeedCommissionInfo> fc = convert(feedCommissions, time);
/*  71 */     addFeedCommissions(fc);
/*     */   }
/*     */   
/*     */   public void addFeedCommissions(Map<String, FeedCommission> feedCommissions, long time)
/*     */   {
/*  76 */     addFeedCommissions(feedCommissions, new Long(time));
/*     */   }
/*     */   
/*     */ 
/*     */   public void addFeedCommissions(List<IInstrumentFeedCommissionInfo> feedCommissions)
/*     */   {
/*  82 */     if ((feedCommissions == null) || (feedCommissions.isEmpty())) {
/*  83 */       return;
/*     */     }
/*     */     
/*  86 */     synchronized (feedCommissions) {
/*  87 */       addToFeedCommissionsMap(feedCommissions);
/*     */     }
/*     */   }
/*     */   
/*     */   private IInstrumentFeedCommissionInfo getFeedCommissionInfo(Instrument instrument, long time) {
/*  92 */     IInstrumentFeedCommissionInfo result = this.feedCommissionMap.getFeedCommissionInfo(instrument, time);
/*  93 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public double getFeedCommission(Instrument instrument, OfferSide side, long time)
/*     */   {
/*  99 */     if (side == null) {
/* 100 */       throw new NullPointerException("Offer side has to be specified");
/*     */     }
/*     */     
/* 103 */     IInstrumentFeedCommissionInfo feedCommissionInfo = getFeedCommissionInfo(instrument, time);
/*     */     
/* 105 */     if (feedCommissionInfo == null) {
/* 106 */       return 0.0D;
/*     */     }
/*     */     
/*     */     double commission;
/*     */     double commission;
/* 111 */     if (OfferSide.ASK.equals(side)) {
/* 112 */       commission = feedCommissionInfo.getAskFeedCommission();
/*     */     }
/*     */     else {
/* 115 */       commission = feedCommissionInfo.getBidFeedCommission();
/*     */     }
/*     */     
/* 118 */     return toPrice(instrument, commission);
/*     */   }
/*     */   
/*     */   private double toPrice(Instrument instrument, double commissionInPips) {
/* 122 */     double result = commissionInPips * instrument.getPipValue();
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public void setupFeedCommissions(List<IInstrumentFeedCommissionInfo> feedCommissions)
/*     */   {
/* 128 */     if ((feedCommissions == null) || (feedCommissions.isEmpty())) {
/* 129 */       return;
/*     */     }
/*     */     
/* 132 */     this.feedCommissionMap.setupFeedCommissionsMap(feedCommissions);
/*     */   }
/*     */   
/*     */   public void setupFeedCommissionsFromAuthServer(List<String[]> feedCommissions)
/*     */   {
/* 137 */     if ((feedCommissions == null) || (feedCommissions.isEmpty())) {
/* 138 */       return;
/*     */     }
/*     */     
/* 141 */     this.feedCommissions = feedCommissions;
/*     */     try
/*     */     {
/* 144 */       List<IInstrumentFeedCommissionInfo> result = convert(feedCommissions);
/* 145 */       setupFeedCommissions(result);
/*     */     } catch (Throwable t) {
/* 147 */       LOGGER.error("Failed to setup feed commission history " + t.getMessage(), t);
/*     */     }
/*     */   }
/*     */   
/*     */   public TickData applyFeedCommissionToTick(Instrument instrument, OfferSide offerSide, TickData tick)
/*     */   {
/* 153 */     synchronized (this.feedCommissionMap) {
/* 154 */       if (!doWeHaveCommission(instrument)) {
/* 155 */         return tick;
/*     */       }
/*     */       
/* 158 */       if (offerSide != null) {
/* 159 */         double feedCommission = getFeedCommission(instrument, offerSide, tick.time);
/* 160 */         if (feedCommission != 0.0D) {
/* 161 */           applyCommission(instrument, tick, offerSide, feedCommission);
/*     */         }
/*     */       }
/*     */       else {
/* 165 */         tick = applyFeedCommissionToTick(instrument, tick);
/*     */       }
/*     */       
/* 168 */       return tick;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */   {
/* 175 */     this.feedCommissionMap.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getPriceWithCommission(Instrument instrument, OfferSide side, double price, long time)
/*     */   {
/* 185 */     synchronized (this.feedCommissionMap) {
/* 186 */       if (!doWeHaveCommission(instrument)) {
/* 187 */         return price;
/*     */       }
/*     */       
/* 190 */       double feedCommission = getFeedCommission(instrument, side, time);
/* 191 */       double priceWithCommission = price;
/*     */       
/* 193 */       if (feedCommission != 0.0D) {
/* 194 */         priceWithCommission = DataCacheUtils.getPriceWithCommission(instrument, side, price, feedCommission);
/*     */       }
/*     */       
/* 197 */       return priceWithCommission;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CandleData applyFeedCommissionToCandle(Instrument instrument, OfferSide side, CandleData candle)
/*     */   {
/* 208 */     synchronized (this.feedCommissionMap) {
/* 209 */       if (!doWeHaveCommission(instrument)) {
/* 210 */         return candle;
/*     */       }
/*     */       
/* 213 */       double feedCommission = getFeedCommission(instrument, side, candle.time);
/*     */       
/* 215 */       if (feedCommission != 0.0D) {
/* 216 */         applyCommission(instrument, side, candle, feedCommission);
/*     */       }
/*     */       
/* 219 */       return candle;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Data[] applyFeedCommissionToData(Instrument instrument, Period period, OfferSide offerSide, Data[] data)
/*     */   {
/* 231 */     synchronized (this.feedCommissionMap) {
/* 232 */       if (!doWeHaveCommission(instrument)) {
/* 233 */         return data;
/*     */       }
/*     */       
/* 236 */       if (period.isTickBasedPeriod()) {
/* 237 */         for (Data dataElem : data) {
/* 238 */           TickData tick = (TickData)dataElem;
/* 239 */           if (offerSide == null) {
/* 240 */             applyFeedCommissionToTick(instrument, tick);
/*     */           }
/*     */           else {
/* 243 */             double feedCommission = getFeedCommission(instrument, offerSide, tick.time);
/* 244 */             if (feedCommission != 0.0D) {
/* 245 */               applyCommission(instrument, tick, offerSide, feedCommission);
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       } else {
/* 251 */         for (Data dataElem : data) {
/* 252 */           CandleData candle = (CandleData)dataElem;
/* 253 */           double feedCommission = getFeedCommission(instrument, offerSide, candle.time);
/* 254 */           if (feedCommission != 0.0D) {
/* 255 */             applyCommission(instrument, offerSide, candle, feedCommission);
/*     */           }
/*     */         }
/*     */       }
/* 259 */       return data;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasCommission(Instrument instrument)
/*     */   {
/* 266 */     return doWeHaveCommission(instrument);
/*     */   }
/*     */   
/*     */   private boolean doWeHaveCommission(Instrument instrument) {
/* 270 */     boolean contains = this.feedCommissionMap.hasCommission(instrument);
/* 271 */     return contains;
/*     */   }
/*     */   
/*     */   private List<IInstrumentFeedCommissionInfo> convert(Map<String, FeedCommission> feedCommissions, Long time)
/*     */   {
/* 276 */     if ((feedCommissions == null) || (feedCommissions.isEmpty())) {
/* 277 */       return null;
/*     */     }
/*     */     
/* 280 */     long theTime = time == null ? System.currentTimeMillis() : time.longValue();
/* 281 */     List<IInstrumentFeedCommissionInfo> result = new ArrayList();
/*     */     
/* 283 */     for (String key : feedCommissions.keySet()) {
/*     */       try
/*     */       {
/* 286 */         FeedCommission fc = (FeedCommission)feedCommissions.get(key);
/* 287 */         BigDecimal askFeedCommissionBD = fc.getFeedComAskPip();
/* 288 */         BigDecimal bidFeedCommissionBD = fc.getFeedComBidPip();
/*     */         
/* 290 */         if ((askFeedCommissionBD != null) || (bidFeedCommissionBD != null))
/*     */         {
/*     */ 
/*     */ 
/* 294 */           Instrument instrument = parseInstrument(key);
/* 295 */           double askFeedCommission = askFeedCommissionBD == null ? 0.0D : askFeedCommissionBD.doubleValue();
/* 296 */           double bidFeedCommission = bidFeedCommissionBD == null ? 0.0D : bidFeedCommissionBD.doubleValue();
/*     */           
/* 298 */           IInstrumentFeedCommissionInfo info = new InstrumentFeedCommissionInfo(instrument, askFeedCommission, bidFeedCommission, theTime, Long.MAX_VALUE);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */           result.add(info);
/*     */         }
/*     */       } catch (Throwable t) {
/* 308 */         LOGGER.error("Failed to add feed commission history for instrument " + key + " " + t.getMessage(), t);
/*     */       }
/*     */     }
/*     */     
/* 312 */     return result;
/*     */   }
/*     */   
/*     */   private List<IInstrumentFeedCommissionInfo> convert(List<String[]> feedCommissions) {
/* 316 */     List<IInstrumentFeedCommissionInfo> result = new ArrayList();
/*     */     
/* 318 */     for (String[] feedCommissionArray : feedCommissions)
/* 319 */       if (feedCommissionArray != null) {
/* 320 */         int LENGTH = 8;
/* 321 */         if (feedCommissionArray.length < 8) {
/* 322 */           throw new IllegalArgumentException("Wrong commission record length! Desired <8> got <" + feedCommissionArray.length + "> for commission record <" + Arrays.toString(feedCommissionArray) + ">");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */         Instrument instrument = parseInstrument(feedCommissionArray[1]);
/*     */         
/* 333 */         Long from = parseLong(feedCommissionArray[3]);
/* 334 */         Long to = parseLong(feedCommissionArray[4]);
/* 335 */         Long priority = parseLong(feedCommissionArray[5]);
/* 336 */         Double askFeedCommission = parseDouble(feedCommissionArray[6]);
/* 337 */         Double bidFeedCommission = parseDouble(feedCommissionArray[7]);
/*     */         
/* 339 */         if ((askFeedCommission == null) && (bidFeedCommission == null)) {
/* 340 */           LOGGER.warn("Ask and bid feed commission are null - skipping feed commission");
/*     */         }
/*     */         else
/*     */         {
/* 344 */           if (askFeedCommission == null) {
/* 345 */             askFeedCommission = new Double(0.0D);
/*     */           }
/*     */           
/* 348 */           if (bidFeedCommission == null) {
/* 349 */             bidFeedCommission = new Double(0.0D);
/*     */           }
/*     */           
/* 352 */           if ((askFeedCommission.doubleValue() == 0.0D) && (bidFeedCommission.doubleValue() == 0.0D)) {
/* 353 */             LOGGER.warn("Ask and bid feed commission both are zero - skipping feed commission");
/*     */           }
/*     */           else
/*     */           {
/* 357 */             if (priority == null) {
/* 358 */               throw new IllegalArgumentException("Priority value is null");
/*     */             }
/*     */             
/* 361 */             if (from == null) {
/* 362 */               from = Long.valueOf(Long.MIN_VALUE);
/*     */             }
/*     */             
/* 365 */             if (to == null) {
/* 366 */               to = Long.valueOf(Long.MAX_VALUE);
/*     */             }
/*     */             
/* 369 */             if (from.longValue() > to.longValue()) {
/* 370 */               throw new IllegalArgumentException("from > to ");
/*     */             }
/*     */             
/* 373 */             IInstrumentFeedCommissionInfo instrumentFeedCommissionInfo = new InstrumentFeedCommissionInfo(instrument, askFeedCommission.doubleValue(), bidFeedCommission.doubleValue(), from.longValue(), to.longValue(), priority.longValue());
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 382 */             result.add(instrumentFeedCommissionInfo);
/*     */           }
/*     */         }
/*     */       }
/* 386 */     return result;
/*     */   }
/*     */   
/*     */   private Double parseDouble(String str) {
/* 390 */     if ((str == null) || ("null".equalsIgnoreCase(str))) {
/* 391 */       return null;
/*     */     }
/*     */     
/* 394 */     return Double.valueOf(str);
/*     */   }
/*     */   
/*     */   private Instrument parseInstrument(String str)
/*     */   {
/* 399 */     if ((str == null) || ("null".equalsIgnoreCase(str))) {
/* 400 */       return null;
/*     */     }
/*     */     
/* 403 */     Instrument result = Instrument.fromString(str);
/* 404 */     if (result == null) {
/* 405 */       result = Instrument.valueOf(str);
/*     */     }
/*     */     
/* 408 */     return result;
/*     */   }
/*     */   
/*     */   private Long parseLong(String str) {
/* 412 */     if ((str == null) || ("null".equalsIgnoreCase(str))) {
/* 413 */       return null;
/*     */     }
/*     */     
/* 416 */     return Long.valueOf(str);
/*     */   }
/*     */   
/*     */   private void addToFeedCommissionsMap(List<IInstrumentFeedCommissionInfo> instrumentFeedCommissions)
/*     */   {
/* 421 */     this.feedCommissionMap.addToFeedCommissionsMap(instrumentFeedCommissions);
/*     */   }
/*     */   
/*     */   private void applyCommission(Instrument instrument, OfferSide offerSide, CandleData candle, double feedCommission) {
/* 425 */     candle.open = DataCacheUtils.getPriceWithCommission(instrument, offerSide, candle.open, feedCommission);
/* 426 */     candle.close = DataCacheUtils.getPriceWithCommission(instrument, offerSide, candle.close, feedCommission);
/* 427 */     candle.high = DataCacheUtils.getPriceWithCommission(instrument, offerSide, candle.high, feedCommission);
/* 428 */     candle.low = DataCacheUtils.getPriceWithCommission(instrument, offerSide, candle.low, feedCommission);
/*     */   }
/*     */   
/*     */   private void applyCommission(Instrument instrument, TickData tick, OfferSide offerSide, double feedCommission) {
/* 432 */     if (OfferSide.ASK.equals(offerSide)) {
/* 433 */       double priceWithCommission = DataCacheUtils.getPriceWithCommission(instrument, OfferSide.ASK, tick.ask, feedCommission);
/* 434 */       tick.ask = priceWithCommission;
/*     */     }
/*     */     else {
/* 437 */       double priceWithCommission = DataCacheUtils.getPriceWithCommission(instrument, OfferSide.BID, tick.bid, feedCommission);
/* 438 */       tick.bid = priceWithCommission;
/*     */     }
/*     */   }
/*     */   
/*     */   public List<String[]> getFeedCommissions()
/*     */   {
/* 444 */     if (this.feedCommissions == null) {
/* 445 */       return null;
/*     */     }
/* 447 */     return Collections.unmodifiableList(this.feedCommissions);
/*     */   }
/*     */   
/*     */   public TickData applyFeedCommissionToTick(Instrument instrument, TickData tick)
/*     */   {
/* 452 */     IInstrumentFeedCommissionInfo fci = getFeedCommissionInfo(instrument, tick.time);
/*     */     
/* 454 */     if (fci == null) {
/* 455 */       return tick;
/*     */     }
/*     */     
/* 458 */     if (fci.getAskFeedCommission() != 0.0D) {
/* 459 */       double askFeedCommission = toPrice(instrument, fci.getAskFeedCommission());
/* 460 */       if (askFeedCommission != 0.0D) {
/* 461 */         applyCommission(instrument, tick, OfferSide.ASK, askFeedCommission);
/*     */       }
/*     */     }
/*     */     
/* 465 */     if (fci.getBidFeedCommission() != 0.0D) {
/* 466 */       double bidFeedCommission = toPrice(instrument, fci.getBidFeedCommission());
/* 467 */       if (bidFeedCommission != 0.0D) {
/* 468 */         applyCommission(instrument, tick, OfferSide.BID, bidFeedCommission);
/*     */       }
/*     */     }
/*     */     
/* 472 */     return tick;
/*     */   }
/*     */   
/*     */   public FeedCommissionManager() {}
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\feed\FeedCommissionManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */