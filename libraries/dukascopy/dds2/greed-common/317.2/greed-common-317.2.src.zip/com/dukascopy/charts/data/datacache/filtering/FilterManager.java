/*     */ package com.dukascopy.charts.data.datacache.filtering;
/*     */ 
/*     */ import com.dukascopy.api.Filter;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.customperiod.tick.FirstTickLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.customperiod.tick.LastTickLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.time.ITimeManager;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.ITimeInterval;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.TimeInterval;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterManager
/*     */   implements IFilterManager
/*     */ {
/*  40 */   private static final Logger LOGGER = LoggerFactory.getLogger(FilterManager.class);
/*     */   
/*  42 */   private static final Calendar calendarForWeekendsDetection = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*     */   
/*     */   private final WeekendBuffer weekendBuffer;
/*     */   
/*     */   private final IFeedDataProvider feedDataProvider;
/*     */   
/*  48 */   private static final long ONE_WEEK = TimeUnit.DAYS.toMillis(7L);
/*  49 */   private static final long ONE_HOUR = TimeUnit.HOURS.toMillis(1L);
/*  50 */   private static final long TWO_DAYS = TimeUnit.DAYS.toMillis(2L);
/*  51 */   private static final long FIVE_DAYS = TimeUnit.DAYS.toMillis(5L);
/*     */   
/*  53 */   private final Map<ITimeInterval, ITimeInterval> preciseWeekendsCacheMap = new HashMap();
/*  54 */   private final Instrument INSTRUMENT = Instrument.EURUSD;
/*  55 */   private boolean cachePreloaded = false;
/*     */   
/*     */   public FilterManager(IFeedDataProvider feedDataProvider)
/*     */   {
/*  59 */     this(feedDataProvider, new WeekendBuffer());
/*     */   }
/*     */   
/*     */   public FilterManager(IFeedDataProvider feedDataProvider, WeekendBuffer weekendBuffer) {
/*  63 */     this.feedDataProvider = feedDataProvider;
/*  64 */     this.weekendBuffer = weekendBuffer;
/*     */   }
/*     */   
/*     */   public boolean isWeekendTime(long time, Period period) {
/*     */     boolean result;
/*     */     boolean result;
/*  70 */     if (((Period.DAILY_SKIP_SUNDAY.equals(period)) && (Period.DAILY_SKIP_SUNDAY.name().equals(period.name()))) || ((Period.DAILY_SUNDAY_IN_MONDAY.equals(period)) && (Period.DAILY_SUNDAY_IN_MONDAY.name().equals(period.name()))))
/*     */     {
/*     */ 
/*     */ 
/*  74 */       result = isWeekendTime(time, period, false);
/*     */     }
/*     */     else {
/*  77 */       result = isWeekendTime(time, period, true);
/*     */     }
/*  79 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isWeekendTime(long time, Period period, boolean checkPeriodEnd)
/*     */   {
/*  88 */     if (period.getInterval() > TimeUnit.DAYS.toMillis(2L))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  93 */       return false;
/*     */     }
/*     */     
/*  96 */     long periodEnd = time;
/*     */     
/*  98 */     if (checkPeriodEnd) {
/*  99 */       if (period.isTickBasedPeriod()) {
/* 100 */         periodEnd = time;
/*     */       }
/*     */       else {
/* 103 */         periodEnd = DataCacheUtils.getNextCandleStartFast(period, time) - 1L;
/*     */       }
/*     */     }
/*     */     
/*     */     boolean result;
/*     */     
/* 109 */     synchronized (this.weekendBuffer) {
/* 110 */       boolean coversTime = this.weekendBuffer.coversInterval(time, periodEnd);
/* 111 */       if (!coversTime) {
/* 112 */         fillWeekendsBuffer(Math.min(this.weekendBuffer.getFrom(), time), Math.max(this.weekendBuffer.getTo(), periodEnd));
/*     */       }
/*     */       
/* 115 */       result = this.weekendBuffer.isWeekendTime(time);
/*     */       
/* 117 */       if ((result) && (time != periodEnd)) {
/* 118 */         result &= this.weekendBuffer.isWeekendTime(periodEnd);
/*     */       }
/*     */     }
/*     */     
/* 122 */     long serverTime = getServerTime();
/*     */     
/* 124 */     if ((!result) && (serverTime < periodEnd))
/*     */     {
/* 126 */       Object futureWeekends = calculateApproximateWeekends(serverTime, periodEnd);
/* 127 */       for (ITimeInterval weekend : (List)futureWeekends) {
/* 128 */         if (weekend.isInIntervalForWeekends(periodEnd)) {
/* 129 */           result = true;
/* 130 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fillWeekendsBuffer(long from, long to)
/*     */   {
/* 145 */     if (from > to) {
/* 146 */       throw new IllegalArgumentException("from > to : " + DateUtils.format(from) + " > " + DateUtils.format(to));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 152 */     to += 10L * ONE_WEEK;
/* 153 */     from -= 10L * ONE_WEEK;
/*     */     
/* 155 */     if (from < 0L) {
/* 156 */       from = 0L;
/*     */     }
/*     */     
/* 159 */     long serverTime = getServerTime();
/* 160 */     if (to > serverTime) {
/* 161 */       to = serverTime;
/*     */     }
/*     */     
/* 164 */     boolean coversInterval = this.weekendBuffer.coversInterval(from, to);
/*     */     
/* 166 */     if (coversInterval) {
/* 167 */       return;
/*     */     }
/* 169 */     if (!this.weekendBuffer.isEmpty()) {
/* 170 */       boolean fromIsOk = false;
/* 171 */       if (((from == 0L) && (this.weekendBuffer.getFrom() < ONE_WEEK)) || (from >= this.weekendBuffer.getFrom()))
/*     */       {
/*     */ 
/*     */ 
/* 175 */         fromIsOk = true;
/*     */       }
/*     */       
/* 178 */       boolean toIsOk = false;
/* 179 */       if (((to == serverTime) && (Math.abs(serverTime - this.weekendBuffer.getTo()) < ONE_WEEK)) || (to <= this.weekendBuffer.getTo()))
/*     */       {
/*     */ 
/*     */ 
/* 183 */         toIsOk = true;
/*     */       }
/*     */       
/* 186 */       if ((fromIsOk) && (toIsOk)) {
/* 187 */         return;
/*     */       }
/*     */     }
/*     */     
/* 191 */     long preciseApproxWeekendsBorderTime = serverTime - TimeUnit.DAYS.toMillis(14L);
/*     */     List<ITimeInterval> weekends;
/*     */     List<ITimeInterval> weekends;
/* 194 */     if (to < preciseApproxWeekendsBorderTime) {
/* 195 */       weekends = calculateApproximateWeekends(from, to);
/*     */     }
/*     */     else {
/* 198 */       weekends = new ArrayList();
/*     */       
/* 200 */       long approxWeekendsTo = preciseApproxWeekendsBorderTime - 1L;
/* 201 */       if (from >= approxWeekendsTo) {
/* 202 */         from = approxWeekendsTo - ONE_WEEK;
/*     */       }
/* 204 */       List<ITimeInterval> approximateWeekends = calculateApproximateWeekends(from, approxWeekendsTo);
/* 205 */       weekends.addAll(approximateWeekends);
/*     */       
/* 207 */       to = to > serverTime ? serverTime : to;
/*     */       long preciseWeekendsFrom;
/*     */       long preciseWeekendsFrom;
/* 210 */       if (!approximateWeekends.isEmpty())
/*     */       {
/*     */ 
/*     */ 
/* 214 */         preciseWeekendsFrom = ((ITimeInterval)approximateWeekends.get(approximateWeekends.size() - 1)).getEnd() + ONE_HOUR;
/*     */       }
/*     */       else {
/* 217 */         preciseWeekendsFrom = preciseApproxWeekendsBorderTime;
/*     */       }
/*     */       
/* 220 */       if (preciseWeekendsFrom <= to) {
/*     */         try
/*     */         {
/* 223 */           List<ITimeInterval> preciseWeekends = calculatePreciseWeekendsBasedOnTicks(preciseWeekendsFrom, to);
/* 224 */           weekends.addAll(preciseWeekends);
/*     */         } catch (DataCacheException e) {
/* 226 */           LOGGER.error("Failed to calculate precise weekends, reason " + e.getLocalizedMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 231 */     if ((weekends != null) && (!weekends.isEmpty())) {
/* 232 */       this.weekendBuffer.set(weekends);
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<ITimeInterval> calculatePreciseWeekendsBasedOnTicks(long from, long to) throws DataCacheException
/*     */   {
/* 238 */     List<ITimeInterval> result = new ArrayList();
/* 239 */     List<ITimeInterval> approximateWeekends = calculateApproximateWeekends(from, to);
/*     */     
/* 241 */     for (ITimeInterval approximateWeekend : approximateWeekends)
/*     */     {
/*     */       ITimeInterval preciseWeekend;
/*     */       
/* 245 */       synchronized (this.preciseWeekendsCacheMap) {
/* 246 */         preciseWeekend = (ITimeInterval)this.preciseWeekendsCacheMap.get(approximateWeekend);
/*     */       }
/*     */       
/* 249 */       if (preciseWeekend == null) {
/* 250 */         long preciseWeekendStart = getPreciseWeekendStart(approximateWeekend);
/* 251 */         long preciseWeekendEnd = getPreciseWeekendEnd(approximateWeekend);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 256 */         if (preciseWeekendStart >= approximateWeekend.getEnd()) {
/* 257 */           preciseWeekendStart = approximateWeekend.getStart();
/*     */         }
/* 259 */         if (preciseWeekendStart >= preciseWeekendEnd) {
/* 260 */           preciseWeekendEnd = approximateWeekend.getEnd();
/*     */         }
/*     */         
/* 263 */         preciseWeekend = new TimeInterval(preciseWeekendStart, preciseWeekendEnd);
/*     */         
/* 265 */         synchronized (this.preciseWeekendsCacheMap) {
/* 266 */           this.preciseWeekendsCacheMap.put(approximateWeekend, preciseWeekend);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 271 */       result.add(preciseWeekend);
/*     */     }
/*     */     
/* 274 */     return result;
/*     */   }
/*     */   
/*     */   private long getPreciseWeekendEnd(ITimeInterval approximateWeekend) throws DataCacheException {
/* 278 */     long tickCheckIntervalStart = approximateWeekend.getEnd() - 2L * ONE_HOUR;
/* 279 */     long tickCheckIntervalEnd = approximateWeekend.getEnd() + 2L * ONE_HOUR;
/*     */     
/* 281 */     FirstTickLiveFeedListener firstTickLiveFeedListener = new FirstTickLiveFeedListener();
/*     */     
/* 283 */     this.feedDataProvider.loadTicksDataSynched(this.INSTRUMENT, tickCheckIntervalStart, tickCheckIntervalEnd, false, firstTickLiveFeedListener, new LoadingProgressAdapter() {});
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */     if (firstTickLiveFeedListener.getFirstTick() == null)
/*     */     {
/*     */ 
/*     */ 
/* 296 */       return approximateWeekend.getEnd();
/*     */     }
/*     */     
/* 299 */     return firstTickLiveFeedListener.getFirstTick().getTime();
/*     */   }
/*     */   
/*     */   private long getPreciseWeekendStart(ITimeInterval approximateWeekend) throws DataCacheException
/*     */   {
/* 304 */     long tickCheckIntervalStart = approximateWeekend.getStart() - 2L * ONE_HOUR;
/* 305 */     long tickCheckIntervalEnd = approximateWeekend.getStart() + 2L * ONE_HOUR;
/*     */     
/* 307 */     LastTickLiveFeedListener lastTickLiveFeedListener = new LastTickLiveFeedListener();
/*     */     
/* 309 */     this.feedDataProvider.loadTicksDataSynched(this.INSTRUMENT, tickCheckIntervalStart, tickCheckIntervalEnd, false, lastTickLiveFeedListener, new LoadingProgressAdapter() {});
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 318 */     if (lastTickLiveFeedListener.getLastTick() == null)
/*     */     {
/*     */ 
/*     */ 
/* 322 */       return approximateWeekend.getStart();
/*     */     }
/*     */     
/* 325 */     return lastTickLiveFeedListener.getLastTick().getTime() + 1L;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ITimeInterval> calculateApproximateWeekends(long from, long to)
/*     */   {
/* 331 */     if (from > to) {
/* 332 */       throw new IllegalArgumentException("from > to : " + DateUtils.format(from) + " > " + DateUtils.format(to));
/*     */     }
/*     */     
/* 335 */     List<ITimeInterval> result = new ArrayList();
/*     */     
/* 337 */     int sundayStart = FOREX_TIME_ZONE.inDaylightTime(new Date(from)) ? 21 : 22;
/*     */     
/*     */     long time;
/*     */     
/* 341 */     synchronized (calendarForWeekendsDetection) {
/* 342 */       calendarForWeekendsDetection.setFirstDayOfWeek(2);
/* 343 */       calendarForWeekendsDetection.setTimeInMillis(from);
/* 344 */       calendarForWeekendsDetection.set(11, sundayStart);
/* 345 */       calendarForWeekendsDetection.set(12, 0);
/* 346 */       calendarForWeekendsDetection.set(13, 0);
/* 347 */       calendarForWeekendsDetection.set(14, 0);
/* 348 */       calendarForWeekendsDetection.set(7, 1);
/* 349 */       if (calendarForWeekendsDetection.getTimeInMillis() <= from) {
/* 350 */         calendarForWeekendsDetection.add(4, 1);
/*     */       }
/*     */       
/* 353 */       calendarForWeekendsDetection.set(7, 6);
/* 354 */       calendarForWeekendsDetection.set(11, 21);
/*     */       
/* 356 */       time = calendarForWeekendsDetection.getTimeInMillis();
/*     */     }
/*     */     
/*     */ 
/* 360 */     ITimeInterval requestedTimeInterval = new TimeInterval(from, to);
/*     */     
/* 362 */     while (time <= to)
/*     */     {
/* 364 */       Object weekend = new TimeInterval();
/* 365 */       long startTime = time;
/* 366 */       if (!FOREX_TIME_ZONE.inDaylightTime(new Date(time))) {
/* 367 */         startTime += ONE_HOUR;
/*     */       }
/*     */       
/* 370 */       ((ITimeInterval)weekend).setStart(startTime);
/*     */       
/* 372 */       time += ONE_HOUR;
/* 373 */       time += TWO_DAYS;
/* 374 */       long endTime = time;
/*     */       
/* 376 */       if (FOREX_TIME_ZONE.inDaylightTime(new Date(time))) {
/* 377 */         endTime -= ONE_HOUR;
/*     */       }
/*     */       
/* 380 */       ((ITimeInterval)weekend).setEnd(endTime);
/*     */       
/* 382 */       time -= ONE_HOUR;
/*     */       
/* 384 */       if (requestedTimeInterval.intersects((ITimeInterval)weekend)) {
/* 385 */         result.add(weekend);
/*     */       }
/*     */       
/* 388 */       time += FIVE_DAYS;
/*     */     }
/*     */     
/* 391 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isFlat(CandleData candle)
/*     */   {
/* 396 */     boolean result = isFlat(candle.open, candle.close, candle.low, candle.high, candle.vol);
/* 397 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isFlat(double open, double close, double low, double high, double vol)
/*     */   {
/* 402 */     boolean result = (open == close) && (close == high) && (high == low) && (vol <= 0.0D);
/* 403 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public ITimeInterval getWeekend(long time)
/*     */   {
/*     */     ITimeInterval weekend;
/* 410 */     synchronized (this.weekendBuffer) {
/* 411 */       boolean coversTime = this.weekendBuffer.coversTime(time);
/* 412 */       if (!coversTime) {
/* 413 */         fillWeekendsBuffer(Math.min(this.weekendBuffer.getFrom(), time), Math.max(this.weekendBuffer.getTo(), time));
/*     */       }
/* 415 */       weekend = this.weekendBuffer.getWeekend(time);
/*     */     }
/*     */     
/* 418 */     if ((weekend != null) && (weekend.isInIntervalForWeekends(time))) {
/* 419 */       return weekend;
/*     */     }
/*     */     
/* 422 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchedFilter(Period period, Filter filter, CandleData candle)
/*     */   {
/* 431 */     boolean result = matchedFilter(period, filter, candle.time, candle.open, candle.close, candle.low, candle.high, candle.vol);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 441 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchedFilter(Period period, Filter filter, long time, double open, double close, double low, double high, double vol)
/*     */   {
/* 455 */     if ((filter == null) || (Filter.NO_FILTER.equals(filter))) {
/* 456 */       return true;
/*     */     }
/* 458 */     if (Filter.ALL_FLATS.equals(filter)) {
/* 459 */       boolean result = !isFlat(open, close, low, high, vol);
/* 460 */       return result;
/*     */     }
/* 462 */     if (Filter.WEEKENDS.equals(filter)) {
/* 463 */       boolean result = !isWeekendTime(time, period);
/* 464 */       return result;
/*     */     }
/*     */     
/* 467 */     throw new IllegalArgumentException("Unsupported filter - " + filter);
/*     */   }
/*     */   
/*     */ 
/*     */   public ITimeInterval[] getWeekends(long from, long to)
/*     */   {
/* 473 */     if (from > to) {
/* 474 */       throw new IllegalArgumentException("from > to : " + DateUtils.format(from) + " > " + DateUtils.format(to));
/*     */     }
/*     */     
/*     */     ITimeInterval[] rawResult;
/*     */     
/* 479 */     synchronized (this.weekendBuffer) {
/* 480 */       boolean coversInterval = this.weekendBuffer.coversInterval(from, to);
/* 481 */       if (!coversInterval) {
/* 482 */         fillWeekendsBuffer(Math.min(this.weekendBuffer.getFrom(), from), Math.max(this.weekendBuffer.getTo(), to));
/*     */       }
/* 484 */       rawResult = this.weekendBuffer.getWeekends(from, to);
/*     */     }
/*     */     
/* 487 */     ITimeInterval[] result = checkAndGetIntersections(from, to, rawResult);
/*     */     
/* 489 */     if (result == null) {
/* 490 */       result = new TimeInterval[0];
/*     */     }
/*     */     
/* 493 */     if (getServerTime() < to)
/*     */     {
/*     */ 
/* 496 */       long startFrom = from;
/* 497 */       if (result.length > 0) {
/* 498 */         long lastWeekendEnd = result[(result.length - 1)].getEnd();
/* 499 */         if (lastWeekendEnd > startFrom) {
/* 500 */           startFrom = lastWeekendEnd + TimeUnit.DAYS.toMillis(1L);
/*     */         }
/*     */       }
/*     */       
/* 504 */       if (startFrom < to) {
/* 505 */         List<ITimeInterval> futureWeekends = calculateApproximateWeekends(startFrom, to);
/* 506 */         ITimeInterval[] futureWeekendsArray = (ITimeInterval[])futureWeekends.toArray(new ITimeInterval[futureWeekends.size()]);
/*     */         
/*     */ 
/* 509 */         ITimeInterval[] extendedResult = new ITimeInterval[result.length + futureWeekends.size()];
/* 510 */         System.arraycopy(result, 0, extendedResult, 0, result.length);
/* 511 */         System.arraycopy(futureWeekendsArray, 0, extendedResult, result.length, futureWeekendsArray.length);
/*     */         
/* 513 */         result = extendedResult;
/*     */       }
/*     */     }
/*     */     
/* 517 */     return result;
/*     */   }
/*     */   
/*     */   private ITimeInterval[] checkAndGetIntersections(long from, long to, ITimeInterval[] rawResult) {
/* 521 */     if (rawResult == null) {
/* 522 */       return null;
/*     */     }
/*     */     
/* 525 */     ITimeInterval[] result = null;
/*     */     
/* 527 */     ITimeInterval targetTimeInterval = new TimeInterval(from, to);
/* 528 */     int leftIntersectionIndex = getLeftIntersectionIndex(rawResult, targetTimeInterval);
/* 529 */     if (leftIntersectionIndex > -1) {
/* 530 */       int intersectsRightIndex = getRightIntersectionIndex(rawResult, targetTimeInterval);
/* 531 */       if (intersectsRightIndex > -1) {
/* 532 */         result = new TimeInterval[intersectsRightIndex - leftIntersectionIndex + 1];
/* 533 */         System.arraycopy(rawResult, leftIntersectionIndex, result, 0, result.length);
/*     */       }
/*     */     }
/*     */     
/* 537 */     if (result == null) {
/* 538 */       result = new TimeInterval[0];
/*     */     }
/*     */     
/* 541 */     return result;
/*     */   }
/*     */   
/*     */   private int getLeftIntersectionIndex(ITimeInterval[] rawResult, ITimeInterval targetTimeInterval) {
/* 545 */     int leftIntersectionIndex = -1;
/* 546 */     for (int i = 0; i < rawResult.length; i++) {
/* 547 */       ITimeInterval ti = rawResult[i];
/* 548 */       if ((targetTimeInterval.intersects(ti)) && 
/* 549 */         (leftIntersectionIndex == -1)) {
/* 550 */         leftIntersectionIndex = i;
/* 551 */         break;
/*     */       }
/*     */     }
/*     */     
/* 555 */     return leftIntersectionIndex;
/*     */   }
/*     */   
/*     */   private int getRightIntersectionIndex(ITimeInterval[] rawResult, ITimeInterval targetTimeInterval) {
/* 559 */     int rightIntersectionIndex = -1;
/* 560 */     for (int i = rawResult.length - 1; i >= 0; i--) {
/* 561 */       ITimeInterval ti = rawResult[i];
/* 562 */       if ((targetTimeInterval.intersects(ti)) && 
/* 563 */         (rightIntersectionIndex == -1)) {
/* 564 */         rightIntersectionIndex = i;
/* 565 */         break;
/*     */       }
/*     */     }
/*     */     
/* 569 */     return rightIntersectionIndex;
/*     */   }
/*     */   
/*     */   public boolean anyWeekendsInInterval(long from, long to)
/*     */   {
/* 574 */     ITimeInterval[] weekends = getWeekends(from, to);
/* 575 */     boolean result = (weekends != null) && (weekends.length > 0);
/* 576 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isWeekendTime(long time)
/*     */   {
/* 581 */     boolean result = isWeekendTime(time, Period.TICK);
/* 582 */     return result;
/*     */   }
/*     */   
/*     */   public void preloadCache()
/*     */   {
/* 587 */     if (this.cachePreloaded) {
/* 588 */       return;
/*     */     }
/* 590 */     this.cachePreloaded = true;
/*     */     
/* 592 */     long serverTime = getServerTime();
/* 593 */     if (serverTime <= 0L) {
/* 594 */       serverTime = System.currentTimeMillis();
/*     */     }
/* 596 */     long to = serverTime;
/* 597 */     long from = to - TimeUnit.DAYS.toMillis(3660L);
/*     */     
/* 599 */     synchronized (this.weekendBuffer) {
/* 600 */       boolean coversTime = this.weekendBuffer.coversInterval(from, to);
/* 601 */       if (!coversTime) {
/* 602 */         fillWeekendsBuffer(from, to);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected long getServerTime() {
/* 608 */     Long serverTime = this.feedDataProvider.getTimeManager().getServerTime();
/* 609 */     if (serverTime != null) {
/* 610 */       return serverTime.longValue();
/*     */     }
/* 612 */     return this.feedDataProvider.getEstimatedServerOrLocalTime();
/*     */   }
/*     */   
/*     */   public static TimeZone getJForexTimeZone() {
/* 616 */     return FOREX_TIME_ZONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\filtering\FilterManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */