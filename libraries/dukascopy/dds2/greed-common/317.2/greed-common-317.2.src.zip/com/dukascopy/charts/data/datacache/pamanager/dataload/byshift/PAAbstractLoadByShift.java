/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.byshift;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.PANthBarLiveFeedListenerWrapper;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PAAbstractLoadClosestAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PAAbstractLoadToCacheAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PAAbstractNthBarFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PAAbstractLoadByTimeIntervalAction;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationCreator;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationLiveFeedListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PAAbstractLoadByShift<D extends AbstractPriceAggregationData, L extends IPriceAggregationLiveFeedListener<D>, K extends IPriceAggregationCreator<D, TickData, L>, PC extends PAAbstractLoadToCacheAction<D, L, K>, PT extends PAAbstractLoadByTimeIntervalAction<D, L, K, PC>, PCL extends PAAbstractLoadClosestAction<D, L, K, PC, PT>, PNTH extends PAAbstractNthBarFromSeedBarAction<D, L, K, PC, PANthBarLiveFeedListenerWrapper<D>>>
/*     */   implements Runnable
/*     */ {
/*  47 */   private static final Logger LOGGER = LoggerFactory.getLogger(PAAbstractLoadByShift.class);
/*     */   
/*     */ 
/*     */   private IPACacheManager cacheManager;
/*     */   
/*     */   private Instrument instrument;
/*     */   
/*     */   private DataInterpolationDescriptor interpolationDescriptor;
/*     */   
/*     */   private OfferSide side;
/*     */   
/*     */   private JForexPeriod jfPeriod;
/*     */   
/*     */   private int shift;
/*     */   
/*     */   private boolean fireUncompletedLastBasePeriodBars;
/*     */   
/*     */   private boolean infinitBasePeriod;
/*     */   
/*     */   private L listener;
/*     */   
/*     */   private ILoadingProgressListener loadingProgressListener;
/*     */   
/*     */   private int version;
/*     */   
/*     */ 
/*     */   public PAAbstractLoadByShift(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int shift, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, L listener, ILoadingProgressListener loadingProgressListener)
/*     */   {
/*  75 */     this.cacheManager = cacheManager;
/*  76 */     this.instrument = instrument;
/*  77 */     this.interpolationDescriptor = interpolationDescriptor;
/*  78 */     this.side = side;
/*  79 */     this.jfPeriod = jfPeriod;
/*  80 */     this.shift = shift;
/*  81 */     this.fireUncompletedLastBasePeriodBars = fireUncompletedLastBasePeriodBars;
/*  82 */     this.infinitBasePeriod = infinitBasePeriod;
/*  83 */     this.version = version;
/*  84 */     this.listener = listener;
/*  85 */     this.loadingProgressListener = loadingProgressListener;
/*     */   }
/*     */   
/*     */   protected abstract D getInProgressBar();
/*     */   
/*     */   protected abstract PCL createLoadClosestAction(long paramLong, L paramL)
/*     */     throws DataCacheException;
/*     */   
/*     */   protected abstract L createLiveFeedListener(List<D> paramList);
/*     */   
/*     */   protected abstract PNTH createLoadNthAction(int paramInt1, D paramD, int paramInt2, boolean paramBoolean, L paramL);
/*     */   
/*     */   public void run()
/*     */   {
/*  99 */     D inProgressBar = getInProgressBar();
/* 100 */     if (this.shift == 0) {
/* 101 */       this.listener.newPriceData(inProgressBar);
/* 102 */       if (this.loadingProgressListener != null) {
/* 103 */         long inProgrTime = inProgressBar == null ? this.cacheManager.getFeedDataProvider().getCurrentTime() : inProgressBar.getTime();
/* 104 */         this.loadingProgressListener.loadingFinished(true, inProgrTime, inProgrTime, 0L, null);
/*     */       }
/* 106 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 111 */       long currentTime = this.cacheManager.getFeedDataProvider().getCurrentTime();
/*     */       
/* 113 */       List<D> lastCompletedBarList = new ArrayList();
/* 114 */       L lastCompletedBarListener = createLiveFeedListener(lastCompletedBarList);
/*     */       
/*     */ 
/* 117 */       PCL loadClosestAction = createLoadClosestAction(currentTime, lastCompletedBarListener);
/* 118 */       loadClosestAction.run();
/*     */       
/* 120 */       if (!lastCompletedBarList.isEmpty()) {
/* 121 */         createLoadNthAction(this.shift, (AbstractPriceAggregationData)lastCompletedBarList.get(0), 0, true, this.listener).run();
/*     */       }
/*     */     }
/*     */     catch (DataCacheException e) {
/* 125 */       LOGGER.error(e.getMessage(), e);
/* 126 */       if (this.loadingProgressListener != null) {
/* 127 */         long inProgrTime = inProgressBar == null ? this.cacheManager.getFeedDataProvider().getCurrentTime() : inProgressBar.getTime();
/* 128 */         this.loadingProgressListener.loadingFinished(true, inProgrTime, inProgrTime, 0L, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public IPACacheManager getCacheManager()
/*     */   {
/* 135 */     return this.cacheManager;
/*     */   }
/*     */   
/* 138 */   public Instrument getInstrument() { return this.instrument; }
/*     */   
/*     */   public DataInterpolationDescriptor getInterpolationDescriptor() {
/* 141 */     return this.interpolationDescriptor;
/*     */   }
/*     */   
/* 144 */   public OfferSide getSide() { return this.side; }
/*     */   
/*     */   public JForexPeriod getJfPeriod() {
/* 147 */     return this.jfPeriod;
/*     */   }
/*     */   
/* 150 */   public boolean isFireUncompletedLastBasePeriodBars() { return this.fireUncompletedLastBasePeriodBars; }
/*     */   
/*     */   public boolean isInfinitBasePeriod() {
/* 153 */     return this.infinitBasePeriod;
/*     */   }
/*     */   
/* 156 */   public ILoadingProgressListener getLoadingProgressListener() { return this.loadingProgressListener; }
/*     */   
/*     */   public int getVersion() {
/* 159 */     return this.version;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\byshift\PAAbstractLoadByShift.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */