/*    */ package com.dukascopy.charts.data.datacache.ccheck;
/*    */ 
/*    */ import com.dukascopy.api.feed.IFeedDescriptor;
/*    */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*    */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*    */ import com.dukascopy.charts.data.datacache.MergedTimeIntervalList;
/*    */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*    */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PADataChangeAction;
/*    */ import com.dukascopy.charts.data.datacache.wrapper.TimeInterval;
/*    */ import java.io.File;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MFEntryProcessingAction
/*    */   implements Runnable
/*    */ {
/* 29 */   private static final Logger LOGGER = LoggerFactory.getLogger(MFEntryProcessingAction.class);
/*    */   private MissingFileEntryManager manager;
/*    */   private IPACacheManager paManager;
/*    */   private long maxWaitTime;
/*    */   
/*    */   public MFEntryProcessingAction(MissingFileEntryManager manager, IPACacheManager paManager)
/*    */   {
/* 36 */     this.manager = manager;
/* 37 */     this.paManager = paManager;
/* 38 */     this.maxWaitTime = 600000L;
/*    */   }
/*    */   
/*    */ 
/*    */   public void run()
/*    */   {
/* 44 */     long requestStartTime = System.currentTimeMillis();
/* 45 */     boolean gotLock = false;
/*    */     
/* 47 */     Map<IFeedDescriptor, MergedTimeIntervalList> intervalsMap = new HashMap();
/*    */     
/*    */     try
/*    */     {
/* 51 */       while ((!(gotLock = this.manager.requestGlobalLock())) && (System.currentTimeMillis() - requestStartTime < this.maxWaitTime)) {
/* 52 */         Thread.sleep(100L);
/*    */       }
/*    */       
/* 55 */       if (!gotLock) {
/* 56 */         LOGGER.warn("couldn't get lock on mffolder within " + this.maxWaitTime / 1000L / 60L + " minutes!"); return;
/*    */       }
/*    */       
/*    */ 
/* 60 */       File[] mffiles = this.manager.getMFFolderFiles();
/* 61 */       for (File entryFile : mffiles) {
/* 62 */         this.manager.deleteMFEntriesAndChunks(entryFile, intervalsMap);
/*    */       }
/*    */       
/*    */ 
/*    */     }
/*    */     catch (InterruptedException e) {}finally
/*    */     {
/* 69 */       if (gotLock) {
/* 70 */         this.manager.releaseGlobalLock();
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 75 */     for (Iterator i$ = intervalsMap.entrySet().iterator(); i$.hasNext();) { entry = (Map.Entry)i$.next();
/* 76 */       for (TimeInterval interval : ((MergedTimeIntervalList)entry.getValue()).getList()) {
/*    */         try {
/* 78 */           PADataChangeAction paChangeAction = new PADataChangeAction(this.paManager, (IFeedDescriptor)entry.getKey(), interval.getStart(), interval.getEnd(), new LoadingProgressAdapter() {});
/* 79 */           paChangeAction.run();
/*    */         } catch (DataCacheException e) {
/* 81 */           LOGGER.error(e.getMessage(), e);
/*    */         }
/*    */       }
/*    */     }
/*    */     Map.Entry<IFeedDescriptor, MergedTimeIntervalList> entry;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFEntryProcessingAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */