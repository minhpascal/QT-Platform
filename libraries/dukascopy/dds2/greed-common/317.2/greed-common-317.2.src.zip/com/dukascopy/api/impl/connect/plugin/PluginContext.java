/*     */ package com.dukascopy.api.impl.connect.plugin;
/*     */ 
/*     */ import com.dukascopy.api.IClientGUIListener;
/*     */ import com.dukascopy.api.IConsole;
/*     */ import com.dukascopy.api.IEngine;
/*     */ import com.dukascopy.api.IUserInterface;
/*     */ import com.dukascopy.api.impl.History;
/*     */ import com.dukascopy.api.impl.connect.JFRunnableProcessor;
/*     */ import com.dukascopy.api.impl.connect.JForexContextImpl;
/*     */ import com.dukascopy.api.impl.connect.strategy.StrategyManagerWrapper;
/*     */ import com.dukascopy.api.impl.connect.strategy.local.LocalStrategyManagerWrapper;
/*     */ import com.dukascopy.api.impl.connect.strategy.remote.RemoteStrategyManager;
/*     */ import com.dukascopy.api.impl.connect.strategy.remote.RemoteStrategyManagerWrapper;
/*     */ import com.dukascopy.api.plugins.IMessageListener;
/*     */ import com.dukascopy.api.plugins.IPluginContext;
/*     */ import com.dukascopy.api.plugins.PluginGuiListener;
/*     */ import com.dukascopy.api.plugins.menu.IPluginMenu;
/*     */ import com.dukascopy.api.plugins.widget.IPluginWidget;
/*     */ import com.dukascopy.api.plugins.widget.PluginWidgetListener;
/*     */ import com.dukascopy.api.plugins.widget.WidgetProperties;
/*     */ import com.dukascopy.api.strategy.local.ILocalStrategyManager;
/*     */ import com.dukascopy.api.strategy.remote.IRemoteStrategyManager;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ContainerEvent;
/*     */ import java.awt.event.ContainerListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class PluginContext extends JForexContextImpl<IPluginUserInterface> implements IPluginContext
/*     */ {
/*  36 */   private Map<IPluginWidget, String> pluginMap = new HashMap();
/*  37 */   private Map<IPluginMenu, String> menus = new HashMap();
/*  38 */   private Map<PluginWidgetListener, ContainerListener> listenerMap = new HashMap();
/*     */   
/*     */   private final boolean autoTradingAllowed;
/*     */   
/*     */   private final PluginGuiListener guiListener;
/*     */   private final ILocalStrategyManager localStrategyManager;
/*     */   private final IRemoteStrategyManager remoteStrategyManager;
/*     */   
/*     */   public PluginContext(JFRunnableProcessor<?, ?> jfRunnableProcessor, IEngine forexEngineImpl, History history, IConsole console, DDSChartsController chartsController, IPluginUserInterface userInterface, IClientGUIListener clientGUIListener, Properties serverProperties, PluginGuiListener guiListener, boolean autoTradingAllowed, ILocalStrategyManager localStrategyManager)
/*     */   {
/*  48 */     super(jfRunnableProcessor, forexEngineImpl, history, console, chartsController, userInterface, clientGUIListener, serverProperties);
/*  49 */     this.guiListener = guiListener;
/*  50 */     this.autoTradingAllowed = autoTradingAllowed;
/*  51 */     this.localStrategyManager = new LocalStrategyManagerWrapper(localStrategyManager);
/*  52 */     this.remoteStrategyManager = new RemoteStrategyManagerWrapper(RemoteStrategyManager.getInstance());
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  56 */     ((StrategyManagerWrapper)this.localStrategyManager).removeAllListeners();
/*  57 */     ((StrategyManagerWrapper)this.remoteStrategyManager).removeAllListeners();
/*     */   }
/*     */   
/*     */   public IPluginWidget addWidget(String name)
/*     */   {
/*  62 */     final JPanel panel = ((IPluginUserInterface)this.userInterface).getBottomTab(name);
/*  63 */     IPluginWidget pluginWidget = new IPluginWidget()
/*     */     {
/*     */       public JPanel getContentPanel()
/*     */       {
/*  67 */         return panel;
/*     */       }
/*     */       
/*     */       public void addPluginWidgetListener(final PluginWidgetListener listener)
/*     */       {
/*  72 */         if (PluginContext.this.guiListener != null) {
/*  73 */           PluginContext.this.guiListener.onWidgetListenerAdd(listener);
/*  74 */           return;
/*     */         }
/*     */         
/*  77 */         ContainerListener containerListener = new ContainerListener()
/*     */         {
/*     */           public void componentAdded(ContainerEvent e) {}
/*     */           
/*     */ 
/*     */ 
/*     */           public void componentRemoved(ContainerEvent e)
/*     */           {
/*  85 */             listener.onWidgetClose();
/*     */           }
/*  87 */         };
/*  88 */         PluginContext.this.listenerMap.put(listener, containerListener);
/*  89 */         panel.getParent().addContainerListener(containerListener);
/*     */       }
/*     */       
/*     */ 
/*     */       public void removePluginWidgetListener(PluginWidgetListener listener)
/*     */       {
/*  95 */         if (PluginContext.this.guiListener != null) {
/*  96 */           PluginContext.this.guiListener.onWidgetListenerAdd(listener);
/*  97 */           return;
/*     */         }
/*     */         
/* 100 */         ContainerListener containerListener = (ContainerListener)PluginContext.this.listenerMap.get(listener);
/* 101 */         if (containerListener == null) {
/* 102 */           return;
/*     */         }
/* 104 */         panel.getParent().removeContainerListener(containerListener);
/* 105 */         PluginContext.this.listenerMap.remove(listener);
/*     */       }
/*     */     };
/*     */     
/* 109 */     if (this.guiListener != null) {
/* 110 */       this.guiListener.onWidgetAdd(pluginWidget);
/*     */     }
/* 112 */     this.pluginMap.put(pluginWidget, name);
/* 113 */     return pluginWidget;
/*     */   }
/*     */   
/*     */ 
/*     */   public IPluginWidget addWidget(String name, WidgetProperties widgetProperties)
/*     */   {
/* 119 */     return addWidget(name);
/*     */   }
/*     */   
/*     */   public void removeWidget(IPluginWidget pluginWidget)
/*     */   {
/* 124 */     getUserInterface().removeBottomTab((String)this.pluginMap.get(pluginWidget));
/* 125 */     if (this.guiListener != null) {
/* 126 */       this.guiListener.onWidgetRemove(pluginWidget);
/*     */     }
/* 128 */     this.pluginMap.remove(pluginWidget);
/*     */   }
/*     */   
/*     */   public boolean isAutoTradingAllowed()
/*     */   {
/* 133 */     return this.autoTradingAllowed;
/*     */   }
/*     */   
/*     */   public Set<IPluginWidget> getWidgets()
/*     */   {
/* 138 */     return this.pluginMap.keySet();
/*     */   }
/*     */   
/*     */   public void subscribeToMessages(IMessageListener messageListener)
/*     */   {
/* 143 */     this.jfRunnableProcessor.setMessageListener(messageListener);
/*     */   }
/*     */   
/*     */   public IPluginMenu addMenu(String name)
/*     */   {
/* 148 */     final JMenu menu = ((IPluginUserInterface)this.userInterface).addMenu(name);
/* 149 */     IPluginMenu pluginMenu = new IPluginMenu()
/*     */     {
/*     */       public JMenu getMenu()
/*     */       {
/* 153 */         return menu;
/*     */       }
/*     */     };
/* 156 */     if (this.guiListener != null) {
/* 157 */       this.guiListener.onMenuAdd(pluginMenu);
/*     */     }
/* 159 */     this.menus.put(pluginMenu, name);
/* 160 */     return pluginMenu;
/*     */   }
/*     */   
/*     */   public void removeMenu(IPluginMenu pluginMenu)
/*     */   {
/* 165 */     ((IPluginUserInterface)this.userInterface).removeMenu(pluginMenu.getMenu());
/* 166 */     if (this.guiListener != null) {
/* 167 */       this.guiListener.onMenuRemove(pluginMenu);
/*     */     }
/* 169 */     this.menus.remove(pluginMenu);
/*     */   }
/*     */   
/*     */   public Set<IPluginMenu> getMenus()
/*     */   {
/* 174 */     return this.menus.keySet();
/*     */   }
/*     */   
/*     */   public IRemoteStrategyManager getRemoteStrategyManager()
/*     */   {
/* 179 */     return this.remoteStrategyManager;
/*     */   }
/*     */   
/*     */   public ILocalStrategyManager getLocalStrategyManager()
/*     */   {
/* 184 */     return this.localStrategyManager;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\plugin\PluginContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */