/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IContext;
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskStart<CONTEXT extends IContext>
/*    */   implements Task<Void>
/*    */ {
/* 15 */   private CONTEXT context = null;
/* 16 */   private IJFRunnable<CONTEXT> strategy = null;
/*    */   
/* 18 */   public TaskStart(CONTEXT context, IJFRunnable<CONTEXT> strategy) { this.context = context;
/* 19 */     this.strategy = strategy;
/*    */   }
/*    */   
/*    */   public Task.Type getType() {
/* 23 */     return Task.Type.START;
/*    */   }
/*    */   
/*    */   public Void call() throws Exception {
/* 27 */     this.strategy.onStart(this.context);
/* 28 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskStart.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */