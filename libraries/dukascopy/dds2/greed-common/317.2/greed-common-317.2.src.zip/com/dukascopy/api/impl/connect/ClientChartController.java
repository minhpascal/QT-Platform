/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IChart.Type;
/*     */ import com.dukascopy.api.IClientChartController;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import com.dukascopy.charts.utils.ChartUtils;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientChartController
/*     */   implements IClientChartController
/*     */ {
/*     */   private final JPanel chartPanel;
/*     */   protected final int chartPanelId;
/*     */   protected final DDSChartsController ddsChartsController;
/*     */   
/*     */   public ClientChartController(DDSChartsController ddsChartsController, int chartPanelId)
/*     */   {
/*  32 */     this.ddsChartsController = ddsChartsController;
/*  33 */     this.chartPanelId = chartPanelId;
/*  34 */     this.chartPanel = ddsChartsController.getChartPanel(Integer.valueOf(chartPanelId));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIndicators()
/*     */   {
/*  42 */     if (isValid()) {
/*  43 */       this.ddsChartsController.createAddEditIndicatorsDialog(this.chartPanelId);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activatePriceMarker()
/*     */   {
/*  52 */     if (isValid()) {
/*  53 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.PRICEMARKER);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateTimeMarker()
/*     */   {
/*  62 */     if (isValid()) {
/*  63 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.TIMEMARKER);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activatePercentLines()
/*     */   {
/*  72 */     if (isValid()) {
/*  73 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.PERCENT);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateChannelLines()
/*     */   {
/*  82 */     if (isValid()) {
/*  83 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.CHANNEL);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activatePolyLine()
/*     */   {
/*  92 */     if (isValid()) {
/*  93 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.POLY_LINE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateShortLine()
/*     */   {
/* 102 */     if (isValid()) {
/* 103 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.SHORT_LINE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateLongLine()
/*     */   {
/* 112 */     if (isValid()) {
/* 113 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.LONG_LINE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateRayLine()
/*     */   {
/* 122 */     if (isValid()) {
/* 123 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.RAY_LINE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateHorizontalLine()
/*     */   {
/* 132 */     if (isValid()) {
/* 133 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.HLINE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateVerticalLine()
/*     */   {
/* 142 */     if (isValid()) {
/* 143 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.VLINE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void activateTextMode()
/*     */   {
/* 152 */     if (isValid()) {
/* 153 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.TEXT);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addOHLCInformer()
/*     */   {
/* 162 */     if (isValid()) {
/* 163 */       this.ddsChartsController.startDrawing(Integer.valueOf(this.chartPanelId), IChart.Type.OHLC_INFORMER);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCursorPointer(boolean show)
/*     */   {
/* 172 */     if (isValid()) {
/* 173 */       this.ddsChartsController.switchMouseCursor(Integer.valueOf(this.chartPanelId), show);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMouseListener(MouseListener ml)
/*     */   {
/* 182 */     if (isValid()) {
/* 183 */       Component mainChartPanel = getMainChartPanel();
/* 184 */       if (mainChartPanel != null) {
/* 185 */         mainChartPanel.addMouseListener(ml);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMouseMotionListener(MouseMotionListener mml)
/*     */   {
/* 195 */     if (isValid()) {
/* 196 */       Component mainChartPanel = getMainChartPanel();
/* 197 */       if (mainChartPanel != null) {
/* 198 */         mainChartPanel.addMouseMotionListener(mml);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMouseWheelListener(MouseWheelListener mwl)
/*     */   {
/* 208 */     if (isValid()) {
/* 209 */       Component mainChartPanel = getMainChartPanel();
/* 210 */       if (mainChartPanel != null) {
/* 211 */         mainChartPanel.addMouseWheelListener(mwl);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMouseListener(MouseListener ml)
/*     */   {
/* 221 */     if (isValid()) {
/* 222 */       Component mainChartPanel = getMainChartPanel();
/* 223 */       if (mainChartPanel != null) {
/* 224 */         mainChartPanel.removeMouseListener(ml);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMouseMotionListener(MouseMotionListener mml)
/*     */   {
/* 234 */     if (isValid()) {
/* 235 */       Component mainChartPanel = getMainChartPanel();
/* 236 */       if (mainChartPanel != null) {
/* 237 */         mainChartPanel.removeMouseMotionListener(mml);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMouseWheelListener(MouseWheelListener mwl)
/*     */   {
/* 247 */     if (isValid()) {
/* 248 */       Component mainChartPanel = getMainChartPanel();
/* 249 */       if (mainChartPanel != null) {
/* 250 */         mainChartPanel.removeMouseWheelListener(mwl);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isValid() {
/* 256 */     boolean valid = false;
/* 257 */     if ((this.ddsChartsController != null) && (this.chartPanelId != -1)) {
/* 258 */       valid = true;
/*     */     }
/* 260 */     return valid;
/*     */   }
/*     */   
/*     */   private Component getMainChartPanel() {
/* 264 */     return ChartUtils.findComponentByName(this.chartPanel, "MainChartPanel");
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ClientChartController.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */