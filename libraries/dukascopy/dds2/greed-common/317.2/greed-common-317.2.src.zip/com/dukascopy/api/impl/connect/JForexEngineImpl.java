/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.IEngine;
/*     */ import com.dukascopy.api.IEngine.OrderCommand;
/*     */ import com.dukascopy.api.IEngine.RunMode;
/*     */ import com.dukascopy.api.IEngine.StrategyMode;
/*     */ import com.dukascopy.api.IEngine.Type;
/*     */ import com.dukascopy.api.IMessage.Type;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.impl.connect.validation.IOrderValidator;
/*     */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*     */ import com.dukascopy.dds4.transport.client.TransportClient;
/*     */ import com.dukascopy.dds4.transport.msg.system.ErrorResponseMessage;
/*     */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*     */ import com.dukascopy.jss.IJssManager;
/*     */ import com.dukascopy.jss.JssException;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class JForexEngineImpl extends com.dukascopy.api.impl.AbstractEngine implements IEngine
/*     */ {
/*  44 */   private static final Logger LOGGER = LoggerFactory.getLogger(JForexEngineImpl.class);
/*     */   
/*     */   static final double DEFAULT_SLIPPAGE = 5.0D;
/*     */   
/*  48 */   private IEngine.Type myType = IEngine.Type.DEMO;
/*     */   
/*     */   private final JForexTaskManager<?, ?, ?> taskManager;
/*  51 */   private String accountName = null;
/*     */   
/*     */   public JForexEngineImpl(JForexTaskManager<?, ?, ?> taskManager, String accountName, boolean live) {
/*  54 */     if (live) {
/*  55 */       this.myType = IEngine.Type.LIVE;
/*     */     }
/*  57 */     this.taskManager = taskManager;
/*  58 */     this.accountName = accountName;
/*     */   }
/*     */   
/*     */   public IOrder getOrder(String label) throws JFException
/*     */   {
/*  63 */     List<IOrder> allOrders = getOrders();
/*  64 */     IOrder rc = null;
/*  65 */     for (IOrder order : allOrders) {
/*  66 */       if ((order.getLabel() != null) && (order.getLabel().equals(label))) {
/*  67 */         rc = order;
/*  68 */         break;
/*     */       }
/*     */     }
/*  71 */     return rc;
/*     */   }
/*     */   
/*     */   public List<IOrder> getOrders(Instrument instrument) throws JFException
/*     */   {
/*  76 */     List<IOrder> rc = new ArrayList();
/*  77 */     for (IOrder order : getOrders()) {
/*  78 */       if (instrument == order.getInstrument()) {
/*  79 */         rc.add(order);
/*     */       }
/*     */     }
/*  82 */     return rc;
/*     */   }
/*     */   
/*     */   public List<IOrder> getOrders() throws JFException
/*     */   {
/*  87 */     return this.taskManager.getOrdersInternalCollection().allAsOrders();
/*     */   }
/*     */   
/*     */   public IEngine.Type getType()
/*     */   {
/*  92 */     return this.myType;
/*     */   }
/*     */   
/*     */ 
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice, long goodTillTime, String comment)
/*     */     throws JFException
/*     */   {
/*  99 */     FeedDataProvider feedDataProvider = FeedDataProvider.getDefaultInstance();
/* 100 */     label = getOrderValidator().validateOrderParameters(label, this.taskManager.isGlobal(), instrument, getAccountCurrency(), orderCommand, amount, price, stopLossPrice, takeProfitPrice, goodTillTime, feedDataProvider);
/* 101 */     comment = getOrderValidator().validateComment(comment);
/*     */     
/* 103 */     price = StratUtils.round(price, 7);
/*     */     
/*     */ 
/* 106 */     amount = StratUtils.round(amount, 6);
/*     */     
/* 108 */     stopLossPrice = StratUtils.round(stopLossPrice, 7);
/*     */     
/* 110 */     takeProfitPrice = StratUtils.round(takeProfitPrice, 7);
/*     */     
/*     */ 
/* 113 */     if (!Double.isNaN(slippage)) {
/* 114 */       if (slippage < 0.0D) {
/* 115 */         slippage = 5.0D;
/*     */       }
/*     */       
/* 118 */       slippage = StratUtils.round(slippage * instrument.getPipValue(), 7);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 123 */     PlatformOrderImpl order = new PlatformOrderImpl(this.taskManager);
/* 124 */     order.lastServerRequest = PlatformOrderImpl.ServerRequest.SUBMIT;
/* 125 */     order.label = label;
/* 126 */     order.requestedAmount = amount;
/* 127 */     order.setOriginalAmount(amount);
/* 128 */     order.comment = comment;
/* 129 */     order.slPrice = stopLossPrice;
/* 130 */     order.tpPrice = takeProfitPrice;
/* 131 */     order.openPrice = price;
/* 132 */     order.instrument = instrument;
/* 133 */     if (goodTillTime > 0L) {
/* 134 */       order.goodTillTime = goodTillTime;
/*     */     }
/* 136 */     order.orderCommand = orderCommand;
/*     */     
/* 138 */     if (order.slPrice > 0.0D) {
/* 139 */       order.slSide = (orderCommand.isLong() ? OfferSide.BID : OfferSide.ASK);
/*     */     }
/*     */     
/*     */ 
/* 143 */     this.taskManager.getOrdersInternalCollection().put(label, order, true);
/*     */     
/* 145 */     if (!this.taskManager.isConnected())
/*     */     {
/*     */ 
/* 148 */       String content = String.format(generateSubmitRejectFormat(order), new Object[] { "disconnect" });
/* 149 */       LOGGER.warn(content);
/* 150 */       ErrorResponseMessage error = new ErrorResponseMessage(content);
/* 151 */       this.taskManager.onErrorMessage(error, order);
/* 152 */       return order;
/*     */     }
/* 154 */     String strategyName = this.taskManager.getJFRunnableName();
/* 155 */     boolean local = this.taskManager.getEnvironment() != JForexTaskManager.Environment.REMOTE;
/* 156 */     BigDecimal usableMargin = this.taskManager.getUsableMargin();
/* 157 */     if ((usableMargin != null) && (usableMargin.compareTo(BigDecimal.ZERO) < 0))
/*     */     {
/* 159 */       if (!orderCommand.isConditional())
/*     */       {
/* 161 */         if (this.taskManager.getOrdersInternalCollection().isLongExposure(instrument) == orderCommand.isLong())
/*     */         {
/*     */ 
/* 164 */           String content = String.format(generateSubmitRejectFormat(order), new Object[] { "no margin available" });
/* 165 */           LOGGER.warn(content);
/*     */           
/*     */ 
/* 168 */           String message = generateNotificationMessage(order, strategyName, slippage, local);
/* 169 */           NotificationUtilsProvider.getNotificationUtils().postInfoMessage(message);
/* 170 */           NotificationUtilsProvider.getNotificationUtils().postInfoMessage(content, false);
/*     */           
/* 172 */           ErrorResponseMessage error = new ErrorResponseMessage(content);
/* 173 */           this.taskManager.onErrorMessage(error, order);
/* 174 */           return order;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 179 */     String warning = getOrderValidator().validateOrder(order);
/* 180 */     if (!ObjectUtils.isNullOrEmpty(warning)) {
/* 181 */       String content = String.format(generateSubmitRejectFormat(order), new Object[] { warning });
/* 182 */       LOGGER.warn(content);
/* 183 */       NotificationUtilsProvider.getNotificationUtils().postWarningMessage(content, true);
/* 184 */       ErrorResponseMessage error = new ErrorResponseMessage(content);
/* 185 */       this.taskManager.onErrorMessage(error, order);
/* 186 */       return order;
/*     */     }
/*     */     
/*     */ 
/* 190 */     if (JForexAPI.isPlaceBidOffer(orderCommand))
/*     */     {
/* 192 */       if (feedDataProvider.getFeedCommissionManager().hasCommission(instrument)) {
/* 193 */         warning = generateFeedCommissionWarning(instrument);
/* 194 */         LOGGER.warn(warning);
/* 195 */         NotificationUtilsProvider.getNotificationUtils().postWarningMessage(warning);
/* 196 */         ErrorResponseMessage error = new ErrorResponseMessage(warning);
/* 197 */         this.taskManager.onErrorMessage(error, order);
/* 198 */         return order;
/*     */       }
/* 200 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*     */       
/* 202 */       OrderGroupMessage ogm = JForexAPI.placeBidOffer(this.taskManager, label, instrument, orderCommand, amount, price, stopLossPrice, takeProfitPrice, goodTillTime, comment);
/*     */       
/*     */ 
/*     */ 
/* 206 */       if (LOGGER.isDebugEnabled()) {
/* 207 */         LOGGER.debug("Submitting bid/offer order [" + ogm + "]");
/*     */       }
/* 209 */       ProtocolMessage submitResult = transportClient.controlRequest(ogm);
/*     */       
/*     */ 
/* 212 */       if ((submitResult instanceof ErrorResponseMessage)) {
/* 213 */         ErrorResponseMessage error = (ErrorResponseMessage)submitResult;
/* 214 */         this.taskManager.onErrorMessage(error, order);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 220 */       TransportClient transportClient = this.taskManager.getTransportClient();
/*     */       OrderGroupMessage ogm;
/*     */       try {
/* 223 */         ogm = JForexAPI.submitOrder(this.taskManager, label, instrument, orderCommand, amount, price, slippage, stopLossPrice, takeProfitPrice, goodTillTime, comment);
/*     */       }
/*     */       catch (IllegalStateException e) {
/* 226 */         throw new JFException(e.getMessage(), e);
/*     */       }
/* 228 */       if (LOGGER.isDebugEnabled()) {
/* 229 */         LOGGER.debug("Submitting order [" + ogm + "]");
/*     */       }
/* 231 */       ProtocolMessage submitResult = transportClient.controlRequest(ogm);
/* 232 */       if ((submitResult instanceof ErrorResponseMessage)) {
/* 233 */         ErrorResponseMessage error = (ErrorResponseMessage)submitResult;
/* 234 */         this.taskManager.onErrorMessage(error, order);
/*     */       }
/*     */     }
/* 237 */     String message = generateNotificationMessage(order, strategyName, slippage, local);
/* 238 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(message);
/*     */     
/* 240 */     return order;
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice, long goodTillTime)
/*     */     throws JFException
/*     */   {
/* 246 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage, stopLossPrice, takeProfitPrice, goodTillTime, null);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice) throws JFException
/*     */   {
/* 251 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage, stopLossPrice, takeProfitPrice, 0L);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage) throws JFException
/*     */   {
/* 256 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage, 0.0D, 0.0D);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price) throws JFException
/*     */   {
/* 261 */     double slippage = 5.0D;
/*     */     
/* 263 */     if ((orderCommand != null) && ((orderCommand == IEngine.OrderCommand.BUYLIMIT) || (orderCommand == IEngine.OrderCommand.BUYLIMIT_BYBID) || (orderCommand == IEngine.OrderCommand.SELLLIMIT) || (orderCommand == IEngine.OrderCommand.SELLLIMIT_BYASK))) {
/* 264 */       slippage = 0.0D;
/*     */     }
/* 266 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount) throws JFException
/*     */   {
/* 271 */     return submitOrder(label, instrument, orderCommand, amount, 0.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PlatformOrderImpl getOrderById(String positionId)
/*     */   {
/* 278 */     return this.taskManager.getOrdersInternalCollection().getOrderById(positionId);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 283 */     return "Platform engine";
/*     */   }
/*     */   
/*     */   public String getAccount()
/*     */   {
/* 288 */     return this.accountName;
/*     */   }
/*     */   
/*     */   public void mergeOrders(IOrder... orders) throws JFException
/*     */   {
/* 293 */     NotificationUtilsProvider.getNotificationUtils().postWarningMessage("mergeOrders method is deprecated and will be removed later, please use method with label parameter instead", true);
/* 294 */     mergeOrders(null, null, Arrays.asList(orders));
/*     */   }
/*     */   
/*     */   public IOrder mergeOrders(String label, IOrder... orders) throws JFException
/*     */   {
/* 299 */     return mergeOrders(label, null, Arrays.asList(orders));
/*     */   }
/*     */   
/*     */   public IOrder mergeOrders(String label, String comment, IOrder... orders) throws JFException
/*     */   {
/* 304 */     return mergeOrders(label, comment, Arrays.asList(orders));
/*     */   }
/*     */   
/*     */   public IOrder mergeOrders(String label, Collection<IOrder> orders) throws JFException
/*     */   {
/* 309 */     return mergeOrders(label, null, orders);
/*     */   }
/*     */   
/*     */   public IOrder mergeOrders(String label, String comment, Collection<IOrder> orders) throws JFException
/*     */   {
/* 314 */     label = getOrderValidator().validateMergeOrders(label, this.taskManager.isGlobal(), orders);
/* 315 */     comment = getOrderValidator().validateComment(comment);
/*     */     
/* 317 */     Set<String> mergeOrderGroupIdList = new java.util.HashSet(orders.size());
/* 318 */     Instrument instrument = null;
/* 319 */     for (IOrder order : orders) {
/* 320 */       PlatformOrderImpl platformOrder = (PlatformOrderImpl)order;
/* 321 */       mergeOrderGroupIdList.add(platformOrder.groupId);
/* 322 */       if (instrument == null) {
/* 323 */         instrument = order.getInstrument();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 328 */     PlatformOrderImpl order = new PlatformOrderImpl(this.taskManager);
/* 329 */     order.label = label;
/* 330 */     order.comment = comment;
/* 331 */     order.instrument = instrument;
/* 332 */     order.setLastServerRequest(PlatformOrderImpl.ServerRequest.MERGE_TARGET);
/*     */     
/* 334 */     this.taskManager.getOrdersInternalCollection().put(label, order, true);
/*     */     
/* 336 */     TransportClient transportClient = this.taskManager.getTransportClient();
/* 337 */     MergePositionsMessage mpm = JForexAPI.merge(this.taskManager, label, mergeOrderGroupIdList);
/* 338 */     if (LOGGER.isDebugEnabled()) {
/* 339 */       LOGGER.debug("Sending merge request [" + mpm + "]");
/*     */     }
/* 341 */     ProtocolMessage submitResult = transportClient.controlRequest(mpm);
/* 342 */     if ((submitResult instanceof ErrorResponseMessage)) {
/* 343 */       ErrorResponseMessage error = (ErrorResponseMessage)submitResult;
/* 344 */       this.taskManager.onErrorMessage(error, order);
/*     */     }
/* 346 */     DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/* 347 */     format.setTimeZone(TimeZone.getTimeZone("GMT"));
/* 348 */     StringBuilder strBuilder = new StringBuilder();
/* 349 */     strBuilder.append("Merge request with label ").append(label).append(" sent for positions: ");
/* 350 */     for (String mergeOrderGroupId : mergeOrderGroupIdList) {
/* 351 */       strBuilder.append(mergeOrderGroupId).append(", ");
/*     */     }
/* 353 */     strBuilder.setLength(strBuilder.length() - 2);
/* 354 */     strBuilder.append(" at ").append(format.format(Long.valueOf(System.currentTimeMillis()))).append(" by the strategy \"").append(this.taskManager.getJFRunnableName()).append("\": from the ");
/* 355 */     strBuilder.append(this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer");
/* 356 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(strBuilder.toString());
/*     */     
/* 358 */     return order;
/*     */   }
/*     */   
/*     */   public void closeOrders(IOrder... orders) throws JFException
/*     */   {
/* 363 */     closeOrders(Arrays.asList(orders));
/*     */   }
/*     */   
/*     */   public void closeOrders(Collection<IOrder> orders) throws JFException
/*     */   {
/* 368 */     getOrderValidator().validateCloseOrders(this.taskManager.isGlobal(), orders);
/*     */     
/* 370 */     if (!ObjectUtils.isNullOrEmpty(orders)) {
/* 371 */       List<OrderMessageExt> groupsToClose = new ArrayList();
/* 372 */       for (IOrder order : orders) {
/* 373 */         groupsToClose.add(JForexAPI.closePosition(this.taskManager, order.getOrderCommand(), order.getInstrument(), ((PlatformOrderImpl)order).groupId, order.getLabel(), order.getAmount(), 0.0D, -1.0D));
/*     */       }
/*     */       
/* 376 */       for (IOrder order : orders) {
/* 377 */         ((PlatformOrderImpl)order).setLastServerRequest(PlatformOrderImpl.ServerRequest.CLOSE);
/*     */       }
/*     */       
/* 380 */       TransportClient transportClient = this.taskManager.getTransportClient();
/* 381 */       OrderGroupMessage ogm = JForexAPI.massClose(groupsToClose);
/* 382 */       if (LOGGER.isDebugEnabled()) {
/* 383 */         LOGGER.debug("Sending mass close request [" + ogm + "]");
/*     */       }
/* 385 */       ProtocolMessage submitResult = transportClient.controlRequest(ogm);
/* 386 */       if ((submitResult instanceof ErrorResponseMessage)) {
/* 387 */         ErrorResponseMessage error = (ErrorResponseMessage)submitResult;
/* 388 */         this.taskManager.onMessage(new PlatformMessageImpl(error.getReason(), null, IMessage.Type.ORDER_CLOSE_REJECTED, FeedDataProvider.getDefaultInstance().getCurrentTime()));
/*     */       }
/* 390 */       DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/* 391 */       format.setTimeZone(TimeZone.getTimeZone("GMT"));
/* 392 */       StringBuilder strBuilder = new StringBuilder("Closing request sent for positions: ");
/* 393 */       for (OrderMessage orderMessage : groupsToClose) {
/* 394 */         strBuilder.append(orderMessage.getOrderGroupId()).append(", ");
/*     */       }
/* 396 */       strBuilder.setLength(strBuilder.length() - 2);
/* 397 */       strBuilder.append(" at ").append(format.format(Long.valueOf(System.currentTimeMillis()))).append(" by the strategy \"").append(this.taskManager.getJFRunnableName()).append("\": from the ");
/* 398 */       strBuilder.append(this.taskManager.getEnvironment() == JForexTaskManager.Environment.REMOTE ? "remote server" : "local computer");
/* 399 */       NotificationUtilsProvider.getNotificationUtils().postInfoMessage(strBuilder.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public void broadcast(String topic, String message) throws JFException
/*     */   {
/*     */     try {
/* 406 */       LOGGER.debug("Sending broadcast message : " + topic + ", " + message);
/*     */       
/* 408 */       this.taskManager.getFeedDataProvider().getJssManager().broadcastMessageAsynch(this.taskManager.getUID(), topic, message);
/*     */ 
/*     */     }
/*     */     catch (JssException ex)
/*     */     {
/*     */ 
/* 414 */       throw new JFException(ex.getLocalizedMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public JForexTaskManager<?, ?, ?> getTaskManager() {
/* 419 */     return this.taskManager;
/*     */   }
/*     */   
/*     */   protected ILotAmountProvider getLotAmountProvider()
/*     */   {
/* 424 */     return this.taskManager.getLotAmountProvider();
/*     */   }
/*     */   
/*     */   protected ICurrency getAccountCurrency()
/*     */   {
/* 429 */     return this.taskManager.getAccountCurrency();
/*     */   }
/*     */   
/*     */   public IEngine.StrategyMode getStrategyMode()
/*     */   {
/* 434 */     return IEngine.StrategyMode.INDEPENDENT;
/*     */   }
/*     */   
/*     */   public IOrderValidator getOrderValidator() {
/* 438 */     return this.taskManager.getOrderValidator();
/*     */   }
/*     */   
/*     */   public IEngine.RunMode getRunMode()
/*     */   {
/* 443 */     return PlatformSessionClientBean.getInstance().getPlatformType() == PlatformType.JSS ? IEngine.RunMode.REMOTE : IEngine.RunMode.LOCAL;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexEngineImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */