/*    */ package com.dukascopy.charts.data.datacache.filtering;
/*    */ 
/*    */ import com.dukascopy.api.Filter;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.CandleData;
/*    */ import com.dukascopy.charts.data.datacache.wrapper.ITimeInterval;
/*    */ import java.util.List;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface IFilterManager
/*    */ {
/* 24 */   public static final TimeZone FOREX_TIME_ZONE = TimeZone.getTimeZone("America/Los_Angeles");
/*    */   
/*    */   public abstract boolean isWeekendTime(long paramLong);
/*    */   
/*    */   public abstract boolean isWeekendTime(long paramLong, Period paramPeriod);
/*    */   
/*    */   public abstract ITimeInterval getWeekend(long paramLong);
/*    */   
/*    */   public abstract ITimeInterval[] getWeekends(long paramLong1, long paramLong2);
/*    */   
/*    */   public abstract List<ITimeInterval> calculateApproximateWeekends(long paramLong1, long paramLong2);
/*    */   
/*    */   public abstract boolean isFlat(CandleData paramCandleData);
/*    */   
/*    */   public abstract boolean isFlat(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
/*    */   
/*    */   public abstract boolean matchedFilter(Period paramPeriod, Filter paramFilter, CandleData paramCandleData);
/*    */   
/*    */   public abstract boolean matchedFilter(Period paramPeriod, Filter paramFilter, long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
/*    */   
/*    */   public abstract boolean anyWeekendsInInterval(long paramLong1, long paramLong2);
/*    */   
/*    */   public abstract void preloadCache();
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\filtering\IFilterManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */