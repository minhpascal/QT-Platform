/*    */ package com.dukascopy.charts.data.datacache.pamanager.creators;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*    */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureCreator;
/*    */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachePointAndFigureCreator
/*    */   extends PointAndFigureCreator
/*    */ {
/*    */   private IPointAndFigureLiveFeedListener cacheFeedListener;
/*    */   
/*    */   public CachePointAndFigureCreator(Instrument instrument, OfferSide offerSide, JForexPeriod jfPeriod, IPointAndFigureLiveFeedListener cacheFeedListener, boolean fromTheBeginningOfTheHistory)
/*    */   {
/* 31 */     super(instrument, jfPeriod.getPriceRange(), jfPeriod.getReversalAmount(), offerSide, -1, true, false, fromTheBeginningOfTheHistory, null);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 42 */     this.cacheFeedListener = cacheFeedListener;
/*    */   }
/*    */   
/*    */   public boolean isAllDesiredDataLoaded()
/*    */   {
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   protected void resetResultArray()
/*    */   {
/* 52 */     this.result = new PointAndFigureData[1];
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 57 */     return 0;
/*    */   }
/*    */   
/*    */   public void fireNewBarCreated(PointAndFigureData data)
/*    */   {
/* 62 */     this.lastFiredData = data;
/* 63 */     this.cacheFeedListener.newPriceData(data);
/*    */   }
/*    */   
/*    */   protected void addNewElement(PointAndFigureData element)
/*    */   {
/* 68 */     ((PointAndFigureData[])this.result)[getLastElementIndex()] = element;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\creators\CachePointAndFigureCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */