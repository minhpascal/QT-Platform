/*    */ package com.dukascopy.charts.data.datacache.core.connection;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.core.lock.CacheFileHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChildCacheWriteConnection
/*    */   extends CacheWriteConnection
/*    */ {
/*    */   private final CacheReadConnection parentCacheReadConnection;
/*    */   
/*    */   public ChildCacheWriteConnection(CacheFileHandler cacheFileHandler, CacheReadConnection parentCacheReadConnection)
/*    */   {
/* 17 */     super(cacheFileHandler);
/*    */     
/* 19 */     this.parentCacheReadConnection = parentCacheReadConnection;
/*    */   }
/*    */   
/*    */   public void close()
/*    */   {
/* 24 */     super.close();
/*    */     
/* 26 */     this.cacheFileHandler.localWriteUnlockReadLock();
/* 27 */     this.parentCacheReadConnection.activate();
/*    */   }
/*    */   
/*    */   protected void performWriteUnlock() {}
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\ChildCacheWriteConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */