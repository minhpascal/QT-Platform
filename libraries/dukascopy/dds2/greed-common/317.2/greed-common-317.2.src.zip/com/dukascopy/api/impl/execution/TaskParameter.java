/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IStrategy;
/*    */ import com.dukascopy.api.impl.JFRunnableMessages;
/*    */ import java.util.List;
/*    */ import javax.swing.JComponent;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskParameter
/*    */   implements Task
/*    */ {
/* 19 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskParameter.class);
/*    */   
/* 21 */   private IControlUI parametersDialog = null;
/* 22 */   List<JComponent> componentsList = null;
/*    */   private IStrategy strategy;
/*    */   private boolean printChangeMessage;
/*    */   
/*    */   public TaskParameter(IStrategy strategy, IControlUI parametersDialog, List<JComponent> componentsList) {
/* 27 */     this.parametersDialog = parametersDialog;
/* 28 */     this.componentsList = componentsList;
/* 29 */     this.strategy = strategy;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TaskParameter() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Task.Type getType()
/*    */   {
/* 42 */     return Task.Type.PARAMETER;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object call()
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 52 */       if ((this.parametersDialog != null) && (this.componentsList != null)) {
/* 53 */         for (JComponent component : this.componentsList) {
/* 54 */           this.parametersDialog.setControlField(component, false);
/*    */         }
/* 56 */         if ((this.printChangeMessage) && 
/* 57 */           (this.parametersDialog != null) && (this.componentsList != null)) {
/* 58 */           JFRunnableMessages.strategyIsModified(this.strategy, false);
/*    */         }
/*    */       }
/*    */       
/* 62 */       return Boolean.valueOf(true);
/*    */     } catch (Exception e1) {
/* 64 */       LOGGER.error(e1.getMessage(), e1); }
/* 65 */     return Boolean.valueOf(false);
/*    */   }
/*    */   
/*    */ 
/*    */   public void setPrintChangeMessage(boolean printChangeMessage)
/*    */   {
/* 71 */     this.printChangeMessage = printChangeMessage;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskParameter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */