/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.ICalendarMessage;
/*     */ import com.dukascopy.api.ICalendarMessage.Detail;
/*     */ import com.dukascopy.api.IMessage.Type;
/*     */ import com.dukascopy.api.INewsMessage.Action;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.news.CalendarEvent;
/*     */ import com.dukascopy.dds3.transport.msg.news.CalendarEventDetail;
/*     */ import com.dukascopy.dds3.transport.msg.news.CalendarType;
/*     */ import com.dukascopy.dds3.transport.msg.news.NewsSource;
/*     */ import com.dukascopy.dds4.transport.msg.types.GeoRegion;
/*     */ import com.dukascopy.dds4.transport.msg.types.MarketSector;
/*     */ import com.dukascopy.dds4.transport.msg.types.StockIndex;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class PlatformCalendarMessageImpl
/*     */   extends PlatformNewsMessageImpl implements ICalendarMessage
/*     */ {
/*     */   private final String actionString;
/*     */   private final String companyURL;
/*     */   private final String country;
/*     */   private final String eventCode;
/*     */   private final String eventCategory;
/*     */   private long eventDate;
/*     */   private final String id;
/*     */   private final String eventURL;
/*     */   private final String ISIN;
/*     */   private final String organisation;
/*     */   private final String period;
/*     */   private final String ticker;
/*     */   private final String venue;
/*     */   private final boolean isConfirmed;
/*  37 */   private final List<ICalendarMessage.Detail> details = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PlatformCalendarMessageImpl(CalendarEvent calendarEvent, String copyright, String header, String newsId, long publishDate, boolean endOfStory, boolean isHot, Set<String> currencies, Set<GeoRegion> geoRegions, Set<MarketSector> marketSectors, Set<StockIndex> stockIndicies)
/*     */   {
/*  53 */     super(calendarEvent == null ? null : calendarEvent.getDescription(), copyright, header, newsId, publishDate, endOfStory, isHot, currencies, geoRegions, marketSectors, stockIndicies, NewsSource.DJ_LIVE_CALENDAR);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */     if (calendarEvent != null) {
/*  69 */       this.id = calendarEvent.getEventId();
/*  70 */       this.actionString = calendarEvent.getAction();
/*     */     } else {
/*  72 */       this.id = null;
/*  73 */       this.actionString = null;
/*     */     }
/*     */     
/*  76 */     if ((getAction() == null) || (getAction() == INewsMessage.Action.DELETE)) {
/*  77 */       this.companyURL = null;
/*  78 */       this.country = null;
/*  79 */       this.eventCode = null;
/*  80 */       this.eventCategory = null;
/*  81 */       this.eventDate = 0L;
/*  82 */       this.eventURL = null;
/*  83 */       this.ISIN = null;
/*  84 */       this.organisation = null;
/*  85 */       this.period = null;
/*  86 */       this.ticker = null;
/*  87 */       this.venue = null;
/*  88 */       this.isConfirmed = false;
/*     */     } else {
/*  90 */       this.companyURL = calendarEvent.getCompanyUrl();
/*  91 */       this.country = calendarEvent.getCountry();
/*  92 */       this.eventCategory = calendarEvent.getEventCategory();
/*  93 */       if (calendarEvent.getCalendarType() != null) {
/*  94 */         this.eventCode = calendarEvent.getCalendarType().name();
/*     */       } else {
/*  96 */         this.eventCode = null;
/*     */       }
/*  98 */       this.eventDate = calendarEvent.getEventDate();
/*  99 */       this.eventURL = calendarEvent.getEventUrl();
/* 100 */       this.ISIN = calendarEvent.getIsin();
/* 101 */       this.organisation = calendarEvent.getOrganisation();
/* 102 */       this.period = calendarEvent.getPeriod();
/* 103 */       this.ticker = calendarEvent.getTicker();
/* 104 */       this.venue = calendarEvent.getVenue();
/* 105 */       this.isConfirmed = calendarEvent.isConfirmed();
/*     */       
/* 107 */       for (CalendarEventDetail calendarEventDetail : calendarEvent.getDetails()) {
/* 108 */         this.details.add(new PlatformCalendarDetail(calendarEventDetail.getDetailId(), calendarEventDetail.getActual(), calendarEventDetail.getDelta(), calendarEventDetail.getDescription(), calendarEventDetail.getExpected(), calendarEventDetail.getPrevious()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCompanyURL()
/*     */   {
/* 124 */     return this.companyURL;
/*     */   }
/*     */   
/*     */   public String getCountry() {
/* 128 */     return this.country;
/*     */   }
/*     */   
/*     */   public List<ICalendarMessage.Detail> getDetails()
/*     */   {
/* 133 */     return this.details;
/*     */   }
/*     */   
/*     */   public String getEventCode() {
/* 137 */     return this.eventCode;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getEventCategory()
/*     */   {
/* 143 */     return this.eventCategory;
/*     */   }
/*     */   
/*     */   public long getEventDate()
/*     */   {
/* 148 */     return this.eventDate;
/*     */   }
/*     */   
/*     */   public String getISIN() {
/* 152 */     return this.ISIN;
/*     */   }
/*     */   
/*     */   public String getOrganisation() {
/* 156 */     return this.organisation;
/*     */   }
/*     */   
/*     */   public String getPeriod() {
/* 160 */     return this.period;
/*     */   }
/*     */   
/*     */   public String getTicker() {
/* 164 */     return this.ticker;
/*     */   }
/*     */   
/*     */   public String getEventURL() {
/* 168 */     return this.eventURL;
/*     */   }
/*     */   
/*     */   public String getVenue() {
/* 172 */     return this.venue;
/*     */   }
/*     */   
/*     */   public boolean isConfirmed() {
/* 176 */     return this.isConfirmed;
/*     */   }
/*     */   
/*     */   public INewsMessage.Action getAction() {
/* 180 */     if (this.actionString == null) {
/* 181 */       return null;
/*     */     }
/*     */     
/* 184 */     return INewsMessage.Action.valueOf(this.actionString);
/*     */   }
/*     */   
/*     */   public String getId() {
/* 188 */     return this.id;
/*     */   }
/*     */   
/*     */   public IMessage.Type getType() {
/* 192 */     return IMessage.Type.CALENDAR;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 197 */     StringBuilder sb = new StringBuilder();
/* 198 */     sb.append(String.format("[MessageType %s]:%n \tcontent : %s, country : %s, company url : %s, event code : %s, event category: %s, organization : %s, period : %s, event date: %s", new Object[] { getType(), getContent(), getCountry(), getCompanyURL(), getEventCode(), getEventCategory(), getOrganisation(), getPeriod(), this.df.format(Long.valueOf(getEventDate())) }));
/*     */     
/* 200 */     if (!ObjectUtils.isNullOrEmpty(getDetails())) {
/* 201 */       sb.append(String.format("%n", new Object[0]));
/* 202 */       sb.append("\tCalendar Details: ");
/* 203 */       for (ICalendarMessage.Detail detail : getDetails()) {
/* 204 */         sb.append(String.format("%n\t\tId:%s, Description:%s, Expected:%s, Actual:%s, Delta:%s, Previous:%s ", new Object[] { detail.getId(), detail.getDescription(), detail.getExpected(), detail.getActual(), detail.getDelta(), detail.getPrevious() }));
/*     */       }
/*     */     }
/*     */     
/* 208 */     sb.append(String.format("%n", new Object[0])).append(getMetaDataInfo());
/* 209 */     return sb.toString();
/*     */   }
/*     */   
/*     */   class PlatformCalendarDetail
/*     */     implements ICalendarMessage.Detail
/*     */   {
/* 215 */     private String actual = null;
/* 216 */     private String delta = null;
/* 217 */     private String description = null;
/* 218 */     private String id = null;
/* 219 */     private String expected = null;
/* 220 */     private String previous = null;
/*     */     
/*     */     public PlatformCalendarDetail(String id, String actual, String delta, String description, String expected, String previous) {
/* 223 */       this.id = id;
/* 224 */       this.actual = actual;
/* 225 */       this.delta = delta;
/* 226 */       this.description = description;
/* 227 */       this.id = id;
/* 228 */       this.expected = expected;
/* 229 */       this.previous = previous;
/*     */     }
/*     */     
/*     */     public String getActual()
/*     */     {
/* 234 */       return this.actual;
/*     */     }
/*     */     
/*     */     public String getDelta()
/*     */     {
/* 239 */       return this.delta;
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 244 */       return this.description;
/*     */     }
/*     */     
/*     */     public String getExpected()
/*     */     {
/* 249 */       return this.expected;
/*     */     }
/*     */     
/*     */     public String getId()
/*     */     {
/* 254 */       return this.id;
/*     */     }
/*     */     
/*     */     public String getPrevious()
/*     */     {
/* 259 */       return this.previous;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformCalendarMessageImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */