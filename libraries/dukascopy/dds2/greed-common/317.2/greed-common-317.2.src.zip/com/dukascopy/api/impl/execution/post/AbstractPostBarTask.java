/*    */ package com.dukascopy.api.impl.execution.post;
/*    */ 
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.impl.execution.AbstractPostDataTask;
/*    */ import com.dukascopy.api.impl.execution.Task.Type;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPostBarTask
/*    */   extends AbstractPostDataTask<Void>
/*    */ {
/*    */   protected final Instrument instrument;
/*    */   protected final OfferSide offerSide;
/*    */   
/*    */   public AbstractPostBarTask(JForexTaskManager<?, ?, ?> taskManager, IJFRunnable<?> strategy, IStrategyExceptionHandler exceptionHandler, Instrument instrument, OfferSide offerSide)
/*    */   {
/* 31 */     super(taskManager, strategy, exceptionHandler);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 36 */     this.instrument = instrument;
/* 37 */     this.offerSide = offerSide;
/*    */   }
/*    */   
/*    */   protected IStrategyExceptionHandler.Source getSource()
/*    */   {
/* 42 */     return IStrategyExceptionHandler.Source.ON_BAR;
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 47 */     return Task.Type.BAR;
/*    */   }
/*    */   
/*    */   public Instrument getInstrument() {
/* 51 */     return this.instrument;
/*    */   }
/*    */   
/*    */   public OfferSide getOfferSide() {
/* 55 */     return this.offerSide;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\post\AbstractPostBarTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */