/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ 
/*  5 */ public class Substitution { public Substitution() { this.substitutions = new LinkedList(); }
/*    */   
/*    */   private LinkedList<Pair> substitutions;
/*  8 */   public void add(com.dukascopy.calculator.expression.Variable variable, OObject oobject) { if (variable == null) return;
/*  9 */     for (java.util.Iterator<Pair> i = this.substitutions.iterator(); i.hasNext();) {
/* 10 */       Pair pair = (Pair)i.next();
/* 11 */       if (pair.variable.name().equals(variable.name()))
/*    */       {
/* 13 */         if (oobject == null) {
/* 14 */           i.remove();
/*    */         } else {
/* 16 */           pair.oobject = oobject;
/*    */         }
/* 18 */         return;
/*    */       }
/*    */     }
/*    */     
/* 22 */     Pair pair = new Pair();
/* 23 */     pair.variable = variable;
/* 24 */     pair.oobject = oobject;
/* 25 */     this.substitutions.add(pair);
/*    */   }
/*    */   
/*    */   public final LinkedList<Pair> getSubstitutions() {
/* 29 */     return this.substitutions;
/*    */   }
/*    */   
/*    */   public class Pair
/*    */   {
/*    */     public com.dukascopy.calculator.expression.Variable variable;
/*    */     public OObject oobject;
/*    */     
/*    */     public Pair() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\Substitution.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */