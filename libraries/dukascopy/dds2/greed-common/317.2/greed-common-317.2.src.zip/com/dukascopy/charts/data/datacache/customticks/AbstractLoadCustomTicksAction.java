/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.util.DateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractLoadCustomTicksAction
/*    */   implements Runnable
/*    */ {
/*    */   protected final long from;
/*    */   protected final long to;
/*    */   
/*    */   public AbstractLoadCustomTicksAction(long from, long to)
/*    */   {
/* 22 */     this.from = from;
/* 23 */     this.to = to;
/*    */     
/* 25 */     if (from > to) {
/* 26 */       throw new IllegalArgumentException("from(" + DateUtils.format(from) + ") > to(" + DateUtils.format(to) + ")");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\AbstractLoadCustomTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */