/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SpecialButtonType
/*    */ {
/* 12 */   NONE,  SHIFT,  STAT,  SHIFT_STAT,  HEX,  SHIFT_HEX;
/*    */   
/*    */   private SpecialButtonType() {}
/* 15 */   public String toString() { switch (this) {
/*    */     case NONE: 
/* 17 */       return "NONE";
/*    */     case STAT: 
/* 19 */       return "STAT";
/*    */     case SHIFT: 
/*    */     case SHIFT_STAT: 
/*    */     case SHIFT_HEX: 
/* 23 */       return "SHIFT";
/*    */     case HEX: 
/* 25 */       return "HEX";
/*    */     }
/* 27 */     throw new AssertionError("Unknown SpecialButtonType");
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\SpecialButtonType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */