package com.dukascopy.calculator;

public abstract interface ReadOnlyDisplayPanel
{
  public abstract boolean getOn();
  
  public abstract ReadOnlyCalculatorApplet getApplet();
  
  public abstract boolean hasCaret(ScrollableLabel paramScrollableLabel);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\ReadOnlyDisplayPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */