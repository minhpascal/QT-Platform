/*    */ package com.dukascopy.api.impl.execution.post;
/*    */ 
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ import com.dukascopy.api.feed.IRangeBar;
/*    */ import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
/*    */ import com.dukascopy.api.impl.connect.IFeedRangeBarListener;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostRangeBarTask
/*    */   extends AbstractPostBarTask
/*    */ {
/* 22 */   private static final Logger LOGGER = LoggerFactory.getLogger(PostRangeBarTask.class);
/*    */   
/*    */ 
/*    */   private final IFeedRangeBarListener barFeedListener;
/*    */   
/*    */ 
/*    */   private final RangeBarFeedDescriptor feedDescriptor;
/*    */   
/*    */ 
/*    */   private final IRangeBar bar;
/*    */   
/*    */ 
/*    */ 
/*    */   public PostRangeBarTask(JForexTaskManager<?, ?, ?> taskManager, IJFRunnable<?> strategy, IStrategyExceptionHandler exceptionHandler, RangeBarFeedDescriptor feedDescriptor, IFeedRangeBarListener barFeedListener, IRangeBar bar)
/*    */   {
/* 37 */     super(taskManager, strategy, exceptionHandler, feedDescriptor.getInstrument(), feedDescriptor.getOfferSide());
/* 38 */     this.barFeedListener = barFeedListener;
/* 39 */     this.feedDescriptor = feedDescriptor;
/* 40 */     this.bar = bar;
/*    */   }
/*    */   
/*    */   protected Logger getLogger()
/*    */   {
/* 45 */     return LOGGER;
/*    */   }
/*    */   
/*    */   protected void postData() throws Throwable
/*    */   {
/* 50 */     this.barFeedListener.onRangeBar(this.feedDescriptor, this.bar);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\post\PostRangeBarTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */