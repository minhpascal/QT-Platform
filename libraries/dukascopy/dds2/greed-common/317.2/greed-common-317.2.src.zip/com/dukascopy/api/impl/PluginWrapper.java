/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.plugins.Plugin;
/*    */ import com.dukascopy.dds2.greed.agent.compiler.JFXCompiler;
/*    */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.ide.api.ServiceSourceLanguage;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.security.GeneralSecurityException;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ public class PluginWrapper
/*    */   extends JFRunnableWrapper<Plugin>
/*    */ {
/* 17 */   private static final Logger LOGGER = LoggerFactory.getLogger(PluginWrapper.class);
/*    */   
/*    */   public PluginWrapper(File binaryFile) {
/* 20 */     init(binaryFile);
/*    */   }
/*    */   
/*    */   private void init(File binaryFile) {
/* 24 */     setBinaryFile(binaryFile);
/*    */     try
/*    */     {
/* 27 */       this.jfRunnable = getJFRunnable(true);
/*    */     } catch (Exception e) {
/* 29 */       LOGGER.error(e.getMessage(), e);
/*    */     }
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 35 */     if (this.binFile != null) {
/* 36 */       return this.binFile.getName();
/*    */     }
/* 38 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected JFXPack loadFromPack()
/*    */     throws IOException, GeneralSecurityException
/*    */   {
/* 46 */     boolean isJfx = getBinaryFile().getName().endsWith(ServiceSourceLanguage.JFX.getExtension());
/* 47 */     if (!isJfx) {
/* 48 */       File jfxFile = new File(getBinaryFile().getAbsolutePath().substring(0, getBinaryFile().getAbsolutePath().length() - 4) + ServiceSourceLanguage.JFX.getExtension());
/*    */       
/* 50 */       if (jfxFile.exists()) {
/* 51 */         init(jfxFile);
/* 52 */         isJfx = true;
/*    */       }
/*    */     }
/*    */     try {
/* 56 */       return isJfx ? JFXPack.loadJarFromPack(getBinaryFile()) : JFXPack.buildFromJar(getBinaryFile());
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 60 */       LOGGER.error(e.getMessage(), e);
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */   
/*    */   public JFXPack packJarToJfx() throws Exception {
/* 66 */     File jarFile = new File(getBinaryFile().getAbsolutePath().substring(0, getBinaryFile().getAbsolutePath().length() - 4) + ServiceSourceLanguage.JAR.getExtension());
/*    */     
/*    */ 
/* 69 */     if (!jarFile.exists()) {
/* 70 */       LOGGER.error("Unable to create a jfx file - the jar file does not exist - " + jarFile);
/* 71 */       return null;
/*    */     }
/* 73 */     File jfxFile = JFXCompiler.getInstance().packJarToJfx(jarFile);
/* 74 */     if ((jfxFile == null) || (!jfxFile.exists())) {
/* 75 */       return null;
/*    */     }
/* 77 */     init(jfxFile);
/* 78 */     return this.pack;
/*    */   }
/*    */   
/*    */   public JFXPack getPack() {
/* 82 */     return this.pack;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\PluginWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */