/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatPanel
/*    */   extends PlainPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public StatPanel(MainCalculatorPanel applet, SpecialButtonType sbt, Color colour)
/*    */   {
/* 19 */     super(applet, sbt, colour);
/* 20 */     if (sbt != SpecialButtonType.STAT) {
/* 21 */       throw new RuntimeException("StatPanel instantiated wrongly.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void setButtons()
/*    */   {
/* 30 */     super.setButtons();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\StatPanel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */