/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.indicators.OutputParameterInfo.DrawingStyle;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.awt.Color;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LevelInfo
/*     */   implements Comparable<LevelInfo>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 364569280248232454L;
/*     */   private String label;
/*     */   private double value;
/*  27 */   private OutputParameterInfo.DrawingStyle drawingStyle = OutputParameterInfo.DrawingStyle.DASH_LINE;
/*  28 */   private Color color = Color.BLACK;
/*  29 */   private float opacityAlpha = 1.0F;
/*  30 */   private int lineWidth = 1;
/*     */   
/*     */ 
/*     */   public LevelInfo() {}
/*     */   
/*     */   public LevelInfo(double value)
/*     */   {
/*  37 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LevelInfo(String label, double value, OutputParameterInfo.DrawingStyle drawingStyle, Color color, int width, float alpha)
/*     */   {
/*  51 */     this.label = label;
/*  52 */     this.value = value;
/*  53 */     this.drawingStyle = drawingStyle;
/*  54 */     this.color = color;
/*  55 */     this.lineWidth = width;
/*  56 */     this.opacityAlpha = alpha;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getLabel()
/*     */   {
/*  62 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/*  68 */     this.label = label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/*  75 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setValue(double value)
/*     */   {
/*  81 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */   public OutputParameterInfo.DrawingStyle getDrawingStyle()
/*     */   {
/*  87 */     return this.drawingStyle;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDrawingStyle(OutputParameterInfo.DrawingStyle drawingStyle)
/*     */   {
/*  93 */     this.drawingStyle = drawingStyle;
/*     */   }
/*     */   
/*     */ 
/*     */   public Color getColor()
/*     */   {
/*  99 */     if (this.color == null) {
/* 100 */       return Color.BLACK;
/*     */     }
/* 102 */     return this.color;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setColor(Color color)
/*     */   {
/* 108 */     this.color = color;
/*     */   }
/*     */   
/*     */ 
/*     */   public float getOpacityAlpha()
/*     */   {
/* 114 */     return this.opacityAlpha;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setOpacityAlpha(float opacityAlpha)
/*     */   {
/* 120 */     this.opacityAlpha = opacityAlpha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLineWidth()
/*     */   {
/* 127 */     return this.lineWidth;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLineWidth(int lineWidth)
/*     */   {
/* 133 */     this.lineWidth = lineWidth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int compareTo(LevelInfo other)
/*     */   {
/* 140 */     if (other == null) {
/* 141 */       return 1;
/*     */     }
/* 143 */     return ObjectUtils.compare(Double.valueOf(getValue()), Double.valueOf(other.getValue()));
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\LevelInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */