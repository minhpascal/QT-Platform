/*    */ package com.dukascopy.charts.data.datacache.change;
/*    */ 
/*    */ import com.dukascopy.api.util.DateUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheChangeDescriptor
/*    */   implements Comparable<CacheChangeDescriptor>
/*    */ {
/*    */   private long changeFileCreationTime;
/*    */   private String changeFileRelativePath;
/*    */   
/*    */   public CacheChangeDescriptor() {}
/*    */   
/*    */   public CacheChangeDescriptor(long changeFileCreationTime, String changeFileRelativePath)
/*    */   {
/* 25 */     this.changeFileCreationTime = changeFileCreationTime;
/* 26 */     this.changeFileRelativePath = changeFileRelativePath;
/*    */   }
/*    */   
/* 29 */   public long getChangeFileCreationTime() { return this.changeFileCreationTime; }
/*    */   
/*    */   public void setChangeFileCreationTime(long changeFileCreationTime) {
/* 32 */     this.changeFileCreationTime = changeFileCreationTime;
/*    */   }
/*    */   
/* 35 */   public String getChangeFileRelativePath() { return this.changeFileRelativePath; }
/*    */   
/*    */   public void setChangeFileRelativePath(String changeFileRelativePath) {
/* 38 */     this.changeFileRelativePath = changeFileRelativePath;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 42 */     int prime = 31;
/* 43 */     int result = 1;
/* 44 */     result = 31 * result + (int)(this.changeFileCreationTime ^ this.changeFileCreationTime >>> 32);
/* 45 */     result = 31 * result + (this.changeFileRelativePath == null ? 0 : this.changeFileRelativePath.hashCode());
/* 46 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     if (this == obj)
/* 51 */       return true;
/* 52 */     if (obj == null)
/* 53 */       return false;
/* 54 */     if (getClass() != obj.getClass())
/* 55 */       return false;
/* 56 */     CacheChangeDescriptor other = (CacheChangeDescriptor)obj;
/* 57 */     if (this.changeFileCreationTime != other.changeFileCreationTime)
/* 58 */       return false;
/* 59 */     if (this.changeFileRelativePath == null) {
/* 60 */       if (other.changeFileRelativePath != null)
/* 61 */         return false;
/* 62 */     } else if (!this.changeFileRelativePath.equals(other.changeFileRelativePath))
/* 63 */       return false;
/* 64 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 68 */     return DateUtils.format(this.changeFileCreationTime) + " " + this.changeFileRelativePath;
/*    */   }
/*    */   
/*    */   public int compareTo(CacheChangeDescriptor o)
/*    */   {
/* 73 */     return Long.compare(this.changeFileCreationTime, o.changeFileCreationTime);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\change\CacheChangeDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */