/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullPObject
/*    */   extends PObject
/*    */ {
/*    */   private NullPObject()
/*    */   {
/* 10 */     this.ftooltip = "";
/* 11 */     this.fshortcut = '\000';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 15 */     return fname;
/*    */   }
/*    */   
/*    */   public static NullPObject instance() {
/* 19 */     if (instance == null)
/* 20 */       instance = new NullPObject();
/* 21 */     return instance;
/*    */   }
/*    */   
/* 24 */   private static final String[] fname = { "" };
/*    */   
/*    */ 
/*    */ 
/* 28 */   private static NullPObject instance = null;
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\NullPObject.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */