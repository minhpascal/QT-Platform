/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.ICloseOrder;
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.IEngine.OrderCommand;
/*     */ import com.dukascopy.api.IFillOrder;
/*     */ import com.dukascopy.api.IMessage;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.api.IOrder.State;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.impl.connect.JForexAPI;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.OrderHistoricalData;
/*     */ import com.dukascopy.charts.data.datacache.OrderHistoricalData.OpenData;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.AbstractCurrencyConverter;
/*     */ import com.dukascopy.dds2.greed.util.CurrencyConverter;
/*     */ import com.dukascopy.dds2.greed.util.InstrumentUtils;
/*     */ import com.dukascopy.dds2.greed.util.MathConstants;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ public class HistoryOrder
/*     */   implements IOrder
/*     */ {
/*     */   private String label;
/*     */   private long creationTime;
/*     */   private long fillTime;
/*     */   private IEngine.OrderCommand orderCommand;
/*     */   private double filledAmount;
/*     */   private double openPrice;
/*     */   private String comment;
/*  39 */   private double commission = 0.0D;
/*     */   
/*     */   private double stopLossPrice;
/*     */   
/*     */   private double takeProfitPrice;
/*     */   private double originalAmount;
/*     */   private final String id;
/*     */   private final long closeTime;
/*     */   private final double closePrice;
/*     */   private final Instrument instrument;
/*     */   private final ICurrency accountCurrency;
/*     */   private final List<IFillOrder> fillHistory;
/*     */   private final List<ICloseOrder> closeHistory;
/*     */   
/*     */   public HistoryOrder(Instrument instrument, OrderHistoricalData orderData, ICurrency accountCurrency, long closeTime, double closePrice)
/*     */   {
/*  55 */     this.instrument = instrument;
/*  56 */     this.closeTime = closeTime;
/*  57 */     this.closePrice = closePrice;
/*  58 */     this.accountCurrency = accountCurrency;
/*     */     
/*  60 */     BigDecimal commission = orderData.getCommission();
/*  61 */     if (commission != null) {
/*  62 */       this.commission = commission.doubleValue();
/*     */     }
/*     */     
/*  65 */     this.id = orderData.getOrderGroupId();
/*     */     
/*  67 */     OrderHistoricalData.OpenData entryOrder = orderData.getEntryOrder();
/*  68 */     if (entryOrder != null) {
/*  69 */       this.label = entryOrder.getLabel();
/*  70 */       this.fillTime = entryOrder.getFillTime();
/*  71 */       this.creationTime = entryOrder.getCreationTime();
/*  72 */       this.orderCommand = entryOrder.getSide();
/*  73 */       BigDecimal amount = entryOrder.getAmount();
/*  74 */       if (amount != null) {
/*  75 */         this.filledAmount = amount.divide(MathConstants.ONE_MILLION).doubleValue();
/*     */       }
/*  77 */       BigDecimal openPrice = entryOrder.getOpenPrice();
/*  78 */       if (openPrice != null) {
/*  79 */         this.openPrice = openPrice.doubleValue();
/*     */       }
/*  81 */       BigDecimal stopLossPrice = entryOrder.getStopLossPrice();
/*  82 */       if ((stopLossPrice != null) && (!ObjectUtils.isEqual(stopLossPrice, OrderHistoricalData.NEG_ONE))) {
/*  83 */         this.stopLossPrice = stopLossPrice.doubleValue();
/*     */       }
/*  85 */       BigDecimal takeProfitPrice = entryOrder.getTakeProfitPrice();
/*  86 */       if ((takeProfitPrice != null) && (!ObjectUtils.isEqual(takeProfitPrice, OrderHistoricalData.NEG_ONE))) {
/*  87 */         this.takeProfitPrice = takeProfitPrice.doubleValue();
/*     */       }
/*  89 */       this.label = entryOrder.getLabel();
/*  90 */       this.comment = entryOrder.getComment();
/*  91 */       BigDecimal originalAmount = entryOrder.getOriginalAmount();
/*  92 */       if (originalAmount != null) {
/*  93 */         this.originalAmount = originalAmount.divide(MathConstants.ONE_MILLION).doubleValue();
/*     */       }
/*     */     }
/*  96 */     this.fillHistory = new ArrayList();
/*  97 */     this.fillHistory.addAll(JForexAPI.getFillOrders(orderData.getFillDataMap().values()));
/*     */     
/*  99 */     this.closeHistory = new ArrayList();
/* 100 */     this.closeHistory.addAll(JForexAPI.getCloseOrders(orderData.getCloseDataMap().values()));
/*     */   }
/*     */   
/*     */   public Instrument getInstrument()
/*     */   {
/* 105 */     return this.instrument;
/*     */   }
/*     */   
/*     */   public String getLabel()
/*     */   {
/* 110 */     return this.label;
/*     */   }
/*     */   
/*     */   public String getId()
/*     */   {
/* 115 */     return this.id;
/*     */   }
/*     */   
/*     */   public long getCreationTime()
/*     */   {
/* 120 */     return this.creationTime;
/*     */   }
/*     */   
/*     */   public long getCloseTime()
/*     */   {
/* 125 */     return this.closeTime;
/*     */   }
/*     */   
/*     */   public IEngine.OrderCommand getOrderCommand()
/*     */   {
/* 130 */     return this.orderCommand;
/*     */   }
/*     */   
/*     */   public boolean isLong()
/*     */   {
/* 135 */     return (this.orderCommand != null) && (this.orderCommand.isLong());
/*     */   }
/*     */   
/*     */   public long getFillTime()
/*     */   {
/* 140 */     return this.fillTime;
/*     */   }
/*     */   
/*     */   public double getAmount()
/*     */   {
/* 145 */     return this.filledAmount;
/*     */   }
/*     */   
/*     */   public double getRequestedAmount()
/*     */   {
/* 150 */     return this.filledAmount;
/*     */   }
/*     */   
/*     */   public double getOpenPrice()
/*     */   {
/* 155 */     return this.openPrice;
/*     */   }
/*     */   
/*     */   public double getClosePrice()
/*     */   {
/* 160 */     return this.closePrice;
/*     */   }
/*     */   
/*     */   public double getStopLossPrice()
/*     */   {
/* 165 */     return this.stopLossPrice;
/*     */   }
/*     */   
/*     */   public double getTakeProfitPrice()
/*     */   {
/* 170 */     return this.takeProfitPrice;
/*     */   }
/*     */   
/*     */   public void setStopLossPrice(double price) throws JFException
/*     */   {
/* 175 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void setStopLossPrice(double price, OfferSide side)
/*     */     throws JFException
/*     */   {
/* 181 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void setStopLossPrice(double price, OfferSide side, double trailingStep)
/*     */     throws JFException
/*     */   {
/* 187 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public OfferSide getStopLossSide()
/*     */   {
/* 192 */     return null;
/*     */   }
/*     */   
/*     */   public double getTrailingStep()
/*     */   {
/* 197 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public void setTakeProfitPrice(double price) throws JFException
/*     */   {
/* 202 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void setTakeProfit(double price) throws JFException
/*     */   {
/* 207 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public String getComment()
/*     */   {
/* 212 */     return this.comment;
/*     */   }
/*     */   
/*     */   public void setRequestedAmount(double amount) throws JFException
/*     */   {
/* 217 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void setOpenPrice(double price) throws JFException
/*     */   {
/* 222 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void close(double amount, double price, double slippage) throws JFException
/*     */   {
/* 227 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void close(double amount, double price) throws JFException
/*     */   {
/* 232 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void close(double amount) throws JFException
/*     */   {
/* 237 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void close() throws JFException
/*     */   {
/* 242 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public IOrder.State getState()
/*     */   {
/* 247 */     return IOrder.State.CLOSED;
/*     */   }
/*     */   
/*     */   public void setGoodTillTime(long goodTillTime) throws JFException
/*     */   {
/* 252 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public void setLabel(String label) throws JFException
/*     */   {
/* 257 */     throw new JFException("Can't change historical order");
/*     */   }
/*     */   
/*     */   public long getGoodTillTime()
/*     */   {
/* 262 */     return 0L;
/*     */   }
/*     */   
/*     */   public double getOriginalAmount()
/*     */   {
/* 267 */     return this.originalAmount;
/*     */   }
/*     */   
/*     */ 
/*     */   public void waitForUpdate(long timeoutMills) {}
/*     */   
/*     */ 
/*     */   public IMessage waitForUpdate(long timeout, TimeUnit unit)
/*     */   {
/* 276 */     return null;
/*     */   }
/*     */   
/*     */   public IMessage waitForUpdate(IOrder.State... states) throws JFException
/*     */   {
/* 281 */     return null;
/*     */   }
/*     */   
/*     */   public IMessage waitForUpdate(long timeoutMills, IOrder.State... states) throws JFException
/*     */   {
/* 286 */     return null;
/*     */   }
/*     */   
/*     */   public IMessage waitForUpdate(long timeout, TimeUnit unit, IOrder.State... states) throws JFException
/*     */   {
/* 291 */     return null;
/*     */   }
/*     */   
/*     */   public double getProfitLossInPips()
/*     */   {
/* 296 */     double closePrice = this.closePrice;
/*     */     double plInPips;
/* 298 */     double plInPips; if (isLong()) {
/* 299 */       plInPips = StratUtils.roundHalfEven((closePrice - this.openPrice) / this.instrument.getPipValue(), 1);
/*     */     } else {
/* 301 */       plInPips = StratUtils.roundHalfEven((this.openPrice - closePrice) / this.instrument.getPipValue(), 1);
/*     */     }
/* 303 */     return plInPips;
/*     */   }
/*     */   
/*     */   public double getProfitLossInUSD()
/*     */   {
/* 308 */     double commoditiesPerContract = InstrumentUtils.getCommoditiesPerContract(this.instrument.toString()).doubleValue();
/* 309 */     double commoditiesAmount = this.filledAmount * commoditiesPerContract;
/* 310 */     double profLossInSecondaryCCY = StratUtils.roundHalfEven(getProfitLossInPips() * this.instrument.getPipValue() * commoditiesAmount * 1000000.0D, 2);
/* 311 */     return StratUtils.roundHalfEven(getCurrencyConverter().convert(profLossInSecondaryCCY, this.instrument.getSecondaryJFCurrency(), Instrument.EURUSD.getSecondaryJFCurrency(), null), 2);
/*     */   }
/*     */   
/*     */   protected AbstractCurrencyConverter getCurrencyConverter() {
/* 315 */     return CurrencyConverter.getCurrencyConverter();
/*     */   }
/*     */   
/*     */   public double getProfitLossInAccountCurrency()
/*     */   {
/* 320 */     double commoditiesPerContract = InstrumentUtils.getCommoditiesPerContract(this.instrument.toString()).doubleValue();
/* 321 */     double commoditiesAmount = this.filledAmount * commoditiesPerContract;
/* 322 */     double profLossInSecondaryCCY = StratUtils.roundHalfEven(getProfitLossInPips() * this.instrument.getPipValue() * commoditiesAmount * 1000000.0D, 2);
/* 323 */     return StratUtils.roundHalfEven(getCurrencyConverter().convert(profLossInSecondaryCCY, this.instrument.getSecondaryJFCurrency(), this.accountCurrency, null), 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getCommissionInUSD()
/*     */   {
/* 331 */     return StratUtils.roundHalfEven(getCurrencyConverter().convert(this.commission, this.accountCurrency, Instrument.EURUSD.getSecondaryJFCurrency(), null), 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getCommission()
/*     */   {
/* 339 */     return StratUtils.roundHalfEven(this.commission, 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<IFillOrder> getFillHistory()
/*     */   {
/* 347 */     return ObjectUtils.getSortedCopyList(this.fillHistory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ICloseOrder> getCloseHistory()
/*     */   {
/* 355 */     return ObjectUtils.getSortedCopyList(this.closeHistory);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 361 */     String str = "[" + getLabel() + "]-" + "Instrument: " + getInstrument() + ", order command: " + this.orderCommand + ", amount: " + getAmount() + ", fill time: " + DateUtils.format(this.fillTime) + ", fill price " + getOpenPrice() + ", close time: " + DateUtils.format(this.closeTime) + ", close price " + getClosePrice();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */     return str;
/*     */   }
/*     */   
/*     */   public boolean compare(IOrder order)
/*     */   {
/* 388 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\HistoryOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */