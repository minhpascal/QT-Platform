/*     */ package com.dukascopy.charts.data.datacache.ccheck;
/*     */ 
/*     */ import com.dukascopy.api.DataType;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.feed.FeedDescriptor;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.LocalCacheManager;
/*     */ import com.dukascopy.charts.data.datacache.MergedTimeIntervalList;
/*     */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.TimeInterval;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.nio.channels.OverlappingFileLockException;
/*     */ import java.nio.file.Files;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MissingFileEntryManager
/*     */ {
/*  51 */   private static final Logger LOGGER = LoggerFactory.getLogger(MissingFileEntryManager.class);
/*     */   
/*     */   public static final int MISSING_FILE_RECORD_VERSION = 1;
/*     */   
/*     */   public static final String MISSING_FILE_ENTRY_FOLDER_NAME = "mffolder";
/*     */   
/*     */   public static final String MISSING_FILE_ENTRY_FILE_PREFIX = "msfile_";
/*     */   
/*     */   public static final String MISSING_FILE_ENTRY_FILE_SUFFIX = "mfe";
/*     */   public static final String MISSING_FILE_ENTRY_TICK_SUFFIX = "T";
/*     */   public static final String MISSING_FILE_ENTRY_MINUTE_SUFFIX = "M";
/*     */   public static final String MISSING_FILE_ENTRY_HOUR_SUFFIX = "H";
/*     */   public static final String MISSING_FILE_ENTRY_DAY_SUFFIX = "D";
/*     */   public static final int MAX_ENTRIES_IN_ONE_FILE = 1000;
/*     */   private static final int MAX_FILES = 999;
/*     */   private Map<Period, MFFilenameFilter> fileNameFilters;
/*  67 */   private static MFInnerDataComparator comparator = new MFInnerDataComparator();
/*     */   
/*     */   private String cacheFolderStringPath;
/*     */   
/*     */   private IFilterManager filterManager;
/*     */   private IFeedDataProvider feedDataProvider;
/*     */   private static File globalLockFile;
/*     */   protected static FileLock cacheLock;
/*     */   private static MissingFileEntryManager instance;
/*     */   private MissingFileScheduler scheduler;
/*     */   
/*     */   public MissingFileEntryManager(String cachePath, IFeedDataProvider feedDataProvider)
/*     */   {
/*  80 */     this.cacheFolderStringPath = cachePath;
/*  81 */     this.feedDataProvider = feedDataProvider;
/*  82 */     this.filterManager = feedDataProvider.getFilterManager();
/*  83 */     this.fileNameFilters = new HashMap();
/*  84 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  88 */     this.fileNameFilters.put(Period.TICK, new MFFilenameFilter(getMFFolder(), getPeriodSuffix(Period.TICK)));
/*  89 */     this.fileNameFilters.put(Period.ONE_MIN, new MFFilenameFilter(getMFFolder(), getPeriodSuffix(Period.ONE_MIN)));
/*  90 */     this.fileNameFilters.put(Period.ONE_HOUR, new MFFilenameFilter(getMFFolder(), getPeriodSuffix(Period.ONE_HOUR)));
/*  91 */     this.fileNameFilters.put(Period.DAILY, new MFFilenameFilter(getMFFolder(), getPeriodSuffix(Period.DAILY)));
/*     */     
/*  93 */     globalLockFile = new File(getMFFolder().getParentFile(), "mflock.lck");
/*  94 */     instance = this;
/*     */   }
/*     */   
/*     */   public int getNextNewFileNumber(Period period) {
/*  98 */     return getLastFileNumber(period) + 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getLastFileNumber(Period period)
/*     */   {
/* 104 */     int number = 0;
/* 105 */     for (File content : getMFFolderFiles(period)) {
/* 106 */       String filename = content.getName();
/* 107 */       int numStartPosition = "msfile_".length() + 1;
/* 108 */       String numberString = filename.substring(numStartPosition, numStartPosition + 3);
/* 109 */       int fileNum = Integer.parseInt(numberString);
/* 110 */       number = fileNum > number ? fileNum : number;
/*     */     }
/*     */     
/* 113 */     return number;
/*     */   }
/*     */   
/*     */   public boolean doesEntryFileExists()
/*     */   {
/* 118 */     File[] contents = getMFFolderFiles();
/* 119 */     return contents.length > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File[] getMFFolderFiles()
/*     */   {
/* 128 */     return getMFFolderFiles(null);
/*     */   }
/*     */   
/*     */   public File[] getMFFolderFiles(Period period) {
/* 132 */     File mffolder = getMFFolder();
/* 133 */     if ((mffolder.exists()) && (mffolder.isDirectory())) {
/* 134 */       return mffolder.listFiles((FilenameFilter)this.fileNameFilters.get(period));
/*     */     }
/* 136 */     return new File[0];
/*     */   }
/*     */   
/*     */ 
/*     */   public File getMFFolder()
/*     */   {
/* 142 */     StringBuilder folderName = new StringBuilder(this.cacheFolderStringPath);
/*     */     
/* 144 */     if (!this.cacheFolderStringPath.endsWith(File.separator)) {
/* 145 */       folderName.append(File.separator);
/*     */     }
/* 147 */     folderName.append("mffolder");
/*     */     
/* 149 */     File result = new File(folderName.toString());
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   public int getNumOfRowsOfMFFile(File mffile)
/*     */     throws IOException
/*     */   {
/* 156 */     if (mffile.length() == 0L) {
/* 157 */       return 0;
/*     */     }
/*     */     
/* 160 */     LineNumberReader lineReader = new LineNumberReader(new FileReader(mffile));Throwable localThrowable2 = null;
/* 161 */     try { lineReader.skip(2147483647L);
/* 162 */       int lines = lineReader.getLineNumber();
/* 163 */       return lines + 1;
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 160 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */     }
/*     */     finally
/*     */     {
/* 164 */       if (lineReader != null) if (localThrowable2 != null) try { lineReader.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else lineReader.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private String getPeriodSuffix(Period period) {
/* 169 */     if (Period.TICK.equals(period)) {
/* 170 */       return "T";
/*     */     }
/* 172 */     if (Period.ONE_MIN.equals(period)) {
/* 173 */       return "M";
/*     */     }
/* 175 */     if (Period.ONE_HOUR.equals(period)) {
/* 176 */       return "H";
/*     */     }
/* 178 */     if (Period.DAILY.equals(period)) {
/* 179 */       return "D";
/*     */     }
/* 181 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File appendFileWithEntry(MFEntry entry, Period period)
/*     */     throws IOException, DataCacheException
/*     */   {
/* 196 */     long requestStartTime = System.currentTimeMillis();
/* 197 */     boolean gotLock = false;
/*     */     try {
/* 199 */       while ((!(gotLock = requestGlobalLock())) && (System.currentTimeMillis() - requestStartTime < 600000L)) {
/*     */         try
/*     */         {
/* 202 */           Thread.sleep(100L);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/* 206 */       if (!gotLock) {
/* 207 */         LOGGER.warn("couldn't get a lock on mffolder within 10 minutes! Probably taken by another instance.");
/*     */       }
/*     */       else {
/* 210 */         return appendFileWithEntries(new MFEntry[] { entry }, period);
/*     */       }
/*     */     }
/*     */     finally {
/* 214 */       if (gotLock) {
/* 215 */         releaseGlobalLock();
/*     */       }
/*     */     }
/*     */     
/* 219 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File appendFileWithEntries(MFEntry[] entries, Period period)
/*     */     throws IOException, DataCacheException
/*     */   {
/* 234 */     List<MFEntry> alreadyAdded = new ArrayList();
/*     */     
/* 236 */     for (MFEntry entry : entries) {
/* 237 */       Map<File, Integer> entryExistsFile = isEntryAlreadyExists(period, entry);
/* 238 */       if (entryExistsFile != null) {
/* 239 */         alreadyAdded.add(entry);
/*     */       }
/*     */     }
/*     */     
/* 243 */     List<MFEntry> entriesList = new ArrayList();
/* 244 */     entriesList.addAll(Arrays.asList(entries));
/* 245 */     entriesList.removeAll(alreadyAdded);
/*     */     
/* 247 */     if (entriesList.isEmpty()) {
/* 248 */       return null;
/*     */     }
/*     */     
/* 251 */     Collections.sort(entriesList, comparator);
/*     */     
/* 253 */     File appendFile = null;
/* 254 */     while (!entriesList.isEmpty())
/*     */     {
/* 256 */       appendFile = getFileForAppend(period);
/*     */       
/* 258 */       if (!appendFile.exists()) {
/* 259 */         appendFile.getParentFile().mkdirs();
/* 260 */         appendFile.createNewFile();
/*     */       }
/*     */       
/* 263 */       List<MFEntry> allLinesList = readAllEntriesFromFile(appendFile);
/*     */       
/* 265 */       int space = 1000 - allLinesList.size();
/* 266 */       int loop = Math.min(space, entriesList.size());
/* 267 */       for (int x = 0; x < loop; x++) {
/* 268 */         allLinesList.add(entriesList.remove(0));
/*     */       }
/*     */       
/* 271 */       Collections.sort(allLinesList, comparator);
/*     */       
/*     */ 
/* 274 */       writeEntriesToFile((MFEntry[])allLinesList.toArray(new MFEntry[allLinesList.size()]), appendFile);
/*     */     }
/* 276 */     return appendFile;
/*     */   }
/*     */   
/*     */   public boolean removeFileEntry(MFEntry entry, File file) throws IOException, DataCacheException {
/* 280 */     List<MFEntry> allLinesList = readAllEntriesFromFile(file);
/* 281 */     boolean removed = allLinesList.remove(entry);
/* 282 */     writeEntriesToFile((MFEntry[])allLinesList.toArray(new MFEntry[allLinesList.size()]), file);
/* 283 */     return removed;
/*     */   }
/*     */   
/*     */   private List<MFEntry> readAllEntriesFromFile(File file)
/*     */     throws IOException, DataCacheException
/*     */   {
/* 289 */     List<MFEntry> allLinesList = new ArrayList();
/*     */     
/* 291 */     String[] allLines = readAllLines(file);
/* 292 */     for (String line : allLines) {
/* 293 */       MFEntry entryn = MFEntry.fromString(line);
/* 294 */       allLinesList.add(entryn);
/*     */     }
/*     */     
/* 297 */     return allLinesList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeEntriesToFile(MFEntry[] array, File file)
/*     */     throws IOException
/*     */   {
/* 306 */     PrintWriter pw = new PrintWriter(file);Throwable localThrowable2 = null;
/*     */     try {
/* 308 */       if (!file.exists()) {
/* 309 */         file.createNewFile();
/*     */       }
/*     */       
/* 312 */       for (int x = 0; x < array.length; x++) {
/* 313 */         String line = array[x].toString();
/* 314 */         if (x == array.length - 1) {
/* 315 */           pw.print(line);
/*     */         }
/*     */         else {
/* 318 */           pw.println(line);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 306 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 321 */       if (pw != null) if (localThrowable2 != null) try { pw.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else pw.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private File getFileForAppend(Period period)
/*     */     throws IOException
/*     */   {
/* 328 */     File[] files = getMFFolderFiles(period);
/*     */     
/* 330 */     for (File f : files)
/*     */     {
/* 332 */       int rowCount = getNumOfRowsOfMFFile(f);
/* 333 */       if (rowCount < 1000) {
/* 334 */         return f;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 339 */     int nextFileNum = getNextNewFileNumber(period);
/* 340 */     if (nextFileNum > 999) {
/* 341 */       LOGGER.warn("Cannot save missing file! Too many missing file entries! Max allowed number of missing files is 999");
/* 342 */       return null;
/*     */     }
/*     */     
/* 345 */     File result = createNewFileForAppend(period, nextFileNum);
/* 346 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private File createNewFileForAppend(Period period, int nextFileNum)
/*     */   {
/* 352 */     File folder = getMFFolder();
/* 353 */     StringBuilder sb = new StringBuilder(folder.toString());
/* 354 */     sb.append(File.separator);
/* 355 */     sb.append(getPeriodSuffix(period)).append("msfile_").append(nextFileNum < 100 ? "0" : nextFileNum < 10 ? "00" : "").append(nextFileNum).append(".").append("mfe").append(1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */     File file = new File(sb.toString());
/* 364 */     return file;
/*     */   }
/*     */   
/*     */   private MFEntry getFirstEntryOfFile(FileReader reader) throws DataCacheException, IOException {
/* 368 */     BufferedReader br = new BufferedReader(reader);
/* 369 */     MFEntry entry = MFEntry.fromString(br.readLine());
/* 370 */     return entry;
/*     */   }
/*     */   
/*     */   private MFEntry getLastEntryOfFile(File file) throws IOException, DataCacheException
/*     */   {
/* 375 */     int numOfLines = getNumOfRowsOfMFFile(file);
/*     */     
/* 377 */     MFEntry result = null;
/*     */     
/* 379 */     BufferedReader br = new BufferedReader(new FileReader(file));Throwable localThrowable2 = null;
/*     */     try {
/* 381 */       for (int x = 0; x < numOfLines - 1; x++) {
/* 382 */         br.readLine();
/*     */       }
/* 384 */       String lastLine = br.readLine();
/* 385 */       result = MFEntry.fromString(lastLine);
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 379 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 386 */       if (br != null) if (localThrowable2 != null) try { br.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else br.close();
/*     */     }
/* 388 */     return result;
/*     */   }
/*     */   
/*     */   public Map<File, Integer> isEntryAlreadyExists(Period period, MFEntry entry)
/*     */     throws IOException, DataCacheException
/*     */   {
/* 394 */     File[] files = getMFFolderFiles(period);
/* 395 */     if (files.length == 0) {
/* 396 */       return null;
/*     */     }
/*     */     
/* 399 */     for (File file : files)
/*     */     {
/*     */ 
/* 402 */       boolean isWorthToCheck = false;
/* 403 */       if (file.length() > 0L) {
/* 404 */         FileReader reader = new FileReader(file);Throwable localThrowable2 = null;
/*     */         try {
/* 406 */           MFEntry firstEntry = getFirstEntryOfFile(reader);
/* 407 */           MFEntry lastEntry = getLastEntryOfFile(file);
/*     */           long fileTo;
/* 409 */           if ((firstEntry != null) && (lastEntry != null)) {
/* 410 */             long fileFrom = firstEntry.getChunkTime();
/* 411 */             fileTo = lastEntry.getChunkTime();
/*     */             
/* 413 */             if ((entry.getChunkTime() >= fileFrom) && (entry.getChunkTime() <= fileTo)) { Map<File, Integer> localMap1;
/* 414 */               if (entry.equals(firstEntry)) {
/* 415 */                 Map<File, Integer> result = new HashMap();
/* 416 */                 result.put(file, new Integer(0));
/* 417 */                 return result;
/*     */               }
/* 419 */               if (entry.equals(lastEntry)) {
/* 420 */                 Map<File, Integer> result = new HashMap();
/* 421 */                 result.put(file, new Integer(getNumOfRowsOfMFFile(file) - 1));
/* 422 */                 return result;
/*     */               }
/* 424 */               isWorthToCheck = true;
/*     */             }
/*     */           }
/*     */           
/* 428 */           if (isWorthToCheck)
/*     */           {
/* 430 */             int lineNrInFile = isEntryExists(entry, file);
/* 431 */             if (lineNrInFile >= 0) {
/* 432 */               Map<File, Integer> result = new HashMap();
/* 433 */               result.put(file, new Integer(lineNrInFile));
/* 434 */               return result;
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 404 */           localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 437 */           if (reader != null) if (localThrowable2 != null) try { reader.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else reader.close();
/*     */         }
/*     */       }
/*     */     }
/* 441 */     return null;
/*     */   }
/*     */   
/*     */   private String[] readAllLines(File file)
/*     */     throws IOException
/*     */   {
/* 447 */     List<String> resultList = new ArrayList();
/* 448 */     BufferedReader br = new BufferedReader(new FileReader(file));Throwable localThrowable2 = null;
/* 449 */     try { if ((file.exists()) && (file.isFile())) {
/* 450 */         String line = null;
/* 451 */         while ((line = br.readLine()) != null) {
/* 452 */           resultList.add(line);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 448 */       localThrowable2 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 455 */       if (br != null) if (localThrowable2 != null) try { br.close(); } catch (Throwable x2) { localThrowable2.addSuppressed(x2); } else br.close();
/*     */     }
/* 457 */     return (String[])resultList.toArray(new String[resultList.size()]);
/*     */   }
/*     */   
/*     */   private int isEntryExists(MFEntry entry, File file)
/*     */     throws DataCacheException, IOException
/*     */   {
/* 463 */     int numOfLines = getNumOfRowsOfMFFile(file);
/*     */     
/* 465 */     String[] allLines = readAllLines(file);
/*     */     
/* 467 */     int middleLineNr = numOfLines / 2 - (numOfLines % 2 == 0 ? 1 : 0);
/* 468 */     int previousMiddleLineNr = -1;
/*     */     
/* 470 */     MFEntry middleEntry = MFEntry.fromString(allLines[middleLineNr]);
/* 471 */     MFEntry previousEntry = null;
/*     */     
/* 473 */     while (!middleEntry.equals(previousEntry))
/*     */     {
/* 475 */       if (entry.equals(middleEntry)) {
/* 476 */         return middleLineNr;
/*     */       }
/*     */       
/* 479 */       int comp = comparator.compare(entry, middleEntry);
/*     */       
/* 481 */       if (comp < 0) {
/* 482 */         if (middleLineNr == 0) {
/* 483 */           return -1;
/*     */         }
/* 485 */         if (previousMiddleLineNr + 1 == middleLineNr) {
/* 486 */           return -1;
/*     */         }
/*     */         
/* 489 */         int takeLeft = Math.abs(previousMiddleLineNr - middleLineNr) / 2;
/* 490 */         previousMiddleLineNr = middleLineNr;
/* 491 */         middleLineNr -= (takeLeft == 0 ? 1 : takeLeft);
/*     */       }
/* 493 */       else if (comp > 0) {
/* 494 */         if (middleLineNr + 1 == numOfLines) {
/* 495 */           return -1;
/*     */         }
/* 497 */         if (previousMiddleLineNr - 1 == middleLineNr) {
/* 498 */           return -1;
/*     */         }
/*     */         
/* 501 */         int takeRight = Math.abs(previousMiddleLineNr - middleLineNr) / 2;
/* 502 */         previousMiddleLineNr = middleLineNr;
/* 503 */         middleLineNr += (takeRight == 0 ? 1 : takeRight);
/*     */       }
/*     */       
/* 506 */       previousEntry = middleEntry;
/* 507 */       middleEntry = MFEntry.fromString(allLines[middleLineNr]);
/*     */     }
/*     */     
/* 510 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void analyzeAllCache()
/*     */     throws IOException
/*     */   {
/* 519 */     LOGGER.info("Starting to analyze all cache for mffolder.");
/* 520 */     long startTime = System.currentTimeMillis();
/*     */     
/* 522 */     Period[] periods = { Period.TICK, Period.ONE_MIN, Period.ONE_HOUR, Period.DAILY };
/* 523 */     Map<Period, IMFEntryListener> listeners = new HashMap();
/*     */     
/* 525 */     for (Period period : periods) {
/* 526 */       IMFEntryListener listener = new MFEntryListenerImpl(this, period);
/* 527 */       listeners.put(period, listener);
/*     */     }
/* 529 */     MFFileVisitor visitor = new MFFileVisitor(this.filterManager, listeners);
/* 530 */     Files.walkFileTree(getMFFolder().getParentFile().toPath(), visitor);
/*     */     
/* 532 */     for (Map.Entry<Period, IMFEntryListener> entry : listeners.entrySet()) {
/* 533 */       ((IMFEntryListener)entry.getValue()).flush();
/*     */     }
/*     */     
/* 536 */     if (!getMFFolder().exists()) {
/* 537 */       getMFFolder().mkdirs();
/*     */     }
/*     */     
/* 540 */     LOGGER.info("Finished all cache analization for mffolder! Duration [" + (System.currentTimeMillis() - startTime) + "] ms");
/*     */   }
/*     */   
/*     */   public boolean requestGlobalLock()
/*     */   {
/* 545 */     synchronized (MissingFileEntryManager.class) {
/*     */       try {
/* 547 */         RandomAccessFile rAccessFile = new RandomAccessFile(globalLockFile, "rw");
/* 548 */         FileChannel channel = rAccessFile.getChannel();
/*     */         try {
/* 550 */           FileLock lock = channel.tryLock();
/* 551 */           if ((lock != null) && (lock.isValid())) {
/* 552 */             cacheLock = lock;
/* 553 */             return true;
/*     */           }
/* 555 */           channel.close();
/* 556 */           rAccessFile.close();
/*     */ 
/*     */         }
/*     */         catch (OverlappingFileLockException e)
/*     */         {
/* 561 */           channel.close();
/* 562 */           rAccessFile.close();
/*     */         }
/*     */       } catch (IOException e) {
/* 565 */         LOGGER.warn(e.getMessage(), e);
/*     */       }
/* 567 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void releaseGlobalLock()
/*     */   {
/* 573 */     synchronized (MissingFileEntryManager.class) {
/*     */       try {
/* 575 */         if ((cacheLock != null) && (cacheLock.isValid())) {
/* 576 */           cacheLock.release();
/* 577 */           cacheLock.channel().close();
/*     */         }
/*     */       } catch (IOException e) {
/* 580 */         LOGGER.error(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Period extractPeriodFromFilename(File file)
/*     */   {
/* 587 */     String name = file.getName();
/* 588 */     if (name.startsWith("T")) {
/* 589 */       return Period.TICK;
/*     */     }
/* 591 */     if (name.startsWith("M")) {
/* 592 */       return Period.ONE_MIN;
/*     */     }
/* 594 */     if (name.startsWith("H")) {
/* 595 */       return Period.ONE_HOUR;
/*     */     }
/* 597 */     if (name.startsWith("D")) {
/* 598 */       return Period.DAILY;
/*     */     }
/*     */     
/* 601 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void deleteMFEntriesAndChunks(File entryFile, Map<IFeedDescriptor, MergedTimeIntervalList> resultmap)
/*     */   {
/*     */     try
/*     */     {
/* 609 */       List<MFEntry> allEntries = readAllEntriesFromFile(entryFile);
/* 610 */       List<MFEntry> notDeletedEntries = new ArrayList();
/*     */       
/* 612 */       Period period = extractPeriodFromFilename(entryFile);
/*     */       
/* 614 */       for (MFEntry entry : allEntries) {
/*     */         try {
/* 616 */           Instrument instrument = entry.getInstrument();
/* 617 */           OfferSide side = entry.getSide();
/* 618 */           IFeedDescriptor fdescriptor = createFeedDescriptor(instrument, period, side);
/*     */           
/* 620 */           this.feedDataProvider.getLocalCacheManager().deleteDataChunk(instrument, period, side, entry.getChunkTime());
/*     */           
/* 622 */           MergedTimeIntervalList mergedList = (MergedTimeIntervalList)resultmap.get(fdescriptor);
/* 623 */           if (mergedList == null) {
/* 624 */             mergedList = new MergedTimeIntervalList();
/* 625 */             resultmap.put(fdescriptor, mergedList);
/*     */           }
/* 627 */           mergedList.add(new TimeInterval(entry.getChunkTime(), DataCacheUtils.getNextChunkStart(period, entry.getChunkTime()) - 1L));
/*     */         }
/*     */         catch (DataCacheException e) {
/* 630 */           File chunkFile = DataCacheUtils.getChunkFile(entry.getInstrument(), period, entry.getSide(), entry.getChunkTime(), 5, false);
/* 631 */           if (chunkFile.exists()) {
/* 632 */             notDeletedEntries.add(entry);
/*     */           }
/* 634 */           LOGGER.error(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */       
/* 638 */       entryFile.delete();
/*     */       
/* 640 */       if (!notDeletedEntries.isEmpty()) {
/* 641 */         appendFileWithEntries((MFEntry[])notDeletedEntries.toArray(new MFEntry[notDeletedEntries.size()]), period);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 646 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public IFeedDescriptor createFeedDescriptor(Instrument instrument, Period period, OfferSide offerSide) {
/* 651 */     DataType dataType = Period.TICK.equals(period) ? DataType.TICKS : DataType.TIME_PERIOD_AGGREGATION;
/* 652 */     OfferSide side = Period.TICK.equals(period) ? null : offerSide;
/* 653 */     IFeedDescriptor fd = new FeedDescriptor(dataType, instrument, period, side, null, null, null, null);
/* 654 */     return fd;
/*     */   }
/*     */   
/*     */   public MissingFileScheduler getScheduler() {
/* 658 */     return this.scheduler;
/*     */   }
/*     */   
/*     */   public void setScheduler(MissingFileScheduler scheduler) {
/* 662 */     this.scheduler = scheduler;
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 666 */     if (this.scheduler != null) {
/* 667 */       this.scheduler.shutdown();
/*     */     }
/*     */   }
/*     */   
/*     */   public static MissingFileEntryManager getInstance() {
/* 672 */     return instance;
/*     */   }
/*     */   
/*     */   public void processUnloadedChunk(Instrument instrument, Period period, OfferSide side, long chunkStartTime, boolean isLargeFile) {
/* 676 */     FileNotLoadedMFAction action = new FileNotLoadedMFAction(instrument, period, side, chunkStartTime, isLargeFile);
/* 677 */     if (this.scheduler == null) {
/* 678 */       LOGGER.warn("Cannot append missing files entries! Scheduler is null!");
/* 679 */       return;
/*     */     }
/* 681 */     this.scheduler.runChunkNotLoadedAction(action);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MissingFileEntryManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */