/*    */ package com.dukascopy.calculator.graph;
/*    */ 
/*    */ import javax.swing.JMenuItem;
/*    */ 
/*    */ public class Menu extends javax.swing.JMenuBar
/*    */ {
/*    */   private javax.swing.JMenu editMenu;
/*    */   private AxisDialog xAxisDialog;
/*    */   private AxisDialog yAxisDialog;
/*    */   private com.dukascopy.calculator.ReadOnlyCalculatorApplet applet;
/*    */   private Model model;
/*    */   private View view;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Menu(com.dukascopy.calculator.ReadOnlyCalculatorApplet applet, View view, Model model) {
/* 16 */     this.applet = applet;
/* 17 */     this.view = view;
/* 18 */     this.model = model;
/* 19 */     this.editMenu = new javax.swing.JMenu("Edit");
/* 20 */     this.editMenu.setMnemonic('E');
/* 21 */     JMenuItem xAxisItem = new JMenuItem("x-axis");
/* 22 */     this.xAxisDialog = new AxisDialog(applet, view, model.getXAxis(), true, "x axis");
/* 23 */     xAxisItem.addActionListener(this.xAxisDialog);
/* 24 */     xAxisItem.setMnemonic('x');
/* 25 */     this.editMenu.add(xAxisItem);
/* 26 */     JMenuItem yAxisItem = new JMenuItem("y-axis");
/* 27 */     this.yAxisDialog = new AxisDialog(applet, view, model.getYAxis(), false, "y axis");
/* 28 */     yAxisItem.addActionListener(this.yAxisDialog);
/* 29 */     yAxisItem.setMnemonic('y');
/* 30 */     this.editMenu.add(yAxisItem);
/* 31 */     add(this.editMenu);
/*    */     
/*    */ 
/* 34 */     EditMenuAction editMenuAction = new EditMenuAction();
/* 35 */     getInputMap().put(javax.swing.KeyStroke.getKeyStroke(69, 0), editMenuAction.toString());
/*    */     
/*    */ 
/* 38 */     getActionMap().put(editMenuAction.toString(), editMenuAction);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   void updateSizes()
/*    */   {
/* 45 */     if (this.xAxisDialog != null)
/* 46 */       this.xAxisDialog.setBounds();
/* 47 */     if (this.yAxisDialog != null) {
/* 48 */       this.yAxisDialog.setBounds();
/*    */     }
/*    */   }
/*    */   
/*    */   public class EditMenuAction extends javax.swing.AbstractAction
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     
/*    */     public EditMenuAction() {}
/*    */     
/*    */     public void actionPerformed(java.awt.event.ActionEvent actionEvent)
/*    */     {
/* 60 */       System.out.println("Ouch! That hurt.");
/* 61 */       Menu.this.editMenu.doClick(20);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\graph\Menu.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */