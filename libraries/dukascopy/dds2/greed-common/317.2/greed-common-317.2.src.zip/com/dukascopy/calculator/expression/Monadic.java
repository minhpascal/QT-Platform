/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.StringArray;
/*    */ import com.dukascopy.calculator.function.SFunction;
/*    */ 
/*    */ public abstract class Monadic extends Expression
/*    */ {
/*    */   protected final SFunction function;
/*    */   protected Expression expression;
/*    */   
/*    */   public Monadic(SFunction function, Expression expression)
/*    */   {
/* 13 */     this.function = function;
/* 14 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public Product negate() {
/* 18 */     Product p = new Product(this, false);
/* 19 */     return p.negate();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public StringArray toHTMLSubString(int maxChars, int precision, com.dukascopy.calculator.Base base, com.dukascopy.calculator.Notation notation, double polarFactor)
/*    */   {
/* 36 */     StringArray s = new StringArray();
/* 37 */     s.add(this.function.name_array());
/* 38 */     s.addAll(this.expression.toHTMLParenString(maxChars, precision, base, notation, polarFactor));
/*    */     
/* 40 */     return s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public com.dukascopy.calculator.OObject auto_simplify()
/*    */   {
/* 47 */     com.dukascopy.calculator.OObject o = this.expression.auto_simplify();
/* 48 */     if ((o instanceof com.dukascopy.calculator.complex.Complex))
/* 49 */       return this.function.function((com.dukascopy.calculator.complex.Complex)o);
/* 50 */     if ((o instanceof Expression)) {
/* 51 */       return this;
/*    */     }
/* 53 */     return new com.dukascopy.calculator.Error("Function.auto_simplify() error");
/*    */   }
/*    */   
/*    */   public com.dukascopy.calculator.OObject substitute(com.dukascopy.calculator.Substitution substitution) {
/* 57 */     return this.function.function(this.expression.substitute(substitution));
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Monadic.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */