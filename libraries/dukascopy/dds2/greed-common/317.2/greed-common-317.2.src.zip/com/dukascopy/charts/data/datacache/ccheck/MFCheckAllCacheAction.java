/*    */ package com.dukascopy.charts.data.datacache.ccheck;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MFCheckAllCacheAction
/*    */   implements Runnable
/*    */ {
/* 17 */   private static final Logger LOGGER = LoggerFactory.getLogger(MFCheckAllCacheAction.class);
/*    */   private MissingFileEntryManager mfmanager;
/*    */   
/*    */   public MFCheckAllCacheAction(MissingFileEntryManager mfmanager)
/*    */   {
/* 22 */     this.mfmanager = mfmanager;
/*    */   }
/*    */   
/*    */ 
/*    */   public void run()
/*    */   {
/* 28 */     if (this.mfmanager == null) {
/* 29 */       LOGGER.error("Cannot checkout all MissingFileEntryManager is null! FeedDataProvider not yet fully initialized.");
/*    */     }
/*    */     
/* 32 */     long requestStartTime = System.currentTimeMillis();
/* 33 */     boolean gotLock = false;
/*    */     try {
/* 35 */       while ((!(gotLock = this.mfmanager.requestGlobalLock())) && (System.currentTimeMillis() - requestStartTime < 600000L)) {
/*    */         try
/*    */         {
/* 38 */           Thread.sleep(100L);
/*    */         }
/*    */         catch (InterruptedException e) {}
/*    */       }
/* 42 */       if (!gotLock) {
/* 43 */         LOGGER.warn("couldn't get a lock on mffolder within 10 minutes! Probably taken by another instance.");
/*    */       } else {
/*    */         try
/*    */         {
/* 47 */           this.mfmanager.analyzeAllCache();
/*    */         } catch (IOException e) {
/* 49 */           LOGGER.error(e.getMessage(), e);
/*    */         }
/*    */       }
/*    */     }
/*    */     finally {
/* 54 */       if (gotLock) {
/* 55 */         this.mfmanager.releaseGlobalLock();
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 60 */     this.mfmanager.getScheduler().runMFEntryFileCheckoutAndCacheFileDeletionAction();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFCheckAllCacheAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */