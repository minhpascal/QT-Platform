/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadPivotTicksAction
/*    */   extends AbstractLoadCustomTicksFromTicksAction
/*    */ {
/*    */   private final TickFeedListener feedListener;
/*    */   private TickData previousTick;
/*    */   private boolean priceUp;
/* 23 */   private int tickCount = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LoadPivotTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 35 */     super(feedDataProvider, instrument, from, to, loadingProgressListener);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 43 */     this.feedListener = feedListener;
/*    */   }
/*    */   
/*    */   private void tickReceived(TickData tick) {
/* 47 */     if (this.tickCount == 0)
/*    */     {
/* 49 */       this.tickCount += 1;
/*    */     }
/* 51 */     else if (this.tickCount == 1)
/*    */     {
/* 53 */       if ((this.previousTick.getAsk() != tick.getAsk()) || (this.previousTick.getBid() != tick.getBid()))
/*    */       {
/*    */ 
/*    */ 
/* 57 */         this.priceUp = (((this.previousTick.getAsk() < tick.getAsk()) && (this.previousTick.getBid() < tick.getBid())) || ((this.previousTick.getAsk() <= tick.getAsk()) && (this.previousTick.getBid() < tick.getBid())) || ((this.previousTick.getAsk() < tick.getAsk()) && (this.previousTick.getBid() <= tick.getBid())));
/*    */         
/*    */ 
/* 60 */         this.tickCount += 1;
/*    */       }
/*    */     }
/* 63 */     else if (isPriceMovingDirectionChanged(tick)) {
/* 64 */       this.priceUp = (!this.priceUp);
/* 65 */       this.feedListener.newTick(this.instrument, this.previousTick.time, this.previousTick.ask, this.previousTick.bid, this.previousTick.askVol, this.previousTick.bidVol);
/*    */     }
/*    */     
/* 68 */     this.previousTick = tick;
/*    */   }
/*    */   
/*    */   private boolean isPriceMovingDirectionChanged(TickData tick) {
/* 72 */     return ((this.priceUp) && ((this.previousTick.getAsk() > tick.getAsk()) || (this.previousTick.getBid() > tick.getBid()))) || ((!this.priceUp) && ((this.previousTick.getAsk() < tick.getAsk()) || (this.previousTick.getBid() < tick.getBid())));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void tickReceived(long time, double ask, double bid, double askVol, double bidVol)
/*    */   {
/* 85 */     tickReceived(new TickData(time, ask, bid, askVol, bidVol));
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadPivotTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */