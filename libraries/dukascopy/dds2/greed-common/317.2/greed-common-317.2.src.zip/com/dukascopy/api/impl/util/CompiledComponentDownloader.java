/*    */ package com.dukascopy.api.impl.util;
/*    */ 
/*    */ import com.dukascopy.api.IDownloadableStrategy.ComponentType;
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.impl.connect.PlatformType;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompiledComponentDownloader
/*    */   extends ComponentDownloaderUtils
/*    */ {
/* 18 */   private static final Logger LOGGER = LoggerFactory.getLogger(CompiledComponentDownloader.class);
/*    */   private static CompiledComponentDownloader downloaderObject;
/*    */   
/*    */   public static CompiledComponentDownloader getInstance() {
/* 22 */     if (downloaderObject == null) {
/* 23 */       downloaderObject = new CompiledComponentDownloader();
/*    */     }
/* 25 */     return downloaderObject;
/*    */   }
/*    */   
/*    */   public byte[] downloadFile(String id, IDownloadableStrategy.ComponentType blockType) throws JFException {
/* 29 */     FileCache fileCache = (FileCache)fileCacheStorage.get(id);
/*    */     
/* 31 */     if ((blockType != IDownloadableStrategy.ComponentType.BLOCK_INDICATOR) && 
/* 32 */       (fileCache != null) && (fileCache.getCompiledCache() != null)) {
/* 33 */       if (isVFStrategyUpdatedOnTheServer(id, false)) {
/* 34 */         LOGGER.info("The '" + fileCache.getFileName() + "' strategy updating ...");
/* 35 */         fileCache.setCompiledCache(null);
/*    */       } else {
/* 37 */         return fileCache.getCompiledCache();
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 42 */     return getComponentFromServer(id, blockType, fileCache);
/*    */   }
/*    */   
/*    */   private byte[] getComponentFromServer(String id, IDownloadableStrategy.ComponentType blockType, FileCache fileCache) throws JFException {
/* 46 */     Date modifiedTime = null;
/* 47 */     if (fileCache != null) {
/* 48 */       modifiedTime = fileCache.getLastBinaryModifyTime();
/*    */     }
/* 50 */     String params = prepeareParamsForHttpRequest(blockType, modifiedTime != null);
/* 51 */     byte[] component = readComponentAsByteFromServer(id, params, modifiedTime);
/* 52 */     if ((component != null) && (component.length > 0)) {
/* 53 */       this.currentFileCache.setCompiledCache(component);
/* 54 */       this.currentFileCache.setLastBinaryModifyTime(this.strategyModifyDate);
/*    */       
/*    */ 
/* 57 */       if ((fileCache != null) && (fileCache.getSourceCache() != null)) {
/* 58 */         this.currentFileCache.setSourceCache(fileCache.getSourceCache());
/* 59 */         this.currentFileCache.setLastSourceModifyTime(fileCache.getLastSourceModifyTime());
/*    */       }
/* 61 */       fileCacheStorage.put(id, this.currentFileCache);
/*    */     }
/* 63 */     else if ((fileCache != null) && (fileCache.getCompiledCache() != null)) {
/* 64 */       component = fileCache.getCompiledCache();
/*    */     }
/*    */     
/* 67 */     return component;
/*    */   }
/*    */   
/*    */   private String prepeareParamsForHttpRequest(IDownloadableStrategy.ComponentType blockType, boolean isModifiedTimeSpecified) {
/*    */     String paramsForHttpRequest;
/*    */     String paramsForHttpRequest;
/* 73 */     if (runningMode.equals(PlatformType.JSS)) { String paramsForHttpRequest;
/* 74 */       if (blockType == IDownloadableStrategy.ComponentType.BLOCK_OWN_STRATEGY) {
/* 75 */         paramsForHttpRequest = isModifiedTimeSpecified ? "protected/getProtectedUserStrategy?id={0}&login={1}&modifyDate={2}" : "protected/getProtectedUserStrategy?id={0}&login={1}";
/*    */       } else
/* 77 */         paramsForHttpRequest = isModifiedTimeSpecified ? "protected/getProtectedCompiledFilePlatform?id={0}&login={1}&modifyDate={2}" : "protected/getProtectedCompiledFilePlatform?id={0}&login={1}";
/*    */     } else {
/*    */       String paramsForHttpRequest;
/* 80 */       if (blockType == IDownloadableStrategy.ComponentType.BLOCK_OWN_STRATEGY) {
/* 81 */         paramsForHttpRequest = isModifiedTimeSpecified ? "getUserStrategy?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}" : "getUserStrategy?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
/*    */       } else {
/* 83 */         paramsForHttpRequest = isModifiedTimeSpecified ? "getCompiledFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}" : "getCompiledFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
/*    */       }
/*    */     }
/* 86 */     return paramsForHttpRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\CompiledComponentDownloader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */