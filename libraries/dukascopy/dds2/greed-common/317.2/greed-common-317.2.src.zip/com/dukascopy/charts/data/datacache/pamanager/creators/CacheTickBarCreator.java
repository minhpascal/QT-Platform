/*    */ package com.dukascopy.charts.data.datacache.pamanager.creators;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.TickBarSize;
/*    */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*    */ import com.dukascopy.charts.data.datacache.tickbar.ITickBarLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.tickbar.TickBarCreator;
/*    */ import com.dukascopy.charts.data.datacache.tickbar.TickBarData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheTickBarCreator
/*    */   extends TickBarCreator
/*    */ {
/*    */   private ITickBarLiveFeedListener cacheFeedListener;
/*    */   
/*    */   public CacheTickBarCreator(Instrument instrument, OfferSide offerSide, JForexPeriod jfPeriod, ITickBarLiveFeedListener cacheFeedListener, boolean fromTheBeginningOfTheHistory)
/*    */   {
/* 31 */     super(instrument, jfPeriod.getTickBarSize(), offerSide, -1, true, false, fromTheBeginningOfTheHistory, null);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 41 */     this.cacheFeedListener = cacheFeedListener;
/*    */   }
/*    */   
/*    */   public boolean isAllDesiredDataLoaded()
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 51 */     return 0;
/*    */   }
/*    */   
/*    */   protected void resetResulArray()
/*    */   {
/* 56 */     this.result = new TickBarData[1];
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected TickBarData finishCurrentBar(TickBarData currentBar, TickData data)
/*    */   {
/* 64 */     doFinishCurrentBar(currentBar);
/* 65 */     if (data != null) {
/* 66 */       startNewBar(data);
/*    */     }
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   public void fireNewCacheBarCreated(TickBarData data) {
/* 72 */     this.cacheFeedListener.newPriceData(data);
/*    */   }
/*    */   
/*    */   private AbstractPriceAggregationData finishTickBar(TickBarData bar)
/*    */   {
/* 77 */     bar.setFinishedFromTheEnd(true);
/* 78 */     fireNewCacheBarCreated(bar);
/* 79 */     return bar;
/*    */   }
/*    */   
/*    */   protected TickBarData doFinishCurrentBar(TickBarData currentBar)
/*    */   {
/* 84 */     finishTickBar(currentBar);
/* 85 */     currentBar = null;
/* 86 */     this.currentDataConstructionTicksIncluded = 0L;
/* 87 */     return currentBar;
/*    */   }
/*    */   
/*    */   public void setupLastData(TickBarData data)
/*    */   {
/* 92 */     if ((data.isFinishedFromTheEnd()) || (data.isLastBarInTheBasePeriod()) || (data.getFormedElementsCount() == this.tickBarSize.getSize())) {
/* 93 */       return;
/*    */     }
/*    */     
/* 96 */     this.lastElementIndex += 1;
/* 97 */     ((TickBarData[])getResult())[getLastElementIndex()] = data;
/* 98 */     this.currentDataConstructionTicksIncluded = data.getFormedElementsCount();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\creators\CacheTickBarCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */