/*     */ package com.dukascopy.api.impl.util;
/*     */ 
/*     */ import com.dukascopy.api.Filter;
/*     */ import com.dukascopy.api.IBar;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.LoadingProgressListener;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.PriceRange;
/*     */ import com.dukascopy.api.ReversalAmount;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.api.feed.IPointAndFigureFeedListener;
/*     */ import com.dukascopy.api.feed.IRangeBarFeedListener;
/*     */ import com.dukascopy.api.feed.IRenkoBarFeedListener;
/*     */ import com.dukascopy.api.feed.ITickBarFeedListener;
/*     */ import com.dukascopy.api.feed.util.PointAndFigureFeedDescriptor;
/*     */ import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
/*     */ import com.dukascopy.api.feed.util.RenkoFeedDescriptor;
/*     */ import com.dukascopy.api.feed.util.TickBarFeedDescriptor;
/*     */ import com.dukascopy.api.impl.History;
/*     */ import com.dukascopy.api.impl.connect.IFeedPointAndFigureListener;
/*     */ import com.dukascopy.api.impl.connect.IFeedRangeBarListener;
/*     */ import com.dukascopy.api.impl.connect.IFeedRenkoListener;
/*     */ import com.dukascopy.api.impl.connect.IFeedTickBarListener;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HistoryUtils
/*     */ {
/*  48 */   private static final Logger LOGGER = LoggerFactory.getLogger(History.class);
/*     */   
/*     */ 
/*     */   public static void throwJFException(Throwable e)
/*     */     throws JFException
/*     */   {
/*     */     Throwable ex;
/*     */     
/*     */     Throwable ex;
/*     */     
/*  58 */     if ((e instanceof PrivilegedActionException)) {
/*  59 */       ex = ((PrivilegedActionException)e).getException();
/*     */     }
/*     */     else {
/*  62 */       ex = e;
/*     */     }
/*  64 */     if ((ex instanceof JFException))
/*  65 */       throw ((JFException)ex);
/*  66 */     if ((ex instanceof IllegalArgumentException))
/*  67 */       throw new JFException(ex.getLocalizedMessage(), ex);
/*  68 */     if ((ex instanceof RuntimeException)) {
/*  69 */       throw ((RuntimeException)ex);
/*     */     }
/*  71 */     LOGGER.error(ex.getMessage(), ex);
/*  72 */     throw new JFException(ex);
/*     */   }
/*     */   
/*     */   public static <T extends IBar, D extends AbstractPriceAggregationData> List<T> convert(List<D> bars)
/*     */   {
/*  77 */     if (bars == null) {
/*  78 */       return null;
/*     */     }
/*     */     
/*  81 */     List<T> result = new ArrayList(bars.size());
/*  82 */     result.addAll(bars);
/*     */     
/*  84 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isIntervalValid(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to)
/*     */   {
/* 104 */     boolean result = isIntervalValid(feedDataProvider, instrument, Period.TICK, from, to);
/* 105 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isIntervalValid(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, long from, long to)
/*     */   {
/* 115 */     long lastKnownTime = feedDataProvider.getCurrentTime(instrument);
/* 116 */     long firstKnownTime = feedDataProvider.getTimeOfFirstCandle(instrument, period);
/*     */     
/* 118 */     if (!period.isTickBasedPeriod()) {
/* 119 */       lastKnownTime = DataCacheUtils.getCandleStartFast(period, lastKnownTime);
/* 120 */       firstKnownTime = DataCacheUtils.getCandleStartFast(period, firstKnownTime);
/*     */     }
/*     */     
/* 123 */     if ((from > to) || (lastKnownTime < to) || (firstKnownTime > from))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 128 */       return false;
/*     */     }
/* 130 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validateTimeInterval(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to)
/*     */     throws JFException
/*     */   {
/* 147 */     validateTimeInterval(feedDataProvider, instrument, Period.TICK, from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validateTimeInterval(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, long from, long to)
/*     */     throws JFException
/*     */   {
/* 157 */     if (!isIntervalValid(feedDataProvider, instrument, period, from, to)) {
/* 158 */       String fromStr = DateUtils.format(from);
/* 159 */       String toStr = DateUtils.format(to);
/*     */       
/* 161 */       throw new JFException("Requested time interval for instrument [" + instrument + "] period [" + period + "], from [" + fromStr + "] to [" + toStr + "] GMT is not valid");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validatePointAndFigureParams(PointAndFigureFeedDescriptor feedDescriptor)
/*     */     throws JFException
/*     */   {
/* 171 */     if ((feedDescriptor.getInstrument() == null) || (feedDescriptor.getOfferSide() == null) || (feedDescriptor.getPriceRange() == null) || (feedDescriptor.getReversalAmount() == null) || (feedDescriptor.getDataInterpolationDescriptor() == null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */       throw new JFException("Params could not be null: Instrument=" + feedDescriptor.getInstrument() + " OfferSide=" + feedDescriptor.getOfferSide() + " PriceRange=" + feedDescriptor.getPriceRange() + " ReversalAmount=" + feedDescriptor.getReversalAmount() + " DataInterpolationDescriptor=" + feedDescriptor.getDataInterpolationDescriptor());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */     validateBasePeriod(feedDescriptor.getPeriod());
/*     */   }
/*     */   
/*     */   private static void validateBasePeriod(Period basePeriod) throws JFException {
/* 190 */     if ((basePeriod == null) || ((!basePeriod.equals(IFeedDescriptor.DEFAULT_BASE_PERIOD)) && (!Period.isInfinity(basePeriod)))) {
/* 191 */       throw new JFException("Base period is null or invalid! Period (basePeriod)=" + basePeriod + ". Base period can be either IFeedDescriptor.DEFAULT_BASE_PERIOD or Period.INFINITY.");
/*     */     }
/*     */   }
/*     */   
/*     */   public static void validatePointAndFigureListeners(IPointAndFigureFeedListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 198 */     if (listener == null) {
/* 199 */       throw new JFException("PointAndFigureFeedListener could not be null");
/*     */     }
/* 201 */     if (loadingProgress == null) {
/* 202 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void validateRangeBarListeners(IRangeBarFeedListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 210 */     if (listener == null) {
/* 211 */       throw new JFException("RangeBarFeedListener could not be null");
/*     */     }
/* 213 */     if (loadingProgress == null) {
/* 214 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void validateRenkoListeners(IRenkoBarFeedListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 222 */     if (listener == null) {
/* 223 */       throw new JFException("RenkoBarFeedListener could not be null");
/*     */     }
/* 225 */     if (loadingProgress == null) {
/* 226 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void validateTickBarListeners(ITickBarFeedListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 234 */     if (listener == null) {
/* 235 */       throw new JFException("TickBarFeedListener could not be null");
/*     */     }
/* 237 */     if (loadingProgress == null) {
/* 238 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void validatePointAndFigureParams(PointAndFigureFeedDescriptor feedDescriptor, IFeedPointAndFigureListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 247 */     validatePointAndFigureParams(feedDescriptor);
/* 248 */     if (listener == null) {
/* 249 */       throw new JFException("PointAndFigureFeedListener could not be null");
/*     */     }
/* 251 */     if (loadingProgress == null) {
/* 252 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */   public static void validateTickBarParams(TickBarFeedDescriptor feedDescriptor)
/*     */     throws JFException
/*     */   {
/* 259 */     if ((feedDescriptor.getInstrument() == null) || (feedDescriptor.getOfferSide() == null) || (feedDescriptor.getTickBarSize() == null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 264 */       throw new JFException("Params could not be null: Instrument=" + feedDescriptor.getInstrument() + " OfferSide=" + feedDescriptor.getOfferSide() + " TickBarSize=" + feedDescriptor.getTickBarSize());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 270 */     validateBasePeriod(feedDescriptor.getPeriod());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void validateTickBarParams(TickBarFeedDescriptor feedDescriptor, IFeedTickBarListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 278 */     validateTickBarParams(feedDescriptor);
/* 279 */     if (listener == null) {
/* 280 */       throw new JFException("TickBarFeedListener could not be null");
/*     */     }
/* 282 */     if (loadingProgress == null) {
/* 283 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void validateRangeBarParams(RangeBarFeedDescriptor feedDescriptor)
/*     */     throws JFException
/*     */   {
/* 291 */     if ((feedDescriptor.getInstrument() == null) || (feedDescriptor.getOfferSide() == null) || (feedDescriptor.getPriceRange() == null) || (feedDescriptor.getDataInterpolationDescriptor() == null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 297 */       throw new JFException("Params could not be null: Instrument=" + feedDescriptor.getInstrument() + " OfferSide=" + feedDescriptor.getOfferSide() + " PriceRange=" + feedDescriptor.getPriceRange() + " DataInterpolationDescriptor=" + feedDescriptor.getDataInterpolationDescriptor());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 304 */     validateBasePeriod(feedDescriptor.getPeriod());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void validateRangeBarParams(RangeBarFeedDescriptor feedDescriptor, IFeedRangeBarListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 312 */     validateRangeBarParams(feedDescriptor);
/* 313 */     if (listener == null) {
/* 314 */       throw new JFException("RangeBarFeedListener could not be null");
/*     */     }
/* 316 */     if (loadingProgress == null) {
/* 317 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */   public static void validateRenkoBarParams(RenkoFeedDescriptor feedDescriptor)
/*     */     throws JFException
/*     */   {
/* 324 */     if ((feedDescriptor.getInstrument() == null) || (feedDescriptor.getOfferSide() == null) || (feedDescriptor.getPriceRange() == null) || (feedDescriptor.getRenkoSession() == null) || (feedDescriptor.getRenkoCreationPoint() == null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */       throw new JFException("Params could not be null: Instrument=" + feedDescriptor.getInstrument() + " OfferSide=" + feedDescriptor.getOfferSide() + " PriceRange=" + feedDescriptor.getPriceRange() + " Period (renko session)=" + feedDescriptor.getRenkoSession());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 338 */     if ((!Period.TICK.equals(feedDescriptor.getRenkoSession())) && (feedDescriptor.getRenkoCreationPoint() == null)) {
/* 339 */       throw new JFException("Renko creation point cannot be null, if session is other than Period.TICK! Received renko creation point=" + feedDescriptor.getRenkoCreationPoint());
/*     */     }
/* 341 */     validateBasePeriod(feedDescriptor.getPeriod());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void validateRenkoBarParams(RenkoFeedDescriptor feedDescriptor, IFeedRenkoListener listener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 349 */     validateRenkoBarParams(feedDescriptor);
/* 350 */     if (listener == null) {
/* 351 */       throw new JFException("RenkoBarFeedListener could not be null");
/*     */     }
/* 353 */     if (loadingProgress == null) {
/* 354 */       throw new JFException("LoadingProgressListener could not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validateBeforeTimeAfter(IFeedDataProvider feedDataProvider, Instrument instrument, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*     */     throws JFException
/*     */   {
/* 365 */     if (numberOfBarsBefore < 0) {
/* 366 */       throw new JFException("NumberOfBarsBefore must be >= 0");
/*     */     }
/* 368 */     if (numberOfBarsAfter < 0) {
/* 369 */       throw new JFException("NumberOfBarsAfter must be >= 0");
/*     */     }
/*     */     
/* 372 */     long lastKnownTime = feedDataProvider.getCurrentTime(instrument);
/* 373 */     long firstKnownTime = feedDataProvider.getTimeOfFirstCandle(instrument, Period.TICK);
/*     */     
/* 375 */     if ((lastKnownTime < time) || (firstKnownTime > time)) {
/* 376 */       String msg = "Passed Time [" + DateUtils.format(time) + "] has to be in interval [" + DateUtils.format(firstKnownTime) + "; " + DateUtils.format(lastKnownTime) + "]";
/*     */       
/*     */ 
/* 379 */       throw new JFException(msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validateRequestTimeForCandleLoading(IFeedDataProvider feedDataProvider, Instrument instrument, Period desiredPeriod, int numberOfCandlesBefore, long time, int numberOfCandlesAfter)
/*     */     throws JFException
/*     */   {
/* 392 */     long firstTime = getFirstTime(feedDataProvider, instrument, desiredPeriod);
/*     */     
/* 394 */     if (time < firstTime) {
/* 395 */       throw new JFException("Cannot load candles before first possible time. First possible time " + DateUtils.format(firstTime) + "[" + firstTime + "], request time " + DateUtils.format(time) + "[" + time + "]");
/*     */     }
/*     */     
/* 398 */     long loadFromTime = DataCacheUtils.getTimeForNCandlesBackFast(desiredPeriod, time, numberOfCandlesBefore);
/* 399 */     if (loadFromTime < firstTime) {
/* 400 */       throw new JFException("Cannot load candles before first possible time. First possible time " + DateUtils.format(firstTime) + "[" + firstTime + "], the request time for num of candles before is at least from " + DateUtils.format(loadFromTime) + "[" + loadFromTime + "]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validateRequestTimeForCandleLoading(IFeedDataProvider feedDataProvider, Instrument instrument, Period desiredPeriod, long fromTime, long toTime)
/*     */     throws JFException
/*     */   {
/* 413 */     long firstTime = getFirstTime(feedDataProvider, instrument, desiredPeriod);
/*     */     
/* 415 */     if (toTime < firstTime) {
/* 416 */       throw new JFException("Cannot load candles before first possible time. First possible time " + DateUtils.format(firstTime) + "[" + firstTime + "], requested 'to' time " + DateUtils.format(toTime) + "[" + toTime + "]");
/*     */     }
/*     */     
/*     */ 
/* 420 */     if (fromTime < firstTime) {
/* 421 */       throw new JFException("Cannot load candles before first possible time. First possible time " + DateUtils.format(firstTime) + "[" + firstTime + "], requested 'from' time " + DateUtils.format(fromTime) + "[" + fromTime + "]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static long getFirstTime(IFeedDataProvider feedDataProvider, Instrument instrument, Period period)
/*     */   {
/* 428 */     long firstTime = feedDataProvider.getTimeOfFirstCandle(instrument, period);
/* 429 */     if (Period.TICK.equals(period)) {
/* 430 */       return firstTime;
/*     */     }
/*     */     
/* 433 */     return DataCacheUtils.getCandleStartFast(period, firstTime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long correctRequestTime(long time, PriceRange priceRange, ReversalAmount reversalAmount, DataInterpolationDescriptor interpolationDescriptor)
/*     */   {
/* 443 */     Period period = interpolationDescriptor.getInterpolateFromPeriod(priceRange, reversalAmount);
/* 444 */     return correctRequestTime(period, time);
/*     */   }
/*     */   
/*     */   public static long correctRequestTime(Period period, long time) {
/* 448 */     long value = Period.TICK.equals(period) ? time : DataCacheUtils.getCandleStartFast(period, time);
/*     */     
/*     */ 
/*     */ 
/* 452 */     return value;
/*     */   }
/*     */   
/*     */   public static long correctRequestTime(long time, PriceRange priceRange, DataInterpolationDescriptor interpolationDescriptor) {
/* 456 */     return correctRequestTime(time, priceRange, null, interpolationDescriptor);
/*     */   }
/*     */   
/*     */   public static void validateShift(int shift) throws JFException {
/* 460 */     if (shift < 0) {
/* 461 */       throw new JFException("shift < 0");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T getByShift(Loadable<T> loadable, long inProgressBarTime, int shift)
/*     */     throws Exception
/*     */   {
/* 481 */     int barsCount = 0;
/* 482 */     long from = inProgressBarTime - 1L;
/* 483 */     long to = inProgressBarTime - 1L;
/* 484 */     while (barsCount < shift) {
/* 485 */       from = to - loadable.getStep();
/* 486 */       from = loadable.correctTime(from);
/* 487 */       to = loadable.correctTime(to);
/*     */       
/* 489 */       if (to < loadable.getFirstDataTime()) {
/* 490 */         return null;
/*     */       }
/*     */       
/* 493 */       List<T> bars = loadable.load(from, to);
/*     */       
/* 495 */       if (barsCount + bars.size() < shift) {
/* 496 */         barsCount += bars.size();
/*     */       }
/*     */       else {
/* 499 */         for (int i = bars.size() - 1; i >= 0; i--) {
/* 500 */           T bar = bars.get(i);
/* 501 */           barsCount++;
/* 502 */           if (barsCount == shift) {
/* 503 */             return bar;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 508 */       to = from - 1L;
/*     */     }
/*     */     
/* 511 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validate(Instrument instrument, Period period, OfferSide offerSide, Filter filter)
/*     */     throws JFException
/*     */   {
/* 520 */     if ((instrument == null) || (offerSide == null) || (period == null) || (filter == null)) {
/* 521 */       throw new JFException("Params could not be null: Instrument=" + instrument + " OfferSide=" + offerSide + " Period=" + period + " Filter=" + filter);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface Loadable<T>
/*     */   {
/*     */     public abstract List<T> load(long paramLong1, long paramLong2)
/*     */       throws Exception;
/*     */     
/*     */     public abstract long correctTime(long paramLong);
/*     */     
/*     */     public abstract long getStep();
/*     */     
/*     */     public abstract long getFirstDataTime();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\HistoryUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */