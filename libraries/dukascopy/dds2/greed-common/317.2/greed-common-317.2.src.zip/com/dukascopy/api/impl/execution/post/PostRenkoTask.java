/*    */ package com.dukascopy.api.impl.execution.post;
/*    */ 
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ import com.dukascopy.api.feed.IRenkoBar;
/*    */ import com.dukascopy.api.feed.util.RenkoFeedDescriptor;
/*    */ import com.dukascopy.api.impl.connect.IFeedRenkoListener;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostRenkoTask
/*    */   extends AbstractPostBarTask
/*    */ {
/* 22 */   private static final Logger LOGGER = LoggerFactory.getLogger(PostRenkoTask.class);
/*    */   
/*    */ 
/*    */   private final IFeedRenkoListener barFeedListener;
/*    */   
/*    */ 
/*    */   private final RenkoFeedDescriptor feedDescriptor;
/*    */   
/*    */ 
/*    */   private final IRenkoBar bar;
/*    */   
/*    */ 
/*    */ 
/*    */   public PostRenkoTask(JForexTaskManager<?, ?, ?> taskManager, IJFRunnable<?> strategy, IStrategyExceptionHandler exceptionHandler, RenkoFeedDescriptor feedDescriptor, IFeedRenkoListener barFeedListener, IRenkoBar bar)
/*    */   {
/* 37 */     super(taskManager, strategy, exceptionHandler, feedDescriptor.getInstrument(), feedDescriptor.getOfferSide());
/* 38 */     this.barFeedListener = barFeedListener;
/* 39 */     this.feedDescriptor = feedDescriptor;
/* 40 */     this.bar = bar;
/*    */   }
/*    */   
/*    */   protected Logger getLogger()
/*    */   {
/* 45 */     return LOGGER;
/*    */   }
/*    */   
/*    */   protected void postData() throws Throwable
/*    */   {
/* 50 */     this.barFeedListener.onRenkoBar(this.feedDescriptor, this.bar);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\post\PostRenkoTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */