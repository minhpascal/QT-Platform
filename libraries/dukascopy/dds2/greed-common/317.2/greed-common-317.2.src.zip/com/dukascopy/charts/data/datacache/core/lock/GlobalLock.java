/*     */ package com.dukascopy.charts.data.datacache.core.lock;
/*     */ 
/*     */ import com.dukascopy.charts.data.datacache.core.CacheCoreHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.nio.channels.OverlappingFileLockException;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalLock
/*     */ {
/*  25 */   protected static final Logger LOGGER = LoggerFactory.getLogger(GlobalLock.class);
/*     */   
/*     */   private final long globalLockAcquiringOneIterationTimeoutInMillis;
/*     */   
/*     */   private final int globalLockAcquiringIterationsCount;
/*     */   
/*     */   private final File file;
/*     */   private FileLock lock;
/*     */   private RandomAccessFile randomAccessFile;
/*     */   private FileChannel fileChannel;
/*  35 */   private int lockersCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GlobalLock(File file, long globalLockAcquiringOneIterationTimeoutInMillis, int globalLockAcquiringIterationsCount)
/*     */   {
/*  43 */     this.file = file;
/*  44 */     this.globalLockAcquiringOneIterationTimeoutInMillis = globalLockAcquiringOneIterationTimeoutInMillis;
/*  45 */     this.globalLockAcquiringIterationsCount = globalLockAcquiringIterationsCount;
/*     */     
/*  47 */     if (globalLockAcquiringOneIterationTimeoutInMillis <= 0L) {
/*  48 */       throw new IllegalArgumentException("Invalid value of globalLockAcquiringOneIterationTimeoutInMillis = " + globalLockAcquiringOneIterationTimeoutInMillis);
/*     */     }
/*     */     
/*  51 */     if (globalLockAcquiringIterationsCount <= 0) {
/*  52 */       throw new IllegalArgumentException("Invalid value of globalLockAcquiringIterationsCount = " + globalLockAcquiringIterationsCount);
/*     */     }
/*     */   }
/*     */   
/*     */   public void lock() throws TimeoutException, IOException {
/*  57 */     synchronized (this) {
/*  58 */       if (isLocked()) {
/*  59 */         this.lockersCount += 1;
/*  60 */         return;
/*     */       }
/*     */       
/*  63 */       FileLock lock = null;
/*     */       
/*  65 */       CacheCoreHelper.ensureFileCreated(this.file);
/*     */       
/*  67 */       int waitedCount = 0;
/*     */       
/*  69 */       for (int i = 0; i < this.globalLockAcquiringIterationsCount; i++) {
/*     */         try {
/*  71 */           RandomAccessFile raf = new RandomAccessFile(this.file, "rw");
/*     */           try {
/*  73 */             FileChannel channel = raf.getChannel();
/*     */             try {
/*  75 */               lock = channel.tryLock();
/*     */               
/*  77 */               if (lock != null) {
/*  78 */                 this.fileChannel = channel;
/*  79 */                 this.randomAccessFile = raf;
/*  80 */                 this.lock = lock;
/*     */                 
/*  82 */                 this.lockersCount += 1;
/*     */               }
/*     */               
/*     */             }
/*     */             finally {}
/*     */           }
/*     */           finally
/*     */           {
/*  90 */             if (lock == null) {
/*  91 */               raf.close();
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (OverlappingFileLockException e) {}catch (Throwable t)
/*     */         {
/*  97 */           LOGGER.info("Failed to take lock on file " + this.file + ", have to wait a little bit " + t.getLocalizedMessage());
/*     */         }
/*     */         
/* 100 */         if (lock == null) {
/* 101 */           waitedCount++;
/* 102 */           doWait();
/*     */         }
/*     */         else {
/* 105 */           if (waitedCount <= 0) break;
/* 106 */           LOGGER.info("Lock on file " + this.file + " is finally taken after " + waitedCount + " unsuccessful attempts"); break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 112 */       if (lock == null) {
/* 113 */         throw new TimeoutException("Timeout while waiting for the lock on file " + this.file + " is available");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void doWait() throws TimeoutException {
/*     */     try {
/* 120 */       Thread.sleep(this.globalLockAcquiringOneIterationTimeoutInMillis);
/*     */ 
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */ 
/* 126 */       throw new TimeoutException("Current thread was interrupted while was waiting for the lock on file " + this.file + " is available");
/*     */     }
/*     */   }
/*     */   
/*     */   public void unlock(boolean deleteGlobalLockFile) {
/* 131 */     synchronized (this) {
/* 132 */       if (isLocked()) {
/*     */         try {
/* 134 */           if (this.lockersCount == 1) {
/* 135 */             closeQuiet(this.lock);
/* 136 */             closeQuiet(this.fileChannel);
/* 137 */             closeQuiet(this.randomAccessFile);
/*     */           }
/* 139 */           if (deleteGlobalLockFile) {
/* 140 */             this.file.delete();
/*     */           }
/*     */         } finally {
/* 143 */           this.lockersCount -= 1;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isLocked() {
/* 150 */     synchronized (this) {
/* 151 */       return this.lockersCount > 0;
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeQuiet(AutoCloseable autoCloseable) {
/* 156 */     if (autoCloseable == null) {
/* 157 */       throw new NullPointerException();
/*     */     }
/*     */     try
/*     */     {
/* 161 */       autoCloseable.close();
/*     */     } catch (Throwable t) {
/* 163 */       LOGGER.warn(t.getLocalizedMessage(), t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\lock\GlobalLock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */