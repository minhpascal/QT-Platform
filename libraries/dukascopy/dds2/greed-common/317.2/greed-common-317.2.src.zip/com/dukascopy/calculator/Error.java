/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Error
/*    */   extends OObject
/*    */ {
/*    */   private String s;
/*    */   
/*    */ 
/*    */ 
/*    */   public Error(String s)
/*    */   {
/* 15 */     this.s = s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 23 */     return this.s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\Error.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */