/*     */ package com.dukascopy.charts.data.datacache.core.connection;
/*     */ 
/*     */ import com.dukascopy.charts.data.datacache.core.lock.CacheFileHandler;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheReadConnection
/*     */   extends AbstractCacheConnection
/*     */   implements ICacheReadConnection
/*     */ {
/*  24 */   private static final Logger LOGGER = LoggerFactory.getLogger(CacheReadConnection.class);
/*     */   
/*     */   private RandomAccessFile readRandomAccessFile;
/*     */   private FileInputStream fileInputStream;
/*     */   private FileReader fileReader;
/*     */   
/*     */   public CacheReadConnection(CacheFileHandler cacheFileHandler)
/*     */   {
/*  32 */     super(cacheFileHandler);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*  37 */     close(true);
/*     */   }
/*     */   
/*     */   private void close(boolean performUnlock) {
/*  41 */     super.close();
/*     */     
/*  43 */     if (this.readRandomAccessFile != null) {
/*     */       try {
/*  45 */         this.cacheFileHandler.returnToPool(this.readRandomAccessFile);
/*     */       } catch (Throwable e) {
/*  47 */         LOGGER.error(e.getLocalizedMessage(), e);
/*     */       }
/*     */       
/*  50 */       this.readRandomAccessFile = null;
/*     */     }
/*     */     
/*  53 */     if (this.fileInputStream != null) {
/*     */       try {
/*  55 */         this.fileInputStream.close();
/*     */       } catch (Throwable e) {
/*  57 */         LOGGER.error(e.getLocalizedMessage(), e);
/*     */       }
/*  59 */       this.fileInputStream = null;
/*     */     }
/*     */     
/*  62 */     if (this.fileReader != null) {
/*     */       try {
/*  64 */         this.fileReader.close();
/*     */       } catch (Throwable e) {
/*  66 */         LOGGER.error(e.getLocalizedMessage(), e);
/*     */       }
/*  68 */       this.fileReader = null;
/*     */     }
/*     */     
/*  71 */     if (performUnlock) {
/*  72 */       performReadUnlock();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void performReadUnlock() {
/*  77 */     this.cacheFileHandler.readUnlock();
/*     */   }
/*     */   
/*     */   protected RandomAccessFile doGetRandomAccessFile() throws IOException
/*     */   {
/*  82 */     if (this.readRandomAccessFile == null) {
/*  83 */       this.readRandomAccessFile = this.cacheFileHandler.getCachedRandomAccessFileForRead();
/*     */       
/*  85 */       if (this.readRandomAccessFile != null) {
/*  86 */         this.readRandomAccessFile.seek(0L);
/*     */       }
/*     */     }
/*  89 */     return this.readRandomAccessFile;
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/*  94 */     checkIsActive();
/*     */     
/*  96 */     return getRandomAccessFile().read();
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 101 */     checkIsActive();
/*     */     
/* 103 */     return getRandomAccessFile().read(b, off, len);
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/* 108 */     checkIsActive();
/*     */     
/* 110 */     return getRandomAccessFile().read(b);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException
/*     */   {
/* 115 */     checkIsActive();
/*     */     
/* 117 */     getRandomAccessFile().readFully(b);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException
/*     */   {
/* 122 */     checkIsActive();
/*     */     
/* 124 */     getRandomAccessFile().readFully(b, off, len);
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException
/*     */   {
/* 129 */     checkIsActive();
/*     */     
/* 131 */     return getRandomAccessFile().skipBytes(n);
/*     */   }
/*     */   
/*     */   public boolean readBoolean() throws IOException
/*     */   {
/* 136 */     checkIsActive();
/*     */     
/* 138 */     return getRandomAccessFile().readBoolean();
/*     */   }
/*     */   
/*     */   public byte readByte() throws IOException
/*     */   {
/* 143 */     checkIsActive();
/*     */     
/* 145 */     return getRandomAccessFile().readByte();
/*     */   }
/*     */   
/*     */   public int readUnsignedByte() throws IOException
/*     */   {
/* 150 */     checkIsActive();
/*     */     
/* 152 */     return getRandomAccessFile().readUnsignedByte();
/*     */   }
/*     */   
/*     */   public short readShort() throws IOException
/*     */   {
/* 157 */     checkIsActive();
/*     */     
/* 159 */     return getRandomAccessFile().readShort();
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() throws IOException
/*     */   {
/* 164 */     checkIsActive();
/*     */     
/* 166 */     return getRandomAccessFile().readUnsignedShort();
/*     */   }
/*     */   
/*     */   public char readChar() throws IOException
/*     */   {
/* 171 */     checkIsActive();
/*     */     
/* 173 */     return getRandomAccessFile().readChar();
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException
/*     */   {
/* 178 */     checkIsActive();
/*     */     
/* 180 */     return getRandomAccessFile().readInt();
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException
/*     */   {
/* 185 */     checkIsActive();
/*     */     
/* 187 */     return getRandomAccessFile().readLong();
/*     */   }
/*     */   
/*     */   public float readFloat() throws IOException
/*     */   {
/* 192 */     checkIsActive();
/*     */     
/* 194 */     return getRandomAccessFile().readFloat();
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException
/*     */   {
/* 199 */     checkIsActive();
/*     */     
/* 201 */     return getRandomAccessFile().readDouble();
/*     */   }
/*     */   
/*     */   public String readLine() throws IOException
/*     */   {
/* 206 */     checkIsActive();
/*     */     
/* 208 */     return getRandomAccessFile().readLine();
/*     */   }
/*     */   
/*     */   public String readUTF() throws IOException
/*     */   {
/* 213 */     checkIsActive();
/*     */     
/* 215 */     return getRandomAccessFile().readUTF();
/*     */   }
/*     */   
/*     */   public FileInputStream getFileInputStream() throws FileNotFoundException
/*     */   {
/* 220 */     checkIsActive();
/*     */     
/* 222 */     if (this.fileInputStream == null) {
/* 223 */       checkAndThrowFileNotFound();
/* 224 */       this.fileInputStream = new FileInputStream(this.cacheFileHandler.getFile());
/*     */     }
/* 226 */     return this.fileInputStream;
/*     */   }
/*     */   
/*     */   public FileReader getFileReader() throws FileNotFoundException
/*     */   {
/* 231 */     checkIsActive();
/*     */     
/* 233 */     if (this.fileReader == null) {
/* 234 */       checkAndThrowFileNotFound();
/* 235 */       this.fileReader = new FileReader(this.cacheFileHandler.getFile());
/*     */     }
/* 237 */     return this.fileReader;
/*     */   }
/*     */   
/*     */   public ICacheWriteConnection getChildWriteConnection()
/*     */   {
/* 242 */     checkIsActive();
/*     */     
/* 244 */     close(false);
/*     */     
/* 246 */     this.cacheFileHandler.localReadUnlockWriteLock();
/*     */     
/* 248 */     return new ChildCacheWriteConnection(this.cacheFileHandler, this);
/*     */   }
/*     */   
/*     */   protected void activate() {
/* 252 */     this.isActive = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\CacheReadConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */