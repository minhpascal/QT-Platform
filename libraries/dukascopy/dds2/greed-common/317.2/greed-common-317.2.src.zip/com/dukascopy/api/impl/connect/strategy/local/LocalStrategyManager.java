/*    */ package com.dukascopy.api.impl.connect.strategy.local;
/*    */ 
/*    */ import com.dukascopy.api.ConsoleAdapter;
/*    */ import com.dukascopy.api.IStrategy;
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.impl.connect.strategy.StrategyManager;
/*    */ import com.dukascopy.api.strategy.IStrategyParameter;
/*    */ import com.dukascopy.api.strategy.IStrategyResponse;
/*    */ import com.dukascopy.api.strategy.local.ILocalStrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.local.ILocalStrategyManager;
/*    */ import com.dukascopy.api.strategy.local.LocalStrategyListener;
/*    */ import com.dukascopy.dds2.greed.agent.compiler.JFXCompiler;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.bean.IJFRunnablesListener;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.bean.StrategyNewBean;
/*    */ import com.dukascopy.dds2.greed.util.ParameterUtils;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.security.GeneralSecurityException;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.Future;
/*    */ 
/*    */ public abstract class LocalStrategyManager extends StrategyManager<ILocalStrategyDescriptor, LocalStrategyListener> implements ILocalStrategyManager
/*    */ {
/*    */   protected IJFRunnablesListener jfRunnablesListener;
/*    */   
/*    */   protected LocalStrategyManager()
/*    */   {
/* 29 */     setup();
/*    */   }
/*    */   
/*    */   public Future<IStrategyResponse<UUID>> startStrategy(File strategyFile) throws IOException
/*    */   {
/*    */     try {
/* 35 */       return startStrategy(strategyFile, null);
/*    */     } catch (JFException e) {}
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   public java.util.List<IStrategyParameter> getDefaultParameters(File file) throws IOException, JFException
/*    */   {
/*    */     try
/*    */     {
/* 44 */       StrategyNewBean bean = StrategyNewBean.createRunnableBean(file);
/* 45 */       return ParameterUtils.getParameters((IStrategy)bean.getJFRunnable());
/*    */     } catch (GeneralSecurityException e) {
/* 47 */       throw new JFException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public File compileStrategy(File srcFile)
/*    */   {
/* 53 */     if (srcFile == null) {
/* 54 */       throw new NullPointerException("The passed file is null!");
/*    */     }
/* 56 */     if (!srcFile.exists()) {
/* 57 */       throw new IllegalArgumentException("The file " + srcFile + " does not exist!");
/*    */     }
/* 59 */     if (!srcFile.getAbsolutePath().endsWith(".java")) {
/* 60 */       throw new IllegalArgumentException("The file " + srcFile + " is not a java file!");
/*    */     }
/* 62 */     boolean success = JFXCompiler.getInstance().compile(srcFile, new ConsoleAdapter()
/*    */     {
/*    */       public PrintStream getOut() {
/* 65 */         return System.out;
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 70 */       public PrintStream getErr() { return System.err; } }, false);
/*    */     
/*    */ 
/* 73 */     if (success) {
/* 74 */       new File(srcFile.getAbsolutePath().substring(0, srcFile.getAbsolutePath().lastIndexOf(".java")) + ".jfx");
/*    */     }
/* 76 */     return null;
/*    */   }
/*    */   
/*    */   protected UUID getUUID(long id) {
/* 80 */     return new UUID(id, 0L);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\local\LocalStrategyManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */