/*      */ package com.dukascopy.api.impl.connect;
/*      */ 
/*      */ import com.dukascopy.dds4.common.Base64;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.URLEncoder;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.HttpsURLConnection;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.SwingUtilities;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AuthorizationClient
/*      */ {
/*   47 */   private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationClient.class);
/*      */   
/*      */   private static final String FO_REPORTS_ACTION = "open_reports";
/*      */   
/*      */   private static final String OPEN_CHAT_ACTION = "open_chat";
/*      */   
/*      */   private static final String SSL_IGNORE_ERRORS = "auth.ssl.ignore.errors";
/*      */   
/*      */   private static final String MESSAGE_DIGEST_ENCODING = "iso-8859-1";
/*      */   
/*      */   private static final String MESSAGE_DIGEST_ALGORITHM = "SHA-1";
/*      */   
/*      */   private static final String LOGIN_PARAM = "appello";
/*      */   
/*      */   private static final String PASSWORD_PARAM = "specialis";
/*      */   
/*      */   private static final String CAPTCHA_PARAM = "verbum_id";
/*      */   
/*      */   private static final String PIN_PARAM = "sententia";
/*      */   private static final String CAPTCHA_HEADER = "X-CaptchaID";
/*      */   private static final String VERSION_PARAM = "versio";
/*      */   private static final String INSTANCE_ID_PARAM = "sermo";
/*      */   private static final String TYPE_PARAM = "typus";
/*      */   private static final String PLATFORM_PARAM = "platform";
/*      */   private static final String STNGS_PARAM = "stngs";
/*      */   private static final String REGION_PARAM = "region";
/*      */   private static final String WILL_PING_PARAM = "willPing";
/*      */   private static final String API_MUNUS = "&munus=api&";
/*      */   private static final String RELOGIN_MUNUS = "&munus=relogin&";
/*      */   private static final String DATA_FEED_MUNUS = "&munus=datafeed&";
/*      */   private static final String SETTINGS_MUNUS = "&munus=stngs&";
/*      */   private static final String STS_MUNUS = "munus=sts";
/*      */   public static final String JCLIENT_PLATFORM = "DDS3_JCLIENT";
/*      */   public static final String JFOREX_PLATFORM = "DDS3_JFOREX";
/*      */   public static final String JFOREXSDK_PLATFORM = "DDS3_JFOREXSDK";
/*      */   private static final String AUTH_CONTEXT = "/auth?typus=0&munus=api&";
/*      */   private static final String RELOGIN_AUTH_CONTEXT = "/auth?typus=0&munus=relogin&";
/*      */   private static final String FEED_AUTH_CONTEXT = "/auth?typus=0&munus=datafeed&";
/*      */   private static final String SETTINGS_CONTEXT = "/auth?typus=0&munus=stngs&";
/*      */   private static final String STS_CONTEXT = "auth?munus=sts";
/*      */   private static final String STS_WLBO = "auth?munus=sts_token";
/*      */   public static final String TICKET = "licentio";
/*   89 */   public static final Pattern RESULT_PATTERN = Pattern.compile("(([^:@]+(:\\d+)?)(@([^:@]+(:\\d+)?))*)@([\\dabcdef]{64}+)");
/*      */   
/*      */   public static final int URL_GROUP = 1;
/*      */   
/*      */   public static final int TICKET_GROUP = 7;
/*      */   private static final String LINES_SPLITTER = "##";
/*      */   private final AuthorizationConfigurationPool configurationPool;
/*      */   private final String version;
/*      */   private static AuthorizationClient authClient;
/*      */   
/*      */   public static enum AuthorizationServerResponseCode
/*      */   {
/*  101 */     SUCCESS_OK(200, "OK"), 
/*  102 */     SUCCESS_CREATED(201, "Created"), 
/*  103 */     SUCCESS_ACCEPTED(202, "Accepted"), 
/*  104 */     SUCCESS_NONAUTHORITATIVEINFO(203, "Non-Authoritative Information"), 
/*  105 */     SUCCESS_NOCONTENT(204, "No Content"), 
/*  106 */     SUCCESS_RESETCONTENT(205, "Reset Content"), 
/*  107 */     SUCCESS_PARTIALCONTENT(206, "Partial Content"), 
/*      */     
/*      */ 
/*  110 */     WRONG_REQUEST_ERROR(400, "Missing parameters in request"), 
/*  111 */     AUTHENTICATION_AUTHORIZATION_ERROR(401, "Authentication failed. ##Please check your login details."), 
/*  112 */     NOT_FOUND(404, "Not Found"), 
/*  113 */     WRONG_VERSION_RESPONSE(420, "Invalid application version.##Please launch the platform ## from www.dukascopy.com"), 
/*  114 */     WRONG_VERSION_RESPONSE_OLD(-2, "Invalid application version.##Please launch the platform ## from www.dukascopy.com"), 
/*  115 */     TICKET_EXPIRED(421, "Ticket expired"), 
/*  116 */     ACCOUNT_LOCKED_ERROR(423, "Account locked"), 
/*  117 */     TOO_MANY_REQUESTS(429, "Too many requests"), 
/*  118 */     ORIGIN_NOT_ALLOWED_ERROR(430, "Origin not allowed"), 
/*      */     
/*      */ 
/*  121 */     SYSTEM_ERROR(500, "Unexpected system error"), 
/*  122 */     SYSTEM_ERROR_OLD(65036, "Unexpected system error"), 
/*  123 */     SERVICE_UNAVAILABLE(503, "System is offline"), 
/*  124 */     SERVICE_UNAVAILABLE_OLD(-3, "System is offline"), 
/*      */     
/*      */ 
/*  127 */     MINUS_ONE_OLD_ERROR(-1, "Authentication failed. ##Please check your login details."), 
/*  128 */     EMPTY_RESPONSE(-4, "Empty response"), 
/*  129 */     ERROR_INIT(-5, "Initialization error"), 
/*  130 */     BAD_URL(-6, "Bad url"), 
/*  131 */     ERROR_IO(-7, "Connection error occurred"), 
/*  132 */     WRONG_AUTH_RESPONSE(-8, "Wrong authorization response"), 
/*  133 */     INTERNAL_ERROR(-9, "Internal error"), 
/*  134 */     UNKNOWN_RESPONSE("Unknown response");
/*      */     
/*      */     private int code;
/*      */     private String message;
/*      */     
/*      */     private AuthorizationServerResponseCode(int code, String message) {
/*  140 */       this.code = code;
/*  141 */       this.message = message;
/*      */     }
/*      */     
/*      */     private AuthorizationServerResponseCode(String message) {
/*  145 */       this.message = message;
/*      */     }
/*      */     
/*      */     public int getCode() {
/*  149 */       return this.code;
/*      */     }
/*      */     
/*      */     public void setCode(int code) {
/*  153 */       if (this != UNKNOWN_RESPONSE) {
/*  154 */         throw new IllegalStateException("The error code can be set only for UNKNOWN_RESPONSE.");
/*      */       }
/*      */       
/*  157 */       this.code = code;
/*      */     }
/*      */     
/*      */     public String getMessage() {
/*  161 */       return this.message;
/*      */     }
/*      */     
/*      */     public static AuthorizationServerResponseCode fromValue(int code) {
/*  165 */       for (AuthorizationServerResponseCode enumer : ) {
/*  166 */         if (enumer.code == code) {
/*  167 */           return enumer;
/*      */         }
/*      */       }
/*      */       
/*  171 */       UNKNOWN_RESPONSE.setCode(code);
/*  172 */       return UNKNOWN_RESPONSE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static AuthorizationClient getInstance(Collection<String> authServerUrls, String version)
/*      */   {
/*  179 */     if (authClient == null) {
/*      */       try {
/*  181 */         authClient = new AuthorizationClient(authServerUrls, version);
/*      */       } catch (MalformedURLException e) {
/*  183 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     } else {
/*      */       try {
/*  187 */         authClient.updateConfigurationPool(authServerUrls);
/*      */       } catch (MalformedURLException e) {
/*  189 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     }
/*  192 */     return authClient;
/*      */   }
/*      */   
/*      */   private AuthorizationClient(Collection<String> authServerUrls, String version) throws MalformedURLException {
/*  196 */     this.configurationPool = new AuthorizationConfigurationPool();
/*  197 */     for (String authServerUrl : authServerUrls) {
/*  198 */       this.configurationPool.add(authServerUrl);
/*      */     }
/*  200 */     this.version = version;
/*      */   }
/*      */   
/*      */   private void updateConfigurationPool(Collection<String> authServerUrls) throws MalformedURLException {
/*  204 */     this.configurationPool.clear();
/*  205 */     for (String authServerUrl : authServerUrls) {
/*  206 */       this.configurationPool.add(authServerUrl);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReportURL(String reportKey, String baseUrl, String stsToken)
/*      */   {
/*  215 */     if ((reportKey == null) || (reportKey.isEmpty())) {
/*  216 */       throw new IllegalArgumentException("The reportKey is null or empty");
/*      */     }
/*      */     
/*  219 */     if ((baseUrl == null) || (baseUrl.isEmpty())) {
/*  220 */       throw new IllegalArgumentException("The baseUrl is null or empty");
/*      */     }
/*      */     
/*  223 */     if ((stsToken == null) || (stsToken.isEmpty())) {
/*  224 */       throw new IllegalArgumentException("The stsToken is null or empty");
/*      */     }
/*      */     
/*  227 */     reportKey = reportKey.trim();
/*  228 */     String TYPE = "secure";
/*  229 */     StringBuilder reportUrl = new StringBuilder(256);
/*      */     
/*  231 */     reportUrl.append(baseUrl).append("/fo/reports/trader/auth/?").append("type").append("=").append("secure").append("&").append("token").append("=").append(stsToken).append("&").append("report").append("=").append(reportKey);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */     return reportUrl.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getChatURL(String baseUrl, String stsToken, String mode)
/*      */   {
/*  255 */     if ((baseUrl == null) || (baseUrl.isEmpty())) {
/*  256 */       throw new IllegalArgumentException("The baseUrl is null or empty");
/*      */     }
/*      */     
/*  259 */     if ((stsToken == null) || (stsToken.isEmpty())) {
/*  260 */       throw new IllegalArgumentException("The stsToken is null or empty");
/*      */     }
/*      */     
/*  263 */     StringBuilder chatUrl = new StringBuilder();
/*  264 */     char separator = baseUrl.contains("#") ? '&' : '?';
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  269 */     chatUrl.append(baseUrl).append(separator).append("token").append("=").append(mode).append(stsToken);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  276 */     return chatUrl.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthorizationServerStsTokenResponse getReportSTSToken(String apello, String sermo, String licentio)
/*      */   {
/*  284 */     return getSTSToken(apello, sermo, licentio, "open_reports");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthorizationServerStsTokenResponse getChatSTSToken(String apello, String sermo, String licentio)
/*      */   {
/*  292 */     return getSTSToken(apello, sermo, licentio, "open_chat");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthorizationServerStsTokenResponse getSTSToken(String apello, String sermo, String licentio, String action)
/*      */   {
/*  302 */     String to = "FO";
/*      */     
/*  304 */     AuthorizationServerStsTokenResponse authorizationServerStsTokenResponse = null;
/*      */     
/*  306 */     for (int retryCount = 0; retryCount < this.configurationPool.size(); retryCount++) {
/*      */       try {
/*  308 */         String baseUrl = getBaseUrl().toString();
/*      */         
/*  310 */         String slash = "";
/*  311 */         if (!baseUrl.endsWith("/")) {
/*  312 */           slash = "/";
/*      */         }
/*      */         
/*      */ 
/*  316 */         StringBuilder stsTokenURLBuf = new StringBuilder(256);
/*  317 */         stsTokenURLBuf.append(baseUrl).append(slash).append("auth?munus=sts").append("&").append("appello=").append(apello).append("&").append("sermo=").append(sermo).append("&").append("licentio=").append(licentio).append("&").append("to=").append("FO").append("&").append("action=").append(action);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  334 */         URL stsTokenURL = new URL(stsTokenURLBuf.toString());
/*      */         
/*  336 */         String response = null;
/*  337 */         BufferedReader reader = null;
/*      */         
/*  339 */         int authorizationServerResponseCode = 0;
/*  340 */         URLConnection connection = getConnection(stsTokenURL);
/*      */         
/*  342 */         if ((connection instanceof HttpURLConnection)) {
/*  343 */           authorizationServerResponseCode = ((HttpURLConnection)connection).getResponseCode();
/*      */         }
/*      */         try
/*      */         {
/*  347 */           reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*  348 */           response = reader.readLine();
/*      */           
/*      */ 
/*      */ 
/*  352 */           if (reader != null) {
/*      */             try {
/*  354 */               reader.close();
/*      */             } catch (Exception e2) {
/*  356 */               LOGGER.error(e2.getMessage(), e2);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  361 */           authorizationServerStsTokenResponse = new AuthorizationServerStsTokenResponse(response, authorizationServerResponseCode);
/*      */         }
/*      */         catch (Throwable e)
/*      */         {
/*  350 */           LOGGER.error(e.getMessage(), e);
/*      */         } finally {
/*  352 */           if (reader != null) {
/*      */             try {
/*  354 */               reader.close();
/*      */             } catch (Exception e2) {
/*  356 */               LOGGER.error(e2.getMessage(), e2);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  366 */         if (authorizationServerStsTokenResponse.isOK()) {
/*  367 */           return authorizationServerStsTokenResponse;
/*      */         }
/*  369 */         LOGGER.error("Cannot get STS token:" + stsTokenURLBuf.toString());
/*  370 */         LOGGER.error(authorizationServerStsTokenResponse.toString());
/*      */       }
/*      */       catch (MalformedURLException e) {
/*  373 */         LOGGER.error(e.getMessage(), e);
/*  374 */         return new AuthorizationServerStsTokenResponse(AuthorizationServerResponseCode.BAD_URL);
/*      */       }
/*      */       catch (IOException e) {
/*  377 */         LOGGER.error(e.getMessage(), e);
/*  378 */         authorizationServerStsTokenResponse = new AuthorizationServerStsTokenResponse(AuthorizationServerResponseCode.ERROR_IO);
/*      */       } catch (Throwable e) {
/*  380 */         LOGGER.error(e.getMessage(), e);
/*  381 */         return new AuthorizationServerStsTokenResponse(AuthorizationServerResponseCode.INTERNAL_ERROR);
/*      */       }
/*      */       
/*      */ 
/*  385 */       this.configurationPool.markLastUsedAsBad();
/*      */     }
/*      */     
/*  388 */     return authorizationServerStsTokenResponse;
/*      */   }
/*      */   
/*      */   public Map<String, BufferedImage> getImageCaptcha() throws IOException {
/*  392 */     HashMap<String, BufferedImage> output = null;
/*  393 */     int retryCount = 0;
/*      */     
/*  395 */     while ((retryCount < this.configurationPool.size()) && (output == null)) {
/*  396 */       String baseURL = getBaseUrl().toString();
/*      */       
/*  398 */       StringBuffer buf = new StringBuffer(128);
/*  399 */       buf.append(baseURL);
/*  400 */       if (!baseURL.endsWith("/")) {
/*  401 */         buf.append("/");
/*      */       }
/*  403 */       buf.append("captcha");
/*      */       
/*  405 */       String formedUrl = buf.toString();
/*      */       
/*  407 */       LOGGER.debug(">> [{}]", formedUrl);
/*  408 */       URL captchaUrl = new URL(formedUrl);
/*  409 */       InputStream inputStream = null;
/*      */       try
/*      */       {
/*  412 */         URLConnection connection = getConnection(captchaUrl);
/*  413 */         connection.setReadTimeout(20000);
/*  414 */         inputStream = connection.getInputStream();
/*      */         
/*  416 */         BufferedImage captchaImage = ImageIO.read(inputStream);
/*  417 */         if (captchaImage == null) {
/*  418 */           LOGGER.error("Empty captchaImage");
/*  419 */           this.configurationPool.markLastUsedAsBad();
/*  420 */           retryCount++;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*  441 */             if (inputStream != null) {
/*  442 */               inputStream.close();
/*      */             }
/*      */           }
/*      */           catch (Exception e2) {}
/*      */         }
/*      */         else
/*      */         {
/*  424 */           String captchaId = connection.getHeaderField("X-CaptchaID");
/*  425 */           if ((captchaId == null) || (captchaId.trim().isEmpty())) {
/*  426 */             LOGGER.error("Empty captchaId");
/*  427 */             this.configurationPool.markLastUsedAsBad();
/*  428 */             retryCount++;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/*  441 */               if (inputStream != null) {
/*  442 */                 inputStream.close();
/*      */               }
/*      */             }
/*      */             catch (Exception e2) {}
/*      */           }
/*      */           else
/*      */           {
/*  432 */             LOGGER.debug("<< [{} : {}]", "X-CaptchaID", captchaId);
/*      */             
/*  434 */             output = new HashMap();
/*  435 */             output.put(captchaId, captchaImage);
/*      */             
/*      */ 
/*      */ 
/*      */             try
/*      */             {
/*  441 */               if (inputStream != null) {
/*  442 */                 inputStream.close();
/*      */               }
/*      */             }
/*      */             catch (Exception e2) {}
/*      */             
/*      */ 
/*  448 */             retryCount++;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  437 */         this.configurationPool.markLastUsedAsBad();
/*  438 */         LOGGER.error(e.getMessage(), e);
/*      */       } finally {
/*      */         try {
/*  441 */           if (inputStream != null) {
/*  442 */             inputStream.close();
/*      */           }
/*      */         }
/*      */         catch (Exception e2) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  450 */     return output;
/*      */   }
/*      */   
/*      */   public AuthorizationServerResponse getAPIsAndTicketUsingLogin(String login, String password, String instanceId, String platform) {
/*  454 */     return getAPIsAndTicketUsingLogin(login, password, instanceId, true, platform);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean continueObtainingAPIServers(int retryCount, AuthorizationConfigurationPool configurationPool, AuthorizationServerResponse authorizationServerResponse)
/*      */   {
/*  462 */     if (authorizationServerResponse == null) {
/*  463 */       return true;
/*      */     }
/*      */     
/*  466 */     if ((retryCount < configurationPool.size()) && (authorizationServerResponse.isEmptyResponse())) {
/*  467 */       return true;
/*      */     }
/*      */     
/*  470 */     if ((retryCount < configurationPool.size()) && ((authorizationServerResponse.getResponseCode() == AuthorizationServerResponseCode.TOO_MANY_REQUESTS) || (authorizationServerResponse.getResponseCode() == AuthorizationServerResponseCode.ERROR_IO) || (authorizationServerResponse.getResponseCode() == AuthorizationServerResponseCode.EMPTY_RESPONSE) || (authorizationServerResponse.getResponseCode() == AuthorizationServerResponseCode.NOT_FOUND) || (authorizationServerResponse.isSystemError())))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  481 */       return true;
/*      */     }
/*      */     
/*  484 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthorizationServerResponse getAPIsAndTicketUsingLogin(String login, String password, String instanceId, boolean encodePassword, String platform)
/*      */   {
/*  495 */     AuthorizationServerResponse authorizationServerResponse = null;
/*  496 */     int retryCount = 0;
/*      */     
/*  498 */     while (continueObtainingAPIServers(retryCount, this.configurationPool, authorizationServerResponse)) {
/*      */       try {
/*  500 */         String serverRegion = System.getProperty("server.region");
/*  501 */         String formedUrl = getBaseUrl() + "/auth?typus=0&munus=api&" + "platform" + "=" + platform + "&" + "appello" + "=" + URLEncoder.encode(login, "UTF-8") + "&" + "specialis" + "=" + URLEncoder.encode(encodePassword ? encodeAll(password, "", login) : password, "UTF-8") + "&" + "versio" + "=" + URLEncoder.encode(this.version, "UTF-8") + "&" + "sermo" + "=" + instanceId + "&" + "willPing" + "=true" + (serverRegion == null ? "" : new StringBuilder().append("&region=").append(serverRegion).toString());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  510 */         URL url = new URL(formedUrl);
/*  511 */         authorizationServerResponse = getAuthorizationServerResponse(url);
/*  512 */         if (authorizationServerResponse.isOK()) {
/*  513 */           String fastestAPIAndTicket = selectFastestAPIServer(authorizationServerResponse.getResponseMessage());
/*  514 */           authorizationServerResponse.setFastestAPIAndTicket(fastestAPIAndTicket);
/*      */         }
/*      */       } catch (NoSuchAlgorithmException|MalformedURLException|UnsupportedEncodingException e) {
/*  517 */         LOGGER.error(e.getMessage(), e);
/*  518 */         if ((e instanceof MalformedURLException)) {
/*  519 */           authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.BAD_URL);
/*      */         }
/*  521 */         if ((e instanceof UnsupportedEncodingException)) {
/*  522 */           authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_INIT);
/*      */         }
/*  524 */         if ((e instanceof NoSuchAlgorithmException)) {}
/*  525 */         return new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_INIT);
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  529 */         LOGGER.error(e.getMessage(), e);
/*  530 */         authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_IO);
/*      */       } catch (Throwable e) {
/*  532 */         LOGGER.error(e.getMessage(), e);
/*  533 */         return new AuthorizationServerResponse(AuthorizationServerResponseCode.INTERNAL_ERROR);
/*      */       }
/*      */       
/*      */ 
/*  537 */       retryCount++;
/*      */       
/*  539 */       if (continueObtainingAPIServers(retryCount, this.configurationPool, authorizationServerResponse)) {
/*  540 */         this.configurationPool.markLastUsedAsBad();
/*      */       }
/*      */     }
/*  543 */     return authorizationServerResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthorizationServerResponse getAPIsAndTicketUsingLogin(String login, String password, String captchaId, String pin, String instanceId, String platform)
/*      */   {
/*  554 */     AuthorizationServerResponse authorizationServerResponse = null;
/*  555 */     int retryCount = 0;
/*      */     
/*  557 */     while (continueObtainingAPIServers(retryCount, this.configurationPool, authorizationServerResponse)) {
/*      */       try {
/*  559 */         String serverRegion = System.getProperty("server.region");
/*  560 */         String urlString = getBaseUrl() + "/auth?typus=0&munus=api&" + "platform" + "=" + platform + "&" + "appello" + "=" + URLEncoder.encode(login, "UTF-8") + "&" + "specialis" + "=" + URLEncoder.encode(encodeAll(password, captchaId, login), "UTF-8") + "&" + "versio" + "=" + URLEncoder.encode(this.version, "UTF-8") + "&" + "sermo" + "=" + instanceId + "&" + "willPing" + "=true" + (serverRegion == null ? "" : new StringBuilder().append("&region=").append(serverRegion).toString());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  569 */         if (captchaId != null) {
/*  570 */           urlString = urlString + "&verbum_id=" + captchaId;
/*      */         }
/*  572 */         if (pin != null) {
/*  573 */           urlString = urlString + "&sententia=" + URLEncoder.encode(pin, "iso-8859-1");
/*      */         }
/*      */         
/*  576 */         URL url = new URL(urlString);
/*  577 */         authorizationServerResponse = getAuthorizationServerResponse(url);
/*  578 */         if (authorizationServerResponse.isOK()) {
/*  579 */           String fastestAPIAndTicket = selectFastestAPIServer(authorizationServerResponse.getResponseMessage());
/*  580 */           authorizationServerResponse.setFastestAPIAndTicket(fastestAPIAndTicket);
/*      */         }
/*      */       } catch (NoSuchAlgorithmException|MalformedURLException e) {
/*  583 */         LOGGER.error(e.getMessage(), e);
/*  584 */         if ((e instanceof MalformedURLException)) {
/*  585 */           authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.BAD_URL);
/*      */         }
/*  587 */         if ((e instanceof NoSuchAlgorithmException)) {}
/*  588 */         return new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_INIT);
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  592 */         LOGGER.error(e.getMessage(), e);
/*  593 */         authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_IO);
/*      */       } catch (Throwable e) {
/*  595 */         LOGGER.error(e.getMessage(), e);
/*  596 */         return new AuthorizationServerResponse(AuthorizationServerResponseCode.INTERNAL_ERROR);
/*      */       }
/*      */       
/*      */ 
/*  600 */       retryCount++;
/*      */       
/*  602 */       if (continueObtainingAPIServers(retryCount, this.configurationPool, authorizationServerResponse)) {
/*  603 */         this.configurationPool.markLastUsedAsBad();
/*      */       }
/*      */     }
/*      */     
/*  607 */     return authorizationServerResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AuthorizationServerResponse getAPIsAndTicketUsingRelogin(String login, String oldTicket, String instanceId, String platform)
/*      */   {
/*  616 */     AuthorizationServerResponse authorizationServerResponse = null;
/*  617 */     int retryCount = 0;
/*      */     
/*  619 */     while (continueObtainingAPIServers(retryCount, this.configurationPool, authorizationServerResponse)) {
/*      */       try {
/*  621 */         String formedUrl = getBaseUrl() + "/auth?typus=0&munus=relogin&" + "platform" + "=" + platform + "&" + "appello" + "=" + URLEncoder.encode(login, "UTF-8") + "&" + "licentio" + "=" + oldTicket + "&" + "sermo" + "=" + instanceId + "&" + "willPing" + "=true";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  628 */         URL url = new URL(formedUrl);
/*  629 */         authorizationServerResponse = getAuthorizationServerResponse(url);
/*      */         
/*  631 */         if (authorizationServerResponse.isOK()) {
/*  632 */           String fastestAPIAndTicket = selectFastestAPIServer(authorizationServerResponse.getResponseMessage());
/*  633 */           authorizationServerResponse.setFastestAPIAndTicket(fastestAPIAndTicket);
/*      */         }
/*      */       } catch (MalformedURLException|UnsupportedEncodingException e) {
/*  636 */         LOGGER.error(e.getMessage(), e);
/*  637 */         if ((e instanceof MalformedURLException)) {
/*  638 */           authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.BAD_URL);
/*      */         }
/*  640 */         if ((e instanceof UnsupportedEncodingException)) {}
/*  641 */         return new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_INIT);
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  645 */         LOGGER.error(e.getMessage(), e);
/*  646 */         authorizationServerResponse = new AuthorizationServerResponse(AuthorizationServerResponseCode.ERROR_IO);
/*      */       } catch (Throwable e) {
/*  648 */         LOGGER.error(e.getMessage(), e);
/*  649 */         return new AuthorizationServerResponse(AuthorizationServerResponseCode.INTERNAL_ERROR);
/*      */       }
/*      */       
/*      */ 
/*  653 */       retryCount++;
/*      */       
/*  655 */       if (continueObtainingAPIServers(retryCount, this.configurationPool, authorizationServerResponse)) {
/*  656 */         this.configurationPool.markLastUsedAsBad();
/*      */       }
/*      */     }
/*  659 */     return authorizationServerResponse;
/*      */   }
/*      */   
/*      */   public AuthorizationServerWLBOResponse getResponeForTheWLBOAutoLogin(String authToken) {
/*  663 */     AuthorizationServerWLBOResponse authorizationServerWLBOResponse = null;
/*      */     
/*  665 */     if (this.configurationPool.size() == 0) {
/*  666 */       LOGGER.error("No authorization url provided.");
/*  667 */       authorizationServerWLBOResponse = new AuthorizationServerWLBOResponse(AuthorizationServerResponseCode.INTERNAL_ERROR);
/*  668 */       return authorizationServerWLBOResponse;
/*      */     }
/*      */     
/*  671 */     for (int retryCount = 0; retryCount < this.configurationPool.size(); retryCount++) {
/*      */       try {
/*  673 */         String baseUrl = getBaseUrl().toString();
/*      */         
/*  675 */         String slash = "";
/*  676 */         if (!baseUrl.endsWith("/")) {
/*  677 */           slash = "/";
/*      */         }
/*      */         
/*      */ 
/*  681 */         StringBuilder authURLBuf = new StringBuilder(256);
/*  682 */         authURLBuf.append(baseUrl).append(slash).append("auth?munus=sts_token").append("&").append("indicium=").append(authToken);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  692 */         LOGGER.debug("Authorization url=" + authURLBuf.toString());
/*  693 */         URL stsTokenURL = new URL(authURLBuf.toString());
/*      */         
/*  695 */         String response = null;
/*  696 */         BufferedReader reader = null;
/*  697 */         int authorizationServerResponseCode = 0;
/*      */         
/*  699 */         URLConnection connection = getConnection(stsTokenURL);
/*      */         
/*  701 */         if ((connection instanceof HttpURLConnection)) {
/*  702 */           authorizationServerResponseCode = ((HttpURLConnection)connection).getResponseCode();
/*      */         }
/*      */         try
/*      */         {
/*  706 */           reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*  707 */           response = reader.readLine();
/*      */           
/*      */ 
/*      */ 
/*  711 */           if (reader != null) {
/*      */             try {
/*  713 */               reader.close();
/*      */             } catch (Throwable e) {
/*  715 */               LOGGER.error(e.getMessage(), e);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  720 */           authorizationServerWLBOResponse = new AuthorizationServerWLBOResponse(response, authorizationServerResponseCode);
/*      */         }
/*      */         catch (Throwable e) {}finally
/*      */         {
/*  711 */           if (reader != null) {
/*      */             try {
/*  713 */               reader.close();
/*      */             } catch (Throwable e) {
/*  715 */               LOGGER.error(e.getMessage(), e);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  725 */         if (authorizationServerWLBOResponse.isOK()) {
/*  726 */           return authorizationServerWLBOResponse;
/*      */         }
/*  728 */         LOGGER.error("Wrong response, URL=" + authURLBuf.toString() + ", response=" + authorizationServerWLBOResponse.toString());
/*      */       }
/*      */       catch (MalformedURLException e) {
/*  731 */         LOGGER.error(e.getMessage(), e);
/*  732 */         return new AuthorizationServerWLBOResponse(AuthorizationServerResponseCode.BAD_URL);
/*      */       }
/*      */       catch (IOException e) {
/*  735 */         LOGGER.error(e.getMessage(), e);
/*  736 */         authorizationServerWLBOResponse = new AuthorizationServerWLBOResponse(AuthorizationServerResponseCode.ERROR_IO);
/*      */       } catch (Throwable e) {
/*  738 */         LOGGER.error(e.getMessage(), e);
/*  739 */         return new AuthorizationServerWLBOResponse(AuthorizationServerResponseCode.INTERNAL_ERROR);
/*      */       }
/*      */       
/*      */ 
/*  743 */       this.configurationPool.markLastUsedAsBad();
/*      */     }
/*      */     
/*  746 */     return authorizationServerWLBOResponse;
/*      */   }
/*      */   
/*      */   public String getFeedUrlAndTicket(String login, String platformTicket, String instanceId) throws IOException, NoSuchAlgorithmException {
/*  750 */     String result = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  801 */     return result;
/*      */   }
/*      */   
/*      */   public Properties getAllProperties(String login, String ticket, String sessionId) throws IOException, NoSuchAlgorithmException {
/*  805 */     Properties result = null;
/*  806 */     int retryCount = 0;
/*      */     
/*  808 */     SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  809 */     String formedUrl = null;
/*      */     
/*  811 */     while (result == null) {
/*      */       try {
/*  813 */         formedUrl = getBaseUrl() + "/auth?typus=0&munus=stngs&" + "appello" + "=" + URLEncoder.encode(login, "UTF-8") + "&" + "licentio" + "=" + ticket + "&" + "sermo" + "=" + sessionId + "&" + "stngs" + "=1";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  819 */         URL url = new URL(formedUrl);
/*      */         
/*  821 */         LOGGER.info("retry count = " + (retryCount + 1) + ", properties request time = " + DATE_FORMAT.format(Long.valueOf(System.currentTimeMillis())));
/*      */         
/*  823 */         result = (Properties)getRetrievePropsFromResponse(url);
/*      */         
/*  825 */         if (result == null) {
/*  826 */           LOGGER.info("Cannot get the platform properties, url=" + formedUrl);
/*  827 */           this.configurationPool.markLastUsedAsBad();
/*      */         } else {
/*  829 */           int[] times = (int[])result.get("marketTimes");
/*  830 */           if (times != null) {
/*  831 */             LOGGER.debug("MarketTimes from " + times[0] + ":" + times[1] + " to " + times[2] + ":" + times[3]);
/*      */           }
/*      */         }
/*      */       } catch (Throwable e) {
/*  835 */         LOGGER.info("Cannot get the platform properties, url=" + formedUrl);
/*  836 */         this.configurationPool.markLastUsedAsBad();
/*  837 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */       
/*  840 */       LOGGER.info("retry count = " + (retryCount + 1) + ", properties response time = " + DATE_FORMAT.format(Long.valueOf(System.currentTimeMillis())));
/*      */       
/*  842 */       if (retryCount > 0) {
/*      */         try {
/*  844 */           Thread.sleep(3000L);
/*      */         }
/*      */         catch (Throwable e) {}
/*      */       }
/*      */       
/*      */ 
/*  850 */       retryCount++;
/*      */       
/*      */ 
/*  853 */       if ((retryCount > this.configurationPool.size()) && 
/*  854 */         (autoConnectWithNoLoginDialog())) {
/*  855 */         exitPlatform();
/*      */       }
/*      */     }
/*      */     
/*  859 */     return result;
/*      */   }
/*      */   
/*      */   private static AuthorizationServerResponse getAuthorizationServerResponse(URL url) throws IOException
/*      */   {
/*  864 */     LOGGER.debug(">> [{}]", url);
/*  865 */     String response = null;
/*  866 */     BufferedReader reader = null;
/*  867 */     AuthorizationServerResponse authorizationServerResponse = null;
/*      */     try
/*      */     {
/*  870 */       int authorizationServerResponseCode = 0;
/*  871 */       URLConnection connection = getConnection(url);
/*      */       
/*      */ 
/*  874 */       if ((connection instanceof HttpURLConnection)) {
/*  875 */         authorizationServerResponseCode = ((HttpURLConnection)connection).getResponseCode();
/*      */       }
/*      */       try
/*      */       {
/*  879 */         reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*  880 */         response = reader.readLine();
/*      */       }
/*      */       catch (IOException e) {}
/*      */       
/*      */ 
/*  885 */       authorizationServerResponse = new AuthorizationServerResponse(response, authorizationServerResponseCode);
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*  890 */       if (reader != null) {
/*  891 */         reader.close();
/*      */       }
/*      */     }
/*  894 */     LOGGER.debug("<< [{}]", response);
/*  895 */     return authorizationServerResponse;
/*      */   }
/*      */   
/*      */   public static String selectFastestAPIServer(String apiServersAndTicket) throws FastestAPIServerSelectionException {
/*  899 */     LOGGER.info("Selecting the best server...");
/*      */     
/*  901 */     Matcher matcher = null;
/*  902 */     boolean matches = false;
/*      */     try
/*      */     {
/*  905 */       matcher = RESULT_PATTERN.matcher(apiServersAndTicket);
/*  906 */       matches = matcher.matches();
/*      */     } catch (Throwable e) {
/*  908 */       throw new FastestAPIServerSelectionException(e);
/*      */     }
/*      */     
/*  911 */     if (!matches) {
/*  912 */       throw new FastestAPIServerSelectionException("Wrong format: " + apiServersAndTicket);
/*      */     }
/*      */     try
/*      */     {
/*  916 */       String apiUrls = matcher.group(1);
/*  917 */       Map<String, InetSocketAddress> addresses = new LinkedHashMap();
/*  918 */       StringTokenizer tokenizer = new StringTokenizer(apiUrls, "@");
/*      */       
/*  920 */       if (tokenizer.countTokens() == 0) {
/*  921 */         throw new FastestAPIServerSelectionException("Wrong format: " + apiServersAndTicket);
/*      */       }
/*      */       
/*  924 */       if (tokenizer.countTokens() == 1) {
/*  925 */         return apiServersAndTicket;
/*      */       }
/*  927 */       while (tokenizer.hasMoreTokens()) {
/*  928 */         String apiURL = tokenizer.nextToken();
/*      */         
/*      */ 
/*  931 */         int semicolonIndex = apiURL.indexOf(':');
/*  932 */         int port; String host; int port; if (semicolonIndex != -1) {
/*  933 */           String host = apiURL.substring(0, semicolonIndex);
/*  934 */           int port; if (semicolonIndex + 1 >= apiURL.length()) {
/*  935 */             LOGGER.warn("Port is not set, using default 443");
/*  936 */             port = 443;
/*      */           } else {
/*  938 */             port = Integer.parseInt(apiURL.substring(semicolonIndex + 1));
/*      */           }
/*      */         } else {
/*  941 */           LOGGER.warn("Port is not set, using default 443");
/*  942 */           host = apiURL;
/*  943 */           port = 443;
/*      */         }
/*      */         
/*  946 */         addresses.put(apiURL, new InetSocketAddress(host, port));
/*      */       }
/*      */       
/*      */ 
/*  950 */       Map<String, Long[]> pingResult = Ping.ping(addresses);
/*      */       
/*  952 */       Map<String, Long> pingAverages = new LinkedHashMap();
/*  953 */       for (Map.Entry<String, Long[]> entry : pingResult.entrySet()) {
/*  954 */         Long[] results = (Long[])entry.getValue();
/*  955 */         long averageTime = 0L;
/*  956 */         for (Long time : results) {
/*  957 */           if (time.longValue() == Long.MIN_VALUE) {
/*  958 */             if (averageTime > 0L)
/*      */             {
/*  960 */               averageTime = -averageTime;
/*      */             }
/*  962 */             averageTime += -2147483648L;
/*  963 */           } else if (time.longValue() == Long.MAX_VALUE) {
/*  964 */             if (averageTime < 0L) {
/*  965 */               averageTime += -2147483648L;
/*      */             } else {
/*  967 */               averageTime += 2147483647L;
/*      */             }
/*      */           }
/*  970 */           else if (averageTime < 0L) {
/*  971 */             averageTime -= time.longValue();
/*      */           } else {
/*  973 */             averageTime += time.longValue();
/*      */           }
/*      */         }
/*      */         
/*  977 */         averageTime /= results.length;
/*  978 */         pingAverages.put(entry.getKey(), Long.valueOf(averageTime));
/*      */       }
/*      */       
/*  981 */       String mainURL = null;
/*  982 */       Long mainTime = null;
/*  983 */       String bestURL = null;
/*  984 */       Long bestTime = null;
/*  985 */       for (Map.Entry<String, Long> entry : pingAverages.entrySet()) {
/*  986 */         if (mainURL == null) {
/*  987 */           bestURL = mainURL = (String)entry.getKey();
/*  988 */           bestTime = mainTime = (Long)entry.getValue();
/*      */         } else {
/*  990 */           Long time = (Long)entry.getValue();
/*  991 */           if (mainTime.longValue() >= 0L) {
/*  992 */             if (time.longValue() < 0L) {
/*      */               break;
/*      */             }
/*      */             
/*  996 */             if ((mainTime.longValue() > time.longValue()) && ((mainTime.longValue() - time.longValue()) * 100L / mainTime.longValue() > 10L) && (mainTime.longValue() - time.longValue() > 50L))
/*      */             {
/*  998 */               if (bestTime.longValue() > time.longValue()) {
/*  999 */                 bestURL = (String)entry.getKey();
/* 1000 */                 bestTime = time;
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/* 1006 */           else if (time.longValue() >= 0L) {
/* 1007 */             if ((bestTime.longValue() < 0L) || (bestTime.longValue() > time.longValue())) {
/* 1008 */               bestURL = (String)entry.getKey();
/* 1009 */               bestTime = (Long)entry.getValue();
/*      */             }
/*      */             
/*      */           }
/* 1013 */           else if ((Math.abs(mainTime.longValue()) > Math.abs(time.longValue())) && ((Math.abs(mainTime.longValue()) - Math.abs(time.longValue())) * 100L / Math.abs(mainTime.longValue()) > 10L) && (Math.abs(mainTime.longValue()) - Math.abs(time.longValue()) > 50L))
/*      */           {
/* 1015 */             if (bestTime.longValue() < 0L)
/*      */             {
/* 1017 */               if (Math.abs(bestTime.longValue()) > Math.abs(time.longValue())) {
/* 1018 */                 bestURL = (String)entry.getKey();
/* 1019 */                 bestTime = time;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1027 */       LOGGER.debug("Best api url [" + bestURL + "] with time [" + bestTime + "]");
/*      */       
/* 1029 */       String address = bestURL + "@" + matcher.group(7);
/* 1030 */       if (validAPIServerAddressFormat(address)) {
/* 1031 */         return address;
/*      */       }
/* 1033 */       throw new FastestAPIServerSelectionException("Wrong fastest API server format:" + address);
/*      */     }
/*      */     catch (FastestAPIServerSelectionException e)
/*      */     {
/* 1037 */       throw e;
/*      */     } catch (Throwable e) {
/* 1039 */       LOGGER.error(e.getMessage(), e);
/* 1040 */       throw new FastestAPIServerSelectionException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private static String readResponse(URL url) throws IOException {
/* 1045 */     String result = null;
/* 1046 */     BufferedReader reader = null;
/*      */     try {
/* 1048 */       URLConnection connection = getConnection(url);
/*      */       
/*      */ 
/* 1051 */       if ((connection instanceof HttpURLConnection)) {
/* 1052 */         int authorizationServerResponseCode = ((HttpURLConnection)connection).getResponseCode();
/* 1053 */         if ((autoConnectWithNoLoginDialog()) && (AuthorizationServerResponseCode.SUCCESS_OK.getCode() != authorizationServerResponseCode)) {
/* 1054 */           exitPlatform();
/*      */         }
/*      */       }
/*      */       
/* 1058 */       reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*      */       
/*      */ 
/* 1061 */       StringBuffer sb = new StringBuffer();
/*      */       String tempRes;
/*      */       do {
/* 1064 */         tempRes = reader.readLine();
/* 1065 */         sb.append(tempRes);
/* 1066 */       } while (tempRes != null);
/*      */       
/* 1068 */       result = sb.toString();
/*      */     }
/*      */     catch (Throwable e) {
/* 1071 */       if (autoConnectWithNoLoginDialog()) {
/* 1072 */         LOGGER.error(e.getMessage(), e);
/* 1073 */         exitPlatform();
/*      */       } else {
/* 1075 */         throw e;
/*      */       }
/*      */     } finally {
/* 1078 */       if (reader != null) {
/* 1079 */         reader.close();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1084 */     if (autoConnectWithNoLoginDialog()) {
/* 1085 */       result = result.trim();
/* 1086 */       if ((result.isEmpty()) || (result.equals("-1"))) {
/* 1087 */         exitPlatform();
/*      */       }
/*      */     }
/*      */     
/* 1091 */     return result;
/*      */   }
/*      */   
/*      */   private static void exitPlatform()
/*      */   {
/* 1096 */     showErrorMessageInEDT();
/* 1097 */     System.exit(0);
/*      */   }
/*      */   
/*      */   private static void showErrorMessage()
/*      */   {
/* 1102 */     JOptionPane.showMessageDialog(null, "Platform cannot be launched. Please contact support.", "Error", 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void showErrorMessageInEDT()
/*      */   {
/*      */     try
/*      */     {
/* 1114 */       Class.forName("com.dukascopy.dds2.greed.GreedClient");
/*      */     } catch (ClassNotFoundException e) {
/* 1116 */       return;
/*      */     }
/*      */     
/* 1119 */     if (!SwingUtilities.isEventDispatchThread()) {
/*      */       try {
/* 1121 */         SwingUtilities.invokeAndWait(new Runnable()
/*      */         {
/*      */           public void run() {}
/*      */         });
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/* 1128 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     } else {
/* 1131 */       showErrorMessage();
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean autoConnectWithNoLoginDialog()
/*      */   {
/* 1137 */     String ticket = System.getProperty("jnlp.auth.ticket");
/* 1138 */     String instanceId = System.getProperty("jnlp.api.sid");
/* 1139 */     String authToken = System.getProperty("jnlp.auth.token");
/*      */     
/* 1141 */     if ((authToken != null) && (authToken.length() > 0)) {
/* 1142 */       return true;
/*      */     }
/*      */     
/* 1145 */     if (ticket == null) {
/* 1146 */       return false;
/*      */     }
/* 1148 */     if (instanceId == null) {
/* 1149 */       return false;
/*      */     }
/*      */     
/* 1152 */     ticket = ticket.trim();
/* 1153 */     instanceId = instanceId.trim();
/*      */     
/* 1155 */     if ((ticket.length() == 0) || (instanceId.length() == 0)) {
/* 1156 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1166 */     return true;
/*      */   }
/*      */   
/*      */   private static Object getRetrievePropsFromResponse(URL url) throws IOException {
/* 1170 */     LOGGER.debug(">> [{}]", url);
/* 1171 */     Object result = null;
/*      */     
/* 1173 */     String encodedString = readResponse(url);
/*      */     
/* 1175 */     byte[] decodedBytes = Base64.decode(encodedString);
/* 1176 */     if (decodedBytes != null) {
/*      */       try {
/* 1178 */         ObjectInputStream inputStream = new ObjectInputStream(new ByteArrayInputStream(decodedBytes));
/* 1179 */         result = inputStream.readObject();
/*      */       } catch (IOException e) {
/* 1181 */         LOGGER.error(e.getMessage(), e);
/*      */       } catch (ClassNotFoundException e) {
/* 1183 */         LOGGER.error(e.getMessage(), e);
/*      */       }
/*      */     }
/*      */     
/* 1187 */     LOGGER.debug("Properties received << [{}]", result);
/* 1188 */     return result;
/*      */   }
/*      */   
/*      */   private static URLConnection getConnection(URL url) throws IOException {
/* 1192 */     URLConnection connection = url.openConnection();
/* 1193 */     if (((connection instanceof HttpsURLConnection)) && 
/* 1194 */       (Boolean.getBoolean("auth.ssl.ignore.errors"))) {
/* 1195 */       LOGGER.debug("Ignoring SSL errors");
/* 1196 */       ((HttpsURLConnection)connection).setHostnameVerifier(new DummyHostNameVerifier(null));
/*      */     }
/*      */     
/* 1199 */     return connection;
/*      */   }
/*      */   
/*      */   private static String convertToHex(byte[] data) {
/* 1203 */     StringBuffer buf = new StringBuffer();
/* 1204 */     for (byte aData : data) {
/* 1205 */       int halfbyte = aData >>> 4 & 0xF;
/* 1206 */       int twoHalfs = 0;
/*      */       do {
/* 1208 */         if ((0 <= halfbyte) && (halfbyte <= 9)) {
/* 1209 */           buf.append((char)(48 + halfbyte));
/*      */         } else {
/* 1211 */           buf.append((char)(97 + (halfbyte - 10)));
/*      */         }
/* 1213 */         halfbyte = aData & 0xF;
/* 1214 */       } while (twoHalfs++ < 1);
/*      */     }
/* 1216 */     return buf.toString();
/*      */   }
/*      */   
/*      */   private static String encodeAll(String password, String capthaId, String login) throws NoSuchAlgorithmException, UnsupportedEncodingException { String toCode;
/*      */     String toCode;
/* 1221 */     if (capthaId != null) {
/* 1222 */       toCode = encodeString(password) + capthaId + login;
/*      */     } else {
/* 1224 */       toCode = encodeString(password) + login;
/*      */     }
/*      */     
/* 1227 */     return encodeString(toCode);
/*      */   }
/*      */   
/*      */   public static String encodeString(String string) throws NoSuchAlgorithmException, UnsupportedEncodingException
/*      */   {
/* 1232 */     MessageDigest md = MessageDigest.getInstance("SHA-1");
/* 1233 */     md.update(string.getBytes("iso-8859-1"), 0, string.length());
/* 1234 */     byte[] sha1hash = md.digest();
/* 1235 */     return convertToHex(sha1hash).toUpperCase();
/*      */   }
/*      */   
/*      */   public URL getBaseUrl() {
/* 1239 */     return this.configurationPool.get();
/*      */   }
/*      */   
/*      */   public String getLoginUrl() {
/* 1243 */     return this.configurationPool.get().toString();
/*      */   }
/*      */   
/*      */   public static boolean validAPIServerAddressFormat(String address) {
/*      */     try {
/* 1248 */       Matcher matcher = RESULT_PATTERN.matcher(address);
/* 1249 */       if (matcher.matches()) {
/* 1250 */         return true;
/*      */       }
/*      */     } catch (Throwable e) {
/* 1253 */       LOGGER.error(e.getMessage(), e);
/*      */     }
/*      */     
/* 1256 */     return false;
/*      */   }
/*      */   
/*      */   private static class DummyHostNameVerifier
/*      */     implements HostnameVerifier
/*      */   {
/*      */     public boolean verify(String hostname, SSLSession session)
/*      */     {
/* 1264 */       AuthorizationClient.LOGGER.debug("Verify : {} @ {}", hostname, session);
/* 1265 */       return true;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\AuthorizationClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */