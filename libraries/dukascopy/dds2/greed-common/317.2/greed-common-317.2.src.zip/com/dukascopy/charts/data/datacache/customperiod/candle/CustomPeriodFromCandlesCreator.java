/*     */ package com.dukascopy.charts.data.datacache.customperiod.candle;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.customperiod.AbstractCustomPeriodCreator;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomPeriodFromCandlesCreator
/*     */   extends AbstractCustomPeriodCreator
/*     */ {
/*  20 */   protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
/*     */   
/*  22 */   static { DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT 0")); }
/*     */   
/*     */ 
/*     */ 
/*     */   private final Period basicPeriod;
/*     */   
/*     */ 
/*     */   private CandleData currentCandleDataUnderAnalysis;
/*     */   
/*     */ 
/*     */   private CandleData previouslyAnalysedCandleData;
/*     */   
/*     */   public CustomPeriodFromCandlesCreator(Instrument instrument, Period desiredPeriod, Period basicPeriod, OfferSide offerSide)
/*     */   {
/*  36 */     super(instrument, offerSide, desiredPeriod);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */     this.basicPeriod = basicPeriod;
/*     */     
/*  44 */     this.currentCandleDataUnderAnalysis = null;
/*  45 */     this.previouslyAnalysedCandleData = null;
/*     */   }
/*     */   
/*     */   public CandleData analyse(CandleData data) {
/*  49 */     if (this.currentCandleDataUnderAnalysis == null) {
/*  50 */       startNewCandleAnalysis(data);
/*     */     }
/*     */     else {
/*  53 */       long currentCandleStartTimeForData = DataCacheUtils.getCandleStartFast(getDesiredPeriod(), data.getTime());
/*  54 */       long nextCandleStartTimeForData = DataCacheUtils.getCandleStartFast(getDesiredPeriod(), data.getTime() + getBasicPeriod().getInterval());
/*     */       
/*  56 */       if ((this.currentCandleDataUnderAnalysis.getTime() == currentCandleStartTimeForData) && (nextCandleStartTimeForData > currentCandleStartTimeForData)) {
/*  57 */         continueCurrentCandleAnalysis(data);
/*  58 */         CandleData candleDataResult = finishCurrentCandleAnalysis();
/*  59 */         fireNewCandle(candleDataResult);
/*  60 */         return candleDataResult;
/*     */       }
/*  62 */       if (currentCandleStartTimeForData > this.currentCandleDataUnderAnalysis.getTime())
/*     */       {
/*     */ 
/*     */ 
/*  66 */         CandleData candleDataResult = finishCurrentCandleAnalysis();
/*  67 */         fireNewCandle(candleDataResult);
/*  68 */         startNewCandleAnalysis(data);
/*  69 */         return candleDataResult;
/*     */       }
/*     */       
/*  72 */       continueCurrentCandleAnalysis(data);
/*     */     }
/*     */     
/*     */ 
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   protected CandleData finishCurrentCandleAnalysis() {
/*  80 */     this.previouslyAnalysedCandleData = this.currentCandleDataUnderAnalysis;
/*  81 */     this.currentCandleDataUnderAnalysis = null;
/*  82 */     return this.previouslyAnalysedCandleData;
/*     */   }
/*     */   
/*     */   protected void continueCurrentCandleAnalysis(CandleData data)
/*     */   {
/*  87 */     boolean isFlat = isFlat(data);
/*     */     
/*  89 */     if (!isFlat) {
/*  90 */       if (isFlat(this.currentCandleDataUnderAnalysis)) {
/*  91 */         this.currentCandleDataUnderAnalysis.setOpen(data.getOpen());
/*  92 */         this.currentCandleDataUnderAnalysis.setClose(data.getClose());
/*  93 */         this.currentCandleDataUnderAnalysis.setHigh(data.getHigh());
/*  94 */         this.currentCandleDataUnderAnalysis.setLow(data.getLow());
/*  95 */         this.currentCandleDataUnderAnalysis.setVolume(data.getVolume());
/*     */       } else {
/*  97 */         this.currentCandleDataUnderAnalysis.setVolume(round(this.currentCandleDataUnderAnalysis.getVolume() + data.getVolume()));
/*  98 */         this.currentCandleDataUnderAnalysis.setClose(data.getClose());
/*     */         
/* 100 */         if (this.currentCandleDataUnderAnalysis.getHigh() < data.getHigh()) {
/* 101 */           this.currentCandleDataUnderAnalysis.setHigh(data.getHigh());
/*     */         }
/*     */         
/* 104 */         if (this.currentCandleDataUnderAnalysis.getLow() > data.getLow()) {
/* 105 */           this.currentCandleDataUnderAnalysis.setLow(data.getLow());
/*     */         }
/*     */       }
/*     */     }
/* 109 */     else if (isFlat(this.currentCandleDataUnderAnalysis)) {
/* 110 */       this.currentCandleDataUnderAnalysis.setOpen(data.getOpen());
/* 111 */       this.currentCandleDataUnderAnalysis.setClose(data.getClose());
/* 112 */       this.currentCandleDataUnderAnalysis.setHigh(data.getHigh());
/* 113 */       this.currentCandleDataUnderAnalysis.setLow(data.getLow());
/* 114 */       this.currentCandleDataUnderAnalysis.setVolume(data.getVolume());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void startNewCandleAnalysis(CandleData data)
/*     */   {
/* 121 */     this.currentCandleDataUnderAnalysis = new CandleData();
/*     */     
/* 123 */     this.currentCandleDataUnderAnalysis.setClose(data.getClose());
/* 124 */     this.currentCandleDataUnderAnalysis.setHigh(data.getHigh());
/* 125 */     this.currentCandleDataUnderAnalysis.setLow(data.getLow());
/* 126 */     this.currentCandleDataUnderAnalysis.setOpen(data.getOpen());
/* 127 */     this.currentCandleDataUnderAnalysis.setVolume(data.getVolume());
/*     */     
/* 129 */     this.currentCandleDataUnderAnalysis.setTime(DataCacheUtils.getCandleStartFast(getDesiredPeriod(), data.getTime()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isFlat(CandleData data)
/*     */   {
/* 140 */     if ((data.getClose() == data.getOpen()) && (data.getOpen() == data.getHigh()) && (data.getHigh() == data.getLow()) && (data.getVolume() == 0.0D))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */       return true;
/*     */     }
/*     */     
/* 149 */     return false;
/*     */   }
/*     */   
/*     */   protected CandleData getCurrentCandleDataUnderAnalysis()
/*     */   {
/* 154 */     return this.currentCandleDataUnderAnalysis;
/*     */   }
/*     */   
/*     */ 
/* 158 */   protected void setCurrentCandleDataUnderAnalysis(CandleData newCurrentCandleDataUnderAnalysis) { this.currentCandleDataUnderAnalysis = newCurrentCandleDataUnderAnalysis; }
/*     */   
/*     */   protected CandleData[] completeAnalysis() {
/* 161 */     CandleData candleDataResult = finishCurrentCandleAnalysis();
/*     */     
/* 163 */     CandleData[] result = { candleDataResult };
/* 164 */     return result;
/*     */   }
/*     */   
/*     */   protected Period getBasicPeriod() {
/* 168 */     return this.basicPeriod;
/*     */   }
/*     */   
/*     */   private double round(double value) {
/* 172 */     return StratUtils.round(value, 8);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customperiod\candle\CustomPeriodFromCandlesCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */