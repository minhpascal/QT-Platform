/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.ICloseOrder;
/*    */ import com.dukascopy.api.IEngine.OrderCommand;
/*    */ import com.dukascopy.api.IFillOrder;
/*    */ import com.dukascopy.api.IOrder.State;
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class InternalPlatformOrder extends PlatformOrderImpl
/*    */ {
/*    */   private JForexInternalEngineImpl engine;
/*    */   
/*    */   public InternalPlatformOrder(JForexTaskManager taskManager, JForexInternalEngineImpl engine)
/*    */   {
/* 19 */     super(taskManager);
/* 20 */     this.engine = engine;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public InternalPlatformOrder(JForexTaskManager taskManager, JForexInternalEngineImpl engine, String comment, Instrument instrument, double requestedAmount, double filledAmount, String label, double tpPrice, double slPrice, OfferSide slSide, double slTrailStep, double openPrice, double closePrice, IOrder.State state, String groupId, String openingOrderId, String pendingOrderId, IEngine.OrderCommand pendingOrderCommand, String slOrderId, String tpOrderId, long goodTillTime, long creationTime, long fillTime, long closeTime, IEngine.OrderCommand orderCommand, double commission)
/*    */   {
/* 27 */     super(taskManager, comment, instrument, requestedAmount, filledAmount, label, tpPrice, slPrice, slSide, slTrailStep, openPrice, closePrice, state, groupId, openingOrderId, pendingOrderId, pendingOrderCommand, slOrderId, tpOrderId, goodTillTime, creationTime, fillTime, closeTime, orderCommand, commission, Collections.emptyList(), Collections.emptyList());
/*    */     
/* 29 */     this.engine = engine;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public InternalPlatformOrder(JForexTaskManager taskManager, JForexInternalEngineImpl engine, String comment, Instrument instrument, double requestedAmount, double filledAmount, String label, double tpPrice, double slPrice, OfferSide slSide, double slTrailStep, double openPrice, double closePrice, IOrder.State state, String groupId, String openingOrderId, String pendingOrderId, IEngine.OrderCommand pendingOrderCommand, String slOrderId, String tpOrderId, long goodTillTime, long creationTime, long fillTime, long closeTime, IEngine.OrderCommand orderCommand, double commission, List<IFillOrder> fillHistory, List<ICloseOrder> closeHistory)
/*    */   {
/* 36 */     super(taskManager, comment, instrument, requestedAmount, filledAmount, label, tpPrice, slPrice, slSide, slTrailStep, openPrice, closePrice, state, groupId, openingOrderId, pendingOrderId, pendingOrderCommand, slOrderId, tpOrderId, goodTillTime, creationTime, fillTime, closeTime, orderCommand, commission, fillHistory, closeHistory);
/*    */     
/* 38 */     this.engine = engine;
/*    */   }
/*    */   
/*    */   public InternalPlatformOrder(JForexTaskManager taskManager, JForexInternalEngineImpl engine, PlatformOrderImpl oldOrder) {
/* 42 */     super(taskManager, oldOrder.comment, oldOrder.instrument, oldOrder.requestedAmount, oldOrder.filledAmount, oldOrder.label, oldOrder.tpPrice, oldOrder.slPrice, oldOrder.slSide, oldOrder.slTrailStep, oldOrder.openPrice, oldOrder.closePrice, oldOrder.getState(), oldOrder.groupId, oldOrder.openingOrderId, oldOrder.pendingOrderId, oldOrder.pendingOrderCommand, oldOrder.slOrderId, oldOrder.tpOrderId, oldOrder.goodTillTime, oldOrder.creationTime, oldOrder.fillTime, oldOrder.closeTime, oldOrder.orderCommand, oldOrder.commission, oldOrder.getFillHistory(), oldOrder.getCloseHistory());
/*    */     
/*    */ 
/*    */ 
/* 46 */     this.engine = engine;
/*    */   }
/*    */   
/*    */   public void setStopLossPrice(double price, OfferSide side, double trailingStep) throws JFException
/*    */   {
/* 51 */     this.slPrice = price;
/* 52 */     this.slSide = side;
/* 53 */     this.slTrailStep = trailingStep;
/*    */     
/* 55 */     this.engine.setStopLoss(this, price, side, trailingStep);
/*    */   }
/*    */   
/*    */   public void setTakeProfitPrice(double price) throws JFException
/*    */   {
/* 60 */     this.tpPrice = price;
/*    */     
/* 62 */     this.engine.setTakeProfit(this, price);
/*    */   }
/*    */   
/*    */   public void setRequestedAmount(double amount) throws JFException
/*    */   {
/* 67 */     this.requestedAmount = amount;
/*    */     
/* 69 */     this.engine.setRequestedAmount(this, amount);
/*    */   }
/*    */   
/*    */   public void setOpenPrice(double price) throws JFException
/*    */   {
/* 74 */     this.openPrice = price;
/*    */     
/* 76 */     this.engine.setOpenPrice(this, price);
/*    */   }
/*    */   
/*    */   public void close(double amount, double price, double slippage) throws JFException
/*    */   {
/* 81 */     this.engine.close(this, amount, price, slippage);
/*    */   }
/*    */   
/*    */   public void setGoodTillTime(long goodTillTime) throws JFException
/*    */   {
/* 86 */     this.engine.setGoodTillTime(this, goodTillTime);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\InternalPlatformOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */