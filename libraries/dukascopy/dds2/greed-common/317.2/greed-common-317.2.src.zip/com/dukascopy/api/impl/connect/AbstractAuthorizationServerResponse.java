/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ 
/*    */ public abstract class AbstractAuthorizationServerResponse
/*    */ {
/*  6 */   protected String responseMessage = null;
/*  7 */   protected AuthorizationClient.AuthorizationServerResponseCode responseCode = null;
/*    */   
/*    */   protected abstract void validateResponse(String paramString);
/*    */   
/*    */   public String getResponseMessage() {
/* 12 */     return this.responseMessage;
/*    */   }
/*    */   
/*    */   public AuthorizationClient.AuthorizationServerResponseCode getResponseCode() {
/* 16 */     return this.responseCode;
/*    */   }
/*    */   
/*    */   protected void init() {
/* 20 */     if (this.responseMessage != null) {
/* 21 */       this.responseMessage.trim();
/*    */     }
/*    */     
/* 24 */     if (AuthorizationClient.AuthorizationServerResponseCode.SUCCESS_OK == this.responseCode) {
/* 25 */       if ((this.responseMessage != null) && (this.responseMessage.length() > 0)) {
/* 26 */         if ((this.responseMessage.equals("-1")) || (this.responseMessage.equals("-2")) || (this.responseMessage.equals("-3")) || (this.responseMessage.equals("-500"))) {
/* 27 */           int responseCode = Integer.parseInt(this.responseMessage);
/* 28 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.fromValue(responseCode);
/*    */         } else {
/* 30 */           validateResponse(this.responseMessage);
/*    */         }
/*    */       } else {
/* 33 */         validateResponse(this.responseMessage);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isOK() {
/* 39 */     if (AuthorizationClient.AuthorizationServerResponseCode.SUCCESS_OK == this.responseCode) {
/* 40 */       return true;
/*    */     }
/*    */     
/* 43 */     return false;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 47 */     String message = "no AUTH response";
/*    */     
/* 49 */     if (this.responseMessage != null) {
/* 50 */       message = this.responseMessage;
/*    */     }
/*    */     
/* 53 */     if (this.responseCode != null) {
/* 54 */       message = message + " (" + this.responseCode.getCode() + " " + this.responseCode.getMessage() + ")";
/*    */     }
/*    */     
/* 57 */     return message;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\AbstractAuthorizationServerResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */