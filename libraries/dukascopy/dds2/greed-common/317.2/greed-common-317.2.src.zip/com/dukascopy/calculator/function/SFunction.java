package com.dukascopy.calculator.function;

import com.dukascopy.calculator.OObject;

public abstract class SFunction
  extends PObject
{
  public abstract double function(double paramDouble);
  
  public abstract OObject function(OObject paramOObject);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\SFunction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */