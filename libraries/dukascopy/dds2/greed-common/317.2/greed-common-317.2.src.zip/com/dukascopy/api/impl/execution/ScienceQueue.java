/*      */ package com.dukascopy.api.impl.execution;
/*      */ 
/*      */ import com.dukascopy.api.ITick;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.impl.execution.post.PostTickTask;
/*      */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.AbstractQueue;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.concurrent.BlockingDeque;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.locks.Condition;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ScienceQueue<E extends ScienceFuture<Task>>
/*      */   extends AbstractQueue<E>
/*      */   implements BlockingDeque<E>, Serializable
/*      */ {
/*      */   private static final long TICK_SURVIVE_TIME = 1000L;
/*   62 */   private static final int INSTRUMENTS_LENGTH = Instrument.values().length;
/*      */   
/*   64 */   private static final Logger LOGGER = LoggerFactory.getLogger(ScienceQueue.class);
/*      */   
/*      */   private Thread dropTicksThread;
/*      */   
/*      */   private boolean stopThread;
/*   69 */   private long lastOverloadWarning = Long.MIN_VALUE;
/*      */   
/*      */   private static final long serialVersionUID = -387911632671998426L;
/*      */   private transient Node<E> first;
/*      */   private transient Node<E> last;
/*      */   private transient int count;
/*      */   private final int capacity;
/*      */   
/*      */   private void dropOldTicks(E e)
/*      */   {
/*   79 */     Task task = e.getTask();
/*   80 */     if (task.getType() == Task.Type.TICK)
/*      */     {
/*   82 */       if (this.count > 0)
/*      */       {
/*      */         ITick taskTick;
/*      */         
/*   86 */         if ((task instanceof TaskTick)) {
/*   87 */           Instrument taskInstrument = ((TaskTick)task).getInstrument();
/*   88 */           taskTick = ((TaskTick)task).getTick();
/*      */         } else { ITick taskTick;
/*   90 */           if ((task instanceof PostTickTask)) {
/*   91 */             Instrument taskInstrument = ((PostTickTask)task).getInstrument();
/*   92 */             taskTick = ((PostTickTask)task).getTick();
/*      */           }
/*      */           else {
/*   95 */             throw new ClassCastException("Can not cast tick task " + task); } }
/*      */         ITick taskTick;
/*      */         Instrument taskInstrument;
/*   98 */         long[][] latestTicks = new long[2][INSTRUMENTS_LENGTH];
/*   99 */         long currentTime = taskTick.getTime();
/*      */         
/*  101 */         latestTicks[0][taskInstrument.ordinal()] = currentTime;
/*  102 */         latestTicks[1][taskInstrument.ordinal()] = 1L;
/*      */         
/*  104 */         for (Node<E> p = this.last; p != null; p = p.prev) {
/*  105 */           ScienceFuture<Task> future = (ScienceFuture)p.item;
/*  106 */           Task queueTask = future.getTask();
/*  107 */           if (queueTask.getType() == Task.Type.TICK)
/*      */           {
/*      */             ITick tick;
/*      */             
/*  111 */             if ((task instanceof TaskTick)) {
/*  112 */               Instrument instrument = ((TaskTick)task).getInstrument();
/*  113 */               tick = ((TaskTick)task).getTick();
/*      */             } else { ITick tick;
/*  115 */               if ((task instanceof PostTickTask)) {
/*  116 */                 Instrument instrument = ((PostTickTask)task).getInstrument();
/*  117 */                 tick = ((PostTickTask)task).getTick();
/*      */               }
/*      */               else {
/*  120 */                 throw new ClassCastException("Can not cast tick task " + task); } }
/*      */             ITick tick;
/*      */             Instrument instrument;
/*  123 */             if (latestTicks[0][instrument.ordinal()] != 0L)
/*      */             {
/*  125 */               if ((currentTime - tick.getTime() > 1000L) || (latestTicks[1][instrument.ordinal()] >= 3L)) {
/*  126 */                 unlink(p);
/*  127 */                 if (LOGGER.isDebugEnabled()) {
/*  128 */                   LOGGER.debug("old tick removed from the queue [" + tick + "], current time [" + currentTime + "], diff [" + (currentTime - tick.getTime()) + "] tick waiting in queue [" + latestTicks[1][instrument.ordinal()] + "]");
/*      */                 }
/*      */               } else {
/*  131 */                 latestTicks[1][instrument.ordinal()] += 1L;
/*      */               }
/*      */             }
/*      */             else {
/*  135 */               latestTicks[0][instrument.ordinal()] = tick.getTime();
/*  136 */               latestTicks[1][instrument.ordinal()] = 1L;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  141 */     } else if (task.getType() == Task.Type.ACCOUNT)
/*      */     {
/*  143 */       if (this.count > 0)
/*      */       {
/*  145 */         for (Node<E> p = this.last; p != null; p = p.prev) {
/*  146 */           ScienceFuture<Task> future = (ScienceFuture)p.item;
/*  147 */           Task queueTask = future.getTask();
/*  148 */           if (queueTask.getType() == Task.Type.ACCOUNT) {
/*  149 */             unlink(p);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void dropOldTicksByCurrentTime() {
/*  157 */     long currentLocalTime = System.currentTimeMillis();
/*  158 */     boolean[] latestTicksExist = new boolean[INSTRUMENTS_LENGTH];
/*  159 */     for (Node<E> p = this.last; p != null; p = p.prev) {
/*  160 */       ScienceFuture<Task> future = (ScienceFuture)p.item;
/*  161 */       Task queueTask = future.getTask();
/*  162 */       if (queueTask.getType() == Task.Type.TICK)
/*      */       {
/*      */         long addedTime;
/*      */         
/*  166 */         if ((queueTask instanceof TaskTick)) {
/*  167 */           Instrument taskInstrument = ((TaskTick)queueTask).getInstrument();
/*  168 */           ITick taskTick = ((TaskTick)queueTask).getTick();
/*  169 */           addedTime = ((TaskTick)queueTask).getAddedTime();
/*      */         } else { long addedTime;
/*  171 */           if ((queueTask instanceof PostTickTask)) {
/*  172 */             Instrument taskInstrument = ((PostTickTask)queueTask).getInstrument();
/*  173 */             ITick taskTick = ((PostTickTask)queueTask).getTick();
/*  174 */             addedTime = ((PostTickTask)queueTask).getAddedTime();
/*      */           }
/*      */           else {
/*  177 */             throw new ClassCastException("Can not cast tick task " + queueTask); } }
/*      */         Instrument taskInstrument;
/*      */         long addedTime;
/*  180 */         ITick taskTick; if (latestTicksExist[taskInstrument.ordinal()] != 0)
/*      */         {
/*  182 */           if (currentLocalTime - addedTime > 1000L) {
/*  183 */             unlink(p);
/*  184 */             if (LOGGER.isDebugEnabled()) {
/*  185 */               LOGGER.debug("old tick removed from the queue [" + taskTick + "], current local time [" + currentLocalTime + "], diff [" + (currentLocalTime - addedTime) + "]");
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/*  190 */           latestTicksExist[taskInstrument.ordinal()] = true;
/*      */         }
/*      */       }
/*      */     }
/*  194 */     if ((this.count > 500) && (this.lastOverloadWarning + 5000L < System.currentTimeMillis())) {
/*  195 */       int ticks = 0;
/*  196 */       int bars = 0;
/*  197 */       int tasks = 0;
/*  198 */       for (Node<E> p = this.first; p != null; p = p.next) {
/*  199 */         ScienceFuture<Task> future = (ScienceFuture)p.item;
/*  200 */         Task queueTask = future.getTask();
/*  201 */         if (queueTask.getType() == Task.Type.TICK) {
/*  202 */           ticks++;
/*  203 */         } else if (queueTask.getType() == Task.Type.BAR) {
/*  204 */           bars++;
/*      */         } else {
/*  206 */           tasks++;
/*      */         }
/*      */       }
/*  209 */       if (this.count > 2000) {
/*  210 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage("Strategy thread queue overloaded with tasks. Ticks in queue - " + ticks + ", bars - " + bars + ", other tasks - " + tasks, true);
/*      */       }
/*      */       else {
/*  213 */         NotificationUtilsProvider.getNotificationUtils().postWarningMessage("Strategy thread queue overloaded with tasks. Ticks in queue - " + ticks + ", bars - " + bars + ", other tasks - " + tasks, true);
/*      */       }
/*      */       
/*  216 */       this.lastOverloadWarning = System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class Node<E>
/*      */   {
/*      */     E item;
/*      */     
/*      */ 
/*      */ 
/*      */     Node<E> prev;
/*      */     
/*      */ 
/*      */ 
/*      */     Node<E> next;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Node(E x, Node<E> p, Node<E> n)
/*      */     {
/*  240 */       this.item = x;
/*  241 */       this.prev = p;
/*  242 */       this.next = n;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  255 */   private final ReentrantLock lock = new ReentrantLock();
/*      */   
/*  257 */   private final Condition notEmpty = this.lock.newCondition();
/*      */   
/*  259 */   private final Condition notFull = this.lock.newCondition();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ScienceQueue()
/*      */   {
/*  266 */     this(Integer.MAX_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ScienceQueue(int capacity)
/*      */   {
/*  276 */     if (capacity <= 0) throw new IllegalArgumentException();
/*  277 */     this.capacity = capacity;
/*  278 */     this.dropTicksThread = new Thread("SQOTD")
/*      */     {
/*      */       public void run() {
/*  281 */         while (!ScienceQueue.this.stopThread) {
/*  282 */           ReentrantLock lock = ScienceQueue.this.lock;
/*  283 */           lock.lock();
/*      */           try {
/*  285 */             ScienceQueue.this.dropOldTicksByCurrentTime();
/*      */           } finally {
/*  287 */             lock.unlock();
/*      */           }
/*      */           try {
/*  290 */             Thread.sleep(100L);
/*      */ 
/*      */           }
/*      */           catch (InterruptedException e) {}
/*      */         }
/*      */       }
/*  296 */     };
/*  297 */     this.dropTicksThread.setDaemon(true);
/*  298 */     this.dropTicksThread.start();
/*      */   }
/*      */   
/*      */   protected void stop() {
/*  302 */     this.stopThread = true;
/*  303 */     this.dropTicksThread.interrupt();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ScienceQueue(Collection<? extends E> c)
/*      */   {
/*  317 */     this(Integer.MAX_VALUE);
/*  318 */     for (E e : c) {
/*  319 */       add(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean linkFirst(E e)
/*      */   {
/*  329 */     if (this.count >= this.capacity)
/*  330 */       return false;
/*  331 */     this.count += 1;
/*  332 */     Node<E> f = this.first;
/*  333 */     Node<E> x = new Node(e, null, f);
/*  334 */     this.first = x;
/*  335 */     if (this.last == null) {
/*  336 */       this.last = x;
/*      */     } else
/*  338 */       f.prev = x;
/*  339 */     this.notEmpty.signal();
/*  340 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean linkLast(E e)
/*      */   {
/*  347 */     if (this.count >= this.capacity)
/*  348 */       return false;
/*  349 */     this.count += 1;
/*  350 */     Node<E> l = this.last;
/*  351 */     Node<E> x = new Node(e, l, null);
/*  352 */     this.last = x;
/*  353 */     if (this.first == null) {
/*  354 */       this.first = x;
/*      */     } else
/*  356 */       l.next = x;
/*  357 */     this.notEmpty.signal();
/*  358 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private E unlinkFirst()
/*      */   {
/*  365 */     Node<E> f = this.first;
/*  366 */     if (f == null)
/*  367 */       return null;
/*  368 */     Node<E> n = f.next;
/*  369 */     this.first = n;
/*  370 */     if (n == null) {
/*  371 */       this.last = null;
/*      */     } else
/*  373 */       n.prev = null;
/*  374 */     this.count -= 1;
/*  375 */     this.notFull.signal();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  388 */     return (ScienceFuture)f.item;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private E unlinkLast()
/*      */   {
/*  395 */     Node<E> l = this.last;
/*  396 */     if (l == null)
/*  397 */       return null;
/*  398 */     Node<E> p = l.prev;
/*  399 */     this.last = p;
/*  400 */     if (p == null) {
/*  401 */       this.first = null;
/*      */     } else
/*  403 */       p.next = null;
/*  404 */     this.count -= 1;
/*  405 */     this.notFull.signal();
/*  406 */     return (ScienceFuture)l.item;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void unlink(Node<E> x)
/*      */   {
/*  413 */     Node<E> p = x.prev;
/*  414 */     Node<E> n = x.next;
/*  415 */     if (p == null) {
/*  416 */       if (n == null) {
/*  417 */         this.first = (this.last = null);
/*      */       } else {
/*  419 */         n.prev = null;
/*  420 */         this.first = n;
/*      */       }
/*  422 */     } else if (n == null) {
/*  423 */       p.next = null;
/*  424 */       this.last = p;
/*      */     } else {
/*  426 */       p.next = n;
/*  427 */       n.prev = p;
/*      */     }
/*  429 */     this.count -= 1;
/*  430 */     this.notFull.signalAll();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFirst(E e)
/*      */   {
/*  440 */     if (!offerFirst(e)) {
/*  441 */       throw new IllegalStateException("Deque full");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addLast(E e)
/*      */   {
/*  449 */     if (!offerLast(e)) {
/*  450 */       throw new IllegalStateException("Deque full");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean offerFirst(E e)
/*      */   {
/*  457 */     if (e == null) throw new NullPointerException();
/*  458 */     this.lock.lock();
/*      */     try {
/*  460 */       dropOldTicks(e);
/*  461 */       return linkFirst(e);
/*      */     } finally {
/*  463 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean offerLast(E e)
/*      */   {
/*  471 */     if (e == null) throw new NullPointerException();
/*  472 */     this.lock.lock();
/*      */     try {
/*  474 */       dropOldTicks(e);
/*  475 */       return linkLast(e);
/*      */     } finally {
/*  477 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void putFirst(E e)
/*      */     throws InterruptedException
/*      */   {
/*  486 */     if (e == null) throw new NullPointerException();
/*  487 */     this.lock.lock();
/*      */     try {
/*  489 */       dropOldTicks(e);
/*  490 */       while (!linkFirst(e))
/*  491 */         this.notFull.await();
/*      */     } finally {
/*  493 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void putLast(E e)
/*      */     throws InterruptedException
/*      */   {
/*  502 */     if (e == null) throw new NullPointerException();
/*  503 */     this.lock.lock();
/*      */     try {
/*  505 */       dropOldTicks(e);
/*  506 */       while (!linkLast(e))
/*  507 */         this.notFull.await();
/*      */     } finally {
/*  509 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean offerFirst(E e, long timeout, TimeUnit unit)
/*      */     throws InterruptedException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +11 -> 12
/*      */     //   4: new 95	java/lang/NullPointerException
/*      */     //   7: dup
/*      */     //   8: invokespecial 96	java/lang/NullPointerException:<init>	()V
/*      */     //   11: athrow
/*      */     //   12: aload 4
/*      */     //   14: lload_2
/*      */     //   15: invokevirtual 103	java/util/concurrent/TimeUnit:toNanos	(J)J
/*      */     //   18: lstore 5
/*      */     //   20: aload_0
/*      */     //   21: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   24: invokevirtual 104	java/util/concurrent/locks/ReentrantLock:lockInterruptibly	()V
/*      */     //   27: aload_0
/*      */     //   28: aload_1
/*      */     //   29: invokespecial 98	com/dukascopy/api/impl/execution/ScienceQueue:dropOldTicks	(Lcom/dukascopy/api/impl/execution/ScienceFuture;)V
/*      */     //   32: aload_0
/*      */     //   33: aload_1
/*      */     //   34: invokespecial 99	com/dukascopy/api/impl/execution/ScienceQueue:linkFirst	(Lcom/dukascopy/api/impl/execution/ScienceFuture;)Z
/*      */     //   37: ifeq +16 -> 53
/*      */     //   40: iconst_1
/*      */     //   41: istore 7
/*      */     //   43: aload_0
/*      */     //   44: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   47: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   50: iload 7
/*      */     //   52: ireturn
/*      */     //   53: lload 5
/*      */     //   55: lconst_0
/*      */     //   56: lcmp
/*      */     //   57: ifgt +16 -> 73
/*      */     //   60: iconst_0
/*      */     //   61: istore 7
/*      */     //   63: aload_0
/*      */     //   64: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   67: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   70: iload 7
/*      */     //   72: ireturn
/*      */     //   73: aload_0
/*      */     //   74: getfield 71	com/dukascopy/api/impl/execution/ScienceQueue:notFull	Ljava/util/concurrent/locks/Condition;
/*      */     //   77: lload 5
/*      */     //   79: invokeinterface 105 3 0
/*      */     //   84: lstore 5
/*      */     //   86: goto -54 -> 32
/*      */     //   89: astore 8
/*      */     //   91: aload_0
/*      */     //   92: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   95: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   98: aload 8
/*      */     //   100: athrow
/*      */     // Line number table:
/*      */     //   Java source line #519	-> byte code offset #0
/*      */     //   Java source line #520	-> byte code offset #12
/*      */     //   Java source line #521	-> byte code offset #20
/*      */     //   Java source line #523	-> byte code offset #27
/*      */     //   Java source line #525	-> byte code offset #32
/*      */     //   Java source line #526	-> byte code offset #40
/*      */     //   Java source line #532	-> byte code offset #43
/*      */     //   Java source line #527	-> byte code offset #53
/*      */     //   Java source line #528	-> byte code offset #60
/*      */     //   Java source line #532	-> byte code offset #63
/*      */     //   Java source line #529	-> byte code offset #73
/*      */     //   Java source line #532	-> byte code offset #89
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	101	0	this	ScienceQueue<E>
/*      */     //   0	101	1	e	E
/*      */     //   0	101	2	timeout	long
/*      */     //   0	101	4	unit	TimeUnit
/*      */     //   18	67	5	nanos	long
/*      */     //   41	30	7	bool	boolean
/*      */     //   89	10	8	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	43	89	finally
/*      */     //   53	63	89	finally
/*      */     //   73	91	89	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public boolean offerLast(E e, long timeout, TimeUnit unit)
/*      */     throws InterruptedException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +11 -> 12
/*      */     //   4: new 95	java/lang/NullPointerException
/*      */     //   7: dup
/*      */     //   8: invokespecial 96	java/lang/NullPointerException:<init>	()V
/*      */     //   11: athrow
/*      */     //   12: aload 4
/*      */     //   14: lload_2
/*      */     //   15: invokevirtual 103	java/util/concurrent/TimeUnit:toNanos	(J)J
/*      */     //   18: lstore 5
/*      */     //   20: aload_0
/*      */     //   21: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   24: invokevirtual 104	java/util/concurrent/locks/ReentrantLock:lockInterruptibly	()V
/*      */     //   27: aload_0
/*      */     //   28: aload_1
/*      */     //   29: invokespecial 98	com/dukascopy/api/impl/execution/ScienceQueue:dropOldTicks	(Lcom/dukascopy/api/impl/execution/ScienceFuture;)V
/*      */     //   32: aload_0
/*      */     //   33: aload_1
/*      */     //   34: invokespecial 101	com/dukascopy/api/impl/execution/ScienceQueue:linkLast	(Lcom/dukascopy/api/impl/execution/ScienceFuture;)Z
/*      */     //   37: ifeq +16 -> 53
/*      */     //   40: iconst_1
/*      */     //   41: istore 7
/*      */     //   43: aload_0
/*      */     //   44: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   47: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   50: iload 7
/*      */     //   52: ireturn
/*      */     //   53: lload 5
/*      */     //   55: lconst_0
/*      */     //   56: lcmp
/*      */     //   57: ifgt +16 -> 73
/*      */     //   60: iconst_0
/*      */     //   61: istore 7
/*      */     //   63: aload_0
/*      */     //   64: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   67: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   70: iload 7
/*      */     //   72: ireturn
/*      */     //   73: aload_0
/*      */     //   74: getfield 71	com/dukascopy/api/impl/execution/ScienceQueue:notFull	Ljava/util/concurrent/locks/Condition;
/*      */     //   77: lload 5
/*      */     //   79: invokeinterface 105 3 0
/*      */     //   84: lstore 5
/*      */     //   86: goto -54 -> 32
/*      */     //   89: astore 8
/*      */     //   91: aload_0
/*      */     //   92: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   95: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   98: aload 8
/*      */     //   100: athrow
/*      */     // Line number table:
/*      */     //   Java source line #542	-> byte code offset #0
/*      */     //   Java source line #543	-> byte code offset #12
/*      */     //   Java source line #544	-> byte code offset #20
/*      */     //   Java source line #546	-> byte code offset #27
/*      */     //   Java source line #548	-> byte code offset #32
/*      */     //   Java source line #549	-> byte code offset #40
/*      */     //   Java source line #555	-> byte code offset #43
/*      */     //   Java source line #550	-> byte code offset #53
/*      */     //   Java source line #551	-> byte code offset #60
/*      */     //   Java source line #555	-> byte code offset #63
/*      */     //   Java source line #552	-> byte code offset #73
/*      */     //   Java source line #555	-> byte code offset #89
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	101	0	this	ScienceQueue<E>
/*      */     //   0	101	1	e	E
/*      */     //   0	101	2	timeout	long
/*      */     //   0	101	4	unit	TimeUnit
/*      */     //   18	67	5	nanos	long
/*      */     //   41	30	7	bool	boolean
/*      */     //   89	10	8	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	43	89	finally
/*      */     //   53	63	89	finally
/*      */     //   73	91	89	finally
/*      */   }
/*      */   
/*      */   public E removeFirst()
/*      */   {
/*  563 */     E x = pollFirst();
/*  564 */     if (x == null) throw new NoSuchElementException();
/*  565 */     return x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public E removeLast()
/*      */   {
/*  572 */     E x = pollLast();
/*  573 */     if (x == null) throw new NoSuchElementException();
/*  574 */     return x;
/*      */   }
/*      */   
/*      */   public E pollFirst() {
/*  578 */     this.lock.lock();
/*      */     try {
/*  580 */       return unlinkFirst();
/*      */     } finally {
/*  582 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public E pollLast() {
/*  587 */     this.lock.lock();
/*      */     try {
/*  589 */       return unlinkLast();
/*      */     } finally {
/*  591 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public E takeFirst() throws InterruptedException {
/*  596 */     this.lock.lock();
/*      */     try {
/*      */       E x;
/*  599 */       while ((x = unlinkFirst()) == null)
/*  600 */         this.notEmpty.await();
/*  601 */       return x;
/*      */     } finally {
/*  603 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public E takeLast() throws InterruptedException {
/*  608 */     this.lock.lock();
/*      */     try {
/*      */       E x;
/*  611 */       while ((x = unlinkLast()) == null)
/*  612 */         this.notEmpty.await();
/*  613 */       return x;
/*      */     } finally {
/*  615 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public E pollFirst(long timeout, TimeUnit unit)
/*      */     throws InterruptedException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_3
/*      */     //   1: lload_1
/*      */     //   2: invokevirtual 103	java/util/concurrent/TimeUnit:toNanos	(J)J
/*      */     //   5: lstore 4
/*      */     //   7: aload_0
/*      */     //   8: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   11: invokevirtual 104	java/util/concurrent/locks/ReentrantLock:lockInterruptibly	()V
/*      */     //   14: aload_0
/*      */     //   15: invokespecial 110	com/dukascopy/api/impl/execution/ScienceQueue:unlinkFirst	()Lcom/dukascopy/api/impl/execution/ScienceFuture;
/*      */     //   18: astore 6
/*      */     //   20: aload 6
/*      */     //   22: ifnull +17 -> 39
/*      */     //   25: aload 6
/*      */     //   27: astore 7
/*      */     //   29: aload_0
/*      */     //   30: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   33: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   36: aload 7
/*      */     //   38: areturn
/*      */     //   39: lload 4
/*      */     //   41: lconst_0
/*      */     //   42: lcmp
/*      */     //   43: ifgt +16 -> 59
/*      */     //   46: aconst_null
/*      */     //   47: astore 7
/*      */     //   49: aload_0
/*      */     //   50: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   53: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   56: aload 7
/*      */     //   58: areturn
/*      */     //   59: aload_0
/*      */     //   60: getfield 70	com/dukascopy/api/impl/execution/ScienceQueue:notEmpty	Ljava/util/concurrent/locks/Condition;
/*      */     //   63: lload 4
/*      */     //   65: invokeinterface 105 3 0
/*      */     //   70: lstore 4
/*      */     //   72: goto -58 -> 14
/*      */     //   75: astore 8
/*      */     //   77: aload_0
/*      */     //   78: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   81: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   84: aload 8
/*      */     //   86: athrow
/*      */     // Line number table:
/*      */     //   Java source line #621	-> byte code offset #0
/*      */     //   Java source line #622	-> byte code offset #7
/*      */     //   Java source line #625	-> byte code offset #14
/*      */     //   Java source line #626	-> byte code offset #20
/*      */     //   Java source line #627	-> byte code offset #25
/*      */     //   Java source line #633	-> byte code offset #29
/*      */     //   Java source line #628	-> byte code offset #39
/*      */     //   Java source line #629	-> byte code offset #46
/*      */     //   Java source line #633	-> byte code offset #49
/*      */     //   Java source line #630	-> byte code offset #59
/*      */     //   Java source line #631	-> byte code offset #72
/*      */     //   Java source line #633	-> byte code offset #75
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	87	0	this	ScienceQueue<E>
/*      */     //   0	87	1	timeout	long
/*      */     //   0	87	3	unit	TimeUnit
/*      */     //   5	66	4	nanos	long
/*      */     //   18	8	6	x	E
/*      */     //   27	30	7	?	E
/*      */     //   75	10	8	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	29	75	finally
/*      */     //   39	49	75	finally
/*      */     //   59	77	75	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public E pollLast(long timeout, TimeUnit unit)
/*      */     throws InterruptedException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_3
/*      */     //   1: lload_1
/*      */     //   2: invokevirtual 103	java/util/concurrent/TimeUnit:toNanos	(J)J
/*      */     //   5: lstore 4
/*      */     //   7: aload_0
/*      */     //   8: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   11: invokevirtual 104	java/util/concurrent/locks/ReentrantLock:lockInterruptibly	()V
/*      */     //   14: aload_0
/*      */     //   15: invokespecial 111	com/dukascopy/api/impl/execution/ScienceQueue:unlinkLast	()Lcom/dukascopy/api/impl/execution/ScienceFuture;
/*      */     //   18: astore 6
/*      */     //   20: aload 6
/*      */     //   22: ifnull +17 -> 39
/*      */     //   25: aload 6
/*      */     //   27: astore 7
/*      */     //   29: aload_0
/*      */     //   30: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   33: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   36: aload 7
/*      */     //   38: areturn
/*      */     //   39: lload 4
/*      */     //   41: lconst_0
/*      */     //   42: lcmp
/*      */     //   43: ifgt +16 -> 59
/*      */     //   46: aconst_null
/*      */     //   47: astore 7
/*      */     //   49: aload_0
/*      */     //   50: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   53: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   56: aload 7
/*      */     //   58: areturn
/*      */     //   59: aload_0
/*      */     //   60: getfield 70	com/dukascopy/api/impl/execution/ScienceQueue:notEmpty	Ljava/util/concurrent/locks/Condition;
/*      */     //   63: lload 4
/*      */     //   65: invokeinterface 105 3 0
/*      */     //   70: lstore 4
/*      */     //   72: goto -58 -> 14
/*      */     //   75: astore 8
/*      */     //   77: aload_0
/*      */     //   78: getfield 4	com/dukascopy/api/impl/execution/ScienceQueue:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*      */     //   81: invokevirtual 100	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*      */     //   84: aload 8
/*      */     //   86: athrow
/*      */     // Line number table:
/*      */     //   Java source line #639	-> byte code offset #0
/*      */     //   Java source line #640	-> byte code offset #7
/*      */     //   Java source line #643	-> byte code offset #14
/*      */     //   Java source line #644	-> byte code offset #20
/*      */     //   Java source line #645	-> byte code offset #25
/*      */     //   Java source line #651	-> byte code offset #29
/*      */     //   Java source line #646	-> byte code offset #39
/*      */     //   Java source line #647	-> byte code offset #46
/*      */     //   Java source line #651	-> byte code offset #49
/*      */     //   Java source line #648	-> byte code offset #59
/*      */     //   Java source line #649	-> byte code offset #72
/*      */     //   Java source line #651	-> byte code offset #75
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	87	0	this	ScienceQueue<E>
/*      */     //   0	87	1	timeout	long
/*      */     //   0	87	3	unit	TimeUnit
/*      */     //   5	66	4	nanos	long
/*      */     //   18	8	6	x	E
/*      */     //   27	30	7	?	E
/*      */     //   75	10	8	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	29	75	finally
/*      */     //   39	49	75	finally
/*      */     //   59	77	75	finally
/*      */   }
/*      */   
/*      */   public E getFirst()
/*      */   {
/*  659 */     E x = peekFirst();
/*  660 */     if (x == null) throw new NoSuchElementException();
/*  661 */     return x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public E getLast()
/*      */   {
/*  668 */     E x = peekLast();
/*  669 */     if (x == null) throw new NoSuchElementException();
/*  670 */     return x;
/*      */   }
/*      */   
/*      */   public E peekFirst() {
/*  674 */     this.lock.lock();
/*      */     try {
/*  676 */       return this.first == null ? null : (ScienceFuture)this.first.item;
/*      */     } finally {
/*  678 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public E peekLast() {
/*  683 */     this.lock.lock();
/*      */     try {
/*  685 */       return this.last == null ? null : (ScienceFuture)this.last.item;
/*      */     } finally {
/*  687 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean removeFirstOccurrence(Object o) {
/*  692 */     if (o == null) return false;
/*  693 */     this.lock.lock();
/*      */     try {
/*  695 */       for (Node<E> p = this.first; p != null; p = p.next) {
/*  696 */         if (o.equals(p.item)) {
/*  697 */           unlink(p);
/*  698 */           return true;
/*      */         }
/*      */       }
/*  701 */       return 0;
/*      */     } finally {
/*  703 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean removeLastOccurrence(Object o) {
/*  708 */     if (o == null) return false;
/*  709 */     this.lock.lock();
/*      */     try {
/*  711 */       for (Node<E> p = this.last; p != null; p = p.prev) {
/*  712 */         if (o.equals(p.item)) {
/*  713 */           unlink(p);
/*  714 */           return true;
/*      */         }
/*      */       }
/*  717 */       return 0;
/*      */     } finally {
/*  719 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean add(E e)
/*      */   {
/*  737 */     addLast(e);
/*  738 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean offer(E e)
/*      */   {
/*  745 */     return offerLast(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void put(E e)
/*      */     throws InterruptedException
/*      */   {
/*  753 */     putLast(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean offer(E e, long timeout, TimeUnit unit)
/*      */     throws InterruptedException
/*      */   {
/*  762 */     return offerLast(e, timeout, unit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public E remove()
/*      */   {
/*  776 */     return removeFirst();
/*      */   }
/*      */   
/*      */   public E poll() {
/*  780 */     return pollFirst();
/*      */   }
/*      */   
/*      */   public E take() throws InterruptedException {
/*  784 */     return takeFirst();
/*      */   }
/*      */   
/*      */   public E poll(long timeout, TimeUnit unit) throws InterruptedException {
/*  788 */     return pollFirst(timeout, unit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public E element()
/*      */   {
/*  802 */     return getFirst();
/*      */   }
/*      */   
/*      */   public E peek() {
/*  806 */     return peekFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int remainingCapacity()
/*      */   {
/*  821 */     this.lock.lock();
/*      */     try {
/*  823 */       return this.capacity - this.count;
/*      */     } finally {
/*  825 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int drainTo(Collection<? super E> c)
/*      */   {
/*  836 */     if (c == null)
/*  837 */       throw new NullPointerException();
/*  838 */     if (c == this)
/*  839 */       throw new IllegalArgumentException();
/*  840 */     this.lock.lock();
/*      */     try {
/*  842 */       for (Node<E> p = this.first; p != null; p = p.next)
/*  843 */         c.add(p.item);
/*  844 */       int n = this.count;
/*  845 */       this.count = 0;
/*  846 */       this.first = (this.last = null);
/*  847 */       this.notFull.signalAll();
/*  848 */       return n;
/*      */     } finally {
/*  850 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int drainTo(Collection<? super E> c, int maxElements)
/*      */   {
/*  861 */     if (c == null)
/*  862 */       throw new NullPointerException();
/*  863 */     if (c == this)
/*  864 */       throw new IllegalArgumentException();
/*  865 */     this.lock.lock();
/*      */     try {
/*  867 */       int n = 0;
/*  868 */       while ((n < maxElements) && (this.first != null)) {
/*  869 */         c.add(this.first.item);
/*  870 */         this.first.prev = null;
/*  871 */         this.first = this.first.next;
/*  872 */         this.count -= 1;
/*  873 */         n++;
/*      */       }
/*  875 */       if (this.first == null)
/*  876 */         this.last = null;
/*  877 */       this.notFull.signalAll();
/*  878 */       return n;
/*      */     } finally {
/*  880 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(E e)
/*      */   {
/*  891 */     addFirst(e);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public E pop()
/*      */   {
/*  898 */     return removeFirst();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean remove(Object o)
/*      */   {
/*  918 */     return removeFirstOccurrence(o);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/*  927 */     this.lock.lock();
/*      */     try {
/*  929 */       return this.count;
/*      */     } finally {
/*  931 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean contains(Object o)
/*      */   {
/*  944 */     if (o == null) return false;
/*  945 */     this.lock.lock();
/*      */     try {
/*  947 */       for (Node<E> p = this.first; p != null; p = p.next)
/*  948 */         if (o.equals(p.item))
/*  949 */           return true;
/*  950 */       return 0;
/*      */     } finally {
/*  952 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean removeNode(Node<E> e)
/*      */   {
/*  961 */     this.lock.lock();
/*      */     try {
/*  963 */       for (Node<E> p = this.first; p != null; p = p.next) {
/*  964 */         if (p == e) {
/*  965 */           unlink(p);
/*  966 */           return true;
/*      */         }
/*      */       }
/*  969 */       return 0;
/*      */     } finally {
/*  971 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] toArray()
/*      */   {
/*  989 */     this.lock.lock();
/*      */     try {
/*  991 */       Object[] a = new Object[this.count];
/*  992 */       int k = 0;
/*  993 */       for (Node<E> p = this.first; p != null; p = p.next)
/*  994 */         a[(k++)] = p.item;
/*  995 */       return a;
/*      */     } finally {
/*  997 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T[] toArray(T[] a)
/*      */   {
/* 1038 */     this.lock.lock();
/*      */     try {
/* 1040 */       if (a.length < this.count) {
/* 1041 */         a = (Object[])Array.newInstance(a.getClass().getComponentType(), this.count);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1046 */       int k = 0;
/* 1047 */       for (Node<E> p = this.first; p != null; p = p.next)
/* 1048 */         a[(k++)] = p.item;
/* 1049 */       if (a.length > k)
/* 1050 */         a[k] = null;
/* 1051 */       return a;
/*      */     } finally {
/* 1053 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1058 */     this.lock.lock();
/*      */     try {
/* 1060 */       return super.toString();
/*      */     } finally {
/* 1062 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear()
/*      */   {
/* 1071 */     this.lock.lock();
/*      */     try {
/* 1073 */       this.first = (this.last = null);
/* 1074 */       this.count = 0;
/* 1075 */       this.notFull.signalAll();
/*      */     } finally {
/* 1077 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterator<E> iterator()
/*      */   {
/* 1093 */     return new Itr(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterator<E> descendingIterator()
/*      */   {
/* 1107 */     return new DescendingItr(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private abstract class AbstractItr
/*      */     implements Iterator<E>
/*      */   {
/*      */     ScienceQueue.Node<E> next;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     E nextItem;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private ScienceQueue.Node<E> lastRet;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     AbstractItr()
/*      */     {
/* 1134 */       advance();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     abstract void advance();
/*      */     
/*      */ 
/*      */     public boolean hasNext()
/*      */     {
/* 1144 */       return this.next != null;
/*      */     }
/*      */     
/*      */     public E next() {
/* 1148 */       if (this.next == null)
/* 1149 */         throw new NoSuchElementException();
/* 1150 */       this.lastRet = this.next;
/* 1151 */       E x = this.nextItem;
/* 1152 */       advance();
/* 1153 */       return x;
/*      */     }
/*      */     
/*      */     public void remove() {
/* 1157 */       ScienceQueue.Node<E> n = this.lastRet;
/* 1158 */       if (n == null)
/* 1159 */         throw new IllegalStateException();
/* 1160 */       this.lastRet = null;
/*      */       
/*      */ 
/*      */ 
/* 1164 */       ScienceQueue.this.removeNode(n);
/*      */     }
/*      */   }
/*      */   
/*      */   private class Itr extends ScienceQueue<E>.AbstractItr {
/* 1169 */     private Itr() { super(); }
/*      */     
/* 1171 */     void advance() { ReentrantLock lock = ScienceQueue.this.lock;
/* 1172 */       lock.lock();
/*      */       try {
/* 1174 */         this.next = (this.next == null ? ScienceQueue.this.first : this.next.next);
/* 1175 */         this.nextItem = (this.next == null ? null : (ScienceFuture)this.next.item);
/*      */       } finally {
/* 1177 */         lock.unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class DescendingItr
/*      */     extends ScienceQueue<E>.AbstractItr
/*      */   {
/* 1185 */     private DescendingItr() { super(); }
/*      */     
/* 1187 */     void advance() { ReentrantLock lock = ScienceQueue.this.lock;
/* 1188 */       lock.lock();
/*      */       try {
/* 1190 */         this.next = (this.next == null ? ScienceQueue.this.last : this.next.prev);
/* 1191 */         this.nextItem = (this.next == null ? null : (ScienceFuture)this.next.item);
/*      */       } finally {
/* 1193 */         lock.unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeObject(ObjectOutputStream s)
/*      */     throws IOException
/*      */   {
/* 1207 */     this.lock.lock();
/*      */     try
/*      */     {
/* 1210 */       s.defaultWriteObject();
/*      */       
/* 1212 */       for (Node<E> p = this.first; p != null; p = p.next) {
/* 1213 */         s.writeObject(p.item);
/*      */       }
/* 1215 */       s.writeObject(null);
/*      */     } finally {
/* 1217 */       this.lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream s)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1228 */     s.defaultReadObject();
/* 1229 */     this.count = 0;
/* 1230 */     this.first = null;
/* 1231 */     this.last = null;
/*      */     for (;;)
/*      */     {
/* 1234 */       E item = (ScienceFuture)s.readObject();
/* 1235 */       if (item == null)
/*      */         break;
/* 1237 */       add(item);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\ScienceQueue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */