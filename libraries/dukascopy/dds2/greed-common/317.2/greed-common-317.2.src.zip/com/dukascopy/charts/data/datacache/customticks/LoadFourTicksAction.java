/*     */ package com.dukascopy.charts.data.datacache.customticks;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadFourTicksAction
/*     */   extends AbstractLoadCustomTicksFromCandlesAction
/*     */ {
/*     */   private final TickFeedListener feedListener;
/*     */   private final double spreadInPipsAsk;
/*     */   private final double spreadInPipsBid;
/*     */   private final double length;
/*     */   private final double step;
/*     */   
/*     */   public LoadFourTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, OfferSide offerSide, long from, long to, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*     */   {
/*  39 */     super(feedDataProvider, instrument, period, offerSide, from, to, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */     this.feedListener = feedListener;
/*     */     
/*  50 */     this.spreadInPipsAsk = ((offerSide == OfferSide.ASK ? 0.0D : 2.0D) * instrument.getPipValue());
/*  51 */     this.spreadInPipsBid = ((offerSide == OfferSide.ASK ? -2.0D : 0.0D) * instrument.getPipValue());
/*     */     
/*  53 */     this.length = period.getInterval();
/*  54 */     this.step = (this.length / 8.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void candleToTicks(long time, double open, double high, double low, double close, double volume)
/*     */   {
/*  66 */     double ask = StratUtils.round(open + this.spreadInPipsAsk, 5);
/*  67 */     double bid = StratUtils.round(open + this.spreadInPipsBid, 5);
/*  68 */     double vol = StratUtils.round(volume / 4.0D, 5);
/*  69 */     if (!isStop()) {
/*  70 */       newTick((time + this.step), ask, bid, vol, vol);
/*     */     }
/*     */     
/*     */ 
/*  74 */     double lowhigh = close < open ? high : low;
/*  75 */     ask = StratUtils.round(lowhigh + this.spreadInPipsAsk, 5);
/*  76 */     bid = StratUtils.round(lowhigh + this.spreadInPipsBid, 5);
/*  77 */     if (!isStop()) {
/*  78 */       newTick((time + this.step * 3.0D), ask, bid, vol, vol);
/*     */     }
/*     */     
/*     */ 
/*  82 */     lowhigh = close < open ? low : high;
/*  83 */     ask = StratUtils.round(lowhigh + this.spreadInPipsAsk, 5);
/*  84 */     bid = StratUtils.round(lowhigh + this.spreadInPipsBid, 5);
/*  85 */     if (!isStop()) {
/*  86 */       newTick((time + this.step * 5.0D), ask, bid, vol, vol);
/*     */     }
/*     */     
/*     */ 
/*  90 */     ask = StratUtils.round(close + this.spreadInPipsAsk, 5);
/*  91 */     bid = StratUtils.round(close + this.spreadInPipsBid, 5);
/*  92 */     if (!isStop()) {
/*  93 */       newTick((time + this.step * 7.0D), ask, bid, vol, vol);
/*     */     }
/*     */   }
/*     */   
/*     */   private void newTick(long time, double ask, double bid, double askVol, double bidVol) {
/*  98 */     if ((this.from <= time) && (time <= this.to)) {
/*  99 */       this.feedListener.newTick(this.instrument, time, ask, bid, askVol, bidVol);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void candleReceived(long time, double open, double close, double low, double high, double vol)
/*     */   {
/* 105 */     candleToTicks(time, open, high, low, close, vol);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadFourTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */