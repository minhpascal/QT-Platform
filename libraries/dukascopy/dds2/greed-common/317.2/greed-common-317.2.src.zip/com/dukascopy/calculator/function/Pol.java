/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pol
/*    */   extends PObject
/*    */ {
/*    */   public Pol()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.change.to.from.complex.polar.notation";
/* 12 */     this.fshortcut = 'o';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */   
/* 19 */   private static final String[] fname = { "P", "o", "l" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Pol.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */