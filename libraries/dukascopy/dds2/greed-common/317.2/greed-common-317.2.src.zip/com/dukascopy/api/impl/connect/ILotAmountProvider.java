package com.dukascopy.api.impl.connect;

import com.dukascopy.api.Instrument;
import java.math.BigDecimal;

public abstract interface ILotAmountProvider
{
  public abstract BigDecimal getMinTradableAmount(Instrument paramInstrument);
  
  public abstract BigDecimal getMaxTradableAmount(Instrument paramInstrument);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ILotAmountProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */