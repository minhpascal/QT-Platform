/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class I
/*    */   extends PObject
/*    */ {
/*    */   public static final String I = "i";
/*    */   
/*    */ 
/*    */ 
/*    */   public I()
/*    */   {
/* 15 */     this.ftooltip = "i";
/* 16 */     this.fshortcut = 'j';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 20 */     return fname;
/*    */   }
/*    */   
/* 23 */   private static final String[] fname = { "i" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\I.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */