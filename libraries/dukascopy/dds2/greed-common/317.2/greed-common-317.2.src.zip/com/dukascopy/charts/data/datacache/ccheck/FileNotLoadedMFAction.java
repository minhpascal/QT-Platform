/*     */ package com.dukascopy.charts.data.datacache.ccheck;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.Unit;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import java.io.IOException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileNotLoadedMFAction
/*     */   implements Runnable
/*     */ {
/*  29 */   private static final Logger LOGGER = LoggerFactory.getLogger(FileNotLoadedMFAction.class);
/*     */   private Instrument instrument;
/*     */   private Period period;
/*     */   private OfferSide side;
/*     */   private long chunkStart;
/*     */   private boolean isLargeFile;
/*     */   
/*     */   public FileNotLoadedMFAction(Instrument instrument, Period period, OfferSide side, long chunkStart, boolean isLargeFile)
/*     */   {
/*  38 */     this.instrument = instrument;
/*  39 */     this.period = period;
/*  40 */     this.side = side;
/*  41 */     this.chunkStart = chunkStart;
/*  42 */     this.isLargeFile = isLargeFile;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*  49 */       MissingFileEntryManager manager = MissingFileEntryManager.getInstance();
/*  50 */       if (manager == null) {
/*  51 */         LOGGER.warn("Couldn't add missing file entry to list! Manager is null!");
/*  52 */         return;
/*     */       }
/*     */       
/*     */ 
/*  56 */       if (this.isLargeFile)
/*     */       {
/*  58 */         long firstSmallChunkTime = DataCacheUtils.getChunkStartFast(this.period, this.chunkStart);
/*  59 */         long lastSmallChunkTime = DataCacheUtils.getChunkStartFast(this.period, DataCacheUtils.getLargeChunkEndFast(this.period, this.chunkStart));
/*     */         
/*  61 */         if (Period.TICK.equals(this.period))
/*     */         {
/*  63 */           lastSmallChunkTime += DataCacheUtils.getChunkLength(this.period).getInterval();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */         long[][] allSmallChunks = DataCacheUtils.separateChunksForCache(this.period, firstSmallChunkTime, lastSmallChunkTime);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  75 */         MFEntry[] mfentries = new MFEntry[allSmallChunks.length];
/*  76 */         for (int x = 0; x < allSmallChunks.length; x++)
/*     */         {
/*  78 */           long[] chunkX = allSmallChunks[x];
/*     */           
/*  80 */           mfentries[x] = new MFEntry(chunkX[0], this.instrument, Period.TICK.equals(this.period) ? null : this.side);
/*     */         }
/*     */         
/*  83 */         long requestStartTime = System.currentTimeMillis();
/*  84 */         boolean gotLock = false;
/*     */         try {
/*  86 */           while ((!(gotLock = manager.requestGlobalLock())) && (System.currentTimeMillis() - requestStartTime < 600000L)) {
/*     */             try
/*     */             {
/*  89 */               Thread.sleep(100L);
/*     */             }
/*     */             catch (InterruptedException e) {}
/*     */           }
/*  93 */           if (!gotLock) {
/*  94 */             LOGGER.warn("couldn't get a lock on mffolder within 10 minutes! Probably taken by another instance.");
/*     */           }
/*     */           else {
/*  97 */             manager.appendFileWithEntries(mfentries, this.period);
/*     */           }
/*     */         }
/*     */         finally {
/* 101 */           if (gotLock) {
/* 102 */             manager.releaseGlobalLock();
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 107 */         MFEntry entry = new MFEntry(this.chunkStart, this.instrument, Period.TICK.equals(this.period) ? null : this.side);
/* 108 */         manager.appendFileWithEntry(entry, this.period);
/*     */       }
/*     */     } catch (DataCacheException|IOException e) {
/* 111 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\FileNotLoadedMFAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */