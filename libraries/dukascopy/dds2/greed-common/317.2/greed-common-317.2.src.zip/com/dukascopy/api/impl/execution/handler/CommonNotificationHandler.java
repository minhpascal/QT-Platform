/*    */ package com.dukascopy.api.impl.execution.handler;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.impl.connect.PlatformMessageImpl;
/*    */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonNotificationHandler
/*    */   implements INotificationHandler
/*    */ {
/* 29 */   private static final Logger LOGGER = LoggerFactory.getLogger(CommonNotificationHandler.class);
/*    */   
/* 31 */   private static Set<INotificationHandler> notificationsHandlers = Collections.synchronizedSet(new HashSet() { private static final long serialVersionUID = -5343712523470005813L; });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private final JForexTaskManager taskManager;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CommonNotificationHandler(JForexTaskManager taskManager)
/*    */   {
/* 43 */     this.taskManager = taskManager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PlatformMessageImpl handleNotificationMessage(NotificationMessage notificationMessage)
/*    */   {
/* 50 */     for (INotificationHandler notificationHandler : notificationsHandlers) {
/*    */       try {
/* 52 */         PlatformMessageImpl platformMessageImpl = notificationHandler.handleNotificationMessage(notificationMessage);
/* 53 */         if (platformMessageImpl != null) {
/* 54 */           this.taskManager.onMessage(platformMessageImpl);
/*    */         }
/*    */       } catch (Exception exc) {
/* 57 */         LOGGER.error(exc.getMessage());
/*    */       }
/*    */     }
/*    */     
/* 61 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean canHandle(NotificationMessage notificationMessage)
/*    */   {
/* 69 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void addNotificationHandler(INotificationHandler notificationHandler)
/*    */   {
/* 76 */     synchronized (notificationsHandlers) {
/* 77 */       notificationsHandlers.add(notificationHandler);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void removeNotificationHandler(INotificationHandler notificationHandler)
/*    */   {
/* 85 */     synchronized (notificationsHandlers) {
/* 86 */       notificationsHandlers.remove(notificationHandler);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\handler\CommonNotificationHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */