/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Divide
/*    */   extends MFunction
/*    */ {
/*    */   public Divide()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.division";
/* 15 */     this.fshortcut = '/';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x, double y)
/*    */   {
/* 25 */     return x / y;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x, OObject y)
/*    */   {
/* 35 */     return x.divide(y);
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 39 */     return fname;
/*    */   }
/*    */   
/* 42 */   private static final String[] fname = { "&#247;" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Divide.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */