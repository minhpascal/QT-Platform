/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ import com.dukascopy.calculator.function.Graph;
/*    */ import java.awt.event.ActionEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GraphButton
/*    */   extends CalculatorButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public GraphButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 16 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 17 */     setPobject(new Graph());
/* 18 */     setText();
/* 19 */     setTextSize();
/* 20 */     addActionListener(this);
/*    */     
/* 22 */     setShortcut('G');
/* 23 */     setToolTipKey("sc.calculator.use.to.display.a.graph");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent actionEvent)
/*    */   {
/* 33 */     this.mainCalculatorPanel.displayGraph();
/* 34 */     getMainCalculatorPanel().setShift(false);
/* 35 */     getMainCalculatorPanel().updateDisplay(false, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\GraphButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */