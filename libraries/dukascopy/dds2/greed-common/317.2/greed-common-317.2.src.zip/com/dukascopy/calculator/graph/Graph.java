/*    */ package com.dukascopy.calculator.graph;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import com.dukascopy.calculator.ReadOnlyCalculatorApplet;
/*    */ 
/*    */ public class Graph extends javax.swing.JFrame
/*    */ {
/*    */   private Menu menu;
/*    */   private Model model;
/*    */   private View view;
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Graph(ReadOnlyCalculatorApplet applet)
/*    */   {
/* 15 */     super("Scientific Calculator Graph");
/* 16 */     this.model = new Model();
/* 17 */     this.view = new View(this.model, this);
/* 18 */     this.menu = new Menu(applet, this.view, this.model);
/* 19 */     setJMenuBar(this.menu);
/* 20 */     int h = applet.graphHeight();
/* 21 */     setSize(3 * h / 2, h);
/* 22 */     setDefaultCloseOperation(1);
/* 23 */     setContentPane(this.view);
/* 24 */     setVisible(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setLocus(OObject oobject)
/*    */   {
/* 32 */     if ((oobject != null) && (!(oobject instanceof com.dukascopy.calculator.Error)))
/*    */     {
/*    */ 
/*    */ 
/* 36 */       Locus locus = new Locus(oobject, this.view);
/* 37 */       this.model.reset(locus);
/* 38 */       this.view.repaint();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void updateMenu()
/*    */   {
/* 46 */     this.menu.updateSizes();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\graph\Graph.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */