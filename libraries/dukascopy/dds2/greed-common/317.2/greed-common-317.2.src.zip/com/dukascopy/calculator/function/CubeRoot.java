/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CubeRoot
/*    */   extends RFunction
/*    */ {
/*    */   public CubeRoot()
/*    */   {
/* 15 */     this.ftooltip = "sc.calculator.cube.root.of.x";
/* 16 */     this.fshortcut = 'v';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 25 */     return Math.exp(Math.log(x) / 3.0D);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 34 */     return x.cuberoot();
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 38 */     return fname;
/*    */   }
/*    */   
/* 41 */   private static final String[] fname = { "&#179;", "&#8730;" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\CubeRoot.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */