/*    */ package com.dukascopy.charts.data.datacache.ccheck;
/*    */ 
/*    */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*    */ import java.io.File;
/*    */ import java.io.FilenameFilter;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MFFilenameFilter
/*    */   implements FilenameFilter
/*    */ {
/*    */   private final Pattern mfeFilePattern;
/*    */   private final File mfDir;
/*    */   
/*    */   public MFFilenameFilter(File mfDir, String periodSuffix)
/*    */   {
/* 29 */     this.mfDir = mfDir;
/* 30 */     this.mfeFilePattern = Pattern.compile((ObjectUtils.isNullOrEmpty(periodSuffix) ? "[TMHD]" : periodSuffix) + "msfile_" + "[0-9][0-9][0-9]" + "\\." + "mfe" + 1);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean accept(File dir, String name)
/*    */   {
/* 36 */     if ((this.mfDir.equals(dir)) && (this.mfeFilePattern.matcher(name).matches())) {
/* 37 */       return true;
/*    */     }
/* 39 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFFilenameFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */