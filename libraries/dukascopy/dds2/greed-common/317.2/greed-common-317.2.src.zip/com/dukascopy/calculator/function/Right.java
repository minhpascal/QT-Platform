/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Right
/*    */   extends PObject
/*    */ {
/*    */   public Right()
/*    */   {
/* 11 */     this.ftooltip = "sc.calculator.move.caret.right.right.arrow";
/* 12 */     this.fshortcut = '\000';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 16 */     return fname;
/*    */   }
/*    */   
/* 19 */   private static final String[] fname = { "&#8594;" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Right.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */