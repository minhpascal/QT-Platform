/*     */ package com.dukascopy.charts.data.datacache.core.connection;
/*     */ 
/*     */ import com.dukascopy.charts.data.datacache.core.lock.CacheFileHandler;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCacheConnection
/*     */   implements ICacheConnection
/*     */ {
/*     */   protected final CacheFileHandler cacheFileHandler;
/*  21 */   protected boolean isActive = true;
/*     */   
/*     */   public AbstractCacheConnection(CacheFileHandler cacheFileHandler)
/*     */   {
/*  25 */     this.cacheFileHandler = cacheFileHandler;
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*  30 */     checkIsActive();
/*     */     
/*  32 */     this.isActive = false;
/*     */   }
/*     */   
/*     */   protected RandomAccessFile getRandomAccessFile() throws IOException {
/*  36 */     checkAndThrowFileNotFound();
/*     */     
/*  38 */     RandomAccessFile raf = doGetRandomAccessFile();
/*     */     
/*  40 */     if (raf == null) {
/*  41 */       throw new FileNotFoundException("File doesn't exist " + this.cacheFileHandler.getFile());
/*     */     }
/*     */     
/*  44 */     return raf;
/*     */   }
/*     */   
/*     */   protected abstract RandomAccessFile doGetRandomAccessFile() throws IOException;
/*     */   
/*     */   public boolean isFileExists()
/*     */   {
/*  51 */     checkIsActive();
/*     */     
/*  53 */     return this.cacheFileHandler.isFileExists();
/*     */   }
/*     */   
/*     */   public void seek(long pos) throws IOException
/*     */   {
/*  58 */     checkIsActive();
/*     */     
/*  60 */     getRandomAccessFile().seek(pos);
/*     */   }
/*     */   
/*     */   public long length() throws IOException
/*     */   {
/*  65 */     checkIsActive();
/*     */     
/*  67 */     return getRandomAccessFile().length();
/*     */   }
/*     */   
/*     */   public String getFilePath()
/*     */   {
/*  72 */     checkIsActive();
/*     */     
/*  74 */     return this.cacheFileHandler.getFile().getPath();
/*     */   }
/*     */   
/*     */   public String getFileAbsolutePath()
/*     */   {
/*  79 */     checkIsActive();
/*     */     
/*  81 */     return this.cacheFileHandler.getFile().getAbsolutePath();
/*     */   }
/*     */   
/*     */   public String getFileName()
/*     */   {
/*  86 */     checkIsActive();
/*     */     
/*  88 */     return this.cacheFileHandler.getFile().getName();
/*     */   }
/*     */   
/*     */   public boolean isFile()
/*     */   {
/*  93 */     checkIsActive();
/*     */     
/*  95 */     return this.cacheFileHandler.getFile().isFile();
/*     */   }
/*     */   
/*     */   public boolean isDirectory()
/*     */   {
/* 100 */     checkIsActive();
/*     */     
/* 102 */     return this.cacheFileHandler.getFile().isDirectory();
/*     */   }
/*     */   
/*     */   public boolean isForFile(File file)
/*     */   {
/* 107 */     checkIsActive();
/*     */     
/* 109 */     return this.cacheFileHandler.getFile().equals(file);
/*     */   }
/*     */   
/*     */   public long getFilePointer() throws IOException
/*     */   {
/* 114 */     checkIsActive();
/*     */     
/* 116 */     return getRandomAccessFile().getFilePointer();
/*     */   }
/*     */   
/*     */   public void scheduleToDeleteFileOnExit()
/*     */   {
/* 121 */     checkIsActive();
/*     */     try
/*     */     {
/* 124 */       this.cacheFileHandler.deleteOnExit();
/*     */     }
/*     */     catch (Throwable e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkIsActive()
/*     */   {
/* 138 */     if (!this.isActive) {
/* 139 */       throw new IllegalArgumentException("Connection is not active and could not be used " + this);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void checkAndThrowFileNotFound() throws FileNotFoundException {
/* 144 */     if (!isFileExists()) {
/* 145 */       throw new FileNotFoundException("File doesn't exist " + this.cacheFileHandler.getFile());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\AbstractCacheConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */