/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bin
/*    */   extends PObject
/*    */ {
/*    */   public Bin()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.change.base.to.binary";
/* 15 */     this.fshortcut = 'B';
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 19 */     return fname;
/*    */   }
/*    */   
/* 22 */   private static final String[] fname = { "B", "i", "n" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Bin.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */