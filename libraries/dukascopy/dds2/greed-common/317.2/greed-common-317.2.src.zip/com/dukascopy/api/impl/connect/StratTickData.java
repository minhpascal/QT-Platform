/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StratTickData
/*    */   extends TickData
/*    */ {
/*    */   private double totalAskVolume;
/*    */   private double totalBidVolume;
/*    */   
/*    */   public StratTickData(TickData tickData, double totalAskVolume, double totalBidVolume)
/*    */   {
/* 17 */     this.time = tickData.time;
/* 18 */     this.ask = tickData.ask;
/* 19 */     this.bid = tickData.bid;
/* 20 */     this.askVol = tickData.askVol;
/* 21 */     this.bidVol = tickData.bidVol;
/* 22 */     this.asks = tickData.asks;
/* 23 */     this.bids = tickData.bids;
/* 24 */     this.askVolumes = tickData.askVolumes;
/* 25 */     this.bidVolumes = tickData.bidVolumes;
/* 26 */     this.totalAskVolume = totalAskVolume;
/* 27 */     this.totalBidVolume = totalBidVolume;
/*    */   }
/*    */   
/*    */   public void setTotalAskVolume(double totalAskVolume) {
/* 31 */     this.totalAskVolume = totalAskVolume;
/*    */   }
/*    */   
/*    */   public void setTotalBidVolume(double totalBidVolume) {
/* 35 */     this.totalBidVolume = totalBidVolume;
/*    */   }
/*    */   
/*    */   public double getTotalAskVolume()
/*    */   {
/* 40 */     return this.totalAskVolume;
/*    */   }
/*    */   
/*    */   public double getTotalBidVolume()
/*    */   {
/* 45 */     return this.totalBidVolume;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\StratTickData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */