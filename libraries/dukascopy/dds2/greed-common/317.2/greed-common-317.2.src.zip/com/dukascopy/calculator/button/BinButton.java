/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ 
/*    */ public class BinButton extends EqualsButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public BinButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 11 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 12 */     setPobject(new com.dukascopy.calculator.function.Bin());
/* 13 */     setText();
/* 14 */     setShortcut(getPobject().shortcut());
/* 15 */     setTextSize();
/* 16 */     this.changeBase = EqualsButton.ChangeBase.BINARY;
/* 17 */     addActionListener(this);
/*    */     
/* 19 */     setToolTipKey(getPobject().tooltip());
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\BinButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */