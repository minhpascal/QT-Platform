/*    */ package com.dukascopy.charts.data.datacache.core.lock;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalLockCacheFileHandler
/*    */ {
/*    */   private final File file;
/*    */   private final GlobalLock fileLock;
/*    */   
/*    */   public GlobalLockCacheFileHandler(File file, long globalLockAcquiringOneIterationTimeoutInMillis, int globalLockAcquiringIterationsCount)
/*    */   {
/* 23 */     this.file = file;
/* 24 */     this.fileLock = new GlobalLock(file, globalLockAcquiringOneIterationTimeoutInMillis, globalLockAcquiringIterationsCount);
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 28 */     return this.file;
/*    */   }
/*    */   
/* 31 */   public GlobalLock getFileLock() { return this.fileLock; }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 36 */     return "LockCacheFileHandler [" + (this.file != null ? "file=" + this.file : "") + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\lock\GlobalLockCacheFileHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */