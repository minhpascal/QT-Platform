/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.byshift;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.api.feed.util.PointAndFigureFeedDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.intraperiod.IIntraperiodBarsGenerator;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadClosestPointAndFigureAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadToCachePointAndFigureAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PANthPointAndFigureFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PALoadByTimeIntervalPointAndFigureAction;
/*     */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureCreator;
/*     */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PALoadByShiftPointAndFigure
/*     */   extends PAAbstractLoadByShift<PointAndFigureData, IPointAndFigureLiveFeedListener, IPointAndFigureCreator, PALoadToCachePointAndFigureAction, PALoadByTimeIntervalPointAndFigureAction, PALoadClosestPointAndFigureAction, PANthPointAndFigureFromSeedBarAction>
/*     */ {
/*     */   public PALoadByShiftPointAndFigure(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int shift, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, IPointAndFigureLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  53 */     super(cacheManager, instrument, interpolationDescriptor, side, jfPeriod, shift, fireUncompletedLastBasePeriodBars, infinitBasePeriod, version, listener, loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PointAndFigureData getInProgressBar()
/*     */   {
/*  70 */     PointAndFigureFeedDescriptor descriptor = new PointAndFigureFeedDescriptor(getInstrument(), getJfPeriod().getPriceRange(), getJfPeriod().getReversalAmount(), getSide(), getJfPeriod().getPeriod());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     return getCacheManager().getFeedDataProvider().getIntraperiodBarsGenerator().getOrLoadInProgressPointAndFigure(descriptor, getInterpolationDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PALoadClosestPointAndFigureAction createLoadClosestAction(long currentTime, IPointAndFigureLiveFeedListener lastCompletedBarListener)
/*     */     throws DataCacheException
/*     */   {
/*  88 */     PALoadClosestPointAndFigureAction action = new PALoadClosestPointAndFigureAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), currentTime, isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), lastCompletedBarListener, getLoadingProgressListener());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     return action;
/*     */   }
/*     */   
/*     */   protected IPointAndFigureLiveFeedListener createLiveFeedListener(final List<PointAndFigureData> result)
/*     */   {
/* 106 */     IPointAndFigureLiveFeedListener listener = new IPointAndFigureLiveFeedListener()
/*     */     {
/*     */       public void newPriceData(PointAndFigureData pointAndFigure) {
/* 109 */         result.add(pointAndFigure);
/*     */       }
/* 111 */     };
/* 112 */     return listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PANthPointAndFigureFromSeedBarAction createLoadNthAction(int numOfBarsBefore, PointAndFigureData timedBar, int numOfBarsAfter, boolean lookLeft, IPointAndFigureLiveFeedListener listener)
/*     */   {
/* 123 */     PANthPointAndFigureFromSeedBarAction action = new PANthPointAndFigureFromSeedBarAction(getCacheManager(), getVersion(), numOfBarsBefore, timedBar, numOfBarsAfter, getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), lookLeft, getLoadingProgressListener(), listener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     return action;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\byshift\PALoadByShiftPointAndFigure.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */