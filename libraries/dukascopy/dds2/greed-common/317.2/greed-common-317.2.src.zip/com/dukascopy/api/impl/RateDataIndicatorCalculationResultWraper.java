/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IBar;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RateDataIndicatorCalculationResultWraper
/*    */ {
/*    */   private Object[] indicatorCalculationResult;
/*    */   private List<IBar> sourceData;
/*    */   
/*    */   public Object[] getIndicatorCalculationResult()
/*    */   {
/* 21 */     return this.indicatorCalculationResult;
/*    */   }
/*    */   
/*    */   public void setIndicatorCalculationResult(Object[] indicatorCalculationResult) {
/* 25 */     this.indicatorCalculationResult = indicatorCalculationResult;
/*    */   }
/*    */   
/*    */   public List<IBar> getSourceData() {
/* 29 */     return this.sourceData;
/*    */   }
/*    */   
/*    */   public void setSourceData(List<IBar> sourceData) {
/* 33 */     this.sourceData = sourceData;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\RateDataIndicatorCalculationResultWraper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */