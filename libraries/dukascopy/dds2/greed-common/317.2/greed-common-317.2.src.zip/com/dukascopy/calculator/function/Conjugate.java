/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Conjugate
/*    */   extends RFunction
/*    */ {
/*    */   public Conjugate()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.complex.conjugate.of.x";
/* 15 */     this.fshortcut = '_';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 24 */     return x;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 33 */     return x.conjugate();
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 37 */     return fname;
/*    */   }
/*    */   
/* 40 */   private static final String[] fname = { "c", "o", "n", "j", " " };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Conjugate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */