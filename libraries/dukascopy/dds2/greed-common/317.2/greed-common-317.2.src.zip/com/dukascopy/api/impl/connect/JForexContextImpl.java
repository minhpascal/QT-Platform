/*      */ package com.dukascopy.api.impl.connect;
/*      */ 
/*      */ import com.dukascopy.api.ConfigurableChangeListener;
/*      */ import com.dukascopy.api.DataType;
/*      */ import com.dukascopy.api.Filter;
/*      */ import com.dukascopy.api.IAccount;
/*      */ import com.dukascopy.api.IBar;
/*      */ import com.dukascopy.api.IChart;
/*      */ import com.dukascopy.api.IClientGUIListener;
/*      */ import com.dukascopy.api.IConsole;
/*      */ import com.dukascopy.api.IContext;
/*      */ import com.dukascopy.api.IDataService;
/*      */ import com.dukascopy.api.IDownloadableStrategies;
/*      */ import com.dukascopy.api.IEngine;
/*      */ import com.dukascopy.api.IIndicators;
/*      */ import com.dukascopy.api.IReportService;
/*      */ import com.dukascopy.api.IStrategies;
/*      */ import com.dukascopy.api.IStrategy;
/*      */ import com.dukascopy.api.IStrategyListener;
/*      */ import com.dukascopy.api.ITick;
/*      */ import com.dukascopy.api.ITimedData;
/*      */ import com.dukascopy.api.IUserInterface;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.JFException;
/*      */ import com.dukascopy.api.JFUtils;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.Period;
/*      */ import com.dukascopy.api.PriceRange;
/*      */ import com.dukascopy.api.ReversalAmount;
/*      */ import com.dukascopy.api.TickBarSize;
/*      */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*      */ import com.dukascopy.api.feed.FeedDescriptor;
/*      */ import com.dukascopy.api.feed.IBarFeedListener;
/*      */ import com.dukascopy.api.feed.IFeedDescriptor;
/*      */ import com.dukascopy.api.feed.IFeedListener;
/*      */ import com.dukascopy.api.feed.IPointAndFigure;
/*      */ import com.dukascopy.api.feed.IPointAndFigureFeedListener;
/*      */ import com.dukascopy.api.feed.IRangeBar;
/*      */ import com.dukascopy.api.feed.IRangeBarFeedListener;
/*      */ import com.dukascopy.api.feed.IRenkoBar;
/*      */ import com.dukascopy.api.feed.IRenkoBarFeedListener;
/*      */ import com.dukascopy.api.feed.ITailoredFeedDescriptor;
/*      */ import com.dukascopy.api.feed.ITailoredFeedListener;
/*      */ import com.dukascopy.api.feed.ITickBar;
/*      */ import com.dukascopy.api.feed.ITickBarFeedListener;
/*      */ import com.dukascopy.api.feed.ITickFeedListener;
/*      */ import com.dukascopy.api.feed.util.PointAndFigureFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.RangeBarFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.RenkoFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TickBarFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TicksFeedDescriptor;
/*      */ import com.dukascopy.api.feed.util.TimePeriodAggregationFeedDescriptor;
/*      */ import com.dukascopy.api.impl.DownloadableStrategies;
/*      */ import com.dukascopy.api.impl.History;
/*      */ import com.dukascopy.api.impl.ReportService;
/*      */ import com.dukascopy.api.impl.StrategyWrapper;
/*      */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*      */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*      */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*      */ import com.dukascopy.charts.data.datacache.priceaggregation.TimeDataUtils;
/*      */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*      */ import com.dukascopy.charts.main.interfaces.IContextChartsController;
/*      */ import com.dukascopy.charts.utils.CustomReference;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.IStrategyRateDataNotificationFactory;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.StrategyRateDataNotificationFactory;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.candle.IStrategyCandleNotificationManager;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.pnf.IStrategyPointAndFigureNotificationManager;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.pr.IStrategyPriceRangeNotificationManager;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.renko.IStrategyRenkoNotificationManager;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.tick.IStrategyTickNotificationManager;
/*      */ import com.dukascopy.dds2.greed.agent.strategy.notification.tickbar.IStrategyTickBarNotificationManager;
/*      */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*      */ import com.dukascopy.dds2.greed.util.JForexUtils;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.io.File;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.Future;
/*      */ import javax.swing.SwingUtilities;
/*      */ 
/*      */ public class JForexContextImpl<UI extends IUserInterface> implements IContext
/*      */ {
/*   96 */   protected JFRunnableProcessor<?, ?> jfRunnableProcessor = null;
/*   97 */   private IEngine forexEngineImpl = null;
/*   98 */   private History history = null;
/*      */   
/*      */   private IConsole console;
/*      */   
/*      */   protected UI userInterface;
/*      */   private IIndicators indicators;
/*      */   private JForexUtils jfUtils;
/*      */   private IDataService dataService;
/*      */   private IReportService reportService;
/*      */   private IDownloadableStrategies downloadableStrategies;
/*      */   private IContextChartsController contextChartsController;
/*      */   private File filesDir;
/*  110 */   private final Map<IFeedListener, Map<IFeedDescriptor, List<IFeedPointAndFigureListener>>> pointAndFigureFeedListenerDescriptiveMap = new HashMap();
/*  111 */   private final Map<IFeedListener, Map<IFeedDescriptor, List<IFeedRangeBarListener>>> rangeBarFeedListenerDescriptiveMap = new HashMap();
/*  112 */   private final Map<IFeedListener, Map<IFeedDescriptor, List<IFeedTickBarListener>>> tickBarFeedListenerDescriptiveMap = new HashMap();
/*  113 */   private final Map<IFeedListener, Map<IFeedDescriptor, List<IFeedRenkoListener>>> renkoFeedListenerDescriptiveMap = new HashMap();
/*  114 */   private final Map<IFeedListener, Map<IFeedDescriptor, List<IBarFeedListener>>> barFeedListenerDescriptiveMap = new HashMap();
/*  115 */   private final Map<IFeedListener, Map<IFeedDescriptor, List<ITickFeedListener>>> tickFeedListenerDescriptiveMap = new HashMap();
/*      */   
/*  117 */   private final Map<ITailoredFeedListener<?>, Map<ITailoredFeedDescriptor<?>, List<IFeedListener>>> tailoredFeedListenerDescriptiveMap = new HashMap();
/*      */   
/*  119 */   private final Map<ITickBarFeedListener, List<IFeedTickBarListener>> tickBarListenerMapperMap = Collections.synchronizedMap(new HashMap());
/*  120 */   private final Map<IRenkoBarFeedListener, List<IFeedRenkoListener>> renkokBarListenerMapperMap = Collections.synchronizedMap(new HashMap());
/*  121 */   private final Map<IRangeBarFeedListener, List<IFeedRangeBarListener>> rangeBarListenerMapperMap = Collections.synchronizedMap(new HashMap());
/*  122 */   private final Map<IPointAndFigureFeedListener, List<IFeedPointAndFigureListener>> pnfBarListenerMapperMap = Collections.synchronizedMap(new HashMap());
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JForexContextImpl(JFRunnableProcessor<?, ?> jfRunnableProcessor, IEngine forexEngineImpl, History history, IConsole console, DDSChartsController chartsController, UI userInterface, IClientGUIListener clientGUIListener, Properties serverProperties)
/*      */   {
/*  134 */     this.jfRunnableProcessor = jfRunnableProcessor;
/*  135 */     this.forexEngineImpl = forexEngineImpl;
/*  136 */     this.history = history;
/*  137 */     this.console = console;
/*  138 */     this.filesDir = com.dukascopy.dds2.greed.util.FilePathManager.getInstance().getFilesForStrategiesDir();
/*  139 */     this.userInterface = userInterface;
/*  140 */     this.jfUtils = new JForexUtils(history, this);
/*  141 */     this.dataService = new JForexDataService(FeedDataProvider.getDefaultInstance(), serverProperties, jfRunnableProcessor);
/*  142 */     this.reportService = new ReportService(FeedDataProvider.getDefaultInstance());
/*  143 */     this.downloadableStrategies = new DownloadableStrategies();
/*  144 */     this.contextChartsController = new JForexContextChartsController(chartsController, jfRunnableProcessor.getTaskManager(), clientGUIListener, jfRunnableProcessor.getJfRunnable().getClass().getName());
/*      */   }
/*      */   
/*      */   public boolean isStopped()
/*      */   {
/*  149 */     return this.jfRunnableProcessor.isStopping();
/*      */   }
/*      */   
/*      */   public JFRunnableProcessor<?, ?> getJFRunnableProcessor() {
/*  153 */     return this.jfRunnableProcessor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public IChart getChart(Instrument instrument)
/*      */   {
/*  161 */     return this.contextChartsController.getChart(instrument);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<IChart> getCharts(Instrument instrument)
/*      */   {
/*  169 */     return this.contextChartsController.getCharts(instrument);
/*      */   }
/*      */   
/*      */   public Set<IChart> getCharts()
/*      */   {
/*  174 */     return this.contextChartsController.getCharts();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IChart getLastActiveChart()
/*      */   {
/*  183 */     return this.contextChartsController.getLastActiveChart();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public IChart openChart(final IFeedDescriptor feedDescriptor)
/*      */   {
/*  191 */     final CustomReference<IChart> reference = new CustomReference();
/*      */     try {
/*  193 */       SwingUtilities.invokeAndWait(new Runnable()
/*      */       {
/*      */         public void run() {
/*  196 */           reference.setReferent(JForexContextImpl.this.contextChartsController.openChart(feedDescriptor));
/*      */         }
/*      */       });
/*      */     } catch (InterruptedException e) {
/*  200 */       throw new RuntimeException(e);
/*      */     } catch (InvocationTargetException e) {
/*  202 */       throw new RuntimeException(e);
/*      */     }
/*  204 */     return (IChart)reference.getReferent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void closeChart(final IChart chart)
/*      */   {
/*      */     try
/*      */     {
/*  213 */       SwingUtilities.invokeAndWait(new Runnable()
/*      */       {
/*      */         public void run() {
/*  216 */           JForexContextImpl.this.contextChartsController.closeChart(chart);
/*      */         }
/*      */       });
/*      */     } catch (InterruptedException e) {
/*  220 */       throw new RuntimeException(e);
/*      */     } catch (InvocationTargetException e) {
/*  222 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public IUserInterface getUserInterface()
/*      */   {
/*  228 */     return this.userInterface;
/*      */   }
/*      */   
/*      */   public IConsole getConsole()
/*      */   {
/*  233 */     return this.console;
/*      */   }
/*      */   
/*      */   public IEngine getEngine()
/*      */   {
/*  238 */     return this.forexEngineImpl;
/*      */   }
/*      */   
/*      */   public com.dukascopy.api.IHistory getHistory()
/*      */   {
/*  243 */     return this.history;
/*      */   }
/*      */   
/*      */   public IIndicators getIndicators()
/*      */   {
/*  248 */     if (this.indicators == null) {
/*  249 */       this.indicators = new com.dukascopy.api.impl.Indicators(this.history);
/*      */     }
/*  251 */     return this.indicators;
/*      */   }
/*      */   
/*      */   public IStrategies getStrategies()
/*      */   {
/*  256 */     new IStrategies()
/*      */     {
/*      */       public long startStrategy(File jfxFile, IStrategyListener listener, Map<String, Object> configurables, boolean fullAccess) throws JFException
/*      */       {
/*  260 */         return 0L;
/*      */       }
/*      */       
/*      */       public long startStrategy(IStrategy strategy, IStrategyListener listener, boolean fullAccess) throws JFException
/*      */       {
/*  265 */         return 0L;
/*      */       }
/*      */       
/*      */       public void stopStrategy(long strategyId) throws JFException
/*      */       {}
/*      */       
/*      */       public void stopAll() throws JFException
/*      */       {}
/*      */     };
/*      */   }
/*      */   
/*      */   public IDownloadableStrategies getDownloadableStrategies() {
/*  277 */     return this.downloadableStrategies;
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> Future<T> executeTask(Callable<T> callable)
/*      */   {
/*  283 */     return this.jfRunnableProcessor.executeTask(callable, false);
/*      */   }
/*      */   
/*      */   public boolean isFullAccessGranted()
/*      */   {
/*  288 */     return this.jfRunnableProcessor.isFullAccessGranted();
/*      */   }
/*      */   
/*      */   public void stop()
/*      */   {
/*      */     try {
/*  294 */       AccessController.doPrivileged(new StopStrategyPrivilegedAction(null));
/*      */     } catch (PrivilegedActionException e) {
/*  296 */       Exception ex = e.getException();
/*  297 */       String error = StrategyWrapper.representError(new Long(this.jfRunnableProcessor.getRunnableId()), ex);
/*  298 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(error, ex, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public File getFilesDir()
/*      */   {
/*  304 */     return this.filesDir;
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/*  309 */     return "JForex context";
/*      */   }
/*      */   
/*      */   public void pause() {}
/*      */   
/*      */   private final class StopStrategyPrivilegedAction implements PrivilegedExceptionAction<Object>
/*      */   {
/*      */     private StopStrategyPrivilegedAction() {}
/*      */     
/*      */     public Object run() throws Exception
/*      */     {
/*  320 */       JForexContextImpl.this.jfRunnableProcessor.getTaskManager().stopStrategy();
/*  321 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   public void setSubscribedInstruments(Set<Instrument> instruments)
/*      */   {
/*  327 */     setSubscribedInstruments(instruments, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSubscribedInstruments(final Set<Instrument> instruments, final boolean lock)
/*      */   {
/*      */     try
/*      */     {
/*  336 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  339 */           JForexContextImpl.this.jfRunnableProcessor.setSubscribedInstruments(instruments, lock);
/*  340 */           return null;
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/*  345 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public Set<Instrument> getSubscribedInstruments()
/*      */   {
/*  351 */     return this.jfRunnableProcessor.getSubscribedInstruments();
/*      */   }
/*      */   
/*      */   public IAccount getAccount()
/*      */   {
/*  356 */     return this.jfRunnableProcessor.getAccount();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToBarsFeed(Instrument instrument, Period period, OfferSide offerSide, final IBarFeedListener listener)
/*      */   {
/*  366 */     if (instrument == null) {
/*  367 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  369 */     if (offerSide == null) {
/*  370 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  372 */     if (period == null) {
/*  373 */       throw new NullPointerException("Period is null");
/*      */     }
/*  375 */     if (listener == null) {
/*  376 */       throw new NullPointerException("IBarFeedListener is null");
/*      */     }
/*      */     
/*  379 */     final IFeedDescriptor feedDescriptor = new FeedDescriptor(DataType.TIME_PERIOD_AGGREGATION, instrument, period, offerSide, null, null, null, null);
/*      */     try
/*      */     {
/*  382 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  385 */           StrategyRateDataNotificationFactory.getIsntance().getCandleNotificationManager().subscribeToLiveBarsFeed(JForexContextImpl.this.jfRunnableProcessor.getJfRunnable(), feedDescriptor, listener, JForexContextImpl.this.jfRunnableProcessor.getTaskManager().getExceptionHandler(), JForexContextImpl.this.jfRunnableProcessor.getTaskManager(), JForexContextImpl.this.jfRunnableProcessor, NotificationUtilsProvider.getNotificationUtils());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  394 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  398 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void unsubscribeFromBarsFeed(IBarFeedListener listener)
/*      */   {
/*  405 */     StrategyRateDataNotificationFactory.getIsntance().getCandleNotificationManager().unsubscribeFromLiveBarsFeed(this.jfRunnableProcessor.getJfRunnable(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToPointAndFigureFeed(Instrument instrument, OfferSide offerSide, PriceRange priceRange, ReversalAmount reversalAmount, IPointAndFigureFeedListener listener)
/*      */   {
/*  419 */     subscribeToPointAndFigureFeed(instrument, offerSide, priceRange, reversalAmount, null, null, listener);
/*      */   }
/*      */   
/*      */   private void subscribeToPointAndFigureFeed(final PointAndFigureFeedDescriptor feedDescriptor, final IFeedPointAndFigureListener listener) {
/*  423 */     if (feedDescriptor == null) {
/*  424 */       throw new NullPointerException("PointAndFigureFeedDescriptor is null");
/*      */     }
/*  426 */     if (listener == null) {
/*  427 */       throw new NullPointerException("IPointAndFigureFeedListener is null");
/*      */     }
/*      */     
/*  430 */     if (feedDescriptor.getInstrument() == null) {
/*  431 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  433 */     if (feedDescriptor.getOfferSide() == null) {
/*  434 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  436 */     if (feedDescriptor.getPriceRange() == null) {
/*  437 */       throw new NullPointerException("PriceRange is null");
/*      */     }
/*  439 */     if (feedDescriptor.getReversalAmount() == null) {
/*  440 */       throw new NullPointerException("ReversalAmount is null");
/*      */     }
/*  442 */     if (feedDescriptor.getDataInterpolationDescriptor() == null) {
/*  443 */       throw new NullPointerException("DataInterpolationDescriptor is null");
/*      */     }
/*  445 */     if (feedDescriptor.getPeriod() == null) {
/*  446 */       throw new NullPointerException("Base period is null");
/*      */     }
/*      */     try
/*      */     {
/*  450 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  453 */           StrategyRateDataNotificationFactory.getIsntance().getPointAndFigureNotificationManager().subscribeToLiveBarsFeed(JForexContextImpl.this.jfRunnableProcessor.getJfRunnable(), feedDescriptor, listener, JForexContextImpl.this.jfRunnableProcessor.getTaskManager().getExceptionHandler(), JForexContextImpl.this.jfRunnableProcessor.getTaskManager(), JForexContextImpl.this.jfRunnableProcessor, NotificationUtilsProvider.getNotificationUtils());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  462 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  466 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToPointAndFigureFeed(Instrument instrument, OfferSide offerSide, PriceRange priceRange, ReversalAmount reversalAmount, Period sessionPeriod, DataInterpolationDescriptor interpolationDescriptor, final IPointAndFigureFeedListener listener)
/*      */   {
/*  480 */     if (instrument == null) {
/*  481 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  483 */     if (offerSide == null) {
/*  484 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  486 */     if (priceRange == null) {
/*  487 */       throw new NullPointerException("PriceRange is null");
/*      */     }
/*  489 */     if (reversalAmount == null) {
/*  490 */       throw new NullPointerException("ReversalAmount is null");
/*      */     }
/*  492 */     if (listener == null) {
/*  493 */       throw new NullPointerException("IPointAndFigureFeedListener is null");
/*      */     }
/*      */     
/*  496 */     IFeedPointAndFigureListener feedListener = new IFeedPointAndFigureListener()
/*      */     {
/*      */       public void onPointAndFigureBar(ITailoredFeedDescriptor<IPointAndFigure> feedDescriptor, IPointAndFigure pointAndFigure) throws JFException {
/*  499 */         listener.onBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), pointAndFigure);
/*      */       }
/*      */       
/*  502 */     };
/*  503 */     List<IFeedPointAndFigureListener> list = (List)this.pnfBarListenerMapperMap.get(listener);
/*  504 */     if (list == null) {
/*  505 */       list = new ArrayList();
/*  506 */       this.pnfBarListenerMapperMap.put(listener, list);
/*      */     }
/*  508 */     list.add(feedListener);
/*      */     
/*  510 */     PointAndFigureFeedDescriptor feedDescriptor = new PointAndFigureFeedDescriptor(instrument, priceRange, reversalAmount, offerSide, sessionPeriod, interpolationDescriptor);
/*      */     
/*  512 */     subscribeToPointAndFigureFeed(feedDescriptor, feedListener);
/*      */   }
/*      */   
/*      */ 
/*      */   public void unsubscribeFromPointAndFigureFeed(IPointAndFigureFeedListener listener)
/*      */   {
/*  518 */     List<IFeedPointAndFigureListener> list = (List)this.pnfBarListenerMapperMap.remove(listener);
/*  519 */     for (IFeedPointAndFigureListener ll : list) {
/*  520 */       unsubscribeFromPointAndFigureFeed(ll);
/*      */     }
/*      */   }
/*      */   
/*      */   private void unsubscribeFromPointAndFigureFeed(IFeedPointAndFigureListener listener) {
/*  525 */     StrategyRateDataNotificationFactory.getIsntance().getPointAndFigureNotificationManager().unsubscribeFromLiveBarsFeed(this.jfRunnableProcessor.getJfRunnable(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToRangeBarFeed(Instrument instrument, OfferSide offerSide, PriceRange priceRange, IRangeBarFeedListener listener)
/*      */   {
/*  538 */     subscribeToRangeBarFeed(instrument, offerSide, priceRange, null, null, listener);
/*      */   }
/*      */   
/*      */   private void subscribeToRangeBarFeed(final RangeBarFeedDescriptor feedDescriptor, final IFeedRangeBarListener listener) {
/*  542 */     if (feedDescriptor == null) {
/*  543 */       throw new NullPointerException("RangeBarFeedDescriptor is null");
/*      */     }
/*  545 */     if (listener == null) {
/*  546 */       throw new NullPointerException("IRangeBarFeedListener is null");
/*      */     }
/*      */     
/*  549 */     if (feedDescriptor.getInstrument() == null) {
/*  550 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  552 */     if (feedDescriptor.getOfferSide() == null) {
/*  553 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  555 */     if (feedDescriptor.getPriceRange() == null) {
/*  556 */       throw new NullPointerException("PriceRange is null");
/*      */     }
/*  558 */     if (feedDescriptor.getPeriod() == null) {
/*  559 */       throw new NullPointerException("Base period is null");
/*      */     }
/*  561 */     if (feedDescriptor.getDataInterpolationDescriptor() == null) {
/*  562 */       throw new NullPointerException("DataInterpolationDescriptor is null");
/*      */     }
/*      */     try
/*      */     {
/*  566 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  569 */           StrategyRateDataNotificationFactory.getIsntance().getPriceRangeNotificationManager().subscribeToLiveBarsFeed(JForexContextImpl.this.jfRunnableProcessor.getJfRunnable(), feedDescriptor, listener, JForexContextImpl.this.jfRunnableProcessor.getTaskManager().getExceptionHandler(), JForexContextImpl.this.jfRunnableProcessor.getTaskManager(), JForexContextImpl.this.jfRunnableProcessor, NotificationUtilsProvider.getNotificationUtils());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  578 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  582 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToRangeBarFeed(Instrument instrument, OfferSide offerSide, PriceRange priceRange, Period sessionPeriod, DataInterpolationDescriptor interpolationDescriptor, final IRangeBarFeedListener listener)
/*      */   {
/*  595 */     if (instrument == null) {
/*  596 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  598 */     if (offerSide == null) {
/*  599 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  601 */     if (priceRange == null) {
/*  602 */       throw new NullPointerException("PriceRange is null");
/*      */     }
/*  604 */     if (listener == null) {
/*  605 */       throw new NullPointerException("IRangeBarFeedListener is null");
/*      */     }
/*      */     
/*  608 */     IFeedRangeBarListener feedListener = new IFeedRangeBarListener()
/*      */     {
/*      */       public void onRangeBar(ITailoredFeedDescriptor<IRangeBar> feedDescriptor, IRangeBar rangeBar) throws JFException {
/*  611 */         listener.onBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), rangeBar);
/*      */       }
/*      */       
/*  614 */     };
/*  615 */     List<IFeedRangeBarListener> list = (List)this.rangeBarListenerMapperMap.get(listener);
/*  616 */     if (list == null) {
/*  617 */       list = new ArrayList();
/*  618 */       this.rangeBarListenerMapperMap.put(listener, list);
/*      */     }
/*  620 */     list.add(feedListener);
/*      */     
/*  622 */     RangeBarFeedDescriptor feedDescriptor = new RangeBarFeedDescriptor(instrument, priceRange, offerSide, sessionPeriod, interpolationDescriptor);
/*      */     
/*  624 */     subscribeToRangeBarFeed(feedDescriptor, feedListener);
/*      */   }
/*      */   
/*      */   public void unsubscribeFromRangeBarFeed(IRangeBarFeedListener listener)
/*      */   {
/*  629 */     List<IFeedRangeBarListener> list = (List)this.rangeBarListenerMapperMap.remove(listener);
/*  630 */     for (IFeedRangeBarListener ll : list) {
/*  631 */       unsubscribeFromRangeBarFeed(listener);
/*      */     }
/*      */   }
/*      */   
/*      */   private void unsubscribeFromRangeBarFeed(IFeedRangeBarListener listener) {
/*  636 */     StrategyRateDataNotificationFactory.getIsntance().getPriceRangeNotificationManager().unsubscribeFromLiveBarsFeed(this.jfRunnableProcessor.getJfRunnable(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToTickBarFeed(Instrument instrument, OfferSide offerSide, TickBarSize tickBarSize, ITickBarFeedListener listener)
/*      */   {
/*  649 */     subscribeToTickBarFeed(instrument, offerSide, tickBarSize, null, listener);
/*      */   }
/*      */   
/*      */   private void subscribeToTickBarFeed(final TickBarFeedDescriptor feedDescriptor, final IFeedTickBarListener listener)
/*      */   {
/*  654 */     if (feedDescriptor == null) {
/*  655 */       throw new NullPointerException("TickBarFeedDescriptor is null");
/*      */     }
/*  657 */     if (feedDescriptor.getInstrument() == null) {
/*  658 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  660 */     if (feedDescriptor.getOfferSide() == null) {
/*  661 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  663 */     if (feedDescriptor.getTickBarSize() == null) {
/*  664 */       throw new NullPointerException("TickBarSize is null");
/*      */     }
/*  666 */     if (feedDescriptor.getPeriod() == null) {
/*  667 */       throw new NullPointerException("Base period is null");
/*      */     }
/*  669 */     if (listener == null) {
/*  670 */       throw new NullPointerException("IFeedTickBarListener is null");
/*      */     }
/*      */     try
/*      */     {
/*  674 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  677 */           StrategyRateDataNotificationFactory.getIsntance().getTickBarNotificationManager().subscribeToLiveBarsFeed(JForexContextImpl.this.jfRunnableProcessor.getJfRunnable(), feedDescriptor, listener, JForexContextImpl.this.jfRunnableProcessor.getTaskManager().getExceptionHandler(), JForexContextImpl.this.jfRunnableProcessor.getTaskManager(), JForexContextImpl.this.jfRunnableProcessor, NotificationUtilsProvider.getNotificationUtils());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  686 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  690 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToTickBarFeed(Instrument instrument, OfferSide offerSide, TickBarSize tickBarSize, Period sessionPeriod, final ITickBarFeedListener listener)
/*      */   {
/*  704 */     if (instrument == null) {
/*  705 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  707 */     if (offerSide == null) {
/*  708 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  710 */     if (tickBarSize == null) {
/*  711 */       throw new NullPointerException("TickBarSize is null");
/*      */     }
/*  713 */     if (listener == null) {
/*  714 */       throw new NullPointerException("ITickBarFeedListener is null");
/*      */     }
/*      */     
/*  717 */     IFeedTickBarListener feedListener = new IFeedTickBarListener()
/*      */     {
/*      */       public void onTickBar(ITailoredFeedDescriptor<ITickBar> feedDescriptor, ITickBar tickBar) throws JFException {
/*  720 */         listener.onBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), tickBar);
/*      */       }
/*      */       
/*  723 */     };
/*  724 */     List<IFeedTickBarListener> list = (List)this.tickBarListenerMapperMap.get(listener);
/*  725 */     if (list == null) {
/*  726 */       list = new ArrayList();
/*  727 */       this.tickBarListenerMapperMap.put(listener, list);
/*      */     }
/*  729 */     list.add(feedListener);
/*      */     
/*  731 */     TickBarFeedDescriptor feedDescriptor = new TickBarFeedDescriptor(instrument, tickBarSize, offerSide, sessionPeriod);
/*      */     
/*  733 */     subscribeToTickBarFeed(feedDescriptor, feedListener);
/*      */   }
/*      */   
/*      */ 
/*      */   public void unsubscribeFromTickBarFeed(ITickBarFeedListener listener)
/*      */   {
/*  739 */     List<IFeedTickBarListener> listeners = (List)this.tickBarListenerMapperMap.remove(listener);
/*  740 */     for (IFeedTickBarListener lis : listeners) {
/*  741 */       unsubscribeFromTickBarFeed(lis);
/*      */     }
/*      */   }
/*      */   
/*      */   private void unsubscribeFromTickBarFeed(IFeedTickBarListener listener) {
/*  746 */     StrategyRateDataNotificationFactory.getIsntance().getTickBarNotificationManager().unsubscribeFromLiveBarsFeed(this.jfRunnableProcessor.getJfRunnable(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToRenkoBarFeed(Instrument instrument, OfferSide offerSide, PriceRange brickSize, IRenkoBarFeedListener listener)
/*      */   {
/*  759 */     subscribeToRenkoBarFeed(instrument, offerSide, brickSize, null, listener);
/*      */   }
/*      */   
/*      */   private void subscribeToRenkoBarFeed(final RenkoFeedDescriptor feedDescriptor, final IFeedRenkoListener listener)
/*      */   {
/*  764 */     if (feedDescriptor == null) {
/*  765 */       throw new NullPointerException("RenkoFeedDescriptor is null");
/*      */     }
/*  767 */     if (listener == null) {
/*  768 */       throw new NullPointerException("IFeedRenkoBarListener is null");
/*      */     }
/*      */     
/*  771 */     if (feedDescriptor.getInstrument() == null) {
/*  772 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  774 */     if (feedDescriptor.getOfferSide() == null) {
/*  775 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  777 */     if (feedDescriptor.getPriceRange() == null) {
/*  778 */       throw new NullPointerException("PriceRange is null");
/*      */     }
/*  780 */     if (feedDescriptor.getRenkoSession() == null) {
/*  781 */       throw new NullPointerException("Renko session is null");
/*      */     }
/*  783 */     if (feedDescriptor.getRenkoCreationPoint() == null) {
/*  784 */       throw new NullPointerException("RenkoCreationPoint is null");
/*      */     }
/*  786 */     if (feedDescriptor.getPeriod() == null) {
/*  787 */       throw new NullPointerException("Base period is null");
/*      */     }
/*      */     try
/*      */     {
/*  791 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/*  794 */           StrategyRateDataNotificationFactory.getIsntance().getRenkoNotificationManager().subscribeToLiveBarsFeed(JForexContextImpl.this.jfRunnableProcessor.getJfRunnable(), feedDescriptor, listener, JForexContextImpl.this.jfRunnableProcessor.getTaskManager().getExceptionHandler(), JForexContextImpl.this.jfRunnableProcessor.getTaskManager(), JForexContextImpl.this.jfRunnableProcessor, NotificationUtilsProvider.getNotificationUtils());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  803 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/*  807 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToRenkoBarFeed(Instrument instrument, OfferSide offerSide, PriceRange brickSize, Period basePeriod, final IRenkoBarFeedListener listener)
/*      */   {
/*  821 */     if (instrument == null) {
/*  822 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*  824 */     if (offerSide == null) {
/*  825 */       throw new NullPointerException("OfferSide is null");
/*      */     }
/*  827 */     if (brickSize == null) {
/*  828 */       throw new NullPointerException("PriceRange is null");
/*      */     }
/*  830 */     if (listener == null) {
/*  831 */       throw new NullPointerException("IRenkoBarFeedListener is null");
/*      */     }
/*      */     
/*  834 */     IFeedRenkoListener feedListener = new IFeedRenkoListener()
/*      */     {
/*      */       public void onRenkoBar(ITailoredFeedDescriptor<IRenkoBar> feedDescriptor, IRenkoBar renkoBar) throws JFException {
/*  837 */         listener.onBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), renkoBar);
/*      */       }
/*      */       
/*  840 */     };
/*  841 */     List<IFeedRenkoListener> list = (List)this.renkokBarListenerMapperMap.get(listener);
/*  842 */     if (list == null) {
/*  843 */       list = new ArrayList();
/*  844 */       this.renkokBarListenerMapperMap.put(listener, list);
/*      */     }
/*  846 */     list.add(feedListener);
/*      */     
/*  848 */     RenkoFeedDescriptor feedDescriptor = new RenkoFeedDescriptor(instrument, brickSize, offerSide, null, null, basePeriod);
/*      */     
/*  850 */     subscribeToRenkoBarFeed(feedDescriptor, feedListener);
/*      */   }
/*      */   
/*      */   public void unsubscribeFromRenkoBarFeed(IRenkoBarFeedListener listener)
/*      */   {
/*  855 */     List<IFeedRenkoListener> listeners = (List)this.renkokBarListenerMapperMap.remove(listener);
/*  856 */     for (IFeedRenkoListener lis : listeners) {
/*  857 */       unsubscribeFromRenkoBarFeed(lis);
/*      */     }
/*      */   }
/*      */   
/*      */   private void unsubscribeFromRenkoBarFeed(IFeedRenkoListener listener) {
/*  862 */     StrategyRateDataNotificationFactory.getIsntance().getRenkoNotificationManager().unsubscribeFromLiveBarsFeed(this.jfRunnableProcessor.getJfRunnable(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addConfigurationChangeListener(String parameter, PropertyChangeListener listener)
/*      */   {
/*  874 */     this.jfRunnableProcessor.getTaskManager().addConfigurationChangeListener(parameter, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeConfigurationChangeListener(String parameter, PropertyChangeListener listener)
/*      */   {
/*  882 */     this.jfRunnableProcessor.getTaskManager().removeConfigurationChangeListener(parameter, listener);
/*      */   }
/*      */   
/*      */   public JFUtils getUtils()
/*      */   {
/*  887 */     return this.jfUtils;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public IDataService getDataService()
/*      */   {
/*  895 */     return this.dataService;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public IReportService getReportService()
/*      */   {
/*  903 */     return this.reportService;
/*      */   }
/*      */   
/*      */   private void subscribeToBarsFeed(IFeedDescriptor feedDescriptor, IBarFeedListener listener) {
/*  907 */     subscribeToBarsFeed(feedDescriptor.getInstrument(), feedDescriptor.getPeriod(), feedDescriptor.getOfferSide(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToRangeBarFeed(IFeedDescriptor feedDescriptor, IRangeBarFeedListener listener)
/*      */   {
/*  916 */     subscribeToRangeBarFeed(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToPointAndFigureFeed(IFeedDescriptor feedDescriptor, IPointAndFigureFeedListener listener)
/*      */   {
/*  927 */     subscribeToPointAndFigureFeed(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToTickBarFeed(IFeedDescriptor feedDescriptor, ITickBarFeedListener listener)
/*      */   {
/*  939 */     subscribeToTickBarFeed(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), feedDescriptor.getPeriod(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void subscribeToRenkoBarFeed(IFeedDescriptor feedDescriptor, IRenkoBarFeedListener listener)
/*      */   {
/*  949 */     subscribeToRenkoBarFeed(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getPeriod(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToFeed(IFeedDescriptor feedDescriptor, final IFeedListener feedListener)
/*      */   {
/*  960 */     Period sessionPeriod = feedDescriptor.getPeriod() == null ? TimeDataUtils.getDefaultSessionPeriod() : feedDescriptor.getPeriod();
/*  961 */     switch (feedDescriptor.getDataType()) {
/*      */     case POINT_AND_FIGURE: 
/*  963 */       IFeedPointAndFigureListener businessListener = new IFeedPointAndFigureListener()
/*      */       {
/*      */         public void onPointAndFigureBar(ITailoredFeedDescriptor<IPointAndFigure> feedDescriptor, IPointAndFigure pointAndFigure) throws JFException {
/*  966 */           feedListener.onFeedData(feedDescriptor, pointAndFigure);
/*      */         }
/*      */         
/*  969 */       };
/*  970 */       PointAndFigureFeedDescriptor feedDesc = new PointAndFigureFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  978 */       subscribeToPointAndFigureFeed(feedDesc, businessListener);
/*  979 */       addBusinessListener(feedListener, businessListener, feedDesc);
/*  980 */       break;
/*      */     
/*      */     case PRICE_RANGE_AGGREGATION: 
/*  983 */       RangeBarFeedDescriptor fDescriptor = new RangeBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod(), feedDescriptor.getDataInterpolationDescriptor());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  989 */       IFeedRangeBarListener list = new IFeedRangeBarListener()
/*      */       {
/*      */         public void onRangeBar(ITailoredFeedDescriptor<IRangeBar> feedDescriptor, IRangeBar rangeBar) {
/*  992 */           feedListener.onFeedData(feedDescriptor, rangeBar);
/*      */         }
/*  994 */       };
/*  995 */       subscribeToRangeBarFeed(fDescriptor, list);
/*  996 */       addBusinessListener(feedListener, list, fDescriptor);
/*  997 */       break;
/*      */     
/*      */     case RENKO: 
/* 1000 */       RenkoFeedDescriptor fDescriptor = new RenkoFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getPriceRange(), feedDescriptor.getOfferSide(), feedDescriptor.getRenkoSession(), feedDescriptor.getRenkoCreationPoint(), feedDescriptor.getPeriod());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1007 */       IFeedRenkoListener list = new IFeedRenkoListener()
/*      */       {
/*      */         public void onRenkoBar(ITailoredFeedDescriptor<IRenkoBar> feedDescriptor, IRenkoBar renkoBar) {
/* 1010 */           feedListener.onFeedData(feedDescriptor, renkoBar);
/*      */         }
/* 1012 */       };
/* 1013 */       subscribeToRenkoBarFeed(fDescriptor, list);
/* 1014 */       addBusinessListener(feedListener, list, fDescriptor);
/* 1015 */       break;
/*      */     
/*      */     case TICK_BAR: 
/* 1018 */       TickBarFeedDescriptor fDescriptor = new TickBarFeedDescriptor(feedDescriptor.getInstrument(), feedDescriptor.getTickBarSize(), feedDescriptor.getOfferSide(), feedDescriptor.getPeriod());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1023 */       IFeedTickBarListener list = new IFeedTickBarListener()
/*      */       {
/*      */         public void onTickBar(ITailoredFeedDescriptor<ITickBar> feedDescriptor, ITickBar tickBar) {
/* 1026 */           feedListener.onFeedData(feedDescriptor, tickBar);
/*      */         }
/* 1028 */       };
/* 1029 */       subscribeToTickBarFeed(fDescriptor, list);
/* 1030 */       addBusinessListener(feedListener, list, fDescriptor);
/* 1031 */       break;
/*      */     
/*      */ 
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 1035 */       final Filter filter = feedDescriptor.getFilter();
/*      */       
/*      */       IBarFeedListener businessListener;
/*      */       IBarFeedListener businessListener;
/* 1039 */       if ((filter == null) || (Filter.NO_FILTER.equals(filter))) {
/* 1040 */         businessListener = new IBarFeedListener()
/*      */         {
/*      */           public void onBar(Instrument instrument, Period period, OfferSide offerSide, IBar bar) {
/* 1043 */             feedListener.onFeedData(new TimePeriodAggregationFeedDescriptor(instrument, period, offerSide), bar);
/*      */           }
/*      */         };
/*      */       }
/*      */       else {
/* 1048 */         final IFilterManager filterManager = FeedDataProvider.getDefaultInstance().getFilterManager();
/* 1049 */         businessListener = new IBarFeedListener()
/*      */         {
/*      */           public void onBar(Instrument instrument, Period period, OfferSide offerSide, IBar bar) {
/* 1052 */             boolean matchedFilter = filterManager.matchedFilter(period, filter, bar.getTime(), bar.getOpen(), bar.getClose(), bar.getLow(), bar.getHigh(), bar.getVolume());
/*      */             
/* 1054 */             if (matchedFilter) {
/* 1055 */               feedListener.onFeedData(new TimePeriodAggregationFeedDescriptor(instrument, period, offerSide, filter), bar);
/*      */             }
/*      */           }
/*      */         };
/*      */       }
/*      */       
/* 1061 */       subscribeToBarsFeed(feedDescriptor, businessListener);
/* 1062 */       addBusinessListener(feedListener, businessListener, feedDescriptor);
/* 1063 */       break;
/*      */     
/*      */     case TICKS: 
/* 1066 */       ITickFeedListener businessListener = new ITickFeedListener()
/*      */       {
/*      */         public void onTick(Instrument instrument, ITick tick) {
/* 1069 */           feedListener.onFeedData(new TicksFeedDescriptor(instrument), tick);
/*      */         }
/* 1071 */       };
/* 1072 */       subscribeToTicksFeed(feedDescriptor, businessListener);
/* 1073 */       addBusinessListener(feedListener, businessListener, feedDescriptor);
/* 1074 */       break;
/*      */     default: 
/* 1076 */       throw new IllegalArgumentException("Unsupported data type " + feedDescriptor.getDataType());
/*      */     }
/*      */   }
/*      */   
/*      */   private <T> void addBusinessListener(IFeedListener feedListener, T businessListener, IFeedDescriptor feedDescriptor) {
/* 1081 */     switch (feedDescriptor.getDataType()) {
/*      */     case POINT_AND_FIGURE: 
/* 1083 */       Map<IFeedDescriptor, List<IFeedPointAndFigureListener>> map = (Map)this.pointAndFigureFeedListenerDescriptiveMap.get(feedListener);
/* 1084 */       if (map == null) {
/* 1085 */         map = new HashMap();
/* 1086 */         map.put(feedDescriptor, new ArrayList());
/* 1087 */         this.pointAndFigureFeedListenerDescriptiveMap.put(feedListener, map);
/*      */       }
/* 1089 */       List<IFeedPointAndFigureListener> businessListeners = (List)map.get(feedDescriptor);
/* 1090 */       if (businessListeners == null) {
/* 1091 */         businessListeners = new ArrayList();
/* 1092 */         map.put(feedDescriptor, businessListeners);
/*      */       }
/* 1094 */       if ((businessListener instanceof IFeedPointAndFigureListener)) {
/* 1095 */         businessListeners.add((IFeedPointAndFigureListener)businessListener);
/*      */       }
/*      */       
/*      */       break;
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 1100 */       Map<IFeedDescriptor, List<IFeedRangeBarListener>> map = (Map)this.rangeBarFeedListenerDescriptiveMap.get(feedListener);
/* 1101 */       if (map == null) {
/* 1102 */         map = new HashMap();
/* 1103 */         map.put(feedDescriptor, new ArrayList());
/* 1104 */         this.rangeBarFeedListenerDescriptiveMap.put(feedListener, map);
/*      */       }
/* 1106 */       List<IFeedRangeBarListener> rangeBarBusinessListeners = (List)map.get(feedDescriptor);
/* 1107 */       if (rangeBarBusinessListeners == null) {
/* 1108 */         rangeBarBusinessListeners = new ArrayList();
/* 1109 */         map.put(feedDescriptor, rangeBarBusinessListeners);
/*      */       }
/* 1111 */       if ((businessListener instanceof IFeedRangeBarListener)) {
/* 1112 */         rangeBarBusinessListeners.add((IFeedRangeBarListener)businessListener);
/*      */       }
/*      */       
/*      */       break;
/*      */     case TICK_BAR: 
/* 1117 */       Map<IFeedDescriptor, List<IFeedTickBarListener>> tickBarMap = (Map)this.tickBarFeedListenerDescriptiveMap.get(feedListener);
/* 1118 */       if (tickBarMap == null) {
/* 1119 */         tickBarMap = new HashMap();
/* 1120 */         tickBarMap.put(feedDescriptor, new ArrayList());
/* 1121 */         this.tickBarFeedListenerDescriptiveMap.put(feedListener, tickBarMap);
/*      */       }
/* 1123 */       List<IFeedTickBarListener> tickBarBusinessListeners = (List)tickBarMap.get(feedDescriptor);
/* 1124 */       if (tickBarBusinessListeners == null) {
/* 1125 */         tickBarBusinessListeners = new ArrayList();
/* 1126 */         tickBarMap.put(feedDescriptor, tickBarBusinessListeners);
/*      */       }
/* 1128 */       if ((businessListener instanceof IFeedTickBarListener)) {
/* 1129 */         tickBarBusinessListeners.add((IFeedTickBarListener)businessListener);
/*      */       }
/*      */       
/*      */       break;
/*      */     case RENKO: 
/* 1134 */       Map<IFeedDescriptor, List<IFeedRenkoListener>> renkoMap = (Map)this.renkoFeedListenerDescriptiveMap.get(feedListener);
/* 1135 */       if (renkoMap == null) {
/* 1136 */         renkoMap = new HashMap();
/* 1137 */         renkoMap.put(feedDescriptor, new ArrayList());
/* 1138 */         this.renkoFeedListenerDescriptiveMap.put(feedListener, renkoMap);
/*      */       }
/* 1140 */       List<IFeedRenkoListener> renkoBusinessListeners = (List)renkoMap.get(feedDescriptor);
/* 1141 */       if (renkoBusinessListeners == null) {
/* 1142 */         renkoBusinessListeners = new ArrayList();
/* 1143 */         renkoMap.put(feedDescriptor, renkoBusinessListeners);
/*      */       }
/* 1145 */       if ((businessListener instanceof IFeedRenkoListener)) {
/* 1146 */         renkoBusinessListeners.add((IFeedRenkoListener)businessListener);
/*      */       }
/*      */       
/*      */       break;
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 1151 */       Map<IFeedDescriptor, List<IBarFeedListener>> barMap = (Map)this.barFeedListenerDescriptiveMap.get(feedListener);
/* 1152 */       if (barMap == null) {
/* 1153 */         barMap = new HashMap();
/* 1154 */         barMap.put(feedDescriptor, new ArrayList());
/* 1155 */         this.barFeedListenerDescriptiveMap.put(feedListener, barMap);
/*      */       }
/* 1157 */       List<IBarFeedListener> barBusinessListeners = (List)barMap.get(feedDescriptor);
/* 1158 */       if (barBusinessListeners == null) {
/* 1159 */         barBusinessListeners = new ArrayList();
/* 1160 */         barMap.put(feedDescriptor, barBusinessListeners);
/*      */       }
/* 1162 */       if ((businessListener instanceof IBarFeedListener)) {
/* 1163 */         barBusinessListeners.add((IBarFeedListener)businessListener);
/*      */       }
/*      */       
/*      */       break;
/*      */     case TICKS: 
/* 1168 */       Map<IFeedDescriptor, List<ITickFeedListener>> tickMap = (Map)this.tickFeedListenerDescriptiveMap.get(feedListener);
/* 1169 */       if (tickMap == null) {
/* 1170 */         tickMap = new HashMap();
/* 1171 */         tickMap.put(feedDescriptor, new ArrayList());
/* 1172 */         this.tickFeedListenerDescriptiveMap.put(feedListener, tickMap);
/*      */       }
/* 1174 */       List<ITickFeedListener> tickBusinessListeners = (List)tickMap.get(feedDescriptor);
/* 1175 */       if (tickBusinessListeners == null) {
/* 1176 */         tickBusinessListeners = new ArrayList();
/* 1177 */         tickMap.put(feedDescriptor, tickBusinessListeners);
/*      */       }
/* 1179 */       if ((businessListener instanceof ITickFeedListener)) {
/* 1180 */         tickBusinessListeners.add((ITickFeedListener)businessListener);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   public void unsubscribeFromFeed(IFeedListener feedListener, IFeedDescriptor feedDescriptor)
/*      */   {
/* 1190 */     if (feedListener == null) {
/* 1191 */       return;
/*      */     }
/* 1193 */     if (feedDescriptor == null) {
/* 1194 */       unsubscribeFromFeed(feedListener);
/* 1195 */       return;
/*      */     }
/*      */     
/* 1198 */     switch (feedDescriptor.getDataType()) {
/*      */     case POINT_AND_FIGURE: 
/* 1200 */       Map<IFeedDescriptor, List<IFeedPointAndFigureListener>> pointAndFigureFkmap = (Map)this.pointAndFigureFeedListenerDescriptiveMap.get(feedListener);
/* 1201 */       if (pointAndFigureFkmap != null) {
/* 1202 */         List<IFeedPointAndFigureListener> businessListeners = (List)pointAndFigureFkmap.remove(feedDescriptor);
/* 1203 */         if ((businessListeners != null) && (!businessListeners.isEmpty())) {
/* 1204 */           for (IFeedPointAndFigureListener listener : businessListeners)
/* 1205 */             unsubscribeFromPointAndFigureFeed(listener);
/*      */         }
/*      */       }
/* 1208 */       break;
/*      */     
/*      */ 
/*      */     case PRICE_RANGE_AGGREGATION: 
/* 1212 */       Map<IFeedDescriptor, List<IFeedRangeBarListener>> rangeBarTkmap = (Map)this.rangeBarFeedListenerDescriptiveMap.get(feedListener);
/* 1213 */       if (rangeBarTkmap != null) {
/* 1214 */         List<IFeedRangeBarListener> businessListeners = (List)rangeBarTkmap.remove(feedDescriptor);
/* 1215 */         if ((businessListeners != null) && (!businessListeners.isEmpty())) {
/* 1216 */           for (IFeedRangeBarListener listener : businessListeners)
/* 1217 */             unsubscribeFromRangeBarFeed(listener);
/*      */         }
/*      */       }
/* 1220 */       break;
/*      */     
/*      */ 
/*      */     case TICK_BAR: 
/* 1224 */       Map<IFeedDescriptor, List<IFeedTickBarListener>> tickBarMap = (Map)this.tickBarFeedListenerDescriptiveMap.get(feedListener);
/* 1225 */       if (tickBarMap != null) {
/* 1226 */         List<IFeedTickBarListener> businessListeners = (List)tickBarMap.remove(feedDescriptor);
/* 1227 */         if ((businessListeners != null) && (!businessListeners.isEmpty())) {
/* 1228 */           for (IFeedTickBarListener listener : businessListeners)
/* 1229 */             unsubscribeFromTickBarFeed(listener);
/*      */         }
/*      */       }
/* 1232 */       break;
/*      */     
/*      */ 
/*      */     case RENKO: 
/* 1236 */       Map<IFeedDescriptor, List<IFeedRenkoListener>> renkoMap = (Map)this.renkoFeedListenerDescriptiveMap.get(feedListener);
/* 1237 */       if (renkoMap != null) {
/* 1238 */         List<IFeedRenkoListener> businessListeners = (List)renkoMap.remove(feedDescriptor);
/* 1239 */         if ((businessListeners != null) && (!businessListeners.isEmpty())) {
/* 1240 */           for (IFeedRenkoListener listener : businessListeners)
/* 1241 */             unsubscribeFromRenkoBarFeed(listener);
/*      */         }
/*      */       }
/* 1244 */       break;
/*      */     
/*      */ 
/*      */     case TIME_PERIOD_AGGREGATION: 
/* 1248 */       Map<IFeedDescriptor, List<IBarFeedListener>> barMap = (Map)this.barFeedListenerDescriptiveMap.get(feedListener);
/* 1249 */       if (barMap != null) {
/* 1250 */         List<IBarFeedListener> businessListeners = (List)barMap.remove(feedDescriptor);
/* 1251 */         if ((businessListeners != null) && (!businessListeners.isEmpty())) {
/* 1252 */           for (IBarFeedListener listener : businessListeners)
/* 1253 */             unsubscribeFromBarsFeed(listener);
/*      */         }
/*      */       }
/* 1256 */       break;
/*      */     
/*      */ 
/*      */     case TICKS: 
/* 1260 */       Map<IFeedDescriptor, List<ITickFeedListener>> tickMap = (Map)this.tickFeedListenerDescriptiveMap.get(feedListener);
/* 1261 */       if (tickMap != null) {
/* 1262 */         List<ITickFeedListener> businessListeners = (List)tickMap.remove(feedDescriptor);
/* 1263 */         if ((businessListeners != null) && (!businessListeners.isEmpty())) {
/* 1264 */           for (ITickFeedListener listener : businessListeners)
/* 1265 */             unsubscribeFromTicksFeed(listener);
/*      */         }
/*      */       }
/* 1268 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 1272 */       unsubscribeFromFeed(feedListener);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unsubscribeFromFeed(IFeedListener feedListener)
/*      */   {
/* 1285 */     Map<IFeedDescriptor, List<IFeedPointAndFigureListener>> pointAndFigureMap = (Map)this.pointAndFigureFeedListenerDescriptiveMap.remove(feedListener);
/* 1286 */     if (pointAndFigureMap != null) {
/* 1287 */       for (Map.Entry<IFeedDescriptor, List<IFeedPointAndFigureListener>> entry : pointAndFigureMap.entrySet()) {
/* 1288 */         List<IFeedPointAndFigureListener> pointAndFigureFeedListeners = (List)entry.getValue();
/* 1289 */         for (IFeedPointAndFigureListener listener : pointAndFigureFeedListeners) {
/* 1290 */           unsubscribeFromPointAndFigureFeed(listener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1295 */     Map<IFeedDescriptor, List<IFeedRangeBarListener>> rangeBarMap = (Map)this.rangeBarFeedListenerDescriptiveMap.remove(feedListener);
/* 1296 */     if (rangeBarMap != null) {
/* 1297 */       for (Map.Entry<IFeedDescriptor, List<IFeedRangeBarListener>> entry : rangeBarMap.entrySet()) {
/* 1298 */         List<IFeedRangeBarListener> priceRangeFeedListeners = (List)entry.getValue();
/* 1299 */         for (IFeedRangeBarListener listener : priceRangeFeedListeners) {
/* 1300 */           unsubscribeFromRangeBarFeed(listener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1305 */     Map<IFeedDescriptor, List<IFeedTickBarListener>> tickBarMap = (Map)this.tickBarFeedListenerDescriptiveMap.remove(feedListener);
/* 1306 */     if (tickBarMap != null) {
/* 1307 */       for (Map.Entry<IFeedDescriptor, List<IFeedTickBarListener>> entry : tickBarMap.entrySet()) {
/* 1308 */         List<IFeedTickBarListener> tickBarFeedListeners = (List)entry.getValue();
/* 1309 */         for (IFeedTickBarListener listener : tickBarFeedListeners) {
/* 1310 */           unsubscribeFromTickBarFeed(listener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1315 */     Map<IFeedDescriptor, List<IFeedRenkoListener>> renkoMap = (Map)this.renkoFeedListenerDescriptiveMap.remove(feedListener);
/* 1316 */     if (renkoMap != null) {
/* 1317 */       for (Map.Entry<IFeedDescriptor, List<IFeedRenkoListener>> entry : renkoMap.entrySet()) {
/* 1318 */         List<IFeedRenkoListener> renkoFeedListeners = (List)entry.getValue();
/* 1319 */         for (IFeedRenkoListener listener : renkoFeedListeners) {
/* 1320 */           unsubscribeFromRenkoBarFeed(listener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1325 */     Map<IFeedDescriptor, List<IBarFeedListener>> barMap = (Map)this.barFeedListenerDescriptiveMap.remove(feedListener);
/* 1326 */     if (barMap != null) {
/* 1327 */       for (Map.Entry<IFeedDescriptor, List<IBarFeedListener>> entry : barMap.entrySet()) {
/* 1328 */         List<IBarFeedListener> barFeedListeners = (List)entry.getValue();
/* 1329 */         for (IBarFeedListener listener : barFeedListeners) {
/* 1330 */           unsubscribeFromBarsFeed(listener);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1335 */     Map<IFeedDescriptor, List<ITickFeedListener>> tickMap = (Map)this.tickFeedListenerDescriptiveMap.remove(feedListener);
/* 1336 */     if (tickMap != null) {
/* 1337 */       for (Map.Entry<IFeedDescriptor, List<ITickFeedListener>> entry : tickMap.entrySet()) {
/* 1338 */         List<ITickFeedListener> barFeedListeners = (List)entry.getValue();
/* 1339 */         for (ITickFeedListener listener : barFeedListeners) {
/* 1340 */           unsubscribeFromTicksFeed(listener);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void unsubscribeFromTicksFeed(ITickFeedListener listener)
/*      */   {
/* 1349 */     StrategyRateDataNotificationFactory.getIsntance().getTickNotificationManager().unsubscribeFromLiveBarsFeed(this.jfRunnableProcessor.getJfRunnable(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void subscribeToTicksFeed(Instrument instrument, final ITickFeedListener listener)
/*      */   {
/* 1357 */     if (instrument == null) {
/* 1358 */       throw new NullPointerException("Instrument is null");
/*      */     }
/*      */     
/* 1361 */     JForexPeriod jForexPeriod = new JForexPeriod(DataType.TICKS, Period.TICK);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1366 */     final IFeedDescriptor feedDescriptor = new FeedDescriptor(DataType.TICKS, instrument, Period.TICK, OfferSide.BID, null, null, null, null);
/*      */     try
/*      */     {
/* 1369 */       AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Object run() throws Exception {
/* 1372 */           StrategyRateDataNotificationFactory.getIsntance().getTickNotificationManager().subscribeToLiveBarsFeed(JForexContextImpl.this.jfRunnableProcessor.getJfRunnable(), feedDescriptor, listener, JForexContextImpl.this.jfRunnableProcessor.getTaskManager().getExceptionHandler(), JForexContextImpl.this.jfRunnableProcessor.getTaskManager(), JForexContextImpl.this.jfRunnableProcessor, NotificationUtilsProvider.getNotificationUtils());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1381 */           return null;
/*      */         }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 1385 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void subscribeToTicksFeed(IFeedDescriptor feedDescriptor, ITickFeedListener listener) {
/* 1390 */     subscribeToTicksFeed(feedDescriptor.getInstrument(), listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setConfigurableChangeListener(ConfigurableChangeListener listener) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public <T extends ITimedData> void subscribeToFeed(final ITailoredFeedDescriptor<T> feedDescriptor, final ITailoredFeedListener<T> feedListener)
/*      */   {
/* 1401 */     IFeedListener feedListenerRequired = new IFeedListener()
/*      */     {
/*      */       public void onFeedData(IFeedDescriptor feedDescriptorInner, ITimedData feedData) {
/* 1404 */         feedListener.onFeedData(feedDescriptor, feedData);
/*      */       }
/*      */       
/* 1407 */     };
/* 1408 */     Map<ITailoredFeedDescriptor<?>, List<IFeedListener>> map = (Map)this.tailoredFeedListenerDescriptiveMap.get(feedListener);
/* 1409 */     if (map == null) {
/* 1410 */       map = new HashMap();
/* 1411 */       this.tailoredFeedListenerDescriptiveMap.put(feedListener, map);
/*      */     }
/*      */     
/* 1414 */     List<IFeedListener> listenersList = (List)map.get(feedDescriptor);
/* 1415 */     if (listenersList == null) {
/* 1416 */       listenersList = new ArrayList();
/* 1417 */       map.put(feedDescriptor, listenersList);
/*      */     }
/* 1419 */     listenersList.add(feedListenerRequired);
/*      */     
/*      */ 
/* 1422 */     subscribeToFeed(feedDescriptor, feedListenerRequired);
/*      */   }
/*      */   
/*      */   public <T extends ITimedData> void unsubscribeFromFeed(ITailoredFeedListener<T> feedListener)
/*      */   {
/* 1427 */     Map<ITailoredFeedDescriptor<?>, List<IFeedListener>> map = (Map)this.tailoredFeedListenerDescriptiveMap.remove(feedListener);
/* 1428 */     if (map != null) {
/* 1429 */       for (Map.Entry<ITailoredFeedDescriptor<?>, List<IFeedListener>> entry : map.entrySet()) {
/* 1430 */         List<IFeedListener> list = (List)entry.getValue();
/* 1431 */         if ((list != null) && (!list.isEmpty())) {
/* 1432 */           Iterator<IFeedListener> it = list.iterator();
/* 1433 */           while (it.hasNext()) {
/* 1434 */             unsubscribeFromFeed((IFeedListener)it.next());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public <T extends ITimedData> void unsubscribeFromFeed(ITailoredFeedListener<T> feedListener, ITailoredFeedDescriptor<T> feedDescriptor)
/*      */   {
/* 1443 */     Map<ITailoredFeedDescriptor<?>, List<IFeedListener>> map = (Map)this.tailoredFeedListenerDescriptiveMap.get(feedListener);
/* 1444 */     if (map != null) {
/* 1445 */       List<IFeedListener> list = (List)map.remove(feedDescriptor);
/* 1446 */       if ((list != null) && (!list.isEmpty())) {
/* 1447 */         Iterator<IFeedListener> it = list.iterator();
/* 1448 */         while (it.hasNext()) {
/* 1449 */           unsubscribeFromFeed((IFeedListener)it.next());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexContextImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */