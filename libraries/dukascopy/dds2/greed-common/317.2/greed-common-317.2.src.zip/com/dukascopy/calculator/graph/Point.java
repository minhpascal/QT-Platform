/*    */ package com.dukascopy.calculator.graph;
/*    */ 
/*    */ import java.awt.geom.Point2D.Double;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Point
/*    */   extends Point2D.Double
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Point() {}
/*    */   
/*    */   public Point(double x, double y)
/*    */   {
/* 19 */     super(x, y);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\graph\Point.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */