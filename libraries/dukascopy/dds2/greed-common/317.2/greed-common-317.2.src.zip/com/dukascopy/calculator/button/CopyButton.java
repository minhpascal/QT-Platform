/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ import com.dukascopy.calculator.function.Copy;
/*    */ import java.awt.event.ActionEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyButton
/*    */   extends CalculatorButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public CopyButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 17 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 18 */     setPobject(new Copy());
/* 19 */     setText();
/* 20 */     setTextSize();
/* 21 */     setShortcut('\000');
/* 22 */     addActionListener(this);
/*    */     
/* 24 */     setToolTipKey("sc.calculator.copy.result.to.clipboard.copy");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent actionEvent)
/*    */   {
/* 34 */     synchronized (this.mainCalculatorPanel) {
/* 35 */       if (getMainCalculatorPanel().getMode() != 0) {
/* 36 */         getMainCalculatorPanel().setMode(getPobject());
/* 37 */         getMainCalculatorPanel().requestFocusInWindow();
/* 38 */         return;
/*    */       }
/* 40 */       if (!getMainCalculatorPanel().getOn())
/* 41 */         return;
/* 42 */       getMainCalculatorPanel().copy();
/* 43 */       getMainCalculatorPanel().setShift(false);
/* 44 */       getMainCalculatorPanel().updateDisplay(true, true);
/* 45 */       getMainCalculatorPanel().requestFocusInWindow();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\CopyButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */