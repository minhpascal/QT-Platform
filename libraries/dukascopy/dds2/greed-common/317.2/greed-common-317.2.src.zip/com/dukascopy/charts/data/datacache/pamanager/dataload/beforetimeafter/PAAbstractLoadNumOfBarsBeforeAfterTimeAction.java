/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.beforetimeafter;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.PANthBarLiveFeedListenerWrapper;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PAAbstractLoadClosestAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PAAbstractLoadToCacheAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PAAbstractNthBarFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PAAbstractLoadByTimeIntervalAction;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationCreator;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationLiveFeedListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PAAbstractLoadNumOfBarsBeforeAfterTimeAction<D extends AbstractPriceAggregationData, L extends IPriceAggregationLiveFeedListener<D>, K extends IPriceAggregationCreator<D, TickData, L>, PC extends PAAbstractLoadToCacheAction<D, L, K>, PT extends PAAbstractLoadByTimeIntervalAction<D, L, K, PC>>
/*     */   implements Runnable
/*     */ {
/*  54 */   private static final Logger LOGGER = LoggerFactory.getLogger(PAAbstractLoadNumOfBarsBeforeAfterTimeAction.class);
/*     */   
/*     */   private IPACacheManager cacheManager;
/*     */   
/*     */   private Instrument instrument;
/*     */   
/*     */   private DataInterpolationDescriptor interpolationDescriptor;
/*     */   
/*     */   private OfferSide side;
/*     */   
/*     */   private JForexPeriod jfPeriod;
/*     */   
/*     */   private int numOfBarsBefore;
/*     */   
/*     */   private long time;
/*     */   
/*     */   private int numOfBarsAfter;
/*     */   
/*     */   private boolean fireUncompletedLastBasePeriodBars;
/*     */   
/*     */   private boolean infinitBasePeriod;
/*     */   
/*     */   private L listener;
/*     */   
/*     */   private ILoadingProgressListener loadingProgressListener;
/*     */   
/*     */   private int version;
/*     */   
/*     */ 
/*     */   public PAAbstractLoadNumOfBarsBeforeAfterTimeAction(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int numOfBarsBefore, long time, int numOfBarsAfter, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, L listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  86 */     this.cacheManager = cacheManager;
/*  87 */     this.instrument = instrument;
/*  88 */     this.interpolationDescriptor = interpolationDescriptor;
/*  89 */     this.side = side;
/*  90 */     this.jfPeriod = jfPeriod;
/*  91 */     this.numOfBarsBefore = numOfBarsBefore;
/*  92 */     this.numOfBarsAfter = numOfBarsAfter;
/*  93 */     this.time = time;
/*  94 */     this.fireUncompletedLastBasePeriodBars = fireUncompletedLastBasePeriodBars;
/*  95 */     this.infinitBasePeriod = infinitBasePeriod;
/*  96 */     this.version = version;
/*  97 */     this.listener = listener;
/*  98 */     this.loadingProgressListener = loadingProgressListener;
/*  99 */     validate();
/*     */   }
/*     */   
/*     */   private void validate() throws DataCacheException {
/* 103 */     long lastPossibleTime = this.cacheManager.getLastPossibleCacheFileTime();
/* 104 */     if (DataCacheUtils.getPACacheFileStartTime(this.time) > lastPossibleTime) {
/* 105 */       throw new DataCacheException("Cannot load price aggregation bars before/after the time! Requested time > last possible time or is in future! Last possible file time [" + lastPossibleTime + "], requested time [" + this.time + "]");
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract L createOneBarListener(List<D> paramList);
/*     */   
/*     */   protected abstract PT createLoadIntervalAction(long paramLong1, long paramLong2, ILoadingProgressListener paramILoadingProgressListener)
/*     */     throws DataCacheException;
/*     */   
/*     */   protected abstract PAAbstractLoadClosestAction<D, L, K, PC, PT> createLoadClosestAction(L paramL, ILoadingProgressListener paramILoadingProgressListener) throws DataCacheException;
/*     */   
/*     */   protected abstract PAAbstractNthBarFromSeedBarAction<D, L, K, PC, PANthBarLiveFeedListenerWrapper<D>> createNthBarFromSeedAction(D paramD, L paramL, boolean paramBoolean, ILoadingProgressListener paramILoadingProgressListener);
/*     */   
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 122 */       final List<D> oneBarList = new ArrayList();
/*     */       
/* 124 */       L oneBarListener = createOneBarListener(oneBarList);
/*     */       
/* 126 */       LoadingProgressAdapter loadingProgressAdapter = new LoadingProgressAdapter()
/*     */       {
/*     */         public boolean stopJob() {
/* 129 */           if ((PAAbstractLoadNumOfBarsBeforeAfterTimeAction.this.getLoadingProgressListener() != null) && (PAAbstractLoadNumOfBarsBeforeAfterTimeAction.this.getLoadingProgressListener().stopJob())) {
/* 130 */             return true;
/*     */           }
/*     */           
/* 133 */           return !oneBarList.isEmpty();
/*     */         }
/*     */         
/* 136 */       };
/* 137 */       PAAbstractLoadClosestAction<D, L, K, PC, PT> closestAction = createLoadClosestAction(oneBarListener, loadingProgressAdapter);
/* 138 */       closestAction.run();
/*     */       
/*     */ 
/* 141 */       if (oneBarList.isEmpty()) {
/* 142 */         if (this.loadingProgressListener != null) {
/* 143 */           if (this.loadingProgressListener.stopJob()) {
/* 144 */             this.loadingProgressListener.loadingFinished(false, this.time, this.time, 0L, null);
/* 145 */             return;
/*     */           }
/* 147 */           this.loadingProgressListener.loadingFinished(false, this.time, this.time, 0L, null);
/*     */         }
/* 149 */         return;
/*     */       }
/*     */       
/* 152 */       D timedBar = (AbstractPriceAggregationData)oneBarList.get(0);
/* 153 */       oneBarList.clear();
/*     */       
/*     */ 
/* 156 */       if (((this.numOfBarsBefore == 0) && (this.numOfBarsAfter == 1)) || ((this.numOfBarsBefore == 1) && (this.numOfBarsAfter == 0)))
/*     */       {
/*     */ 
/* 159 */         this.listener.newPriceData(timedBar);
/* 160 */         if (this.loadingProgressListener != null) {
/* 161 */           this.loadingProgressListener.loadingFinished(true, this.time, this.time, 0L, null);
/*     */         }
/* 163 */         return;
/*     */       }
/*     */       
/* 166 */       D fromBar = timedBar;
/*     */       
/*     */ 
/*     */ 
/* 170 */       if (this.numOfBarsBefore > 1)
/*     */       {
/* 172 */         PAAbstractNthBarFromSeedBarAction<D, L, K, PC, PANthBarLiveFeedListenerWrapper<D>> nthActionLeft = createNthBarFromSeedAction(timedBar, oneBarListener, true, loadingProgressAdapter);
/* 173 */         nthActionLeft.run();
/*     */         
/* 175 */         if (!oneBarList.isEmpty()) {
/* 176 */           fromBar = (AbstractPriceAggregationData)oneBarList.get(0);
/*     */         }
/*     */       }
/*     */       
/* 180 */       oneBarList.clear();
/*     */       
/* 182 */       D toBar = timedBar;
/*     */       
/* 184 */       if (this.numOfBarsAfter > 0) {
/* 185 */         PAAbstractNthBarFromSeedBarAction<D, L, K, PC, PANthBarLiveFeedListenerWrapper<D>> nthActionRight = createNthBarFromSeedAction(timedBar, oneBarListener, false, loadingProgressAdapter);
/* 186 */         nthActionRight.run();
/*     */         
/* 188 */         if ((!oneBarList.isEmpty()) && (((AbstractPriceAggregationData)oneBarList.get(0)).getTime() > toBar.getTime())) {
/* 189 */           toBar = (AbstractPriceAggregationData)oneBarList.get(0);
/*     */         }
/*     */       }
/*     */       
/* 193 */       long timeFrom = fromBar.getTime();
/* 194 */       long timeTo = toBar.getTime();
/*     */       
/* 196 */       ILoadingProgressListener loadingProgressAdapter2 = new LoadingProgressAdapter()
/*     */       {
/*     */         public boolean stopJob() {
/* 199 */           if ((PAAbstractLoadNumOfBarsBeforeAfterTimeAction.this.getLoadingProgressListener() != null) && (PAAbstractLoadNumOfBarsBeforeAfterTimeAction.this.getLoadingProgressListener().stopJob())) {
/* 200 */             return true;
/*     */           }
/* 202 */           return false;
/*     */         }
/*     */         
/* 205 */       };
/* 206 */       PT timeIntervalAction = createLoadIntervalAction(timeFrom, timeTo, loadingProgressAdapter2);
/*     */       
/* 208 */       timeIntervalAction.run();
/* 209 */       if ((this.loadingProgressListener != null) && (this.loadingProgressListener.stopJob())) {
/* 210 */         this.loadingProgressListener.loadingFinished(false, timeFrom, timeTo, 0L, null);
/* 211 */         return;
/*     */       }
/*     */       
/*     */ 
/* 215 */       if (this.loadingProgressListener != null) {
/* 216 */         this.loadingProgressListener.loadingFinished(true, timeFrom, timeTo, 0L, null);
/*     */       }
/*     */     }
/*     */     catch (DataCacheException e) {
/* 220 */       if (this.loadingProgressListener != null) {
/* 221 */         this.loadingProgressListener.loadingFinished(false, this.time, this.time, 0L, e);
/*     */       }
/* 223 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public IPACacheManager getCacheManager() {
/* 228 */     return this.cacheManager;
/*     */   }
/*     */   
/* 231 */   public Instrument getInstrument() { return this.instrument; }
/*     */   
/*     */   public DataInterpolationDescriptor getInterpolationDescriptor() {
/* 234 */     return this.interpolationDescriptor;
/*     */   }
/*     */   
/* 237 */   public OfferSide getSide() { return this.side; }
/*     */   
/*     */   public JForexPeriod getJfPeriod() {
/* 240 */     return this.jfPeriod;
/*     */   }
/*     */   
/* 243 */   public int getNumOfBarsBefore() { return this.numOfBarsBefore; }
/*     */   
/*     */   public long getTime() {
/* 246 */     return this.time;
/*     */   }
/*     */   
/* 249 */   public int getNumOfBarsAfter() { return this.numOfBarsAfter; }
/*     */   
/*     */   public boolean isFireUncompletedLastBasePeriodBars() {
/* 252 */     return this.fireUncompletedLastBasePeriodBars;
/*     */   }
/*     */   
/* 255 */   public boolean isInfinitBasePeriod() { return this.infinitBasePeriod; }
/*     */   
/*     */   public ILoadingProgressListener getLoadingProgressListener() {
/* 258 */     return this.loadingProgressListener;
/*     */   }
/*     */   
/* 261 */   public int getVersion() { return this.version; }
/*     */   
/*     */   public L getListener() {
/* 264 */     return this.listener;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\beforetimeafter\PAAbstractLoadNumOfBarsBeforeAfterTimeAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */