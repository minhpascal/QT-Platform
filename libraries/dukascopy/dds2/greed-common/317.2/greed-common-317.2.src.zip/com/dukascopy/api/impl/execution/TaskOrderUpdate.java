/*     */ package com.dukascopy.api.impl.execution;
/*     */ 
/*     */ import com.dukascopy.api.IMessage;
/*     */ import com.dukascopy.api.IOrder.State;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*     */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*     */ import com.dukascopy.api.impl.connect.OrdersInternalCollection;
/*     */ import com.dukascopy.api.impl.connect.PlatformOrderImpl;
/*     */ import com.dukascopy.api.plugins.IMessageListener;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*     */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderMessageExt;
/*     */ import com.dukascopy.dds3.transport.msg.types.OrderState;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskOrderUpdate
/*     */   implements Task
/*     */ {
/*  32 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskOrderUpdate.class);
/*     */   private IMessageListener strategy;
/*     */   private OrderMessageExt orderMessage;
/*     */   private JForexTaskManager taskManager;
/*     */   private StrategyEventsCallback strategyEventsCallback;
/*     */   
/*     */   public TaskOrderUpdate(JForexTaskManager taskManager, IMessageListener strategy, OrderMessageExt orderMessage)
/*     */   {
/*  40 */     this.strategy = strategy;
/*  41 */     this.orderMessage = orderMessage;
/*  42 */     this.taskManager = taskManager;
/*  43 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*     */   }
/*     */   
/*     */   public Task.Type getType()
/*     */   {
/*  48 */     return Task.Type.MESSAGE;
/*     */   }
/*     */   
/*     */   public Object call() throws Exception
/*     */   {
/*  53 */     if (this.taskManager.isStrategyStopping()) {
/*  54 */       return null;
/*     */     }
/*  56 */     if (LOGGER.isDebugEnabled()) {
/*  57 */       LOGGER.debug("Starting processing of order message [" + this.orderMessage + "]");
/*     */     }
/*  59 */     if (!this.taskManager.isGlobal()) {
/*  60 */       LOGGER.error("Received OrderMessage for not global account");
/*  61 */       return null;
/*     */     }
/*     */     try {
/*  64 */       OrderGroupMessage orderGroupMessage = new OrderGroupMessage();
/*  65 */       ArrayList<OrderMessageExt> orders = new ArrayList();
/*  66 */       orders.add(this.orderMessage);
/*  67 */       orderGroupMessage.setOrders(orders);
/*  68 */       OrdersInternalCollection ordersInternalCollection = this.taskManager.getOrdersInternalCollection();
/*  69 */       PlatformOrderImpl platformOrderImpl = null;
/*  70 */       String parentOrderId = this.orderMessage.getParentOrderId();
/*  71 */       if (parentOrderId != null) {
/*  72 */         platformOrderImpl = ordersInternalCollection.getOrderById(parentOrderId);
/*  73 */         orderGroupMessage.setOrderGroupId(parentOrderId);
/*     */       }
/*     */       
/*  76 */       String label = PlatformOrderImpl.extractLabel(orderGroupMessage);
/*  77 */       if ((platformOrderImpl == null) && (label != null) && (
/*  78 */         (!this.taskManager.isGlobal()) || (this.orderMessage.getState() != OrderState.CANCELLED)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  83 */         platformOrderImpl = ordersInternalCollection.getOrderByLabel(label);
/*  84 */         if ((platformOrderImpl != null) && (platformOrderImpl.getState() != IOrder.State.CREATED)) {
/*  85 */           LOGGER.warn("Getting order by label [" + label + "] instead of order id");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  90 */       if (platformOrderImpl == null) {
/*  91 */         if ((this.taskManager.isGlobal()) && (this.orderMessage.getState() == OrderState.CANCELLED))
/*     */         {
/*  93 */           return null;
/*     */         }
/*  95 */         if (label == null) {
/*  96 */           LOGGER.warn("Order message received that doesn't have assigned external id. Parent order id [" + parentOrderId + "]");
/*  97 */           orderGroupMessage.setExternalSysId(parentOrderId);
/*  98 */           label = parentOrderId;
/*     */         }
/* 100 */         if (orderGroupMessage.getOrders().size() > 0) {
/* 101 */           platformOrderImpl = new PlatformOrderImpl(this.taskManager);
/*     */           try {
/* 103 */             ordersInternalCollection.put(label, platformOrderImpl, false);
/*     */           } catch (JFException e) {
/* 105 */             LOGGER.error(e.getMessage(), e);
/*     */           }
/* 107 */         } else if ((orderGroupMessage.isOcoMerge()) && (orderGroupMessage.getAmount() != null) && (orderGroupMessage.getAmount().compareTo(BigDecimal.ZERO) == 0))
/*     */         {
/* 109 */           platformOrderImpl = new PlatformOrderImpl(this.taskManager);
/*     */           try {
/* 111 */             ordersInternalCollection.put(label, platformOrderImpl, false);
/*     */           } catch (JFException e) {
/* 113 */             LOGGER.error(e.getMessage(), e);
/*     */           }
/*     */         }
/*     */         else {
/* 117 */           return null;
/*     */         }
/*     */       }
/* 120 */       IMessage platformMessageImpl = platformOrderImpl.update(orderGroupMessage);
/* 121 */       if ((platformOrderImpl.getState() == IOrder.State.FILLED) && (platformOrderImpl.getAmount() == platformOrderImpl.getRequestedAmount()))
/*     */       {
/* 123 */         this.taskManager.getOrdersInternalCollection().removeById(parentOrderId);
/*     */       }
/*     */       
/* 126 */       if (platformMessageImpl != null) {
/* 127 */         this.strategy.onMessage(platformMessageImpl);
/* 128 */         if (this.strategyEventsCallback != null) {
/* 129 */           this.strategyEventsCallback.onMessage(platformMessageImpl);
/*     */         }
/*     */       }
/*     */     } catch (Throwable t) {
/* 133 */       String msg = ErrorHelper.representError(this.strategy, t);
/* 134 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 135 */       LOGGER.error(t.getMessage(), t);
/* 136 */       this.taskManager.getExceptionHandler().onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_MESSAGE, t);
/*     */     }
/* 138 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskOrderUpdate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */