/*     */ package com.dukascopy.charts.data.datacache.filtering;
/*     */ 
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.ITimeInterval;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.TimeInterval;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeekendBuffer
/*     */ {
/*  24 */   protected static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss:SSS");
/*     */   
/*  26 */   static { DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT 0")); }
/*     */   
/*     */ 
/*     */   private ITimeInterval[] buffer;
/*     */   
/*     */   private long from;
/*     */   
/*     */   private long to;
/*     */   private static final long ONE_DAY_INTERVAL = 86400000L;
/*     */   private static final long ONE_WEEK_INTERVAL = 604800000L;
/*     */   public WeekendBuffer()
/*     */   {
/*  38 */     clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  45 */     this.from = Long.MAX_VALUE;
/*  46 */     this.to = Long.MIN_VALUE;
/*  47 */     this.buffer = new TimeInterval[0];
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  51 */     return size() <= 0;
/*     */   }
/*     */   
/*     */   public int size() {
/*  55 */     return this.buffer.length;
/*     */   }
/*     */   
/*     */   public boolean coversTime(long time) {
/*  59 */     boolean result = (this.from <= time) && (time <= this.to);
/*  60 */     return result;
/*     */   }
/*     */   
/*     */   public boolean coversInterval(long from, long to) {
/*  64 */     boolean result = (this.from <= from) && (to <= this.to);
/*  65 */     return result;
/*     */   }
/*     */   
/*     */   public void set(List<ITimeInterval> weekends) {
/*  69 */     if ((weekends == null) || (weekends.isEmpty())) {
/*  70 */       return;
/*     */     }
/*     */     
/*     */ 
/*  74 */     validate(weekends);
/*     */     
/*  76 */     clear();
/*  77 */     this.buffer = ((ITimeInterval[])weekends.toArray(new TimeInterval[weekends.size()]));
/*     */     
/*  79 */     for (ITimeInterval weekend : this.buffer) {
/*  80 */       if (this.from > weekend.getStart()) {
/*  81 */         this.from = weekend.getStart();
/*     */       }
/*     */       
/*  84 */       if (this.to < weekend.getEnd()) {
/*  85 */         this.to = weekend.getEnd();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void validate(List<ITimeInterval> weekends)
/*     */   {
/*  92 */     ITimeInterval previousWeekend = null;
/*     */     
/*  94 */     for (ITimeInterval ti : weekends) {
/*  95 */       if ((ti.getStart() < 0L) || (ti.getEnd() < 0L)) {
/*  96 */         throw new IllegalArgumentException("Dates before " + DateUtils.format(0L) + " are not supported <" + ti + ">");
/*     */       }
/*     */       
/*  99 */       if (ti.getStart() > ti.getEnd()) {
/* 100 */         throw new IllegalArgumentException("start > end " + ti);
/*     */       }
/*     */       
/* 103 */       if (previousWeekend != null) {
/* 104 */         if (previousWeekend.getEnd() > ti.getStart()) {
/* 105 */           throw new IllegalArgumentException("Passed weekend array is not consequent, prev weekend<" + previousWeekend + "> current weekend<" + ti + ">");
/*     */         }
/* 107 */         if (Math.abs(ti.getEnd() - previousWeekend.getEnd()) > TimeUnit.DAYS.toMillis(8L)) {
/* 108 */           throw new IllegalArgumentException("Gap between two weekends is too big, prev weekend<" + previousWeekend + "> current weekend<" + ti + ">");
/*     */         }
/*     */       }
/*     */       
/* 112 */       previousWeekend = ti;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWeekendTime(long time)
/*     */   {
/* 124 */     boolean result = false;
/* 125 */     ITimeInterval appropriateWeekend = getWeekend(time);
/*     */     
/* 127 */     if (appropriateWeekend != null) {
/* 128 */       result = appropriateWeekend.isInIntervalForWeekends(time);
/*     */     }
/*     */     else {
/* 131 */       for (ITimeInterval weekend : this.buffer) {
/* 132 */         if (weekend.isInIntervalForWeekends(time)) {
/* 133 */           result = true;
/* 134 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 139 */     return result;
/*     */   }
/*     */   
/*     */   public ITimeInterval getWeekend(long time) {
/* 143 */     int index = getIndexForTime(time);
/*     */     
/* 145 */     ITimeInterval weekend = null;
/* 146 */     if ((0 <= index) && (index < this.buffer.length)) {
/* 147 */       weekend = this.buffer[index];
/*     */     }
/*     */     
/* 150 */     return weekend;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getIndexForTime(long time)
/*     */   {
/* 157 */     long fromWeekNumber = this.from / 604800000L;
/* 158 */     long currentWeekNumber = time / 604800000L;
/* 159 */     int index = (int)(currentWeekNumber - fromWeekNumber);
/*     */     
/* 161 */     return index;
/*     */   }
/*     */   
/*     */   public long getFrom() {
/* 165 */     return this.from;
/*     */   }
/*     */   
/*     */   public long getTo() {
/* 169 */     return this.to;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TimeInterval[] getWeekends(long from, long to)
/*     */   {
/* 182 */     TimeInterval[] result = null;
/*     */     
/* 184 */     if (isEmpty()) {
/* 185 */       return result;
/*     */     }
/*     */     
/* 188 */     int indexFrom = getIndexForTime(from);
/* 189 */     int indexTo = getIndexForTime(to);
/*     */     
/* 191 */     indexFrom = indexFrom < 0 ? 0 : indexFrom;
/* 192 */     indexFrom = indexFrom >= size() ? size() - 1 : indexFrom;
/*     */     
/* 194 */     indexTo = indexTo < 0 ? 0 : indexTo;
/* 195 */     indexTo = indexTo >= size() ? size() - 1 : indexTo;
/*     */     
/* 197 */     if (indexFrom > indexTo) {
/* 198 */       return result;
/*     */     }
/*     */     
/* 201 */     result = new TimeInterval[indexTo - indexFrom + 1];
/* 202 */     System.arraycopy(this.buffer, indexFrom, result, 0, result.length);
/*     */     
/* 204 */     return result;
/*     */   }
/*     */   
/*     */   public ITimeInterval getWeekendByIndex(int index) {
/* 208 */     return this.buffer[index];
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\filtering\WeekendBuffer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */