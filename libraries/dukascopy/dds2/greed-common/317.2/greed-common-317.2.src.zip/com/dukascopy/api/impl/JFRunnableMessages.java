/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.Configurable;
/*     */ import com.dukascopy.api.IJFRunnable;
/*     */ import com.dukascopy.api.IStrategy;
/*     */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StrategyRunParameter;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.params.Variable;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds2.greed.util.ParameterUtils;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JFRunnableMessages
/*     */ {
/*  37 */   private static final Logger LOGGER = LoggerFactory.getLogger(JForexTaskManager.class);
/*     */   
/*     */   private static final String PARAMS_SEPARATOR = ", ";
/*     */   private static final String UNKNOWN_VALUE = "?";
/*     */   private static final String WITH_PARAMETERS = " with parameters ";
/*     */   private static final String WITH_NO_PARAMETERS = " with no parameters";
/*     */   private static final String ON_THE_LOCAL_COMPUTER = " on the local computer";
/*     */   private static final String ON_THE_REMOTE_SERVER = " on the remote server";
/*     */   private static final String REASON = ". Reason: ";
/*  46 */   private static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/*  47 */   static { DATE_FORMATTER.setTimeZone(TimeZone.getTimeZone("GMT")); }
/*     */   
/*  49 */   private static final DecimalFormat DECIMAL_FORMATTER = new DecimalFormat("0.0####");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void startingStrategy(boolean isRemoteRun, StrategyWrapper wrapper)
/*     */   {
/*  60 */     printStartingStrategy(getStrategyName(wrapper), isRemoteRun);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void startingRunnable(IJFRunnable<?> strategy, boolean isRemoteRun)
/*     */   {
/*  67 */     printStartingStrategy(getStrategyName(strategy), isRemoteRun);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printStartingStrategy(String strategyName, boolean isRemoteRun)
/*     */   {
/*  79 */     StringBuilder str = new StringBuilder();
/*  80 */     str.append("Starting \"").append(strategyName).append("\" strategy at ").append(DATE_FORMATTER.format(new Date()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  85 */     if (isRemoteRun) {
/*  86 */       str.append(" on the remote server");
/*     */     } else {
/*  88 */       str.append(" on the local computer");
/*     */     }
/*     */     
/*  91 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(str.toString(), false);
/*     */   }
/*     */   
/*     */   public static void strategyIsStarted(boolean isRemoteRun, String strategyName, List<StrategyRunParameter> params) {
/*  95 */     printStrategyIsStarted(strategyName, getParameters(params), isRemoteRun, null, null);
/*     */   }
/*     */   
/*     */   public static void strategyIsStarted(String strategyName, List<StrategyRunParameter> params, boolean isRemoteRun, Date date, String jfxPackMD5) {
/*  99 */     printStrategyIsStarted(strategyName, getParameters(params), isRemoteRun, date, jfxPackMD5);
/*     */   }
/*     */   
/*     */   public static void runnableIsStarted(IJFRunnable<?> strategy, boolean isRemoteRun, String jfxPackMD5) {
/* 103 */     printStrategyIsStarted(getStrategyName(strategy), getParameters(strategy), isRemoteRun, null, jfxPackMD5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printStrategyIsStarted(String strategyName, String parameters, boolean isRemoteRun, Date date, String jfxPackMD5)
/*     */   {
/* 112 */     if (date == null) {
/* 113 */       date = new Date();
/*     */     }
/*     */     
/* 116 */     StringBuilder message = new StringBuilder();
/*     */     
/* 118 */     if (jfxPackMD5 == null) {
/* 119 */       jfxPackMD5 = "";
/*     */     }
/*     */     
/* 122 */     message.append("Strategy \"").append(strategyName).append("\" ").append("Strategy ID: ").append(jfxPackMD5).append(" is started at ").append(DATE_FORMATTER.format(date));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */     if (isRemoteRun) {
/* 131 */       message.append(" on the remote server");
/*     */     } else {
/* 133 */       message.append(" on the local computer");
/*     */     }
/*     */     
/* 136 */     if (parameters.length() > 0) {
/* 137 */       message.append(" with parameters ").append(parameters);
/*     */     } else {
/* 139 */       message.append(" with no parameters");
/*     */     }
/*     */     
/* 142 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(message.toString(), false);
/*     */   }
/*     */   
/*     */   public static void strategyIsModified(boolean isRemoteRun, StrategyWrapper wrapper, List<StrategyRunParameter> params) {
/* 146 */     printStrategyIsModified(getStrategyName(wrapper), getParameters(params), isRemoteRun);
/*     */   }
/*     */   
/*     */   public static void strategyIsModified(boolean isRemoteRun, String strategyName, IStrategy strategy) {
/* 150 */     printStrategyIsModified(strategyName, getParameters(strategy), isRemoteRun);
/*     */   }
/*     */   
/*     */   public static void strategyIsModified(IStrategy strategy, boolean isRemoteRun) {
/* 154 */     printStrategyIsModified(getStrategyName(strategy), getParameters(strategy), isRemoteRun);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printStrategyIsModified(String strategyName, String parameters, boolean isRemoteRun)
/*     */   {
/* 163 */     StringBuilder message = new StringBuilder();
/* 164 */     message.append("Strategy \"").append(strategyName).append("\" is modified at ").append(DATE_FORMATTER.format(new Date()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 169 */     if (isRemoteRun) {
/* 170 */       message.append(" on the remote server");
/*     */     } else {
/* 172 */       message.append(" on the local computer");
/*     */     }
/*     */     
/* 175 */     if (parameters.length() > 0) {
/* 176 */       message.append(" with parameters ").append(parameters);
/*     */     } else {
/* 178 */       message.append(" with no parameters");
/*     */     }
/*     */     
/* 181 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(message.toString(), false);
/*     */   }
/*     */   
/*     */   public static void stoppingStrategy(boolean isRemoteRun, StrategyWrapper wrapper) {
/* 185 */     printStoppingStrategy(getStrategyName(wrapper), isRemoteRun);
/*     */   }
/*     */   
/*     */   public static void stoppingStrategy(boolean isRemoteRun, String strategyName) {
/* 189 */     printStoppingStrategy(strategyName, isRemoteRun);
/*     */   }
/*     */   
/*     */   public static void stoppingStrategy(IJFRunnable<?> strategy, boolean isRemoteRun) {
/* 193 */     printStoppingStrategy(getStrategyName(strategy), isRemoteRun);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printStoppingStrategy(String strategyName, boolean isRemoteRun)
/*     */   {
/* 203 */     StringBuilder message = new StringBuilder();
/* 204 */     message.append("Stopping \"").append(strategyName).append("\" strategy at ").append(DATE_FORMATTER.format(new Date()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 209 */     if (isRemoteRun) {
/* 210 */       message.append(" on the remote server");
/*     */     } else {
/* 212 */       message.append(" on the local computer");
/*     */     }
/*     */     
/* 215 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(message.toString(), false);
/*     */   }
/*     */   
/*     */   public static void strategyIsStopped(boolean isRemoteRun, String strategyName, List<StrategyRunParameter> params) {
/* 219 */     printStrategyIsStopped(strategyName, getParameters(params), isRemoteRun, null, null);
/*     */   }
/*     */   
/*     */   public static void strategyIsStopped(String strategyName, List<StrategyRunParameter> params, boolean isRemoteRun, Date date, String reason) {
/* 223 */     printStrategyIsStopped(strategyName, getParameters(params), isRemoteRun, date, reason);
/*     */   }
/*     */   
/*     */   public static void strategyIsStopped(IJFRunnable<?> strategy, String reason, boolean isRemoteRun) {
/* 227 */     printStrategyIsStopped(getStrategyName(strategy), getParameters(strategy), isRemoteRun, null, reason);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printStrategyIsStopped(String strategyName, String parameters, boolean isRemoteRun, Date date, String reason)
/*     */   {
/* 237 */     if (date == null) {
/* 238 */       date = new Date();
/*     */     }
/*     */     
/* 241 */     StringBuilder message = new StringBuilder();
/* 242 */     message.append("Strategy \"").append(strategyName).append("\" is stopped at ").append(DATE_FORMATTER.format(new Date()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 247 */     if (isRemoteRun) {
/* 248 */       message.append(" on the remote server");
/*     */     } else {
/* 250 */       message.append(" on the local computer");
/*     */     }
/*     */     
/* 253 */     if (parameters.length() > 0) {
/* 254 */       message.append(" with parameters ").append(parameters);
/*     */     } else {
/* 256 */       message.append(" with no parameters");
/*     */     }
/* 258 */     if (!ObjectUtils.isNullOrEmpty(reason)) {
/* 259 */       message.append(". Reason: ").append(reason);
/*     */     }
/* 261 */     NotificationUtilsProvider.getNotificationUtils().postInfoMessage(message.toString(), false);
/*     */   }
/*     */   
/*     */   private static String getParameters(List<StrategyRunParameter> parameters) {
/* 265 */     StringBuilder result = new StringBuilder();
/* 266 */     if (parameters != null) {
/* 267 */       for (StrategyRunParameter strategyRunParameter : parameters) {
/* 268 */         String name = strategyRunParameter.getTitle();
/* 269 */         if ((name == null) || (name.isEmpty())) {
/* 270 */           name = strategyRunParameter.getName();
/*     */         }
/* 272 */         Variable var = strategyRunParameter.getVariable();
/* 273 */         boolean dateAsLong = strategyRunParameter.isDateAsLong();
/*     */         
/* 275 */         appendNameValue(result, name, var.getType(), var.getValue(), dateAsLong);
/*     */       }
/*     */     }
/* 278 */     if (result.toString().endsWith(", ")) {
/* 279 */       result.setLength(result.length() - ", ".length());
/*     */     }
/* 281 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getParameters(Object strategy)
/*     */   {
/* 289 */     StringBuilder result = new StringBuilder();
/*     */     
/* 291 */     Field[] fields = strategy.getClass().getFields();
/* 292 */     for (Field field : fields) {
/* 293 */       Configurable configurable = (Configurable)field.getAnnotation(Configurable.class);
/* 294 */       if (configurable != null) {
/*     */         try {
/* 296 */           String uiName = configurable.value();
/* 297 */           if ((uiName == null) || (uiName.isEmpty())) {
/* 298 */             uiName = field.getName();
/*     */           }
/* 300 */           Class<?> type = field.getType();
/*     */           
/*     */ 
/* 303 */           Object value = field.get(strategy);
/*     */           
/*     */ 
/* 306 */           Type genType = field.getGenericType();
/* 307 */           Class<?> typeParameter = null;
/* 308 */           if ((genType instanceof ParameterizedType)) {
/* 309 */             ParameterizedType pType = (ParameterizedType)genType;
/* 310 */             typeParameter = (Class)pType.getActualTypeArguments()[0];
/*     */           }
/*     */           
/* 313 */           if (ParameterUtils.isSupportedParameter(value, type, typeParameter))
/*     */           {
/*     */ 
/*     */ 
/* 317 */             appendNameValue(result, uiName, type, value, configurable.datetimeAsLong()); }
/*     */         } catch (Exception ex) {
/* 319 */           LOGGER.debug(ex.getMessage(), ex);
/*     */         }
/*     */       }
/*     */     }
/* 323 */     if (result.toString().endsWith(", ")) {
/* 324 */       result.setLength(result.length() - ", ".length());
/*     */     }
/* 326 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static void appendNameValue(StringBuilder builder, String uiName, Class<?> type, Object value, boolean dateAsLong) {
/*     */     String valueAsString;
/*     */     try {
/* 332 */       valueAsString = valueAsString(type, value, dateAsLong);
/*     */     } catch (RuntimeException ex) {
/* 334 */       String message = MessageFormat.format("Error getting value from field {0}.", new Object[] { uiName });
/* 335 */       LOGGER.debug(message, ex);
/* 336 */       valueAsString = "?";
/*     */     }
/* 338 */     builder.append("\"").append(uiName).append("\"=[").append(valueAsString).append("]");
/* 339 */     builder.append(", ");
/*     */   }
/*     */   
/*     */ 
/*     */   private static String valueAsString(Class<?> fieldType, Object value, boolean datetimeAsLong)
/*     */     throws RuntimeException
/*     */   {
/* 346 */     if (value == null)
/* 347 */       return "null";
/* 348 */     if (((Long.TYPE.equals(fieldType)) || (Long.class.equals(fieldType))) && (datetimeAsLong))
/* 349 */       return DATE_FORMATTER.format(new Date(((Long)value).longValue()));
/* 350 */     if (Calendar.class.isAssignableFrom(fieldType))
/* 351 */       return DATE_FORMATTER.format(((Calendar)value).getTime());
/* 352 */     if (Date.class.isAssignableFrom(fieldType))
/* 353 */       return DATE_FORMATTER.format((Date)value);
/* 354 */     if ((Double.TYPE.equals(fieldType)) || (Double.class.equals(fieldType))) {
/* 355 */       return DECIMAL_FORMATTER.format(value);
/*     */     }
/* 357 */     return value.toString();
/*     */   }
/*     */   
/*     */   private static String getStrategyName(Object strategy)
/*     */   {
/* 362 */     return strategy.getClass().getSimpleName();
/*     */   }
/*     */   
/*     */   private static String getStrategyName(StrategyWrapper wrapper) {
/* 366 */     String name = wrapper.getName();
/* 367 */     int index = name.lastIndexOf(".");
/* 368 */     if (index > 0) {
/* 369 */       return name.substring(0, index);
/*     */     }
/* 371 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\JFRunnableMessages.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */