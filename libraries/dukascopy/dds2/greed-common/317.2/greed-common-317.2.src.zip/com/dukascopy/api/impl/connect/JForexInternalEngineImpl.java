/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IEngine.OrderCommand;
/*     */ import com.dukascopy.api.IEngine.StrategyMode;
/*     */ import com.dukascopy.api.IOrder;
/*     */ import com.dukascopy.api.ISignal.Type;
/*     */ import com.dukascopy.api.ISignalsProcessor;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.impl.connect.validation.IOrderValidator;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class JForexInternalEngineImpl extends JForexEngineImpl
/*     */ {
/*     */   private ISignalsProcessor signalsProcessor;
/*     */   private IEngine.StrategyMode strategyMode;
/*     */   private JForexEngineImpl mainEngine;
/*  24 */   private Map<String, InternalPlatformOrder> internalStrategyOrders = new HashMap();
/*     */   
/*     */   public JForexInternalEngineImpl(JForexTaskManager taskManager, String accountName, boolean live, JForexEngineImpl mainEngine, IEngine.StrategyMode strategyMode) {
/*  27 */     super(taskManager, accountName, live);
/*  28 */     this.mainEngine = mainEngine;
/*  29 */     this.strategyMode = strategyMode;
/*  30 */     this.signalsProcessor = new SignalsProcessorImpl();
/*     */   }
/*     */   
/*     */   public synchronized IOrder getOrder(String label)
/*     */   {
/*  35 */     if (label == null) {
/*  36 */       throw new NullPointerException("Label is null");
/*     */     }
/*  38 */     return (IOrder)this.internalStrategyOrders.get(label);
/*     */   }
/*     */   
/*     */   public synchronized PlatformOrderImpl getOrderById(String orderId)
/*     */   {
/*  43 */     if (orderId == null) {
/*  44 */       throw new NullPointerException("OrderId is null");
/*     */     }
/*  46 */     for (PlatformOrderImpl order : this.internalStrategyOrders.values()) {
/*  47 */       if (order.getId().equals(orderId)) {
/*  48 */         return order;
/*     */       }
/*     */     }
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized List<IOrder> getOrders(Instrument instrument)
/*     */   {
/*  56 */     List<IOrder> orders = new ArrayList();
/*  57 */     for (IOrder order : this.internalStrategyOrders.values()) {
/*  58 */       if (order.getInstrument() == instrument) {
/*  59 */         orders.add(order);
/*     */       }
/*     */     }
/*     */     
/*  63 */     return orders;
/*     */   }
/*     */   
/*     */   public synchronized List<IOrder> getOrders()
/*     */   {
/*  68 */     return new ArrayList(this.internalStrategyOrders.values());
/*     */   }
/*     */   
/*     */   public com.dukascopy.api.IEngine.Type getType()
/*     */   {
/*  73 */     return this.mainEngine.getType();
/*     */   }
/*     */   
/*     */ 
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice, long goodTillTime, String comment)
/*     */     throws JFException
/*     */   {
/*  80 */     InternalPlatformOrder order = new InternalPlatformOrder(getTaskManager(), this);
/*  81 */     order.lastServerRequest = PlatformOrderImpl.ServerRequest.SUBMIT;
/*  82 */     order.label = label;
/*  83 */     order.requestedAmount = amount;
/*  84 */     order.setOriginalAmount(amount);
/*  85 */     order.comment = comment;
/*  86 */     order.slPrice = stopLossPrice;
/*  87 */     order.tpPrice = takeProfitPrice;
/*  88 */     order.openPrice = price;
/*  89 */     order.instrument = instrument;
/*  90 */     if (goodTillTime > 0L) {
/*  91 */       order.goodTillTime = goodTillTime;
/*     */     }
/*  93 */     order.orderCommand = orderCommand;
/*     */     
/*  95 */     createSignal(order, orderCommand.equals(IEngine.OrderCommand.BUY) ? ISignal.Type.ORDER_BUY : ISignal.Type.ORDER_SELL);
/*     */     
/*  97 */     if (this.strategyMode.equals(IEngine.StrategyMode.INDEPENDENT)) {
/*  98 */       return this.mainEngine.submitOrder(label, instrument, orderCommand, amount, price, slippage, stopLossPrice, takeProfitPrice, goodTillTime, comment);
/*     */     }
/*     */     
/* 101 */     return order;
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice, long goodTillTime)
/*     */     throws JFException
/*     */   {
/* 107 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage, stopLossPrice, takeProfitPrice, goodTillTime, null);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage, double stopLossPrice, double takeProfitPrice) throws JFException
/*     */   {
/* 112 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage, stopLossPrice, takeProfitPrice, 0L);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price, double slippage) throws JFException
/*     */   {
/* 117 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage, 0.0D, 0.0D);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount, double price) throws JFException
/*     */   {
/* 122 */     double slippage = 5.0D;
/*     */     
/* 124 */     if ((orderCommand != null) && ((orderCommand == IEngine.OrderCommand.BUYLIMIT) || (orderCommand == IEngine.OrderCommand.BUYLIMIT_BYBID) || (orderCommand == IEngine.OrderCommand.SELLLIMIT) || (orderCommand == IEngine.OrderCommand.SELLLIMIT_BYASK))) {
/* 125 */       slippage = 0.0D;
/*     */     }
/* 127 */     return submitOrder(label, instrument, orderCommand, amount, price, slippage);
/*     */   }
/*     */   
/*     */   public IOrder submitOrder(String label, Instrument instrument, IEngine.OrderCommand orderCommand, double amount) throws JFException
/*     */   {
/* 132 */     return submitOrder(label, instrument, orderCommand, amount, 0.0D);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 137 */     return "Patform engine for internal strategies";
/*     */   }
/*     */   
/*     */   public String getAccount()
/*     */   {
/* 142 */     return this.mainEngine.getAccount();
/*     */   }
/*     */   
/*     */   public void mergeOrders(IOrder... orders) throws JFException
/*     */   {
/* 147 */     mergeOrders(null, orders);
/*     */   }
/*     */   
/*     */   public IOrder mergeOrders(String label, IOrder... orders) throws JFException
/*     */   {
/* 152 */     Instrument instrument = null;
/* 153 */     for (IOrder order : orders) {
/* 154 */       if (instrument == null) {
/* 155 */         instrument = order.getInstrument();
/*     */       }
/* 157 */       if (order.getInstrument() != instrument) {
/* 158 */         throw new JFException("Cannot merge orders with instruments not equal");
/*     */       }
/*     */     }
/*     */     
/* 162 */     if (label == null) {
/* 163 */       label = StratUtils.generateLabel();
/*     */     } else {
/* 165 */       label = this.mainEngine.getOrderValidator().validateLabel(label);
/*     */     }
/*     */     
/* 168 */     PlatformOrderImpl order = null;
/* 169 */     List<IOrder> realOrders = getRealOrders(orders);
/*     */     
/* 171 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 172 */       order = (PlatformOrderImpl)this.mainEngine.mergeOrders(label, (IOrder[])realOrders.toArray());
/*     */     } else {
/* 174 */       order = new PlatformOrderImpl(getTaskManager());
/* 175 */       order.label = label;
/* 176 */       order.instrument = instrument;
/*     */     }
/*     */     
/* 179 */     createSignal(order, ISignal.Type.ORDER_MERGE, realOrders);
/*     */     
/* 181 */     return order;
/*     */   }
/*     */   
/*     */   public void closeOrders(IOrder... orders) throws JFException
/*     */   {
/* 186 */     createSignal(null, ISignal.Type.ORDER_CLOSE, Arrays.asList(orders));
/*     */     
/* 188 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 189 */       this.mainEngine.closeOrders(orders);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStopLoss(InternalPlatformOrder order, double price, OfferSide side, double trailingStep) throws JFException {
/* 194 */     IOrder realOrder = getRealOrder(order);
/* 195 */     createSignal(order, ISignal.Type.ORDER_MODIFY, realOrder);
/*     */     
/* 197 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 198 */       realOrder.setStopLossPrice(price, side, trailingStep);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTakeProfit(InternalPlatformOrder order, double price) throws JFException {
/* 203 */     IOrder realOrder = getRealOrder(order);
/* 204 */     createSignal(order, ISignal.Type.ORDER_MODIFY, realOrder);
/*     */     
/* 206 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 207 */       realOrder.setStopLossPrice(price);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRequestedAmount(InternalPlatformOrder order, double amount) throws JFException {
/* 212 */     IOrder realOrder = getRealOrder(order);
/* 213 */     createSignal(order, ISignal.Type.ORDER_MODIFY, realOrder);
/*     */     
/* 215 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 216 */       realOrder.setRequestedAmount(amount);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOpenPrice(InternalPlatformOrder order, double price) throws JFException {
/* 221 */     IOrder realOrder = getRealOrder(order);
/* 222 */     createSignal(order, ISignal.Type.ORDER_MODIFY, realOrder);
/*     */     
/* 224 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 225 */       realOrder.setOpenPrice(price);
/*     */     }
/*     */   }
/*     */   
/*     */   public void close(InternalPlatformOrder order, double amount, double price, double slippage) throws JFException {
/* 230 */     IOrder realOrder = getRealOrder(order);
/* 231 */     createSignal(realOrder, ISignal.Type.ORDER_CLOSE);
/*     */     
/* 233 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 234 */       realOrder.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setGoodTillTime(InternalPlatformOrder order, long goodTillTime) throws JFException {
/* 239 */     IOrder realOrder = getRealOrder(order);
/* 240 */     createSignal(order, ISignal.Type.ORDER_MODIFY, realOrder);
/*     */     
/* 242 */     if (this.strategyMode == IEngine.StrategyMode.INDEPENDENT) {
/* 243 */       realOrder.setGoodTillTime(goodTillTime);
/*     */     }
/*     */   }
/*     */   
/*     */   public void broadcast(String topic, String message) throws JFException
/*     */   {
/* 249 */     this.mainEngine.broadcast(topic, message);
/*     */   }
/*     */   
/*     */   public IEngine.StrategyMode getStrategyMode() {
/* 253 */     return this.strategyMode;
/*     */   }
/*     */   
/*     */   public void setStrategyMode(IEngine.StrategyMode strategyMode) {
/* 257 */     this.strategyMode = strategyMode;
/*     */   }
/*     */   
/*     */   public void createSignal(IOrder order, ISignal.Type type) {
/* 261 */     this.signalsProcessor.add(new SignalImpl(order, type));
/*     */   }
/*     */   
/*     */   public void createSignal(IOrder order, ISignal.Type type, IOrder oldOrder) {
/* 265 */     List<IOrder> oldOrders = new ArrayList();
/* 266 */     oldOrders.add(oldOrder);
/* 267 */     createSignal(order, type, oldOrders);
/*     */   }
/*     */   
/* 270 */   public void createSignal(IOrder order, ISignal.Type type, List<IOrder> oldOrders) { this.signalsProcessor.add(new SignalImpl(order, type, oldOrders)); }
/*     */   
/*     */   public ISignalsProcessor getSignalsProcessor()
/*     */   {
/* 274 */     return this.signalsProcessor;
/*     */   }
/*     */   
/*     */   public synchronized void setOrders(List<IOrder> orders) throws JFException {
/* 278 */     updateOrders(orders);
/*     */   }
/*     */   
/*     */   public synchronized void updateOrders(List<IOrder> orders) throws JFException {
/* 282 */     for (IOrder internalOrder : this.internalStrategyOrders.values()) {
/* 283 */       boolean isNotExist = true;
/* 284 */       for (IOrder order : orders) {
/* 285 */         if (order.getLabel().matches(internalOrder.getLabel())) {
/* 286 */           internalOrder = copyOrder((PlatformOrderImpl)order);
/* 287 */           isNotExist = false;
/*     */         }
/*     */       }
/* 290 */       if (isNotExist) {
/* 291 */         this.internalStrategyOrders.remove(internalOrder);
/*     */       }
/*     */     }
/* 294 */     for (IOrder order : orders) {
/* 295 */       if (this.internalStrategyOrders.get(order.getLabel()) == null) {
/* 296 */         InternalPlatformOrder newOrder = copyOrder((PlatformOrderImpl)order);
/* 297 */         this.internalStrategyOrders.put(newOrder.getLabel(), newOrder);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private InternalPlatformOrder copyOrder(PlatformOrderImpl oldOrder) throws JFException {
/* 303 */     InternalPlatformOrder newOrder = new InternalPlatformOrder(getTaskManager(), this, oldOrder);
/* 304 */     return newOrder;
/*     */   }
/*     */   
/*     */   private IOrder getRealOrder(IOrder order)
/*     */   {
/*     */     try {
/* 310 */       return this.mainEngine.getOrder(order.getLabel());
/*     */     } catch (JFException e) {}
/* 312 */     return null;
/*     */   }
/*     */   
/*     */   private List<IOrder> getRealOrders(IOrder... orders) throws JFException
/*     */   {
/* 317 */     List<IOrder> realOrders = new ArrayList();
/* 318 */     for (IOrder order : orders) {
/* 319 */       realOrders.add(this.mainEngine.getOrder(order.getLabel()));
/*     */     }
/* 321 */     return realOrders;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexInternalEngineImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */