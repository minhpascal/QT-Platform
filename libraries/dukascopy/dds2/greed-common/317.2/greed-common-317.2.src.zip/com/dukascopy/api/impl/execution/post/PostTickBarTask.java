/*    */ package com.dukascopy.api.impl.execution.post;
/*    */ 
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ import com.dukascopy.api.feed.ITickBar;
/*    */ import com.dukascopy.api.feed.util.TickBarFeedDescriptor;
/*    */ import com.dukascopy.api.impl.connect.IFeedTickBarListener;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostTickBarTask
/*    */   extends AbstractPostBarTask
/*    */ {
/* 22 */   private static final Logger LOGGER = LoggerFactory.getLogger(PostTickBarTask.class);
/*    */   
/*    */ 
/*    */   private final IFeedTickBarListener feedBarListener;
/*    */   
/*    */ 
/*    */   private final TickBarFeedDescriptor feedDescriptor;
/*    */   
/*    */ 
/*    */   private final ITickBar bar;
/*    */   
/*    */ 
/*    */   public PostTickBarTask(JForexTaskManager<?, ?, ?> taskManager, IJFRunnable<?> strategy, IStrategyExceptionHandler exceptionHandler, TickBarFeedDescriptor feedDescriptor, IFeedTickBarListener feedBarListener, ITickBar bar)
/*    */   {
/* 36 */     super(taskManager, strategy, exceptionHandler, feedDescriptor.getInstrument(), feedDescriptor.getOfferSide());
/* 37 */     this.feedDescriptor = feedDescriptor;
/* 38 */     this.feedBarListener = feedBarListener;
/* 39 */     this.bar = bar;
/*    */   }
/*    */   
/*    */   protected Logger getLogger()
/*    */   {
/* 44 */     return LOGGER;
/*    */   }
/*    */   
/*    */   protected void postData() throws Throwable
/*    */   {
/* 49 */     this.feedBarListener.onTickBar(this.feedDescriptor, this.bar);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\post\PostTickBarTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */