/*      */ package com.dukascopy.api.impl;
/*      */ 
/*      */ import com.dukascopy.api.DataType;
/*      */ import com.dukascopy.api.Filter;
/*      */ import com.dukascopy.api.IBar;
/*      */ import com.dukascopy.api.IDownloadableStrategy.ComponentType;
/*      */ import com.dukascopy.api.IIndicators;
/*      */ import com.dukascopy.api.IIndicators.AppliedPrice;
/*      */ import com.dukascopy.api.IIndicators.MaType;
/*      */ import com.dukascopy.api.ITick;
/*      */ import com.dukascopy.api.Instrument;
/*      */ import com.dukascopy.api.JFException;
/*      */ import com.dukascopy.api.OfferSide;
/*      */ import com.dukascopy.api.Period;
/*      */ import com.dukascopy.api.feed.FeedDescriptor;
/*      */ import com.dukascopy.api.feed.IFeedDescriptor;
/*      */ import com.dukascopy.api.feed.IPointAndFigure;
/*      */ import com.dukascopy.api.feed.IRangeBar;
/*      */ import com.dukascopy.api.feed.IRenkoBar;
/*      */ import com.dukascopy.api.feed.ITickBar;
/*      */ import com.dukascopy.api.impl.util.CompiledComponentDownloader;
/*      */ import com.dukascopy.api.indicators.IIndicator;
/*      */ import com.dukascopy.api.indicators.IIndicatorCalculator;
/*      */ import com.dukascopy.api.indicators.IndicatorInfo;
/*      */ import com.dukascopy.api.indicators.IndicatorResult;
/*      */ import com.dukascopy.api.indicators.InputParameterInfo;
/*      */ import com.dukascopy.api.indicators.InputParameterInfo.Type;
/*      */ import com.dukascopy.api.indicators.OutputParameterInfo;
/*      */ import com.dukascopy.api.util.DateUtils;
/*      */ import com.dukascopy.charts.data.datacache.CandleData;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*      */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*      */ import com.dukascopy.charts.data.datacache.IntraPeriodCandleData;
/*      */ import com.dukascopy.charts.data.datacache.IntraperiodCandlesGenerator;
/*      */ import com.dukascopy.charts.math.indicators.IndicatorsProvider;
/*      */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*      */ import com.dukascopy.dds2.greed.util.FilePathManager;
/*      */ import com.dukascopy.dds2.greed.util.IFilePathManager;
/*      */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*      */ import com.dukascopy.dds2.greed.util.IndicatorHelper;
/*      */ import com.dukascopy.dds2.greed.util.IndicatorHelper.PeriodParameterMapper;
/*      */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*      */ import java.io.File;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ 
/*      */ public class Indicators implements IIndicators
/*      */ {
/*   61 */   private static final Logger LOGGER = LoggerFactory.getLogger(Indicators.class);
/*      */   
/*      */   protected History history;
/*      */   
/*      */   protected INotificationUtils notificationUtils;
/*      */   
/*      */   private final Calculator calculator;
/*      */   
/*   69 */   protected final Map<String, IndicatorHolder> cachedIndicators = Collections.synchronizedMap(new LinkedHashMap(50, 0.75F, true) {
/*      */     protected boolean removeEldestEntry(Map.Entry<String, IndicatorHolder> eldest) {
/*   71 */       return size() > 15;
/*      */     }
/*   69 */   });
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   75 */   private final Map<String, Class<? extends IIndicator>> customIndicators = Collections.synchronizedMap(new LinkedHashMap());
/*      */   
/*      */   public Indicators(History history) {
/*   78 */     this(history, null);
/*      */   }
/*      */   
/*      */   public Indicators(History history, INotificationUtils notificationUtils) {
/*   82 */     this.history = history;
/*   83 */     this.notificationUtils = (notificationUtils == null ? NotificationUtilsProvider.getNotificationUtils() : notificationUtils);
/*   84 */     this.calculator = new Calculator(this);
/*      */   }
/*      */   
/*      */   public Collection<String> getAllNames() {
/*   88 */     Collection<String> result = new LinkedHashSet();
/*   89 */     if (!this.customIndicators.isEmpty()) {
/*   90 */       result.addAll(this.customIndicators.keySet());
/*      */     }
/*   92 */     result.addAll(IndicatorsProvider.getInstance().getAllNames());
/*   93 */     return result;
/*      */   }
/*      */   
/*      */   public Collection<String> getGroups() {
/*   97 */     Collection<String> result = new LinkedHashSet();
/*   98 */     if (!this.customIndicators.isEmpty()) {
/*   99 */       for (String indicatorName : this.customIndicators.keySet()) {
/*      */         try {
/*  101 */           IndicatorHolder cachedIndicator = getCachedIndicator(indicatorName);
/*  102 */           result.add(cachedIndicator.getIndicator().getIndicatorInfo().getName());
/*  103 */           cacheIndicator(indicatorName, cachedIndicator);
/*      */         } catch (Exception ex) {
/*  105 */           String msg = IndicatorMessages.getCachedIndicatorErrorMsg(indicatorName);
/*  106 */           LOGGER.error(msg, ex);
/*      */         }
/*      */       }
/*      */     }
/*  110 */     result.addAll(IndicatorsProvider.getInstance().getGroups());
/*  111 */     return result;
/*      */   }
/*      */   
/*      */   public IIndicator getIndicator(String name) {
/*      */     try {
/*  116 */       IIndicator indicator = getCustomIndicator(name);
/*  117 */       if (indicator != null) {
/*  118 */         return indicator;
/*      */       }
/*      */     } catch (Exception ex) {
/*  121 */       LOGGER.error("Error while getting custom indicator : " + name, ex);
/*      */     }
/*  123 */     IndicatorHolder holder = IndicatorsProvider.getInstance().getIndicatorHolder(name, this.history, this.notificationUtils, null);
/*  124 */     if (holder != null) {
/*  125 */       IndicatorsProvider.getInstance().saveIndicatorContext(holder);
/*  126 */       return holder.getIndicator();
/*      */     }
/*      */     
/*  129 */     return null;
/*      */   }
/*      */   
/*      */   public IIndicator getIndicatorByPath(String indicatorPath)
/*      */   {
/*  134 */     File indicatorFile = new File(indicatorPath);
/*  135 */     String indicatorName = null;
/*      */     
/*  137 */     if (indicatorFile.isAbsolute()) {
/*  138 */       if (indicatorFile.isFile()) {
/*      */         try {
/*  140 */           indicatorName = registerCustomIndicator(indicatorFile);
/*      */         } catch (JFException e) {
/*  142 */           LOGGER.error(e.getMessage(), e);
/*      */         }
/*      */       }
/*  145 */     } else if (indicatorFile.getName().equals(indicatorFile.getPath())) {
/*  146 */       File filesDirectory = FilePathManager.getInstance().getFilesForStrategiesDir();
/*  147 */       String indicatorFilename = indicatorFile.getName();
/*  148 */       String[] files = filesDirectory.list();
/*  149 */       for (String filename : files) {
/*  150 */         if (filename.equals(indicatorFilename)) {
/*      */           try {
/*  152 */             File indicator = new File(filesDirectory.getAbsolutePath() + FilePathManager.getInstance().getPathSeparator() + indicatorFilename);
/*  153 */             indicatorName = registerCustomIndicator(indicator);
/*      */           }
/*      */           catch (JFException e) {
/*  156 */             LOGGER.error(e.getMessage(), e);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  162 */     return indicatorName != null ? getIndicator(indicatorName) : null;
/*      */   }
/*      */   
/*      */   public Collection<String> getNames(String groupName) {
/*  166 */     Collection<String> result = new LinkedHashSet();
/*  167 */     if (!this.customIndicators.isEmpty()) {
/*  168 */       for (String indicatorName : this.customIndicators.keySet()) {
/*      */         try {
/*  170 */           IndicatorHolder cachedIndicator = getCachedIndicator(indicatorName);
/*  171 */           IndicatorInfo indicatorInfo = cachedIndicator.getIndicator().getIndicatorInfo();
/*  172 */           if (indicatorInfo.getGroupName().equalsIgnoreCase(groupName)) {
/*  173 */             result.add(indicatorInfo.getName());
/*      */           }
/*  175 */           cacheIndicator(indicatorName, cachedIndicator);
/*      */         } catch (Exception ex) {
/*  177 */           String msg = IndicatorMessages.getCachedIndicatorErrorMsg(indicatorName);
/*  178 */           LOGGER.error(msg, ex);
/*      */         }
/*      */       }
/*      */     }
/*  182 */     return IndicatorsProvider.getInstance().getNames(groupName);
/*      */   }
/*      */   
/*      */   public double acos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/*  186 */     return ((Double)function(instrument, period, side, "ACOS", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] acos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/*  190 */     return (double[])function(instrument, period, side, "ACOS", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] acos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  194 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ACOS", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] acos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/*  198 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ACOS", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ac(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, int shift) throws JFException {
/*  202 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, shift);
/*  203 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] ac(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, long from, long to) throws JFException {
/*  207 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, from, to);
/*  208 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] ac(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  212 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  213 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] ac(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, Filter filter, long from, long to) throws JFException {
/*  217 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, filter, from, to);
/*  218 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double ad(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  222 */     return ((Double)function(instrument, period, side, "AD", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ad(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  226 */     return (double[])function(instrument, period, side, "AD", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ad(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  230 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "AD", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ad(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  234 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "AD", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double add(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int shift) throws JFException {
/*  238 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "ADD", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] add(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, long from, long to) throws JFException {
/*  242 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "ADD", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] add(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  246 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "ADD", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] add(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, long from, long to) throws JFException {
/*  250 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "ADD", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double adOsc(Instrument instrument, Period period, OfferSide side, int fastPeriod, int slowPeriod, int shift) throws JFException {
/*  254 */     return ((Double)function(instrument, period, side, "ADOSC", null, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] adOsc(Instrument instrument, Period period, OfferSide side, int fastPeriod, int slowPeriod, long from, long to) throws JFException {
/*  258 */     return (double[])function(instrument, period, side, "ADOSC", null, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] adOsc(Instrument instrument, Period period, OfferSide side, int fastPeriod, int slowPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  262 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ADOSC", null, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] adOsc(Instrument instrument, Period period, OfferSide side, int fastPeriod, int slowPeriod, Filter filter, long from, long to) throws JFException {
/*  266 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ADOSC", null, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double adx(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  270 */     return ((Double)function(instrument, period, side, "ADX", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] adx(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  274 */     return (double[])function(instrument, period, side, "ADX", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] adx(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  278 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ADX", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] adx(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  282 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ADX", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double adxr(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  286 */     return ((Double)function(instrument, period, side, "ADXR", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] adxr(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  290 */     return (double[])function(instrument, period, side, "ADXR", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] adxr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  294 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ADXR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] adxr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  298 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ADXR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] alligator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, int shift) throws JFException {
/*  302 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ALLIGATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, shift);
/*  303 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] alligator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, Filter filter, long from, long to) throws JFException {
/*  307 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ALLIGATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, filter, from, to);
/*  308 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] alligator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  312 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ALLIGATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  313 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] alligator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, long from, long to) throws JFException {
/*  317 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ALLIGATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, from, to);
/*  318 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double apo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, int shift) throws JFException {
/*  322 */     return ((Double)function(instrument, period, side, "APO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] apo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/*  326 */     return (double[])function(instrument, period, side, "APO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] apo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  330 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "APO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] apo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/*  334 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "APO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] aroon(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  338 */     Object[] ret = function(instrument, period, side, "AROON", null, new Object[] { Integer.valueOf(timePeriod) }, shift);
/*  339 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] aroon(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  343 */     Object[] ret = function(instrument, period, side, "AROON", null, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/*  344 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] aroon(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  348 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AROON", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  349 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] aroon(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  353 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AROON", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/*  354 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double aroonOsc(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  358 */     return ((Double)function(instrument, period, side, "AROONOSC", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] aroonOsc(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  362 */     return (double[])function(instrument, period, side, "AROONOSC", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] aroonOsc(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  366 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "AROONOSC", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] aroonOsc(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  370 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "AROONOSC", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double asin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/*  374 */     return ((Double)function(instrument, period, side, "ASIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] asin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/*  378 */     return (double[])function(instrument, period, side, "ASIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] asin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  382 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ASIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] asin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/*  386 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ASIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double atan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/*  390 */     return ((Double)function(instrument, period, side, "ATAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] atan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/*  394 */     return (double[])function(instrument, period, side, "ATAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] atan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  398 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ATAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] atan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/*  402 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ATAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double atr(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  406 */     return ((Double)function(instrument, period, side, "ATR", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] atr(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  410 */     return (double[])function(instrument, period, side, "ATR", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] atr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  414 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ATR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] atr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  418 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ATR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double avgPrice(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  422 */     return ((Double)function(instrument, period, side, "AVGPRICE", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] avgPrice(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  426 */     return (double[])function(instrument, period, side, "AVGPRICE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] avgPrice(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  430 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "AVGPRICE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] avgPrice(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  434 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "AVGPRICE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] awesome(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fasterMaTimePeriod, IIndicators.MaType fasterMaType, int slowerMaTimePeriod, IIndicators.MaType slowerMaType, int shift) throws JFException {
/*  438 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AWESOME", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fasterMaTimePeriod), Integer.valueOf(fasterMaType.ordinal()), Integer.valueOf(slowerMaTimePeriod), Integer.valueOf(slowerMaType.ordinal()) }, shift);
/*  439 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] awesome(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fasterMaTimePeriod, IIndicators.MaType fasterMaType, int slowerMaTimePeriod, IIndicators.MaType slowerMaType, long from, long to) throws JFException {
/*  443 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AWESOME", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fasterMaTimePeriod), Integer.valueOf(fasterMaType.ordinal()), Integer.valueOf(slowerMaTimePeriod), Integer.valueOf(slowerMaType.ordinal()) }, from, to);
/*  444 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] awesome(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fasterMaTimePeriod, IIndicators.MaType fasterMaType, int slowerMaTimePeriod, IIndicators.MaType slowerMaType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  448 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AWESOME", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fasterMaTimePeriod), Integer.valueOf(fasterMaType.ordinal()), Integer.valueOf(slowerMaTimePeriod), Integer.valueOf(slowerMaType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  449 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] awesome(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fasterMaTimePeriod, IIndicators.MaType fasterMaType, int slowerMaTimePeriod, IIndicators.MaType slowerMaType, Filter filter, long from, long to) throws JFException {
/*  453 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "AWESOME", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fasterMaTimePeriod), Integer.valueOf(fasterMaType.ordinal()), Integer.valueOf(slowerMaTimePeriod), Integer.valueOf(slowerMaType.ordinal()) }, filter, from, to);
/*  454 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[] bbands(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDevUp, double nbDevDn, IIndicators.MaType maType, int shift) throws JFException {
/*  458 */     Object[] ret = function(instrument, period, side, "BBANDS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDevUp), Double.valueOf(nbDevDn), Integer.valueOf(maType.ordinal()) }, shift);
/*  459 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] bbands(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDevUp, double nbDevDn, IIndicators.MaType maType, long from, long to) throws JFException {
/*  463 */     Object[] ret = function(instrument, period, side, "BBANDS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDevUp), Double.valueOf(nbDevDn), Integer.valueOf(maType.ordinal()) }, from, to);
/*  464 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] bbands(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDevUp, double nbDevDn, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  468 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BBANDS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDevUp), Double.valueOf(nbDevDn), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  469 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] bbands(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDevUp, double nbDevDn, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/*  473 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BBANDS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDevUp), Double.valueOf(nbDevDn), Integer.valueOf(maType.ordinal()) }, filter, from, to);
/*  474 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double beta(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, int shift) throws JFException {
/*  478 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "BETA", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] beta(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, long from, long to) throws JFException {
/*  482 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "BETA", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] beta(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  486 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "BETA", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] beta(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  490 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "BETA", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double bear(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  494 */     return ((Double)function(instrument, period, side, "BEARP", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] bear(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  498 */     return (double[])function(instrument, period, side, "BEARP", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] bear(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  502 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BEARP", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] bear(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  506 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BEARP", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double bull(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  510 */     return ((Double)function(instrument, period, side, "BULLP", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] bull(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  514 */     return (double[])function(instrument, period, side, "BULLP", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] bull(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  518 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BULLP", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] bull(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  522 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BULLP", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] bwmfi(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  526 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BWMFI", null, new Object[0], shift);
/*  527 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] bwmfi(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  531 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BWMFI", null, new Object[0], from, to);
/*  532 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3] };
/*      */   }
/*      */   
/*      */   public double[][] bwmfi(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  536 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BWMFI", null, new Object[0], filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  537 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3] };
/*      */   }
/*      */   
/*      */   public double[][] bwmfi(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  541 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BWMFI", null, new Object[0], filter, from, to);
/*  542 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3] };
/*      */   }
/*      */   
/*      */   public double bop(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  546 */     return ((Double)function(instrument, period, side, "BOP", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] bop(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  550 */     return (double[])function(instrument, period, side, "BOP", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] bop(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  554 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BOP", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] bop(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  558 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BOP", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double butterworthFilter(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/*  562 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BUTTERWORTH", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift);
/*  563 */     return ((Double)ret[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] butterworthFilter(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/*  567 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BUTTERWORTH", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/*  568 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] butterworthFilter(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  572 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "BUTTERWORTH", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  573 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] butterworthFilter(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  577 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "BUTTERWORTH", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] camPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/*  582 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/*  583 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { mappedPeriod }, shift);
/*  584 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue(), ((Double)ret[7]).doubleValue(), ((Double)ret[8]).doubleValue(), ((Double)ret[9]).doubleValue(), ((Double)ret[10]).doubleValue() };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] camPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException
/*      */   {
/*  590 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/*  591 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { mappedPeriod }, from, to);
/*  592 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] camPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/*  598 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/*  599 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { mappedPeriod }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  600 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] camPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException
/*      */   {
/*  606 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/*  607 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { mappedPeriod }, filter, from, to);
/*  608 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10] };
/*      */   }
/*      */   
/*      */   public double[] camPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, int shift) throws JFException
/*      */   {
/*  613 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { timePeriod }, shift);
/*  614 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue(), ((Double)ret[7]).doubleValue(), ((Double)ret[8]).doubleValue(), ((Double)ret[9]).doubleValue(), ((Double)ret[10]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] camPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, long from, long to) throws JFException
/*      */   {
/*  619 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { timePeriod }, from, to);
/*  620 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10] };
/*      */   }
/*      */   
/*      */   public double[][] camPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/*  625 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { timePeriod }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*  626 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10] };
/*      */   }
/*      */   
/*      */   public double[][] camPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, long from, long to) throws JFException
/*      */   {
/*  631 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "CAMPIVOT", null, new Object[] { timePeriod }, filter, from, to);
/*  632 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10] };
/*      */   }
/*      */   
/*      */   public double cci(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException
/*      */   {
/*  637 */     return ((Double)function(instrument, period, side, "CCI", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] cci(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/*  641 */     return (double[])function(instrument, period, side, "CCI", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] cci(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  645 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CCI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] cci(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/*  649 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CCI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl2Crows(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  653 */     return ((Integer)function(instrument, period, side, "CDL2CROWS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl2Crows(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  657 */     return (int[])function(instrument, period, side, "CDL2CROWS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl2Crows(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  661 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL2CROWS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl2Crows(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  665 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL2CROWS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl3BlackCrows(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  669 */     return ((Integer)function(instrument, period, side, "CDL3BLACKCROWS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl3BlackCrows(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  673 */     return (int[])function(instrument, period, side, "CDL3BLACKCROWS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3BlackCrows(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  677 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3BLACKCROWS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3BlackCrows(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  681 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3BLACKCROWS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl3Inside(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  685 */     return ((Integer)function(instrument, period, side, "CDL3INSIDE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl3Inside(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  689 */     return (int[])function(instrument, period, side, "CDL3INSIDE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3Inside(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  693 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3INSIDE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3Inside(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  697 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3INSIDE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl3LineStrike(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  701 */     return ((Integer)function(instrument, period, side, "CDL3LINESTRIKE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl3LineStrike(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  705 */     return (int[])function(instrument, period, side, "CDL3LINESTRIKE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3LineStrike(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  709 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3LINESTRIKE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3LineStrike(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  713 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3LINESTRIKE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl3Outside(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  717 */     return ((Integer)function(instrument, period, side, "CDL3OUTSIDE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl3Outside(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  721 */     return (int[])function(instrument, period, side, "CDL3OUTSIDE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3Outside(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  725 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3OUTSIDE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3Outside(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  729 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3OUTSIDE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl3StarsInSouth(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  733 */     return ((Integer)function(instrument, period, side, "CDL3STARSINSOUTH", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl3StarsInSouth(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  737 */     return (int[])function(instrument, period, side, "CDL3STARSINSOUTH", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3StarsInSouth(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  741 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3STARSINSOUTH", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3StarsInSouth(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  745 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3STARSINSOUTH", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdl3WhiteSoldiers(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  749 */     return ((Integer)function(instrument, period, side, "CDL3WHITESOLDIERS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdl3WhiteSoldiers(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  753 */     return (int[])function(instrument, period, side, "CDL3WHITESOLDIERS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3WhiteSoldiers(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  757 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3WHITESOLDIERS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdl3WhiteSoldiers(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  761 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDL3WHITESOLDIERS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlAbandonedBaby(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/*  765 */     return ((Integer)function(instrument, period, side, "CDLABANDONEDBABY", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlAbandonedBaby(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/*  769 */     return (int[])function(instrument, period, side, "CDLABANDONEDBABY", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlAbandonedBaby(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  773 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLABANDONEDBABY", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlAbandonedBaby(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/*  777 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLABANDONEDBABY", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlAdvanceBlock(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  781 */     return ((Integer)function(instrument, period, side, "CDLADVANCEBLOCK", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlAdvanceBlock(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  785 */     return (int[])function(instrument, period, side, "CDLADVANCEBLOCK", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlAdvanceBlock(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  789 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLADVANCEBLOCK", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlAdvanceBlock(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  793 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLADVANCEBLOCK", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlBeltHold(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  797 */     return ((Integer)function(instrument, period, side, "CDLBELTHOLD", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlBeltHold(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  801 */     return (int[])function(instrument, period, side, "CDLBELTHOLD", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlBeltHold(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  805 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLBELTHOLD", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlBeltHold(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  809 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLBELTHOLD", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlBreakAway(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  813 */     return ((Integer)function(instrument, period, side, "CDLBREAKAWAY", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlBreakAway(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  817 */     return (int[])function(instrument, period, side, "CDLBREAKAWAY", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlBreakAway(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  821 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLBREAKAWAY", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlBreakAway(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  825 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLBREAKAWAY", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlClosingMarubozu(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  829 */     return ((Integer)function(instrument, period, side, "CDLCLOSINGMARUBOZU", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlClosingMarubozu(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  833 */     return (int[])function(instrument, period, side, "CDLCLOSINGMARUBOZU", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlClosingMarubozu(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  837 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLCLOSINGMARUBOZU", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlClosingMarubozu(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  841 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLCLOSINGMARUBOZU", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlConcealBabySwall(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  845 */     return ((Integer)function(instrument, period, side, "CDLCONCEALBABYSWALL", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlConcealBabySwall(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  849 */     return (int[])function(instrument, period, side, "CDLCONCEALBABYSWALL", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlConcealBabySwall(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  853 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLCONCEALBABYSWALL", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlConcealBabySwall(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  857 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLCONCEALBABYSWALL", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlCounterattack(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  861 */     return ((Integer)function(instrument, period, side, "CDLCOUNTERATTACK", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlCounterattack(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  865 */     return (int[])function(instrument, period, side, "CDLCOUNTERATTACK", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlCounterattack(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  869 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLCOUNTERATTACK", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlCounterattack(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  873 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLCOUNTERATTACK", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlDarkCloudCover(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/*  877 */     return ((Integer)function(instrument, period, side, "CDLDARKCLOUDCOVER", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlDarkCloudCover(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/*  881 */     return (int[])function(instrument, period, side, "CDLDARKCLOUDCOVER", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDarkCloudCover(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  885 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDARKCLOUDCOVER", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDarkCloudCover(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/*  889 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDARKCLOUDCOVER", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlDoji(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  893 */     return ((Integer)function(instrument, period, side, "CDLDOJI", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlDoji(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  897 */     return (int[])function(instrument, period, side, "CDLDOJI", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDoji(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  901 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDOJI", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDoji(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  905 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDOJI", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlDojiStar(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  909 */     return ((Integer)function(instrument, period, side, "CDLDOJISTAR", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlDojiStar(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  913 */     return (int[])function(instrument, period, side, "CDLDOJISTAR", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDojiStar(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  917 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDOJISTAR", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDojiStar(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  921 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDOJISTAR", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlDragonflyDoji(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  925 */     return ((Integer)function(instrument, period, side, "CDLDRAGONFLYDOJI", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlDragonflyDoji(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  929 */     return (int[])function(instrument, period, side, "CDLDRAGONFLYDOJI", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDragonflyDoji(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  933 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDRAGONFLYDOJI", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlDragonflyDoji(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  937 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLDRAGONFLYDOJI", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlEngulfing(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  941 */     return ((Integer)function(instrument, period, side, "CDLENGULFING", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlEngulfing(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  945 */     return (int[])function(instrument, period, side, "CDLENGULFING", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlEngulfing(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  949 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLENGULFING", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlEngulfing(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/*  953 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLENGULFING", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlEveningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/*  957 */     return ((Integer)function(instrument, period, side, "CDLEVENINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlEveningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/*  961 */     return (int[])function(instrument, period, side, "CDLEVENINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlEveningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  965 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLEVENINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlEveningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/*  969 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLEVENINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlEveningStar(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/*  973 */     return ((Integer)function(instrument, period, side, "CDLEVENINGSTAR", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlEveningStar(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/*  977 */     return (int[])function(instrument, period, side, "CDLEVENINGSTAR", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlEveningStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  981 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLEVENINGSTAR", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlEveningStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/*  985 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLEVENINGSTAR", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlGapSideSideWhite(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/*  989 */     return ((Integer)function(instrument, period, side, "CDLGAPSIDESIDEWHITE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlGapSideSideWhite(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/*  993 */     return (int[])function(instrument, period, side, "CDLGAPSIDESIDEWHITE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlGapSideSideWhite(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/*  997 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLGAPSIDESIDEWHITE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlGapSideSideWhite(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1001 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLGAPSIDESIDEWHITE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlGravestoneDoji(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1005 */     return ((Integer)function(instrument, period, side, "CDLGRAVESTONEDOJI", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlGravestoneDoji(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1009 */     return (int[])function(instrument, period, side, "CDLGRAVESTONEDOJI", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlGravestoneDoji(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1013 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLGRAVESTONEDOJI", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlGravestoneDoji(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1017 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLGRAVESTONEDOJI", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHammer(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1021 */     return ((Integer)function(instrument, period, side, "CDLHAMMER", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHammer(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1025 */     return (int[])function(instrument, period, side, "CDLHAMMER", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHammer(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1029 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHAMMER", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHammer(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1033 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHAMMER", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHangingMan(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1037 */     return ((Integer)function(instrument, period, side, "CDLHANGINGMAN", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHangingMan(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1041 */     return (int[])function(instrument, period, side, "CDLHANGINGMAN", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHangingMan(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1045 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHANGINGMAN", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHangingMan(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1049 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHANGINGMAN", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHarami(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1053 */     return ((Integer)function(instrument, period, side, "CDLHARAMI", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHarami(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1057 */     return (int[])function(instrument, period, side, "CDLHARAMI", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHarami(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1061 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHARAMI", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHarami(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1065 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHARAMI", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHaramiCross(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1069 */     return ((Integer)function(instrument, period, side, "CDLHARAMICROSS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHaramiCross(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1073 */     return (int[])function(instrument, period, side, "CDLHARAMICROSS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHaramiCross(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1077 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHARAMICROSS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHaramiCross(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1081 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHARAMICROSS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHighWave(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1085 */     return ((Integer)function(instrument, period, side, "CDLHIGHWAVE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHighWave(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1089 */     return (int[])function(instrument, period, side, "CDLHIGHWAVE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHighWave(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1093 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHIGHWAVE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHighWave(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1097 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHIGHWAVE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHikkake(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1101 */     return ((Integer)function(instrument, period, side, "CDLHIKKAKE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHikkake(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1105 */     return (int[])function(instrument, period, side, "CDLHIKKAKE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHikkake(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1109 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHIKKAKE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHikkake(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1113 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHIKKAKE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHikkakeMod(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1117 */     return ((Integer)function(instrument, period, side, "CDLHIKKAKEMOD", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHikkakeMod(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1121 */     return (int[])function(instrument, period, side, "CDLHIKKAKEMOD", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHikkakeMod(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1125 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHIKKAKEMOD", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHikkakeMod(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1129 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHIKKAKEMOD", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlHomingPigeon(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1133 */     return ((Integer)function(instrument, period, side, "CDLHOMINGPIGEON", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlHomingPigeon(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1137 */     return (int[])function(instrument, period, side, "CDLHOMINGPIGEON", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHomingPigeon(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1141 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHOMINGPIGEON", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlHomingPigeon(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1145 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLHOMINGPIGEON", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlIdentical3Crows(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1149 */     return ((Integer)function(instrument, period, side, "CDLIDENTICAL3CROWS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlIdentical3Crows(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1153 */     return (int[])function(instrument, period, side, "CDLIDENTICAL3CROWS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlIdentical3Crows(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1157 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLIDENTICAL3CROWS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlIdentical3Crows(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1161 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLIDENTICAL3CROWS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlInNeck(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1165 */     return ((Integer)function(instrument, period, side, "CDLINNECK", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlInNeck(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1169 */     return (int[])function(instrument, period, side, "CDLINNECK", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlInNeck(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1173 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLINNECK", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlInNeck(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1177 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLINNECK", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlInvertedHammer(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1181 */     return ((Integer)function(instrument, period, side, "CDLINVERTEDHAMMER", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlInvertedHammer(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1185 */     return (int[])function(instrument, period, side, "CDLINVERTEDHAMMER", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlInvertedHammer(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1189 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLINVERTEDHAMMER", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlInvertedHammer(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1193 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLINVERTEDHAMMER", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlKicking(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1197 */     return ((Integer)function(instrument, period, side, "CDLKICKING", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlKicking(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1201 */     return (int[])function(instrument, period, side, "CDLKICKING", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlKicking(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1205 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLKICKING", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlKicking(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1209 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLKICKING", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlKickingByLength(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1213 */     return ((Integer)function(instrument, period, side, "CDLKICKINGBYLENGTH", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlKickingByLength(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1217 */     return (int[])function(instrument, period, side, "CDLKICKINGBYLENGTH", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlKickingByLength(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1221 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLKICKINGBYLENGTH", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlKickingByLength(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1225 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLKICKINGBYLENGTH", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlLadderBotton(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1229 */     return ((Integer)function(instrument, period, side, "CDLLADDERBOTTOM", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlLadderBotton(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1233 */     return (int[])function(instrument, period, side, "CDLLADDERBOTTOM", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLadderBotton(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1237 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLADDERBOTTOM", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLadderBotton(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1241 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLADDERBOTTOM", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlLadderBottom(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1245 */     return ((Integer)function(instrument, period, side, "CDLLADDERBOTTOM", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlLadderBottom(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1249 */     return (int[])function(instrument, period, side, "CDLLADDERBOTTOM", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLadderBottom(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1253 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLADDERBOTTOM", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLadderBottom(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1257 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLADDERBOTTOM", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlLongLeggedDoji(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1261 */     return ((Integer)function(instrument, period, side, "CDLLONGLEGGEDDOJI", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlLongLeggedDoji(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1265 */     return (int[])function(instrument, period, side, "CDLLONGLEGGEDDOJI", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLongLeggedDoji(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1269 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLONGLEGGEDDOJI", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLongLeggedDoji(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1273 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLONGLEGGEDDOJI", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlLongLine(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1277 */     return ((Integer)function(instrument, period, side, "CDLLONGLINE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlLongLine(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1281 */     return (int[])function(instrument, period, side, "CDLLONGLINE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLongLine(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1285 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLONGLINE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlLongLine(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1289 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLLONGLINE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlMarubozu(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1293 */     return ((Integer)function(instrument, period, side, "CDLMARUBOZU", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlMarubozu(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1297 */     return (int[])function(instrument, period, side, "CDLMARUBOZU", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMarubozu(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1301 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMARUBOZU", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMarubozu(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1305 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMARUBOZU", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlMatchingLow(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1309 */     return ((Integer)function(instrument, period, side, "CDLMATCHINGLOW", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlMatchingLow(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1313 */     return (int[])function(instrument, period, side, "CDLMATCHINGLOW", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMatchingLow(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1317 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMATCHINGLOW", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMatchingLow(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1321 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMATCHINGLOW", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlMathold(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/* 1325 */     return ((Integer)function(instrument, period, side, "CDLMATHOLD", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlMathold(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/* 1329 */     return (int[])function(instrument, period, side, "CDLMATHOLD", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMathold(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1333 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMATHOLD", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMathold(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/* 1337 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMATHOLD", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlMorningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/* 1341 */     return ((Integer)function(instrument, period, side, "CDLMORNINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlMorningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/* 1345 */     return (int[])function(instrument, period, side, "CDLMORNINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMorningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1349 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMORNINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMorningDojiStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/* 1353 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMORNINGDOJISTAR", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlMorningStar(Instrument instrument, Period period, OfferSide side, double penetration, int shift) throws JFException {
/* 1357 */     return ((Integer)function(instrument, period, side, "CDLMORNINGSTAR", null, new Object[] { Double.valueOf(penetration) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlMorningStar(Instrument instrument, Period period, OfferSide side, double penetration, long from, long to) throws JFException {
/* 1361 */     return (int[])function(instrument, period, side, "CDLMORNINGSTAR", null, new Object[] { Double.valueOf(penetration) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMorningStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1365 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMORNINGSTAR", null, new Object[] { Double.valueOf(penetration) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlMorningStar(Instrument instrument, Period period, OfferSide side, double penetration, Filter filter, long from, long to) throws JFException {
/* 1369 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLMORNINGSTAR", null, new Object[] { Double.valueOf(penetration) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlOnNeck(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1373 */     return ((Integer)function(instrument, period, side, "CDLONNECK", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlOnNeck(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1377 */     return (int[])function(instrument, period, side, "CDLONNECK", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlOnNeck(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1381 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLONNECK", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlOnNeck(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1385 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLONNECK", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlPiercing(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1389 */     return ((Integer)function(instrument, period, side, "CDLPIERCING", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlPiercing(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1393 */     return (int[])function(instrument, period, side, "CDLPIERCING", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlPiercing(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1397 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLPIERCING", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlPiercing(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1401 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLPIERCING", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlRickshawMan(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1405 */     return ((Integer)function(instrument, period, side, "CDLRICKSHAWMAN", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlRickshawMan(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1409 */     return (int[])function(instrument, period, side, "CDLRICKSHAWMAN", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlRickshawMan(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1413 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLRICKSHAWMAN", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlRickshawMan(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1417 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLRICKSHAWMAN", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlRiseFall3Methods(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1421 */     return ((Integer)function(instrument, period, side, "CDLRISEFALL3METHODS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlRiseFall3Methods(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1425 */     return (int[])function(instrument, period, side, "CDLRISEFALL3METHODS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlRiseFall3Methods(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1429 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLRISEFALL3METHODS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlRiseFall3Methods(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1433 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLRISEFALL3METHODS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlSeparatingLines(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1437 */     return ((Integer)function(instrument, period, side, "CDLSEPARATINGLINES", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlSeparatingLines(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1441 */     return (int[])function(instrument, period, side, "CDLSEPARATINGLINES", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlSeparatingLines(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1445 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSEPARATINGLINES", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlSeparatingLines(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1449 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSEPARATINGLINES", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlShootingStar(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1453 */     return ((Integer)function(instrument, period, side, "CDLSHOOTINGSTAR", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlShootingStar(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1457 */     return (int[])function(instrument, period, side, "CDLSHOOTINGSTAR", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlShootingStar(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1461 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSHOOTINGSTAR", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlShootingStar(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1465 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSHOOTINGSTAR", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlShortLine(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1469 */     return ((Integer)function(instrument, period, side, "CDLSHORTLINE", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlShortLine(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1473 */     return (int[])function(instrument, period, side, "CDLSHORTLINE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlShortLine(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1477 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSHORTLINE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlShortLine(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1481 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSHORTLINE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlSpinningTop(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1485 */     return ((Integer)function(instrument, period, side, "CDLSPINNINGTOP", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlSpinningTop(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1489 */     return (int[])function(instrument, period, side, "CDLSPINNINGTOP", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlSpinningTop(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1493 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSPINNINGTOP", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlSpinningTop(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1497 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSPINNINGTOP", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlStalledPattern(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1501 */     return ((Integer)function(instrument, period, side, "CDLSTALLEDPATTERN", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlStalledPattern(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1505 */     return (int[])function(instrument, period, side, "CDLSTALLEDPATTERN", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlStalledPattern(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1509 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSTALLEDPATTERN", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlStalledPattern(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1513 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSTALLEDPATTERN", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlStickSandwich(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1517 */     return ((Integer)function(instrument, period, side, "CDLSTICKSANDWICH", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlStickSandwich(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1521 */     return (int[])function(instrument, period, side, "CDLSTICKSANDWICH", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlStickSandwich(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1525 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSTICKSANDWICH", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlStickSandwich(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1529 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLSTICKSANDWICH", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlTakuri(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1533 */     return ((Integer)function(instrument, period, side, "CDLTAKURI", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlTakuri(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1537 */     return (int[])function(instrument, period, side, "CDLTAKURI", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlTakuri(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1541 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTAKURI", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlTakuri(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1545 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTAKURI", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlTasukiGap(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1549 */     return ((Integer)function(instrument, period, side, "CDLTASUKIGAP", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlTasukiGap(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1553 */     return (int[])function(instrument, period, side, "CDLTASUKIGAP", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlTasukiGap(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1557 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTASUKIGAP", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlTasukiGap(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1561 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTASUKIGAP", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlThrusting(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1565 */     return ((Integer)function(instrument, period, side, "CDLTHRUSTING", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlThrusting(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1569 */     return (int[])function(instrument, period, side, "CDLTHRUSTING", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlThrusting(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1573 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTHRUSTING", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlThrusting(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1577 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTHRUSTING", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlTristar(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1581 */     return ((Integer)function(instrument, period, side, "CDLTRISTAR", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlTristar(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1585 */     return (int[])function(instrument, period, side, "CDLTRISTAR", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlTristar(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1589 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTRISTAR", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlTristar(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1593 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLTRISTAR", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlUnique3River(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1597 */     return ((Integer)function(instrument, period, side, "CDLUNIQUE3RIVER", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlUnique3River(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1601 */     return (int[])function(instrument, period, side, "CDLUNIQUE3RIVER", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlUnique3River(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1605 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLUNIQUE3RIVER", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlUnique3River(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1609 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLUNIQUE3RIVER", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlUpsideGap2Crows(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1613 */     return ((Integer)function(instrument, period, side, "CDLUPSIDEGAP2CROWS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlUpsideGap2Crows(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1617 */     return (int[])function(instrument, period, side, "CDLUPSIDEGAP2CROWS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlUpsideGap2Crows(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1621 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLUPSIDEGAP2CROWS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlUpsideGap2Crows(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1625 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLUPSIDEGAP2CROWS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int cdlXsideGap3Methods(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 1629 */     return ((Integer)function(instrument, period, side, "CDLXSIDEGAP3METHODS", null, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] cdlXsideGap3Methods(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 1633 */     return (int[])function(instrument, period, side, "CDLXSIDEGAP3METHODS", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlXsideGap3Methods(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1637 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLXSIDEGAP3METHODS", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] cdlXsideGap3Methods(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 1641 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CDLXSIDEGAP3METHODS", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ceil(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 1645 */     return ((Double)function(instrument, period, side, "CEIL", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ceil(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 1649 */     return (double[])function(instrument, period, side, "CEIL", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ceil(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1653 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CEIL", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ceil(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 1657 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CEIL", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double cmo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 1661 */     return ((Double)function(instrument, period, side, "CMO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] cmo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 1665 */     return (double[])function(instrument, period, side, "CMO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] cmo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1669 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CMO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] cmo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1673 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "CMO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] cog(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int smoothPeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 1677 */     Object[] res = function(instrument, period, side, "COG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(smoothPeriod), Integer.valueOf(maType.ordinal()) }, shift);
/* 1678 */     return new double[] { ((Double)res[0]).doubleValue(), ((Double)res[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] cog(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int smoothPeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 1682 */     Object[] res = function(instrument, period, side, "COG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(smoothPeriod), Integer.valueOf(maType.ordinal()) }, from, to);
/* 1683 */     return new double[][] { (double[])(double[])res[0], (double[])(double[])res[1] };
/*      */   }
/*      */   
/*      */   public double[][] cog(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int smoothPeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1687 */     Object[] res = calculateIndicator(instrument, period, new OfferSide[] { side }, "COG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(smoothPeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1688 */     return new double[][] { (double[])(double[])res[0], (double[])(double[])res[1] };
/*      */   }
/*      */   
/*      */   public double[][] cog(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int smoothPeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/* 1692 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "COG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(smoothPeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to);
/* 1693 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double correl(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, int shift) throws JFException {
/* 1697 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "CORREL", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] correl(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, long from, long to) throws JFException {
/* 1701 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "CORREL", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] correl(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1705 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "CORREL", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] correl(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1709 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "CORREL", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double cos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 1713 */     return ((Double)function(instrument, period, side, "COS", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] cos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 1717 */     return (double[])function(instrument, period, side, "COS", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] cos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1721 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "COS", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] cos(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 1725 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "COS", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double cosh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 1729 */     return ((Double)function(instrument, period, side, "COSH", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] cosh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 1733 */     return (double[])function(instrument, period, side, "COSH", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] cosh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1737 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "COSH", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] cosh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 1741 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "COSH", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double dema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 1745 */     return ((Double)function(instrument, period, side, "DEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] dema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 1749 */     return (double[])function(instrument, period, side, "DEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] dema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1753 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "DEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] dema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1757 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "DEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double div(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int shift) throws JFException
/*      */   {
/* 1762 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "DIV", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] div(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, long from, long to) throws JFException
/*      */   {
/* 1767 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "DIV", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] div(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 1772 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "DIV", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] div(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, long from, long to) throws JFException
/*      */   {
/* 1777 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "DIV", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] dmi(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 1781 */     Object[] res = function(instrument, period, side, "DMI", null, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 1782 */     return new double[] { ((Double)res[0]).doubleValue(), ((Double)res[1]).doubleValue(), ((Double)res[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] dmi(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 1786 */     Object[] res = function(instrument, period, side, "DMI", null, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 1787 */     return new double[][] { (double[])(double[])res[0], (double[])(double[])res[1], (double[])(double[])res[2] };
/*      */   }
/*      */   
/*      */   public double[][] dmi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1791 */     Object[] res = calculateIndicator(instrument, period, new OfferSide[] { side }, "DMI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1792 */     return new double[][] { (double[])(double[])res[0], (double[])(double[])res[1], (double[])(double[])res[2] };
/*      */   }
/*      */   
/*      */   public double[][] dmi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1796 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "DMI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 1797 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[] donchian(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 1801 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "DONCHIANCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 1802 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] donchian(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 1806 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "DONCHIANCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 1807 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] donchian(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1811 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "DONCHIANCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1812 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] donchian(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1816 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "DONCHIANCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 1817 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double dx(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 1821 */     return ((Double)function(instrument, period, side, "DX", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] dx(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 1825 */     return (double[])function(instrument, period, side, "DX", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] dx(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1829 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "DX", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] dx(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1833 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "DX", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 1837 */     return ((Double)function(instrument, period, side, "EMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 1841 */     return (double[])function(instrument, period, side, "EMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1845 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "EMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1849 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "EMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] emaEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, int shift) throws JFException {
/* 1853 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "EMAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, shift);
/* 1854 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] emaEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, long from, long to) throws JFException {
/* 1858 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "EMAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, from, to);
/* 1859 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] emaEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1863 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "EMAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1864 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] emaEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, Filter filter, long from, long to) throws JFException {
/* 1868 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "EMAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, filter, from, to);
/* 1869 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double exp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 1873 */     return ((Double)function(instrument, period, side, "EXP", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] exp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 1877 */     return (double[])function(instrument, period, side, "EXP", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] exp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 1882 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "EXP", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] exp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 1886 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "EXP", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double floor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 1890 */     return ((Double)function(instrument, period, side, "FLOOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] floor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 1894 */     return (double[])function(instrument, period, side, "FLOOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] floor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 1899 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "FLOOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] floor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 1903 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "FLOOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double force(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 1907 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FORCEI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, shift);
/* 1908 */     return ((Double)ret[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] force(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 1912 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FORCEI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, from, to);
/* 1913 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */ 
/*      */   public double[] force(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter)
/*      */     throws JFException
/*      */   {
/* 1920 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FORCEI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1921 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] force(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/* 1925 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FORCEI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] fractal(Instrument instrument, Period period, OfferSide side, int barsOnSides, int shift) throws JFException {
/* 1929 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTAL", null, new Object[] { Integer.valueOf(barsOnSides) }, shift);
/* 1930 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] fractal(Instrument instrument, Period period, OfferSide side, int barsOnSides, long from, long to) throws JFException {
/* 1934 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTAL", null, new Object[] { Integer.valueOf(barsOnSides) }, from, to);
/* 1935 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] fractal(Instrument instrument, Period period, OfferSide side, int barsOnSides, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1939 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTAL", null, new Object[] { Integer.valueOf(barsOnSides) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1940 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] fractal(Instrument instrument, Period period, OfferSide side, int barsOnSides, Filter filter, long from, long to) throws JFException {
/* 1944 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTAL", null, new Object[] { Integer.valueOf(barsOnSides) }, filter, from, to);
/* 1945 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[] fractalLines(Instrument instrument, Period period, OfferSide side, int barsOnSides, int shift) throws JFException {
/* 1949 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTALLINES", null, new Object[] { Integer.valueOf(barsOnSides) }, shift);
/* 1950 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] fractalLines(Instrument instrument, Period period, OfferSide side, int barsOnSides, long from, long to) throws JFException {
/* 1954 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTALLINES", null, new Object[] { Integer.valueOf(barsOnSides) }, from, to);
/* 1955 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] fractalLines(Instrument instrument, Period period, OfferSide side, int barsOnSides, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1959 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTALLINES", null, new Object[] { Integer.valueOf(barsOnSides) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1960 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] fractalLines(Instrument instrument, Period period, OfferSide side, int barsOnSides, Filter filter, long from, long to) throws JFException {
/* 1964 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "FRACTALLINES", null, new Object[] { Integer.valueOf(barsOnSides) }, filter, from, to);
/* 1965 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] fibPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 1970 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 1971 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { mappedPeriod }, shift);
/* 1972 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue() };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] fibPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 1977 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 1978 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { mappedPeriod }, from, to);
/* 1979 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] fibPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 1984 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 1985 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { mappedPeriod }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 1986 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] fibPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 1991 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 1992 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { mappedPeriod }, filter, from, to);
/* 1993 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[] fibPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, int shift) throws JFException {
/* 1997 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { timePeriod }, shift);
/* 1998 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] fibPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, long from, long to) throws JFException {
/* 2002 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { timePeriod }, from, to);
/* 2003 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[][] fibPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2007 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { timePeriod }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2008 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[][] fibPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, long from, long to) throws JFException {
/* 2012 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "FIBPIVOT", null, new Object[] { timePeriod }, filter, from, to);
/* 2013 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[] gator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, int shift) throws JFException {
/* 2017 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "GATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, shift);
/* 2018 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] gator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, long from, long to) throws JFException {
/* 2022 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "GATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, from, to);
/* 2023 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] gator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2027 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "GATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2028 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] gator(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod, Filter filter, long from, long to) throws JFException {
/* 2032 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "GATOR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) }, filter, from, to);
/* 2033 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[] heikenAshi(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 2037 */     Object ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, shift)[0];
/* 2038 */     return (double[])ret;
/*      */   }
/*      */   
/*      */   public double[][] heikenAshi(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 2042 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, from, to);
/* 2043 */     double[][] retD = new double[((Object[])ret[0]).length][];
/* 2044 */     System.arraycopy(ret[0], 0, retD, 0, retD.length);
/* 2045 */     return retD;
/*      */   }
/*      */   
/*      */   public double[][] heikenAshi(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2049 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2050 */     double[][] retD = new double[((Object[])ret[0]).length][];
/* 2051 */     System.arraycopy(ret[0], 0, retD, 0, retD.length);
/* 2052 */     return retD;
/*      */   }
/*      */   
/*      */   public double[] heikinAshi(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 2056 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, shift);
/* 2057 */     return new double[] { ((double[])(double[])ret[0])[0], ((double[])(double[])ret[0])[1], ((double[])(double[])ret[0])[2], ((double[])(double[])ret[0])[3] };
/*      */   }
/*      */   
/*      */   public double[][] heikinAshi(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 2061 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, from, to);
/* 2062 */     double[][] retD = new double[((Object[])ret[0]).length][];
/* 2063 */     System.arraycopy(ret[0], 0, retD, 0, retD.length);
/* 2064 */     return retD;
/*      */   }
/*      */   
/*      */   public double[][] heikinAshi(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2068 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2069 */     double[][] retD = new double[((Object[])ret[0]).length][];
/* 2070 */     System.arraycopy(ret[0], 0, retD, 0, retD.length);
/* 2071 */     return retD;
/*      */   }
/*      */   
/*      */   public double[][] heikinAshi(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 2075 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshi", null, null, filter, from, to);
/* 2076 */     double[][] retD = new double[((Object[])ret[0]).length][];
/* 2077 */     System.arraycopy(ret[0], 0, retD, 0, retD.length);
/* 2078 */     return retD;
/*      */   }
/*      */   
/*      */   public IBar heikinAshiSingle(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 2082 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshiSingle", null, null, shift);
/* 2083 */     return (IBar)ret[0];
/*      */   }
/*      */   
/*      */   public IBar[] heikinAshiSingle(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 2087 */     IBar[] ret = (IBar[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshiSingle", null, null, from, to)[0];
/* 2088 */     return ret;
/*      */   }
/*      */   
/*      */   public IBar[] heikinAshiSingle(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2092 */     IBar[] ret = (IBar[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshiSingle", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/* 2093 */     return ret;
/*      */   }
/*      */   
/*      */   public IBar[] heikinAshiSingle(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 2097 */     IBar[] ret = (IBar[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HeikinAshiSingle", null, null, filter, from, to)[0];
/* 2098 */     return ret;
/*      */   }
/*      */   
/*      */   public double hma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2102 */     return ((Double)function(instrument, period, side, "HMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] hma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2106 */     return (double[])function(instrument, period, side, "HMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] hma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2110 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] hma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2114 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ht_dcperiod(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2118 */     return ((Double)function(instrument, period, side, "HT_DCPERIOD", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ht_dcperiod(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2122 */     return (double[])function(instrument, period, side, "HT_DCPERIOD", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_dcperiod(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2127 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_DCPERIOD", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_dcperiod(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2131 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_DCPERIOD", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ht_dcphase(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2135 */     return ((Double)function(instrument, period, side, "HT_DCPHASE", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ht_dcphase(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2139 */     return (double[])function(instrument, period, side, "HT_DCPHASE", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_dcphase(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2144 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_DCPHASE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_dcphase(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2148 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_DCPHASE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_phasor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2152 */     Object[] ret = function(instrument, period, side, "HT_PHASOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift);
/* 2153 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] ht_phasor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2157 */     Object[] ret = function(instrument, period, side, "HT_PHASOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to);
/* 2158 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] ht_phasor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2163 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_PHASOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2164 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] ht_phasor(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2168 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_PHASOR", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to);
/* 2169 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[] ht_sine(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2173 */     Object[] ret = function(instrument, period, side, "HT_SINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift);
/* 2174 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] ht_sine(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2178 */     Object[] ret = function(instrument, period, side, "HT_SINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to);
/* 2179 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] ht_sine(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2184 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_SINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2185 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] ht_sine(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2189 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_SINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to);
/* 2190 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double ht_trendline(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2194 */     return ((Double)function(instrument, period, side, "HT_TRENDLINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ht_trendline(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2198 */     return (double[])function(instrument, period, side, "HT_TRENDLINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_trendline(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2203 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_TRENDLINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ht_trendline(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2207 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_TRENDLINE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int ht_trendmode(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2211 */     return ((Integer)function(instrument, period, side, "HT_TRENDMODE", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] ht_trendmode(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2215 */     return (int[])function(instrument, period, side, "HT_TRENDMODE", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] ht_trendmode(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2220 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_TRENDMODE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] ht_trendmode(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2224 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "HT_TRENDMODE", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ichimoku(Instrument instrument, Period period, OfferSide side, int tenkan, int kijun, int senkou, int shift) throws JFException {
/* 2228 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ICHIMOKU", null, new Object[] { Integer.valueOf(tenkan), Integer.valueOf(kijun), Integer.valueOf(senkou) }, shift);
/* 2229 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), Double.valueOf(((double[])(double[])ret[5])[0]).doubleValue(), Double.valueOf(((double[])(double[])ret[5])[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] ichimoku(Instrument instrument, Period period, OfferSide side, int tenkan, int kijun, int senkou, long from, long to) throws JFException {
/* 2233 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ICHIMOKU", null, new Object[] { Integer.valueOf(tenkan), Integer.valueOf(kijun), Integer.valueOf(senkou) }, from, to);
/* 2234 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])((Object[])(Object[])ret[5])[0], (double[])(double[])((Object[])(Object[])ret[5])[0] };
/*      */   }
/*      */   
/*      */   public double[][] ichimoku(Instrument instrument, Period period, OfferSide side, int tenkan, int kijun, int senkou, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2238 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ICHIMOKU", null, new Object[] { Integer.valueOf(tenkan), Integer.valueOf(kijun), Integer.valueOf(senkou) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2239 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])((Object[])(Object[])ret[5])[0], (double[])(double[])((Object[])(Object[])ret[5])[0] };
/*      */   }
/*      */   
/*      */   public double[][] ichimoku(Instrument instrument, Period period, OfferSide side, int tenkan, int kijun, int senkou, Filter filter, long from, long to) throws JFException {
/* 2243 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "ICHIMOKU", null, new Object[] { Integer.valueOf(tenkan), Integer.valueOf(kijun), Integer.valueOf(senkou) }, filter, from, to);
/* 2244 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])((Object[])(Object[])ret[5])[0], (double[])(double[])((Object[])(Object[])ret[5])[0] };
/*      */   }
/*      */   
/*      */   public double kairi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 2248 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "KAIRI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, shift);
/* 2249 */     return ((Double)ret[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] kairi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 2253 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "KAIRI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, from, to);
/* 2254 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] kairi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2258 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "KAIRI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2259 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] kairi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/* 2263 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side, side }, "KAIRI", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2268 */     return ((Double)function(instrument, period, side, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(2), Integer.valueOf(30) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2273 */     return (double[])function(instrument, period, side, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(2), Integer.valueOf(30) }, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2278 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(2), Integer.valueOf(30) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2283 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(2), Integer.valueOf(30) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastMAPeriod, int slowMAPeriod, int shift) throws JFException {
/* 2287 */     return ((Double)function(instrument, period, side, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastMAPeriod), Integer.valueOf(slowMAPeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastMAPeriod, int slowMAPeriod, long from, long to) throws JFException {
/* 2291 */     return (double[])function(instrument, period, side, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastMAPeriod), Integer.valueOf(slowMAPeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastMAPeriod, int slowMAPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2295 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastMAPeriod), Integer.valueOf(slowMAPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] kama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastMAPeriod, int slowMAPeriod, Filter filter, long from, long to) throws JFException {
/* 2299 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "KAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastMAPeriod), Integer.valueOf(slowMAPeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] kdj(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriodK, int timePeriodD, IIndicators.MaType slowKMaType, int slowKPeriod, IIndicators.MaType slowDMaType, int slowDPeriod, IIndicators.MaType slowJMaType, int slowJPeriod, int shift) throws JFException {
/* 2303 */     Object[] ret = function(instrument, period, side, "KDJ", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriodK), Integer.valueOf(timePeriodD), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()), Integer.valueOf(slowJPeriod), Integer.valueOf(slowJMaType.ordinal()) }, shift);
/* 2304 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] kdj(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriodK, int timePeriodD, IIndicators.MaType slowKMaType, int slowKPeriod, IIndicators.MaType slowDMaType, int slowDPeriod, IIndicators.MaType slowJMaType, int slowJPeriod, long from, long to) throws JFException {
/* 2308 */     Object[] ret = function(instrument, period, side, "KDJ", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriodK), Integer.valueOf(timePeriodD), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()), Integer.valueOf(slowJPeriod), Integer.valueOf(slowJMaType.ordinal()) }, from, to);
/* 2309 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] kdj(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriodK, int timePeriodD, IIndicators.MaType slowKMaType, int slowKPeriod, IIndicators.MaType slowDMaType, int slowDPeriod, IIndicators.MaType slowJMaType, int slowJPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2313 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "KDJ", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriodK), Integer.valueOf(timePeriodD), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()), Integer.valueOf(slowJPeriod), Integer.valueOf(slowJMaType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2314 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] kdj(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriodK, int timePeriodD, IIndicators.MaType slowKMaType, int slowKPeriod, IIndicators.MaType slowDMaType, int slowDPeriod, IIndicators.MaType slowJMaType, int slowJPeriod, Filter filter, long from, long to) throws JFException {
/* 2318 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "KDJ", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriodK), Integer.valueOf(timePeriodD), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()), Integer.valueOf(slowJPeriod), Integer.valueOf(slowJMaType.ordinal()) }, filter, from, to);
/* 2319 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[] keltner(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2323 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "KELTNER", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 2324 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] keltner(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2328 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "KELTNER", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 2329 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] keltner(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2333 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "KELTNER", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2334 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] keltner(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2338 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "KELTNER", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 2339 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double lasacs1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, int shift) throws JFException {
/* 2343 */     return ((Double)function(instrument, period, side, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] lasacs1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, long from, long to) throws JFException {
/* 2347 */     return (double[])function(instrument, period, side, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] lasacs1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2351 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double lagACS1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, int shift) throws JFException {
/* 2355 */     return ((Double)function(instrument, period, side, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] lagACS1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, long from, long to) throws JFException {
/* 2359 */     return (double[])function(instrument, period, side, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] lagACS1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2363 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] lagACS1(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int ma, double gamma, int lookback, Filter filter, long from, long to) throws JFException {
/* 2367 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LAGACS1", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double linearReg(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2371 */     return ((Double)function(instrument, period, side, "LINEARREG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] linearReg(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2375 */     return (double[])function(instrument, period, side, "LINEARREG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] linearReg(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2379 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] linearReg(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2383 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double linearRegAngle(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2387 */     return ((Double)function(instrument, period, side, "LINEARREG_ANGLE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] linearRegAngle(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2391 */     return (double[])function(instrument, period, side, "LINEARREG_ANGLE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] linearRegAngle(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2395 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG_ANGLE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] linearRegAngle(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2399 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG_ANGLE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double linearRegIntercept(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2403 */     return ((Double)function(instrument, period, side, "LINEARREG_INTERCEPT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] linearRegIntercept(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2407 */     return (double[])function(instrument, period, side, "LINEARREG_INTERCEPT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] linearRegIntercept(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2411 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG_INTERCEPT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] linearRegIntercept(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2415 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG_INTERCEPT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double linearRegSlope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2419 */     return ((Double)function(instrument, period, side, "LINEARREG_SLOPE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] linearRegSlope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2423 */     return (double[])function(instrument, period, side, "LINEARREG_SLOPE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] linearRegSlope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2427 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG_SLOPE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] linearRegSlope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2431 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LINEARREG_SLOPE", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ln(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2435 */     return ((Double)function(instrument, period, side, "LN", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ln(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2439 */     return (double[])function(instrument, period, side, "LN", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ln(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2443 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ln(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2447 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double log10(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 2451 */     return ((Double)function(instrument, period, side, "LOG10", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] log10(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 2455 */     return (double[])function(instrument, period, side, "LOG10", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] log10(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2459 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LOG10", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] log10(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 2463 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LOG10", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double lwma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2467 */     return ((Double)function(instrument, period, side, "LWMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] lwma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2471 */     return (double[])function(instrument, period, side, "LWMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] lwma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2475 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LWMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] lwma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2479 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "LWMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 2483 */     return ((Double)function(instrument, period, side, "MA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 2487 */     return (double[])function(instrument, period, side, "MA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2491 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/* 2495 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] macd(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, int signalPeriod, int shift) throws JFException {
/* 2499 */     Object[] ret = function(instrument, period, side, "MACD", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(signalPeriod) }, shift);
/* 2500 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] macd(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, int signalPeriod, long from, long to) throws JFException {
/* 2504 */     Object[] ret = function(instrument, period, side, "MACD", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(signalPeriod) }, from, to);
/* 2505 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] macd(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, int signalPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2509 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MACD", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(signalPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2510 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] macd(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, int signalPeriod, Filter filter, long from, long to) throws JFException {
/* 2514 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MACD", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(signalPeriod) }, filter, from, to);
/* 2515 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[] macdExt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, IIndicators.MaType fastMaType, int slowPeriod, IIndicators.MaType slowMaType, int signalPeriod, IIndicators.MaType signalMaType, int shift) throws JFException {
/* 2519 */     Object[] ret = function(instrument, period, side, "MACDEXT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(fastMaType.ordinal()), Integer.valueOf(slowPeriod), Integer.valueOf(slowMaType.ordinal()), Integer.valueOf(signalPeriod), Integer.valueOf(signalMaType.ordinal()) }, shift);
/* 2520 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] macdExt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, IIndicators.MaType fastMaType, int slowPeriod, IIndicators.MaType slowMaType, int signalPeriod, IIndicators.MaType signalMaType, long from, long to) throws JFException {
/* 2524 */     Object[] ret = function(instrument, period, side, "MACDEXT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(fastMaType.ordinal()), Integer.valueOf(slowPeriod), Integer.valueOf(slowMaType.ordinal()), Integer.valueOf(signalPeriod), Integer.valueOf(signalMaType.ordinal()) }, from, to);
/* 2525 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] macdExt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, IIndicators.MaType fastMaType, int slowPeriod, IIndicators.MaType slowMaType, int signalPeriod, IIndicators.MaType signalMaType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2529 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MACDEXT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(fastMaType.ordinal()), Integer.valueOf(slowPeriod), Integer.valueOf(slowMaType.ordinal()), Integer.valueOf(signalPeriod), Integer.valueOf(signalMaType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2530 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] macdExt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, IIndicators.MaType fastMaType, int slowPeriod, IIndicators.MaType slowMaType, int signalPeriod, IIndicators.MaType signalMaType, Filter filter, long from, long to) throws JFException {
/* 2534 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MACDEXT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(fastMaType.ordinal()), Integer.valueOf(slowPeriod), Integer.valueOf(slowMaType.ordinal()), Integer.valueOf(signalPeriod), Integer.valueOf(signalMaType.ordinal()) }, filter, from, to);
/* 2535 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[] macdFix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int signalPeriod, int shift) throws JFException {
/* 2539 */     Object[] ret = function(instrument, period, side, "MACDFIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(signalPeriod) }, shift);
/* 2540 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] macdFix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int signalPeriod, long from, long to) throws JFException {
/* 2544 */     Object[] ret = function(instrument, period, side, "MACDFIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(signalPeriod) }, from, to);
/* 2545 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] macdFix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int signalPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2549 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MACDFIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(signalPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2550 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] macdFix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int signalPeriod, Filter filter, long from, long to) throws JFException {
/* 2554 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MACDFIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(signalPeriod) }, filter, from, to);
/* 2555 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[] maEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, int shift) throws JFException {
/* 2559 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, shift);
/* 2560 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] maEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, long from, long to) throws JFException {
/* 2564 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, from, to);
/* 2565 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] maEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2569 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2570 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] maEnvelope(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double deviation, Filter filter, long from, long to) throws JFException {
/* 2574 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MAEnvelope", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, filter, from, to);
/* 2575 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[] mama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, double fastLimit, double slowLimit, int shift) throws JFException {
/* 2579 */     Object[] ret = function(instrument, period, side, "MAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Double.valueOf(fastLimit), Double.valueOf(slowLimit) }, shift);
/* 2580 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] mama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, double fastLimit, double slowLimit, long from, long to) throws JFException {
/* 2584 */     Object[] ret = function(instrument, period, side, "MAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Double.valueOf(fastLimit), Double.valueOf(slowLimit) }, from, to);
/* 2585 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] mama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, double fastLimit, double slowLimit, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2589 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Double.valueOf(fastLimit), Double.valueOf(slowLimit) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2590 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] mama(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, double fastLimit, double slowLimit, Filter filter, long from, long to) throws JFException {
/* 2594 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MAMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Double.valueOf(fastLimit), Double.valueOf(slowLimit) }, filter, from, to);
/* 2595 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public Object[] wsmTime(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 2599 */     return function(instrument, period, side, "WSMTIME", null, null, shift);
/*      */   }
/*      */   
/*      */   public Object[] wsmTime(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 2603 */     return function(instrument, period, side, "WSMTIME", null, null, from, to);
/*      */   }
/*      */   
/*      */   public Object[] wsmTime(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2607 */     return calculateIndicator(instrument, period, new OfferSide[] { side }, "WSMTIME", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/*      */   }
/*      */   
/*      */   public Object[] wsmTime(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 2611 */     return calculateIndicator(instrument, period, new OfferSide[] { side }, "WSMTIME", null, null, filter, from, to);
/*      */   }
/*      */   
/*      */   public double mavp(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int minPeriod, int maxPeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 2615 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MAVP", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(minPeriod), Integer.valueOf(maxPeriod), Integer.valueOf(maType.ordinal()) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] mavp(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int minPeriod, int maxPeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 2619 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MAVP", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(minPeriod), Integer.valueOf(maxPeriod), Integer.valueOf(maType.ordinal()) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] mavp(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int minPeriod, int maxPeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2623 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MAVP", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(minPeriod), Integer.valueOf(maxPeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] mavp(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int minPeriod, int maxPeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/* 2627 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MAVP", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(minPeriod), Integer.valueOf(maxPeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double max(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2631 */     return ((Double)function(instrument, period, side, "MAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] max(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2635 */     return (double[])function(instrument, period, side, "MAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] max(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2639 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] max(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2643 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int maxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2647 */     return ((Integer)function(instrument, period, side, "MAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] maxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2651 */     return (int[])function(instrument, period, side, "MAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] maxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2655 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] maxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2659 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double medPrice(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 2663 */     return ((Double)function(instrument, period, side, "MEDPRICE", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] medPrice(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 2667 */     return (double[])function(instrument, period, side, "MEDPRICE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] medPrice(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2671 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MEDPRICE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] medPrice(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 2675 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MEDPRICE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double mfi(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 2679 */     return ((Double)function(instrument, period, side, "MFI", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] mfi(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 2683 */     return (double[])function(instrument, period, side, "MFI", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] mfi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2687 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MFI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] mfi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2691 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MFI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double midPoint(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2695 */     return ((Double)function(instrument, period, side, "MIDPOINT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] midPoint(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2699 */     return (double[])function(instrument, period, side, "MIDPOINT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] midPoint(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2703 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MIDPOINT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] midPoint(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2707 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MIDPOINT", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double midPrice(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 2711 */     return ((Double)function(instrument, period, side, "MIDPRICE", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] midPrice(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 2715 */     return (double[])function(instrument, period, side, "MIDPRICE", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] midPrice(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2719 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MIDPRICE", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] midPrice(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2723 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MIDPRICE", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double min(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2727 */     return ((Double)function(instrument, period, side, "MIN", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] min(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2731 */     return (double[])function(instrument, period, side, "MIN", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] min(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2735 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MIN", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] min(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2739 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MIN", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public int minIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2743 */     return ((Integer)function(instrument, period, side, "MININDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).intValue();
/*      */   }
/*      */   
/*      */   public int[] minIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2747 */     return (int[])function(instrument, period, side, "MININDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public int[] minIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2751 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MININDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public int[] minIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2755 */     return (int[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MININDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] minMax(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2759 */     Object[] ret = function(instrument, period, side, "MINMAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 2760 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] minMax(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2764 */     Object[] ret = function(instrument, period, side, "MINMAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 2765 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] minMax(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2769 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MINMAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2770 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] minMax(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2774 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MINMAX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 2775 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public int[] minMaxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2779 */     Object[] ret = function(instrument, period, side, "MINMAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 2780 */     return new int[] { ((Integer)ret[0]).intValue(), ((Integer)ret[1]).intValue() };
/*      */   }
/*      */   
/*      */   public int[][] minMaxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2784 */     Object[] ret = function(instrument, period, side, "MINMAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 2785 */     return new int[][] { (int[])(int[])ret[0], (int[])(int[])ret[1] };
/*      */   }
/*      */   
/*      */   public int[][] minMaxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2789 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MINMAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2790 */     return new int[][] { (int[])(int[])ret[0], (int[])(int[])ret[1] };
/*      */   }
/*      */   
/*      */   public int[][] minMaxIndex(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2794 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MINMAXINDEX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 2795 */     return new int[][] { (int[])(int[])ret[0], (int[])(int[])ret[1] };
/*      */   }
/*      */   
/*      */   public double minusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 2799 */     return ((Double)function(instrument, period, side, "MINUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] minusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 2803 */     return (double[])function(instrument, period, side, "MINUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] minusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2807 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MINUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] minusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2811 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MINUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double minusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 2815 */     return ((Double)function(instrument, period, side, "MINUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] minusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 2819 */     return (double[])function(instrument, period, side, "MINUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] minusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2823 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MINUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] minusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2827 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MINUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double mom(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 2831 */     return ((Double)function(instrument, period, side, "MOM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] mom(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 2835 */     return (double[])function(instrument, period, side, "MOM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] mom(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2839 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MOM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] mom(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2843 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "MOM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double mult(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int shift) throws JFException
/*      */   {
/* 2848 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MULT", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] mult(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, long from, long to) throws JFException
/*      */   {
/* 2853 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MULT", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] mult(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2858 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MULT", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] mult(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, long from, long to) throws JFException
/*      */   {
/* 2863 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "MULT", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, int timePeriod, int stepBack, int shift) throws JFException {
/* 2868 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2869 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), mappedPeriod, Integer.valueOf(stepBack) }, shift);
/* 2870 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue(), ((Double)ret[7]).doubleValue(), ((Double)ret[8]).doubleValue(), ((Double)ret[9]).doubleValue(), ((Double)ret[10]).doubleValue(), ((Double)ret[11]).doubleValue(), ((Double)ret[12]).doubleValue() };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, int timePeriod, int stepBack, long from, long to) throws JFException {
/* 2875 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2876 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), mappedPeriod, Integer.valueOf(stepBack) }, from, to);
/* 2877 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, int timePeriod, int stepBack, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2882 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2883 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), mappedPeriod, Integer.valueOf(stepBack) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2884 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, int timePeriod, int stepBack, Filter filter, long from, long to) throws JFException {
/* 2889 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2890 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), mappedPeriod, Integer.valueOf(stepBack) }, filter, from, to);
/* 2891 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double[] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, Period timePeriod, int stepBack, int shift) throws JFException {
/* 2895 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), timePeriod, Integer.valueOf(stepBack) }, shift);
/* 2896 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue(), ((Double)ret[7]).doubleValue(), ((Double)ret[8]).doubleValue(), ((Double)ret[9]).doubleValue(), ((Double)ret[10]).doubleValue(), ((Double)ret[11]).doubleValue(), ((Double)ret[12]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, Period timePeriod, int stepBack, long from, long to) throws JFException {
/* 2900 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), timePeriod, Integer.valueOf(stepBack) }, from, to);
/* 2901 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double[][] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, Period timePeriod, int stepBack, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2905 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), timePeriod, Integer.valueOf(stepBack) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2906 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double[][] murrey(Instrument instrument, Period period, OfferSide side, int nPeriod, Period timePeriod, int stepBack, Filter filter, long from, long to) throws JFException {
/* 2910 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "MURRCH", null, new Object[] { Integer.valueOf(nPeriod), timePeriod, Integer.valueOf(stepBack) }, filter, from, to);
/* 2911 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double natr(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 2915 */     return ((Double)function(instrument, period, side, "NATR", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] natr(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 2919 */     return (double[])function(instrument, period, side, "NATR", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] natr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2923 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "NATR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] natr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 2927 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "NATR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double obv(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, OfferSide sideForPriceV, int shift) throws JFException
/*      */   {
/* 2932 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side, sideForPriceV }, "OBV", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] obv(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, OfferSide sideForPriceV, long from, long to) throws JFException
/*      */   {
/* 2937 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side, sideForPriceV }, "OBV", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] obv(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, OfferSide sideForPriceV, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2942 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side, sideForPriceV }, "OBV", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] obv(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, OfferSide sideForPriceV, Filter filter, long from, long to) throws JFException {
/* 2946 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side, sideForPriceV }, "OBV", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double osma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fast_ema_period, int slow_ema_period, int signal_period, int shift) throws JFException {
/* 2950 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "OsMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fast_ema_period), Integer.valueOf(slow_ema_period), Integer.valueOf(signal_period) }, shift);
/* 2951 */     return ((Double)ret[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] osma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fast_ema_period, int slow_ema_period, int signal_period, long from, long to) throws JFException {
/* 2955 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "OsMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fast_ema_period), Integer.valueOf(slow_ema_period), Integer.valueOf(signal_period) }, from, to);
/* 2956 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] osma(Instrument instrument, Period period, OfferSide side, int fast_ema_period, int slow_ema_period, int signal_period, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 2961 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "OsMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fast_ema_period), Integer.valueOf(slow_ema_period), Integer.valueOf(signal_period) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2962 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] osma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fast_ema_period, int slow_ema_period, int signal_period, Filter filter, long from, long to) throws JFException {
/* 2966 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "OsMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fast_ema_period), Integer.valueOf(slow_ema_period), Integer.valueOf(signal_period) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, boolean showHistoricalLevels, int shift) throws JFException {
/* 2971 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2972 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(showHistoricalLevels) }, shift);
/* 2973 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue() };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, boolean showHistoricalLevels, long from, long to) throws JFException {
/* 2978 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2979 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(showHistoricalLevels) }, from, to);
/* 2980 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, boolean showHistoricalLevels, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 2985 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2986 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(showHistoricalLevels) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 2987 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, boolean showHistoricalLevels, Filter filter, long from, long to) throws JFException {
/* 2992 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 2993 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(showHistoricalLevels) }, filter, from, to);
/* 2994 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 2999 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 3000 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(true) }, shift);
/* 3001 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue(), ((Double)ret[7]).doubleValue(), ((Double)ret[8]).doubleValue(), ((Double)ret[9]).doubleValue(), ((Double)ret[10]).doubleValue(), ((Double)ret[11]).doubleValue(), ((Double)ret[12]).doubleValue() };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException
/*      */   {
/* 3007 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 3008 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(true) }, from, to);
/* 3009 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3015 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 3016 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(true) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3017 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException
/*      */   {
/* 3023 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 3024 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { mappedPeriod, Boolean.valueOf(true) }, filter, from, to);
/* 3025 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double[] pivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, int shift) throws JFException
/*      */   {
/* 3030 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { timePeriod, Boolean.valueOf(true) }, shift);
/* 3031 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue(), ((Double)ret[7]).doubleValue(), ((Double)ret[8]).doubleValue(), ((Double)ret[9]).doubleValue(), ((Double)ret[10]).doubleValue(), ((Double)ret[11]).doubleValue(), ((Double)ret[12]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, long from, long to) throws JFException
/*      */   {
/* 3036 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { timePeriod, Boolean.valueOf(true) }, from, to);
/* 3037 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3042 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { timePeriod, Boolean.valueOf(true) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3043 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double[][] pivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, long from, long to) throws JFException
/*      */   {
/* 3048 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "PIVOT", null, new Object[] { timePeriod, Boolean.valueOf(true) }, filter, from, to);
/* 3049 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6], (double[])(double[])ret[7], (double[])(double[])ret[8], (double[])(double[])ret[9], (double[])(double[])ret[10], (double[])(double[])ret[11], (double[])(double[])ret[12] };
/*      */   }
/*      */   
/*      */   public double plusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException
/*      */   {
/* 3054 */     return ((Double)function(instrument, period, side, "PLUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] plusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 3058 */     return (double[])function(instrument, period, side, "PLUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] plusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3062 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PLUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] plusDi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3066 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PLUS_DI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double plusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 3070 */     return ((Double)function(instrument, period, side, "PLUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] plusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 3074 */     return (double[])function(instrument, period, side, "PLUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] plusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3078 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PLUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] plusDm(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3082 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PLUS_DM", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ppo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 3086 */     return ((Double)function(instrument, period, side, "PPO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ppo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 3090 */     return (double[])function(instrument, period, side, "PPO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ppo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3094 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PPO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ppo(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, Filter filter, long from, long to) throws JFException {
/* 3098 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PPO", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double prchannel(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, int shift) throws JFException {
/* 3103 */     return ((Double)function(instrument, period, side, "PCHANNEL", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] prchannel(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, long from, long to) throws JFException {
/* 3108 */     return (double[])function(instrument, period, side, "PCHANNEL", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] prchannel(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int fastPeriod, int slowPeriod, IIndicators.MaType maType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3113 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PCHANNEL", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double prchannel(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 3117 */     return ((Double)function(instrument, period, side, "PCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] prchannel(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 3121 */     return (double[])function(instrument, period, side, "PCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] prchannel(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3125 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] prchannel(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3129 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "PCHANNEL", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double rci(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3133 */     return ((Double)function(instrument, period, side, "RCI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] rci(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3137 */     return (double[])function(instrument, period, side, "RCI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rci(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3141 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "RCI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] rci(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3145 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "RCI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double rmi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int momentumPeriod, int shift) throws JFException {
/* 3149 */     return ((Double)function(instrument, period, side, "RMI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(momentumPeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] rmi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int momentumPeriod, long from, long to) throws JFException {
/* 3153 */     return (double[])function(instrument, period, side, "RMI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(momentumPeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rmi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int momentumPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3157 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "RMI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(momentumPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] rmi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int momentumPeriod, Filter filter, long from, long to) throws JFException {
/* 3161 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "RMI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(momentumPeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double roc(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3165 */     return ((Double)function(instrument, period, side, "ROC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] roc(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3169 */     return (double[])function(instrument, period, side, "ROC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] roc(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3173 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] roc(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3177 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROC", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double rocp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3181 */     return ((Double)function(instrument, period, side, "ROCP", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] rocp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3185 */     return (double[])function(instrument, period, side, "ROCP", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rocp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3189 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROCP", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] rocp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3193 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROCP", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double rocr(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3197 */     return ((Double)function(instrument, period, side, "ROCR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] rocr(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3201 */     return (double[])function(instrument, period, side, "ROCR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rocr(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3205 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROCR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] rocr(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3209 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROCR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double rocr100(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3213 */     return ((Double)function(instrument, period, side, "ROCR100", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] rocr100(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3217 */     return (double[])function(instrument, period, side, "ROCR100", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rocr100(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3221 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROCR100", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] rocr100(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3225 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ROCR100", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double rsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3229 */     return ((Double)function(instrument, period, side, "RSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] rsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3233 */     return (double[])function(instrument, period, side, "RSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3237 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "RSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] rsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3241 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "RSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] rvi(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 3245 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "RVI", null, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 3246 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] rvi(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 3250 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "RVI", null, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 3251 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] rvi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3255 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "RVI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3256 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] rvi(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3260 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "RVI", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 3261 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double sar(Instrument instrument, Period period, OfferSide side, double acceleration, double maximum, int shift) throws JFException {
/* 3265 */     double value = sarExt(instrument, period, side, 0.0D, 0.0D, acceleration, acceleration, maximum, acceleration, acceleration, maximum, shift);
/* 3266 */     if (value < 0.0D) {
/* 3267 */       return -value;
/*      */     }
/* 3269 */     return value;
/*      */   }
/*      */   
/*      */   public double[] sar(Instrument instrument, Period period, OfferSide side, double acceleration, double maximum, long from, long to) throws JFException
/*      */   {
/* 3274 */     double[] values = sarExt(instrument, period, side, 0.0D, 0.0D, acceleration, acceleration, maximum, acceleration, acceleration, maximum, null, from, to);
/* 3275 */     for (int i = 0; i < values.length; i++) {
/* 3276 */       double value = values[i];
/* 3277 */       if (value < 0.0D) {
/* 3278 */         values[i] = (-value);
/*      */       }
/*      */     }
/* 3281 */     return values;
/*      */   }
/*      */   
/*      */   public double[] sar(Instrument instrument, Period period, OfferSide side, double acceleration, double maximum, Filter filter, long from, long to) throws JFException {
/* 3285 */     double[] values = sarExt(instrument, period, side, 0.0D, 0.0D, acceleration, acceleration, maximum, acceleration, acceleration, maximum, filter, from, to);
/* 3286 */     for (int i = 0; i < values.length; i++) {
/* 3287 */       double value = values[i];
/* 3288 */       if (value < 0.0D) {
/* 3289 */         values[i] = (-value);
/*      */       }
/*      */     }
/* 3292 */     return values;
/*      */   }
/*      */   
/*      */   public double[] sar(Instrument instrument, Period period, OfferSide side, double acceleration, double maximum, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3296 */     double[] values = sarExt(instrument, period, side, 0.0D, 0.0D, acceleration, acceleration, maximum, acceleration, acceleration, maximum, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3297 */     for (int i = 0; i < values.length; i++) {
/* 3298 */       double value = values[i];
/* 3299 */       if (value < 0.0D) {
/* 3300 */         values[i] = (-value);
/*      */       }
/*      */     }
/* 3303 */     return values;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public double sarExt(Instrument instrument, Period period, OfferSide side, double startValue, double offsetOnReverse, double accelerationInitLong, double accelerationLong, double accelerationMaxLong, double accelerationInitShort, double accelerationShort, double accelerationMaxShort, int shift)
/*      */     throws JFException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_2
/*      */     //   2: invokevirtual 269	com/dukascopy/api/impl/Indicators:checkNotTick	(Lcom/dukascopy/api/Period;)V
/*      */     //   5: aload_0
/*      */     //   6: aload_2
/*      */     //   7: iconst_1
/*      */     //   8: anewarray 82	com/dukascopy/api/OfferSide
/*      */     //   11: dup
/*      */     //   12: iconst_0
/*      */     //   13: aload_3
/*      */     //   14: aastore
/*      */     //   15: invokevirtual 270	com/dukascopy/api/impl/Indicators:checkSide	(Lcom/dukascopy/api/Period;[Lcom/dukascopy/api/OfferSide;)V
/*      */     //   18: aload_0
/*      */     //   19: ldc_w 271
/*      */     //   22: invokevirtual 38	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */     //   25: astore 21
/*      */     //   27: aload 21
/*      */     //   29: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   32: astore 22
/*      */     //   34: aload_0
/*      */     //   35: aload 22
/*      */     //   37: bipush 8
/*      */     //   39: anewarray 86	java/lang/Object
/*      */     //   42: dup
/*      */     //   43: iconst_0
/*      */     //   44: dload 4
/*      */     //   46: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   49: aastore
/*      */     //   50: dup
/*      */     //   51: iconst_1
/*      */     //   52: dload 6
/*      */     //   54: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   57: aastore
/*      */     //   58: dup
/*      */     //   59: iconst_2
/*      */     //   60: dload 8
/*      */     //   62: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   65: aastore
/*      */     //   66: dup
/*      */     //   67: iconst_3
/*      */     //   68: dload 10
/*      */     //   70: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   73: aastore
/*      */     //   74: dup
/*      */     //   75: iconst_4
/*      */     //   76: dload 12
/*      */     //   78: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   81: aastore
/*      */     //   82: dup
/*      */     //   83: iconst_5
/*      */     //   84: dload 14
/*      */     //   86: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   89: aastore
/*      */     //   90: dup
/*      */     //   91: bipush 6
/*      */     //   93: dload 16
/*      */     //   95: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   98: aastore
/*      */     //   99: dup
/*      */     //   100: bipush 7
/*      */     //   102: dload 18
/*      */     //   104: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   107: aastore
/*      */     //   108: invokevirtual 272	com/dukascopy/api/impl/Indicators:setOptParams	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)V
/*      */     //   111: aload 22
/*      */     //   113: invokeinterface 273 1 0
/*      */     //   118: dup
/*      */     //   119: istore 24
/*      */     //   121: istore 23
/*      */     //   123: iconst_0
/*      */     //   124: istore 25
/*      */     //   126: iconst_0
/*      */     //   127: istore 26
/*      */     //   129: iconst_0
/*      */     //   130: newarray <illegal type>
/*      */     //   132: astore 27
/*      */     //   134: aconst_null
/*      */     //   135: astore 28
/*      */     //   137: wide
/*      */     //   143: aload_0
/*      */     //   144: aload_1
/*      */     //   145: aload_2
/*      */     //   146: aload_3
/*      */     //   147: getstatic 274	com/dukascopy/api/indicators/InputParameterInfo$Type:PRICE	Lcom/dukascopy/api/indicators/InputParameterInfo$Type;
/*      */     //   150: aconst_null
/*      */     //   151: iload 20
/*      */     //   153: iload 23
/*      */     //   155: iconst_0
/*      */     //   156: invokevirtual 275	com/dukascopy/api/impl/Indicators:getInputData	(Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;Lcom/dukascopy/api/OfferSide;Lcom/dukascopy/api/indicators/InputParameterInfo$Type;Lcom/dukascopy/api/IIndicators$AppliedPrice;III)Ljava/lang/Object;
/*      */     //   159: checkcast 276	[[D
/*      */     //   162: checkcast 276	[[D
/*      */     //   165: astore 29
/*      */     //   167: aload 29
/*      */     //   169: ifnonnull +20 -> 189
/*      */     //   172: ldc2_w 277
/*      */     //   175: dstore 30
/*      */     //   177: aload_0
/*      */     //   178: ldc_w 271
/*      */     //   181: aload 21
/*      */     //   183: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   186: dload 30
/*      */     //   188: dreturn
/*      */     //   189: aload 29
/*      */     //   191: iconst_0
/*      */     //   192: aaload
/*      */     //   193: arraylength
/*      */     //   194: istore 30
/*      */     //   196: iload 30
/*      */     //   198: iload 26
/*      */     //   200: if_icmpgt +6 -> 206
/*      */     //   203: goto +127 -> 330
/*      */     //   206: iload 30
/*      */     //   208: istore 26
/*      */     //   210: aload 22
/*      */     //   212: iconst_0
/*      */     //   213: aload 29
/*      */     //   215: invokeinterface 279 3 0
/*      */     //   220: iload 30
/*      */     //   222: iload 24
/*      */     //   224: isub
/*      */     //   225: newarray <illegal type>
/*      */     //   227: astore 27
/*      */     //   229: aload 22
/*      */     //   231: iconst_0
/*      */     //   232: aload 27
/*      */     //   234: invokeinterface 280 3 0
/*      */     //   239: aload 22
/*      */     //   241: iconst_0
/*      */     //   242: iload 30
/*      */     //   244: iconst_1
/*      */     //   245: isub
/*      */     //   246: invokeinterface 281 3 0
/*      */     //   251: astore 28
/*      */     //   253: aload 28
/*      */     //   255: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   258: ifne +6 -> 264
/*      */     //   261: goto +69 -> 330
/*      */     //   264: aload 27
/*      */     //   266: iconst_0
/*      */     //   267: daload
/*      */     //   268: dconst_0
/*      */     //   269: dcmpl
/*      */     //   270: ifle +7 -> 277
/*      */     //   273: iconst_1
/*      */     //   274: goto +4 -> 278
/*      */     //   277: iconst_0
/*      */     //   278: istore 31
/*      */     //   280: iconst_1
/*      */     //   281: istore 32
/*      */     //   283: iload 32
/*      */     //   285: aload 28
/*      */     //   287: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   290: if_icmpge +35 -> 325
/*      */     //   293: aload 27
/*      */     //   295: iload 32
/*      */     //   297: daload
/*      */     //   298: dconst_0
/*      */     //   299: dcmpl
/*      */     //   300: ifle +7 -> 307
/*      */     //   303: iconst_1
/*      */     //   304: goto +4 -> 308
/*      */     //   307: iconst_0
/*      */     //   308: iload 31
/*      */     //   310: if_icmpeq +9 -> 319
/*      */     //   313: iconst_1
/*      */     //   314: istore 25
/*      */     //   316: goto +9 -> 325
/*      */     //   319: iinc 32 1
/*      */     //   322: goto -39 -> 283
/*      */     //   325: iload 25
/*      */     //   327: ifeq -190 -> 137
/*      */     //   330: aload 28
/*      */     //   332: ifnull +11 -> 343
/*      */     //   335: aload 28
/*      */     //   337: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   340: ifgt +20 -> 360
/*      */     //   343: ldc2_w 277
/*      */     //   346: dstore 29
/*      */     //   348: aload_0
/*      */     //   349: ldc_w 271
/*      */     //   352: aload 21
/*      */     //   354: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   357: dload 29
/*      */     //   359: dreturn
/*      */     //   360: aload 27
/*      */     //   362: aload 28
/*      */     //   364: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   367: iconst_1
/*      */     //   368: isub
/*      */     //   369: daload
/*      */     //   370: dstore 29
/*      */     //   372: aload_0
/*      */     //   373: ldc_w 271
/*      */     //   376: aload 21
/*      */     //   378: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   381: dload 29
/*      */     //   383: dreturn
/*      */     //   384: astore 33
/*      */     //   386: aload_0
/*      */     //   387: ldc_w 271
/*      */     //   390: aload 21
/*      */     //   392: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   395: aload 33
/*      */     //   397: athrow
/*      */     //   398: astore 21
/*      */     //   400: aload 21
/*      */     //   402: athrow
/*      */     //   403: astore 21
/*      */     //   405: aload 21
/*      */     //   407: invokevirtual 284	com/dukascopy/api/impl/TaLibException:getCause	()Ljava/lang/Throwable;
/*      */     //   410: astore 22
/*      */     //   412: new 61	com/dukascopy/api/JFException
/*      */     //   415: dup
/*      */     //   416: aload 22
/*      */     //   418: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   421: athrow
/*      */     //   422: astore 21
/*      */     //   424: aload 21
/*      */     //   426: athrow
/*      */     //   427: astore 21
/*      */     //   429: new 61	com/dukascopy/api/JFException
/*      */     //   432: dup
/*      */     //   433: aload 21
/*      */     //   435: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   438: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3308	-> byte code offset #0
/*      */     //   Java source line #3309	-> byte code offset #5
/*      */     //   Java source line #3311	-> byte code offset #18
/*      */     //   Java source line #3313	-> byte code offset #27
/*      */     //   Java source line #3314	-> byte code offset #34
/*      */     //   Java source line #3318	-> byte code offset #111
/*      */     //   Java source line #3319	-> byte code offset #123
/*      */     //   Java source line #3320	-> byte code offset #126
/*      */     //   Java source line #3321	-> byte code offset #129
/*      */     //   Java source line #3322	-> byte code offset #134
/*      */     //   Java source line #3325	-> byte code offset #137
/*      */     //   Java source line #3326	-> byte code offset #143
/*      */     //   Java source line #3327	-> byte code offset #167
/*      */     //   Java source line #3328	-> byte code offset #172
/*      */     //   Java source line #3360	-> byte code offset #177
/*      */     //   Java source line #3330	-> byte code offset #189
/*      */     //   Java source line #3331	-> byte code offset #196
/*      */     //   Java source line #3333	-> byte code offset #203
/*      */     //   Java source line #3335	-> byte code offset #206
/*      */     //   Java source line #3336	-> byte code offset #210
/*      */     //   Java source line #3337	-> byte code offset #220
/*      */     //   Java source line #3338	-> byte code offset #229
/*      */     //   Java source line #3339	-> byte code offset #239
/*      */     //   Java source line #3340	-> byte code offset #253
/*      */     //   Java source line #3342	-> byte code offset #261
/*      */     //   Java source line #3344	-> byte code offset #264
/*      */     //   Java source line #3345	-> byte code offset #280
/*      */     //   Java source line #3346	-> byte code offset #293
/*      */     //   Java source line #3347	-> byte code offset #313
/*      */     //   Java source line #3348	-> byte code offset #316
/*      */     //   Java source line #3345	-> byte code offset #319
/*      */     //   Java source line #3351	-> byte code offset #325
/*      */     //   Java source line #3353	-> byte code offset #330
/*      */     //   Java source line #3354	-> byte code offset #343
/*      */     //   Java source line #3360	-> byte code offset #348
/*      */     //   Java source line #3357	-> byte code offset #360
/*      */     //   Java source line #3360	-> byte code offset #372
/*      */     //   Java source line #3362	-> byte code offset #398
/*      */     //   Java source line #3363	-> byte code offset #400
/*      */     //   Java source line #3364	-> byte code offset #403
/*      */     //   Java source line #3365	-> byte code offset #405
/*      */     //   Java source line #3366	-> byte code offset #412
/*      */     //   Java source line #3367	-> byte code offset #422
/*      */     //   Java source line #3368	-> byte code offset #424
/*      */     //   Java source line #3369	-> byte code offset #427
/*      */     //   Java source line #3370	-> byte code offset #429
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	439	0	this	Indicators
/*      */     //   0	439	1	instrument	Instrument
/*      */     //   0	439	2	period	Period
/*      */     //   0	439	3	side	OfferSide
/*      */     //   0	439	4	startValue	double
/*      */     //   0	439	6	offsetOnReverse	double
/*      */     //   0	439	8	accelerationInitLong	double
/*      */     //   0	439	10	accelerationLong	double
/*      */     //   0	439	12	accelerationMaxLong	double
/*      */     //   0	439	14	accelerationInitShort	double
/*      */     //   0	439	16	accelerationShort	double
/*      */     //   0	439	18	accelerationMaxShort	double
/*      */     //   0	439	20	shift	int
/*      */     //   25	366	21	indicatorHolder	IndicatorHolder
/*      */     //   398	3	21	e	JFException
/*      */     //   403	3	21	e	TaLibException
/*      */     //   422	3	21	e	RuntimeException
/*      */     //   427	7	21	e	Exception
/*      */     //   32	208	22	indicator	IIndicator
/*      */     //   410	7	22	t	Throwable
/*      */     //   121	33	23	lookback	int
/*      */     //   119	106	24	indicatorLookback	int
/*      */     //   124	202	25	hasPeriodChange	boolean
/*      */     //   127	82	26	previousLength	int
/*      */     //   132	229	27	doubles	double[]
/*      */     //   135	228	28	result	IndicatorResult
/*      */     //   165	217	29	inputData	double[][]
/*      */     //   194	52	30	length	int
/*      */     //   278	31	31	positive	boolean
/*      */     //   281	39	32	i	int
/*      */     //   384	12	33	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	177	384	finally
/*      */     //   189	348	384	finally
/*      */     //   360	372	384	finally
/*      */     //   384	386	384	finally
/*      */     //   0	186	398	com/dukascopy/api/JFException
/*      */     //   189	357	398	com/dukascopy/api/JFException
/*      */     //   360	381	398	com/dukascopy/api/JFException
/*      */     //   384	398	398	com/dukascopy/api/JFException
/*      */     //   0	186	403	com/dukascopy/api/impl/TaLibException
/*      */     //   189	357	403	com/dukascopy/api/impl/TaLibException
/*      */     //   360	381	403	com/dukascopy/api/impl/TaLibException
/*      */     //   384	398	403	com/dukascopy/api/impl/TaLibException
/*      */     //   0	186	422	java/lang/RuntimeException
/*      */     //   189	357	422	java/lang/RuntimeException
/*      */     //   360	381	422	java/lang/RuntimeException
/*      */     //   384	398	422	java/lang/RuntimeException
/*      */     //   0	186	427	java/lang/Exception
/*      */     //   189	357	427	java/lang/Exception
/*      */     //   360	381	427	java/lang/Exception
/*      */     //   384	398	427	java/lang/Exception
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public double[] sarExt(Instrument instrument, Period period, OfferSide side, double startValue, double offsetOnReverse, double accelerationInitLong, double accelerationLong, double accelerationMaxLong, double accelerationInitShort, double accelerationShort, double accelerationMaxShort, Filter filter, long from, long to)
/*      */     throws JFException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_2
/*      */     //   2: iconst_1
/*      */     //   3: anewarray 82	com/dukascopy/api/OfferSide
/*      */     //   6: dup
/*      */     //   7: iconst_0
/*      */     //   8: aload_3
/*      */     //   9: aastore
/*      */     //   10: invokevirtual 270	com/dukascopy/api/impl/Indicators:checkSide	(Lcom/dukascopy/api/Period;[Lcom/dukascopy/api/OfferSide;)V
/*      */     //   13: aload_0
/*      */     //   14: aload_2
/*      */     //   15: lload 21
/*      */     //   17: lload 23
/*      */     //   19: invokevirtual 287	com/dukascopy/api/impl/Indicators:checkIntervalValid	(Lcom/dukascopy/api/Period;JJ)V
/*      */     //   22: aload_0
/*      */     //   23: ldc_w 271
/*      */     //   26: invokevirtual 38	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */     //   29: astore 25
/*      */     //   31: aload 25
/*      */     //   33: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   36: astore 26
/*      */     //   38: aload_0
/*      */     //   39: aload 26
/*      */     //   41: bipush 8
/*      */     //   43: anewarray 86	java/lang/Object
/*      */     //   46: dup
/*      */     //   47: iconst_0
/*      */     //   48: dload 4
/*      */     //   50: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   53: aastore
/*      */     //   54: dup
/*      */     //   55: iconst_1
/*      */     //   56: dload 6
/*      */     //   58: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   61: aastore
/*      */     //   62: dup
/*      */     //   63: iconst_2
/*      */     //   64: dload 8
/*      */     //   66: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   69: aastore
/*      */     //   70: dup
/*      */     //   71: iconst_3
/*      */     //   72: dload 10
/*      */     //   74: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   77: aastore
/*      */     //   78: dup
/*      */     //   79: iconst_4
/*      */     //   80: dload 12
/*      */     //   82: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   85: aastore
/*      */     //   86: dup
/*      */     //   87: iconst_5
/*      */     //   88: dload 14
/*      */     //   90: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   93: aastore
/*      */     //   94: dup
/*      */     //   95: bipush 6
/*      */     //   97: dload 16
/*      */     //   99: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   102: aastore
/*      */     //   103: dup
/*      */     //   104: bipush 7
/*      */     //   106: dload 18
/*      */     //   108: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   111: aastore
/*      */     //   112: invokevirtual 272	com/dukascopy/api/impl/Indicators:setOptParams	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)V
/*      */     //   115: aload 26
/*      */     //   117: invokeinterface 273 1 0
/*      */     //   122: dup
/*      */     //   123: istore 28
/*      */     //   125: istore 27
/*      */     //   127: iconst_0
/*      */     //   128: istore 29
/*      */     //   130: iconst_0
/*      */     //   131: istore 30
/*      */     //   133: iconst_0
/*      */     //   134: newarray <illegal type>
/*      */     //   136: astore 31
/*      */     //   138: aconst_null
/*      */     //   139: astore 32
/*      */     //   141: wide
/*      */     //   147: aload 20
/*      */     //   149: ifnull +43 -> 192
/*      */     //   152: aload 20
/*      */     //   154: getstatic 288	com/dukascopy/api/Filter:NO_FILTER	Lcom/dukascopy/api/Filter;
/*      */     //   157: if_acmpeq +35 -> 192
/*      */     //   160: aload_0
/*      */     //   161: aload_1
/*      */     //   162: aload_2
/*      */     //   163: aload_3
/*      */     //   164: getstatic 274	com/dukascopy/api/indicators/InputParameterInfo$Type:PRICE	Lcom/dukascopy/api/indicators/InputParameterInfo$Type;
/*      */     //   167: aconst_null
/*      */     //   168: aload 20
/*      */     //   170: lload 21
/*      */     //   172: lload 23
/*      */     //   174: iload 27
/*      */     //   176: iconst_0
/*      */     //   177: iconst_0
/*      */     //   178: invokevirtual 289	com/dukascopy/api/impl/Indicators:getInputData	(Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;Lcom/dukascopy/api/OfferSide;Lcom/dukascopy/api/indicators/InputParameterInfo$Type;Lcom/dukascopy/api/IIndicators$AppliedPrice;Lcom/dukascopy/api/Filter;JJIII)Ljava/lang/Object;
/*      */     //   181: checkcast 276	[[D
/*      */     //   184: checkcast 276	[[D
/*      */     //   187: astore 33
/*      */     //   189: goto +31 -> 220
/*      */     //   192: aload_0
/*      */     //   193: aload_1
/*      */     //   194: aload_2
/*      */     //   195: aload_3
/*      */     //   196: getstatic 274	com/dukascopy/api/indicators/InputParameterInfo$Type:PRICE	Lcom/dukascopy/api/indicators/InputParameterInfo$Type;
/*      */     //   199: aconst_null
/*      */     //   200: lload 21
/*      */     //   202: lload 23
/*      */     //   204: iload 27
/*      */     //   206: iconst_0
/*      */     //   207: iconst_0
/*      */     //   208: iconst_0
/*      */     //   209: invokevirtual 290	com/dukascopy/api/impl/Indicators:getInputData	(Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;Lcom/dukascopy/api/OfferSide;Lcom/dukascopy/api/indicators/InputParameterInfo$Type;Lcom/dukascopy/api/IIndicators$AppliedPrice;JJIIZI)Ljava/lang/Object;
/*      */     //   212: checkcast 276	[[D
/*      */     //   215: checkcast 276	[[D
/*      */     //   218: astore 33
/*      */     //   220: aload 33
/*      */     //   222: iconst_0
/*      */     //   223: aaload
/*      */     //   224: arraylength
/*      */     //   225: istore 34
/*      */     //   227: iload 34
/*      */     //   229: iload 30
/*      */     //   231: if_icmpgt +6 -> 237
/*      */     //   234: goto +127 -> 361
/*      */     //   237: iload 34
/*      */     //   239: istore 30
/*      */     //   241: aload 26
/*      */     //   243: iconst_0
/*      */     //   244: aload 33
/*      */     //   246: invokeinterface 279 3 0
/*      */     //   251: iload 34
/*      */     //   253: iload 28
/*      */     //   255: isub
/*      */     //   256: newarray <illegal type>
/*      */     //   258: astore 31
/*      */     //   260: aload 26
/*      */     //   262: iconst_0
/*      */     //   263: aload 31
/*      */     //   265: invokeinterface 280 3 0
/*      */     //   270: aload 26
/*      */     //   272: iconst_0
/*      */     //   273: iload 34
/*      */     //   275: iconst_1
/*      */     //   276: isub
/*      */     //   277: invokeinterface 281 3 0
/*      */     //   282: astore 32
/*      */     //   284: aload 32
/*      */     //   286: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   289: ifne +6 -> 295
/*      */     //   292: goto +69 -> 361
/*      */     //   295: aload 31
/*      */     //   297: iconst_0
/*      */     //   298: daload
/*      */     //   299: dconst_0
/*      */     //   300: dcmpl
/*      */     //   301: ifle +7 -> 308
/*      */     //   304: iconst_1
/*      */     //   305: goto +4 -> 309
/*      */     //   308: iconst_0
/*      */     //   309: istore 35
/*      */     //   311: iconst_1
/*      */     //   312: istore 36
/*      */     //   314: iload 36
/*      */     //   316: aload 32
/*      */     //   318: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   321: if_icmpge +35 -> 356
/*      */     //   324: aload 31
/*      */     //   326: iload 36
/*      */     //   328: daload
/*      */     //   329: dconst_0
/*      */     //   330: dcmpl
/*      */     //   331: ifle +7 -> 338
/*      */     //   334: iconst_1
/*      */     //   335: goto +4 -> 339
/*      */     //   338: iconst_0
/*      */     //   339: iload 35
/*      */     //   341: if_icmpeq +9 -> 350
/*      */     //   344: iconst_1
/*      */     //   345: istore 29
/*      */     //   347: goto +9 -> 356
/*      */     //   350: iinc 36 1
/*      */     //   353: goto -39 -> 314
/*      */     //   356: iload 29
/*      */     //   358: ifeq -217 -> 141
/*      */     //   361: aload 32
/*      */     //   363: ifnull +11 -> 374
/*      */     //   366: aload 32
/*      */     //   368: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   371: ifgt +19 -> 390
/*      */     //   374: aload 31
/*      */     //   376: astore 33
/*      */     //   378: aload_0
/*      */     //   379: ldc_w 271
/*      */     //   382: aload 25
/*      */     //   384: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   387: aload 33
/*      */     //   389: areturn
/*      */     //   390: aload_2
/*      */     //   391: invokevirtual 291	com/dukascopy/api/Period:isTickBasedPeriod	()Z
/*      */     //   394: ifeq +9 -> 403
/*      */     //   397: getstatic 292	com/dukascopy/api/Period:ONE_SEC	Lcom/dukascopy/api/Period;
/*      */     //   400: goto +4 -> 404
/*      */     //   403: aload_2
/*      */     //   404: lload 21
/*      */     //   406: lload 23
/*      */     //   408: invokestatic 293	com/dukascopy/charts/data/datacache/DataCacheUtils:getCandlesCountBetweenFast	(Lcom/dukascopy/api/Period;JJ)I
/*      */     //   411: istore 33
/*      */     //   413: iload 33
/*      */     //   415: aload 32
/*      */     //   417: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   420: if_icmple +11 -> 431
/*      */     //   423: aload 32
/*      */     //   425: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   428: goto +5 -> 433
/*      */     //   431: iload 33
/*      */     //   433: istore 34
/*      */     //   435: iload 34
/*      */     //   437: newarray <illegal type>
/*      */     //   439: astore 35
/*      */     //   441: aload 31
/*      */     //   443: aload 32
/*      */     //   445: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   448: iload 34
/*      */     //   450: isub
/*      */     //   451: aload 35
/*      */     //   453: iconst_0
/*      */     //   454: iload 34
/*      */     //   456: invokestatic 202	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   459: aload 35
/*      */     //   461: astore 36
/*      */     //   463: aload_0
/*      */     //   464: ldc_w 271
/*      */     //   467: aload 25
/*      */     //   469: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   472: aload 36
/*      */     //   474: areturn
/*      */     //   475: astore 37
/*      */     //   477: aload_0
/*      */     //   478: ldc_w 271
/*      */     //   481: aload 25
/*      */     //   483: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   486: aload 37
/*      */     //   488: athrow
/*      */     //   489: astore 25
/*      */     //   491: aload 25
/*      */     //   493: athrow
/*      */     //   494: astore 25
/*      */     //   496: aload 25
/*      */     //   498: invokevirtual 284	com/dukascopy/api/impl/TaLibException:getCause	()Ljava/lang/Throwable;
/*      */     //   501: astore 26
/*      */     //   503: new 61	com/dukascopy/api/JFException
/*      */     //   506: dup
/*      */     //   507: aload 26
/*      */     //   509: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   512: athrow
/*      */     //   513: astore 25
/*      */     //   515: aload 25
/*      */     //   517: athrow
/*      */     //   518: astore 25
/*      */     //   520: new 61	com/dukascopy/api/JFException
/*      */     //   523: dup
/*      */     //   524: aload 25
/*      */     //   526: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   529: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3391	-> byte code offset #0
/*      */     //   Java source line #3392	-> byte code offset #13
/*      */     //   Java source line #3394	-> byte code offset #22
/*      */     //   Java source line #3396	-> byte code offset #31
/*      */     //   Java source line #3397	-> byte code offset #38
/*      */     //   Java source line #3401	-> byte code offset #115
/*      */     //   Java source line #3402	-> byte code offset #127
/*      */     //   Java source line #3403	-> byte code offset #130
/*      */     //   Java source line #3404	-> byte code offset #133
/*      */     //   Java source line #3405	-> byte code offset #138
/*      */     //   Java source line #3408	-> byte code offset #141
/*      */     //   Java source line #3410	-> byte code offset #147
/*      */     //   Java source line #3411	-> byte code offset #160
/*      */     //   Java source line #3414	-> byte code offset #192
/*      */     //   Java source line #3416	-> byte code offset #220
/*      */     //   Java source line #3417	-> byte code offset #227
/*      */     //   Java source line #3419	-> byte code offset #234
/*      */     //   Java source line #3421	-> byte code offset #237
/*      */     //   Java source line #3423	-> byte code offset #241
/*      */     //   Java source line #3424	-> byte code offset #251
/*      */     //   Java source line #3426	-> byte code offset #260
/*      */     //   Java source line #3427	-> byte code offset #270
/*      */     //   Java source line #3429	-> byte code offset #284
/*      */     //   Java source line #3430	-> byte code offset #292
/*      */     //   Java source line #3433	-> byte code offset #295
/*      */     //   Java source line #3434	-> byte code offset #311
/*      */     //   Java source line #3435	-> byte code offset #324
/*      */     //   Java source line #3436	-> byte code offset #344
/*      */     //   Java source line #3437	-> byte code offset #347
/*      */     //   Java source line #3434	-> byte code offset #350
/*      */     //   Java source line #3440	-> byte code offset #356
/*      */     //   Java source line #3442	-> byte code offset #361
/*      */     //   Java source line #3443	-> byte code offset #374
/*      */     //   Java source line #3454	-> byte code offset #378
/*      */     //   Java source line #3446	-> byte code offset #390
/*      */     //   Java source line #3447	-> byte code offset #413
/*      */     //   Java source line #3449	-> byte code offset #435
/*      */     //   Java source line #3450	-> byte code offset #441
/*      */     //   Java source line #3452	-> byte code offset #459
/*      */     //   Java source line #3454	-> byte code offset #463
/*      */     //   Java source line #3456	-> byte code offset #489
/*      */     //   Java source line #3457	-> byte code offset #491
/*      */     //   Java source line #3458	-> byte code offset #494
/*      */     //   Java source line #3459	-> byte code offset #496
/*      */     //   Java source line #3460	-> byte code offset #503
/*      */     //   Java source line #3461	-> byte code offset #513
/*      */     //   Java source line #3462	-> byte code offset #515
/*      */     //   Java source line #3463	-> byte code offset #518
/*      */     //   Java source line #3464	-> byte code offset #520
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	530	0	this	Indicators
/*      */     //   0	530	1	instrument	Instrument
/*      */     //   0	530	2	period	Period
/*      */     //   0	530	3	side	OfferSide
/*      */     //   0	530	4	startValue	double
/*      */     //   0	530	6	offsetOnReverse	double
/*      */     //   0	530	8	accelerationInitLong	double
/*      */     //   0	530	10	accelerationLong	double
/*      */     //   0	530	12	accelerationMaxLong	double
/*      */     //   0	530	14	accelerationInitShort	double
/*      */     //   0	530	16	accelerationShort	double
/*      */     //   0	530	18	accelerationMaxShort	double
/*      */     //   0	530	20	filter	Filter
/*      */     //   0	530	21	from	long
/*      */     //   0	530	23	to	long
/*      */     //   29	453	25	indicatorHolder	IndicatorHolder
/*      */     //   489	3	25	e	JFException
/*      */     //   494	3	25	e	TaLibException
/*      */     //   513	3	25	e	RuntimeException
/*      */     //   518	7	25	e	Exception
/*      */     //   36	235	26	indicator	IIndicator
/*      */     //   501	7	26	t	Throwable
/*      */     //   125	80	27	lookback	int
/*      */     //   123	131	28	indicatorLookback	int
/*      */     //   128	229	29	hasPeriodChange	boolean
/*      */     //   131	109	30	previousLength	int
/*      */     //   136	306	31	doubles	double[]
/*      */     //   139	305	32	result	IndicatorResult
/*      */     //   187	3	33	inputData	double[][]
/*      */     //   218	170	33	inputData	double[][]
/*      */     //   411	21	33	numCandles	int
/*      */     //   225	49	34	length	int
/*      */     //   433	22	34	outCount	int
/*      */     //   309	31	35	positive	boolean
/*      */     //   439	21	35	retDoubles	double[]
/*      */     //   312	161	36	i	int
/*      */     //   475	12	37	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   31	378	475	finally
/*      */     //   390	463	475	finally
/*      */     //   475	477	475	finally
/*      */     //   0	387	489	com/dukascopy/api/JFException
/*      */     //   390	472	489	com/dukascopy/api/JFException
/*      */     //   475	489	489	com/dukascopy/api/JFException
/*      */     //   0	387	494	com/dukascopy/api/impl/TaLibException
/*      */     //   390	472	494	com/dukascopy/api/impl/TaLibException
/*      */     //   475	489	494	com/dukascopy/api/impl/TaLibException
/*      */     //   0	387	513	java/lang/RuntimeException
/*      */     //   390	472	513	java/lang/RuntimeException
/*      */     //   475	489	513	java/lang/RuntimeException
/*      */     //   0	387	518	java/lang/Exception
/*      */     //   390	472	518	java/lang/Exception
/*      */     //   475	489	518	java/lang/Exception
/*      */   }
/*      */   
/*      */   public double[] sarExt(Instrument instrument, Period period, OfferSide side, double startValue, double offsetOnReverse, double accelerationInitLong, double accelerationLong, double accelerationMaxLong, double accelerationInitShort, double accelerationShort, double accelerationMaxShort, long from, long to)
/*      */     throws JFException
/*      */   {
/* 3483 */     return sarExt(instrument, period, side, startValue, offsetOnReverse, accelerationInitLong, accelerationLong, accelerationMaxLong, accelerationInitShort, accelerationShort, accelerationMaxShort, null, from, to);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public double[] sarExt(Instrument instrument, Period period, OfferSide side, double startValue, double offsetOnReverse, double accelerationInitLong, double accelerationLong, double accelerationMaxLong, double accelerationInitShort, double accelerationShort, double accelerationMaxShort, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter)
/*      */     throws JFException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_2
/*      */     //   2: invokevirtual 269	com/dukascopy/api/impl/Indicators:checkNotTick	(Lcom/dukascopy/api/Period;)V
/*      */     //   5: aload_0
/*      */     //   6: aload_2
/*      */     //   7: aload_3
/*      */     //   8: invokespecial 294	com/dukascopy/api/impl/Indicators:checkSide	(Lcom/dukascopy/api/Period;Lcom/dukascopy/api/OfferSide;)V
/*      */     //   11: aload_0
/*      */     //   12: iload 21
/*      */     //   14: iload 24
/*      */     //   16: invokespecial 2	com/dukascopy/api/impl/Indicators:checkIntervalValid	(II)V
/*      */     //   19: aload_0
/*      */     //   20: ldc_w 271
/*      */     //   23: invokevirtual 38	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */     //   26: astore 25
/*      */     //   28: aload 25
/*      */     //   30: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   33: astore 26
/*      */     //   35: aload_0
/*      */     //   36: aload 26
/*      */     //   38: bipush 8
/*      */     //   40: anewarray 86	java/lang/Object
/*      */     //   43: dup
/*      */     //   44: iconst_0
/*      */     //   45: dload 4
/*      */     //   47: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   50: aastore
/*      */     //   51: dup
/*      */     //   52: iconst_1
/*      */     //   53: dload 6
/*      */     //   55: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   58: aastore
/*      */     //   59: dup
/*      */     //   60: iconst_2
/*      */     //   61: dload 8
/*      */     //   63: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   66: aastore
/*      */     //   67: dup
/*      */     //   68: iconst_3
/*      */     //   69: dload 10
/*      */     //   71: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   74: aastore
/*      */     //   75: dup
/*      */     //   76: iconst_4
/*      */     //   77: dload 12
/*      */     //   79: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   82: aastore
/*      */     //   83: dup
/*      */     //   84: iconst_5
/*      */     //   85: dload 14
/*      */     //   87: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   90: aastore
/*      */     //   91: dup
/*      */     //   92: bipush 6
/*      */     //   94: dload 16
/*      */     //   96: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   99: aastore
/*      */     //   100: dup
/*      */     //   101: bipush 7
/*      */     //   103: dload 18
/*      */     //   105: invokestatic 106	java/lang/Double:valueOf	(D)Ljava/lang/Double;
/*      */     //   108: aastore
/*      */     //   109: invokevirtual 272	com/dukascopy/api/impl/Indicators:setOptParams	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)V
/*      */     //   112: aload 26
/*      */     //   114: invokeinterface 273 1 0
/*      */     //   119: dup
/*      */     //   120: istore 28
/*      */     //   122: istore 27
/*      */     //   124: iconst_0
/*      */     //   125: istore 29
/*      */     //   127: iconst_0
/*      */     //   128: istore 30
/*      */     //   130: iconst_0
/*      */     //   131: newarray <illegal type>
/*      */     //   133: astore 31
/*      */     //   135: aconst_null
/*      */     //   136: astore 32
/*      */     //   138: wide
/*      */     //   144: aload_0
/*      */     //   145: aload_1
/*      */     //   146: aload_2
/*      */     //   147: aload_3
/*      */     //   148: getstatic 274	com/dukascopy/api/indicators/InputParameterInfo$Type:PRICE	Lcom/dukascopy/api/indicators/InputParameterInfo$Type;
/*      */     //   151: aconst_null
/*      */     //   152: aload 20
/*      */     //   154: iload 21
/*      */     //   156: lload 22
/*      */     //   158: iload 24
/*      */     //   160: iload 27
/*      */     //   162: iconst_0
/*      */     //   163: iconst_0
/*      */     //   164: invokevirtual 295	com/dukascopy/api/impl/Indicators:getInputData	(Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;Lcom/dukascopy/api/OfferSide;Lcom/dukascopy/api/indicators/InputParameterInfo$Type;Lcom/dukascopy/api/IIndicators$AppliedPrice;Lcom/dukascopy/api/Filter;IJIIII)Ljava/lang/Object;
/*      */     //   167: checkcast 276	[[D
/*      */     //   170: checkcast 276	[[D
/*      */     //   173: astore 33
/*      */     //   175: aload 33
/*      */     //   177: iconst_0
/*      */     //   178: aaload
/*      */     //   179: arraylength
/*      */     //   180: istore 34
/*      */     //   182: iload 34
/*      */     //   184: iload 30
/*      */     //   186: if_icmpgt +6 -> 192
/*      */     //   189: goto +127 -> 316
/*      */     //   192: iload 34
/*      */     //   194: istore 30
/*      */     //   196: aload 26
/*      */     //   198: iconst_0
/*      */     //   199: aload 33
/*      */     //   201: invokeinterface 279 3 0
/*      */     //   206: iload 34
/*      */     //   208: iload 28
/*      */     //   210: isub
/*      */     //   211: newarray <illegal type>
/*      */     //   213: astore 31
/*      */     //   215: aload 26
/*      */     //   217: iconst_0
/*      */     //   218: aload 31
/*      */     //   220: invokeinterface 280 3 0
/*      */     //   225: aload 26
/*      */     //   227: iconst_0
/*      */     //   228: iload 34
/*      */     //   230: iconst_1
/*      */     //   231: isub
/*      */     //   232: invokeinterface 281 3 0
/*      */     //   237: astore 32
/*      */     //   239: aload 32
/*      */     //   241: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   244: ifne +6 -> 250
/*      */     //   247: goto +69 -> 316
/*      */     //   250: aload 31
/*      */     //   252: iconst_0
/*      */     //   253: daload
/*      */     //   254: dconst_0
/*      */     //   255: dcmpl
/*      */     //   256: ifle +7 -> 263
/*      */     //   259: iconst_1
/*      */     //   260: goto +4 -> 264
/*      */     //   263: iconst_0
/*      */     //   264: istore 35
/*      */     //   266: iconst_1
/*      */     //   267: istore 36
/*      */     //   269: iload 36
/*      */     //   271: aload 32
/*      */     //   273: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   276: if_icmpge +35 -> 311
/*      */     //   279: aload 31
/*      */     //   281: iload 36
/*      */     //   283: daload
/*      */     //   284: dconst_0
/*      */     //   285: dcmpl
/*      */     //   286: ifle +7 -> 293
/*      */     //   289: iconst_1
/*      */     //   290: goto +4 -> 294
/*      */     //   293: iconst_0
/*      */     //   294: iload 35
/*      */     //   296: if_icmpeq +9 -> 305
/*      */     //   299: iconst_1
/*      */     //   300: istore 29
/*      */     //   302: goto +9 -> 311
/*      */     //   305: iinc 36 1
/*      */     //   308: goto -39 -> 269
/*      */     //   311: iload 29
/*      */     //   313: ifeq -175 -> 138
/*      */     //   316: aload 32
/*      */     //   318: ifnull +11 -> 329
/*      */     //   321: aload 32
/*      */     //   323: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   326: ifgt +19 -> 345
/*      */     //   329: aload 31
/*      */     //   331: astore 33
/*      */     //   333: aload_0
/*      */     //   334: ldc_w 271
/*      */     //   337: aload 25
/*      */     //   339: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   342: aload 33
/*      */     //   344: areturn
/*      */     //   345: iload 21
/*      */     //   347: iload 24
/*      */     //   349: iadd
/*      */     //   350: aload 32
/*      */     //   352: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   355: if_icmple +11 -> 366
/*      */     //   358: aload 32
/*      */     //   360: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   363: goto +8 -> 371
/*      */     //   366: iload 21
/*      */     //   368: iload 24
/*      */     //   370: iadd
/*      */     //   371: istore 33
/*      */     //   373: iload 33
/*      */     //   375: newarray <illegal type>
/*      */     //   377: astore 34
/*      */     //   379: aload 31
/*      */     //   381: aload 32
/*      */     //   383: invokevirtual 282	com/dukascopy/api/indicators/IndicatorResult:getNumberOfElements	()I
/*      */     //   386: iload 33
/*      */     //   388: isub
/*      */     //   389: aload 34
/*      */     //   391: iconst_0
/*      */     //   392: iload 33
/*      */     //   394: invokestatic 202	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   397: aload 34
/*      */     //   399: astore 35
/*      */     //   401: aload_0
/*      */     //   402: ldc_w 271
/*      */     //   405: aload 25
/*      */     //   407: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   410: aload 35
/*      */     //   412: areturn
/*      */     //   413: astore 37
/*      */     //   415: aload_0
/*      */     //   416: ldc_w 271
/*      */     //   419: aload 25
/*      */     //   421: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   424: aload 37
/*      */     //   426: athrow
/*      */     //   427: astore 25
/*      */     //   429: aload 25
/*      */     //   431: athrow
/*      */     //   432: astore 25
/*      */     //   434: aload 25
/*      */     //   436: invokevirtual 284	com/dukascopy/api/impl/TaLibException:getCause	()Ljava/lang/Throwable;
/*      */     //   439: astore 26
/*      */     //   441: new 61	com/dukascopy/api/JFException
/*      */     //   444: dup
/*      */     //   445: aload 26
/*      */     //   447: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   450: athrow
/*      */     //   451: astore 25
/*      */     //   453: aload 25
/*      */     //   455: athrow
/*      */     //   456: astore 25
/*      */     //   458: new 61	com/dukascopy/api/JFException
/*      */     //   461: dup
/*      */     //   462: aload 25
/*      */     //   464: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   467: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3506	-> byte code offset #0
/*      */     //   Java source line #3507	-> byte code offset #5
/*      */     //   Java source line #3508	-> byte code offset #11
/*      */     //   Java source line #3510	-> byte code offset #19
/*      */     //   Java source line #3512	-> byte code offset #28
/*      */     //   Java source line #3513	-> byte code offset #35
/*      */     //   Java source line #3517	-> byte code offset #112
/*      */     //   Java source line #3518	-> byte code offset #124
/*      */     //   Java source line #3519	-> byte code offset #127
/*      */     //   Java source line #3520	-> byte code offset #130
/*      */     //   Java source line #3521	-> byte code offset #135
/*      */     //   Java source line #3524	-> byte code offset #138
/*      */     //   Java source line #3525	-> byte code offset #144
/*      */     //   Java source line #3526	-> byte code offset #175
/*      */     //   Java source line #3527	-> byte code offset #182
/*      */     //   Java source line #3529	-> byte code offset #189
/*      */     //   Java source line #3531	-> byte code offset #192
/*      */     //   Java source line #3532	-> byte code offset #196
/*      */     //   Java source line #3533	-> byte code offset #206
/*      */     //   Java source line #3534	-> byte code offset #215
/*      */     //   Java source line #3535	-> byte code offset #225
/*      */     //   Java source line #3536	-> byte code offset #239
/*      */     //   Java source line #3538	-> byte code offset #247
/*      */     //   Java source line #3540	-> byte code offset #250
/*      */     //   Java source line #3541	-> byte code offset #266
/*      */     //   Java source line #3542	-> byte code offset #279
/*      */     //   Java source line #3543	-> byte code offset #299
/*      */     //   Java source line #3544	-> byte code offset #302
/*      */     //   Java source line #3541	-> byte code offset #305
/*      */     //   Java source line #3547	-> byte code offset #311
/*      */     //   Java source line #3549	-> byte code offset #316
/*      */     //   Java source line #3550	-> byte code offset #329
/*      */     //   Java source line #3561	-> byte code offset #333
/*      */     //   Java source line #3553	-> byte code offset #345
/*      */     //   Java source line #3556	-> byte code offset #373
/*      */     //   Java source line #3557	-> byte code offset #379
/*      */     //   Java source line #3559	-> byte code offset #397
/*      */     //   Java source line #3561	-> byte code offset #401
/*      */     //   Java source line #3563	-> byte code offset #427
/*      */     //   Java source line #3564	-> byte code offset #429
/*      */     //   Java source line #3565	-> byte code offset #432
/*      */     //   Java source line #3566	-> byte code offset #434
/*      */     //   Java source line #3567	-> byte code offset #441
/*      */     //   Java source line #3568	-> byte code offset #451
/*      */     //   Java source line #3569	-> byte code offset #453
/*      */     //   Java source line #3570	-> byte code offset #456
/*      */     //   Java source line #3571	-> byte code offset #458
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	468	0	this	Indicators
/*      */     //   0	468	1	instrument	Instrument
/*      */     //   0	468	2	period	Period
/*      */     //   0	468	3	side	OfferSide
/*      */     //   0	468	4	startValue	double
/*      */     //   0	468	6	offsetOnReverse	double
/*      */     //   0	468	8	accelerationInitLong	double
/*      */     //   0	468	10	accelerationLong	double
/*      */     //   0	468	12	accelerationMaxLong	double
/*      */     //   0	468	14	accelerationInitShort	double
/*      */     //   0	468	16	accelerationShort	double
/*      */     //   0	468	18	accelerationMaxShort	double
/*      */     //   0	468	20	filter	Filter
/*      */     //   0	468	21	numberOfCandlesBefore	int
/*      */     //   0	468	22	time	long
/*      */     //   0	468	24	numberOfCandlesAfter	int
/*      */     //   26	394	25	indicatorHolder	IndicatorHolder
/*      */     //   427	3	25	e	JFException
/*      */     //   432	3	25	e	TaLibException
/*      */     //   451	3	25	e	RuntimeException
/*      */     //   456	7	25	e	Exception
/*      */     //   33	193	26	indicator	IIndicator
/*      */     //   439	7	26	t	Throwable
/*      */     //   122	39	27	lookback	int
/*      */     //   120	89	28	indicatorLookback	int
/*      */     //   125	187	29	hasPeriodChange	boolean
/*      */     //   128	67	30	previousLength	int
/*      */     //   133	247	31	doubles	double[]
/*      */     //   136	246	32	result	IndicatorResult
/*      */     //   173	170	33	inputData	double[][]
/*      */     //   371	22	33	outCount	int
/*      */     //   180	49	34	length	int
/*      */     //   377	21	34	retDoubles	double[]
/*      */     //   264	147	35	positive	boolean
/*      */     //   267	39	36	i	int
/*      */     //   413	12	37	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   28	333	413	finally
/*      */     //   345	401	413	finally
/*      */     //   413	415	413	finally
/*      */     //   0	342	427	com/dukascopy/api/JFException
/*      */     //   345	410	427	com/dukascopy/api/JFException
/*      */     //   413	427	427	com/dukascopy/api/JFException
/*      */     //   0	342	432	com/dukascopy/api/impl/TaLibException
/*      */     //   345	410	432	com/dukascopy/api/impl/TaLibException
/*      */     //   413	427	432	com/dukascopy/api/impl/TaLibException
/*      */     //   0	342	451	java/lang/RuntimeException
/*      */     //   345	410	451	java/lang/RuntimeException
/*      */     //   413	427	451	java/lang/RuntimeException
/*      */     //   0	342	456	java/lang/Exception
/*      */     //   345	410	456	java/lang/Exception
/*      */     //   413	427	456	java/lang/Exception
/*      */   }
/*      */   
/*      */   public double sin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift)
/*      */     throws JFException
/*      */   {
/* 3576 */     return ((Double)function(instrument, period, side, "SIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] sin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 3580 */     return (double[])function(instrument, period, side, "SIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] sin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3584 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] sin(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 3588 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SIN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double sinh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 3592 */     return ((Double)function(instrument, period, side, "SINH", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] sinh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 3596 */     return (double[])function(instrument, period, side, "SINH", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] sinh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3601 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SINH", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] sinh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 3605 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SINH", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double sma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3609 */     return ((Double)function(instrument, period, side, "SMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] sma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3613 */     return (double[])function(instrument, period, side, "SMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] sma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3617 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] sma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3621 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] smi(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, int slowDPeriod, int smoothingPeriod, int shift) throws JFException {
/* 3625 */     Object[] ret = function(instrument, period, side, "SMI", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowDPeriod), Integer.valueOf(smoothingPeriod) }, shift);
/* 3626 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] smi(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, int slowDPeriod, int smoothingPeriod, long from, long to) throws JFException {
/* 3630 */     Object[] ret = function(instrument, period, side, "SMI", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowDPeriod), Integer.valueOf(smoothingPeriod) }, from, to);
/* 3631 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] smi(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, int slowDPeriod, int smoothingPeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3635 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "SMI", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowDPeriod), Integer.valueOf(smoothingPeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3636 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] smi(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, int slowDPeriod, int smoothingPeriod, Filter filter, long from, long to) throws JFException {
/* 3640 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "SMI", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowDPeriod), Integer.valueOf(smoothingPeriod) }, filter, from, to);
/* 3641 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double smma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3645 */     return ((Double)function(instrument, period, side, "SMMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] smma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3649 */     return (double[])function(instrument, period, side, "SMMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] smma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3653 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SMMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] smma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3657 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SMMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double sqrt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 3661 */     return ((Double)function(instrument, period, side, "SQRT", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] sqrt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 3665 */     return (double[])function(instrument, period, side, "SQRT", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] sqrt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3670 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SQRT", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] sqrt(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 3674 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SQRT", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double stdDev(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, int shift) throws JFException {
/* 3678 */     return ((Double)function(instrument, period, side, "STDDEV", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] stdDev(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, long from, long to) throws JFException {
/* 3682 */     return (double[])function(instrument, period, side, "STDDEV", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] stdDev(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3686 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "STDDEV", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] stdDev(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, Filter filter, long from, long to) throws JFException {
/* 3690 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "STDDEV", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] stoch(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, IIndicators.MaType slowKMaType, int slowDPeriod, IIndicators.MaType slowDMaType, int shift) throws JFException {
/* 3694 */     Object[] ret = function(instrument, period, side, "STOCH", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()) }, shift);
/* 3695 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] stoch(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, IIndicators.MaType slowKMaType, int slowDPeriod, IIndicators.MaType slowDMaType, long from, long to) throws JFException {
/* 3699 */     Object[] ret = function(instrument, period, side, "STOCH", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()) }, from, to);
/* 3700 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] stoch(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, IIndicators.MaType slowKMaType, int slowDPeriod, IIndicators.MaType slowDMaType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3704 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "STOCH", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3705 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] stoch(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int slowKPeriod, IIndicators.MaType slowKMaType, int slowDPeriod, IIndicators.MaType slowDMaType, Filter filter, long from, long to) throws JFException {
/* 3709 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "STOCH", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()) }, filter, from, to);
/* 3710 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[] stochF(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, int shift) throws JFException {
/* 3714 */     Object[] ret = function(instrument, period, side, "STOCHF", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, shift);
/* 3715 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] stochF(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, long from, long to) throws JFException {
/* 3719 */     Object[] ret = function(instrument, period, side, "STOCHF", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, from, to);
/* 3720 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] stochF(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3724 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "STOCHF", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3725 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] stochF(Instrument instrument, Period period, OfferSide side, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, Filter filter, long from, long to) throws JFException {
/* 3729 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "STOCHF", null, new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, filter, from, to);
/* 3730 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[] stochRsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, int shift) throws JFException {
/* 3734 */     Object[] ret = function(instrument, period, side, "STOCHRSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, shift);
/* 3735 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] stochRsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, long from, long to) throws JFException {
/* 3739 */     Object[] ret = function(instrument, period, side, "STOCHRSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, from, to);
/* 3740 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] stochRsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3744 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "STOCHRSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3745 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] stochRsi(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType, Filter filter, long from, long to) throws JFException {
/* 3749 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "STOCHRSI", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) }, filter, from, to);
/* 3750 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double sub(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, int shift) throws JFException {
/* 3754 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "SUB", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] sub(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, long from, long to) throws JFException {
/* 3758 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "SUB", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] sub(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3762 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "SUB", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] sub(Instrument instrument, Period period, OfferSide side1, IIndicators.AppliedPrice appliedPrice1, OfferSide side2, IIndicators.AppliedPrice appliedPrice2, Filter filter, long from, long to) throws JFException {
/* 3766 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side1, side2 }, "SUB", new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double sum(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3770 */     return ((Double)function(instrument, period, side, "SUM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] sum(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3774 */     return (double[])function(instrument, period, side, "SUM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] sum(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3778 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SUM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] sum(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3782 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "SUM", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] supportResistance(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 3786 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "S&R", null, null, shift);
/* 3787 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] supportResistance(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 3791 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "S&R", null, null, from, to);
/* 3792 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] supportResistance(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3796 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "S&R", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3797 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] supportResistance(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 3801 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "S&R", null, null, filter, from, to);
/* 3802 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double t3(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double factor, int shift) throws JFException
/*      */   {
/* 3807 */     return ((Double)function(instrument, period, side, "T3", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(factor) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] t3(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double factor, long from, long to) throws JFException {
/* 3811 */     return (double[])function(instrument, period, side, "T3", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(factor) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] t3(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double factor, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3816 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "T3", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(factor) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] t3(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double factor, Filter filter, long from, long to) throws JFException {
/* 3820 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "T3", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(factor) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double tan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 3824 */     return ((Double)function(instrument, period, side, "TAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] tan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 3828 */     return (double[])function(instrument, period, side, "TAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] tan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3833 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] tan(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 3837 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TAN", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double tanh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 3841 */     return ((Double)function(instrument, period, side, "TANH", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] tanh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, long from, long to) throws JFException {
/* 3845 */     return (double[])function(instrument, period, side, "TANH", new IIndicators.AppliedPrice[] { appliedPrice }, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] tanh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3850 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TANH", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] tanh(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to) throws JFException {
/* 3854 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TANH", new IIndicators.AppliedPrice[] { appliedPrice }, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] tbp(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 3858 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "THRUSTBAR", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift);
/* 3859 */     return new double[] { ((Integer)ret[0]).intValue(), ((Integer)ret[1]).intValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[] tbop(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int shift) throws JFException {
/* 3863 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "THRUSTOUTSIDEBAR", new IIndicators.AppliedPrice[] { appliedPrice }, null, shift);
/* 3864 */     return new double[] { ((Integer)ret[0]).intValue(), ((Integer)ret[1]).intValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[] td_i(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 3868 */     Object[] ret = function(instrument, period, side, "TD_I", null, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 3869 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] td_i(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 3873 */     Object[] ret = function(instrument, period, side, "TD_I", null, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 3874 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] td_i(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3878 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "TD_I", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3879 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public double[][] td_i(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3883 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "TD_I", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 3884 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2] };
/*      */   }
/*      */   
/*      */   public int[] td_s(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3888 */     Object[] ret = function(instrument, period, side, "TD_S", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 3889 */     return new int[] { ((Integer)ret[0]).intValue(), ((Integer)ret[1]).intValue() };
/*      */   }
/*      */   
/*      */   public int[][] td_s(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3893 */     Object[] ret = function(instrument, period, side, "TD_S", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 3894 */     return new int[][] { (int[])(int[])ret[0], (int[])(int[])ret[1] };
/*      */   }
/*      */   
/*      */   public int[][] td_s(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3898 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "TD_S", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3899 */     return new int[][] { (int[])(int[])ret[0], (int[])(int[])ret[1] };
/*      */   }
/*      */   
/*      */   public int[][] td_s(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3903 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "TD_S", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 3904 */     return new int[][] { (int[])(int[])ret[0], (int[])(int[])ret[1] };
/*      */   }
/*      */   
/*      */   public double tema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3908 */     return ((Double)function(instrument, period, side, "TEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] tema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3912 */     return (double[])function(instrument, period, side, "TEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] tema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3916 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] tema(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3920 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TEMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double trange(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 3924 */     return ((Double)function(instrument, period, side, "TRANGE", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] trange(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 3928 */     return (double[])function(instrument, period, side, "TRANGE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] trange(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3932 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TRANGE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] trange(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 3936 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TRANGE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] trendEnv(Instrument instrument, Period period, OfferSide side, int timePeriod, double deviation, int shift) throws JFException {
/* 3940 */     Object[] res = function(instrument, period, side, "TrendEnvelopes", null, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, shift);
/* 3941 */     return new double[] { ((Double)res[0]).doubleValue(), ((Double)res[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] trendEnv(Instrument instrument, Period period, OfferSide side, int timePeriod, double deviation, long from, long to) throws JFException {
/* 3945 */     Object[] res = function(instrument, period, side, "TrendEnvelopes", null, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, from, to);
/* 3946 */     return new double[][] { (double[])(double[])res[0], (double[])(double[])res[1] };
/*      */   }
/*      */   
/*      */   public double[][] trendEnv(Instrument instrument, Period period, OfferSide side, int timePeriod, double deviation, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3950 */     Object[] res = calculateIndicator(instrument, period, new OfferSide[] { side }, "TrendEnvelopes", null, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 3951 */     return new double[][] { (double[])(double[])res[0], (double[])(double[])res[1] };
/*      */   }
/*      */   
/*      */   public double[][] trendEnv(Instrument instrument, Period period, OfferSide side, int timePeriod, double deviation, Filter filter, long from, long to) throws JFException {
/* 3955 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "TrendEnvelopes", null, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) }, filter, from, to);
/* 3956 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double trima(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException
/*      */   {
/* 3961 */     return ((Double)function(instrument, period, side, "TRIMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] trima(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3965 */     return (double[])function(instrument, period, side, "TRIMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] trima(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException
/*      */   {
/* 3970 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TRIMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] trima(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3974 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TRIMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double trix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3978 */     return ((Double)function(instrument, period, side, "TRIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] trix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3982 */     return (double[])function(instrument, period, side, "TRIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] trix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 3986 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TRIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] trix(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 3990 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TRIX", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double tsf(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 3994 */     return ((Double)function(instrument, period, side, "TSF", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] tsf(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 3998 */     return (double[])function(instrument, period, side, "TSF", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] tsf(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4002 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TSF", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] tsf(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4006 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TSF", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double tvs(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 4010 */     return ((Double)function(instrument, period, side, "TVS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] tvs(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 4014 */     return (double[])function(instrument, period, side, "TVS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] tvs(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4018 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TVS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] tvs(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4022 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TVS", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double typPrice(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 4026 */     return ((Double)function(instrument, period, side, "TYPPRICE", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] typPrice(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 4030 */     return (double[])function(instrument, period, side, "TYPPRICE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] typPrice(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4034 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TYPPRICE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] typPrice(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 4038 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "TYPPRICE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double ultOsc(Instrument instrument, Period period, OfferSide side, int timePeriod1, int timePeriod2, int timePeriod3, int shift) throws JFException {
/* 4042 */     return ((Double)function(instrument, period, side, "ULTOSC", null, new Object[] { Integer.valueOf(timePeriod1), Integer.valueOf(timePeriod2), Integer.valueOf(timePeriod3) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] ultOsc(Instrument instrument, Period period, OfferSide side, int timePeriod1, int timePeriod2, int timePeriod3, long from, long to) throws JFException {
/* 4046 */     return (double[])function(instrument, period, side, "ULTOSC", null, new Object[] { Integer.valueOf(timePeriod1), Integer.valueOf(timePeriod2), Integer.valueOf(timePeriod3) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] ultOsc(Instrument instrument, Period period, OfferSide side, int timePeriod1, int timePeriod2, int timePeriod3, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4050 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ULTOSC", null, new Object[] { Integer.valueOf(timePeriod1), Integer.valueOf(timePeriod2), Integer.valueOf(timePeriod3) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] ultOsc(Instrument instrument, Period period, OfferSide side, int timePeriod1, int timePeriod2, int timePeriod3, Filter filter, long from, long to) throws JFException {
/* 4054 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ULTOSC", null, new Object[] { Integer.valueOf(timePeriod1), Integer.valueOf(timePeriod2), Integer.valueOf(timePeriod3) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double var(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, int shift) throws JFException {
/* 4058 */     return ((Double)function(instrument, period, side, "VAR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] var(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, long from, long to) throws JFException {
/* 4062 */     return (double[])function(instrument, period, side, "VAR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] var(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4066 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "VAR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] var(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, double nbDev, Filter filter, long from, long to) throws JFException {
/* 4070 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "VAR", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double volume(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 4074 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "Volume", null, null, shift);
/* 4075 */     return ((Double)ret[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] volume(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 4079 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "Volume", null, null, from, to);
/* 4080 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] volume(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4084 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "Volume", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 4085 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] volume(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 4089 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "Volume", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double volumeWAP(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 4093 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "VolumeWAP", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 4094 */     return ((Double)ret[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] volumeWAP(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 4098 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "VolumeWAP", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 4099 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] volumeWAP(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4103 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "VolumeWAP", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 4104 */     return (double[])ret[0];
/*      */   }
/*      */   
/*      */   public double[] volumeWAP(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4108 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side, side }, "VolumeWAP", new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] vortex(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 4112 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "VORTEX", null, new Object[] { Integer.valueOf(timePeriod) }, shift);
/* 4113 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] vortex(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 4117 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "VORTEX", null, new Object[] { Integer.valueOf(timePeriod) }, from, to);
/* 4118 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] vortex(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4122 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "VORTEX", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 4123 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double[][] vortex(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4127 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side }, "VORTEX", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to);
/* 4128 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1] };
/*      */   }
/*      */   
/*      */   public double waddahAttar(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 4132 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side }, "WADDAHAT", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] waddahAttar(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 4136 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WADDAHAT", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] waddahAttar(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4140 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WADDAHAT", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] waddahAttar(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 4144 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WADDAHAT", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double wclPrice(Instrument instrument, Period period, OfferSide side, int shift) throws JFException {
/* 4148 */     return ((Double)function(instrument, period, side, "WCLPRICE", null, null, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] wclPrice(Instrument instrument, Period period, OfferSide side, long from, long to) throws JFException {
/* 4152 */     return (double[])function(instrument, period, side, "WCLPRICE", null, null, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] wclPrice(Instrument instrument, Period period, OfferSide side, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4156 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WCLPRICE", null, null, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] wclPrice(Instrument instrument, Period period, OfferSide side, Filter filter, long from, long to) throws JFException {
/* 4160 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WCLPRICE", null, null, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double willr(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 4164 */     return ((Double)function(instrument, period, side, "WILLR", null, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] willr(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 4168 */     return (double[])function(instrument, period, side, "WILLR", null, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] willr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4172 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WILLR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] willr(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4176 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WILLR", null, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   public double wma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, int shift) throws JFException {
/* 4180 */     return ((Double)function(instrument, period, side, "WMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] wma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, long from, long to) throws JFException {
/* 4184 */     return (double[])function(instrument, period, side, "WMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] wma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4188 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] wma(Instrument instrument, Period period, OfferSide side, IIndicators.AppliedPrice appliedPrice, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4192 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "WMA", new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[] woodPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, int shift) throws JFException {
/* 4197 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 4198 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { mappedPeriod }, shift);
/* 4199 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue() };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] woodPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, long from, long to) throws JFException {
/* 4204 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 4205 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { mappedPeriod }, from, to);
/* 4206 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] woodPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4211 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 4212 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { mappedPeriod }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 4213 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public double[][] woodPivot(Instrument instrument, Period period, OfferSide side, int timePeriod, Filter filter, long from, long to) throws JFException {
/* 4218 */     Period mappedPeriod = IndicatorHelper.PeriodParameterMapper.mapToPredefPeriodOrdinal(timePeriod);
/* 4219 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { mappedPeriod }, filter, from, to);
/* 4220 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[] woodPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, int shift) throws JFException {
/* 4224 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { timePeriod }, shift);
/* 4225 */     return new double[] { ((Double)ret[0]).doubleValue(), ((Double)ret[1]).doubleValue(), ((Double)ret[2]).doubleValue(), ((Double)ret[3]).doubleValue(), ((Double)ret[4]).doubleValue(), ((Double)ret[5]).doubleValue(), ((Double)ret[6]).doubleValue() };
/*      */   }
/*      */   
/*      */   public double[][] woodPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, long from, long to) throws JFException {
/* 4229 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { timePeriod }, from, to);
/* 4230 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[][] woodPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4234 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { timePeriod }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter);
/* 4235 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double[][] woodPivot(Instrument instrument, Period period, OfferSide side, Period timePeriod, Filter filter, long from, long to) throws JFException {
/* 4239 */     Object[] ret = calculateIndicator(instrument, period, new OfferSide[] { side, side }, "WOODPIVOT", null, new Object[] { timePeriod }, filter, from, to);
/* 4240 */     return new double[][] { (double[])(double[])ret[0], (double[])(double[])ret[1], (double[])(double[])ret[2], (double[])(double[])ret[3], (double[])(double[])ret[4], (double[])(double[])ret[5], (double[])(double[])ret[6] };
/*      */   }
/*      */   
/*      */   public double zigzag(Instrument instrument, Period period, OfferSide side, int extDepth, int extDeviation, int extBackstep, int shift) throws JFException {
/* 4244 */     return ((Double)calculateIndicator(instrument, period, new OfferSide[] { side }, "ZIGZAG", null, new Object[] { Integer.valueOf(extDepth), Integer.valueOf(extDeviation), Integer.valueOf(extBackstep) }, shift)[0]).doubleValue();
/*      */   }
/*      */   
/*      */   public double[] zigzag(Instrument instrument, Period period, OfferSide side, int extDepth, int extDeviation, int extBackstep, long from, long to) throws JFException {
/* 4248 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ZIGZAG", null, new Object[] { Integer.valueOf(extDepth), Integer.valueOf(extDeviation), Integer.valueOf(extBackstep) }, from, to)[0];
/*      */   }
/*      */   
/*      */   public double[] zigzag(Instrument instrument, Period period, OfferSide side, int extDepth, int extDeviation, int extBackstep, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter) throws JFException {
/* 4252 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ZIGZAG", null, new Object[] { Integer.valueOf(extDepth), Integer.valueOf(extDeviation), Integer.valueOf(extBackstep) }, filter, numberOfCandlesBefore, time, numberOfCandlesAfter)[0];
/*      */   }
/*      */   
/*      */   public double[] zigzag(Instrument instrument, Period period, OfferSide side, int extDepth, int extDeviation, int extBackstep, Filter filter, long from, long to) throws JFException {
/* 4256 */     return (double[])calculateIndicator(instrument, period, new OfferSide[] { side }, "ZIGZAG", null, new Object[] { Integer.valueOf(extDepth), Integer.valueOf(extDeviation), Integer.valueOf(extBackstep) }, filter, from, to)[0];
/*      */   }
/*      */   
/*      */   protected IndicatorHolder getCachedIndicator(String name)
/*      */     throws JFException
/*      */   {
/* 4262 */     IndicatorHolder indicatorHolder = (IndicatorHolder)this.cachedIndicators.remove(name);
/* 4263 */     if (indicatorHolder == null) {
/* 4264 */       indicatorHolder = getCustomIndicatorHolder(name);
/* 4265 */       if (indicatorHolder == null) {
/* 4266 */         indicatorHolder = IndicatorsProvider.getInstance().getIndicatorHolder(name, this.history, this.notificationUtils, null);
/*      */       }
/*      */     }
/* 4269 */     return indicatorHolder;
/*      */   }
/*      */   
/*      */   private IIndicator getCustomIndicator(String customIndicatorName) throws JFException {
/* 4273 */     if (this.customIndicators.containsKey(customIndicatorName)) {
/* 4274 */       IIndicator custom = null;
/*      */       try {
/* 4276 */         custom = (IIndicator)((Class)this.customIndicators.get(customIndicatorName)).newInstance();
/*      */       } catch (Throwable th) {
/* 4278 */         throw new JFException("Error while creating custom indicator [" + customIndicatorName + "] instance");
/*      */       }
/*      */       try {
/* 4281 */         custom.onStart(IndicatorHelper.createIndicatorContext(this.history, this.notificationUtils));
/* 4282 */         return custom;
/*      */       } catch (Throwable th) {
/* 4284 */         throw new JFException("Exception in onStart method");
/*      */       }
/*      */     }
/* 4287 */     return null;
/*      */   }
/*      */   
/*      */   private IndicatorHolder getCustomIndicatorHolder(String customIndicatorName) throws JFException {
/* 4291 */     IIndicator indicator = getCustomIndicator(customIndicatorName);
/* 4292 */     if (indicator != null) {
/* 4293 */       return new IndicatorHolder(indicator, IndicatorHelper.createIndicatorContext(this.history, this.notificationUtils));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4299 */     return null;
/*      */   }
/*      */   
/*      */   protected void cacheIndicator(String name, IndicatorHolder indicator) {
/* 4303 */     this.cachedIndicators.put(name, indicator);
/*      */   }
/*      */   
/*      */   private Object[] function(Instrument instrument, Period period, OfferSide side, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, int shift) throws JFException
/*      */   {
/* 4308 */     return calculateIndicator(instrument, period, new OfferSide[] { side }, functionName, inputTypes, optParams, shift);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] calculateIndicator(Instrument instrument, Period period, OfferSide[] side, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, int shift)
/*      */     throws JFException
/*      */   {
/* 4320 */     IndicatorHelper.PeriodParameterMapper.performMapping(functionName, optParams);
/* 4321 */     IndicatorCalcShift calc = new IndicatorCalcShift(functionName, instrument, period, side, inputTypes, optParams, shift);
/* 4322 */     return calc.calculate();
/*      */   }
/*      */   
/*      */   protected int[] calculateLookbackLookforward(IIndicator indicator, Object[] optParams) throws JFException {
/* 4326 */     setOptParams(indicator, optParams);
/*      */     int indicatorLookback;
/*      */     int lookback;
/*      */     try {
/* 4330 */       lookback = indicatorLookback = indicator.getLookback();
/*      */     } catch (Throwable t) {
/* 4332 */       LOGGER.error(t.getMessage(), t);
/* 4333 */       String error = StrategyWrapper.representError(indicator, t);
/* 4334 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4335 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4336 */       throw new JFException(t);
/*      */     }
/*      */     int lookforward;
/*      */     try {
/* 4340 */       lookforward = indicator.getLookforward();
/*      */     } catch (AbstractMethodError e) {
/* 4342 */       lookforward = 0;
/*      */     } catch (Throwable t) {
/* 4344 */       LOGGER.error(t.getMessage(), t);
/* 4345 */       String error = StrategyWrapper.representError(indicator, t);
/* 4346 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4347 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4348 */       throw new JFException(t);
/*      */     }
/* 4350 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 4351 */     if (indicatorInfo.isUnstablePeriod())
/*      */     {
/* 4353 */       lookback += (lookback * 4 < 100 ? 100 : lookback * 4);
/*      */     }
/* 4355 */     return new int[] { indicatorLookback, lookback, lookforward };
/*      */   }
/*      */   
/*      */   protected int calculateShift(Instrument instrument, Period childPeriod, Period parentPeriod, int shift) throws JFException {
/* 4359 */     if (parentPeriod == childPeriod) {
/* 4360 */       return shift;
/*      */     }
/* 4362 */     if (shift == 0) {
/* 4363 */       return 0;
/*      */     }
/* 4365 */     long parentLatestBarStartTime = this.history.getStartTimeOfCurrentBar(instrument, parentPeriod);
/* 4366 */     long requestedBarStartTime = DataCacheUtils.getTimeForNCandlesBackFast(parentPeriod, DataCacheUtils.getPreviousCandleStartFast(parentPeriod, parentLatestBarStartTime), shift);
/*      */     
/*      */ 
/* 4369 */     long childLatestBarStartTime = this.history.getStartTimeOfCurrentBar(instrument, childPeriod);
/* 4370 */     requestedBarStartTime = DataCacheUtils.getCandleStartFast(childPeriod, requestedBarStartTime);
/*      */     
/* 4372 */     if (requestedBarStartTime <= childLatestBarStartTime) {
/* 4373 */       return DataCacheUtils.getCandlesCountBetweenFast(childPeriod, requestedBarStartTime, childLatestBarStartTime) - 1;
/*      */     }
/* 4375 */     return -(DataCacheUtils.getCandlesCountBetweenFast(childPeriod, childLatestBarStartTime, requestedBarStartTime) - 1);
/*      */   }
/*      */   
/*      */   private Object[] calculateIndicator(IIndicator indicator, int indicatorLookback, int lookback, int lookforward, int inputLength) throws JFException
/*      */   {
/* 4380 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/*      */     
/* 4382 */     if (inputLength <= indicatorLookback + lookforward) {
/* 4383 */       LOGGER.warn("There is not enough data to calculate value for " + indicatorInfo.getName());
/* 4384 */       Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4385 */       int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4386 */         OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4387 */         switch (info.getType()) {
/*      */         case DOUBLE: 
/* 4389 */           ret[i] = Double.valueOf(NaN.0D);
/* 4390 */           break;
/*      */         case INT: 
/* 4392 */           ret[i] = Integer.valueOf(Integer.MIN_VALUE);
/* 4393 */           break;
/*      */         case OBJECT: 
/* 4395 */           ret[i] = null;
/* 4396 */           break;
/*      */         case CANDLE: 
/* 4398 */           ret[i] = null;
/*      */         }
/*      */         
/*      */       }
/* 4402 */       return ret;
/*      */     }
/*      */     
/* 4405 */     Object[] outputs = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4406 */     int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4407 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4408 */       switch (info.getType()) {
/*      */       case DOUBLE: 
/* 4410 */         double[] doubles = new double[inputLength - (indicatorLookback + lookforward)];
/* 4411 */         outputs[i] = doubles;
/*      */         try {
/* 4413 */           indicator.setOutputParameter(i, doubles);
/*      */         } catch (Throwable t) {
/* 4415 */           LOGGER.error(t.getMessage(), t);
/* 4416 */           String error = StrategyWrapper.representError(indicator, t);
/* 4417 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4418 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4419 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case INT: 
/* 4423 */         int[] ints = new int[inputLength - (indicatorLookback + lookforward)];
/* 4424 */         outputs[i] = ints;
/*      */         try {
/* 4426 */           indicator.setOutputParameter(i, ints);
/*      */         } catch (Throwable t) {
/* 4428 */           LOGGER.error(t.getMessage(), t);
/* 4429 */           String error = StrategyWrapper.representError(indicator, t);
/* 4430 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4431 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4432 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case OBJECT: 
/* 4436 */         Object[] objects = new Object[inputLength - (indicatorLookback + lookforward)];
/* 4437 */         outputs[i] = objects;
/*      */         try {
/* 4439 */           indicator.setOutputParameter(i, objects);
/*      */         } catch (Throwable t) {
/* 4441 */           LOGGER.error(t.getMessage(), t);
/* 4442 */           String error = StrategyWrapper.representError(indicator, t);
/* 4443 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4444 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4445 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case CANDLE: 
/* 4449 */         IBar[] candles = new IBar[inputLength - (indicatorLookback + lookforward)];
/* 4450 */         outputs[i] = candles;
/*      */         try {
/* 4452 */           indicator.setOutputParameter(i, candles);
/*      */         } catch (Throwable t) {
/* 4454 */           LOGGER.error(t.getMessage(), t);
/* 4455 */           String error = StrategyWrapper.representError(indicator, t);
/* 4456 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4457 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4458 */           throw new JFException(t);
/*      */         }
/*      */       }
/*      */     }
/*      */     IndicatorResult result;
/*      */     try
/*      */     {
/* 4465 */       result = indicator.calculate(0, inputLength - 1);
/*      */     } catch (TaLibException e) {
/* 4467 */       Throwable t = e.getCause();
/* 4468 */       LOGGER.error(t.getMessage(), t);
/* 4469 */       String error = StrategyWrapper.representError(indicator, t);
/* 4470 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4471 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4472 */       throw new JFException(t);
/*      */     } catch (Throwable t) {
/* 4474 */       LOGGER.error(t.getMessage(), t);
/* 4475 */       String error = StrategyWrapper.representError(indicator, t);
/* 4476 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4477 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4478 */       throw new JFException(t);
/*      */     }
/* 4480 */     if ((result.getLastValueIndex() == Integer.MIN_VALUE) && (result.getNumberOfElements() != 0)) {
/* 4481 */       if (lookforward != 0) {
/* 4482 */         String error = IndicatorMessages.getIndexNotSetMsg(indicatorInfo.getName());
/* 4483 */         LOGGER.error(error);
/* 4484 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4485 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 4486 */         throw new JFException(error);
/*      */       }
/* 4488 */       result.setLastValueIndex(inputLength - 1);
/*      */     }
/*      */     
/* 4491 */     if ((result.getLastValueIndex() + 1 - result.getFirstValueIndex() < inputLength - lookback - lookforward) || (result.getNumberOfElements() < inputLength - lookback - lookforward)) {
/* 4492 */       String error = IndicatorMessages.getLackOfValuesMsg(indicator.getIndicatorInfo().getName());
/* 4493 */       LOGGER.error(error);
/* 4494 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4495 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 4496 */       throw new JFException(error);
/*      */     }
/* 4498 */     Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4499 */     int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4500 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4501 */       if (result.getNumberOfElements() == 0) {
/* 4502 */         throw new JFException("Indicator did not return any values");
/*      */       }
/* 4504 */       switch (info.getType()) {
/*      */       case DOUBLE: 
/* 4506 */         double[] doubles = (double[])outputs[i];
/* 4507 */         ret[i] = Double.valueOf(doubles[(result.getNumberOfElements() - 1)]);
/* 4508 */         break;
/*      */       case INT: 
/* 4510 */         int[] ints = (int[])outputs[i];
/* 4511 */         ret[i] = Integer.valueOf(ints[(result.getNumberOfElements() - 1)]);
/* 4512 */         break;
/*      */       case OBJECT: 
/* 4514 */         Object[] objects = (Object[])outputs[i];
/* 4515 */         ret[i] = objects[(result.getNumberOfElements() - 1)];
/* 4516 */         break;
/*      */       case CANDLE: 
/* 4518 */         IBar[] candles = (IBar[])outputs[i];
/* 4519 */         ret[i] = candles[(result.getNumberOfElements() - 1)];
/*      */       }
/*      */       
/*      */     }
/* 4523 */     return ret;
/*      */   }
/*      */   
/*      */   private Object[] function(Instrument instrument, Period period, OfferSide side, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, long from, long to) throws JFException
/*      */   {
/* 4528 */     return calculateIndicator(instrument, period, new OfferSide[] { side }, functionName, inputTypes, optParams, from, to);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] calculateIndicator(Instrument instrument, Period period, OfferSide[] side, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, long from, long to)
/*      */     throws JFException
/*      */   {
/* 4541 */     IndicatorHelper.PeriodParameterMapper.performMapping(functionName, optParams);
/* 4542 */     IndicatorCalcFromTo calc = new IndicatorCalcFromTo(functionName, instrument, period, side, inputTypes, optParams, from, to);
/* 4543 */     return calc.calculate();
/*      */   }
/*      */   
/*      */   private Object[] calculateIndicator(Period period, long from, long to, IIndicator indicator, int indicatorLookback, int lookback, int lookforward, int inputLength) throws JFException {
/* 4547 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/*      */     
/* 4549 */     if (inputLength <= indicatorLookback + lookforward) {
/* 4550 */       String msg = IndicatorMessages.getNotEnoughDataMsg(indicatorInfo.getName());
/* 4551 */       LOGGER.warn(msg);
/* 4552 */       Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4553 */       int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4554 */         OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4555 */         switch (info.getType()) {
/*      */         case DOUBLE: 
/* 4557 */           ret[i] = new double[0];
/* 4558 */           break;
/*      */         case INT: 
/* 4560 */           ret[i] = new int[0];
/* 4561 */           break;
/*      */         case OBJECT: 
/* 4563 */           ret[i] = new Object[0];
/* 4564 */           break;
/*      */         case CANDLE: 
/* 4566 */           ret[i] = new IBar[0];
/*      */         }
/*      */         
/*      */       }
/* 4570 */       return ret;
/*      */     }
/*      */     
/* 4573 */     Object[] outputs = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4574 */     int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4575 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4576 */       switch (info.getType()) {
/*      */       case DOUBLE: 
/* 4578 */         double[] doubles = new double[inputLength - (indicatorLookback + lookforward)];
/* 4579 */         outputs[i] = doubles;
/*      */         try {
/* 4581 */           indicator.setOutputParameter(i, doubles);
/*      */         } catch (Throwable t) {
/* 4583 */           LOGGER.error(t.getMessage(), t);
/* 4584 */           String error = StrategyWrapper.representError(indicator, t);
/* 4585 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4586 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4587 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case INT: 
/* 4591 */         int[] ints = new int[inputLength - (indicatorLookback + lookforward)];
/* 4592 */         outputs[i] = ints;
/*      */         try {
/* 4594 */           indicator.setOutputParameter(i, ints);
/*      */         } catch (Throwable t) {
/* 4596 */           LOGGER.error(t.getMessage(), t);
/* 4597 */           String error = StrategyWrapper.representError(indicator, t);
/* 4598 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4599 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4600 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case OBJECT: 
/* 4604 */         Object[] objects = new Object[inputLength - (indicatorLookback + lookforward)];
/* 4605 */         outputs[i] = objects;
/*      */         try {
/* 4607 */           indicator.setOutputParameter(i, objects);
/*      */         } catch (Throwable t) {
/* 4609 */           LOGGER.error(t.getMessage(), t);
/* 4610 */           String error = StrategyWrapper.representError(indicator, t);
/* 4611 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4612 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4613 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case CANDLE: 
/* 4617 */         IBar[] candles = new IBar[inputLength - (indicatorLookback + lookforward)];
/* 4618 */         outputs[i] = candles;
/*      */         try {
/* 4620 */           indicator.setOutputParameter(i, candles);
/*      */         } catch (Throwable t) {
/* 4622 */           LOGGER.error(t.getMessage(), t);
/* 4623 */           String error = StrategyWrapper.representError(indicator, t);
/* 4624 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4625 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4626 */           throw new JFException(t);
/*      */         }
/*      */       }
/*      */     }
/*      */     IndicatorResult result;
/*      */     try
/*      */     {
/* 4633 */       result = indicator.calculate(0, inputLength - 1);
/*      */     } catch (TaLibException e) {
/* 4635 */       Throwable t = e.getCause();
/* 4636 */       LOGGER.error(t.getMessage(), t);
/* 4637 */       String error = StrategyWrapper.representError(indicator, t);
/* 4638 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4639 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4640 */       throw new JFException(t);
/*      */     } catch (Throwable t) {
/* 4642 */       LOGGER.error(t.getMessage(), t);
/* 4643 */       String error = StrategyWrapper.representError(indicator, t);
/* 4644 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4645 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4646 */       throw new JFException(t);
/*      */     }
/* 4648 */     if ((result.getLastValueIndex() == Integer.MIN_VALUE) && (result.getNumberOfElements() != 0)) {
/* 4649 */       if (lookforward != 0) {
/* 4650 */         String error = IndicatorMessages.getIndexNotSetMsg(indicatorInfo.getName());
/* 4651 */         LOGGER.error(error);
/* 4652 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4653 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 4654 */         throw new JFException(error);
/*      */       }
/* 4656 */       result.setLastValueIndex(inputLength - 1);
/*      */     }
/*      */     
/* 4659 */     if ((result.getLastValueIndex() + 1 - result.getFirstValueIndex() < inputLength - lookback - lookforward) || (result.getNumberOfElements() < inputLength - lookback - lookforward)) {
/* 4660 */       String error = IndicatorMessages.getLackOfValuesMsg(indicator.getIndicatorInfo().getName());
/* 4661 */       LOGGER.error(error);
/* 4662 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4663 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 4664 */       throw new JFException(error);
/*      */     }
/* 4666 */     Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4667 */     int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4668 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/*      */       int outCount;
/*      */       int outCount;
/* 4671 */       if (period != null) {
/* 4672 */         outCount = DataCacheUtils.getCandlesCountBetweenFast(period.isTickBasedPeriod() ? Period.ONE_SEC : period, from, to) > result.getNumberOfElements() ? result.getNumberOfElements() : DataCacheUtils.getCandlesCountBetweenFast(period.isTickBasedPeriod() ? Period.ONE_SEC : period, from, to);
/*      */       }
/*      */       else
/*      */       {
/* 4676 */         outCount = inputLength - lookback - lookforward;
/*      */       }
/*      */       
/* 4679 */       switch (info.getType()) {
/*      */       case DOUBLE: 
/* 4681 */         double[] doubles = (double[])outputs[i];
/* 4682 */         double[] retDoubles = new double[outCount];
/* 4683 */         System.arraycopy(doubles, result.getNumberOfElements() - outCount, retDoubles, 0, outCount);
/* 4684 */         ret[i] = retDoubles;
/* 4685 */         break;
/*      */       case INT: 
/* 4687 */         int[] ints = (int[])outputs[i];
/* 4688 */         int[] retInts = new int[outCount];
/* 4689 */         System.arraycopy(ints, result.getNumberOfElements() - outCount, retInts, 0, outCount);
/* 4690 */         ret[i] = retInts;
/* 4691 */         break;
/*      */       case OBJECT: 
/* 4693 */         Object[] objects = (Object[])outputs[i];
/* 4694 */         Object[] retObjs = new Object[outCount];
/* 4695 */         System.arraycopy(objects, result.getNumberOfElements() - outCount, retObjs, 0, outCount);
/* 4696 */         ret[i] = retObjs;
/* 4697 */         break;
/*      */       case CANDLE: 
/* 4699 */         IBar[] candles = (IBar[])outputs[i];
/* 4700 */         IBar[] retCandles = new IBar[outCount];
/* 4701 */         System.arraycopy(candles, result.getNumberOfElements() - outCount, retCandles, 0, outCount);
/* 4702 */         ret[i] = retCandles;
/*      */       }
/*      */       
/*      */     }
/* 4706 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] calculateIndicator(Instrument instrument, Period period, OfferSide[] side, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, Filter filter, int numberOfCandlesBefore, long time, int numberOfCandlesAfter)
/*      */     throws JFException
/*      */   {
/* 4722 */     IndicatorHelper.PeriodParameterMapper.performMapping(functionName, optParams);
/* 4723 */     IndicatorCalcBeforeAfter calc = new IndicatorCalcBeforeAfter(functionName, instrument, period, side, inputTypes, optParams, numberOfCandlesBefore, time, numberOfCandlesAfter, filter);
/*      */     
/* 4725 */     return calc.calculate();
/*      */   }
/*      */   
/*      */   public static int calculateLookback(IIndicator indicator) {
/* 4729 */     return calculateLookback(indicator, indicator.getLookback());
/*      */   }
/*      */   
/*      */   private static int calculateLookback(IIndicator indicator, int initialLookback) {
/* 4733 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 4734 */     if (indicatorInfo.isUnstablePeriod())
/*      */     {
/* 4736 */       initialLookback += (initialLookback * 4 < 100 ? 100 : initialLookback * 4);
/*      */     }
/* 4738 */     return initialLookback;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object[] calculateIndicator(int numberOfCandlesBefore, long time, int numberOfCandlesAfter, IIndicator indicator, int indicatorLookback, int lookback, int lookforward, int inputLength)
/*      */     throws JFException
/*      */   {
/* 4751 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 4752 */     if (inputLength < numberOfCandlesBefore + numberOfCandlesAfter + indicatorLookback + lookforward) {
/* 4753 */       String msg = IndicatorMessages.getNotEnoughDataMsg(indicatorInfo.getName());
/* 4754 */       LOGGER.warn(msg);
/* 4755 */       Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4756 */       int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4757 */         OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4758 */         switch (info.getType()) {
/*      */         case DOUBLE: 
/* 4760 */           ret[i] = new double[0];
/* 4761 */           break;
/*      */         case INT: 
/* 4763 */           ret[i] = new int[0];
/* 4764 */           break;
/*      */         case OBJECT: 
/* 4766 */           ret[i] = new Object[0];
/* 4767 */           break;
/*      */         case CANDLE: 
/* 4769 */           ret[i] = new IBar[0];
/*      */         }
/*      */         
/*      */       }
/*      */       
/* 4774 */       return ret;
/*      */     }
/* 4776 */     Object[] outputs = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4777 */     int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4778 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4779 */       switch (info.getType()) {
/*      */       case DOUBLE: 
/* 4781 */         double[] doubles = new double[inputLength - (indicatorLookback + lookforward)];
/* 4782 */         outputs[i] = doubles;
/*      */         try {
/* 4784 */           indicator.setOutputParameter(i, doubles);
/*      */         } catch (Throwable t) {
/* 4786 */           LOGGER.error(t.getMessage(), t);
/* 4787 */           String error = StrategyWrapper.representError(indicator, t);
/* 4788 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4789 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4790 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case INT: 
/* 4794 */         int[] ints = new int[inputLength - (indicatorLookback + lookforward)];
/* 4795 */         outputs[i] = ints;
/*      */         try {
/* 4797 */           indicator.setOutputParameter(i, ints);
/*      */         } catch (Throwable t) {
/* 4799 */           LOGGER.error(t.getMessage(), t);
/* 4800 */           String error = StrategyWrapper.representError(indicator, t);
/* 4801 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4802 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4803 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case OBJECT: 
/* 4807 */         Object[] objects = new Object[inputLength - (indicatorLookback + lookforward)];
/* 4808 */         outputs[i] = objects;
/*      */         try {
/* 4810 */           indicator.setOutputParameter(i, objects);
/*      */         } catch (Throwable t) {
/* 4812 */           LOGGER.error(t.getMessage(), t);
/* 4813 */           String error = StrategyWrapper.representError(indicator, t);
/* 4814 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4815 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4816 */           throw new JFException(t);
/*      */         }
/*      */       
/*      */       case CANDLE: 
/* 4820 */         IBar[] candles = new IBar[inputLength - (indicatorLookback + lookforward)];
/* 4821 */         outputs[i] = candles;
/*      */         try {
/* 4823 */           indicator.setOutputParameter(i, candles);
/*      */         } catch (Throwable t) {
/* 4825 */           LOGGER.error(t.getMessage(), t);
/* 4826 */           String error = StrategyWrapper.representError(indicator, t);
/* 4827 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4828 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4829 */           throw new JFException(t);
/*      */         }
/*      */       }
/*      */     }
/*      */     IndicatorResult result;
/*      */     try
/*      */     {
/* 4836 */       result = indicator.calculate(0, inputLength - 1);
/*      */     } catch (TaLibException e) {
/* 4838 */       Throwable t = e.getCause();
/* 4839 */       LOGGER.error(t.getMessage(), t);
/* 4840 */       String error = StrategyWrapper.representError(indicator, t);
/* 4841 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4842 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4843 */       throw new JFException(t);
/*      */     } catch (Throwable t) {
/* 4845 */       LOGGER.error(t.getMessage(), t);
/* 4846 */       String error = StrategyWrapper.representError(indicator, t);
/* 4847 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4848 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4849 */       throw new JFException(t);
/*      */     }
/* 4851 */     if ((result.getLastValueIndex() == Integer.MIN_VALUE) && (result.getNumberOfElements() != 0)) {
/* 4852 */       if (lookforward != 0) {
/* 4853 */         String error = IndicatorMessages.getIndexNotSetMsg(indicatorInfo.getName());
/* 4854 */         LOGGER.error(error);
/* 4855 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4856 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 4857 */         throw new JFException(error);
/*      */       }
/* 4859 */       result.setLastValueIndex(inputLength - 1);
/*      */     }
/*      */     
/* 4862 */     if ((result.getLastValueIndex() + 1 - result.getFirstValueIndex() < inputLength - lookback - lookforward) || (result.getNumberOfElements() < inputLength - lookback - lookforward)) {
/* 4863 */       String error = IndicatorMessages.getLackOfValuesMsg(indicator.getIndicatorInfo().getName());
/* 4864 */       LOGGER.error(error);
/* 4865 */       String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4866 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 4867 */       throw new JFException(error);
/*      */     }
/* 4869 */     Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 4870 */     int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 4871 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 4872 */       int outCount; switch (info.getType()) {
/*      */       case DOUBLE: 
/* 4874 */         double[] doubles = (double[])outputs[i];
/* 4875 */         outCount = numberOfCandlesBefore + numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : numberOfCandlesBefore + numberOfCandlesAfter;
/*      */         
/* 4877 */         double[] retDoubles = new double[outCount];
/* 4878 */         System.arraycopy(doubles, result.getNumberOfElements() - outCount, retDoubles, 0, outCount);
/* 4879 */         ret[i] = retDoubles;
/* 4880 */         break;
/*      */       case INT: 
/* 4882 */         int[] ints = (int[])outputs[i];
/* 4883 */         outCount = numberOfCandlesBefore + numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : numberOfCandlesBefore + numberOfCandlesAfter;
/*      */         
/* 4885 */         int[] retInts = new int[outCount];
/* 4886 */         System.arraycopy(ints, result.getNumberOfElements() - outCount, retInts, 0, outCount);
/* 4887 */         ret[i] = retInts;
/* 4888 */         break;
/*      */       case OBJECT: 
/* 4890 */         Object[] objects = (Object[])outputs[i];
/* 4891 */         outCount = numberOfCandlesBefore + numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : numberOfCandlesBefore + numberOfCandlesAfter;
/*      */         
/* 4893 */         Object[] retObjs = new Object[outCount];
/* 4894 */         System.arraycopy(objects, result.getNumberOfElements() - outCount, retObjs, 0, outCount);
/* 4895 */         ret[i] = retObjs;
/* 4896 */         break;
/*      */       case CANDLE: 
/* 4898 */         IBar[] candles = (IBar[])outputs[i];
/* 4899 */         outCount = numberOfCandlesBefore + numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : numberOfCandlesBefore + numberOfCandlesAfter;
/*      */         
/* 4901 */         IBar[] retCandles = new IBar[outCount];
/* 4902 */         System.arraycopy(candles, result.getNumberOfElements() - outCount, retCandles, 0, outCount);
/* 4903 */         ret[i] = retCandles;
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 4908 */     return ret;
/*      */   }
/*      */   
/*      */   protected void setOptParams(IIndicator indicator, Object[] optParams) throws JFException {
/* 4912 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 4913 */     int i = 0; for (int j = indicatorInfo.getNumberOfOptionalInputs(); i < j; i++) {
/*      */       try {
/* 4915 */         indicator.setOptInputParameter(i, optParams[i]);
/*      */       } catch (Throwable t) {
/* 4917 */         LOGGER.error(t.getMessage(), t);
/* 4918 */         String error = StrategyWrapper.representError(indicator, t);
/* 4919 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 4920 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 4921 */         throw new JFException(t);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getInputData(Instrument instrument, Period period, OfferSide side, InputParameterInfo.Type inputType, IIndicators.AppliedPrice appliedPrice, int shift, int lookback, int lookforward)
/*      */     throws DataCacheException, JFException
/*      */   {
/* 4937 */     if ((lookback == 0) && (lookforward == 0))
/*      */     {
/*      */       IBar bar;
/* 4940 */       if (shift < 0) {
/* 4941 */         IBar bar = this.history.getCurrentBar(instrument, period, side);
/* 4942 */         if (bar == null) {
/* 4943 */           return null;
/*      */         }
/* 4945 */         double price = bar.getClose();
/* 4946 */         bar = new CandleData(DataCacheUtils.getTimeForNCandlesForwardFast(period, bar.getTime(), -shift + 1), price, price, price, price, 0.0D);
/*      */       } else {
/* 4948 */         bar = this.history.getBar(instrument, period, side, shift);
/* 4949 */         if (bar == null) {
/* 4950 */           return null;
/*      */         }
/*      */       }
/* 4953 */       List<IBar> bars = new ArrayList(1);
/* 4954 */       bars.add(bar);
/*      */       
/* 4956 */       return barsToReal(bars, inputType, appliedPrice); }
/* 4957 */     if (lookback == 0) {
/* 4958 */       int flats = shift < 0 ? -shift : 0;
/* 4959 */       shift = shift < 0 ? 0 : shift;
/* 4960 */       IBar currentBar = null;
/* 4961 */       long currentBarStartTime = this.history.getStartTimeOfCurrentBar(instrument, period);
/* 4962 */       long requestedBarStartTime = DataCacheUtils.getTimeForNCandlesBackFast(period, DataCacheUtils.getPreviousCandleStart(period, currentBarStartTime), shift);
/*      */       
/* 4964 */       int count = DataCacheUtils.getCandlesCountBetweenFast(period, requestedBarStartTime, currentBarStartTime) - 1;
/*      */       long lookforwardStartTime;
/* 4966 */       if (count > lookforward) {
/* 4967 */         lookforwardStartTime = DataCacheUtils.getTimeForNCandlesForwardFast(period, requestedBarStartTime, count + 1);
/* 4968 */       } else if (count == lookforward) {
/* 4969 */         long lookforwardStartTime = DataCacheUtils.getTimeForNCandlesForwardFast(period, requestedBarStartTime, count);
/* 4970 */         currentBar = this.history.getCurrentBar(instrument, period, side);
/*      */       }
/*      */       else {
/* 4973 */         return null;
/*      */       }
/*      */       long lookforwardStartTime;
/* 4976 */       List<IBar> bars = this.history.getBars(instrument, period, side, requestedBarStartTime, lookforwardStartTime);
/* 4977 */       if (currentBar != null) {
/* 4978 */         bars.add(currentBar);
/*      */       }
/*      */       
/* 4981 */       if ((flats > 0) && (!bars.isEmpty()))
/*      */       {
/*      */ 
/* 4984 */         IBar lastCandle = (IBar)bars.get(bars.size() - 1);
/* 4985 */         double price = lastCandle.getClose();
/* 4986 */         int i = 0; for (long time = DataCacheUtils.getNextCandleStartFast(period, lastCandle.getTime()); i < flats; time = DataCacheUtils.getNextCandleStartFast(period, time)) {
/* 4987 */           bars.add(new CandleData(time, price, price, price, price, 0.0D));i++;
/*      */         }
/*      */       }
/* 4990 */       return barsToReal(bars, inputType, appliedPrice);
/*      */     }
/* 4992 */     int flats = shift < 0 ? -shift : 0;
/* 4993 */     shift = shift < 0 ? 0 : shift;
/* 4994 */     IBar currentBar = null;
/* 4995 */     if (shift == 0) {
/* 4996 */       if (lookforward > 0)
/*      */       {
/* 4998 */         return null;
/*      */       }
/* 5000 */       shift = 1;
/* 5001 */       lookback--;
/* 5002 */       currentBar = this.history.getCurrentBar(instrument, period, side);
/* 5003 */       if (currentBar == null) {
/* 5004 */         return null;
/*      */       }
/*      */     }
/* 5007 */     long currentBarStartTime = this.history.getStartTimeOfCurrentBar(instrument, period);
/* 5008 */     long requestedBarStartTime = DataCacheUtils.getTimeForNCandlesBackFast(period, DataCacheUtils.getPreviousCandleStart(period, currentBarStartTime), shift);
/* 5009 */     long lookbackStartTime = DataCacheUtils.getTimeForNCandlesBackFast(period, requestedBarStartTime, lookback + 1);
/* 5010 */     if (lookforward > 0) {
/* 5011 */       int count = DataCacheUtils.getCandlesCountBetweenFast(period, requestedBarStartTime, currentBarStartTime) - 1;
/* 5012 */       if (count > lookforward) {
/* 5013 */         requestedBarStartTime = DataCacheUtils.getTimeForNCandlesForwardFast(period, requestedBarStartTime, lookforward + 1);
/* 5014 */       } else if (count == lookforward) {
/* 5015 */         requestedBarStartTime = DataCacheUtils.getTimeForNCandlesForwardFast(period, requestedBarStartTime, count);
/* 5016 */         currentBar = this.history.getCurrentBar(instrument, period, side);
/*      */       }
/*      */       else {
/* 5019 */         return null;
/*      */       }
/*      */     }
/* 5022 */     List<IBar> bars = this.history.getBars(instrument, period, side, lookbackStartTime, requestedBarStartTime);
/* 5023 */     if (currentBar != null)
/* 5024 */       bars.add(currentBar);
/*      */     double price;
/* 5026 */     int i; long time; if ((flats > 0) && (!bars.isEmpty()))
/*      */     {
/*      */ 
/* 5029 */       IBar lastCandle = (IBar)bars.get(bars.size() - 1);
/* 5030 */       price = lastCandle.getClose();
/* 5031 */       i = 0; for (time = DataCacheUtils.getNextCandleStartFast(period, lastCandle.getTime()); i < flats;)
/*      */       {
/*      */ 
/* 5034 */         bars.add(new CandleData(time, price, price, price, price, 0.0D));i++;time = DataCacheUtils.getNextCandleStartFast(period, time);
/*      */       }
/*      */     }
/* 5037 */     return barsToReal(bars, inputType, appliedPrice);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getInputData(Instrument instrument, Period period, OfferSide side, InputParameterInfo.Type inputType, IIndicators.AppliedPrice appliedPrice, long from, long to, int lookback, int lookforward, boolean addCurrentCandle, int addFlatsAtTheEnd)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5054 */     if (period.isTickBasedPeriod()) {
/* 5055 */       from = DataCacheUtils.getCandleStartFast(Period.ONE_SEC, from);
/* 5056 */       from -= lookback * 1000;
/* 5057 */       long candleTo = DataCacheUtils.getCandleStartFast(Period.ONE_SEC, to);
/* 5058 */       long timeOfLastTick = this.history.getTimeOfLastTick(instrument);
/* 5059 */       if (lookforward > 0) {
/* 5060 */         long lastCandle = DataCacheUtils.getCandleStartFast(Period.ONE_SEC, timeOfLastTick);
/* 5061 */         int count = DataCacheUtils.getCandlesCountBetweenFast(Period.ONE_SEC, candleTo, lastCandle) - 1;
/* 5062 */         count = count > lookforward ? lookforward : count;
/* 5063 */         to = DataCacheUtils.getTimeForNCandlesForwardFast(Period.ONE_SEC, candleTo, count + 1);
/* 5064 */         candleTo = to;
/* 5065 */         if (candleTo + 999L <= timeOfLastTick) {
/* 5066 */           to = candleTo + 999L;
/* 5067 */         } else if (candleTo <= timeOfLastTick) {
/* 5068 */           to = timeOfLastTick;
/*      */         }
/* 5070 */       } else if (candleTo + 999L <= timeOfLastTick) {
/* 5071 */         to = candleTo + 999L;
/*      */       }
/* 5073 */       List<ITick> ticks = this.history.getTicks(instrument, from, to);
/* 5074 */       List<IBar> bars = new ArrayList((int)((to - from) / 1000L + 1L));
/* 5075 */       if ((ticks.isEmpty()) || (DataCacheUtils.getCandleStartFast(Period.ONE_SEC, ((ITick)ticks.get(0)).getTime()) != from)) {
/* 5076 */         ITick tickBefore = this.history.getLastTickBefore(instrument, from - 1L);
/* 5077 */         double price = side == OfferSide.ASK ? tickBefore.getAsk() : tickBefore.getBid();
/* 5078 */         long timeOfLastFlatCandle = ticks.isEmpty() ? DataCacheUtils.getCandleStartFast(Period.ONE_SEC, to) : DataCacheUtils.getPreviousCandleStartFast(Period.ONE_SEC, DataCacheUtils.getCandleStartFast(Period.ONE_SEC, ((ITick)ticks.get(0)).getTime()));
/*      */         
/* 5080 */         for (long time = from; time <= timeOfLastFlatCandle; time += 1000L) {
/* 5081 */           bars.add(new CandleData(time, price, price, price, price, 0.0D));
/*      */         }
/*      */       }
/* 5084 */       createCandlesFromTicks(ticks, bars, side);
/* 5085 */       return barsToReal(bars, inputType, appliedPrice);
/*      */     }
/* 5087 */     from = DataCacheUtils.getCandleStartFast(period, from);
/* 5088 */     long lookbackStartTime = DataCacheUtils.getTimeForNCandlesBackFast(period, from, lookback + 1);
/* 5089 */     if (lookforward > 0) {
/* 5090 */       to = DataCacheUtils.getCandleStartFast(period, to);
/* 5091 */       long lastCandle = DataCacheUtils.getPreviousCandleStartFast(period, this.history.getStartTimeOfCurrentBar(instrument, period));
/* 5092 */       int count = DataCacheUtils.getCandlesCountBetweenFast(period, to, lastCandle) - 1;
/* 5093 */       count = count > lookforward ? lookforward : count;
/* 5094 */       to = DataCacheUtils.getTimeForNCandlesForwardFast(period, to, count + 1);
/*      */     }
/* 5096 */     List<IBar> bars = this.history.getBars(instrument, period, side, lookbackStartTime, to);
/* 5097 */     if (addCurrentCandle) {
/* 5098 */       IBar currentBar = this.history.getCurrentBar(instrument, period, side);
/* 5099 */       bars.add(currentBar);
/*      */     }
/* 5101 */     if ((addFlatsAtTheEnd > 0) && (!bars.isEmpty()))
/*      */     {
/*      */ 
/* 5104 */       IBar lastCandle = (IBar)bars.get(bars.size() - 1);
/* 5105 */       double price = lastCandle.getClose();
/* 5106 */       int i = 0; for (long lastTime = DataCacheUtils.getNextCandleStartFast(period, lastCandle.getTime()); i < addFlatsAtTheEnd; lastTime = DataCacheUtils.getNextCandleStartFast(period, lastTime)) {
/* 5107 */         bars.add(new CandleData(lastTime, price, price, price, price, 0.0D));i++;
/*      */       }
/*      */     }
/* 5110 */     return barsToReal(bars, inputType, appliedPrice);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getInputData(Instrument instrument, Period period, OfferSide side, InputParameterInfo.Type inputType, IIndicators.AppliedPrice appliedPrice, Filter filter, int before, long time, int after, int lookback, int lookforward, int addFlatsAtTheEnd)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5128 */     List<IBar> bars = getInputBars(instrument, period, side, inputType, appliedPrice, filter, before, time, after, lookback, lookforward, addFlatsAtTheEnd);
/* 5129 */     return barsToReal(bars, inputType, appliedPrice);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<IBar> getInputBars(Instrument instrument, Period period, OfferSide side, InputParameterInfo.Type inputType, IIndicators.AppliedPrice appliedPrice, Filter filter, int before, long time, int after, int lookback, int lookforward, int addFlatsAtTheEnd)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5147 */     time = DataCacheUtils.getCandleStartFast(period, time);
/* 5148 */     before += lookback;
/* 5149 */     after += lookforward;
/*      */     
/* 5151 */     if (!this.history.isInstrumentSubscribed(instrument)) {
/* 5152 */       throw new JFException("Instrument [" + instrument + "] is not subscribed");
/*      */     }
/* 5154 */     long timeOfLastCandle = this.history.getCurrentTime(instrument);
/* 5155 */     if (timeOfLastCandle != Long.MIN_VALUE) {
/* 5156 */       timeOfLastCandle = DataCacheUtils.getCandleStartFast(period, timeOfLastCandle);
/* 5157 */       if (time > timeOfLastCandle)
/*      */       {
/* 5159 */         throw new JFException("Requested time is after last bar time. Requested time [" + DateUtils.format(time) + "/" + time + "], " + "last bar time [" + lookforward + "] is [" + DateUtils.format(timeOfLastCandle) + "/" + timeOfLastCandle + "], ");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5165 */       long to = DataCacheUtils.getTimeForNCandlesForwardFast(period, time, this.history.getNumOfCandlesForwardForTimeCalculations(before, after));
/* 5166 */       if (to > timeOfLastCandle) {
/* 5167 */         throw new JFException("There is not enough bars after the central bar to calculate the indicator. Requested time [" + DateUtils.format(time) + "/" + time + "], " + "requested bar time shifted by lookforward [" + lookforward + "] is [" + DateUtils.format(to) + "/" + to + "], " + "last formed bar time [" + DateUtils.format(timeOfLastCandle) + "/" + timeOfLastCandle + "], ");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5176 */     List<IBar> bars = this.history.getBars(instrument, period, side, filter, before, time, after);
/* 5177 */     if ((addFlatsAtTheEnd > 0) && (!bars.isEmpty()))
/*      */     {
/*      */ 
/* 5180 */       IBar lastCandle = (IBar)bars.get(bars.size() - 1);
/* 5181 */       double price = lastCandle.getClose();
/* 5182 */       int i = 0; for (long lastTime = DataCacheUtils.getNextCandleStartFast(period, lastCandle.getTime()); i < addFlatsAtTheEnd; lastTime = DataCacheUtils.getNextCandleStartFast(period, lastTime)) {
/* 5183 */         bars.add(new CandleData(lastTime, price, price, price, price, 0.0D));i++;
/*      */       }
/*      */     }
/* 5186 */     return bars;
/*      */   }
/*      */   
/*      */   protected void checkSide(Period period, OfferSide[] side) throws JFException {
/* 5190 */     if (period.isTickBasedPeriod()) {
/* 5191 */       return;
/*      */     }
/* 5193 */     checkSide(side);
/*      */   }
/*      */   
/*      */   protected void checkSide(OfferSide[] side) throws JFException {
/* 5197 */     if (side == null) {
/* 5198 */       throw new JFException("Side parameter cannot be null");
/*      */     }
/* 5200 */     for (OfferSide offerSide : side) {
/* 5201 */       if (offerSide == null) {
/* 5202 */         throw new JFException("Side parameter cannot be null");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkSide(Period period, OfferSide side) throws JFException
/*      */   {
/* 5209 */     if (period.isTickBasedPeriod()) {
/* 5210 */       return;
/*      */     }
/* 5212 */     if (side == null) {
/* 5213 */       throw new JFException("Side parameter cannot be null");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void checkIntervalValid(Period period, long from, long to) throws JFException {
/* 5218 */     this.history.validateIntervalByPeriod(period, from, to);
/*      */   }
/*      */   
/*      */   private void checkIntervalValid(int before, int after) throws JFException {
/* 5222 */     if ((before <= 0) && (after <= 0)) {
/* 5223 */       throw new IllegalArgumentException("Negative or zero number of candles requested");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void checkNotTick(Period period) throws JFException {
/* 5228 */     if (period.isTickBasedPeriod()) {
/* 5229 */       throw new JFException("Functions with shift parameter doesn't support ticks");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void checkShiftPositive(int shift) throws JFException {
/* 5234 */     if (shift < 0) {
/* 5235 */       throw new JFException("Shift parameter must not be negative");
/*      */     }
/*      */   }
/*      */   
/*      */   protected <B extends IBar> Object barsToReal(List<B> bars, InputParameterInfo.Type inputType, IIndicators.AppliedPrice appliedPrice) throws JFException {
/* 5240 */     int i = 0;
/* 5241 */     switch (inputType) {
/*      */     case DOUBLE: 
/* 5243 */       double[] retDouble = new double[bars.size()];
/* 5244 */       for (IBar bar : bars) {
/* 5245 */         retDouble[i] = barToReal(bar, appliedPrice);
/* 5246 */         i++;
/*      */       }
/* 5248 */       return retDouble;
/*      */     case PRICE: 
/* 5250 */       double[][] retPrice = new double[5][bars.size()];
/* 5251 */       for (IBar bar : bars) {
/* 5252 */         retPrice[0][i] = barToReal(bar, IIndicators.AppliedPrice.OPEN);
/* 5253 */         retPrice[1][i] = barToReal(bar, IIndicators.AppliedPrice.CLOSE);
/* 5254 */         retPrice[2][i] = barToReal(bar, IIndicators.AppliedPrice.HIGH);
/* 5255 */         retPrice[3][i] = barToReal(bar, IIndicators.AppliedPrice.LOW);
/* 5256 */         retPrice[4][i] = barToReal(bar, IIndicators.AppliedPrice.VOLUME);
/* 5257 */         i++;
/*      */       }
/* 5259 */       return retPrice;
/*      */     case BAR: 
/* 5261 */       return bars.toArray(new IBar[bars.size()]);
/*      */     }
/* 5263 */     throw new RuntimeException("Unexpected input type [" + inputType + "]");
/*      */   }
/*      */   
/*      */   private double barToReal(IBar bar, IIndicators.AppliedPrice appliedPrice) throws JFException
/*      */   {
/* 5268 */     switch (appliedPrice) {
/*      */     case CLOSE: 
/* 5270 */       return bar.getClose();
/*      */     case HIGH: 
/* 5272 */       return bar.getHigh();
/*      */     case LOW: 
/* 5274 */       return bar.getLow();
/*      */     case MEDIAN_PRICE: 
/* 5276 */       return (bar.getHigh() + bar.getLow()) / 2.0D;
/*      */     case OPEN: 
/* 5278 */       return bar.getOpen();
/*      */     case TYPICAL_PRICE: 
/* 5280 */       return (bar.getHigh() + bar.getLow() + bar.getClose()) / 3.0D;
/*      */     case WEIGHTED_CLOSE: 
/* 5282 */       return (bar.getHigh() + bar.getLow() + bar.getClose() + bar.getClose()) / 4.0D;
/*      */     case TIMESTAMP: 
/* 5284 */       return bar.getTime();
/*      */     case VOLUME: 
/* 5286 */       return bar.getVolume();
/*      */     }
/* 5288 */     throw new JFException("Parameter should not be ASK, BID, ASK_VOLUME or BID_VOLUME for bars");
/*      */   }
/*      */   
/*      */   private void createCandlesFromTicks(List<ITick> timeData, List<IBar> tickCandles, OfferSide side)
/*      */   {
/* 5293 */     if (timeData.isEmpty()) {
/* 5294 */       return;
/*      */     }
/* 5296 */     IntraPeriodCandleData[][] generatedCandles = new IntraPeriodCandleData[Period.values().length][];
/* 5297 */     generatedCandles[Period.ONE_SEC.ordinal()] = new IntraPeriodCandleData[0];
/* 5298 */     List<Object[]> formedCandles = new ArrayList();
/* 5299 */     for (ITick tickData : timeData) {
/* 5300 */       IntraperiodCandlesGenerator.addTickToCandles(tickData.getTime(), tickData.getAsk(), tickData.getBid(), tickData.getAskVolume(), tickData.getBidVolume(), null, generatedCandles, formedCandles, null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5313 */     long nextCandleTime = DataCacheUtils.getNextCandleStartFast(Period.ONE_SEC, DataCacheUtils.getCandleStartFast(Period.ONE_SEC, ((ITick)timeData.get(timeData.size() - 1)).getTime()));
/* 5314 */     IntraperiodCandlesGenerator.addTickToCandles(nextCandleTime, 0.0D, 0.0D, 0.0D, 0.0D, null, generatedCandles, formedCandles, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5326 */     for (Object[] formedCandlesData : formedCandles) { IntraPeriodCandleData candle;
/*      */       IntraPeriodCandleData candle;
/* 5328 */       if (side == OfferSide.ASK) {
/* 5329 */         candle = (IntraPeriodCandleData)formedCandlesData[1];
/*      */       } else {
/* 5331 */         candle = (IntraPeriodCandleData)formedCandlesData[2];
/*      */       }
/* 5333 */       IBar bar = new CandleData(candle.time, candle.open, candle.close, candle.low, candle.high, candle.vol);
/* 5334 */       tickCandles.add(bar);
/*      */     }
/*      */   }
/*      */   
/*      */   public String registerCustomIndicator(final File compiledCustomIndcatorFile) throws JFException
/*      */   {
/* 5340 */     String indicatorName = null;
/*      */     try {
/* 5342 */       indicatorName = (String)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/* 5344 */         public String run() throws Exception { return Indicators.this.registerCustomIndicatorSecured(compiledCustomIndcatorFile); }
/*      */       });
/*      */     } catch (PrivilegedActionException e) {
/* 5347 */       Exception ex = e.getException();
/* 5348 */       if ((ex instanceof JFException))
/* 5349 */         throw ((JFException)ex);
/* 5350 */       if ((ex instanceof RuntimeException)) {
/* 5351 */         throw ((RuntimeException)ex);
/*      */       }
/* 5353 */       LOGGER.error(ex.getMessage(), ex);
/* 5354 */       throw new JFException(ex);
/*      */     }
/*      */     
/*      */ 
/* 5358 */     return indicatorName;
/*      */   }
/*      */   
/*      */   public String registerCustomIndicator(final Class<? extends IIndicator> indicatorClass) throws JFException
/*      */   {
/* 5363 */     String indicatorName = null;
/*      */     try {
/* 5365 */       indicatorName = (String)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*      */         public String run() throws Exception {
/* 5367 */           return Indicators.this.registerCustomIndicatorSecured(indicatorClass);
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/* 5372 */       Exception ex = e.getException();
/* 5373 */       if ((ex instanceof JFException))
/* 5374 */         throw ((JFException)ex);
/* 5375 */       if ((ex instanceof RuntimeException)) {
/* 5376 */         throw ((RuntimeException)ex);
/*      */       }
/* 5378 */       LOGGER.error(ex.getMessage(), ex);
/* 5379 */       throw new JFException(ex);
/*      */     }
/*      */     
/*      */ 
/* 5383 */     return indicatorName;
/*      */   }
/*      */   
/*      */ 
/*      */   public void registerDownloadableIndicator(String id, String name)
/*      */     throws JFException
/*      */   {
/* 5390 */     CompiledComponentDownloader downloader = CompiledComponentDownloader.getInstance();
/* 5391 */     final byte[] srcCode = downloader.downloadFile(id, IDownloadableStrategy.ComponentType.BLOCK_INDICATOR);
/*      */     Class<? extends IIndicator> indicatorClass;
/*      */     try {
/* 5394 */       indicatorClass = (Class)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*      */       {
/*      */         public Class<? extends IIndicator> run() throws Exception {
/* 5397 */           JFXPack jfxPack = JFXPack.loadFromPack(srcCode);
/* 5398 */           if (jfxPack.isFullAccessRequested()) {
/* 5399 */             jfxPack.setFullAccess(true);
/*      */           }
/* 5401 */           return jfxPack.getTargetClass();
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (Exception e) {
/* 5406 */       throw new JFException("Unable to init component " + name, e);
/*      */     }
/* 5408 */     registerCustomIndicator(indicatorClass);
/*      */   }
/*      */   
/*      */   private String registerCustomIndicatorSecured(File compiledCustomIndicatorFile) throws JFException {
/* 5412 */     if (!compiledCustomIndicatorFile.exists()) {
/* 5413 */       throw new JFException("Indicator file doesn't exists");
/*      */     }
/* 5415 */     IndicatorsProvider indicatorsProvider = IndicatorsProvider.getInstance();
/* 5416 */     CustIndicatorWrapper indicatorWrapper = new CustIndicatorWrapper();
/* 5417 */     indicatorWrapper.setBinaryFile(compiledCustomIndicatorFile);
/*      */     
/* 5419 */     IndicatorHolder holder = indicatorsProvider.enableIndicator(indicatorWrapper, this.notificationUtils);
/* 5420 */     String indicatorName = holder == null ? null : holder.getIndicator().getIndicatorInfo().getName().toUpperCase();
/*      */     
/* 5422 */     if (indicatorName == null) {
/* 5423 */       throw new JFException("Cannot register indicator");
/*      */     }
/*      */     
/* 5426 */     return indicatorName;
/*      */   }
/*      */   
/*      */   private String registerCustomIndicatorSecured(Class<? extends IIndicator> indicatorClass) throws JFException {
/* 5430 */     if (indicatorClass == null) {
/* 5431 */       throw new JFException("Indicator class is null");
/*      */     }
/*      */     
/* 5434 */     IIndicator indicator = null;
/*      */     try {
/* 5436 */       indicator = (IIndicator)indicatorClass.newInstance();
/*      */     } catch (Exception ex) {
/* 5438 */       throw new JFException("Cannot create indicator [" + indicatorClass + "] instance.");
/*      */     }
/* 5440 */     IndicatorContext indicatorContext = IndicatorHelper.createIndicatorContext(this.history, this.notificationUtils);
/*      */     try
/*      */     {
/* 5443 */       indicator.onStart(indicatorContext);
/*      */     }
/*      */     catch (Throwable th) {
/* 5446 */       throw new JFException("Exception in onStart method");
/*      */     }
/* 5448 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 5449 */     if (indicatorInfo == null) {
/* 5450 */       throw new JFException("Indicator info is null");
/*      */     }
/*      */     
/* 5453 */     String indicatorName = indicatorInfo.getName();
/* 5454 */     if ((indicatorName != null) && (!indicatorName.trim().isEmpty())) {
/* 5455 */       this.customIndicators.put(indicatorName, indicatorClass);
/* 5456 */       cacheIndicator(indicatorName, new IndicatorHolder(indicator, indicatorContext));
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 5461 */       throw new JFException("Indicator name is empty");
/*      */     }
/*      */     
/* 5464 */     return indicatorName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] calculateIndicator(Instrument instrument, Period period, OfferSide[] side, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, Filter filter, long from, long to)
/*      */     throws JFException
/*      */   {
/* 5479 */     IndicatorHelper.PeriodParameterMapper.performMapping(functionName, optParams);
/* 5480 */     IndicatorCalcFromToFiltered calc = new IndicatorCalcFromToFiltered(functionName, instrument, period, side, inputTypes, optParams, from, to, filter);
/* 5481 */     return calc.calculate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object getInputData(Instrument instrument, Period period, OfferSide side, InputParameterInfo.Type inputType, IIndicators.AppliedPrice appliedPrice, Filter filter, long from, long to, int lookback, int lookforward, int addFlatsAtTheEnd)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5498 */     if (period.isTickBasedPeriod()) {
/* 5499 */       return getInputData(instrument, period, side, inputType, appliedPrice, from, to, lookback, lookforward, false, addFlatsAtTheEnd);
/*      */     }
/* 5501 */     List<IBar> bars = this.history.getBars(instrument, period, side, filter, from, to);
/* 5502 */     if (!bars.isEmpty()) {
/* 5503 */       if (lookback > 0) {
/* 5504 */         List<IBar> lookBackBars = this.history.getBars(instrument, period, side, filter, lookback + 1, ((IBar)bars.get(0)).getTime(), 0);
/*      */         
/* 5506 */         if (!lookBackBars.isEmpty()) {
/* 5507 */           lookBackBars.remove(lookBackBars.size() - 1);
/*      */         }
/*      */         
/* 5510 */         bars.addAll(0, lookBackBars);
/*      */       }
/* 5512 */       if (lookforward > 0) {
/* 5513 */         List<IBar> lookForwardBars = this.history.getBars(instrument, period, side, filter, 0, ((IBar)bars.get(bars.size() - 1)).getTime(), lookforward + 1);
/*      */         
/* 5515 */         if (!lookForwardBars.isEmpty()) {
/* 5516 */           lookForwardBars.remove(0);
/*      */         }
/* 5518 */         bars.addAll(lookForwardBars);
/*      */       }
/*      */       
/* 5521 */       if (addFlatsAtTheEnd > 0) {
/* 5522 */         addFlatBars(bars, addFlatsAtTheEnd, period);
/*      */       }
/*      */     }
/*      */     
/* 5526 */     return barsToReal(bars, inputType, appliedPrice);
/*      */   }
/*      */   
/*      */   private List<IBar> addFlatBars(List<IBar> bars, int flatsNumber, Period period)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5532 */     IBar lastCandle = (IBar)bars.get(bars.size() - 1);
/* 5533 */     double price = lastCandle.getClose();
/* 5534 */     int i = 0; for (long lastTime = DataCacheUtils.getNextCandleStartFast(period, lastCandle.getTime()); 
/* 5535 */         i < flatsNumber; lastTime = DataCacheUtils.getNextCandleStartFast(period, lastTime))
/*      */     {
/* 5537 */       bars.add(new CandleData(lastTime, price, price, price, price, 0.0D));i++;
/*      */     }
/*      */     
/* 5540 */     return bars;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Object[] calculateIndicator(IFeedDescriptor feedDescriptor, OfferSide[] offerSides, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, long from, long to)
/*      */     throws JFException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +14 -> 15
/*      */     //   4: new 61	com/dukascopy/api/JFException
/*      */     //   7: dup
/*      */     //   8: ldc_w 530
/*      */     //   11: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   14: athrow
/*      */     //   15: aload_1
/*      */     //   16: invokeinterface 531 1 0
/*      */     //   21: ifnonnull +14 -> 35
/*      */     //   24: new 61	com/dukascopy/api/JFException
/*      */     //   27: dup
/*      */     //   28: ldc_w 532
/*      */     //   31: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   34: athrow
/*      */     //   35: aload_3
/*      */     //   36: aload 5
/*      */     //   38: invokestatic 352	com/dukascopy/dds2/greed/util/IndicatorHelper$PeriodParameterMapper:performMapping	(Ljava/lang/String;[Ljava/lang/Object;)V
/*      */     //   41: getstatic 533	com/dukascopy/api/DataType:TICKS	Lcom/dukascopy/api/DataType;
/*      */     //   44: aload_1
/*      */     //   45: invokeinterface 534 1 0
/*      */     //   50: invokevirtual 535	com/dukascopy/api/DataType:equals	(Ljava/lang/Object;)Z
/*      */     //   53: ifne +18 -> 71
/*      */     //   56: getstatic 536	com/dukascopy/api/DataType:TIME_PERIOD_AGGREGATION	Lcom/dukascopy/api/DataType;
/*      */     //   59: aload_1
/*      */     //   60: invokeinterface 534 1 0
/*      */     //   65: invokevirtual 535	com/dukascopy/api/DataType:equals	(Ljava/lang/Object;)Z
/*      */     //   68: ifeq +61 -> 129
/*      */     //   71: aload_1
/*      */     //   72: invokeinterface 537 1 0
/*      */     //   77: astore 10
/*      */     //   79: aload 10
/*      */     //   81: ifnonnull +8 -> 89
/*      */     //   84: getstatic 288	com/dukascopy/api/Filter:NO_FILTER	Lcom/dukascopy/api/Filter;
/*      */     //   87: astore 10
/*      */     //   89: new 522	com/dukascopy/api/impl/Indicators$IndicatorCalcFromToFiltered
/*      */     //   92: dup
/*      */     //   93: aload_0
/*      */     //   94: aload_3
/*      */     //   95: aload_1
/*      */     //   96: invokeinterface 531 1 0
/*      */     //   101: aload_1
/*      */     //   102: invokeinterface 538 1 0
/*      */     //   107: aload_2
/*      */     //   108: aload 4
/*      */     //   110: aload 5
/*      */     //   112: lload 6
/*      */     //   114: lload 8
/*      */     //   116: aload 10
/*      */     //   118: invokespecial 523	com/dukascopy/api/impl/Indicators$IndicatorCalcFromToFiltered:<init>	(Lcom/dukascopy/api/impl/Indicators;Ljava/lang/String;Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;[Lcom/dukascopy/api/OfferSide;[Lcom/dukascopy/api/IIndicators$AppliedPrice;[Ljava/lang/Object;JJLcom/dukascopy/api/Filter;)V
/*      */     //   121: astore 11
/*      */     //   123: aload 11
/*      */     //   125: invokevirtual 524	com/dukascopy/api/impl/Indicators$IndicatorCalcFromToFiltered:calculate	()[Ljava/lang/Object;
/*      */     //   128: areturn
/*      */     //   129: aload_0
/*      */     //   130: aload_2
/*      */     //   131: invokevirtual 443	com/dukascopy/api/impl/Indicators:checkSide	([Lcom/dukascopy/api/OfferSide;)V
/*      */     //   134: aload_0
/*      */     //   135: getfield 21	com/dukascopy/api/impl/Indicators:history	Lcom/dukascopy/api/impl/History;
/*      */     //   138: aload_1
/*      */     //   139: invokeinterface 531 1 0
/*      */     //   144: lload 6
/*      */     //   146: lload 8
/*      */     //   148: invokevirtual 539	com/dukascopy/api/impl/History:validateTimeInterval	(Lcom/dukascopy/api/Instrument;JJ)V
/*      */     //   151: aload_0
/*      */     //   152: aload_3
/*      */     //   153: invokevirtual 38	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */     //   156: astore 10
/*      */     //   158: aload 10
/*      */     //   160: ifnonnull +19 -> 179
/*      */     //   163: aload_3
/*      */     //   164: invokestatic 540	com/dukascopy/api/impl/IndicatorMessages:getIndicatorNotFoundMsg	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   167: astore 11
/*      */     //   169: new 61	com/dukascopy/api/JFException
/*      */     //   172: dup
/*      */     //   173: aload 11
/*      */     //   175: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   178: athrow
/*      */     //   179: aload_0
/*      */     //   180: aload 10
/*      */     //   182: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   185: aload 5
/*      */     //   187: invokevirtual 272	com/dukascopy/api/impl/Indicators:setOptParams	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)V
/*      */     //   190: aload_0
/*      */     //   191: aload 10
/*      */     //   193: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   196: aload 5
/*      */     //   198: invokevirtual 541	com/dukascopy/api/impl/Indicators:calculateLookbackLookforward	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)[I
/*      */     //   201: astore 11
/*      */     //   203: aload_0
/*      */     //   204: aload_1
/*      */     //   205: aload_2
/*      */     //   206: aload 4
/*      */     //   208: lload 6
/*      */     //   210: lload 8
/*      */     //   212: aload 10
/*      */     //   214: aload 11
/*      */     //   216: iconst_0
/*      */     //   217: iaload
/*      */     //   218: aload 11
/*      */     //   220: iconst_1
/*      */     //   221: iaload
/*      */     //   222: aload 11
/*      */     //   224: iconst_2
/*      */     //   225: iaload
/*      */     //   226: invokespecial 542	com/dukascopy/api/impl/Indicators:calculateIndicator	(Lcom/dukascopy/api/feed/IFeedDescriptor;[Lcom/dukascopy/api/OfferSide;[Lcom/dukascopy/api/IIndicators$AppliedPrice;JJLcom/dukascopy/api/impl/IndicatorHolder;III)[Ljava/lang/Object;
/*      */     //   229: astore 12
/*      */     //   231: aload 10
/*      */     //   233: invokevirtual 543	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */     //   236: aconst_null
/*      */     //   237: invokevirtual 544	com/dukascopy/api/impl/IndicatorContext:setFeedDescriptor	(Lcom/dukascopy/api/feed/IFeedDescriptor;)V
/*      */     //   240: aload_0
/*      */     //   241: aload_3
/*      */     //   242: aload 10
/*      */     //   244: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   247: aload 12
/*      */     //   249: areturn
/*      */     //   250: astore 13
/*      */     //   252: aload 10
/*      */     //   254: invokevirtual 543	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */     //   257: aconst_null
/*      */     //   258: invokevirtual 544	com/dukascopy/api/impl/IndicatorContext:setFeedDescriptor	(Lcom/dukascopy/api/feed/IFeedDescriptor;)V
/*      */     //   261: aload_0
/*      */     //   262: aload_3
/*      */     //   263: aload 10
/*      */     //   265: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   268: aload 13
/*      */     //   270: athrow
/*      */     //   271: astore 10
/*      */     //   273: aload 10
/*      */     //   275: athrow
/*      */     //   276: astore 10
/*      */     //   278: aload 10
/*      */     //   280: athrow
/*      */     //   281: astore 10
/*      */     //   283: new 61	com/dukascopy/api/JFException
/*      */     //   286: dup
/*      */     //   287: aload 10
/*      */     //   289: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   292: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5553	-> byte code offset #0
/*      */     //   Java source line #5554	-> byte code offset #4
/*      */     //   Java source line #5556	-> byte code offset #15
/*      */     //   Java source line #5557	-> byte code offset #24
/*      */     //   Java source line #5560	-> byte code offset #35
/*      */     //   Java source line #5562	-> byte code offset #41
/*      */     //   Java source line #5566	-> byte code offset #71
/*      */     //   Java source line #5567	-> byte code offset #79
/*      */     //   Java source line #5568	-> byte code offset #84
/*      */     //   Java source line #5570	-> byte code offset #89
/*      */     //   Java source line #5572	-> byte code offset #123
/*      */     //   Java source line #5576	-> byte code offset #129
/*      */     //   Java source line #5577	-> byte code offset #134
/*      */     //   Java source line #5578	-> byte code offset #151
/*      */     //   Java source line #5579	-> byte code offset #158
/*      */     //   Java source line #5580	-> byte code offset #163
/*      */     //   Java source line #5581	-> byte code offset #169
/*      */     //   Java source line #5584	-> byte code offset #179
/*      */     //   Java source line #5585	-> byte code offset #190
/*      */     //   Java source line #5587	-> byte code offset #203
/*      */     //   Java source line #5589	-> byte code offset #231
/*      */     //   Java source line #5590	-> byte code offset #240
/*      */     //   Java source line #5589	-> byte code offset #250
/*      */     //   Java source line #5590	-> byte code offset #261
/*      */     //   Java source line #5592	-> byte code offset #271
/*      */     //   Java source line #5593	-> byte code offset #273
/*      */     //   Java source line #5594	-> byte code offset #276
/*      */     //   Java source line #5595	-> byte code offset #278
/*      */     //   Java source line #5596	-> byte code offset #281
/*      */     //   Java source line #5597	-> byte code offset #283
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	293	0	this	Indicators
/*      */     //   0	293	1	feedDescriptor	IFeedDescriptor
/*      */     //   0	293	2	offerSides	OfferSide[]
/*      */     //   0	293	3	functionName	String
/*      */     //   0	293	4	inputTypes	IIndicators.AppliedPrice[]
/*      */     //   0	293	5	optParams	Object[]
/*      */     //   0	293	6	from	long
/*      */     //   0	293	8	to	long
/*      */     //   77	40	10	filter	Filter
/*      */     //   156	108	10	indicatorHolder	IndicatorHolder
/*      */     //   271	3	10	e	JFException
/*      */     //   276	3	10	e	RuntimeException
/*      */     //   281	7	10	e	Exception
/*      */     //   121	3	11	calc	IndicatorCalcFromToFiltered
/*      */     //   167	7	11	msg	String
/*      */     //   201	22	11	lookSides	int[]
/*      */     //   250	19	13	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   179	231	250	finally
/*      */     //   250	252	250	finally
/*      */     //   129	247	271	com/dukascopy/api/JFException
/*      */     //   250	271	271	com/dukascopy/api/JFException
/*      */     //   129	247	276	java/lang/RuntimeException
/*      */     //   250	271	276	java/lang/RuntimeException
/*      */     //   129	247	281	java/lang/Exception
/*      */     //   250	271	281	java/lang/Exception
/*      */   }
/*      */   
/*      */   private Object[] calculateIndicator(IFeedDescriptor feedDescriptor, OfferSide[] offerSides, IIndicators.AppliedPrice[] inputTypes, final long from, long to, IndicatorHolder indicatorHolder, int indicatorLookback, final int lookBack, int lookForward)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5612 */     int inputLength = feedDataToIndicator(new BarsLoadable()
/*      */     {
/*      */ 
/*      */       public List<IBar> load(IFeedDescriptor fd) throws JFException {
/* 5616 */         return Indicators.this.loadBarsFromTo(fd, from, lookBack, this.val$lookBack, this.val$lookForward); } }, feedDescriptor, offerSides, inputTypes, indicatorHolder, indicatorLookback, lookBack, lookForward);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5628 */     IIndicator indicator = indicatorHolder.getIndicator();
/*      */     
/* 5630 */     if (inputLength <= 0)
/*      */     {
/* 5632 */       return getEmptyIndicatorCalcResultArray(indicator);
/*      */     }
/*      */     
/* 5635 */     return calculateIndicator(null, from, to, indicator, indicatorLookback, lookBack, lookForward, inputLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<IBar> loadBarsFromTo(final IFeedDescriptor feedDescriptor, final long from, final long to, final int lookBack, int lookForward)
/*      */     throws JFException
/*      */   {
/* 5646 */     DataType dataType = feedDescriptor.getDataType();
/*      */     
/*      */     List<IBar> converedResult;
/* 5649 */     if (DataType.PRICE_RANGE_AGGREGATION.equals(dataType)) {
/* 5650 */       List<IRangeBar> result = loadBarsFromTo(new BarsLoadable()
/*      */       
/*      */ 
/*      */ 
/* 5654 */         new BarsLoadable
/*      */         {
/*      */ 
/*      */           public List<IRangeBar> load(IFeedDescriptor fd) throws JFException {
/* 5654 */             return Indicators.this.history.getRangeBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), from, this.val$to); } }, new BarsLoadable()
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5660 */         new BarsLoadable
/*      */         {
/*      */ 
/*      */ 
/*      */           public List<IRangeBar> load(IFeedDescriptor fd)
/*      */             throws JFException {
/* 5660 */             return Indicators.this.history.getRangeBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), lookBack, DataCacheUtils.getPreviousPriceAggregationBarStart(from), 0); } }, new BarsLoadable()
/*      */         {
/*      */ 
/*      */ 
/*      */           public List<IRangeBar> load(IFeedDescriptor fd)
/*      */             throws JFException {
/* 5666 */             return Indicators.this.history.getRangeBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), 0, DataCacheUtils.getNextPriceAggregationBarStart(to), this.val$lookForward); } }, lookBack, lookForward);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5672 */       converedResult = new ArrayList(result);
/*      */     } else { List<IBar> converedResult;
/* 5674 */       if (DataType.POINT_AND_FIGURE.equals(dataType)) {
/* 5675 */         List<IPointAndFigure> result = loadBarsFromTo(new BarsLoadable()
/*      */         
/*      */ 
/*      */ 
/* 5679 */           new BarsLoadable
/*      */           {
/*      */ 
/*      */             public List<IPointAndFigure> load(IFeedDescriptor fd) throws JFException {
/* 5679 */               return Indicators.this.history.getPointAndFigures(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), from, this.val$to); } }, new BarsLoadable()
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5685 */           new BarsLoadable
/*      */           {
/*      */ 
/*      */ 
/*      */             public List<IPointAndFigure> load(IFeedDescriptor fd)
/*      */               throws JFException {
/* 5685 */               return Indicators.this.history.getPointAndFigures(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), lookBack, DataCacheUtils.getPreviousPriceAggregationBarStart(from), 0); } }, new BarsLoadable()
/*      */           {
/*      */ 
/*      */ 
/*      */             public List<IPointAndFigure> load(IFeedDescriptor fd)
/*      */               throws JFException {
/* 5691 */               return Indicators.this.history.getPointAndFigures(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), 0, DataCacheUtils.getNextPriceAggregationBarStart(to), this.val$lookForward); } }, lookBack, lookForward);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5697 */         converedResult = new ArrayList(result);
/*      */       } else { List<IBar> converedResult;
/* 5699 */         if (DataType.TICK_BAR.equals(dataType)) {
/* 5700 */           List<ITickBar> result = loadBarsFromTo(new BarsLoadable()
/*      */           
/*      */ 
/*      */ 
/* 5704 */             new BarsLoadable
/*      */             {
/*      */ 
/*      */               public List<ITickBar> load(IFeedDescriptor fd) throws JFException {
/* 5704 */                 return Indicators.this.history.getTickBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), from, this.val$to); } }, new BarsLoadable()
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5710 */             new BarsLoadable
/*      */             {
/*      */ 
/*      */ 
/*      */               public List<ITickBar> load(IFeedDescriptor fd)
/*      */                 throws JFException {
/* 5710 */                 return Indicators.this.history.getTickBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), lookBack, DataCacheUtils.getPreviousPriceAggregationBarStart(from), 0); } }, new BarsLoadable()
/*      */             {
/*      */ 
/*      */ 
/*      */               public List<ITickBar> load(IFeedDescriptor fd)
/*      */                 throws JFException {
/* 5716 */                 return Indicators.this.history.getTickBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), 0, DataCacheUtils.getNextPriceAggregationBarStart(to), this.val$lookForward); } }, lookBack, lookForward);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5722 */           converedResult = new ArrayList(result);
/*      */         } else { List<IBar> converedResult;
/* 5724 */           if (DataType.RENKO.equals(dataType)) {
/* 5725 */             List<IRenkoBar> result = loadBarsFromTo(new BarsLoadable()
/*      */             
/*      */ 
/*      */ 
/* 5729 */               new BarsLoadable
/*      */               {
/*      */ 
/*      */                 public List<IRenkoBar> load(IFeedDescriptor fd) throws JFException {
/* 5729 */                   return Indicators.this.history.getRenkoBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), from, this.val$to); } }, new BarsLoadable()
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5735 */               new BarsLoadable
/*      */               {
/*      */ 
/*      */ 
/*      */                 public List<IRenkoBar> load(IFeedDescriptor fd)
/*      */                   throws JFException {
/* 5735 */                   return Indicators.this.history.getRenkoBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), lookBack, DataCacheUtils.getPreviousPriceAggregationBarStart(from), 0); } }, new BarsLoadable()
/*      */               {
/*      */ 
/*      */ 
/*      */                 public List<IRenkoBar> load(IFeedDescriptor fd)
/*      */                   throws JFException {
/* 5741 */                   return Indicators.this.history.getRenkoBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), 0, DataCacheUtils.getNextPriceAggregationBarStart(to), this.val$lookForward); } }, lookBack, lookForward);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5747 */             converedResult = new ArrayList(result);
/*      */           }
/*      */           else
/*      */           {
/* 5751 */             throw new JFException("Unsupported data type [" + dataType + "]");
/*      */           } } } }
/*      */     List<IBar> converedResult;
/* 5754 */     return converedResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <T extends IBar> List<T> loadBarsFromTo(BarsLoadable<T> fromToLoadable, BarsLoadable<T> lookBackLoadable, BarsLoadable<T> lookForwardLoadable, int lookBack, int lookForward)
/*      */     throws JFException
/*      */   {
/* 5768 */     List<T> rangeBars = fromToLoadable.load(null);
/* 5769 */     List<T> lookBackBars = null;
/* 5770 */     List<T> lookForwardBars = null;
/*      */     
/* 5772 */     if (lookBack > 0) {
/* 5773 */       lookBackBars = lookBackLoadable.load(null);
/*      */     }
/*      */     
/* 5776 */     if (lookForward > 0) {
/* 5777 */       lookForwardBars = lookForwardLoadable.load(null);
/*      */     }
/*      */     
/* 5780 */     List<T> result = new ArrayList();
/*      */     
/* 5782 */     if (lookBackBars != null) {
/* 5783 */       result.addAll(lookBackBars);
/*      */     }
/*      */     
/* 5786 */     result.addAll(rangeBars);
/*      */     
/* 5788 */     if (lookForwardBars != null) {
/* 5789 */       result.addAll(lookForwardBars);
/*      */     }
/*      */     
/* 5792 */     return result;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Object[] calculateIndicator(IFeedDescriptor feedDescriptor, OfferSide[] offerSides, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, int shift)
/*      */     throws JFException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +14 -> 15
/*      */     //   4: new 61	com/dukascopy/api/JFException
/*      */     //   7: dup
/*      */     //   8: ldc_w 530
/*      */     //   11: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   14: athrow
/*      */     //   15: aload_3
/*      */     //   16: aload 5
/*      */     //   18: invokestatic 352	com/dukascopy/dds2/greed/util/IndicatorHelper$PeriodParameterMapper:performMapping	(Ljava/lang/String;[Ljava/lang/Object;)V
/*      */     //   21: getstatic 533	com/dukascopy/api/DataType:TICKS	Lcom/dukascopy/api/DataType;
/*      */     //   24: aload_1
/*      */     //   25: invokeinterface 534 1 0
/*      */     //   30: invokevirtual 535	com/dukascopy/api/DataType:equals	(Ljava/lang/Object;)Z
/*      */     //   33: ifne +18 -> 51
/*      */     //   36: getstatic 536	com/dukascopy/api/DataType:TIME_PERIOD_AGGREGATION	Lcom/dukascopy/api/DataType;
/*      */     //   39: aload_1
/*      */     //   40: invokeinterface 534 1 0
/*      */     //   45: invokevirtual 535	com/dukascopy/api/DataType:equals	(Ljava/lang/Object;)Z
/*      */     //   48: ifeq +39 -> 87
/*      */     //   51: new 353	com/dukascopy/api/impl/Indicators$IndicatorCalcShift
/*      */     //   54: dup
/*      */     //   55: aload_0
/*      */     //   56: aload_3
/*      */     //   57: aload_1
/*      */     //   58: invokeinterface 531 1 0
/*      */     //   63: aload_1
/*      */     //   64: invokeinterface 538 1 0
/*      */     //   69: aload_2
/*      */     //   70: aload 4
/*      */     //   72: aload 5
/*      */     //   74: iload 6
/*      */     //   76: invokespecial 354	com/dukascopy/api/impl/Indicators$IndicatorCalcShift:<init>	(Lcom/dukascopy/api/impl/Indicators;Ljava/lang/String;Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;[Lcom/dukascopy/api/OfferSide;[Lcom/dukascopy/api/IIndicators$AppliedPrice;[Ljava/lang/Object;I)V
/*      */     //   79: astore 7
/*      */     //   81: aload 7
/*      */     //   83: invokevirtual 355	com/dukascopy/api/impl/Indicators$IndicatorCalcShift:calculate	()[Ljava/lang/Object;
/*      */     //   86: areturn
/*      */     //   87: aload_0
/*      */     //   88: aload_3
/*      */     //   89: invokevirtual 38	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */     //   92: astore 7
/*      */     //   94: aload_0
/*      */     //   95: aload_2
/*      */     //   96: invokevirtual 443	com/dukascopy/api/impl/Indicators:checkSide	([Lcom/dukascopy/api/OfferSide;)V
/*      */     //   99: aload_0
/*      */     //   100: iload 6
/*      */     //   102: invokevirtual 581	com/dukascopy/api/impl/Indicators:checkShiftPositive	(I)V
/*      */     //   105: aload 7
/*      */     //   107: ifnonnull +19 -> 126
/*      */     //   110: aload_3
/*      */     //   111: invokestatic 540	com/dukascopy/api/impl/IndicatorMessages:getIndicatorNotFoundMsg	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   114: astore 8
/*      */     //   116: new 61	com/dukascopy/api/JFException
/*      */     //   119: dup
/*      */     //   120: aload 8
/*      */     //   122: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   125: athrow
/*      */     //   126: aload_0
/*      */     //   127: aload 7
/*      */     //   129: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   132: aload 5
/*      */     //   134: invokevirtual 541	com/dukascopy/api/impl/Indicators:calculateLookbackLookforward	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)[I
/*      */     //   137: astore 8
/*      */     //   139: aload_0
/*      */     //   140: aload_1
/*      */     //   141: aload_2
/*      */     //   142: aload 4
/*      */     //   144: iload 6
/*      */     //   146: aload 7
/*      */     //   148: aload 8
/*      */     //   150: iconst_0
/*      */     //   151: iaload
/*      */     //   152: aload 8
/*      */     //   154: iconst_1
/*      */     //   155: iaload
/*      */     //   156: aload 8
/*      */     //   158: iconst_2
/*      */     //   159: iaload
/*      */     //   160: invokevirtual 582	com/dukascopy/api/impl/Indicators:calculateIndicator	(Lcom/dukascopy/api/feed/IFeedDescriptor;[Lcom/dukascopy/api/OfferSide;[Lcom/dukascopy/api/IIndicators$AppliedPrice;ILcom/dukascopy/api/impl/IndicatorHolder;III)[Ljava/lang/Object;
/*      */     //   163: astore 9
/*      */     //   165: aload 7
/*      */     //   167: ifnull +19 -> 186
/*      */     //   170: aload 7
/*      */     //   172: invokevirtual 543	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */     //   175: aconst_null
/*      */     //   176: invokevirtual 544	com/dukascopy/api/impl/IndicatorContext:setFeedDescriptor	(Lcom/dukascopy/api/feed/IFeedDescriptor;)V
/*      */     //   179: aload_0
/*      */     //   180: aload_3
/*      */     //   181: aload 7
/*      */     //   183: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   186: aload 9
/*      */     //   188: areturn
/*      */     //   189: astore 10
/*      */     //   191: aload 7
/*      */     //   193: ifnull +19 -> 212
/*      */     //   196: aload 7
/*      */     //   198: invokevirtual 543	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */     //   201: aconst_null
/*      */     //   202: invokevirtual 544	com/dukascopy/api/impl/IndicatorContext:setFeedDescriptor	(Lcom/dukascopy/api/feed/IFeedDescriptor;)V
/*      */     //   205: aload_0
/*      */     //   206: aload_3
/*      */     //   207: aload 7
/*      */     //   209: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   212: aload 10
/*      */     //   214: athrow
/*      */     //   215: astore 7
/*      */     //   217: aload 7
/*      */     //   219: athrow
/*      */     //   220: astore 7
/*      */     //   222: aload 7
/*      */     //   224: athrow
/*      */     //   225: astore 7
/*      */     //   227: new 61	com/dukascopy/api/JFException
/*      */     //   230: dup
/*      */     //   231: aload 7
/*      */     //   233: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   236: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5804	-> byte code offset #0
/*      */     //   Java source line #5805	-> byte code offset #4
/*      */     //   Java source line #5808	-> byte code offset #15
/*      */     //   Java source line #5810	-> byte code offset #21
/*      */     //   Java source line #5814	-> byte code offset #51
/*      */     //   Java source line #5816	-> byte code offset #81
/*      */     //   Java source line #5820	-> byte code offset #87
/*      */     //   Java source line #5822	-> byte code offset #94
/*      */     //   Java source line #5823	-> byte code offset #99
/*      */     //   Java source line #5824	-> byte code offset #105
/*      */     //   Java source line #5825	-> byte code offset #110
/*      */     //   Java source line #5826	-> byte code offset #116
/*      */     //   Java source line #5828	-> byte code offset #126
/*      */     //   Java source line #5829	-> byte code offset #139
/*      */     //   Java source line #5831	-> byte code offset #165
/*      */     //   Java source line #5832	-> byte code offset #170
/*      */     //   Java source line #5833	-> byte code offset #179
/*      */     //   Java source line #5831	-> byte code offset #189
/*      */     //   Java source line #5832	-> byte code offset #196
/*      */     //   Java source line #5833	-> byte code offset #205
/*      */     //   Java source line #5836	-> byte code offset #215
/*      */     //   Java source line #5837	-> byte code offset #217
/*      */     //   Java source line #5838	-> byte code offset #220
/*      */     //   Java source line #5839	-> byte code offset #222
/*      */     //   Java source line #5840	-> byte code offset #225
/*      */     //   Java source line #5841	-> byte code offset #227
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	237	0	this	Indicators
/*      */     //   0	237	1	feedDescriptor	IFeedDescriptor
/*      */     //   0	237	2	offerSides	OfferSide[]
/*      */     //   0	237	3	functionName	String
/*      */     //   0	237	4	inputTypes	IIndicators.AppliedPrice[]
/*      */     //   0	237	5	optParams	Object[]
/*      */     //   0	237	6	shift	int
/*      */     //   79	3	7	calc	IndicatorCalcShift
/*      */     //   92	116	7	indicatorHolder	IndicatorHolder
/*      */     //   215	3	7	e	JFException
/*      */     //   220	3	7	e	RuntimeException
/*      */     //   225	7	7	e	Exception
/*      */     //   114	7	8	msg	String
/*      */     //   137	20	8	lookSides	int[]
/*      */     //   189	24	10	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   94	165	189	finally
/*      */     //   189	191	189	finally
/*      */     //   87	186	215	com/dukascopy/api/JFException
/*      */     //   189	215	215	com/dukascopy/api/JFException
/*      */     //   87	186	220	java/lang/RuntimeException
/*      */     //   189	215	220	java/lang/RuntimeException
/*      */     //   87	186	225	java/lang/Exception
/*      */     //   189	215	225	java/lang/Exception
/*      */   }
/*      */   
/*      */   protected Object[] calculateIndicator(IFeedDescriptor feedDescriptor, OfferSide[] offerSides, IIndicators.AppliedPrice[] inputTypes, final int shift, IndicatorHolder indicatorHolder, int indicatorLookback, final int lookback, final int lookforward)
/*      */     throws JFException, DataCacheException
/*      */   {
/* 5856 */     int inputLength = feedDataToIndicator(new BarsLoadable()
/*      */     {
/*      */ 
/*      */       public List<IBar> load(IFeedDescriptor feedDescriptor) throws JFException {
/* 5860 */         return Indicators.this.loadBarsByShift(feedDescriptor, shift, lookback, lookforward); } }, feedDescriptor, offerSides, inputTypes, indicatorHolder, indicatorLookback, lookback, lookforward);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5872 */     IIndicator indicator = indicatorHolder.getIndicator();
/*      */     
/* 5874 */     if (inputLength <= 0)
/*      */     {
/* 5876 */       return getEmptyIndicatorCalcResult(indicator);
/*      */     }
/*      */     
/*      */ 
/* 5880 */     return calculateIndicator(indicator, indicatorLookback, lookback, lookforward, inputLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<IBar> loadBarsByShift(IFeedDescriptor feedDescriptor, int shift, int lookback, int lookforward)
/*      */     throws JFException
/*      */   {
/* 5890 */     if (lookforward > shift) {
/* 5891 */       return null;
/*      */     }
/*      */     
/* 5894 */     int finalShift = shift - lookforward;
/* 5895 */     IBar shiftedBar = null;
/*      */     
/* 5897 */     if (DataType.PRICE_RANGE_AGGREGATION.equals(feedDescriptor.getDataType())) {
/* 5898 */       shiftedBar = this.history.getRangeBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), finalShift);
/*      */     }
/* 5900 */     else if (DataType.POINT_AND_FIGURE.equals(feedDescriptor.getDataType())) {
/* 5901 */       shiftedBar = this.history.getPointAndFigure(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), finalShift);
/*      */     }
/* 5903 */     else if (DataType.TICK_BAR.equals(feedDescriptor.getDataType())) {
/* 5904 */       shiftedBar = this.history.getTickBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), finalShift);
/* 5905 */       if ((shiftedBar == null) && (finalShift == 0)) {
/* 5906 */         shiftedBar = this.history.getTickBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), 1);
/*      */       }
/*      */     }
/* 5909 */     else if (DataType.RENKO.equals(feedDescriptor.getDataType())) {
/* 5910 */       shiftedBar = this.history.getRenkoBar(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), finalShift);
/*      */     }
/*      */     else {
/* 5913 */       throw new JFException("Unsupported data type [" + feedDescriptor.getDataType() + "]");
/*      */     }
/*      */     
/* 5916 */     if (shiftedBar == null) {
/* 5917 */       return null;
/*      */     }
/*      */     
/* 5920 */     List<IBar> result = new ArrayList();
/*      */     
/* 5922 */     if (lookback + lookforward <= 0) {
/* 5923 */       result.add(shiftedBar);
/*      */     }
/*      */     else {
/* 5926 */       long time = shiftedBar.getTime();
/* 5927 */       int beforeCount = lookback + lookforward + 1;
/*      */       
/* 5929 */       if (DataType.PRICE_RANGE_AGGREGATION.equals(feedDescriptor.getDataType())) {
/* 5930 */         List<IRangeBar> bars = this.history.getRangeBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), beforeCount, time, 0);
/* 5931 */         result.addAll(bars);
/*      */       }
/* 5933 */       else if (DataType.POINT_AND_FIGURE.equals(feedDescriptor.getDataType())) {
/* 5934 */         List<IPointAndFigure> bars = this.history.getPointAndFigures(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), beforeCount, time, 0);
/* 5935 */         result.addAll(bars);
/*      */       }
/* 5937 */       else if (DataType.TICK_BAR.equals(feedDescriptor.getDataType())) {
/* 5938 */         List<ITickBar> bars = this.history.getTickBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), beforeCount, time, 0);
/* 5939 */         result.addAll(bars);
/*      */       }
/* 5941 */       else if (DataType.RENKO.equals(feedDescriptor.getDataType())) {
/* 5942 */         List<IRenkoBar> bars = this.history.getRenkoBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), beforeCount, time, 0);
/* 5943 */         result.addAll(bars);
/*      */       }
/*      */     }
/*      */     
/* 5947 */     return result.isEmpty() ? null : result;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Object[] calculateIndicator(IFeedDescriptor feedDescriptor, OfferSide[] offerSides, String functionName, IIndicators.AppliedPrice[] inputTypes, Object[] optParams, int numberOfBarsBefore, long time, int numberOfBarsAfter)
/*      */     throws JFException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +14 -> 15
/*      */     //   4: new 61	com/dukascopy/api/JFException
/*      */     //   7: dup
/*      */     //   8: ldc_w 530
/*      */     //   11: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   14: athrow
/*      */     //   15: aload_1
/*      */     //   16: invokeinterface 531 1 0
/*      */     //   21: ifnonnull +14 -> 35
/*      */     //   24: new 61	com/dukascopy/api/JFException
/*      */     //   27: dup
/*      */     //   28: ldc_w 532
/*      */     //   31: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   34: athrow
/*      */     //   35: aload_3
/*      */     //   36: aload 5
/*      */     //   38: invokestatic 352	com/dukascopy/dds2/greed/util/IndicatorHelper$PeriodParameterMapper:performMapping	(Ljava/lang/String;[Ljava/lang/Object;)V
/*      */     //   41: getstatic 533	com/dukascopy/api/DataType:TICKS	Lcom/dukascopy/api/DataType;
/*      */     //   44: aload_1
/*      */     //   45: invokeinterface 534 1 0
/*      */     //   50: invokevirtual 535	com/dukascopy/api/DataType:equals	(Ljava/lang/Object;)Z
/*      */     //   53: ifne +18 -> 71
/*      */     //   56: getstatic 536	com/dukascopy/api/DataType:TIME_PERIOD_AGGREGATION	Lcom/dukascopy/api/DataType;
/*      */     //   59: aload_1
/*      */     //   60: invokeinterface 534 1 0
/*      */     //   65: invokevirtual 535	com/dukascopy/api/DataType:equals	(Ljava/lang/Object;)Z
/*      */     //   68: ifeq +49 -> 117
/*      */     //   71: new 387	com/dukascopy/api/impl/Indicators$IndicatorCalcBeforeAfter
/*      */     //   74: dup
/*      */     //   75: aload_0
/*      */     //   76: aload_3
/*      */     //   77: aload_1
/*      */     //   78: invokeinterface 531 1 0
/*      */     //   83: aload_1
/*      */     //   84: invokeinterface 538 1 0
/*      */     //   89: aload_2
/*      */     //   90: aload 4
/*      */     //   92: aload 5
/*      */     //   94: iload 6
/*      */     //   96: lload 7
/*      */     //   98: iload 9
/*      */     //   100: aload_1
/*      */     //   101: invokeinterface 537 1 0
/*      */     //   106: invokespecial 388	com/dukascopy/api/impl/Indicators$IndicatorCalcBeforeAfter:<init>	(Lcom/dukascopy/api/impl/Indicators;Ljava/lang/String;Lcom/dukascopy/api/Instrument;Lcom/dukascopy/api/Period;[Lcom/dukascopy/api/OfferSide;[Lcom/dukascopy/api/IIndicators$AppliedPrice;[Ljava/lang/Object;IJILcom/dukascopy/api/Filter;)V
/*      */     //   109: astore 10
/*      */     //   111: aload 10
/*      */     //   113: invokevirtual 389	com/dukascopy/api/impl/Indicators$IndicatorCalcBeforeAfter:calculate	()[Ljava/lang/Object;
/*      */     //   116: areturn
/*      */     //   117: aload_0
/*      */     //   118: aload_3
/*      */     //   119: invokevirtual 38	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */     //   122: astore 10
/*      */     //   124: aload_0
/*      */     //   125: aload_2
/*      */     //   126: invokevirtual 443	com/dukascopy/api/impl/Indicators:checkSide	([Lcom/dukascopy/api/OfferSide;)V
/*      */     //   129: aload_0
/*      */     //   130: getfield 21	com/dukascopy/api/impl/Indicators:history	Lcom/dukascopy/api/impl/History;
/*      */     //   133: aload_1
/*      */     //   134: invokeinterface 531 1 0
/*      */     //   139: iload 6
/*      */     //   141: lload 7
/*      */     //   143: iload 9
/*      */     //   145: invokevirtual 598	com/dukascopy/api/impl/History:validateBeforeTimeAfter	(Lcom/dukascopy/api/Instrument;IJI)V
/*      */     //   148: aload 10
/*      */     //   150: ifnonnull +19 -> 169
/*      */     //   153: aload_3
/*      */     //   154: invokestatic 540	com/dukascopy/api/impl/IndicatorMessages:getIndicatorNotFoundMsg	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   157: astore 11
/*      */     //   159: new 61	com/dukascopy/api/JFException
/*      */     //   162: dup
/*      */     //   163: aload 11
/*      */     //   165: invokespecial 346	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */     //   168: athrow
/*      */     //   169: aload_0
/*      */     //   170: aload 10
/*      */     //   172: invokevirtual 39	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */     //   175: aload 5
/*      */     //   177: invokevirtual 541	com/dukascopy/api/impl/Indicators:calculateLookbackLookforward	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)[I
/*      */     //   180: astore 11
/*      */     //   182: aload_0
/*      */     //   183: aload_1
/*      */     //   184: aload_2
/*      */     //   185: aload 4
/*      */     //   187: iload 6
/*      */     //   189: lload 7
/*      */     //   191: iload 9
/*      */     //   193: aload 10
/*      */     //   195: aload 11
/*      */     //   197: iconst_0
/*      */     //   198: iaload
/*      */     //   199: aload 11
/*      */     //   201: iconst_1
/*      */     //   202: iaload
/*      */     //   203: aload 11
/*      */     //   205: iconst_2
/*      */     //   206: iaload
/*      */     //   207: invokespecial 599	com/dukascopy/api/impl/Indicators:calculateIndicator	(Lcom/dukascopy/api/feed/IFeedDescriptor;[Lcom/dukascopy/api/OfferSide;[Lcom/dukascopy/api/IIndicators$AppliedPrice;IJILcom/dukascopy/api/impl/IndicatorHolder;III)[Ljava/lang/Object;
/*      */     //   210: astore 12
/*      */     //   212: aload 10
/*      */     //   214: ifnull +19 -> 233
/*      */     //   217: aload 10
/*      */     //   219: invokevirtual 543	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */     //   222: aconst_null
/*      */     //   223: invokevirtual 544	com/dukascopy/api/impl/IndicatorContext:setFeedDescriptor	(Lcom/dukascopy/api/feed/IFeedDescriptor;)V
/*      */     //   226: aload_0
/*      */     //   227: aload_3
/*      */     //   228: aload 10
/*      */     //   230: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   233: aload 12
/*      */     //   235: areturn
/*      */     //   236: astore 13
/*      */     //   238: aload 10
/*      */     //   240: ifnull +19 -> 259
/*      */     //   243: aload 10
/*      */     //   245: invokevirtual 543	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */     //   248: aconst_null
/*      */     //   249: invokevirtual 544	com/dukascopy/api/impl/IndicatorContext:setFeedDescriptor	(Lcom/dukascopy/api/feed/IFeedDescriptor;)V
/*      */     //   252: aload_0
/*      */     //   253: aload_3
/*      */     //   254: aload 10
/*      */     //   256: invokevirtual 43	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */     //   259: aload 13
/*      */     //   261: athrow
/*      */     //   262: astore 10
/*      */     //   264: aload 10
/*      */     //   266: athrow
/*      */     //   267: astore 10
/*      */     //   269: aload 10
/*      */     //   271: athrow
/*      */     //   272: astore 10
/*      */     //   274: new 61	com/dukascopy/api/JFException
/*      */     //   277: dup
/*      */     //   278: aload 10
/*      */     //   280: invokespecial 285	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */     //   283: athrow
/*      */     // Line number table:
/*      */     //   Java source line #5962	-> byte code offset #0
/*      */     //   Java source line #5963	-> byte code offset #4
/*      */     //   Java source line #5966	-> byte code offset #15
/*      */     //   Java source line #5967	-> byte code offset #24
/*      */     //   Java source line #5970	-> byte code offset #35
/*      */     //   Java source line #5972	-> byte code offset #41
/*      */     //   Java source line #5976	-> byte code offset #71
/*      */     //   Java source line #5978	-> byte code offset #111
/*      */     //   Java source line #5982	-> byte code offset #117
/*      */     //   Java source line #5984	-> byte code offset #124
/*      */     //   Java source line #5985	-> byte code offset #129
/*      */     //   Java source line #5986	-> byte code offset #148
/*      */     //   Java source line #5987	-> byte code offset #153
/*      */     //   Java source line #5988	-> byte code offset #159
/*      */     //   Java source line #5990	-> byte code offset #169
/*      */     //   Java source line #5991	-> byte code offset #182
/*      */     //   Java source line #5993	-> byte code offset #212
/*      */     //   Java source line #5994	-> byte code offset #217
/*      */     //   Java source line #5995	-> byte code offset #226
/*      */     //   Java source line #5993	-> byte code offset #236
/*      */     //   Java source line #5994	-> byte code offset #243
/*      */     //   Java source line #5995	-> byte code offset #252
/*      */     //   Java source line #5998	-> byte code offset #262
/*      */     //   Java source line #5999	-> byte code offset #264
/*      */     //   Java source line #6000	-> byte code offset #267
/*      */     //   Java source line #6001	-> byte code offset #269
/*      */     //   Java source line #6002	-> byte code offset #272
/*      */     //   Java source line #6003	-> byte code offset #274
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	284	0	this	Indicators
/*      */     //   0	284	1	feedDescriptor	IFeedDescriptor
/*      */     //   0	284	2	offerSides	OfferSide[]
/*      */     //   0	284	3	functionName	String
/*      */     //   0	284	4	inputTypes	IIndicators.AppliedPrice[]
/*      */     //   0	284	5	optParams	Object[]
/*      */     //   0	284	6	numberOfBarsBefore	int
/*      */     //   0	284	7	time	long
/*      */     //   0	284	9	numberOfBarsAfter	int
/*      */     //   109	3	10	calc	IndicatorCalcBeforeAfter
/*      */     //   122	133	10	indicatorHolder	IndicatorHolder
/*      */     //   262	3	10	e	JFException
/*      */     //   267	3	10	e	RuntimeException
/*      */     //   272	7	10	e	Exception
/*      */     //   157	7	11	msg	String
/*      */     //   180	24	11	lookSides	int[]
/*      */     //   236	24	13	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   124	212	236	finally
/*      */     //   236	238	236	finally
/*      */     //   117	233	262	com/dukascopy/api/JFException
/*      */     //   236	262	262	com/dukascopy/api/JFException
/*      */     //   117	233	267	java/lang/RuntimeException
/*      */     //   236	262	267	java/lang/RuntimeException
/*      */     //   117	233	272	java/lang/Exception
/*      */     //   236	262	272	java/lang/Exception
/*      */   }
/*      */   
/*      */   private Object[] calculateIndicator(IFeedDescriptor feedDescriptor, OfferSide[] offerSides, IIndicators.AppliedPrice[] inputTypes, final int numberOfBarsBefore, final long time, int numberOfBarsAfter, IndicatorHolder indicatorHolder, int indicatorLookback, final int lookback, final int lookforward)
/*      */     throws JFException
/*      */   {
/* 6020 */     int inputLength = feedDataToIndicator(new BarsLoadable()
/*      */     {
/*      */ 
/*      */       public List<IBar> load(IFeedDescriptor feedDescriptor) throws JFException {
/* 6024 */         return Indicators.this.loadBarsBeforeTimeAfter(feedDescriptor, numberOfBarsBefore, time, lookback, lookforward, this.val$lookforward); } }, feedDescriptor, offerSides, inputTypes, indicatorHolder, indicatorLookback, lookback, lookforward);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6036 */     IIndicator indicator = indicatorHolder.getIndicator();
/*      */     
/* 6038 */     if (inputLength <= 0)
/*      */     {
/* 6040 */       return getEmptyIndicatorCalcResultArray(indicator);
/*      */     }
/*      */     
/* 6043 */     return calculateIndicator(numberOfBarsBefore, time, numberOfBarsAfter, indicator, indicatorLookback, lookback, lookforward, inputLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<IBar> loadBarsBeforeTimeAfter(IFeedDescriptor feedDescriptor, int numberOfBarsBefore, long time, int numberOfBarsAfter, int lookback, int lookforward)
/*      */     throws JFException
/*      */   {
/* 6055 */     List<IBar> data = new ArrayList();
/*      */     
/* 6057 */     int beforeCount = numberOfBarsBefore + lookback;
/* 6058 */     int afterCount = numberOfBarsAfter + lookforward;
/*      */     
/* 6060 */     if (DataType.PRICE_RANGE_AGGREGATION.equals(feedDescriptor.getDataType())) {
/* 6061 */       List<IRangeBar> bars = this.history.getRangeBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), beforeCount, time, afterCount);
/* 6062 */       data.addAll(bars);
/*      */     }
/* 6064 */     else if (DataType.POINT_AND_FIGURE.equals(feedDescriptor.getDataType())) {
/* 6065 */       List<IPointAndFigure> bars = this.history.getPointAndFigures(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), feedDescriptor.getReversalAmount(), beforeCount, time, afterCount);
/* 6066 */       data.addAll(bars);
/*      */     }
/* 6068 */     else if (DataType.TICK_BAR.equals(feedDescriptor.getDataType())) {
/* 6069 */       List<ITickBar> bars = this.history.getTickBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getTickBarSize(), beforeCount, time, afterCount);
/* 6070 */       data.addAll(bars);
/*      */     }
/* 6072 */     else if (DataType.RENKO.equals(feedDescriptor.getDataType())) {
/* 6073 */       List<IRenkoBar> bars = this.history.getRenkoBars(feedDescriptor.getInstrument(), feedDescriptor.getOfferSide(), feedDescriptor.getPriceRange(), beforeCount, time, afterCount);
/* 6074 */       data.addAll(bars);
/*      */     }
/*      */     else {
/* 6077 */       throw new JFException("Unsupported data type [" + feedDescriptor.getDataType() + "]");
/*      */     }
/*      */     
/* 6080 */     List<IBar> result = data.size() < beforeCount + afterCount ? null : data;
/* 6081 */     return result;
/*      */   }
/*      */   
/*      */   private Object[] getEmptyIndicatorCalcResult(IIndicator indicator) {
/* 6085 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/*      */     
/* 6087 */     Object[] ret = new Object[indicatorInfo.getNumberOfOutputs()];
/* 6088 */     int k = 0; for (int l = indicatorInfo.getNumberOfOutputs(); k < l; k++) {
/* 6089 */       OutputParameterInfo outInfo = indicator.getOutputParameterInfo(k);
/* 6090 */       switch (outInfo.getType()) {
/*      */       case DOUBLE: 
/* 6092 */         ret[k] = Double.valueOf(NaN.0D);
/* 6093 */         break;
/*      */       case INT: 
/* 6095 */         ret[k] = Integer.valueOf(Integer.MIN_VALUE);
/* 6096 */         break;
/*      */       case OBJECT: 
/* 6098 */         ret[k] = null;
/* 6099 */         break;
/*      */       case CANDLE: 
/* 6101 */         ret[k] = null;
/*      */       }
/*      */       
/*      */     }
/* 6105 */     return ret;
/*      */   }
/*      */   
/*      */   private Object[] getEmptyIndicatorCalcResultArray(IIndicator indicator) {
/* 6109 */     Object[] ret = new Object[indicator.getIndicatorInfo().getNumberOfOutputs()];
/* 6110 */     int i = 0; for (int j = indicator.getIndicatorInfo().getNumberOfOutputs(); i < j; i++) {
/* 6111 */       OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 6112 */       switch (info.getType()) {
/*      */       case DOUBLE: 
/* 6114 */         ret[i] = new double[0];
/* 6115 */         break;
/*      */       case INT: 
/* 6117 */         ret[i] = new int[0];
/* 6118 */         break;
/*      */       case OBJECT: 
/* 6120 */         ret[i] = new Object[0];
/* 6121 */         break;
/*      */       case CANDLE: 
/* 6123 */         ret[i] = new IBar[0];
/*      */       }
/*      */       
/*      */     }
/* 6127 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int feedDataToIndicator(BarsLoadable<IBar> loadable, IFeedDescriptor feedDescriptor, OfferSide[] offerSides, IIndicators.AppliedPrice[] inputTypes, IndicatorHolder indicatorHolder, int indicatorLookback, int lookback, int lookforward)
/*      */     throws JFException
/*      */   {
/* 6141 */     if (feedDescriptor == null) {
/* 6142 */       throw new JFException("FeedDescriptor is null");
/*      */     }
/*      */     
/* 6145 */     int inputLength = Integer.MIN_VALUE;
/* 6146 */     IIndicator indicator = indicatorHolder.getIndicator();
/* 6147 */     IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 6148 */     IndicatorContext indicatorContext = indicatorHolder.getIndicatorContext();
/* 6149 */     indicatorContext.setFeedDescriptor(feedDescriptor);
/*      */     
/* 6151 */     int i = 0; for (int j = indicatorInfo.getNumberOfInputs(); i < j; i++) {
/* 6152 */       InputParameterInfo info = indicator.getInputParameterInfo(i);
/*      */       
/* 6154 */       if ((info.getOfferSide() != null) || (info.getInstrument() != null) || (info.getPeriod() != null)) {
/* 6155 */         throw new JFException("Indicator [" + indicatorInfo.getName() + "] cannot be calculated for data type " + feedDescriptor.getDataType());
/*      */       }
/*      */       
/* 6158 */       OfferSide currentOfferSide = offerSides[i];
/*      */       
/* 6160 */       IFeedDescriptor fd = new FeedDescriptor(feedDescriptor);
/* 6161 */       fd.setOfferSide(currentOfferSide);
/*      */       
/* 6163 */       List<IBar> bars = loadable.load(fd);
/* 6164 */       Object inputData = null;
/*      */       
/* 6166 */       if ((bars == null) || (bars.isEmpty())) {
/* 6167 */         return 0;
/*      */       }
/*      */       
/* 6170 */       inputLength = bars.size();
/* 6171 */       inputData = barsToReal(bars, info.getType(), info.getType() == InputParameterInfo.Type.DOUBLE ? inputTypes[i] : null);
/*      */       
/*      */       try
/*      */       {
/* 6175 */         indicator.setInputParameter(i, inputData);
/*      */       } catch (Throwable t) {
/* 6177 */         LOGGER.error(t.getMessage(), t);
/* 6178 */         String error = StrategyWrapper.representError(indicator, t);
/* 6179 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6180 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6181 */         throw new JFException(t);
/*      */       }
/*      */     }
/*      */     
/* 6185 */     return inputLength;
/*      */   }
/*      */   
/*      */   private static abstract interface BarsLoadable<T>
/*      */   {
/*      */     public abstract List<T> load(IFeedDescriptor paramIFeedDescriptor) throws JFException;
/*      */   }
/*      */   
/*      */   abstract class IndicatorCalc
/*      */   {
/*      */     protected IIndicator indicator;
/*      */     protected Instrument instrument;
/*      */     protected Period period;
/*      */     protected OfferSide[] offerSides;
/*      */     protected String indicatorName;
/*      */     protected IIndicators.AppliedPrice[] appliedPrices;
/*      */     protected Object[] optParams;
/*      */     protected Filter filter;
/*      */     
/*      */     public IndicatorCalc(String indicatorName, Instrument instrument, Period period, OfferSide[] offerSides, IIndicators.AppliedPrice[] appliedPrices, Object[] optParams)
/*      */     {
/* 6206 */       this.indicatorName = indicatorName;
/* 6207 */       this.instrument = instrument;
/* 6208 */       this.period = period;
/* 6209 */       this.offerSides = offerSides;
/* 6210 */       this.appliedPrices = appliedPrices;
/* 6211 */       this.optParams = optParams;
/*      */     }
/*      */     
/*      */     /* Error */
/*      */     public Object[] calculate()
/*      */       throws JFException
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 1	com/dukascopy/api/impl/Indicators$IndicatorCalc:this$0	Lcom/dukascopy/api/impl/Indicators;
/*      */       //   4: getfield 9	com/dukascopy/api/impl/Indicators:history	Lcom/dukascopy/api/impl/History;
/*      */       //   7: aload_0
/*      */       //   8: getfield 4	com/dukascopy/api/impl/Indicators$IndicatorCalc:instrument	Lcom/dukascopy/api/Instrument;
/*      */       //   11: invokevirtual 10	com/dukascopy/api/impl/History:isInstrumentSubscribed	(Lcom/dukascopy/api/Instrument;)Z
/*      */       //   14: ifne +38 -> 52
/*      */       //   17: new 11	com/dukascopy/api/JFException
/*      */       //   20: dup
/*      */       //   21: new 12	java/lang/StringBuilder
/*      */       //   24: dup
/*      */       //   25: invokespecial 13	java/lang/StringBuilder:<init>	()V
/*      */       //   28: ldc 14
/*      */       //   30: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   33: aload_0
/*      */       //   34: getfield 4	com/dukascopy/api/impl/Indicators$IndicatorCalc:instrument	Lcom/dukascopy/api/Instrument;
/*      */       //   37: invokevirtual 16	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */       //   40: ldc 17
/*      */       //   42: invokevirtual 15	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   45: invokevirtual 18	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */       //   48: invokespecial 19	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */       //   51: athrow
/*      */       //   52: aload_0
/*      */       //   53: getfield 1	com/dukascopy/api/impl/Indicators$IndicatorCalc:this$0	Lcom/dukascopy/api/impl/Indicators;
/*      */       //   56: aload_0
/*      */       //   57: getfield 3	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicatorName	Ljava/lang/String;
/*      */       //   60: invokevirtual 20	com/dukascopy/api/impl/Indicators:getCachedIndicator	(Ljava/lang/String;)Lcom/dukascopy/api/impl/IndicatorHolder;
/*      */       //   63: astore_1
/*      */       //   64: aload_1
/*      */       //   65: ifnonnull +20 -> 85
/*      */       //   68: aload_0
/*      */       //   69: getfield 3	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicatorName	Ljava/lang/String;
/*      */       //   72: invokestatic 21	com/dukascopy/api/impl/IndicatorMessages:getIndicatorNotFoundMsg	(Ljava/lang/String;)Ljava/lang/String;
/*      */       //   75: astore_2
/*      */       //   76: new 11	com/dukascopy/api/JFException
/*      */       //   79: dup
/*      */       //   80: aload_2
/*      */       //   81: invokespecial 19	com/dukascopy/api/JFException:<init>	(Ljava/lang/String;)V
/*      */       //   84: athrow
/*      */       //   85: aload_0
/*      */       //   86: aload_1
/*      */       //   87: invokevirtual 22	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */       //   90: putfield 23	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicator	Lcom/dukascopy/api/indicators/IIndicator;
/*      */       //   93: aload_0
/*      */       //   94: getfield 3	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicatorName	Ljava/lang/String;
/*      */       //   97: ldc 24
/*      */       //   99: invokevirtual 25	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */       //   102: ifne +15 -> 117
/*      */       //   105: aload_0
/*      */       //   106: getfield 3	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicatorName	Ljava/lang/String;
/*      */       //   109: ldc 26
/*      */       //   111: invokevirtual 25	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */       //   114: ifeq +8 -> 122
/*      */       //   117: aload_0
/*      */       //   118: invokevirtual 27	com/dukascopy/api/impl/Indicators$IndicatorCalc:calculateSAR	()[Ljava/lang/Object;
/*      */       //   121: areturn
/*      */       //   122: aload_0
/*      */       //   123: invokevirtual 28	com/dukascopy/api/impl/Indicators$IndicatorCalc:validateParameters	()V
/*      */       //   126: aload_0
/*      */       //   127: getfield 1	com/dukascopy/api/impl/Indicators$IndicatorCalc:this$0	Lcom/dukascopy/api/impl/Indicators;
/*      */       //   130: aload_1
/*      */       //   131: invokevirtual 22	com/dukascopy/api/impl/IndicatorHolder:getIndicator	()Lcom/dukascopy/api/indicators/IIndicator;
/*      */       //   134: aload_0
/*      */       //   135: getfield 8	com/dukascopy/api/impl/Indicators$IndicatorCalc:optParams	[Ljava/lang/Object;
/*      */       //   138: invokevirtual 29	com/dukascopy/api/impl/Indicators:calculateLookbackLookforward	(Lcom/dukascopy/api/indicators/IIndicator;[Ljava/lang/Object;)[I
/*      */       //   141: astore_2
/*      */       //   142: aload_0
/*      */       //   143: aload_1
/*      */       //   144: aload_2
/*      */       //   145: iconst_0
/*      */       //   146: iaload
/*      */       //   147: aload_2
/*      */       //   148: iconst_1
/*      */       //   149: iaload
/*      */       //   150: aload_2
/*      */       //   151: iconst_2
/*      */       //   152: iaload
/*      */       //   153: invokevirtual 30	com/dukascopy/api/impl/Indicators$IndicatorCalc:performIndicatorCalculation	(Lcom/dukascopy/api/impl/IndicatorHolder;III)[Ljava/lang/Object;
/*      */       //   156: astore_3
/*      */       //   157: aload_1
/*      */       //   158: invokevirtual 31	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */       //   161: invokevirtual 32	com/dukascopy/api/impl/IndicatorContext:resetFeedDescriptor	()V
/*      */       //   164: aload_0
/*      */       //   165: getfield 1	com/dukascopy/api/impl/Indicators$IndicatorCalc:this$0	Lcom/dukascopy/api/impl/Indicators;
/*      */       //   168: aload_0
/*      */       //   169: getfield 3	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicatorName	Ljava/lang/String;
/*      */       //   172: aload_1
/*      */       //   173: invokevirtual 33	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */       //   176: aload_3
/*      */       //   177: areturn
/*      */       //   178: astore 4
/*      */       //   180: aload_1
/*      */       //   181: invokevirtual 31	com/dukascopy/api/impl/IndicatorHolder:getIndicatorContext	()Lcom/dukascopy/api/impl/IndicatorContext;
/*      */       //   184: invokevirtual 32	com/dukascopy/api/impl/IndicatorContext:resetFeedDescriptor	()V
/*      */       //   187: aload_0
/*      */       //   188: getfield 1	com/dukascopy/api/impl/Indicators$IndicatorCalc:this$0	Lcom/dukascopy/api/impl/Indicators;
/*      */       //   191: aload_0
/*      */       //   192: getfield 3	com/dukascopy/api/impl/Indicators$IndicatorCalc:indicatorName	Ljava/lang/String;
/*      */       //   195: aload_1
/*      */       //   196: invokevirtual 33	com/dukascopy/api/impl/Indicators:cacheIndicator	(Ljava/lang/String;Lcom/dukascopy/api/impl/IndicatorHolder;)V
/*      */       //   199: aload 4
/*      */       //   201: athrow
/*      */       //   202: astore_1
/*      */       //   203: aload_1
/*      */       //   204: athrow
/*      */       //   205: astore_1
/*      */       //   206: aload_1
/*      */       //   207: athrow
/*      */       //   208: astore_1
/*      */       //   209: new 11	com/dukascopy/api/JFException
/*      */       //   212: dup
/*      */       //   213: aload_1
/*      */       //   214: invokespecial 36	com/dukascopy/api/JFException:<init>	(Ljava/lang/Throwable;)V
/*      */       //   217: athrow
/*      */       // Line number table:
/*      */       //   Java source line #6218	-> byte code offset #0
/*      */       //   Java source line #6219	-> byte code offset #17
/*      */       //   Java source line #6222	-> byte code offset #52
/*      */       //   Java source line #6223	-> byte code offset #64
/*      */       //   Java source line #6224	-> byte code offset #68
/*      */       //   Java source line #6225	-> byte code offset #76
/*      */       //   Java source line #6228	-> byte code offset #85
/*      */       //   Java source line #6230	-> byte code offset #93
/*      */       //   Java source line #6231	-> byte code offset #117
/*      */       //   Java source line #6235	-> byte code offset #122
/*      */       //   Java source line #6236	-> byte code offset #126
/*      */       //   Java source line #6238	-> byte code offset #142
/*      */       //   Java source line #6240	-> byte code offset #157
/*      */       //   Java source line #6241	-> byte code offset #164
/*      */       //   Java source line #6240	-> byte code offset #178
/*      */       //   Java source line #6241	-> byte code offset #187
/*      */       //   Java source line #6244	-> byte code offset #202
/*      */       //   Java source line #6245	-> byte code offset #203
/*      */       //   Java source line #6247	-> byte code offset #205
/*      */       //   Java source line #6248	-> byte code offset #206
/*      */       //   Java source line #6250	-> byte code offset #208
/*      */       //   Java source line #6251	-> byte code offset #209
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	218	0	this	IndicatorCalc
/*      */       //   63	133	1	indicatorHolder	IndicatorHolder
/*      */       //   202	2	1	e	JFException
/*      */       //   205	2	1	e	RuntimeException
/*      */       //   208	6	1	e	Exception
/*      */       //   75	6	2	msg	String
/*      */       //   141	10	2	lookbacksLookforward	int[]
/*      */       //   178	22	4	localObject	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   122	157	178	finally
/*      */       //   178	180	178	finally
/*      */       //   0	121	202	com/dukascopy/api/JFException
/*      */       //   122	176	202	com/dukascopy/api/JFException
/*      */       //   178	202	202	com/dukascopy/api/JFException
/*      */       //   0	121	205	java/lang/RuntimeException
/*      */       //   122	176	205	java/lang/RuntimeException
/*      */       //   178	202	205	java/lang/RuntimeException
/*      */       //   0	121	208	java/lang/Exception
/*      */       //   122	176	208	java/lang/Exception
/*      */       //   178	202	208	java/lang/Exception
/*      */     }
/*      */     
/*      */     protected Object[] performIndicatorCalculation(IndicatorHolder indicatorHolder, int indicatorLookback, int actualLookback, int lookforward)
/*      */       throws JFException, DataCacheException
/*      */     {
/* 6261 */       int inputLength = Integer.MIN_VALUE;
/* 6262 */       IIndicator indicator = indicatorHolder.getIndicator();
/* 6263 */       IndicatorInfo indicatorInfo = indicator.getIndicatorInfo();
/* 6264 */       IndicatorContext indicatorContext = indicatorHolder.getIndicatorContext();
/* 6265 */       IFeedDescriptor feedDescriptor = com.dukascopy.charts.math.indicators.IndicatorCalculator.createFeedDescriptor(indicatorContext, this.period, this.instrument, indicatorInfo.getNumberOfInputs() > 0 ? this.offerSides[0] : OfferSide.BID, null);
/*      */       
/* 6267 */       indicatorContext.setFeedDescriptor(feedDescriptor);
/*      */       
/* 6269 */       int i = 0; for (int j = indicatorInfo.getNumberOfInputs(); i < j; i++) {
/* 6270 */         InputParameterInfo info = indicator.getInputParameterInfo(i);
/* 6271 */         Instrument inputInstrument = info.getInstrument() == null ? this.instrument : info.getInstrument();
/* 6272 */         Period inputPeriod = info.getPeriod() == null ? this.period : info.getPeriod();
/* 6273 */         OfferSide inputSide = info.getOfferSide() == null ? this.offerSides[i] : info.getOfferSide();
/* 6274 */         IIndicators.AppliedPrice appliedPrice = info.getType() == InputParameterInfo.Type.DOUBLE ? this.appliedPrices[i] : null;
/* 6275 */         Filter inputFilter = info.getFilter() == null ? this.filter : info.getFilter();
/*      */         
/* 6277 */         Object inputData = setupInputData(inputInstrument, inputPeriod, inputSide, appliedPrice, info.getType(), inputFilter, actualLookback, lookforward);
/*      */         
/* 6279 */         if (!inputDataExists(inputData)) {
/* 6280 */           return createEmptyResult();
/*      */         }
/*      */         
/* 6283 */         if ((info.getInstrument() == null) && (info.getPeriod() == null)) {
/* 6284 */           if (info.getType() == InputParameterInfo.Type.PRICE) {
/* 6285 */             inputLength = ((double[][])(double[][])inputData)[0].length;
/* 6286 */           } else if (info.getType() == InputParameterInfo.Type.DOUBLE) {
/* 6287 */             inputLength = ((double[])inputData).length;
/* 6288 */           } else if (info.getType() == InputParameterInfo.Type.BAR) {
/* 6289 */             inputLength = ((IBar[])inputData).length;
/*      */           }
/*      */         }
/*      */         try {
/* 6293 */           indicator.setInputParameter(i, inputData);
/*      */         } catch (Throwable t) {
/* 6295 */           Indicators.LOGGER.error(t.getMessage(), t);
/* 6296 */           String error = StrategyWrapper.representError(indicator, t);
/* 6297 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6298 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6299 */           throw new JFException(t);
/*      */         }
/*      */       }
/* 6302 */       if (inputLength == Integer.MIN_VALUE) {
/* 6303 */         if (indicatorInfo.getNumberOfInputs() == 0) {
/* 6304 */           inputLength = 0;
/*      */         } else {
/* 6306 */           Object inputData = setupInputData(actualLookback, lookforward);
/* 6307 */           inputLength = ((IBar[])inputData).length;
/*      */         }
/*      */       }
/*      */       
/* 6311 */       return calculateIndicator(indicator, indicatorInfo, inputLength, indicatorLookback, actualLookback, lookforward);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object[] calculateIndicator(IIndicator indicator, IndicatorInfo indicatorInfo, int inputLength, int indicatorLookback, int actualLookback, int lookforward)
/*      */       throws JFException
/*      */     {
/* 6322 */       if (!inputLengthValid(inputLength, indicatorLookback, lookforward)) {
/* 6323 */         Indicators.LOGGER.warn("There is not enough data to calculate value for " + indicatorInfo.getName());
/* 6324 */         return createEmptyResult();
/*      */       }
/*      */       
/* 6327 */       Object[] outputs = new Object[indicatorInfo.getNumberOfOutputs()];
/* 6328 */       int i = 0; for (int j = indicatorInfo.getNumberOfOutputs(); i < j; i++) {
/* 6329 */         OutputParameterInfo info = indicator.getOutputParameterInfo(i);
/* 6330 */         switch (Indicators.20.$SwitchMap$com$dukascopy$api$indicators$OutputParameterInfo$Type[info.getType().ordinal()]) {
/*      */         case 1: 
/* 6332 */           double[] doubles = new double[inputLength - (indicatorLookback + lookforward)];
/* 6333 */           outputs[i] = doubles;
/*      */           try {
/* 6335 */             indicator.setOutputParameter(i, doubles);
/*      */           } catch (Throwable t) {
/* 6337 */             Indicators.LOGGER.error(t.getMessage(), t);
/* 6338 */             String error = StrategyWrapper.representError(indicator, t);
/* 6339 */             String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6340 */             NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6341 */             throw new JFException(t);
/*      */           }
/*      */         
/*      */         case 2: 
/* 6345 */           int[] ints = new int[inputLength - (indicatorLookback + lookforward)];
/* 6346 */           outputs[i] = ints;
/*      */           try {
/* 6348 */             indicator.setOutputParameter(i, ints);
/*      */           } catch (Throwable t) {
/* 6350 */             Indicators.LOGGER.error(t.getMessage(), t);
/* 6351 */             String error = StrategyWrapper.representError(indicator, t);
/* 6352 */             String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6353 */             NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6354 */             throw new JFException(t);
/*      */           }
/*      */         
/*      */         case 3: 
/* 6358 */           Object[] objects = new Object[inputLength - (indicatorLookback + lookforward)];
/* 6359 */           outputs[i] = objects;
/*      */           try {
/* 6361 */             indicator.setOutputParameter(i, objects);
/*      */           } catch (Throwable t) {
/* 6363 */             Indicators.LOGGER.error(t.getMessage(), t);
/* 6364 */             String error = StrategyWrapper.representError(indicator, t);
/* 6365 */             String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6366 */             NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6367 */             throw new JFException(t);
/*      */           }
/*      */         
/*      */         case 4: 
/* 6371 */           IBar[] candles = new IBar[inputLength - (indicatorLookback + lookforward)];
/* 6372 */           outputs[i] = candles;
/*      */           try {
/* 6374 */             indicator.setOutputParameter(i, candles);
/*      */           } catch (Throwable t) {
/* 6376 */             Indicators.LOGGER.error(t.getMessage(), t);
/* 6377 */             String error = StrategyWrapper.representError(indicator, t);
/* 6378 */             String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6379 */             NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6380 */             throw new JFException(t);
/*      */           }
/*      */         }
/*      */         
/*      */       }
/*      */       IndicatorResult result;
/*      */       try
/*      */       {
/* 6388 */         result = indicator.calculate(0, inputLength - 1);
/*      */       } catch (TaLibException e) {
/* 6390 */         Throwable t = e.getCause();
/* 6391 */         Indicators.LOGGER.error(t.getMessage(), t);
/* 6392 */         String error = StrategyWrapper.representError(indicator, t);
/* 6393 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6394 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6395 */         throw new JFException(t);
/*      */       } catch (Throwable t) {
/* 6397 */         Indicators.LOGGER.error(t.getMessage(), t);
/* 6398 */         String error = StrategyWrapper.representError(indicator, t);
/* 6399 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6400 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, true);
/* 6401 */         throw new JFException(t);
/*      */       }
/*      */       
/* 6404 */       if ((result.getLastValueIndex() == Integer.MIN_VALUE) && (result.getNumberOfElements() != 0)) {
/* 6405 */         if (lookforward != 0) {
/* 6406 */           String error = IndicatorMessages.getIndexNotSetMsg(indicatorInfo.getName());
/* 6407 */           Indicators.LOGGER.error(error);
/* 6408 */           String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6409 */           NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 6410 */           throw new JFException(error);
/*      */         }
/* 6412 */         result.setLastValueIndex(inputLength - 1);
/*      */       }
/*      */       
/* 6415 */       if ((result.getLastValueIndex() + 1 - result.getFirstValueIndex() < inputLength - actualLookback - lookforward) || (result.getNumberOfElements() < inputLength - actualLookback - lookforward))
/*      */       {
/* 6417 */         String error = IndicatorMessages.getLackOfValuesMsg(indicator.getIndicatorInfo().getName());
/* 6418 */         Indicators.LOGGER.error(error);
/* 6419 */         String msg = IndicatorMessages.getIndicatorErrorMsg(error);
/* 6420 */         NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, true);
/* 6421 */         throw new JFException(error);
/*      */       }
/*      */       
/* 6424 */       Object[] res = setupResult(result, outputs, inputLength, actualLookback, lookforward);
/*      */       
/* 6426 */       return res;
/*      */     }
/*      */     
/*      */     protected void checkPeriodCompatibility(Period childPeriod) throws JFException {
/* 6430 */       if (this.period.getInterval() > childPeriod.getInterval()) {
/* 6431 */         throw new JFException("Indicator [" + this.indicator.getIndicatorInfo().getName() + "] cannot be run with periods longer than " + childPeriod);
/*      */       }
/*      */     }
/*      */     
/*      */     protected abstract Object[] createEmptyResult();
/*      */     
/*      */     protected abstract Object[] calculateSAR() throws JFException;
/*      */     
/*      */     protected abstract void validateParameters() throws JFException;
/*      */     
/*      */     protected abstract Object setupInputData(Instrument paramInstrument, Period paramPeriod, OfferSide paramOfferSide, IIndicators.AppliedPrice paramAppliedPrice, InputParameterInfo.Type paramType, Filter paramFilter, int paramInt1, int paramInt2) throws JFException, DataCacheException;
/*      */     
/*      */     protected abstract Object setupInputData(int paramInt1, int paramInt2) throws JFException, DataCacheException;
/*      */     
/*      */     protected abstract boolean inputLengthValid(int paramInt1, int paramInt2, int paramInt3);
/*      */     
/*      */     protected abstract boolean inputDataExists(Object paramObject);
/*      */     
/*      */     protected abstract Object[] setupResult(IndicatorResult paramIndicatorResult, Object[] paramArrayOfObject, int paramInt1, int paramInt2, int paramInt3) throws JFException;
/*      */   }
/*      */   
/*      */   class IndicatorCalcShift
/*      */     extends Indicators.IndicatorCalc
/*      */   {
/*      */     private int shift;
/*      */     
/*      */     public IndicatorCalcShift(String indicatorName, Instrument instrument, Period period, OfferSide[] offerSides, IIndicators.AppliedPrice[] appliedPrices, Object[] optParams, int shift)
/*      */     {
/* 6459 */       super(indicatorName, instrument, period, offerSides, appliedPrices, optParams);
/* 6460 */       this.shift = shift;
/*      */     }
/*      */     
/*      */     protected Object[] calculateSAR() throws JFException {
/* 6464 */       if (this.indicatorName.equals("SAR")) {
/* 6465 */         double res = Indicators.this.sar(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), this.shift);
/*      */         
/* 6467 */         return new Object[] { Double.valueOf(res) };
/*      */       }
/*      */       
/* 6470 */       double res = Indicators.this.sarExt(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), ((Double)this.optParams[2]).doubleValue(), ((Double)this.optParams[3]).doubleValue(), ((Double)this.optParams[4]).doubleValue(), ((Double)this.optParams[5]).doubleValue(), ((Double)this.optParams[6]).doubleValue(), ((Double)this.optParams[7]).doubleValue(), this.shift);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 6475 */       return new Object[] { Double.valueOf(res) };
/*      */     }
/*      */     
/*      */     protected void validateParameters() throws JFException
/*      */     {
/* 6480 */       Indicators.this.checkNotTick(this.period);
/* 6481 */       Indicators.this.checkSide(this.period, this.offerSides);
/* 6482 */       Indicators.this.checkShiftPositive(this.shift);
/*      */     }
/*      */     
/*      */     protected boolean inputLengthValid(int inputLength, int indicatorLookback, int lookforward) {
/* 6486 */       boolean res = inputLength > indicatorLookback + lookforward;
/* 6487 */       return res;
/*      */     }
/*      */     
/*      */     protected Object setupInputData(int lookback, int lookforward) throws JFException, DataCacheException {
/* 6491 */       return Indicators.this.getInputData(this.instrument, this.period, OfferSide.BID, InputParameterInfo.Type.BAR, null, this.shift, lookback, lookforward);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object setupInputData(Instrument inputInstrument, Period inputPeriod, OfferSide inputOfferSide, IIndicators.AppliedPrice appliedPrice, InputParameterInfo.Type inputType, Filter inputFilter, int lookback, int lookforward)
/*      */       throws JFException, DataCacheException
/*      */     {
/*      */       Object inputData;
/*      */       
/*      */ 
/*      */       Object inputData;
/*      */       
/*      */ 
/* 6506 */       if ((inputInstrument == this.instrument) && (inputPeriod == this.period)) {
/* 6507 */         inputData = Indicators.this.getInputData(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, this.shift, lookback, lookforward);
/*      */       } else {
/* 6509 */         checkPeriodCompatibility(inputPeriod);
/* 6510 */         int currentShift = Indicators.this.calculateShift(this.instrument, inputPeriod, this.period, this.shift);
/*      */         
/*      */ 
/* 6513 */         int currentLookforward = currentShift >= lookforward ? lookforward : currentShift < 0 ? 0 : currentShift;
/* 6514 */         inputData = Indicators.this.getInputData(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, currentShift, lookback, currentLookforward);
/*      */       }
/*      */       
/* 6517 */       return inputData;
/*      */     }
/*      */     
/*      */     protected boolean inputDataExists(Object inputData) {
/* 6521 */       boolean res = inputData != null;
/* 6522 */       return res;
/*      */     }
/*      */     
/*      */     protected Object[] createEmptyResult() {
/* 6526 */       return Indicators.this.getEmptyIndicatorCalcResult(this.indicator);
/*      */     }
/*      */     
/*      */     protected Object[] setupResult(IndicatorResult result, Object[] outputs, int inputLength, int actualLookback, int lookforward) throws JFException {
/* 6530 */       Object[] ret = new Object[this.indicator.getIndicatorInfo().getNumberOfOutputs()];
/* 6531 */       int i = 0; for (int j = this.indicator.getIndicatorInfo().getNumberOfOutputs(); i < j; i++) {
/* 6532 */         OutputParameterInfo info = this.indicator.getOutputParameterInfo(i);
/* 6533 */         if (result.getNumberOfElements() == 0) {
/* 6534 */           throw new JFException("Indicator didn't return any value");
/*      */         }
/* 6536 */         switch (Indicators.20.$SwitchMap$com$dukascopy$api$indicators$OutputParameterInfo$Type[info.getType().ordinal()]) {
/*      */         case 1: 
/* 6538 */           double[] doubles = (double[])outputs[i];
/* 6539 */           ret[i] = Double.valueOf(doubles[(result.getNumberOfElements() - 1)]);
/* 6540 */           break;
/*      */         case 2: 
/* 6542 */           int[] ints = (int[])outputs[i];
/* 6543 */           ret[i] = Integer.valueOf(ints[(result.getNumberOfElements() - 1)]);
/* 6544 */           break;
/*      */         case 3: 
/* 6546 */           Object[] objects = (Object[])outputs[i];
/* 6547 */           ret[i] = objects[(result.getNumberOfElements() - 1)];
/* 6548 */           break;
/*      */         case 4: 
/* 6550 */           IBar[] candles = (IBar[])outputs[i];
/* 6551 */           ret[i] = candles[(result.getNumberOfElements() - 1)];
/*      */         }
/*      */         
/*      */       }
/* 6555 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   class IndicatorCalcFromTo
/*      */     extends Indicators.IndicatorCalc
/*      */   {
/*      */     protected long from;
/*      */     
/*      */ 
/*      */     protected long to;
/*      */     
/*      */ 
/*      */ 
/*      */     public IndicatorCalcFromTo(String indicatorName, Instrument instrument, Period period, OfferSide[] offerSides, IIndicators.AppliedPrice[] appliedPrices, Object[] optParams, long from, long to)
/*      */     {
/* 6573 */       super(indicatorName, instrument, period, offerSides, appliedPrices, optParams);
/* 6574 */       this.from = from;
/* 6575 */       this.to = to;
/*      */     }
/*      */     
/*      */     protected Object[] calculateSAR() throws JFException {
/* 6579 */       if (this.indicatorName.equals("SAR")) {
/* 6580 */         double[] res = Indicators.this.sar(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), this.from, this.to);
/* 6581 */         return new Object[] { res };
/*      */       }
/*      */       
/* 6584 */       double[] res = Indicators.this.sarExt(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), ((Double)this.optParams[2]).doubleValue(), ((Double)this.optParams[3]).doubleValue(), ((Double)this.optParams[4]).doubleValue(), ((Double)this.optParams[5]).doubleValue(), ((Double)this.optParams[6]).doubleValue(), ((Double)this.optParams[7]).doubleValue(), this.from, this.to);
/*      */       
/*      */ 
/*      */ 
/* 6588 */       return new Object[] { res };
/*      */     }
/*      */     
/*      */     protected void validateParameters() throws JFException
/*      */     {
/* 6593 */       Indicators.this.checkSide(this.period, this.offerSides);
/* 6594 */       Indicators.this.checkIntervalValid(this.period, this.from, this.to);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object setupInputData(Instrument inputInstrument, Period inputPeriod, OfferSide inputOfferSide, IIndicators.AppliedPrice appliedPrice, InputParameterInfo.Type inputType, Filter inputFilter, int lookback, int lookforward)
/*      */       throws JFException, DataCacheException
/*      */     {
/* 6609 */       checkPeriodCompatibility(inputPeriod);
/*      */       
/* 6611 */       int flats = 0;
/* 6612 */       long currentTo = this.to;
/* 6613 */       boolean addCurrentCandle = false;
/* 6614 */       if (this.instrument != inputInstrument) {
/* 6615 */         long lastCandleTime = DataCacheUtils.getPreviousCandleStartFast(this.period, Indicators.this.history.getStartTimeOfCurrentBar(this.instrument, this.period));
/* 6616 */         if (currentTo > lastCandleTime) {
/* 6617 */           currentTo = lastCandleTime;
/*      */         }
/* 6619 */         currentTo = DataCacheUtils.getCandleStartFast(inputPeriod, currentTo);
/*      */         
/* 6621 */         long lastFormedCandleTime = DataCacheUtils.getPreviousCandleStartFast(inputPeriod, Indicators.this.history.getStartTimeOfCurrentBar(inputInstrument, inputPeriod));
/* 6622 */         if (currentTo > lastFormedCandleTime) {
/* 6623 */           addCurrentCandle = true;
/*      */         }
/*      */         
/* 6626 */         lastCandleTime = Indicators.this.history.getStartTimeOfCurrentBar(inputInstrument, inputPeriod);
/* 6627 */         if (currentTo > lastCandleTime) {
/* 6628 */           flats = DataCacheUtils.getCandlesCountBetweenFast(inputPeriod, lastCandleTime, currentTo) - 1;
/*      */         }
/* 6630 */         if (currentTo > lastFormedCandleTime)
/* 6631 */           currentTo = lastFormedCandleTime;
/*      */       }
/*      */       Object inputData;
/*      */       Object inputData;
/* 6635 */       if (inputFilter != null) {
/* 6636 */         inputData = Indicators.this.getInputData(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, inputFilter, this.from, currentTo, lookback, lookforward, flats);
/*      */       }
/*      */       else
/*      */       {
/* 6640 */         inputData = Indicators.this.getInputData(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, this.from, currentTo, lookback, lookforward, addCurrentCandle, flats);
/*      */       }
/*      */       
/*      */ 
/* 6644 */       return inputData;
/*      */     }
/*      */     
/*      */     protected Object setupInputData(int lookback, int lookforward) throws JFException, DataCacheException {
/* 6648 */       return Indicators.this.getInputData(this.instrument, this.period, OfferSide.BID, InputParameterInfo.Type.BAR, null, this.from, this.to, lookback, lookforward, false, 0);
/*      */     }
/*      */     
/*      */     protected boolean inputDataExists(Object inputData) {
/* 6652 */       return true;
/*      */     }
/*      */     
/*      */     protected boolean inputLengthValid(int inputLength, int indicatorLookback, int lookforward) {
/* 6656 */       boolean res = inputLength > indicatorLookback + lookforward;
/* 6657 */       return res;
/*      */     }
/*      */     
/*      */ 
/* 6661 */     protected Object[] createEmptyResult() { return Indicators.this.getEmptyIndicatorCalcResultArray(this.indicator); }
/*      */     
/*      */     protected int identifyNumOfElements(IndicatorResult result, Object[] outputs, int inputLength, int actualLookback, int lookforward) {
/*      */       int outCount;
/*      */       int outCount;
/* 6666 */       if (this.period != null) {
/* 6667 */         outCount = DataCacheUtils.getCandlesCountBetweenFast(this.period.isTickBasedPeriod() ? Period.ONE_SEC : this.period, this.from, this.to) > result.getNumberOfElements() ? result.getNumberOfElements() : DataCacheUtils.getCandlesCountBetweenFast(this.period.isTickBasedPeriod() ? Period.ONE_SEC : this.period, this.from, this.to);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 6672 */         outCount = inputLength - actualLookback - lookforward;
/*      */       }
/*      */       
/* 6675 */       return outCount;
/*      */     }
/*      */     
/*      */     protected Object[] setupResult(IndicatorResult result, Object[] outputs, int inputLength, int actualLookback, int lookforward) throws JFException {
/* 6679 */       Object[] ret = new Object[this.indicator.getIndicatorInfo().getNumberOfOutputs()];
/* 6680 */       int i = 0; for (int j = this.indicator.getIndicatorInfo().getNumberOfOutputs(); i < j; i++) {
/* 6681 */         OutputParameterInfo info = this.indicator.getOutputParameterInfo(i);
/*      */         
/* 6683 */         int outCount = identifyNumOfElements(result, outputs, inputLength, actualLookback, lookforward);
/*      */         
/* 6685 */         switch (Indicators.20.$SwitchMap$com$dukascopy$api$indicators$OutputParameterInfo$Type[info.getType().ordinal()]) {
/*      */         case 1: 
/* 6687 */           double[] doubles = (double[])outputs[i];
/* 6688 */           double[] retDoubles = new double[outCount];
/* 6689 */           System.arraycopy(doubles, result.getNumberOfElements() - outCount, retDoubles, 0, outCount);
/* 6690 */           ret[i] = retDoubles;
/* 6691 */           break;
/*      */         case 2: 
/* 6693 */           int[] ints = (int[])outputs[i];
/* 6694 */           int[] retInts = new int[outCount];
/* 6695 */           System.arraycopy(ints, result.getNumberOfElements() - outCount, retInts, 0, outCount);
/* 6696 */           ret[i] = retInts;
/* 6697 */           break;
/*      */         case 3: 
/* 6699 */           Object[] objects = (Object[])outputs[i];
/* 6700 */           Object[] retObjs = new Object[outCount];
/* 6701 */           System.arraycopy(objects, result.getNumberOfElements() - outCount, retObjs, 0, outCount);
/* 6702 */           ret[i] = retObjs;
/* 6703 */           break;
/*      */         case 4: 
/* 6705 */           IBar[] candles = (IBar[])outputs[i];
/* 6706 */           IBar[] retCandles = new IBar[outCount];
/* 6707 */           System.arraycopy(candles, result.getNumberOfElements() - outCount, retCandles, 0, outCount);
/* 6708 */           ret[i] = retCandles;
/*      */         }
/*      */         
/*      */       }
/* 6712 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   class IndicatorCalcFromToFiltered
/*      */     extends Indicators.IndicatorCalcFromTo
/*      */   {
/*      */     private OfferSide offerSide;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public IndicatorCalcFromToFiltered(String indicatorName, Instrument instrument, Period period, OfferSide[] offerSides, IIndicators.AppliedPrice[] appliedPrices, Object[] optParams, long from, long to, Filter filter)
/*      */     {
/* 6729 */       super(indicatorName, instrument, period, offerSides, appliedPrices, optParams, from, to);
/* 6730 */       this.filter = filter;
/*      */     }
/*      */     
/*      */     protected Object[] calculateSAR() throws JFException
/*      */     {
/* 6735 */       if (this.indicatorName.equals("SAR")) {
/* 6736 */         double[] res = Indicators.this.sar(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), this.filter, this.from, this.to);
/*      */         
/* 6738 */         return new Object[] { res };
/*      */       }
/*      */       
/* 6741 */       double[] res = Indicators.this.sarExt(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), ((Double)this.optParams[2]).doubleValue(), ((Double)this.optParams[3]).doubleValue(), ((Double)this.optParams[4]).doubleValue(), ((Double)this.optParams[5]).doubleValue(), ((Double)this.optParams[6]).doubleValue(), ((Double)this.optParams[7]).doubleValue(), this.filter, this.from, this.to);
/*      */       
/*      */ 
/*      */ 
/* 6745 */       return new Object[] { res };
/*      */     }
/*      */     
/*      */     protected Object setupInputData(int lookback, int lookforward)
/*      */       throws JFException, DataCacheException
/*      */     {
/* 6751 */       return Indicators.this.getInputData(this.instrument, this.period, OfferSide.BID, InputParameterInfo.Type.BAR, null, this.filter, this.from, this.to, lookback, lookforward, 0);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object setupInputData(Instrument inputInstrument, Period inputPeriod, OfferSide inputOfferSide, IIndicators.AppliedPrice appliedPrice, InputParameterInfo.Type inputType, Filter inputFilter, int lookback, int lookforward)
/*      */       throws JFException, DataCacheException
/*      */     {
/* 6768 */       checkPeriodCompatibility(inputPeriod);
/*      */       
/* 6770 */       if (this.offerSide == null) {
/* 6771 */         this.offerSide = inputOfferSide;
/*      */       }
/*      */       
/* 6774 */       long currentTo = this.to;
/* 6775 */       int flats = 0;
/*      */       
/* 6777 */       if (this.instrument != inputInstrument) {
/* 6778 */         long lastCandleTime = DataCacheUtils.getPreviousCandleStartFast(this.period, Indicators.this.history.getStartTimeOfCurrentBar(this.instrument, this.period));
/* 6779 */         if (currentTo > lastCandleTime) {
/* 6780 */           currentTo = lastCandleTime;
/*      */         }
/* 6782 */         currentTo = DataCacheUtils.getCandleStartFast(inputPeriod, currentTo);
/* 6783 */         long lastFormedCandleTime = DataCacheUtils.getPreviousCandleStartFast(inputPeriod, Indicators.this.history.getStartTimeOfCurrentBar(inputInstrument, inputPeriod));
/*      */         
/* 6785 */         lastCandleTime = Indicators.this.history.getStartTimeOfCurrentBar(inputInstrument, inputPeriod);
/*      */         
/* 6787 */         if (currentTo > lastCandleTime) {
/* 6788 */           flats = DataCacheUtils.getCandlesCountBetweenFast(inputPeriod, lastCandleTime, currentTo) - 1;
/*      */         }
/* 6790 */         if (currentTo > lastFormedCandleTime) {
/* 6791 */           currentTo = lastFormedCandleTime;
/*      */         }
/*      */       }
/*      */       
/* 6795 */       Object inputData = Indicators.this.getInputData(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, inputFilter, this.from, currentTo, lookback, lookforward, flats);
/*      */       
/*      */ 
/* 6798 */       return inputData;
/*      */     }
/*      */     
/*      */     protected int identifyNumOfElements(IndicatorResult result, Object[] outputs, int inputLength, int actualLookback, int lookforward)
/*      */     {
/* 6803 */       int numElements = result.getNumberOfElements();
/* 6804 */       int res = numElements;
/*      */       try
/*      */       {
/* 6807 */         List<IBar> bars = Indicators.this.history.getBars(this.instrument, this.period.isTickBasedPeriod() ? Period.ONE_SEC : this.period, this.offerSide, this.filter, this.from, this.to);
/* 6808 */         if ((bars != null) && 
/* 6809 */           (bars.size() < numElements)) {
/* 6810 */           res = bars.size();
/*      */         }
/*      */       }
/*      */       catch (JFException e) {
/* 6814 */         Indicators.LOGGER.error(e.getMessage());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6836 */       return res;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   class IndicatorCalcBeforeAfter
/*      */     extends Indicators.IndicatorCalc
/*      */   {
/*      */     private int numberOfCandlesBefore;
/*      */     
/*      */ 
/*      */     private long time;
/*      */     
/*      */ 
/*      */     private int numberOfCandlesAfter;
/*      */     
/*      */ 
/*      */ 
/*      */     public IndicatorCalcBeforeAfter(String indicatorName, Instrument instrument, Period period, OfferSide[] offerSides, IIndicators.AppliedPrice[] appliedPrices, Object[] optParams, int numberOfCandlesBefore, long time, int numberOfCandlesAfter, Filter filter)
/*      */     {
/* 6857 */       super(indicatorName, instrument, period, offerSides, appliedPrices, optParams);
/* 6858 */       this.numberOfCandlesBefore = numberOfCandlesBefore;
/* 6859 */       this.time = time;
/* 6860 */       this.numberOfCandlesAfter = numberOfCandlesAfter;
/* 6861 */       this.filter = filter;
/*      */     }
/*      */     
/*      */     protected Object[] calculateSAR() throws JFException {
/* 6865 */       if (this.indicatorName.equals("SAR")) {
/* 6866 */         double[] res = Indicators.this.sar(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), this.filter, this.numberOfCandlesBefore, this.time, this.numberOfCandlesAfter);
/*      */         
/*      */ 
/* 6869 */         return new Object[] { res };
/*      */       }
/*      */       
/* 6872 */       double[] res = Indicators.this.sarExt(this.instrument, this.period, this.offerSides[0], ((Double)this.optParams[0]).doubleValue(), ((Double)this.optParams[1]).doubleValue(), ((Double)this.optParams[2]).doubleValue(), ((Double)this.optParams[3]).doubleValue(), ((Double)this.optParams[4]).doubleValue(), ((Double)this.optParams[5]).doubleValue(), ((Double)this.optParams[6]).doubleValue(), ((Double)this.optParams[7]).doubleValue(), this.filter, this.numberOfCandlesBefore, this.time, this.numberOfCandlesAfter);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 6877 */       return new Object[] { res };
/*      */     }
/*      */     
/*      */     protected void validateParameters() throws JFException
/*      */     {
/* 6882 */       Indicators.this.checkNotTick(this.period);
/* 6883 */       Indicators.this.checkSide(this.period, this.offerSides);
/* 6884 */       Indicators.this.checkIntervalValid(this.numberOfCandlesBefore, this.numberOfCandlesAfter);
/*      */     }
/*      */     
/*      */     protected boolean inputLengthValid(int inputLength, int indicatorLookback, int lookforward) {
/* 6888 */       boolean res = inputLength >= this.numberOfCandlesBefore + this.numberOfCandlesAfter + indicatorLookback + lookforward;
/* 6889 */       return res;
/*      */     }
/*      */     
/*      */     protected Object setupInputData(int lookback, int lookforward) throws JFException, DataCacheException {
/* 6893 */       return Indicators.this.getInputData(this.instrument, this.period, OfferSide.BID, InputParameterInfo.Type.BAR, null, this.filter, this.numberOfCandlesBefore, this.time, this.numberOfCandlesAfter, lookback, lookforward, 0);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object setupInputData(Instrument inputInstrument, Period inputPeriod, OfferSide inputOfferSide, IIndicators.AppliedPrice appliedPrice, InputParameterInfo.Type inputType, Filter inputFilter, int lookback, int lookforward)
/*      */       throws JFException, DataCacheException
/*      */     {
/*      */       Object inputData;
/*      */       
/*      */ 
/*      */ 
/*      */       Object inputData;
/*      */       
/*      */ 
/*      */ 
/* 6910 */       if ((inputInstrument == this.instrument) && (inputPeriod == this.period)) {
/* 6911 */         List<IBar> sourceBars = Indicators.this.getInputBars(this.instrument, this.period, inputOfferSide, inputType, appliedPrice, inputFilter, this.numberOfCandlesBefore, this.time, this.numberOfCandlesAfter, lookback, lookforward, 0);
/*      */         
/* 6913 */         inputData = Indicators.this.barsToReal(sourceBars, inputType, appliedPrice);
/*      */       }
/*      */       else {
/* 6916 */         checkPeriodCompatibility(inputPeriod);
/*      */         List<IBar> sourceBars;
/* 6918 */         if (inputPeriod != this.period)
/*      */         {
/* 6920 */           IBar[] bars = (IBar[])Indicators.this.getInputData(this.instrument, this.period, inputOfferSide, InputParameterInfo.Type.BAR, null, this.filter, this.numberOfCandlesBefore, this.time, this.numberOfCandlesAfter, 0, 0, 0);
/*      */           
/*      */           Object inputData;
/* 6923 */           if ((bars != null) && (bars.length > 0)) {
/* 6924 */             long currentFrom = DataCacheUtils.getCandleStartFast(inputPeriod, bars[0].getTime());
/* 6925 */             long currentTo = DataCacheUtils.getCandleStartFast(inputPeriod, bars[(bars.length - 1)].getTime());
/*      */             
/* 6927 */             int before = DataCacheUtils.getCandlesCountBetweenFast(inputPeriod, currentFrom, currentTo);
/* 6928 */             long currentBarTime = Indicators.this.history.getStartTimeOfCurrentBar(inputInstrument, inputPeriod);
/*      */             
/* 6930 */             int flats = 0;
/* 6931 */             if (currentTo > currentBarTime) {
/* 6932 */               flats = DataCacheUtils.getCandlesCountBetweenFast(inputPeriod, currentBarTime, currentTo) - 1;
/* 6933 */               currentTo = currentBarTime;
/*      */             }
/*      */             
/* 6936 */             List<IBar> sourceBars = Indicators.this.getInputBars(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, inputFilter, before, currentTo, 0, lookback - flats < 0 ? 0 : lookback - flats, lookforward, flats);
/*      */             
/* 6938 */             inputData = Indicators.this.barsToReal(sourceBars, inputType, appliedPrice);
/*      */           }
/*      */           else {
/* 6941 */             Object inputData = bars;
/* 6942 */             sourceBars = Arrays.asList(bars);
/*      */           }
/*      */         } else {
/* 6945 */           long currentBarTime = Indicators.this.history.getStartTimeOfCurrentBar(inputInstrument, this.period);
/* 6946 */           int flats = 0;
/* 6947 */           long currentTo = this.time;
/*      */           
/* 6949 */           if (currentTo > currentBarTime) {
/* 6950 */             flats = DataCacheUtils.getCandlesCountBetweenFast(inputPeriod, currentBarTime, currentTo) - 1;
/* 6951 */             currentTo = currentBarTime;
/*      */           }
/*      */           
/* 6954 */           List<IBar> sourceBars = Indicators.this.getInputBars(inputInstrument, inputPeriod, inputOfferSide, inputType, appliedPrice, inputFilter, this.numberOfCandlesBefore, currentTo, this.numberOfCandlesAfter, lookback - flats < 0 ? 0 : lookback - flats, flats > 0 ? 0 : lookforward, flats);
/*      */           
/*      */ 
/* 6957 */           inputData = Indicators.this.barsToReal(sourceBars, inputType, appliedPrice);
/*      */         }
/*      */       }
/*      */       
/* 6961 */       return inputData;
/*      */     }
/*      */     
/*      */     protected boolean inputDataExists(Object inputData) {
/* 6965 */       boolean res = inputData != null;
/* 6966 */       return res;
/*      */     }
/*      */     
/*      */     protected Object[] createEmptyResult() {
/* 6970 */       return Indicators.this.getEmptyIndicatorCalcResultArray(this.indicator);
/*      */     }
/*      */     
/*      */     protected Object[] setupResult(IndicatorResult result, Object[] outputs, int inputLength, int actualLookback, int lookforward) throws JFException {
/* 6974 */       Object[] ret = new Object[this.indicator.getIndicatorInfo().getNumberOfOutputs()];
/* 6975 */       int i = 0; for (int j = this.indicator.getIndicatorInfo().getNumberOfOutputs(); i < j; i++) {
/* 6976 */         OutputParameterInfo info = this.indicator.getOutputParameterInfo(i);
/* 6977 */         int outCount; switch (Indicators.20.$SwitchMap$com$dukascopy$api$indicators$OutputParameterInfo$Type[info.getType().ordinal()]) {
/*      */         case 1: 
/* 6979 */           double[] doubles = (double[])outputs[i];
/* 6980 */           outCount = this.numberOfCandlesBefore + this.numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : this.numberOfCandlesBefore + this.numberOfCandlesAfter;
/*      */           
/* 6982 */           double[] retDoubles = new double[outCount];
/* 6983 */           System.arraycopy(doubles, result.getNumberOfElements() - outCount, retDoubles, 0, outCount);
/* 6984 */           ret[i] = retDoubles;
/* 6985 */           break;
/*      */         case 2: 
/* 6987 */           int[] ints = (int[])outputs[i];
/* 6988 */           outCount = this.numberOfCandlesBefore + this.numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : this.numberOfCandlesBefore + this.numberOfCandlesAfter;
/*      */           
/* 6990 */           int[] retInts = new int[outCount];
/* 6991 */           System.arraycopy(ints, result.getNumberOfElements() - outCount, retInts, 0, outCount);
/* 6992 */           ret[i] = retInts;
/* 6993 */           break;
/*      */         case 3: 
/* 6995 */           Object[] objects = (Object[])outputs[i];
/* 6996 */           outCount = this.numberOfCandlesBefore + this.numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : this.numberOfCandlesBefore + this.numberOfCandlesAfter;
/*      */           
/* 6998 */           Object[] retObjs = new Object[outCount];
/* 6999 */           System.arraycopy(objects, result.getNumberOfElements() - outCount, retObjs, 0, outCount);
/* 7000 */           ret[i] = retObjs;
/* 7001 */           break;
/*      */         case 4: 
/* 7003 */           IBar[] candles = (IBar[])outputs[i];
/* 7004 */           outCount = this.numberOfCandlesBefore + this.numberOfCandlesAfter > result.getNumberOfElements() ? result.getNumberOfElements() : this.numberOfCandlesBefore + this.numberOfCandlesAfter;
/*      */           
/* 7006 */           IBar[] retCandles = new IBar[outCount];
/* 7007 */           System.arraycopy(candles, result.getNumberOfElements() - outCount, retCandles, 0, outCount);
/* 7008 */           ret[i] = retCandles;
/*      */         }
/*      */         
/*      */       }
/* 7012 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IIndicatorCalculator<Double, double[]> trange(IFeedDescriptor feedDescriptor, OfferSide side)
/*      */   {
/* 7023 */     return this.calculator.newInstance("TRANGE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlShootingStar(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7027 */     return this.calculator.newInstance("CDLSHOOTINGSTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> rocr100(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7031 */     return this.calculator.newInstance("ROCR100", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlUnique3River(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7035 */     return this.calculator.newInstance("CDLUNIQUE3RIVER", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlAdvanceBlock(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7039 */     return this.calculator.newInstance("CDLADVANCEBLOCK", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> heikenAshi(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7043 */     return this.calculator.newInstance("HeikinAshi", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHarami(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7047 */     return this.calculator.newInstance("CDLHARAMI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> medPrice(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7051 */     return this.calculator.newInstance("MEDPRICE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> linearRegAngle(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7055 */     return this.calculator.newInstance("LINEARREG_ANGLE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> tema(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7059 */     return this.calculator.newInstance("TEMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> lagACS1(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int ma, double gamma, int lookback) {
/* 7063 */     return this.calculator.newInstance("LAGACS1", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> mom(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7067 */     return this.calculator.newInstance("MOM", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> supportResistance(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7071 */     return this.calculator.newInstance("S&R", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> mavp(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice1, OfferSide side1, IIndicators.AppliedPrice appliedPrice2, OfferSide side2, int minPeriod, int maxPeriod, IIndicators.MaType maType) {
/* 7075 */     return this.calculator.newInstance("MAVP", feedDescriptor, new OfferSide[] { side1, side2 }, new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(minPeriod), Integer.valueOf(maxPeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> stochF(IFeedDescriptor feedDescriptor, OfferSide side, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType) {
/* 7079 */     return this.calculator.newInstance("STOCHF", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> floor(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7083 */     return this.calculator.newInstance("FLOOR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ppo(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fastPeriod, int slowPeriod, IIndicators.MaType maType) {
/* 7087 */     return this.calculator.newInstance("PPO", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlKickingByLength(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7091 */     return this.calculator.newInstance("CDLKICKINGBYLENGTH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlDarkCloudCover(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7095 */     return this.calculator.newInstance("CDLDARKCLOUDCOVER", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl2Crows(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7099 */     return this.calculator.newInstance("CDL2CROWS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl3Inside(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7103 */     return this.calculator.newInstance("CDL3INSIDE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> dmi(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7107 */     return this.calculator.newInstance("DMI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> dx(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7111 */     return this.calculator.newInstance("DX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> tsf(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7115 */     return this.calculator.newInstance("TSF", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ceil(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7119 */     return this.calculator.newInstance("CEIL", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlKicking(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7123 */     return this.calculator.newInstance("CDLKICKING", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> osma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fast_ema_period, int slow_ema_period, int signal_period) {
/* 7127 */     return this.calculator.newInstance("OsMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fast_ema_period), Integer.valueOf(slow_ema_period), Integer.valueOf(signal_period) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlUpsideGap2Crows(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7131 */     return this.calculator.newInstance("CDLUPSIDEGAP2CROWS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> cmo(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7135 */     return this.calculator.newInstance("CMO", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlTakuri(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7139 */     return this.calculator.newInstance("CDLTAKURI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> beta(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice1, OfferSide side1, IIndicators.AppliedPrice appliedPrice2, OfferSide side2, int timePeriod) {
/* 7143 */     return this.calculator.newInstance("BETA", feedDescriptor, new OfferSide[] { side1, side2 }, new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> maEnvelope(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, double deviation) {
/* 7147 */     return this.calculator.newInstance("MAEnvelope", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> pivot(IFeedDescriptor feedDescriptor, OfferSide side, Period timePeriod) {
/* 7151 */     return this.calculator.newInstance("PIVOT", feedDescriptor, new OfferSide[] { side, side }, new IIndicators.AppliedPrice[0], new Object[] { timePeriod, Boolean.valueOf(true) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlConcealBabySwall(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7155 */     return this.calculator.newInstance("CDLCONCEALBABYSWALL", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlMatchingLow(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7159 */     return this.calculator.newInstance("CDLMATCHINGLOW", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlGravestoneDoji(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7163 */     return this.calculator.newInstance("CDLGRAVESTONEDOJI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> camPivot(IFeedDescriptor feedDescriptor, OfferSide side, Period timePeriod) {
/* 7167 */     return this.calculator.newInstance("CAMPIVOT", feedDescriptor, new OfferSide[] { side, side }, new IIndicators.AppliedPrice[0], new Object[] { timePeriod });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlDoji(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7171 */     return this.calculator.newInstance("CDLDOJI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> bear(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7175 */     return this.calculator.newInstance("BEARP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> rvi(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7179 */     return this.calculator.newInstance("RVI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> tbop(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7183 */     return this.calculator.newInstance("THRUSTOUTSIDEBAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> max(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7187 */     return this.calculator.newInstance("MAX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> sqrt(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7191 */     return this.calculator.newInstance("SQRT", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> bull(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7195 */     return this.calculator.newInstance("BULLP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlEngulfing(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7199 */     return this.calculator.newInstance("CDLENGULFING", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> sin(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7203 */     return this.calculator.newInstance("SIN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> adxr(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7207 */     return this.calculator.newInstance("ADXR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> cog(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, int smoothPeriod, IIndicators.MaType maType) {
/* 7211 */     return this.calculator.newInstance("COG", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(smoothPeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> volume(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7215 */     return this.calculator.newInstance("Volume", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlBreakAway(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7219 */     return this.calculator.newInstance("CDLBREAKAWAY", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> stdDev(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, double nbDev) {
/* 7223 */     return this.calculator.newInstance("STDDEV", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHangingMan(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7227 */     return this.calculator.newInstance("CDLHANGINGMAN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> rsi(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7231 */     return this.calculator.newInstance("RSI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> cos(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7235 */     return this.calculator.newInstance("COS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> volumeWAP(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7239 */     return this.calculator.newInstance("VolumeWAP", feedDescriptor, new OfferSide[] { side, side }, new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> midPoint(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7243 */     return this.calculator.newInstance("MIDPOINT", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ht_dcperiod(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7247 */     return this.calculator.newInstance("HT_DCPERIOD", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> plusDm(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7251 */     return this.calculator.newInstance("PLUS_DM", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> tanh(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7255 */     return this.calculator.newInstance("TANH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> obv(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice1, OfferSide side1, IIndicators.AppliedPrice appliedPrice2, OfferSide side2) {
/* 7259 */     return this.calculator.newInstance("OBV", feedDescriptor, new OfferSide[] { side1, side2 }, new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> td_i(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7263 */     return this.calculator.newInstance("TD_I", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlSpinningTop(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7267 */     return this.calculator.newInstance("CDLSPINNINGTOP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl3BlackCrows(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7271 */     return this.calculator.newInstance("CDL3BLACKCROWS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> woodPivot(IFeedDescriptor feedDescriptor, OfferSide side, Period timePeriod) {
/* 7275 */     return this.calculator.newInstance("WOODPIVOT", feedDescriptor, new OfferSide[] { side, side }, new IIndicators.AppliedPrice[0], new Object[] { timePeriod });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlPiercing(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7279 */     return this.calculator.newInstance("CDLPIERCING", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> cosh(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7283 */     return this.calculator.newInstance("COSH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> minusDi(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7287 */     return this.calculator.newInstance("MINUS_DI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlMorningStar(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7291 */     return this.calculator.newInstance("CDLMORNINGSTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHikkakeMod(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7295 */     return this.calculator.newInstance("CDLHIKKAKEMOD", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> minusDm(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7299 */     return this.calculator.newInstance("MINUS_DM", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> zigzag(IFeedDescriptor feedDescriptor, OfferSide side, int extDepth, int extDeviation, int extBackstep) {
/* 7303 */     return this.calculator.newInstance("ZIGZAG", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(extDepth), Integer.valueOf(extDeviation), Integer.valueOf(extBackstep) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<int[], int[][]> td_s(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7307 */     return this.calculator.newInstance("TD_S", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlInNeck(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7311 */     return this.calculator.newInstance("CDLINNECK", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> stochRsi(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, int fastKPeriod, int fastDPeriod, IIndicators.MaType fastDMaType) {
/* 7315 */     return this.calculator.newInstance("STOCHRSI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastKPeriod), Integer.valueOf(fastDPeriod), Integer.valueOf(fastDMaType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> avgPrice(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7319 */     return this.calculator.newInstance("AVGPRICE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> waddahAttar(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7323 */     return this.calculator.newInstance("WADDAHAT", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> midPrice(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7327 */     return this.calculator.newInstance("MIDPRICE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> rci(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7331 */     return this.calculator.newInstance("RCI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlSeparatingLines(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7335 */     return this.calculator.newInstance("CDLSEPARATINGLINES", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> correl(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice1, OfferSide side1, IIndicators.AppliedPrice appliedPrice2, OfferSide side2, int timePeriod) {
/* 7339 */     return this.calculator.newInstance("CORREL", feedDescriptor, new OfferSide[] { side1, side2 }, new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> t3(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, double factor) {
/* 7343 */     return this.calculator.newInstance("T3", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(factor) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlGapSideSideWhite(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7347 */     return this.calculator.newInstance("CDLGAPSIDESIDEWHITE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> sub(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice1, OfferSide side1, IIndicators.AppliedPrice appliedPrice2, OfferSide side2) {
/* 7351 */     return this.calculator.newInstance("SUB", feedDescriptor, new OfferSide[] { side1, side2 }, new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> asin(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7355 */     return this.calculator.newInstance("ASIN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> var(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, double nbDev) {
/* 7359 */     return this.calculator.newInstance("VAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDev) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> ht_sine(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7363 */     return this.calculator.newInstance("HT_SINE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> sum(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7367 */     return this.calculator.newInstance("SUM", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> lwma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7371 */     return this.calculator.newInstance("LWMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> lasacs1(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int ma, double gamma, int lookback) {
/* 7375 */     return this.calculator.newInstance("LAGACS1", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(ma), Double.valueOf(gamma), Integer.valueOf(lookback) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl3LineStrike(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7379 */     return this.calculator.newInstance("CDL3LINESTRIKE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ht_trendline(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7383 */     return this.calculator.newInstance("HT_TRENDLINE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlCounterattack(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7387 */     return this.calculator.newInstance("CDLCOUNTERATTACK", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> trix(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7391 */     return this.calculator.newInstance("TRIX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHaramiCross(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7395 */     return this.calculator.newInstance("CDLHARAMICROSS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> linearRegIntercept(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7399 */     return this.calculator.newInstance("LINEARREG_INTERCEPT", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> keltner(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7403 */     return this.calculator.newInstance("KELTNER", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> gator(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod) {
/* 7407 */     return this.calculator.newInstance("GATOR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlStickSandwich(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7411 */     return this.calculator.newInstance("CDLSTICKSANDWICH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> vortex(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7415 */     return this.calculator.newInstance("VORTEX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> bop(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7419 */     return this.calculator.newInstance("BOP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> plusDi(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7423 */     return this.calculator.newInstance("PLUS_DI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> kdj(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriodK, int timePeriodD, IIndicators.MaType slowKMaType, int slowKPeriod, IIndicators.MaType slowDMaType, int slowDPeriod, IIndicators.MaType slowJMaType, int slowJPeriod) {
/* 7427 */     return this.calculator.newInstance("KDJ", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriodK), Integer.valueOf(timePeriodD), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowKPeriod), Integer.valueOf(slowDMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowJMaType.ordinal()), Integer.valueOf(slowJPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlTristar(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7431 */     return this.calculator.newInstance("CDLTRISTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> adOsc(IFeedDescriptor feedDescriptor, OfferSide side, int fastPeriod, int slowPeriod) {
/* 7435 */     return this.calculator.newInstance("ADOSC", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> ac(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fastPeriod, int slowPeriod) {
/* 7439 */     return this.calculator.newInstance("AC", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ad(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7443 */     return this.calculator.newInstance("AD", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlIdentical3Crows(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7447 */     return this.calculator.newInstance("CDLIDENTICAL3CROWS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlClosingMarubozu(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7451 */     return this.calculator.newInstance("CDLCLOSINGMARUBOZU", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHighWave(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7455 */     return this.calculator.newInstance("CDLHIGHWAVE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlMorningDojiStar(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7459 */     return this.calculator.newInstance("CDLMORNINGDOJISTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> trima(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7463 */     return this.calculator.newInstance("TRIMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> mfi(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7467 */     return this.calculator.newInstance("MFI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> rocr(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7471 */     return this.calculator.newInstance("ROCR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlMarubozu(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7475 */     return this.calculator.newInstance("CDLMARUBOZU", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> rocp(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7479 */     return this.calculator.newInstance("ROCP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlDojiStar(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7483 */     return this.calculator.newInstance("CDLDOJISTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> wma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7487 */     return this.calculator.newInstance("WMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> trendEnv(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod, double deviation) {
/* 7491 */     return this.calculator.newInstance("TrendEnvelopes", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> linearRegSlope(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7495 */     return this.calculator.newInstance("LINEARREG_SLOPE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> smma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7499 */     return this.calculator.newInstance("SMMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlMathold(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7503 */     return this.calculator.newInstance("CDLMATHOLD", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> cci(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7507 */     return this.calculator.newInstance("CCI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlStalledPattern(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7511 */     return this.calculator.newInstance("CDLSTALLEDPATTERN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> macdFix(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int signalPeriod) {
/* 7515 */     return this.calculator.newInstance("MACDFIX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(signalPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> awesome(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fasterMaTimePeriod, IIndicators.MaType fasterMaType, int slowerMaTimePeriod, IIndicators.MaType slowerMaType) {
/* 7519 */     return this.calculator.newInstance("AWESOME", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fasterMaTimePeriod), Integer.valueOf(fasterMaType.ordinal()), Integer.valueOf(slowerMaTimePeriod), Integer.valueOf(slowerMaType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlBeltHold(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7523 */     return this.calculator.newInstance("CDLBELTHOLD", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> stoch(IFeedDescriptor feedDescriptor, OfferSide side, int fastKPeriod, int slowKPeriod, IIndicators.MaType slowKMaType, int slowDPeriod, IIndicators.MaType slowDMaType) {
/* 7527 */     return this.calculator.newInstance("STOCH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowKMaType.ordinal()), Integer.valueOf(slowDPeriod), Integer.valueOf(slowDMaType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> butterworthFilter(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7531 */     return this.calculator.newInstance("BUTTERWORTH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> ichimoku(IFeedDescriptor feedDescriptor, OfferSide side, int tenkan, int kijun, int senkou) {
/* 7535 */     return this.calculator.newInstance("ICHIMOKU", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(tenkan), Integer.valueOf(kijun), Integer.valueOf(senkou) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> natr(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7539 */     return this.calculator.newInstance("NATR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlOnNeck(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7543 */     return this.calculator.newInstance("CDLONNECK", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> roc(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7547 */     return this.calculator.newInstance("ROC", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> dema(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7551 */     return this.calculator.newInstance("DEMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> prchannel(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7555 */     return this.calculator.newInstance("PCHANNEL", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ema(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7559 */     return this.calculator.newInstance("EMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> macdExt(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fastPeriod, IIndicators.MaType fastMaType, int slowPeriod, IIndicators.MaType slowMaType, int signalPeriod, IIndicators.MaType signalMaType) {
/* 7563 */     return this.calculator.newInstance("MACDEXT", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(fastMaType.ordinal()), Integer.valueOf(slowPeriod), Integer.valueOf(slowMaType.ordinal()), Integer.valueOf(signalPeriod), Integer.valueOf(signalMaType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> willr(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7567 */     return this.calculator.newInstance("WILLR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> tan(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7571 */     return this.calculator.newInstance("TAN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> mama(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, double fastLimit, double slowLimit) {
/* 7575 */     return this.calculator.newInstance("MAMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Double.valueOf(fastLimit), Double.valueOf(slowLimit) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ln(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7579 */     return this.calculator.newInstance("LN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> aroon(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7583 */     return this.calculator.newInstance("AROON", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlRiseFall3Methods(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7587 */     return this.calculator.newInstance("CDLRISEFALL3METHODS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlLadderBotton(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7591 */     return this.calculator.newInstance("CDLLADDERBOTTOM", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlLadderBottom(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7595 */     return this.calculator.newInstance("CDLLADDERBOTTOM", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> donchian(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7599 */     return this.calculator.newInstance("DONCHIANCHANNEL", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, IIndicators.MaType maType) {
/* 7603 */     return this.calculator.newInstance("MA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHammer(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7607 */     return this.calculator.newInstance("CDLHAMMER", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> tbp(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7611 */     return this.calculator.newInstance("THRUSTBAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> fractalLines(IFeedDescriptor feedDescriptor, OfferSide side, int barsOnSides) {
/* 7615 */     return this.calculator.newInstance("FRACTALLINES", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(barsOnSides) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> apo(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fastPeriod, int slowPeriod, IIndicators.MaType maType) {
/* 7619 */     return this.calculator.newInstance("APO", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> min(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7623 */     return this.calculator.newInstance("MIN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlInvertedHammer(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7627 */     return this.calculator.newInstance("CDLINVERTEDHAMMER", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlThrusting(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7631 */     return this.calculator.newInstance("CDLTHRUSTING", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlRickshawMan(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7635 */     return this.calculator.newInstance("CDLRICKSHAWMAN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl3StarsInSouth(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7639 */     return this.calculator.newInstance("CDL3STARSINSOUTH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> bwmfi(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7643 */     return this.calculator.newInstance("BWMFI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> force(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, IIndicators.MaType maType) {
/* 7647 */     return this.calculator.newInstance("FORCEI", feedDescriptor, new OfferSide[] { side, side }, new IIndicators.AppliedPrice[] { appliedPrice, appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> fractal(IFeedDescriptor feedDescriptor, OfferSide side, int barsOnSides) {
/* 7651 */     return this.calculator.newInstance("FRACTAL", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(barsOnSides) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> rmi(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, int momentumPeriod) {
/* 7655 */     return this.calculator.newInstance("RMI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(momentumPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> atan(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7659 */     return this.calculator.newInstance("ATAN", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlEveningStar(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7663 */     return this.calculator.newInstance("CDLEVENINGSTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHikkake(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7667 */     return this.calculator.newInstance("CDLHIKKAKE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> tvs(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7671 */     return this.calculator.newInstance("TVS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> fibPivot(IFeedDescriptor feedDescriptor, OfferSide side, Period timePeriod) {
/* 7675 */     return this.calculator.newInstance("FIBPIVOT", feedDescriptor, new OfferSide[] { side, side }, new IIndicators.AppliedPrice[0], new Object[] { timePeriod });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> kama(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, int fastMAPeriod, int slowMAPeriod) {
/* 7679 */     return this.calculator.newInstance("KAMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(fastMAPeriod), Integer.valueOf(slowMAPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> minMax(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7683 */     return this.calculator.newInstance("MINMAX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> wclPrice(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7687 */     return this.calculator.newInstance("WCLPRICE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlXsideGap3Methods(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7691 */     return this.calculator.newInstance("CDLXSIDEGAP3METHODS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> ht_trendmode(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7695 */     return this.calculator.newInstance("HT_TRENDMODE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Object[], Object[]> wsmTime(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7699 */     return this.calculator.newInstance("WSMTIME", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> sinh(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7703 */     return this.calculator.newInstance("SINH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> typPrice(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7707 */     return this.calculator.newInstance("TYPPRICE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlHomingPigeon(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7711 */     return this.calculator.newInstance("CDLHOMINGPIGEON", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlLongLine(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7715 */     return this.calculator.newInstance("CDLLONGLINE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> exp(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7719 */     return this.calculator.newInstance("EXP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlEveningDojiStar(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7723 */     return this.calculator.newInstance("CDLEVENINGDOJISTAR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> macd(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int fastPeriod, int slowPeriod, int signalPeriod) {
/* 7727 */     return this.calculator.newInstance("MACD", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(fastPeriod), Integer.valueOf(slowPeriod), Integer.valueOf(signalPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlLongLeggedDoji(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7731 */     return this.calculator.newInstance("CDLLONGLEGGEDDOJI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> ht_phasor(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7735 */     return this.calculator.newInstance("HT_PHASOR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> emaEnvelope(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, double deviation) {
/* 7739 */     return this.calculator.newInstance("EMAEnvelope", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(deviation) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> heikinAshi(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7743 */     return this.calculator.newInstance("HeikinAshi", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> bbands(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, double nbDevUp, double nbDevDn, IIndicators.MaType maType) {
/* 7747 */     return this.calculator.newInstance("BBANDS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Double.valueOf(nbDevUp), Double.valueOf(nbDevDn), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ht_dcphase(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7751 */     return this.calculator.newInstance("HT_DCPHASE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> add(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice1, OfferSide side1, IIndicators.AppliedPrice appliedPrice2, OfferSide side2) {
/* 7755 */     return this.calculator.newInstance("ADD", feedDescriptor, new OfferSide[] { side1, side2 }, new IIndicators.AppliedPrice[] { appliedPrice1, appliedPrice2 }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> kairi(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod, IIndicators.MaType maType) {
/* 7759 */     return this.calculator.newInstance("KAIRI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod), Integer.valueOf(maType.ordinal()) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> murrey(IFeedDescriptor feedDescriptor, OfferSide side, int nPeriod, Period timePeriod, int stepBack) {
/* 7763 */     return this.calculator.newInstance("MURRCH", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(nPeriod), timePeriod, Integer.valueOf(stepBack) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> atr(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7767 */     return this.calculator.newInstance("ATR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> alligator(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int jawTimePeriod, int teethTimePeriod, int lipsTimePeriod) {
/* 7771 */     return this.calculator.newInstance("ALLIGATOR", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(jawTimePeriod), Integer.valueOf(teethTimePeriod), Integer.valueOf(lipsTimePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> adx(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7775 */     return this.calculator.newInstance("ADX", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl3WhiteSoldiers(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7779 */     return this.calculator.newInstance("CDL3WHITESOLDIERS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> acos(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7783 */     return this.calculator.newInstance("ACOS", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlTasukiGap(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7787 */     return this.calculator.newInstance("CDLTASUKIGAP", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdl3Outside(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7791 */     return this.calculator.newInstance("CDL3OUTSIDE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlDragonflyDoji(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7795 */     return this.calculator.newInstance("CDLDRAGONFLYDOJI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> aroonOsc(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod) {
/* 7799 */     return this.calculator.newInstance("AROONOSC", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<IBar, IBar[]> heikinAshiSingle(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7803 */     return this.calculator.newInstance("HeikinAshiSingle", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> log10(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side) {
/* 7807 */     return this.calculator.newInstance("LOG10", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[0]);
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> linearReg(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7811 */     return this.calculator.newInstance("LINEARREG", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> sma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7815 */     return this.calculator.newInstance("SMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlAbandonedBaby(IFeedDescriptor feedDescriptor, OfferSide side, double penetration) {
/* 7819 */     return this.calculator.newInstance("CDLABANDONEDBABY", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Double.valueOf(penetration) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> ultOsc(IFeedDescriptor feedDescriptor, OfferSide side, int timePeriod1, int timePeriod2, int timePeriod3) {
/* 7823 */     return this.calculator.newInstance("ULTOSC", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(timePeriod1), Integer.valueOf(timePeriod2), Integer.valueOf(timePeriod3) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<double[], double[][]> smi(IFeedDescriptor feedDescriptor, OfferSide side, int fastKPeriod, int slowKPeriod, int slowDPeriod, int smoothingPeriod) {
/* 7827 */     return this.calculator.newInstance("SMI", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[] { Integer.valueOf(fastKPeriod), Integer.valueOf(slowKPeriod), Integer.valueOf(slowDPeriod), Integer.valueOf(smoothingPeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Double, double[]> hma(IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice appliedPrice, OfferSide side, int timePeriod) {
/* 7831 */     return this.calculator.newInstance("HMA", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[] { appliedPrice }, new Object[] { Integer.valueOf(timePeriod) });
/*      */   }
/*      */   
/*      */   public IIndicatorCalculator<Integer, int[]> cdlShortLine(IFeedDescriptor feedDescriptor, OfferSide side) {
/* 7835 */     return this.calculator.newInstance("CDLSHORTLINE", feedDescriptor, new OfferSide[] { side }, new IIndicators.AppliedPrice[0], new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T, U> IIndicatorCalculator<T, U> custom(String indName, Class<T> classShift, Class<U> classArr, IFeedDescriptor feedDescriptor, IIndicators.AppliedPrice[] appliedPrices, OfferSide[] offerSides, Object[] optInputs)
/*      */   {
/* 7841 */     return this.calculator.newInstance(indName, feedDescriptor, offerSides, appliedPrices, optInputs);
/*      */   }
/*      */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\Indicators.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */