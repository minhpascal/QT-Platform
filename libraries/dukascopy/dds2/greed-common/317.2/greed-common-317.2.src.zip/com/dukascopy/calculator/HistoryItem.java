/*    */ package com.dukascopy.calculator;
/*    */ 
/*    */ import com.dukascopy.calculator.function.PObject;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HistoryItem
/*    */ {
/*    */   public LinkedList<PObject> list;
/*    */   public AngleType angleType;
/*    */   public Base base;
/*    */   public Notation notation;
/*    */   
/*    */   HistoryItem(LinkedList<PObject> list, AngleType angleType, Base base, Notation notation)
/*    */   {
/* 23 */     this.list = list;
/* 24 */     this.angleType = angleType;
/* 25 */     this.base = base;
/* 26 */     this.notation = notation;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\HistoryItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */