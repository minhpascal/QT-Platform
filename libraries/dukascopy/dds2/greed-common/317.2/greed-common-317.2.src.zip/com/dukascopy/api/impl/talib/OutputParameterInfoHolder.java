package com.dukascopy.api.impl.talib;

import com.tictactec.ta.lib.meta.annotation.OutputParameterType;

public class OutputParameterInfoHolder
  extends Holder
{
  public OutputParameterType type;
  public String paramName;
  public int flags;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\talib\OutputParameterInfoHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */