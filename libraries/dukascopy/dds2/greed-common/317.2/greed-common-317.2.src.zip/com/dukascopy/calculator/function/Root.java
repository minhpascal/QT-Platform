/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Root
/*    */   extends DFunction
/*    */ {
/*    */   public Root()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.y.th.root.of.x";
/* 15 */     this.fshortcut = '^';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x, double y)
/*    */   {
/* 25 */     if (y >= 0.0D) {
/* 26 */       return Math.pow(y, 1.0D / x);
/*    */     }
/* 28 */     return 1.0D / Math.pow(y, 1.0D / -x);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x, OObject y)
/*    */   {
/* 38 */     return y.root(x);
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 42 */     return fname;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 46 */     Root o = new Root();
/* 47 */     StringBuilder s = new StringBuilder("<html>");
/* 48 */     s.append(o.name());
/* 49 */     s.append("</html>");
/* 50 */     JOptionPane.showMessageDialog(null, s.toString());
/*    */   }
/*    */   
/* 53 */   private static final String[] fname = { "<sup><i>x</i></sup>", "&#8730;" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Root.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */