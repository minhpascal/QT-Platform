/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IMessage;
/*    */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.impl.connect.OrdersInternalCollection;
/*    */ import com.dukascopy.api.impl.connect.PlatformOrderImpl;
/*    */ import com.dukascopy.api.plugins.IMessageListener;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*    */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*    */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*    */ import com.dukascopy.dds3.transport.msg.ord.MergePositionsMessage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskOrdersMerged
/*    */   implements Task
/*    */ {
/* 25 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskOrdersMerged.class);
/*    */   private IMessageListener strategy;
/*    */   private MergePositionsMessage mergePositionsMessage;
/*    */   private JForexTaskManager taskManager;
/*    */   private StrategyEventsCallback strategyEventsCallback;
/*    */   
/*    */   public TaskOrdersMerged(JForexTaskManager taskManager, IMessageListener strategy, MergePositionsMessage mergePositionsMessage)
/*    */   {
/* 33 */     this.strategy = strategy;
/* 34 */     this.mergePositionsMessage = mergePositionsMessage;
/* 35 */     this.taskManager = taskManager;
/* 36 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 41 */     return Task.Type.MESSAGE;
/*    */   }
/*    */   
/*    */   public Object call() throws Exception
/*    */   {
/* 46 */     if (this.taskManager.isStrategyStopping()) {
/* 47 */       return null;
/*    */     }
/* 49 */     if (LOGGER.isDebugEnabled()) {
/* 50 */       LOGGER.debug("Starting processing of merge message [" + this.mergePositionsMessage + "]");
/*    */     }
/*    */     try {
/* 53 */       OrdersInternalCollection ordersInternalCollection = this.taskManager.getOrdersInternalCollection();
/* 54 */       PlatformOrderImpl platformOrderImpl = ordersInternalCollection.getOrderById(this.mergePositionsMessage.getNewOrdGrId());
/* 55 */       if (platformOrderImpl == null) {
/* 56 */         String label = this.mergePositionsMessage.getExternalSysId();
/* 57 */         platformOrderImpl = ordersInternalCollection.getOrderByLabel(label);
/*    */       }
/*    */       
/* 60 */       IMessage platformMessageImpl = null;
/* 61 */       if (platformOrderImpl != null) {
/* 62 */         platformMessageImpl = platformOrderImpl.update(this.mergePositionsMessage);
/*    */       }
/*    */       
/* 65 */       if (platformMessageImpl != null) {
/* 66 */         this.strategy.onMessage(platformMessageImpl);
/* 67 */         if (this.strategyEventsCallback != null) {
/* 68 */           this.strategyEventsCallback.onMessage(platformMessageImpl);
/*    */         }
/*    */       }
/*    */     } catch (Throwable t) {
/* 72 */       String msg = ErrorHelper.representError(this.strategy, t);
/* 73 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 74 */       LOGGER.error(t.getMessage(), t);
/* 75 */       this.taskManager.getExceptionHandler().onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_MESSAGE, t);
/*    */     }
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskOrdersMerged.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */