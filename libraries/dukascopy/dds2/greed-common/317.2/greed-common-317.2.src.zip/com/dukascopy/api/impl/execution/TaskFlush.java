/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskFlush
/*    */   implements Task<Object>
/*    */ {
/*    */   private Object notifyObject;
/*    */   
/*    */ 
/*    */ 
/*    */   public TaskFlush(Object notifyObject)
/*    */   {
/* 14 */     this.notifyObject = notifyObject;
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 19 */     return Task.Type.CUSTOM;
/*    */   }
/*    */   
/*    */   public Object call() throws Exception
/*    */   {
/* 24 */     synchronized (this.notifyObject) {
/* 25 */       this.notifyObject.notifyAll();
/*    */     }
/* 27 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskFlush.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */