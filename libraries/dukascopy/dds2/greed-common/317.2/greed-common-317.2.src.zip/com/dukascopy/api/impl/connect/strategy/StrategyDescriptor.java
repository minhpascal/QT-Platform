/*    */ package com.dukascopy.api.impl.connect.strategy;
/*    */ 
/*    */ import com.dukascopy.api.strategy.IStrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.IStrategyParameter;
/*    */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public abstract class StrategyDescriptor implements IStrategyDescriptor
/*    */ {
/*    */   protected final String name;
/*    */   protected final long startTime;
/*    */   protected final List<IStrategyParameter> parameters;
/*    */   protected final UUID id;
/*    */   protected final String comments;
/*    */   
/*    */   public StrategyDescriptor(String name, long startTime, List<IStrategyParameter> parameters, UUID id, String comments)
/*    */   {
/* 19 */     this.name = name;
/* 20 */     this.startTime = startTime;
/* 21 */     this.parameters = parameters;
/* 22 */     this.id = id;
/* 23 */     this.comments = comments;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 29 */     return this.name;
/*    */   }
/*    */   
/*    */   public long getStartTime()
/*    */   {
/* 34 */     return this.startTime;
/*    */   }
/*    */   
/*    */   public List<IStrategyParameter> getParameters()
/*    */   {
/* 39 */     return this.parameters;
/*    */   }
/*    */   
/*    */   public UUID getId()
/*    */   {
/* 44 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getChangeReason()
/*    */   {
/* 49 */     return this.comments;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 54 */     return "Strategy [name=" + this.name + ", startTime=" + this.startTime + ", parameters=" + this.parameters + ", id=" + this.id + (ObjectUtils.isNullOrEmpty(Boolean.valueOf(this.comments == null)) ? "" : new StringBuilder().append(", changeReason=").append(getChangeReason()).toString()) + "]";
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 60 */     int prime = 31;
/* 61 */     int result = 1;
/* 62 */     result = 31 * result + (this.id == null ? 0 : this.id.hashCode());
/* 63 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 68 */     if (this == obj)
/* 69 */       return true;
/* 70 */     if (obj == null)
/* 71 */       return false;
/* 72 */     if (getClass() != obj.getClass())
/* 73 */       return false;
/* 74 */     StrategyDescriptor other = (StrategyDescriptor)obj;
/* 75 */     if (this.id == null) {
/* 76 */       if (other.id != null)
/* 77 */         return false;
/* 78 */     } else if (!this.id.equals(other.id))
/* 79 */       return false;
/* 80 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\StrategyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */