package com.dukascopy.api.impl.connect;

import com.dukascopy.api.JFException;
import com.dukascopy.api.feed.IRangeBar;
import com.dukascopy.api.feed.ITailoredFeedDescriptor;

public abstract interface IFeedRangeBarListener
{
  public abstract void onRangeBar(ITailoredFeedDescriptor<IRangeBar> paramITailoredFeedDescriptor, IRangeBar paramIRangeBar)
    throws JFException;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\IFeedRangeBarListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */