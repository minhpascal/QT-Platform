/*    */ package com.dukascopy.charts.data.datacache.change;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.Period;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DFSCacheChangeItem
/*    */ {
/*    */   private Instrument instrument;
/*    */   private Period period;
/*    */   private long from;
/*    */   private long to;
/*    */   
/*    */   public DFSCacheChangeItem() {}
/*    */   
/*    */   public DFSCacheChangeItem(Instrument instrument, Period period, long from, long to)
/*    */   {
/* 25 */     this.instrument = instrument;
/* 26 */     this.period = period;
/* 27 */     this.from = from;
/* 28 */     this.to = to;
/*    */   }
/*    */   
/* 31 */   public Instrument getInstrument() { return this.instrument; }
/*    */   
/*    */   public void setInstrument(Instrument instrument) {
/* 34 */     this.instrument = instrument;
/*    */   }
/*    */   
/* 37 */   public Period getPeriod() { return this.period; }
/*    */   
/*    */   public void setPeriod(Period period) {
/* 40 */     this.period = period;
/*    */   }
/*    */   
/* 43 */   public long getFrom() { return this.from; }
/*    */   
/*    */   public void setFrom(long from) {
/* 46 */     this.from = from;
/*    */   }
/*    */   
/* 49 */   public long getTo() { return this.to; }
/*    */   
/*    */   public void setTo(long to) {
/* 52 */     this.to = to;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 56 */     int prime = 31;
/* 57 */     int result = 1;
/* 58 */     result = 31 * result + (int)(this.from ^ this.from >>> 32);
/* 59 */     result = 31 * result + (this.instrument == null ? 0 : this.instrument.hashCode());
/* 60 */     result = 31 * result + (this.period == null ? 0 : this.period.hashCode());
/* 61 */     result = 31 * result + (int)(this.to ^ this.to >>> 32);
/* 62 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 66 */     if (this == obj)
/* 67 */       return true;
/* 68 */     if (obj == null)
/* 69 */       return false;
/* 70 */     if (getClass() != obj.getClass())
/* 71 */       return false;
/* 72 */     DFSCacheChangeItem other = (DFSCacheChangeItem)obj;
/* 73 */     if (this.from != other.from)
/* 74 */       return false;
/* 75 */     if (this.instrument == null) {
/* 76 */       if (other.instrument != null)
/* 77 */         return false;
/* 78 */     } else if (!this.instrument.equals(other.instrument))
/* 79 */       return false;
/* 80 */     if (this.period == null) {
/* 81 */       if (other.period != null)
/* 82 */         return false;
/* 83 */     } else if (!this.period.equals(other.period))
/* 84 */       return false;
/* 85 */     if (this.to != other.to)
/* 86 */       return false;
/* 87 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\change\DFSCacheChangeItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */