package com.dukascopy.charts.data.datacache.nisonrenko;

import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationLiveFeedListener;

public abstract interface IRenkoLiveFeedListener
  extends IPriceAggregationLiveFeedListener<RenkoData>
{
  public abstract void newPriceData(RenkoData paramRenkoData);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\nisonrenko\IRenkoLiveFeedListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */