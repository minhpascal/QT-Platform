package com.dukascopy.charts.data.datacache.change;

import com.dukascopy.charts.data.datacache.DataCacheException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

public abstract interface ICacheChangeTracker
{
  public abstract void checkCacheChange()
    throws DataCacheException, TimeoutException, IOException;
  
  public abstract void addCacheChangeListener(ICacheChangeListener paramICacheChangeListener);
  
  public abstract void removeCacheChangeListener(ICacheChangeListener paramICacheChangeListener);
  
  public abstract List<ICacheChangeListener> getCacheChangeListeners();
  
  public abstract void shutdown();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\change\ICacheChangeTracker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */