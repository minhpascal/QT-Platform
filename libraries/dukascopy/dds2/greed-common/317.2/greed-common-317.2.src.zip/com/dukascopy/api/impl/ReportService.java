/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.ILoadingReportPositionListener;
/*     */ import com.dukascopy.api.IReportPosition;
/*     */ import com.dukascopy.api.IReportService;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.LoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.dds3.transport.msg.ord.data.PositionData;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReportService
/*     */   implements IReportService
/*     */ {
/*  32 */   private static final Logger LOGGER = LoggerFactory.getLogger(ReportService.class);
/*     */   
/*  34 */   private AtomicBoolean requestSent = new AtomicBoolean(false);
/*     */   private final IReportPositionProvider reportPositionProvider;
/*     */   
/*     */   public ReportService(IFeedDataProvider feedDataProvider) {
/*  38 */     this.reportPositionProvider = new ReportPositionProvider(feedDataProvider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<IReportPosition> getOpenPositions()
/*     */     throws JFException
/*     */   {
/*  46 */     (List)getPositions(new IReportPositionsLoader()
/*     */     {
/*     */       public List<IReportPosition> loadReportPositions() throws PrivilegedActionException
/*     */       {
/*  50 */         (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public List<IReportPosition> run() throws Exception {
/*  53 */             return ReportService.this.reportPositionProvider.getOpenPositions();
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readOpenPositions(final ILoadingReportPositionListener reportPositionListener, final LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/*  69 */     getPositions(new IReportPositionsLoader()
/*     */     {
/*     */       public Void loadReportPositions() throws PrivilegedActionException
/*     */       {
/*  73 */         (Void)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public Void run() throws Exception {
/*  76 */             ReportService.this.reportPositionProvider.readOpenPositions(new ReportService.LoadingReportPositionListenerWrapper(ReportService.this, ReportService.2.this.val$reportPositionListener), new ReportService.LoadingProgressListenerWrapper(ReportService.this, ReportService.2.this.val$loadingProgress));
/*  77 */             return null;
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<IReportPosition> getClosedPositions(final long from, long to)
/*     */     throws JFException
/*     */   {
/*  91 */     (List)getPositions(new IReportPositionsLoader()
/*     */     {
/*     */       public List<IReportPosition> loadReportPositions() throws PrivilegedActionException
/*     */       {
/*  95 */         (List)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public List<IReportPosition> run() throws Exception {
/*  98 */             return ReportService.this.reportPositionProvider.getClosedPositions(ReportService.3.this.val$from, ReportService.3.this.val$to);
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readClosedPositions(final long from, long to, final ILoadingReportPositionListener reportPositionListener, LoadingProgressListener loadingProgress)
/*     */     throws JFException
/*     */   {
/* 116 */     getPositions(new IReportPositionsLoader()
/*     */     {
/*     */       public Void loadReportPositions() throws PrivilegedActionException
/*     */       {
/* 120 */         (Void)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */         {
/*     */           public Void run() throws Exception {
/* 123 */             ReportService.this.reportPositionProvider.readClosedPositions(ReportService.4.this.val$from, ReportService.4.this.val$to, new ReportService.LoadingReportPositionListenerWrapper(ReportService.this, ReportService.4.this.val$reportPositionListener), new ReportService.LoadingProgressListenerWrapper(ReportService.this, ReportService.4.this.val$loadingProgress));
/* 124 */             return null;
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private <T> T getPositions(IReportPositionsLoader<T> reportPositionsLoader) throws JFException
/*     */   {
/* 133 */     if (this.requestSent.compareAndSet(false, true)) {
/*     */       try
/*     */       {
/* 136 */         return (T)reportPositionsLoader.loadReportPositions();
/*     */       } catch (PrivilegedActionException e) {
/* 138 */         Exception ex = e.getException();
/* 139 */         if ((ex instanceof JFException))
/* 140 */           throw ((JFException)ex);
/* 141 */         if ((ex instanceof RuntimeException)) {
/* 142 */           throw ((RuntimeException)ex);
/*     */         }
/* 144 */         LOGGER.error(ex.getMessage(), ex);
/* 145 */         throw new JFException(ex);
/*     */       }
/*     */       finally
/*     */       {
/* 149 */         this.requestSent.set(false);
/*     */       }
/*     */     }
/* 152 */     throw new JFException("Only one request for positions report can be sent at one time");
/*     */   }
/*     */   
/*     */   private static abstract interface IReportPositionsLoader<T>
/*     */   {
/*     */     public abstract T loadReportPositions() throws PrivilegedActionException;
/*     */   }
/*     */   
/*     */   private class LoadingReportPositionListenerWrapper extends ReportPositionsListener
/*     */   {
/*     */     private ILoadingReportPositionListener loadingReportPositionListener;
/*     */     
/*     */     public LoadingReportPositionListenerWrapper(ILoadingReportPositionListener loadingReportPositionListener) {
/* 165 */       this.loadingReportPositionListener = loadingReportPositionListener;
/*     */     }
/*     */     
/*     */     public IReportPosition onPositionData(PositionData positionData)
/*     */     {
/* 170 */       IReportPosition reportPosition = super.onPositionData(positionData);
/* 171 */       if (reportPosition != null) {
/* 172 */         this.loadingReportPositionListener.newReportPosition(reportPosition);
/*     */       }
/* 174 */       return reportPosition;
/*     */     }
/*     */   }
/*     */   
/*     */   protected class LoadingProgressListenerWrapper implements ILoadingProgressListener {
/*     */     private LoadingProgressListener loadingProgressListener;
/*     */     
/*     */     public LoadingProgressListenerWrapper(LoadingProgressListener loadingProgressListener) {
/* 182 */       this.loadingProgressListener = loadingProgressListener;
/*     */     }
/*     */     
/*     */     public void dataLoaded(long startTime, long endTime, long currentTime, String information)
/*     */     {
/* 187 */       this.loadingProgressListener.dataLoaded(startTime, endTime, currentTime, information);
/*     */     }
/*     */     
/*     */     public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*     */     {
/* 192 */       if (e != null) {
/* 193 */         ReportService.LOGGER.error(e.getMessage(), e);
/*     */       }
/* 195 */       this.loadingProgressListener.loadingFinished(allDataLoaded, startTime, endTime, currentTime);
/* 196 */       ReportService.this.requestSent.set(false);
/*     */     }
/*     */     
/*     */     public boolean stopJob()
/*     */     {
/* 201 */       return this.loadingProgressListener.stopJob();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\ReportService.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */