/*     */ package com.dukascopy.api.impl.util;
/*     */ 
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.impl.connect.PlatformSessionClientBean;
/*     */ import com.dukascopy.api.impl.connect.PlatformType;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.bean.StrategyNewBean;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.bean.VJFStrategyBean;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.json.JSONArray;
/*     */ import com.dukascopy.json.JSONObject;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.text.MessageFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentDownloaderUtils
/*     */ {
/*  39 */   private static final Logger LOGGER = LoggerFactory.getLogger(ComponentDownloaderUtils.class);
/*  40 */   protected static Map<String, FileCache> fileCacheStorage = new HashMap();
/*  41 */   protected static PlatformSessionClientBean platformSessionClientBean = PlatformSessionClientBean.getInstance();
/*  42 */   protected static PlatformType runningMode = platformSessionClientBean.getPlatformType();
/*     */   protected FileCache currentFileCache;
/*     */   protected Date strategyModifyDate;
/*     */   
/*     */   public static enum FileType {
/*  47 */     COMPILED, 
/*  48 */     SOURCE;
/*     */     
/*     */     private FileType() {} }
/*     */   
/*  52 */   public static String getStrategyModifiedDateUrl(String strategyID) { PlatformSessionClientBean instance = PlatformSessionClientBean.getInstance();
/*  53 */     String storageServerUrl = PlatformSessionClientBean.getInstance().getStorageServerUrl();
/*     */     
/*  55 */     String slash = "/";
/*  56 */     if (storageServerUrl.endsWith(slash)) {
/*  57 */       slash = "";
/*     */     }
/*     */     
/*  60 */     StringBuilder buf = new StringBuilder(256);
/*  61 */     buf.append(storageServerUrl).append(slash).append("getUserStrategyTime").append("?").append("sessionid=").append(instance.getSessionID()).append("&").append("ticket=").append(instance.getTicket()).append("&").append("login=").append(instance.getUserName()).append("&").append("scheme=").append(instance.getScheme()).append("&").append("id=").append(strategyID).append("&").append("fileTime=").append("modifyTime");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static JSONArray getStrategiesList() throws JFException {
/*  78 */     StringBuilder urlStringBuffer = new StringBuilder().append(PlatformSessionClientBean.getInstance().getStorageServerUrl());
/*  79 */     urlStringBuffer.append("getUserStrategiesList").append("?sessionid=").append(PlatformSessionClientBean.getInstance().getSessionID()).append("&ticket=").append(PlatformSessionClientBean.getInstance().getTicket()).append("&login=").append(PlatformSessionClientBean.getInstance().getUserName()).append("&scheme=").append(PlatformSessionClientBean.getInstance().getScheme());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     JSONArray jsonArr = null;
/*     */     try {
/*  87 */       URL url = new URL(urlStringBuffer.toString());
/*  88 */       LOGGER.debug(" Sending request: " + url);
/*     */       
/*  90 */       HttpURLConnection urlc = (HttpURLConnection)url.openConnection();
/*  91 */       urlc.setDoOutput(true);
/*  92 */       urlc.connect();
/*  93 */       checkResponseCode(urlc, null);
/*     */       
/*  95 */       if (200 == urlc.getResponseCode()) {
/*  96 */         String response = readResponse(urlc);
/*  97 */         JSONObject json = new JSONObject(response, false);
/*  98 */         jsonArr = json.getJSONArray("data");
/*  99 */         LOGGER.debug("Data recieved: " + json.getJSONArray("data"));
/*     */       }
/* 101 */       urlc.disconnect();
/*     */     }
/*     */     catch (MalformedURLException e) {
/* 104 */       LOGGER.error(e.getMessage(), e);
/*     */     } catch (IOException e) {
/* 106 */       LOGGER.error(e.getMessage(), e);
/*     */     } catch (ParseException e) {
/* 108 */       LOGGER.error(e.getMessage(), e);
/*     */     }
/*     */     
/* 111 */     if (jsonArr == null) { throw new JFException(" Empty List ");
/*     */     }
/* 113 */     return jsonArr;
/*     */   }
/*     */   
/*     */   public static void reset() {
/* 117 */     fileCacheStorage = new HashMap();
/* 118 */     platformSessionClientBean = PlatformSessionClientBean.getInstance();
/* 119 */     runningMode = platformSessionClientBean.getPlatformType();
/*     */   }
/*     */   
/*     */   public static void removeStrategiesCache(List<StrategyNewBean> oldCache) {
/* 123 */     if (!ObjectUtils.isNullOrEmpty(oldCache)) {
/* 124 */       synchronized (fileCacheStorage) {
/* 125 */         for (StrategyNewBean strategy : oldCache) {
/* 126 */           if ((strategy instanceof VJFStrategyBean)) {
/* 127 */             fileCacheStorage.remove(((VJFStrategyBean)VJFStrategyBean.class.cast(strategy)).getVjfId().toString());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected byte[] readComponentAsByteFromServer(String id, String params, Date modifiedTime) throws JFException {
/* 135 */     HttpURLConnection hpCon = makeUrlConnectionWithServer(id, params, modifiedTime);
/*     */     
/* 137 */     this.currentFileCache = new FileCache();
/*     */     
/* 139 */     checkResponseCode(hpCon, id);
/* 140 */     readResponseHeader(id, hpCon);
/* 141 */     byte[] data = createByteArray(hpCon);
/* 142 */     hpCon.disconnect();
/* 143 */     return data;
/*     */   }
/*     */   
/*     */   private static void checkResponseCode(HttpURLConnection hpCon, String id) throws JFException {
/* 147 */     String message = "Bad response from server.";
/*     */     int responseCode;
/*     */     try
/*     */     {
/* 151 */       responseCode = hpCon.getResponseCode();
/* 152 */       String responseMessage = hpCon.getResponseMessage();
/*     */       
/* 154 */       LOGGER.debug(MessageFormat.format("Response from server: {0} {1}", new Object[] { Integer.valueOf(responseCode), responseMessage }));
/*     */     } catch (IOException e) {
/* 156 */       throw new JFException("No response from server");
/*     */     }
/*     */     
/* 159 */     switch (responseCode) {
/*     */     case 400: 
/* 161 */       throw new JFException("Problem with a server. Please try again later");
/*     */     case 401: 
/* 163 */       throw new JFException("Unauthirized access for the component " + id);
/*     */     case 403: 
/* 165 */       throw new JFException("You haven't permissions to access a server");
/*     */     case 404: 
/* 167 */       throw new JFException("Component with id " + id + " not found ");
/*     */     case 500: 
/* 169 */       throw new JFException(message + " Please try again later");
/*     */     }
/*     */   }
/*     */   
/*     */   private static String readResponse(URLConnection connection)
/*     */     throws IOException
/*     */   {
/* 176 */     result = null;
/* 177 */     BufferedReader reader = null;
/*     */     try {
/* 179 */       reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
/*     */       
/* 181 */       StringBuilder sb = new StringBuilder();
/*     */       String tempRes;
/*     */       do {
/* 184 */         tempRes = reader.readLine();
/* 185 */         if (tempRes != null) {
/* 186 */           sb.append(tempRes);
/*     */         }
/*     */         
/* 189 */       } while (tempRes != null);
/*     */       
/* 191 */       return sb.toString();
/*     */     } finally {
/* 193 */       if (reader != null) {
/*     */         try {
/* 195 */           reader.close();
/*     */         } catch (Throwable e) {
/* 197 */           LOGGER.error(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private HttpURLConnection getURLConnectionFromPath(String id, String filePath, String userName, String sessionID, String ticket, String scheme, Date modifiedTime)
/*     */     throws IOException
/*     */   {
/*     */     String urlPath;
/*     */     String urlPath;
/* 208 */     if (modifiedTime != null) {
/* 209 */       urlPath = MessageFormat.format(filePath, new Object[] { id, userName, sessionID, ticket, scheme, String.valueOf(modifiedTime.getTime()) });
/*     */     } else {
/* 211 */       urlPath = MessageFormat.format(filePath, new Object[] { id, userName, sessionID, ticket, scheme });
/*     */     }
/*     */     
/* 214 */     URL httpUrl = new URL(urlPath);
/* 215 */     HttpURLConnection hpCon = (HttpURLConnection)httpUrl.openConnection();
/* 216 */     hpCon.setUseCaches(false);
/* 217 */     hpCon.connect();
/* 218 */     return hpCon;
/*     */   }
/*     */   
/*     */   private void readResponseHeader(String id, HttpURLConnection hpCon) throws JFException {
/* 222 */     String fileNameHeader = hpCon.getHeaderField("Content-Disposition");
/*     */     
/* 224 */     String fileName = parseNameFromHeader(fileNameHeader);
/* 225 */     String modifyTime = hpCon.getHeaderField("strategyModifyDate");
/* 226 */     if (modifyTime != null) {
/* 227 */       this.strategyModifyDate = new Date(Long.parseLong(modifyTime));
/*     */     }
/* 229 */     if (fileName == null) {
/* 230 */       String message = MessageFormat.format("The strategy file name is not received, strategy id = {0} ", new Object[] { id });
/* 231 */       LOGGER.error(message);
/* 232 */       throw new JFException(message);
/*     */     }
/* 234 */     this.currentFileCache.setFileName(fileName);
/*     */     
/* 236 */     LOGGER.debug("File name: " + fileName);
/*     */   }
/*     */   
/*     */   private HttpURLConnection getJssURLConnectionFromPath(String id, String loginName, String filePath) throws IOException {
/* 240 */     String urlPath = MessageFormat.format(filePath, new Object[] { id, loginName });
/* 241 */     LOGGER.debug("URL: " + urlPath);
/* 242 */     URL httpUrl = new URL(urlPath);
/* 243 */     HttpURLConnection hpCon = (HttpURLConnection)httpUrl.openConnection();
/* 244 */     return hpCon;
/*     */   }
/*     */   
/*     */   private HttpURLConnection makeUrlConnectionWithServer(String id, String params, Date modifiedTime) throws JFException {
/* 248 */     String userName = platformSessionClientBean.getUserName();
/* 249 */     String sessionID = platformSessionClientBean.getSessionID();
/* 250 */     String ticket = platformSessionClientBean.getTicket();
/* 251 */     String storageUrl = platformSessionClientBean.getStorageServerUrl();
/* 252 */     String platformScheme = platformSessionClientBean.getScheme();
/*     */     
/* 254 */     StringBuilder filePath = new StringBuilder().append(storageUrl).append(params);
/*     */     try {
/* 256 */       if (runningMode.equals(PlatformType.JSS)) {
/* 257 */         return getJssURLConnectionFromPath(id, userName, filePath.toString());
/*     */       }
/* 259 */       return getURLConnectionFromPath(id, filePath.toString(), userName, sessionID, ticket, platformScheme, modifiedTime);
/*     */     }
/*     */     catch (IOException e) {
/* 262 */       String message = "Unable to download component " + id;
/* 263 */       LOGGER.error(message, e);
/* 264 */       throw new JFException(message, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private String parseNameFromHeader(String fileNameHeader)
/*     */   {
/* 270 */     if (fileNameHeader == null) {
/* 271 */       return null;
/*     */     }
/* 273 */     String token = "filename=";
/* 274 */     String fullFileName = fileNameHeader.substring(fileNameHeader.indexOf(token) + token.length());
/* 275 */     return fullFileName;
/*     */   }
/*     */   
/*     */   private byte[] createByteArray(URLConnection hpCon)
/*     */     throws JFException
/*     */   {
/* 281 */     ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
/*     */     
/* 283 */     int len = hpCon.getContentLength();
/* 284 */     byte[] byteArray; if (len > 0) {
/*     */       try {
/* 286 */         InputStream input = hpCon.getInputStream();
/* 287 */         int c; while ((c = input.read()) != -1) {
/* 288 */           byteOutputStream.write(c);
/*     */         }
/* 290 */         byteArray = byteOutputStream.toByteArray();
/* 291 */         input.close();
/* 292 */         byteOutputStream.close();
/*     */       } catch (IOException e) {
/* 294 */         throw new JFException("Error retrieving file.", e);
/*     */       }
/*     */     } else {
/* 297 */       String message = "No Content Available";
/* 298 */       LOGGER.debug(message);
/* 299 */       throw new JFException(message);
/*     */     }
/* 301 */     return byteArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isVFStrategyUpdatedOnTheServer(String strategyID, boolean source)
/*     */   {
/* 308 */     String MESSAGE_FIELD_NAME = "message";
/* 309 */     String ERROR_FIELD_NAME = "error";
/* 310 */     String DATA_FIELD_NAME = "data";
/* 311 */     String MODIFYDATE_FIELD_NAME = "ModifyDate";
/*     */     
/* 313 */     String errorMessage = "Cannot get the VF strategy modified date, strategyID=" + strategyID;
/* 314 */     String response = null;
/*     */     try
/*     */     {
/* 317 */       FileCache fileCache = (FileCache)fileCacheStorage.get(strategyID);
/* 318 */       if (fileCache == null) {
/* 319 */         return true;
/*     */       }
/*     */       
/* 322 */       String strategyModifiedDateUrl = getStrategyModifiedDateUrl(strategyID);
/* 323 */       URL url = new URL(strategyModifiedDateUrl);
/* 324 */       HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
/*     */       
/* 326 */       response = readResponse(httpURLConnection);
/* 327 */       if ((response == null) || (response.trim().isEmpty())) {
/* 328 */         errorMessage = errorMessage + ". The response is empty.";
/* 329 */         LOGGER.error(errorMessage);
/* 330 */         return false;
/*     */       }
/*     */       
/* 333 */       Date lastModifyTime = null;
/* 334 */       if (source) {
/* 335 */         lastModifyTime = fileCache.getLastSourceModifyTime();
/* 336 */         if (lastModifyTime == null) {
/* 337 */           LOGGER.error("The lastSourceModifyTime is null, updating strategy ...");
/* 338 */           return true;
/*     */         }
/*     */       } else {
/* 341 */         lastModifyTime = fileCache.getLastBinaryModifyTime();
/* 342 */         if (lastModifyTime == null) {
/* 343 */           LOGGER.error("The lastBinaryModifyTime is null, updating strategy ...");
/* 344 */           return true;
/*     */         }
/*     */       }
/*     */       
/* 348 */       JSONObject jsonObject = new JSONObject(response, false);
/* 349 */       String message = jsonObject.getString("message");
/* 350 */       String error = jsonObject.getString("error");
/*     */       
/* 352 */       if ((message != null) && (!message.equalsIgnoreCase("OK"))) {
/* 353 */         errorMessage = errorMessage + ". Response=" + response;
/* 354 */         LOGGER.error(errorMessage);
/* 355 */         return false;
/*     */       }
/*     */       
/* 358 */       if ((error != null) && (!error.equals("0"))) {
/* 359 */         errorMessage = errorMessage + ". Response=" + response;
/* 360 */         LOGGER.error(errorMessage);
/* 361 */         return false;
/*     */       }
/*     */       
/* 364 */       JSONArray jsonArray = jsonObject.getJSONArray("data");
/* 365 */       if ((jsonArray == null) || (jsonArray.length() == 0)) {
/* 366 */         errorMessage = errorMessage + ". Response=" + response;
/* 367 */         LOGGER.error(errorMessage);
/* 368 */         return false;
/*     */       }
/*     */       
/* 371 */       long modifyDate = 0L;
/* 372 */       for (int i = 0; i < jsonArray.length(); i++) {
/* 373 */         JSONObject tempJsonObject = jsonArray.getJSONObject(i);
/* 374 */         if (tempJsonObject.has("ModifyDate")) {
/*     */           try {
/* 376 */             modifyDate = tempJsonObject.getPrimitiveLong("ModifyDate");
/*     */           }
/*     */           catch (NumberFormatException e)
/*     */           {
/*     */             try
/*     */             {
/* 382 */               SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 383 */               String dateAsString = tempJsonObject.getString("ModifyDate");
/* 384 */               Date currentDate = format.parse(dateAsString);
/*     */               
/* 386 */               String d1 = format.format(lastModifyTime);
/* 387 */               String d2 = format.format(currentDate);
/*     */               
/* 389 */               if (d1.equals(d2)) {
/* 390 */                 return false;
/*     */               }
/* 392 */               return true;
/*     */             }
/*     */             catch (ParseException e2) {
/* 395 */               SimpleDateFormat format = new SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy");
/* 396 */               String dateAsString = tempJsonObject.getString("ModifyDate");
/* 397 */               Date currentDate = format.parse(dateAsString);
/*     */               
/* 399 */               String d1 = format.format(lastModifyTime);
/* 400 */               String d2 = format.format(currentDate);
/*     */               
/* 402 */               if (d1.equals(d2)) {
/* 403 */                 return false;
/*     */               }
/* 405 */               return true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 414 */       if (modifyDate == 0L) {
/* 415 */         errorMessage = errorMessage + ". Response=" + response;
/* 416 */         LOGGER.error(errorMessage);
/* 417 */         return false;
/*     */       }
/*     */       
/* 420 */       if (lastModifyTime.getTime() != modifyDate) {
/* 421 */         return true;
/*     */       }
/* 423 */       return false;
/*     */     }
/*     */     catch (Throwable e) {
/* 426 */       LOGGER.error(errorMessage + ", response=" + response);
/* 427 */       LOGGER.error(e.getMessage(), e); }
/* 428 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\ComponentDownloaderUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */