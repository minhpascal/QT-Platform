/*     */ package com.dukascopy.charts.data.datacache.feed;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.Data;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.dds3.transport.msg.acc.FeedCommission;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZeroFeedCommissionManager
/*     */   implements IFeedCommissionManager
/*     */ {
/*     */   public void addFeedCommissions(Map<String, FeedCommission> feedCommissions) {}
/*     */   
/*     */   public void addFeedCommissions(List<IInstrumentFeedCommissionInfo> feedCommissions) {}
/*     */   
/*     */   public void clear() {}
/*     */   
/*     */   public double getFeedCommission(Instrument instrument, OfferSide offerSide, long time)
/*     */   {
/*  42 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getPriceWithCommission(Instrument instrument, OfferSide side, double price, long time)
/*     */   {
/*  52 */     return price;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setupFeedCommissions(List<IInstrumentFeedCommissionInfo> feedCommissions) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void setupFeedCommissionsFromAuthServer(List<String[]> feedCommissions) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public CandleData applyFeedCommissionToCandle(Instrument instrument, OfferSide side, CandleData candle)
/*     */   {
/*  67 */     return candle;
/*     */   }
/*     */   
/*     */   public TickData applyFeedCommissionToTick(Instrument instrument, OfferSide offerSide, TickData tick)
/*     */   {
/*  72 */     return tick;
/*     */   }
/*     */   
/*     */   public Data[] applyFeedCommissionToData(Instrument instrument, Period period, OfferSide offerSide, Data[] data)
/*     */   {
/*  77 */     return data;
/*     */   }
/*     */   
/*     */   public boolean hasCommission(Instrument instrument)
/*     */   {
/*  82 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addFeedCommissions(Map<String, FeedCommission> feedCommissions, Long time) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void addFeedCommissions(Map<String, FeedCommission> feedCommissions, long time) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public List<String[]> getFeedCommissions()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   public TickData applyFeedCommissionToTick(Instrument instrument, TickData tick)
/*     */   {
/* 102 */     return tick;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\feed\ZeroFeedCommissionManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */