/*     */ package com.dukascopy.charts.data.datacache.feed;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeedCommissionMap
/*     */ {
/*  23 */   private final List<IInstrumentFeedCommissionInfo> allInstrumentFeedCommissions = new ArrayList();
/*  24 */   private final Map<Instrument, List<IInstrumentFeedCommissionInfo>> specificInstrumentFeedCommissions = new HashMap();
/*     */   
/*     */ 
/*  27 */   private final Comparator<IInstrumentFeedCommissionInfo> FEED_COMMISSION_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(IInstrumentFeedCommissionInfo o1, IInstrumentFeedCommissionInfo o2) {
/*  30 */       if (o1.getStart() > o2.getStart()) {
/*  31 */         return 1;
/*     */       }
/*  33 */       if (o1.getStart() < o2.getStart()) {
/*  34 */         return -1;
/*     */       }
/*     */       
/*  37 */       if (o1.getEnd() < o2.getEnd()) {
/*  38 */         return 1;
/*     */       }
/*  40 */       if (o1.getEnd() > o2.getEnd()) {
/*  41 */         return -1;
/*     */       }
/*     */       
/*  44 */       if (o1.getPriority() > o2.getPriority()) {
/*  45 */         return 1;
/*     */       }
/*     */       
/*  48 */       return -1;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void setupFeedCommissionsMap(List<IInstrumentFeedCommissionInfo> instrumentFeedCommissions)
/*     */   {
/*  56 */     clear();
/*  57 */     addToFeedCommissionsMap(instrumentFeedCommissions);
/*     */   }
/*     */   
/*     */   public synchronized void addToFeedCommissionsMap(List<IInstrumentFeedCommissionInfo> instrumentFeedCommissions) {
/*  61 */     if ((instrumentFeedCommissions == null) || (instrumentFeedCommissions.isEmpty())) {
/*  62 */       return;
/*     */     }
/*     */     
/*  65 */     Set<Instrument> instrumentsToBeSorted = new HashSet();
/*     */     
/*  67 */     for (IInstrumentFeedCommissionInfo info : instrumentFeedCommissions) {
/*  68 */       Instrument instrument = info.getInstrument();
/*  69 */       instrumentsToBeSorted.add(instrument);
/*     */       
/*  71 */       if (instrument == null) {
/*  72 */         this.allInstrumentFeedCommissions.add(info);
/*  73 */         instrumentsToBeSorted.add(null);
/*     */       }
/*     */       else {
/*  76 */         List<IInstrumentFeedCommissionInfo> feedCommissions = (List)this.specificInstrumentFeedCommissions.get(instrument);
/*  77 */         if (feedCommissions == null) {
/*  78 */           feedCommissions = new ArrayList();
/*  79 */           this.specificInstrumentFeedCommissions.put(instrument, feedCommissions);
/*     */         }
/*  81 */         feedCommissions.add(info);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  86 */     for (Instrument instrument : instrumentsToBeSorted) { List<IInstrumentFeedCommissionInfo> commissions;
/*     */       List<IInstrumentFeedCommissionInfo> commissions;
/*  88 */       if (instrument == null) {
/*  89 */         commissions = this.allInstrumentFeedCommissions;
/*     */       }
/*     */       else {
/*  92 */         commissions = (List)this.specificInstrumentFeedCommissions.get(instrument);
/*     */       }
/*     */       
/*  95 */       Collections.sort(commissions, this.FEED_COMMISSION_COMPARATOR);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized boolean hasCommission(Instrument instrument)
/*     */   {
/* 101 */     boolean anyCommission = this.specificInstrumentFeedCommissions.containsKey(instrument);
/* 102 */     boolean result = (anyCommission) || (!this.allInstrumentFeedCommissions.isEmpty());
/* 103 */     return result;
/*     */   }
/*     */   
/*     */   public synchronized IInstrumentFeedCommissionInfo getFeedCommissionInfo(Instrument instrument, long time) {
/* 107 */     if (!hasCommission(instrument)) {
/* 108 */       return null;
/*     */     }
/*     */     
/* 111 */     List<IInstrumentFeedCommissionInfo> feedCommissions = (List)this.specificInstrumentFeedCommissions.get(instrument);
/* 112 */     IInstrumentFeedCommissionInfo specificInstrumentFC = findFeedCommission(feedCommissions, time);
/* 113 */     IInstrumentFeedCommissionInfo allInstrumentFC = findFeedCommission(this.allInstrumentFeedCommissions, time);
/*     */     
/* 115 */     if ((specificInstrumentFC != null) && (allInstrumentFC != null)) {
/* 116 */       return specificInstrumentFC.getStart() < allInstrumentFC.getStart() ? allInstrumentFC : specificInstrumentFC;
/*     */     }
/* 118 */     if (specificInstrumentFC != null) {
/* 119 */       return specificInstrumentFC;
/*     */     }
/* 121 */     if (allInstrumentFC != null) {
/* 122 */       return allInstrumentFC;
/*     */     }
/*     */     
/* 125 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private IInstrumentFeedCommissionInfo findFeedCommission(List<IInstrumentFeedCommissionInfo> feedCommissions, long time)
/*     */   {
/* 131 */     if ((feedCommissions != null) && (feedCommissions.size() > 0))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */       for (int i = feedCommissions.size() - 1; i >= 0; i--) {
/* 141 */         IInstrumentFeedCommissionInfo fci = (IInstrumentFeedCommissionInfo)feedCommissions.get(i);
/* 142 */         if (fci.isInInterval(time)) {
/* 143 */           return fci;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized void clear()
/*     */   {
/* 153 */     this.allInstrumentFeedCommissions.clear();
/* 154 */     this.specificInstrumentFeedCommissions.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\feed\FeedCommissionMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */