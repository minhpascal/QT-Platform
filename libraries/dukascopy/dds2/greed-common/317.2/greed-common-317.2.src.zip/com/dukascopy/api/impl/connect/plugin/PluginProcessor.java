/*    */ package com.dukascopy.api.impl.connect.plugin;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.JFRunnableProcessor;
/*    */ import com.dukascopy.api.plugins.IPluginContext;
/*    */ import com.dukascopy.api.plugins.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginProcessor
/*    */   extends JFRunnableProcessor<IPluginContext, Plugin>
/*    */ {
/*    */   public PluginProcessor(PluginTaskManager taskManager, Plugin plugin, boolean fullAccessGranted)
/*    */   {
/* 15 */     super(taskManager, null, plugin, fullAccessGranted);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\plugin\PluginProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */