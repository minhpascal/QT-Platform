/*     */ package com.dukascopy.charts.data.datacache.core.lock;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheFileHandler
/*     */ {
/*     */   private final File file;
/*  24 */   private final AtomicBoolean deleteOnExitCalled = new AtomicBoolean(false);
/*  25 */   private final List<RandomAccessFileItem> cachedRandomAccessesForRead = new ArrayList();
/*     */   
/*  27 */   private AtomicBoolean fileExists = new AtomicBoolean(false);
/*     */   
/*     */ 
/*     */   private final ReentrantReadWriteLock localReadWriteLock;
/*     */   
/*     */   private final GlobalLockCacheFileHandler globalLockFileHandler;
/*     */   
/*     */   private final boolean deleteGlobalLockFileOnUnlock;
/*     */   
/*     */ 
/*     */   public CacheFileHandler(File file, ReentrantReadWriteLock localReadWriteLock, GlobalLockCacheFileHandler globalLockFile, boolean deleteGlobalLockFileOnUnlock)
/*     */   {
/*  39 */     this.file = file;
/*  40 */     this.localReadWriteLock = localReadWriteLock;
/*  41 */     this.globalLockFileHandler = globalLockFile;
/*  42 */     this.deleteGlobalLockFileOnUnlock = deleteGlobalLockFileOnUnlock;
/*     */   }
/*     */   
/*     */   public File getFile() {
/*  46 */     return this.file;
/*     */   }
/*     */   
/*     */   public boolean isFileExists() {
/*  50 */     return this.fileExists.get();
/*     */   }
/*     */   
/*     */   public void setFileExists(boolean fileExists) {
/*  54 */     this.fileExists.set(fileExists);
/*     */   }
/*     */   
/*     */   public RandomAccessFile getCachedRandomAccessFileForRead() throws FileNotFoundException {
/*  58 */     if (!this.fileExists.get()) {
/*  59 */       return null;
/*     */     }
/*     */     
/*  62 */     if (isGlobalLockingEnabled())
/*     */     {
/*     */ 
/*     */ 
/*  66 */       return new RandomAccessFile(this.file, "r");
/*     */     }
/*     */     
/*  69 */     synchronized (this.cachedRandomAccessesForRead) {
/*  70 */       for (RandomAccessFileItem item : this.cachedRandomAccessesForRead) {
/*  71 */         if (!item.isInUse()) {
/*  72 */           item.setInUse(true);
/*  73 */           return item.getRandomAccessFile();
/*     */         }
/*     */       }
/*     */       
/*  77 */       RandomAccessFile result = new RandomAccessFile(this.file, "r");
/*  78 */       RandomAccessFileItem item = new RandomAccessFileItem(result, true);
/*  79 */       this.cachedRandomAccessesForRead.add(item);
/*     */       
/*  81 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   public void returnToPool(RandomAccessFile raf) throws IOException
/*     */   {
/*  87 */     if (isGlobalLockingEnabled())
/*     */     {
/*     */ 
/*     */ 
/*  91 */       raf.close();
/*     */     }
/*     */     else {
/*  94 */       synchronized (this.cachedRandomAccessesForRead) {
/*  95 */         for (RandomAccessFileItem item : this.cachedRandomAccessesForRead) {
/*  96 */           if (item.getRandomAccessFile() == raf) {
/*  97 */             item.setInUse(false);
/*  98 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean clearReadCache() throws IOException
/*     */   {
/* 107 */     if (isGlobalLockingEnabled())
/*     */     {
/*     */ 
/*     */ 
/* 111 */       return true;
/*     */     }
/*     */     
/* 114 */     synchronized (this.cachedRandomAccessesForRead) {
/* 115 */       Iterator<RandomAccessFileItem> iterator = this.cachedRandomAccessesForRead.iterator();
/* 116 */       while (iterator.hasNext()) {
/* 117 */         RandomAccessFileItem item = (RandomAccessFileItem)iterator.next();
/* 118 */         if (!item.isInUse()) {
/* 119 */           item.getRandomAccessFile().close();
/* 120 */           iterator.remove();
/*     */         }
/*     */       }
/*     */       
/* 124 */       return this.cachedRandomAccessesForRead.isEmpty();
/*     */     }
/*     */   }
/*     */   
/*     */   public void readLock() throws TimeoutException, IOException
/*     */   {
/* 130 */     if (isGlobalLockingEnabled()) {
/* 131 */       this.globalLockFileHandler.getFileLock().lock();
/*     */     }
/*     */     
/* 134 */     if (isLocalLockingEnabled()) {
/* 135 */       this.localReadWriteLock.readLock().lock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeLock() throws TimeoutException, IOException {
/* 140 */     if (isGlobalLockingEnabled()) {
/* 141 */       this.globalLockFileHandler.getFileLock().lock();
/*     */     }
/*     */     
/* 144 */     if (isLocalLockingEnabled()) {
/* 145 */       this.localReadWriteLock.writeLock().lock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void readUnlock() {
/* 150 */     if (isLocalLockingEnabled()) {
/* 151 */       this.localReadWriteLock.readLock().unlock();
/*     */     }
/*     */     
/* 154 */     if (isGlobalLockingEnabled()) {
/* 155 */       this.globalLockFileHandler.getFileLock().unlock(this.deleteGlobalLockFileOnUnlock);
/*     */     }
/*     */   }
/*     */   
/*     */   public void localReadUnlockWriteLock() {
/* 160 */     if (isLocalLockingEnabled()) {
/* 161 */       this.localReadWriteLock.readLock().unlock();
/* 162 */       this.localReadWriteLock.writeLock().lock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void localWriteUnlockReadLock() {
/* 167 */     if (isLocalLockingEnabled()) {
/* 168 */       this.localReadWriteLock.writeLock().unlock();
/* 169 */       this.localReadWriteLock.readLock().lock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUnlock() {
/* 174 */     if (isLocalLockingEnabled()) {
/* 175 */       this.localReadWriteLock.writeLock().unlock();
/*     */     }
/*     */     
/* 178 */     if (isGlobalLockingEnabled()) {
/* 179 */       this.globalLockFileHandler.getFileLock().unlock(this.deleteGlobalLockFileOnUnlock);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isGloballyLocked() {
/* 184 */     if (isGlobalLockingEnabled()) {
/* 185 */       return this.globalLockFileHandler.getFileLock().isLocked();
/*     */     }
/*     */     
/* 188 */     return false;
/*     */   }
/*     */   
/*     */   public boolean tryLocalWriteLock()
/*     */   {
/* 193 */     if (isLocalLockingEnabled()) {
/* 194 */       return this.localReadWriteLock.writeLock().tryLock();
/*     */     }
/*     */     
/* 197 */     return true;
/*     */   }
/*     */   
/*     */   public void unlockLocalWriteLock()
/*     */   {
/* 202 */     if (isLocalLockingEnabled()) {
/* 203 */       this.localReadWriteLock.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isGlobalLockingEnabled() {
/* 208 */     boolean result = this.globalLockFileHandler != null;
/* 209 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isLocalLockingEnabled() {
/* 213 */     boolean result = this.localReadWriteLock != null;
/* 214 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 219 */     return this.file == null ? "null" : this.file.toString();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 224 */     int prime = 31;
/* 225 */     int result = 1;
/* 226 */     result = 31 * result + (this.file == null ? 0 : this.file.hashCode());
/* 227 */     result = 31 * result + (this.fileExists == null ? 0 : this.fileExists.hashCode());
/* 228 */     result = 31 * result + (this.globalLockFileHandler == null ? 0 : this.globalLockFileHandler.hashCode());
/* 229 */     result = 31 * result + (this.localReadWriteLock == null ? 0 : this.localReadWriteLock.hashCode());
/* 230 */     result = 31 * result + (this.cachedRandomAccessesForRead == null ? 0 : this.cachedRandomAccessesForRead.hashCode());
/* 231 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 236 */     if (this == obj)
/* 237 */       return true;
/* 238 */     if (obj == null)
/* 239 */       return false;
/* 240 */     if (getClass() != obj.getClass())
/* 241 */       return false;
/* 242 */     CacheFileHandler other = (CacheFileHandler)obj;
/* 243 */     if (this.file == null) {
/* 244 */       if (other.file != null)
/* 245 */         return false;
/* 246 */     } else if (!this.file.equals(other.file))
/* 247 */       return false;
/* 248 */     if (this.fileExists == null) {
/* 249 */       if (other.fileExists != null)
/* 250 */         return false;
/* 251 */     } else if (!this.fileExists.equals(other.fileExists))
/* 252 */       return false;
/* 253 */     if (this.globalLockFileHandler == null) {
/* 254 */       if (other.globalLockFileHandler != null)
/* 255 */         return false;
/* 256 */     } else if (!this.globalLockFileHandler.equals(other.globalLockFileHandler))
/* 257 */       return false;
/* 258 */     if (this.localReadWriteLock == null) {
/* 259 */       if (other.localReadWriteLock != null)
/* 260 */         return false;
/* 261 */     } else if (!this.localReadWriteLock.equals(other.localReadWriteLock))
/* 262 */       return false;
/* 263 */     if (this.cachedRandomAccessesForRead == null) {
/* 264 */       if (other.cachedRandomAccessesForRead != null)
/* 265 */         return false;
/* 266 */     } else if (!this.cachedRandomAccessesForRead.equals(other.cachedRandomAccessesForRead))
/* 267 */       return false;
/* 268 */     return true;
/*     */   }
/*     */   
/*     */   public void deleteOnExit() {
/* 272 */     if (this.deleteOnExitCalled.compareAndSet(false, true)) {
/* 273 */       this.file.deleteOnExit();
/*     */     }
/*     */   }
/*     */   
/*     */   public GlobalLockCacheFileHandler getGlobalLockFileHandler() {
/* 278 */     return this.globalLockFileHandler;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\lock\CacheFileHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */