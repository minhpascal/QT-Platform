/*     */ package com.dukascopy.charts.data.datacache.feed;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.charts.data.datacache.preloader.InstrumentTimeInterval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstrumentFeedCommissionInfo
/*     */   extends InstrumentTimeInterval
/*     */   implements IInstrumentFeedCommissionInfo
/*     */ {
/*     */   private double askFeedCommission;
/*     */   private double bidFeedCommission;
/*     */   private long priority;
/*     */   
/*     */   public InstrumentFeedCommissionInfo(Instrument instrument, double askFeedCommission, double bidFeedCommission, long start, long end)
/*     */   {
/*  26 */     this(instrument, askFeedCommission, bidFeedCommission, start, end, Long.MIN_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InstrumentFeedCommissionInfo(Instrument instrument, double askFeedCommission, double bidFeedCommission, long start, long end, long priority)
/*     */   {
/*  44 */     super(instrument, start, end);
/*  45 */     this.askFeedCommission = askFeedCommission;
/*  46 */     this.bidFeedCommission = bidFeedCommission;
/*  47 */     this.priority = priority;
/*     */   }
/*     */   
/*     */   public long getPriority()
/*     */   {
/*  52 */     return this.priority;
/*     */   }
/*     */   
/*     */   public void setPriority(long priority)
/*     */   {
/*  57 */     this.priority = priority;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  62 */     return this.askFeedCommission + "/" + this.bidFeedCommission + " " + super.toString() + " " + this.priority;
/*     */   }
/*     */   
/*     */   public double getAskFeedCommission()
/*     */   {
/*  67 */     return this.askFeedCommission;
/*     */   }
/*     */   
/*     */   public void setAskFeedCommission(double askFeedCommission)
/*     */   {
/*  72 */     this.askFeedCommission = askFeedCommission;
/*     */   }
/*     */   
/*     */   public double getBidFeedCommission()
/*     */   {
/*  77 */     return this.bidFeedCommission;
/*     */   }
/*     */   
/*     */   public void setBidFeedCommission(double bidFeedCommission)
/*     */   {
/*  82 */     this.bidFeedCommission = bidFeedCommission;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  87 */     int prime = 31;
/*  88 */     int result = super.hashCode();
/*     */     
/*  90 */     long temp = Double.doubleToLongBits(this.askFeedCommission);
/*  91 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/*  92 */     temp = Double.doubleToLongBits(this.bidFeedCommission);
/*  93 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/*  94 */     result = 31 * result + (int)(this.priority ^ this.priority >>> 32);
/*  95 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 100 */     if (this == obj)
/* 101 */       return true;
/* 102 */     if (!super.equals(obj))
/* 103 */       return false;
/* 104 */     if (getClass() != obj.getClass())
/* 105 */       return false;
/* 106 */     InstrumentFeedCommissionInfo other = (InstrumentFeedCommissionInfo)obj;
/* 107 */     if (Double.doubleToLongBits(this.askFeedCommission) != Double.doubleToLongBits(other.askFeedCommission))
/*     */     {
/* 109 */       return false; }
/* 110 */     if (Double.doubleToLongBits(this.bidFeedCommission) != Double.doubleToLongBits(other.bidFeedCommission))
/*     */     {
/* 112 */       return false; }
/* 113 */     if (this.priority != other.priority)
/* 114 */       return false;
/* 115 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\feed\InstrumentFeedCommissionInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */