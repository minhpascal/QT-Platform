/*     */ package com.dukascopy.charts.data.datacache.customperiod.tick;
/*     */ 
/*     */ import com.dukascopy.api.Filter;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.customperiod.AbstractCustomPeriodCreator;
/*     */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomPeriodFromTicksCreator
/*     */   extends AbstractCustomPeriodCreator
/*     */ {
/*     */   private final int desiredCandlesCount;
/*     */   private final boolean inverseOrder;
/*     */   private final Filter filter;
/*     */   private Long desiredFirstDataTime;
/*     */   private final Double firstDataValue;
/*     */   private CandleData currentCandleDataUnderAnalysis;
/*     */   private CandleData previouslyAnalysedCandleData;
/*     */   protected CandleData[] result;
/*     */   private int lastElementIndex;
/*     */   private Long firstTime;
/*     */   private Long lastTime;
/*     */   private int loadedCandlesCount;
/*     */   private final IFilterManager filterManager;
/*     */   
/*     */   public CustomPeriodFromTicksCreator(Instrument instrument, OfferSide offerSide, int desiredCandlesCount, Period desiredPeriod, Filter filter, boolean inverseOrder, Long desiredFirstDataTime, Double firstDataValue, IFilterManager filterManager)
/*     */   {
/*  52 */     super(instrument, offerSide, desiredPeriod);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */     this.desiredCandlesCount = desiredCandlesCount;
/*  59 */     this.inverseOrder = inverseOrder;
/*  60 */     this.filter = filter;
/*  61 */     this.firstDataValue = firstDataValue;
/*  62 */     this.desiredFirstDataTime = (desiredFirstDataTime != null ? new Long(DataCacheUtils.getCandleStartFast(desiredPeriod, desiredFirstDataTime.longValue())) : null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  67 */     this.filterManager = filterManager;
/*     */     
/*  69 */     reset();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  73 */     this.lastElementIndex = -1;
/*  74 */     this.firstTime = null;
/*  75 */     this.lastTime = null;
/*  76 */     this.loadedCandlesCount = 0;
/*  77 */     this.result = new CandleData[this.desiredCandlesCount];
/*     */   }
/*     */   
/*     */   public boolean analyseTickData(TickData data)
/*     */   {
/*  82 */     if (data == null) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     long candleStartTime = getCandleStartFast(data);
/*     */     
/*  88 */     if (this.firstTime == null) {
/*  89 */       this.firstTime = new Long(candleStartTime);
/*     */     }
/*     */     
/*  92 */     this.lastTime = new Long(candleStartTime);
/*     */     
/*  94 */     if (this.currentCandleDataUnderAnalysis == null)
/*     */     {
/*  96 */       Long currentCandleTime = null;
/*     */       
/*  98 */       if (getLastData() != null) {
/*  99 */         currentCandleTime = Long.valueOf(DataCacheUtils.getNextCandleStartFast(getDesiredPeriod(), getLastData().time));
/*     */       }
/* 101 */       else if (this.desiredFirstDataTime != null) {
/* 102 */         currentCandleTime = this.desiredFirstDataTime;
/*     */       }
/*     */       
/* 105 */       if ((currentCandleTime != null) && (timesBelongToDifferentCandles(candleStartTime, currentCandleTime.longValue())))
/*     */       {
/*     */ 
/*     */ 
/* 109 */         double price = getFirstDataValue() != null ? getFirstDataValue().doubleValue() : getPrice(data, getOfferSide());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 114 */         this.currentCandleDataUnderAnalysis = new CandleData(currentCandleTime.longValue(), price, price, price, price, 0.0D);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */         boolean result = finishCurrentCandleCreation(data, candleStartTime);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 128 */         if (result) {
/* 129 */           return true;
/*     */         }
/*     */       }
/*     */       else {
/* 133 */         this.currentCandleDataUnderAnalysis = startNewCandleData(data, candleStartTime, true);
/*     */       }
/*     */     }
/* 136 */     else if (timesBelongToDifferentCandles(candleStartTime, this.currentCandleDataUnderAnalysis.getTime())) {
/* 137 */       boolean result = finishCurrentCandleCreation(data, candleStartTime);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 142 */       if (result) {
/* 143 */         return true;
/*     */       }
/*     */     }
/*     */     else {
/* 147 */       continueCurrentCandleAnalysis(data);
/*     */     }
/*     */     
/* 150 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean finishCurrentCandleCreation(TickData data, long candleStartTime)
/*     */   {
/* 157 */     CandleData candleDataResult = finishCurrentCandleAnalysis();
/*     */     
/* 159 */     if ((!Filter.ALL_FLATS.equals(getFilter())) || (!candleDataResult.isFlat()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */       if ((!Filter.WEEKENDS.equals(getFilter())) || (!this.filterManager.isWeekendTime(candleDataResult.getTime(), Period.TICK)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 171 */         addCompletedCandle(candleDataResult);
/*     */       }
/*     */       
/*     */ 
/* 175 */       if (!Filter.ALL_FLATS.equals(getFilter()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 180 */         checkAndFirePreviousFlatsIfAny(data, candleDataResult, getDesiredPeriod(), getFilter());
/*     */       }
/*     */     }
/*     */     
/* 184 */     if (isItEnoughCandles(this.loadedCandlesCount))
/*     */     {
/*     */ 
/*     */ 
/* 188 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 194 */     this.currentCandleDataUnderAnalysis = startNewCandleData(data, candleStartTime, false);
/*     */     
/* 196 */     return false;
/*     */   }
/*     */   
/*     */   private boolean timesBelongToDifferentCandles(long time1, long time2) {
/* 200 */     if (time1 == time2) {
/* 201 */       return false;
/*     */     }
/*     */     
/* 204 */     Period period = getDesiredPeriod();
/* 205 */     boolean theSameCandle = DataCacheUtils.getCandleStartFast(period, time1) == DataCacheUtils.getCandleStartFast(period, time2);
/* 206 */     return !theSameCandle;
/*     */   }
/*     */   
/*     */   private long getCandleStartFast(TickData tickData)
/*     */   {
/* 211 */     long time = tickData.getTime();
/* 212 */     long candleStartTime = DataCacheUtils.getCandleStartFast(getDesiredPeriod(), time);
/* 213 */     return candleStartTime;
/*     */   }
/*     */   
/*     */   protected void addCompletedCandle(CandleData candleData) {
/* 217 */     this.loadedCandlesCount += 1;
/* 218 */     this.lastElementIndex += 1;
/* 219 */     this.result[this.lastElementIndex] = candleData;
/*     */     
/* 221 */     fireNewCandle(candleData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkAndFirePreviousFlatsIfAny(TickData data, CandleData currentCandleDataUnderAnalysis, Period period, Filter filter)
/*     */   {
/* 230 */     if (currentCandleDataUnderAnalysis == null) {
/* 231 */       return;
/*     */     }
/*     */     
/* 234 */     long targetTime = getCandleStartFast(data);
/* 235 */     long currentTime = currentCandleDataUnderAnalysis.getTime();
/*     */     
/* 237 */     long candlesCountInTimePeriod = Math.abs(targetTime - currentTime) / period.getInterval();
/* 238 */     candlesCountInTimePeriod -= 1L;
/*     */     
/* 240 */     if (candlesCountInTimePeriod > 0L) {
/* 241 */       long time = 0L;
/* 242 */       double value = -1.0D;
/*     */       
/* 244 */       if (!getInverseOrder()) {
/* 245 */         if ((getFirstDataValue() != null) && (getLoadedCandleCount() == 0) && (this.firstTime != null) && (this.firstTime.longValue() != currentCandleDataUnderAnalysis.time))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */           value = getFirstDataValue().doubleValue();
/*     */         }
/*     */         else {
/* 254 */           value = currentCandleDataUnderAnalysis.getClose();
/*     */         }
/*     */       }
/*     */       else {
/* 258 */         value = getPrice(data, getOfferSide());
/*     */       }
/*     */       
/* 261 */       for (int i = 0; i < (int)candlesCountInTimePeriod; i++) {
/* 262 */         if (!getInverseOrder())
/*     */         {
/*     */ 
/*     */ 
/* 266 */           time = DataCacheUtils.getTimeForNCandlesForwardFast(period, currentTime, i + 2);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 272 */           time = DataCacheUtils.getTimeForNCandlesBackFast(period, currentTime, i + 2);
/*     */         }
/* 274 */         CandleData flat = createFlat(value, time);
/*     */         
/* 276 */         if (isItEnoughCandles(this.loadedCandlesCount))
/*     */         {
/*     */ 
/*     */ 
/* 280 */           return;
/*     */         }
/*     */         
/* 283 */         if ((!Filter.WEEKENDS.equals(filter)) || (!this.filterManager.isWeekendTime(flat.getTime(), Period.TICK)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 289 */           addCompletedCandle(flat);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private CandleData createFlat(double value, long time)
/*     */   {
/* 297 */     CandleData candleData = new CandleData();
/* 298 */     candleData.setClose(value);
/* 299 */     candleData.setOpen(value);
/* 300 */     candleData.setHigh(value);
/* 301 */     candleData.setLow(value);
/* 302 */     candleData.setVolume(0.0D);
/* 303 */     candleData.setTime(time);
/* 304 */     return candleData;
/*     */   }
/*     */   
/*     */   private void continueCurrentCandleAnalysis(TickData data) {
/* 308 */     boolean wasFlat = this.currentCandleDataUnderAnalysis.isFlat();
/* 309 */     this.currentCandleDataUnderAnalysis.setVolume(round(this.currentCandleDataUnderAnalysis.getVolume() + getVolume(data, getOfferSide())));
/*     */     
/* 311 */     double value = getPrice(data, getOfferSide());
/*     */     
/* 313 */     if (getInverseOrder()) {
/* 314 */       this.currentCandleDataUnderAnalysis.setOpen(value);
/* 315 */       if (wasFlat)
/*     */       {
/* 317 */         this.currentCandleDataUnderAnalysis.setClose(value);
/* 318 */         this.currentCandleDataUnderAnalysis.setLow(value);
/* 319 */         this.currentCandleDataUnderAnalysis.setHigh(value);
/*     */       }
/*     */     }
/*     */     else {
/* 323 */       this.currentCandleDataUnderAnalysis.setClose(value);
/* 324 */       if (wasFlat)
/*     */       {
/* 326 */         this.currentCandleDataUnderAnalysis.setOpen(value);
/* 327 */         this.currentCandleDataUnderAnalysis.setLow(value);
/* 328 */         this.currentCandleDataUnderAnalysis.setHigh(value);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 333 */     if (this.currentCandleDataUnderAnalysis.getLow() > value) {
/* 334 */       this.currentCandleDataUnderAnalysis.setLow(value);
/*     */     }
/* 336 */     if (this.currentCandleDataUnderAnalysis.getHigh() < value) {
/* 337 */       this.currentCandleDataUnderAnalysis.setHigh(value);
/*     */     }
/*     */   }
/*     */   
/*     */   private CandleData finishCurrentCandleAnalysis() {
/* 342 */     this.previouslyAnalysedCandleData = this.currentCandleDataUnderAnalysis;
/* 343 */     this.currentCandleDataUnderAnalysis = null;
/*     */     
/* 345 */     return this.previouslyAnalysedCandleData;
/*     */   }
/*     */   
/*     */   private CandleData startNewCandleData(TickData data, long time, boolean firstTime) {
/* 349 */     return startNewCandleData(time, getPrice(data, getOfferSide()), getVolume(data, getOfferSide()), firstTime);
/*     */   }
/*     */   
/*     */   private CandleData startNewCandleData(long time, double value, double volume, boolean firstTime) {
/* 353 */     CandleData candleData = new CandleData();
/*     */     
/* 355 */     if ((firstTime) && (getDesiredFirstDataTime() != null)) {
/* 356 */       time = getDesiredFirstDataTime().longValue();
/*     */     }
/*     */     
/* 359 */     candleData.setTime(time);
/* 360 */     candleData.setOpen(value);
/* 361 */     candleData.setClose(value);
/* 362 */     candleData.setHigh(value);
/* 363 */     candleData.setLow(value);
/* 364 */     candleData.setVolume(volume);
/*     */     
/* 366 */     return candleData;
/*     */   }
/*     */   
/*     */   protected boolean isItEnoughCandles(int loadedCandleCount)
/*     */   {
/* 371 */     return loadedCandleCount == getDesiredCandlesCount();
/*     */   }
/*     */   
/*     */   private double getVolume(TickData tickData, OfferSide offerSide) {
/* 375 */     if (OfferSide.ASK.equals(offerSide)) {
/* 376 */       return tickData.getAskVolume();
/*     */     }
/*     */     
/* 379 */     return tickData.getBidVolume();
/*     */   }
/*     */   
/*     */   private double getPrice(TickData tickData, OfferSide offerSide)
/*     */   {
/* 384 */     if (OfferSide.ASK.equals(offerSide)) {
/* 385 */       return tickData.getAsk();
/*     */     }
/*     */     
/* 388 */     return tickData.getBid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDesiredCandlesCount()
/*     */   {
/* 397 */     return this.desiredCandlesCount;
/*     */   }
/*     */   
/*     */   public boolean allDesiredDataLoaded() {
/* 401 */     return getLoadedCandleCount() == getDesiredCandlesCount();
/*     */   }
/*     */   
/*     */   public Long getFirstTime() {
/* 405 */     return this.firstTime;
/*     */   }
/*     */   
/*     */   public Long getLastTime() {
/* 409 */     return this.lastTime;
/*     */   }
/*     */   
/*     */   public int getLoadedCandleCount() {
/* 413 */     return this.loadedCandlesCount;
/*     */   }
/*     */   
/*     */   public boolean getInverseOrder() {
/* 417 */     return this.inverseOrder;
/*     */   }
/*     */   
/*     */   public CandleData[] getResult() {
/* 421 */     return this.result;
/*     */   }
/*     */   
/*     */   protected int getLastElementIndex()
/*     */   {
/* 426 */     return this.lastElementIndex;
/*     */   }
/*     */   
/*     */   protected void setLastElementIndex(int lastElementIndex) {
/* 430 */     this.lastElementIndex = lastElementIndex;
/*     */   }
/*     */   
/*     */   protected Filter getFilter() {
/* 434 */     return this.filter;
/*     */   }
/*     */   
/*     */   protected Long getDesiredFirstDataTime() {
/* 438 */     return this.desiredFirstDataTime;
/*     */   }
/*     */   
/*     */   protected Double getFirstDataValue() {
/* 442 */     return this.firstDataValue;
/*     */   }
/*     */   
/*     */   private double round(double value) {
/* 446 */     return StratUtils.round(value, 6);
/*     */   }
/*     */   
/*     */   public CandleData getLastData() {
/* 450 */     if ((getResult() != null) && (getLastElementIndex() > -1) && (getLastElementIndex() < getResult().length))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 455 */       return getResult()[getLastElementIndex()];
/*     */     }
/* 457 */     return null;
/*     */   }
/*     */   
/*     */   public CandleData getCurrentCandleDataUnderAnalysis() {
/* 461 */     return this.currentCandleDataUnderAnalysis;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customperiod\tick\CustomPeriodFromTicksCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */