package com.dukascopy.charts.data.datacache.core.connection;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public abstract interface ICacheWriteConnection
  extends ICacheReadConnection
{
  public abstract FileOutputStream getFileOutputStream()
    throws FileNotFoundException;
  
  public abstract FileWriter getFileWriter()
    throws IOException;
  
  public abstract boolean mkdirs();
  
  public abstract boolean renameFrom(File paramFile)
    throws IOException;
  
  public abstract void createFile()
    throws IOException;
  
  public abstract void deleteFile()
    throws IOException;
  
  public abstract void ensureFileCreated()
    throws IOException;
  
  public abstract void write(int paramInt)
    throws IOException;
  
  public abstract void write(byte[] paramArrayOfByte)
    throws IOException;
  
  public abstract void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
  
  public abstract void writeBoolean(boolean paramBoolean)
    throws IOException;
  
  public abstract void writeByte(int paramInt)
    throws IOException;
  
  public abstract void writeShort(int paramInt)
    throws IOException;
  
  public abstract void writeChar(int paramInt)
    throws IOException;
  
  public abstract void writeInt(int paramInt)
    throws IOException;
  
  public abstract void writeLong(long paramLong)
    throws IOException;
  
  public abstract void writeFloat(float paramFloat)
    throws IOException;
  
  public abstract void writeDouble(double paramDouble)
    throws IOException;
  
  public abstract void writeBytes(String paramString)
    throws IOException;
  
  public abstract void writeChars(String paramString)
    throws IOException;
  
  public abstract void writeUTF(String paramString)
    throws IOException;
  
  public abstract void setLength(int paramInt)
    throws IOException;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\connection\ICacheWriteConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */