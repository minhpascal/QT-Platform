/*     */ package com.dukascopy.charts.data.datacache.change;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.feed.FeedDescriptor;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.CacheManager;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.ICurvesProtocolHandler;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.LoadingProgressAdapter;
/*     */ import com.dukascopy.charts.data.datacache.LocalCacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PADataChangeAction;
/*     */ import com.dukascopy.charts.data.datacache.time.ITimeManager;
/*     */ import com.dukascopy.dds2.greed.util.IFilePathManager;
/*     */ import com.dukascopy.dds3.transport.msg.dfs.DFHistoryChangedMessage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import java.util.Vector;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheChangeTracker
/*     */   implements ICacheChangeTracker
/*     */ {
/*  55 */   private static final Logger LOGGER = LoggerFactory.getLogger(CacheChangeTracker.class);
/*     */   
/*  57 */   private static final Calendar CALENDAR = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*     */   
/*  59 */   private Pattern tickFilePattern = Pattern.compile("\\d\\dh_ticks");
/*  60 */   private Pattern minuteFilePattern = Pattern.compile("(ASK)|(BID)_candles_min_1");
/*  61 */   private Pattern hourFilePattern = Pattern.compile("(ASK)|(BID)_candles_hour_1");
/*  62 */   private Pattern dayFilePattern = Pattern.compile("(ASK)|(BID)_candles_day_1");
/*     */   
/*     */ 
/*  65 */   private final AtomicBoolean scheduled = new AtomicBoolean(false);
/*  66 */   private boolean canContinue = true;
/*     */   
/*     */   private Thread worker;
/*     */   
/*     */   private final IFilePathManager filePathManager;
/*     */   private final LocalCacheManager localCacheManager;
/*     */   private final IPACacheManager paCacheManager;
/*     */   private final ITimeManager timeManager;
/*     */   private final ICurvesProtocolHandler serverProtocolHandler;
/*  75 */   public static Comparator<long[]> fromToComparator = new Comparator()
/*     */   {
/*     */     public int compare(long[] o1, long[] o2) {
/*  78 */       if (o1[0] < o2[0]) {
/*  79 */         return -1;
/*     */       }
/*  81 */       if (o1[0] > o2[0]) {
/*  82 */         return 1;
/*     */       }
/*  84 */       return 0;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*  89 */   private final List<ICacheChangeListener> cacheChangeListeners = new Vector();
/*     */   
/*  91 */   private final Set<DFSCacheChangeItem> dfsCacheChanges = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheChangeTracker(IFilePathManager filePathManager, LocalCacheManager localCacheManager, IPACacheManager paCacheManager, ITimeManager timeManager, ICurvesProtocolHandler serverProtocolHandler)
/*     */   {
/* 101 */     this.filePathManager = filePathManager;
/* 102 */     this.localCacheManager = localCacheManager;
/* 103 */     this.paCacheManager = paCacheManager;
/* 104 */     this.timeManager = timeManager;
/* 105 */     this.serverProtocolHandler = serverProtocolHandler;
/*     */     
/* 107 */     finalizeSetup();
/*     */   }
/*     */   
/*     */   public void checkCacheChange() throws DataCacheException, TimeoutException, IOException
/*     */   {
/* 112 */     LOGGER.info("Checking cache change...");
/*     */     
/* 114 */     long lastCacheChangePerformTime = this.localCacheManager.readLastCacheChangePerformTime();
/* 115 */     ensureMetadataIsLoadedToLocalCache(lastCacheChangePerformTime);
/*     */     
/* 117 */     CacheChangeCommit cacheChangeCommit = performCacheChange(lastCacheChangePerformTime);
/* 118 */     if (cacheChangeCommit.isSuccessfull()) {
/* 119 */       LOGGER.info("Recording the last cache checking change " + cacheChangeCommit);
/* 120 */       this.localCacheManager.saveLastCacheChangePerformTime(cacheChangeCommit.getLastPerformedTime());
/*     */     }
/*     */     else {
/* 123 */       LOGGER.warn("The last cache checking was not successfull " + cacheChangeCommit);
/*     */     }
/*     */     
/* 126 */     Set<Instrument> instruments = toFinancialInstruments(cacheChangeCommit.getUniqueInstrumentFolderNames());
/* 127 */     fireCacheChanged(instruments);
/*     */   }
/*     */   
/*     */   private Set<Instrument> toFinancialInstruments(Set<String> cacheDeletedForUniqueInstrumentFolderNames) {
/* 131 */     Set<Instrument> instruments = new HashSet();
/* 132 */     if ((cacheDeletedForUniqueInstrumentFolderNames != null) && (!cacheDeletedForUniqueInstrumentFolderNames.isEmpty())) {
/* 133 */       for (String cacheFolderName : cacheDeletedForUniqueInstrumentFolderNames) {
/* 134 */         Instrument fi = DataCacheUtils.getInstrumentByCacheInstrumentFolderName(cacheFolderName);
/* 135 */         if (fi != null) {
/* 136 */           instruments.add(fi);
/*     */         }
/*     */       }
/*     */     }
/* 140 */     return instruments;
/*     */   }
/*     */   
/*     */   private CacheChangeCommit performCacheChange(long previousPerformTime) throws TimeoutException, IOException, DataCacheException {
/* 144 */     int fileNumber = 0;
/* 145 */     boolean canContinue = false;
/* 146 */     boolean successfullClean = true;
/*     */     
/* 148 */     long lastPerformTime = previousPerformTime;
/*     */     
/* 150 */     Set<String> cacheDeletedForUniqueInstrumentFolderNames = new HashSet();
/*     */     
/* 152 */     File cacheFolder = new File(this.filePathManager.getCacheDirectory());
/* 153 */     if (!cacheFolder.exists()) {
/* 154 */       LOGGER.warn("Cache folder doesn't exist " + cacheFolder);
/* 155 */       return new CacheChangeCommit(true);
/*     */     }
/*     */     
/* 158 */     List<CacheChangeItem> changedDayItems = new ArrayList();
/*     */     do
/*     */     {
/* 161 */       Set<CacheChangeDescriptor> ccdFromCache = this.localCacheManager.readCacheChangeDescriptionFile(fileNumber);
/* 162 */       if (ccdFromCache != null) {
/* 163 */         for (CacheChangeDescriptor ccd : ccdFromCache) {
/* 164 */           if (ccd.getChangeFileCreationTime() > previousPerformTime)
/*     */           {
/*     */ 
/*     */ 
/* 168 */             if (lastPerformTime < ccd.getChangeFileCreationTime()) {
/* 169 */               lastPerformTime = ccd.getChangeFileCreationTime();
/*     */             }
/*     */             
/* 172 */             Set<CacheChangeItem> cacheFiles = this.localCacheManager.readCacheChangeFile(ccd.getChangeFileRelativePath());
/* 173 */             for (CacheChangeItem change : cacheFiles) {
/* 174 */               String cacheFilePath = cacheFolder.getAbsolutePath() + File.separatorChar + change.getRelativePathToFile();
/* 175 */               cacheFilePath = cacheFilePath.replaceAll("/", Matcher.quoteReplacement(File.separator));
/*     */               
/* 177 */               changedDayItems.add(change);
/*     */               
/* 179 */               File cacheFile = new File(cacheFilePath);
/* 180 */               if (cacheFile.exists()) {
/*     */                 try {
/* 182 */                   LOGGER.info("Deleting changed cache file " + cacheFile);
/* 183 */                   CacheManager.deleteFile(cacheFile);
/* 184 */                   cacheDeletedForUniqueInstrumentFolderNames.add(change.getInstrumentFolderName());
/*     */                 } catch (IOException|TimeoutException e) {
/* 186 */                   successfullClean = false;
/* 187 */                   LOGGER.error("Failed to delete cache file " + cacheFile, e);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/* 194 */         canContinue = false;
/*     */       }
/*     */       
/* 197 */       fileNumber++;
/* 198 */     } while (canContinue);
/*     */     
/* 200 */     if (!changedDayItems.isEmpty()) {
/* 201 */       analysePACache(changedDayItems);
/*     */     }
/*     */     
/* 204 */     return new CacheChangeCommit(successfullClean, cacheDeletedForUniqueInstrumentFolderNames, lastPerformTime);
/*     */   }
/*     */   
/*     */   private void analysePACache(List<CacheChangeItem> changedItems) throws DataCacheException
/*     */   {
/* 209 */     Map<IFeedDescriptor, List<long[]>> rawChangeMap = new HashMap();
/*     */     
/*     */ 
/*     */ 
/* 213 */     for (CacheChangeItem item : changedItems)
/*     */     {
/*     */ 
/* 216 */       Period period = null;
/* 217 */       long changeTime = item.getChunkStart();
/* 218 */       OfferSide offerSide = null;
/*     */       
/*     */ 
/* 221 */       Path relativePath = Paths.get(item.getRelativePathToFile(), new String[0]);
/* 222 */       String fileName = relativePath.getFileName().toString();
/*     */       
/* 224 */       Instrument instrument = DataCacheUtils.getInstrumentByCacheInstrumentFolderName(item.getInstrumentFolderName());
/* 225 */       DataCacheUtils.getInstrumentByCacheInstrumentFolderName(item.getInstrumentFolderName());
/* 226 */       if (instrument != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 231 */         if (this.tickFilePattern.matcher(fileName).find()) {
/* 232 */           period = Period.TICK;
/*     */         }
/* 234 */         else if (this.minuteFilePattern.matcher(fileName).find()) {
/* 235 */           period = Period.ONE_MIN;
/*     */         }
/* 237 */         else if (this.hourFilePattern.matcher(fileName).find()) {
/* 238 */           period = Period.ONE_HOUR;
/*     */         } else {
/* 240 */           if (!this.dayFilePattern.matcher(fileName).find()) continue;
/* 241 */           period = Period.DAILY;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 247 */         if (fileName.contains(OfferSide.ASK.name())) {
/* 248 */           offerSide = OfferSide.ASK;
/*     */         }
/* 250 */         else if (fileName.contains(OfferSide.BID.name())) {
/* 251 */           offerSide = OfferSide.BID;
/*     */         }
/*     */         
/* 254 */         IFeedDescriptor rawDescriptor = new FeedDescriptor();
/* 255 */         rawDescriptor.setInstrument(instrument);
/* 256 */         rawDescriptor.setOfferSide(offerSide);
/* 257 */         rawDescriptor.setPeriod(period);
/*     */         
/* 259 */         addCacheFeedDescriptorToRawChangeMap(rawDescriptor, changeTime, rawChangeMap);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 265 */     rawChangeMap = mergeIntervals(rawChangeMap);
/*     */     
/*     */ 
/* 268 */     adjustEndTimes(rawChangeMap);
/*     */     
/* 270 */     roundToCacheDayStartTimes(rawChangeMap);
/*     */     
/*     */ 
/* 273 */     for (Iterator i$ = rawChangeMap.entrySet().iterator(); i$.hasNext();) { entry = (Map.Entry)i$.next();
/*     */       
/* 275 */       List<long[]> intervals = (List)entry.getValue();
/* 276 */       for (long[] interval : intervals) {
/* 277 */         long from = interval[0];
/* 278 */         long to = interval[1];
/*     */         
/* 280 */         ILoadingProgressListener progressListener = new LoadingProgressAdapter()
/*     */         {
/*     */           public boolean stopJob() {
/* 283 */             return !CacheChangeTracker.this.canContinue;
/*     */           }
/*     */           
/* 286 */         };
/* 287 */         PADataChangeAction paChangeAction = new PADataChangeAction(this.paCacheManager, (IFeedDescriptor)entry.getKey(), from, to, progressListener);
/* 288 */         paChangeAction.run();
/*     */       }
/*     */     }
/*     */     Map.Entry<IFeedDescriptor, List<long[]>> entry;
/*     */   }
/*     */   
/*     */   private void roundToCacheDayStartTimes(Map<IFeedDescriptor, List<long[]>> rawChangeMap)
/*     */   {
/* 296 */     for (Map.Entry<IFeedDescriptor, List<long[]>> entry : rawChangeMap.entrySet()) {
/* 297 */       List<long[]> intervals = (List)entry.getValue();
/* 298 */       for (long[] interval : intervals) {
/* 299 */         interval[0] = DataCacheUtils.getPACacheFileStartTime(interval[0]);
/* 300 */         interval[1] = DataCacheUtils.getPACacheFileStartTime(interval[1]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void adjustEndTimes(Map<IFeedDescriptor, List<long[]>> rawChangeMap)
/*     */   {
/* 308 */     for (Map.Entry<IFeedDescriptor, List<long[]>> entry : rawChangeMap.entrySet()) {
/* 309 */       List<long[]> intervals = (List)entry.getValue();
/* 310 */       long[] lastInterval = (long[])intervals.get(intervals.size() - 1);
/* 311 */       if (lastInterval[1] > this.paCacheManager.getLastPossibleCacheFileTime()) {
/* 312 */         lastInterval[1] = this.paCacheManager.getLastPossibleCacheFileTime();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static Map<IFeedDescriptor, List<long[]>> mergeIntervals(Map<IFeedDescriptor, List<long[]>> rawChangeMap)
/*     */   {
/* 319 */     Map<IFeedDescriptor, List<long[]>> resultMap = new HashMap();
/*     */     
/* 321 */     for (Map.Entry<IFeedDescriptor, List<long[]>> entry : rawChangeMap.entrySet()) {
/* 322 */       List<long[]> timeList = (List)entry.getValue();
/*     */       
/* 324 */       Collections.sort(timeList, fromToComparator);
/*     */       
/* 326 */       List<long[]> result = new ArrayList();
/*     */       
/* 328 */       long[] previousInterval = null;
/*     */       
/* 330 */       for (long[] interval : timeList) {
/* 331 */         if (previousInterval == null) {
/* 332 */           previousInterval = interval;
/*     */ 
/*     */ 
/*     */         }
/* 336 */         else if (((previousInterval[0] <= interval[0]) && (interval[1] <= previousInterval[1])) || ((previousInterval[0] <= interval[0]) && (previousInterval[1] >= interval[0])) || ((previousInterval[0] <= interval[1]) && (previousInterval[1] >= interval[1])) || ((previousInterval[0] >= interval[0]) && (interval[1] >= previousInterval[1])) || (previousInterval[1] + 1L == interval[0]))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 345 */           previousInterval[0] = Math.min(previousInterval[0], interval[0]);
/* 346 */           previousInterval[1] = Math.max(previousInterval[1], interval[1]);
/*     */         }
/*     */         else {
/* 349 */           result.add(previousInterval);
/* 350 */           previousInterval = interval;
/*     */         }
/*     */       }
/*     */       
/* 354 */       if (previousInterval != null) {
/* 355 */         result.add(previousInterval);
/*     */       }
/*     */       
/* 358 */       resultMap.put(entry.getKey(), result);
/*     */     }
/*     */     
/* 361 */     return resultMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addCacheFeedDescriptorToRawChangeMap(IFeedDescriptor rawDescriptor, long changeTime, Map<IFeedDescriptor, List<long[]>> rawChangeMap)
/*     */   {
/* 370 */     List<long[]> currentIntervalList = (List)rawChangeMap.get(rawDescriptor);
/*     */     
/* 372 */     if (currentIntervalList == null) {
/* 373 */       currentIntervalList = new ArrayList();
/* 374 */       rawChangeMap.put(rawDescriptor, currentIntervalList);
/*     */     }
/*     */     
/* 377 */     long rawCacheFrom = changeTime;
/* 378 */     long rawCacheTo = rawCacheFrom;
/*     */     
/* 380 */     if (Period.TICK.equals(rawDescriptor.getPeriod())) {
/* 381 */       rawCacheTo += Period.ONE_HOUR.getInterval() - 1L;
/*     */     }
/* 383 */     else if (Period.ONE_MIN.equals(rawDescriptor.getPeriod())) {
/* 384 */       rawCacheTo += Period.DAILY.getInterval() - 1L;
/*     */     }
/* 386 */     else if (Period.ONE_HOUR.equals(rawDescriptor.getPeriod())) {
/* 387 */       rawCacheTo = DataCacheUtils.getNextCandleStartFast(Period.MONTHLY, rawCacheFrom) - 1L;
/*     */     }
/* 389 */     else if (Period.DAILY.equals(rawDescriptor.getPeriod())) {
/* 390 */       Calendar gmtCalendar = DataCacheUtils.getGMTCalendar();
/*     */       
/* 392 */       gmtCalendar.setTimeInMillis(rawCacheFrom);
/* 393 */       gmtCalendar.add(1, 1);
/*     */       
/* 395 */       rawCacheTo = gmtCalendar.getTimeInMillis() - 1L;
/*     */     }
/*     */     
/* 398 */     currentIntervalList.add(new long[] { rawCacheFrom, rawCacheTo });
/*     */   }
/*     */   
/*     */   private void ensureMetadataIsLoadedToLocalCache(long lastCacheChangePerformTime) throws DataCacheException, TimeoutException, IOException
/*     */   {
/* 403 */     int fileNumber = 0;
/* 404 */     boolean canContinue = false;
/*     */     do
/*     */     {
/* 407 */       Set<CacheChangeDescriptor> ccdFromCFG = this.serverProtocolHandler.loadCacheChangeDescriptionFileFromCFG(fileNumber);
/* 408 */       if (ccdFromCFG != null)
/*     */       {
/* 410 */         LOGGER.info("ccd file is loaded from CFG " + ccdFromCFG);
/* 411 */         canContinue = true;
/*     */         
/* 413 */         Set<CacheChangeDescriptor> ccdFromLocalCache = this.localCacheManager.readCacheChangeDescriptionFile(fileNumber);
/* 414 */         if (ccdFromLocalCache != null) {
/* 415 */           if (!ccdFromCFG.equals(ccdFromLocalCache)) {
/* 416 */             this.localCacheManager.deleteCacheChangeDescriptionFile(fileNumber);
/* 417 */             this.localCacheManager.saveCacheChangeDescriptionFile(ccdFromCFG, fileNumber);
/*     */             
/* 419 */             LOGGER.info("ccd file is saved to local cache " + ccdFromCFG);
/*     */           }
/*     */         }
/*     */         else {
/* 423 */           this.localCacheManager.saveCacheChangeDescriptionFile(ccdFromCFG, fileNumber);
/*     */         }
/*     */         
/* 426 */         checkAndLoadCacheChanges(ccdFromCFG, lastCacheChangePerformTime);
/*     */       }
/*     */       else {
/* 429 */         canContinue = false;
/*     */       }
/*     */       
/* 432 */       fileNumber++;
/* 433 */     } while (canContinue);
/*     */   }
/*     */   
/*     */   private void checkAndLoadCacheChanges(Set<CacheChangeDescriptor> ccds, long lastCacheChangePerformTime) throws DataCacheException, TimeoutException, IOException {
/* 437 */     for (CacheChangeDescriptor ccd : ccds) {
/* 438 */       if ((ccd.getChangeFileCreationTime() > lastCacheChangePerformTime) && 
/* 439 */         (!this.localCacheManager.isCacheChangeFileExist(ccd.getChangeFileRelativePath()))) {
/* 440 */         Set<CacheChangeItem> changedFiles = this.serverProtocolHandler.loadCacheChangeFileFromCFG(ccd.getChangeFileRelativePath());
/* 441 */         if ((changedFiles != null) && (!changedFiles.isEmpty())) {
/* 442 */           this.localCacheManager.saveCacheChangeFile(ccd.getChangeFileRelativePath(), changedFiles);
/* 443 */           LOGGER.info("cc file is saved to local cache " + changedFiles);
/*     */         }
/*     */         else {
/* 446 */           LOGGER.warn("Cache file " + ccd.getChangeFileRelativePath() + " is empty");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void finalizeSetup()
/*     */   {
/* 454 */     if (this.scheduled.compareAndSet(false, true)) {
/* 455 */       Runnable task = new Runnable()
/*     */       {
/*     */         public void run() {
/*     */           try {
/* 459 */             Thread.sleep(TimeUnit.MINUTES.toMillis(1L));
/*     */           }
/*     */           catch (InterruptedException e) {}
/*     */           
/* 463 */           while (CacheChangeTracker.this.canContinue) {
/*     */             try {
/* 465 */               CacheChangeTracker.this.checkCacheChange();
/*     */             } catch (Throwable e) {
/* 467 */               CacheChangeTracker.LOGGER.error("Failed to check cache changes ", e);
/*     */             }
/*     */             try
/*     */             {
/* 471 */               long timeToRun = CacheChangeTracker.this.calculateTimeToRun();
/* 472 */               while (timeToRun > CacheChangeTracker.this.getCurrentTime()) {
/* 473 */                 Thread.sleep(timeToRun - CacheChangeTracker.this.getCurrentTime());
/*     */               }
/*     */               
/*     */             }
/*     */             catch (Throwable e) {}
/*     */           }
/*     */         }
/* 480 */       };
/* 481 */       this.worker = new Thread(task, getClass().getSimpleName());
/* 482 */       this.worker.setDaemon(true);
/* 483 */       this.worker.start();
/*     */       
/* 485 */       LOGGER.info("Started");
/*     */     }
/*     */   }
/*     */   
/*     */   private long calculateTimeToRun() {
/* 490 */     long currentTime = getCurrentTime();
/*     */     
/* 492 */     CALENDAR.setTimeInMillis(currentTime);
/*     */     
/* 494 */     CALENDAR.set(14, 0);
/* 495 */     CALENDAR.set(13, 0);
/* 496 */     CALENDAR.set(12, 1);
/* 497 */     CALENDAR.set(10, 0);
/*     */     
/* 499 */     long timeToRun = CALENDAR.getTimeInMillis();
/*     */     
/* 501 */     while (timeToRun <= currentTime) {
/* 502 */       CALENDAR.add(7, 1);
/* 503 */       timeToRun = CALENDAR.getTimeInMillis();
/*     */     }
/*     */     
/* 506 */     return timeToRun;
/*     */   }
/*     */   
/*     */   private long getCurrentTime() {
/* 510 */     Long serverTime = this.timeManager.getServerTime();
/* 511 */     long currentTime = serverTime != null ? serverTime.longValue() : System.currentTimeMillis();
/* 512 */     return currentTime;
/*     */   }
/*     */   
/*     */   private void fireCacheChanged(Set<Instrument> instruments) {
/* 516 */     if ((instruments == null) || (instruments.isEmpty())) {
/* 517 */       return;
/*     */     }
/*     */     
/* 520 */     List<ICacheChangeListener> listeners = getCacheChangeListeners();
/* 521 */     for (ICacheChangeListener l : listeners) {
/* 522 */       l.cacheChanged(instruments);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addCacheChangeListener(ICacheChangeListener cacheChangeListener)
/*     */   {
/* 528 */     this.cacheChangeListeners.add(cacheChangeListener);
/*     */   }
/*     */   
/*     */   public void removeCacheChangeListener(ICacheChangeListener cacheChangeListener)
/*     */   {
/* 533 */     this.cacheChangeListeners.remove(cacheChangeListener);
/*     */   }
/*     */   
/*     */   public List<ICacheChangeListener> getCacheChangeListeners()
/*     */   {
/* 538 */     return new ArrayList(this.cacheChangeListeners);
/*     */   }
/*     */   
/*     */   public void shutdown()
/*     */   {
/* 543 */     this.canContinue = false;
/* 544 */     if (this.worker != null) {
/* 545 */       this.worker.interrupt();
/*     */     }
/*     */   }
/*     */   
/*     */   private Period getPeriodFromInterval(long interval)
/*     */   {
/* 551 */     if (interval <= 0L) {
/* 552 */       return Period.TICK;
/*     */     }
/*     */     
/* 555 */     for (Period period : Period.valuesForIndicator()) {
/* 556 */       if (period.getInterval() == interval) {
/* 557 */         return period;
/*     */       }
/*     */     }
/*     */     
/* 561 */     return null;
/*     */   }
/*     */   
/*     */   public void handleDFHistoryChangedMessage(DFHistoryChangedMessage message) {
/* 565 */     Instrument instrument = Instrument.fromString(message.getInstrument());
/* 566 */     Period period = getPeriodFromInterval(message.getPeriod().longValue());
/* 567 */     if ((instrument != null) && (period != null) && (message.getChangedFrom() != null) && (message.getChangedTo() != null) && (message.getChangedFrom().longValue() <= message.getChangedTo().longValue()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 574 */       DFSCacheChangeItem dfsCacheChangeItem = new DFSCacheChangeItem(instrument, period, message.getChangedFrom().longValue(), message.getChangedTo().longValue());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 581 */       synchronized (this.dfsCacheChanges)
/*     */       {
/* 583 */         if (this.dfsCacheChanges.isEmpty()) {
/* 584 */           Runnable task = new Runnable()
/*     */           {
/*     */             public void run() {
/*     */               try {
/* 588 */                 Thread.sleep(TimeUnit.MINUTES.toMillis(1L));
/*     */               }
/*     */               catch (InterruptedException e) {}
/*     */               
/* 592 */               Set<DFSCacheChangeItem> dfsCacheChangeItems = new HashSet();
/* 593 */               synchronized (CacheChangeTracker.this.dfsCacheChanges) {
/* 594 */                 dfsCacheChangeItems.addAll(CacheChangeTracker.this.dfsCacheChanges);
/* 595 */                 CacheChangeTracker.this.dfsCacheChanges.clear();
/*     */               }
/*     */               try
/*     */               {
/* 599 */                 CacheChangeTracker.this.processDFSCacheChangeItems(dfsCacheChangeItems);
/*     */               } catch (DataCacheException e) {
/* 601 */                 CacheChangeTracker.LOGGER.error(e.getMessage(), e);
/*     */               }
/*     */             }
/* 604 */           };
/* 605 */           new Thread(task).start();
/*     */         }
/*     */         
/* 608 */         this.dfsCacheChanges.add(dfsCacheChangeItem);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void processDFSCacheChangeItems(Set<DFSCacheChangeItem> dfsCacheChangeItems) throws DataCacheException {
/* 614 */     Set<Instrument> uniqueInstruments = new HashSet();
/*     */     
/* 616 */     List<CacheChangeItem> changedDayItems = new ArrayList();
/*     */     
/* 618 */     for (DFSCacheChangeItem changeItem : dfsCacheChangeItems)
/*     */     {
/* 620 */       for (long chunkStart = DataCacheUtils.getChunkStart(changeItem.getPeriod(), changeItem.getFrom()); 
/* 621 */           chunkStart <= changeItem.getTo(); 
/* 622 */           chunkStart = DataCacheUtils.getNextChunkStart(changeItem.getPeriod(), chunkStart))
/*     */       {
/* 624 */         for (OfferSide side : OfferSide.values()) {
/*     */           try {
/* 626 */             File[] cacheFiles = new File[2];
/*     */             
/* 628 */             cacheFiles[0] = this.localCacheManager.getIntraPeriodFile(changeItem.getInstrument(), changeItem.getPeriod(), side, chunkStart);
/* 629 */             cacheFiles[1] = this.localCacheManager.getChunkFile(changeItem.getInstrument(), changeItem.getPeriod(), side, chunkStart);
/*     */             
/* 631 */             for (File cacheFile : cacheFiles) {
/* 632 */               changedDayItems.add(new CacheChangeItem(DataCacheUtils.getCfgInstrumentFolderName(changeItem.getInstrument()), changeItem.getPeriod().toString(), cacheFile.toString(), DataCacheUtils.getPACacheFileStartTime(chunkStart)));
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 639 */               if ((cacheFile != null) && (cacheFile.exists())) {
/*     */                 try {
/* 641 */                   LOGGER.info("Deleting changed cache file " + cacheFile);
/* 642 */                   LocalCacheManager.deleteFile(cacheFile);
/* 643 */                   uniqueInstruments.add(changeItem.getInstrument());
/*     */ 
/*     */ 
/*     */                 }
/*     */                 catch (IOException|TimeoutException e)
/*     */                 {
/*     */ 
/* 650 */                   LOGGER.error("Failed to delete cache file " + cacheFile, e);
/*     */                 }
/*     */               }
/*     */             }
/*     */           } catch (Exception e1) {
/* 655 */             LOGGER.error("Cache change error for " + changeItem.getInstrument() + ", " + changeItem.getPeriod() + ", " + side + ", " + DateUtils.format(chunkStart), e1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 661 */     if (!changedDayItems.isEmpty()) {
/* 662 */       analysePACache(changedDayItems);
/*     */     }
/*     */     
/* 665 */     if (!dfsCacheChangeItems.isEmpty()) {
/* 666 */       fireCacheChanged(uniqueInstruments);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\change\CacheChangeTracker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */