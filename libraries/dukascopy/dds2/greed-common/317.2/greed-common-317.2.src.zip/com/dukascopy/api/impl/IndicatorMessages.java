/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.indicators.IndicatorResult;
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IndicatorMessages
/*    */ {
/*    */   public static String getCachedIndicatorErrorMsg(String indicatorName)
/*    */   {
/* 17 */     return MessageFormat.format("Error while getting cached indicator: {0}", new Object[] { indicatorName });
/*    */   }
/*    */   
/*    */   public static String getIndicatorNotFoundMsg(String indicatorName) {
/* 21 */     return MessageFormat.format("Indicator with name {0} was not found", new Object[] { indicatorName });
/*    */   }
/*    */   
/*    */   public static String getNotEnoughDataMsg(String indicatorName) {
/* 25 */     return MessageFormat.format("There is not enough data to calculate values for {0}", new Object[] { indicatorName });
/*    */   }
/*    */   
/*    */   public static String getIndicatorErrorMsg(String error) {
/* 29 */     return MessageFormat.format("Error in indicator: {0}", new Object[] { error });
/*    */   }
/*    */   
/*    */   public static String getLackOfValuesMsg(String indicatorName) {
/* 33 */     String pattern = "calculate() method of indicator [{0}] returned less values than expected";
/*    */     
/* 35 */     return MessageFormat.format(pattern, new Object[] { indicatorName });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getLackOfValuesMsg(String indicatorName, IndicatorResult indicatorResult, int inputSize, int lookback, int lookforward)
/*    */   {
/* 45 */     String pattern = getLackOfValuesMsg(indicatorName) + ". Requested from-to [0]-[{0}], input array size [{1}], returned first calculated index [{2}], number of calculated values [{3}], " + "lookback [{4}], lookforward [{5}], expected number of elements is [{6}]";
/*    */     
/*    */ 
/*    */ 
/* 49 */     return MessageFormat.format(pattern, new Object[] { Integer.valueOf(inputSize - 1), Integer.valueOf(inputSize), Integer.valueOf(indicatorResult.getFirstValueIndex()), Integer.valueOf(indicatorResult.getNumberOfElements()), Integer.valueOf(lookback), Integer.valueOf(lookforward), Integer.valueOf(inputSize - lookback - lookforward) });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getIncorrectValuesMsg(String indicatorName, IndicatorResult indicatorResult, int inputSize, int lookback, int lookforward)
/*    */   {
/* 60 */     String pattern = "calculate() method of indicator [{0}] returned incorrect values. Requested from-to [0]-[{1}],  input array size [{2}], returned first calculated index [{3}], number of calculated values [{4}], lookback [{5}], lookforward [{6}], first index + number of elements cannot be > input array size";
/*    */     
/*    */ 
/*    */ 
/* 64 */     return MessageFormat.format(pattern, new Object[] { indicatorName, Integer.valueOf(inputSize - 1), Integer.valueOf(inputSize), Integer.valueOf(indicatorResult.getFirstValueIndex()), Integer.valueOf(indicatorResult.getNumberOfElements()), Integer.valueOf(lookback), Integer.valueOf(lookforward) });
/*    */   }
/*    */   
/*    */   public static String getIndexNotSetMsg(String indicatorName)
/*    */   {
/* 69 */     String pattern = "calculate() method of indicator [{0}] returned result without lastValueIndex set. This is only allowed when lookforward is equals to zero";
/*    */     
/* 71 */     return MessageFormat.format(pattern, new Object[] { indicatorName });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getIncorrectIndexesMsg(String indicatorName, IndicatorResult indicatorResult, int inputSize, int lookback, int lookforward)
/*    */   {
/* 81 */     String pattern = "calculate() method of indicator [{0}] returned incorrect first value and last value indexes. Requested from-to [0]-[{1}], input array size [{2}], returned first calculated index [{3}], number of calculated values [{4}], last calculated index (set to max index by default) [{5}], lookback [{6}], lookforward [{7}]";
/*    */     
/*    */ 
/*    */ 
/* 85 */     return MessageFormat.format(pattern, new Object[] { indicatorName, Integer.valueOf(inputSize - 1), Integer.valueOf(inputSize), Integer.valueOf(indicatorResult.getFirstValueIndex()), Integer.valueOf(indicatorResult.getNumberOfElements()), Integer.valueOf(indicatorResult.getLastValueIndex()), Integer.valueOf(lookback), Integer.valueOf(lookforward) });
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\IndicatorMessages.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */