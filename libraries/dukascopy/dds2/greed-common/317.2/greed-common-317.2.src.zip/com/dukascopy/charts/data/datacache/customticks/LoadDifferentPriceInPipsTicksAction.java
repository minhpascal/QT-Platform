/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadDifferentPriceInPipsTicksAction
/*    */   extends AbstractLoadCustomTicksFromTicksAction
/*    */ {
/*    */   private final TickFeedListener feedListener;
/*    */   private final long priceDifferenceInPips;
/*    */   private TickData previousTick;
/*    */   
/*    */   public LoadDifferentPriceInPipsTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to, long priceDifferenceInPips, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 34 */     super(feedDataProvider, instrument, from, to, loadingProgressListener);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 41 */     this.priceDifferenceInPips = priceDifferenceInPips;
/* 42 */     this.feedListener = feedListener;
/*    */   }
/*    */   
/*    */   private void tickReceived(TickData tick) {
/* 46 */     if (this.previousTick == null) {
/* 47 */       this.previousTick = tick;
/* 48 */       this.feedListener.newTick(this.instrument, tick.time, tick.ask, tick.bid, tick.askVol, tick.bidVol);
/*    */     }
/*    */     else {
/* 51 */       double priceDifference = Math.abs(this.previousTick.getAsk() - tick.getAsk());
/* 52 */       double currentPriceDifferenceInPips = StratUtils.roundHalfEven(priceDifference / this.instrument.getPipValue(), 1);
/* 53 */       if (currentPriceDifferenceInPips >= this.priceDifferenceInPips) {
/* 54 */         this.feedListener.newTick(this.instrument, tick.time, tick.ask, tick.bid, tick.askVol, tick.bidVol);
/* 55 */         this.previousTick = tick;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected void tickReceived(long time, double ask, double bid, double askVol, double bidVol)
/*    */   {
/* 62 */     tickReceived(new TickData(time, ask, bid, askVol, bidVol));
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadDifferentPriceInPipsTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */