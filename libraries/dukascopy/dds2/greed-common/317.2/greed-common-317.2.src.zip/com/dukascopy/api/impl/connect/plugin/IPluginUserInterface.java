package com.dukascopy.api.impl.connect.plugin;

import com.dukascopy.api.IUserInterface;
import javax.swing.JMenu;

public abstract interface IPluginUserInterface
  extends IUserInterface
{
  public abstract JMenu addMenu(String paramString);
  
  public abstract void removeMenu(JMenu paramJMenu);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\plugin\IPluginUserInterface.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */