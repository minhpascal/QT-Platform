/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.beforetimeafter;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoCreator;
/*     */ import com.dukascopy.charts.data.datacache.nisonrenko.IRenkoLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.nisonrenko.RenkoData;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadClosestRenkoAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadToCacheRenkoAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PANthRenkoFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PALoadByTimeIntervalRenkoAction;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PALoadNumberOfBarsBeforeAfterTimeRenkoAction
/*     */   extends PAAbstractLoadNumOfBarsBeforeAfterTimeAction<RenkoData, IRenkoLiveFeedListener, IRenkoCreator, PALoadToCacheRenkoAction, PALoadByTimeIntervalRenkoAction>
/*     */ {
/*     */   public PALoadNumberOfBarsBeforeAfterTimeRenkoAction(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int numOfBarsBefore, long time, int numOfBarsAfter, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, IRenkoLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  52 */     super(cacheManager, instrument, interpolationDescriptor, side, jfPeriod, numOfBarsBefore, time, numOfBarsAfter, fireUncompletedLastBasePeriodBars, infinitBasePeriod, version, listener, loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected IRenkoLiveFeedListener createOneBarListener(final List<RenkoData> oneBarList)
/*     */   {
/*  72 */     new IRenkoLiveFeedListener()
/*     */     {
/*     */       public void newPriceData(RenkoData data) {
/*  75 */         oneBarList.add(data);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   protected PALoadByTimeIntervalRenkoAction createLoadIntervalAction(long timeFrom, long timeTo, ILoadingProgressListener loadingProgressListener) throws DataCacheException
/*     */   {
/*  82 */     return new PALoadByTimeIntervalRenkoAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), timeFrom, timeTo, isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), (IRenkoLiveFeedListener)getListener(), loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PALoadClosestRenkoAction createLoadClosestAction(IRenkoLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 100 */     PALoadClosestRenkoAction action = new PALoadClosestRenkoAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), getTime(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), listener, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     return action;
/*     */   }
/*     */   
/*     */   protected PANthRenkoFromSeedBarAction createNthBarFromSeedAction(RenkoData timedBar, IRenkoLiveFeedListener oneBarListener, boolean lookLeft, ILoadingProgressListener loadingProgressListener)
/*     */   {
/* 118 */     PANthRenkoFromSeedBarAction action = new PANthRenkoFromSeedBarAction(getCacheManager(), getVersion(), getNumOfBarsBefore(), timedBar, getNumOfBarsAfter(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), lookLeft, loadingProgressListener, oneBarListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */     return action;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\beforetimeafter\PALoadNumberOfBarsBeforeAfterTimeRenkoAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */