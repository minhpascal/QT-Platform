/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.remotestorage.data.RemoteVersion;
/*    */ import com.dukascopy.charts.data.datacache.remotestorage.data.key.RemoteStorageKey;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JStoreRemoteStrategyWrapper
/*    */   extends StrategyWrapper
/*    */ {
/*    */   private RemoteVersion remoteVersion;
/*    */   private RemoteStorageKey remoteKey;
/*    */   
/*    */   public RemoteVersion getRemoteVersion()
/*    */   {
/* 19 */     return this.remoteVersion;
/*    */   }
/*    */   
/*    */   public void setRemoteVersion(RemoteVersion remoteVersion) {
/* 23 */     this.remoteVersion = remoteVersion;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 28 */     return this.remoteVersion.getName();
/*    */   }
/*    */   
/*    */   public RemoteStorageKey getRemoteKey() {
/* 32 */     return this.remoteKey;
/*    */   }
/*    */   
/*    */   public void setRemoteKey(RemoteStorageKey remoteKey) {
/* 36 */     this.remoteKey = remoteKey;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\JStoreRemoteStrategyWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */