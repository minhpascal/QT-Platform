/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Inverse
/*    */   extends LFunction
/*    */ {
/*    */   public Inverse()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.the.inverse.of.x";
/* 15 */     this.fshortcut = 'i';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 24 */     return 1.0D / x;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 33 */     return x.inverse();
/*    */   }
/*    */   
/*    */   public String shortName() {
/* 37 */     return "<i>x</i><sup>&#8722;1</sup>";
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 41 */     return fname;
/*    */   }
/*    */   
/* 44 */   private static final String[] fname = { "<sup>&#8722;</sup>", "<sup>1</sup>" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Inverse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */