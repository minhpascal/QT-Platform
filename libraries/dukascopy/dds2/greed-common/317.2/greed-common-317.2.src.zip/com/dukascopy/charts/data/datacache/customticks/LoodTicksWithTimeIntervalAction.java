/*    */ package com.dukascopy.charts.data.datacache.customticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoodTicksWithTimeIntervalAction
/*    */   extends AbstractLoadCustomTicksFromTicksAction
/*    */ {
/*    */   private final long timeIntervalBetweenTicks;
/*    */   private final TickFeedListener feedListener;
/*    */   private TickData previousTick;
/*    */   
/*    */   public LoodTicksWithTimeIntervalAction(IFeedDataProvider feedDataProvider, Instrument instrument, long from, long to, long timeIntervalBetweenTicks, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*    */   {
/* 33 */     super(feedDataProvider, instrument, from, to, loadingProgressListener);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 41 */     this.timeIntervalBetweenTicks = timeIntervalBetweenTicks;
/* 42 */     this.feedListener = feedListener;
/*    */   }
/*    */   
/*    */   private void tickReceived(TickData tick) {
/* 46 */     if (this.previousTick == null) {
/* 47 */       this.previousTick = tick;
/* 48 */       this.feedListener.newTick(this.instrument, tick.time, tick.ask, tick.bid, tick.askVol, tick.bidVol);
/*    */     }
/*    */     else {
/* 51 */       long timeDiff = tick.getTime() - this.previousTick.getTime();
/* 52 */       if (timeDiff >= this.timeIntervalBetweenTicks) {
/* 53 */         this.previousTick = tick;
/* 54 */         this.feedListener.newTick(this.instrument, tick.time, tick.ask, tick.bid, tick.askVol, tick.bidVol);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected void tickReceived(long time, double ask, double bid, double askVol, double bidVol)
/*    */   {
/* 61 */     tickReceived(new TickData(time, ask, bid, askVol, bidVol));
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoodTicksWithTimeIntervalAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */