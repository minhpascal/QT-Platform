/*    */ package com.dukascopy.api.impl.util;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ public class FileCache
/*    */ {
/*    */   private byte[] sourceCache;
/*    */   private byte[] compiledCache;
/*    */   private Date lastBinaryModifyTime;
/*    */   private Date lastSourceModifyTime;
/*    */   private String fileName;
/*    */   
/*    */   public byte[] getSourceCache()
/*    */   {
/* 16 */     return this.sourceCache;
/*    */   }
/*    */   
/*    */   public void setSourceCache(byte[] sourceCache) {
/* 20 */     this.sourceCache = sourceCache;
/*    */   }
/*    */   
/*    */   public byte[] getCompiledCache() {
/* 24 */     return this.compiledCache;
/*    */   }
/*    */   
/*    */   public void setCompiledCache(byte[] compiledCache) {
/* 28 */     this.compiledCache = compiledCache;
/*    */   }
/*    */   
/*    */   public Date getLastBinaryModifyTime() {
/* 32 */     return this.lastBinaryModifyTime;
/*    */   }
/*    */   
/*    */   public void setLastBinaryModifyTime(Date lastBinaryModifyTime) {
/* 36 */     this.lastBinaryModifyTime = lastBinaryModifyTime;
/*    */   }
/*    */   
/*    */   public Date getLastSourceModifyTime() {
/* 40 */     return this.lastSourceModifyTime;
/*    */   }
/*    */   
/*    */   public void setLastSourceModifyTime(Date lastSourceModifyTime) {
/* 44 */     this.lastSourceModifyTime = lastSourceModifyTime;
/*    */   }
/*    */   
/*    */   public String getFileName() {
/* 48 */     return this.fileName;
/*    */   }
/*    */   
/*    */   public void setFileName(String fileName) {
/* 52 */     this.fileName = fileName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\FileCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */