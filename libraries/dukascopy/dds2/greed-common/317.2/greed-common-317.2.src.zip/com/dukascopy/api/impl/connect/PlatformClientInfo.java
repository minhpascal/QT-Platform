/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IAccount;
/*     */ import com.dukascopy.api.IAccount.AccountState;
/*     */ import com.dukascopy.api.IClientInfo;
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.JFCurrency;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.EnumConverter;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.acc.ClientInfoMessage;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Currency;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformClientInfo
/*     */   implements IClientInfo
/*     */ {
/*     */   private String clientId;
/*     */   private double stopLossLevel;
/*     */   private double ratio;
/*     */   private ICurrency currency;
/*     */   private IAccount.AccountState clientState;
/*     */   
/*     */   public PlatformClientInfo(ClientInfoMessage clientInfoMessage)
/*     */   {
/*  38 */     updateFromMessage(clientInfoMessage);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateFromMessage(ClientInfoMessage clientInfoMessage)
/*     */   {
/*  46 */     if (clientInfoMessage == null) {
/*  47 */       throw new IllegalArgumentException("ClientInfoMessage is null");
/*     */     }
/*  49 */     this.clientId = clientInfoMessage.getClientId();
/*  50 */     this.ratio = (clientInfoMessage.getRatio() != null ? clientInfoMessage.getRatio().doubleValue() : 0.0D);
/*  51 */     BigDecimal lossLimit = clientInfoMessage.getLossLimit();
/*  52 */     String lossLimitCurrency = clientInfoMessage.getLossLimitCur();
/*  53 */     if ((lossLimit != null) && (!ObjectUtils.isNullOrEmpty(lossLimitCurrency))) {
/*  54 */       this.stopLossLevel = lossLimit.doubleValue();
/*  55 */       this.currency = JFCurrency.getInstance(lossLimitCurrency);
/*     */     }
/*  57 */     if (clientInfoMessage.getState() != null) {
/*  58 */       this.clientState = ((IAccount.AccountState)EnumConverter.convert(clientInfoMessage.getState(), IAccount.AccountState.class));
/*     */     }
/*     */   }
/*     */   
/*     */   public String getClientId()
/*     */   {
/*  64 */     return this.clientId;
/*     */   }
/*     */   
/*     */   public IAccount.AccountState getClientState()
/*     */   {
/*  69 */     return this.clientState;
/*     */   }
/*     */   
/*     */   public double getStopLossLevel()
/*     */   {
/*  74 */     return this.stopLossLevel;
/*     */   }
/*     */   
/*     */   public Currency getCurrency()
/*     */   {
/*  79 */     return this.currency.getJavaCurrency();
/*     */   }
/*     */   
/*     */   public ICurrency getAccountCurrency()
/*     */   {
/*  84 */     return this.currency;
/*     */   }
/*     */   
/*     */   public double getEquity()
/*     */   {
/*  89 */     if ((this.ratio > 0.0D) && (PlatformAccountImpl.getAccount() != null)) {
/*  90 */       double equity = this.ratio * PlatformAccountImpl.getAccount().getEquity();
/*  91 */       return StratUtils.round(equity, 2);
/*     */     }
/*  93 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */   public double getBaseEquity()
/*     */   {
/*  99 */     if ((this.ratio > 0.0D) && (PlatformAccountImpl.getAccount() != null)) {
/* 100 */       double baseEquity = this.ratio * PlatformAccountImpl.getAccount().getBaseEquity();
/* 101 */       return StratUtils.round(baseEquity, 2);
/*     */     }
/* 103 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public double getBalance()
/*     */   {
/* 108 */     if ((this.ratio > 0.0D) && (PlatformAccountImpl.getAccount() != null)) {
/* 109 */       double balance = this.ratio * PlatformAccountImpl.getAccount().getBalance();
/* 110 */       return StratUtils.round(balance, 2);
/*     */     }
/* 112 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public double getRatio()
/*     */   {
/* 117 */     return this.ratio;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 122 */     return String.format("Client ID = %s, State = %s, Equity = %.2f, Stop Loss Level = %.2f, Currency = %s", new Object[] { getClientId(), getClientState(), Double.valueOf(getEquity()), Double.valueOf(getStopLossLevel()), getAccountCurrency() });
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformClientInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */