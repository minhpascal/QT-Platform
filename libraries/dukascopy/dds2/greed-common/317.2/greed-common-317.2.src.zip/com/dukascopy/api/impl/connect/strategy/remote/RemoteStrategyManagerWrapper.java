/*    */ package com.dukascopy.api.impl.connect.strategy.remote;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.strategy.StrategyManagerWrapper;
/*    */ import com.dukascopy.api.strategy.remote.IRemoteStrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.remote.IRemoteStrategyManager;
/*    */ 
/*    */ public class RemoteStrategyManagerWrapper extends StrategyManagerWrapper<IRemoteStrategyDescriptor, com.dukascopy.api.strategy.remote.RemoteStrategyListener, IRemoteStrategyManager> implements IRemoteStrategyManager
/*    */ {
/*    */   public RemoteStrategyManagerWrapper(IRemoteStrategyManager manager)
/*    */   {
/* 11 */     super(manager);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\remote\RemoteStrategyManagerWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */