/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface Task<T>
/*    */   extends Callable<T>
/*    */ {
/*    */   public abstract Type getType();
/*    */   
/*    */   public static enum Type
/*    */   {
/* 14 */     TICK,  ACCOUNT,  START,  STOP,  BAR,  MESSAGE,  PARAMETER,  CUSTOM;
/*    */     
/*    */     private Type() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\Task.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */