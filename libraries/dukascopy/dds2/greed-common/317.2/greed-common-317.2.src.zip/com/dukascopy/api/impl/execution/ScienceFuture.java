/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.FutureTask;
/*    */ 
/*    */ 
/*    */ public class ScienceFuture<T>
/*    */   extends FutureTask<T>
/*    */ {
/* 10 */   private Task task = null;
/*    */   
/*    */   public ScienceFuture(Callable<T> callable) {
/* 13 */     super(callable);
/* 14 */     this.task = ((Task)callable);
/*    */   }
/*    */   
/*    */   public Task getTask() {
/* 18 */     return this.task;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\ScienceFuture.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */