/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*    */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*    */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPostDataTask<T>
/*    */   implements Task<T>
/*    */ {
/*    */   protected final JForexTaskManager<?, ?, ?> taskManager;
/*    */   protected final IStrategyExceptionHandler exceptionHandler;
/*    */   protected final IJFRunnable<?> jfRunnable;
/*    */   
/*    */   public AbstractPostDataTask(JForexTaskManager<?, ?, ?> taskManager, IJFRunnable<?> jfRunnable, IStrategyExceptionHandler exceptionHandler)
/*    */   {
/* 30 */     this.exceptionHandler = exceptionHandler;
/* 31 */     this.jfRunnable = jfRunnable;
/* 32 */     this.taskManager = taskManager;
/*    */   }
/*    */   
/*    */   public T call()
/*    */     throws Exception
/*    */   {
/* 38 */     if (this.taskManager.isStrategyStopping()) {
/* 39 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 43 */       postData();
/*    */     } catch (Throwable t) {
/* 45 */       handleError(t, this.jfRunnable);
/*    */     }
/*    */     
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   protected void handleError(Throwable t) {
/* 52 */     handleError(t, this.jfRunnable);
/*    */   }
/*    */   
/*    */   protected void handleError(Throwable t, Object forObject) {
/* 56 */     String msg = ErrorHelper.representError(forObject, t);
/* 57 */     NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 58 */     getLogger().error(t.getMessage(), t);
/* 59 */     this.exceptionHandler.onException(this.taskManager.getStrategyId(), getSource(), t);
/*    */   }
/*    */   
/*    */   protected abstract Logger getLogger();
/*    */   
/*    */   protected abstract IStrategyExceptionHandler.Source getSource();
/*    */   
/*    */   protected abstract void postData()
/*    */     throws Throwable;
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\AbstractPostDataTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */