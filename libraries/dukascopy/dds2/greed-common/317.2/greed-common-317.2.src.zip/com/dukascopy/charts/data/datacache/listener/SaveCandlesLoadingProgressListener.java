/*    */ package com.dukascopy.charts.data.datacache.listener;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaveCandlesLoadingProgressListener
/*    */   implements ILoadingProgressListener
/*    */ {
/*    */   private boolean loadedSuccessfully;
/*    */   private Throwable exception;
/*    */   private final ILoadingProgressListener loadingProgress;
/*    */   
/*    */   public SaveCandlesLoadingProgressListener(ILoadingProgressListener loadingProgress)
/*    */   {
/* 21 */     this.loadingProgress = loadingProgress;
/*    */   }
/*    */   
/*    */ 
/*    */   public void dataLoaded(long startTime, long endTime, long currentTime, String information) {}
/*    */   
/*    */ 
/*    */   public void loadingFinished(boolean allDataLoaded, long startTime, long endTime, long currentTime, Throwable e)
/*    */   {
/* 30 */     this.loadedSuccessfully = true;
/* 31 */     this.exception = e;
/*    */   }
/*    */   
/*    */   public boolean stopJob()
/*    */   {
/* 36 */     return this.loadingProgress.stopJob();
/*    */   }
/*    */   
/*    */   public boolean isLoadedSuccessfully() {
/* 40 */     return this.loadedSuccessfully;
/*    */   }
/*    */   
/*    */   public Throwable getException() {
/* 44 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\listener\SaveCandlesLoadingProgressListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */