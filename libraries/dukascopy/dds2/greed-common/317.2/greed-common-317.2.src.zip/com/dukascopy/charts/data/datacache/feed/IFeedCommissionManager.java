package com.dukascopy.charts.data.datacache.feed;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.OfferSide;
import com.dukascopy.api.Period;
import com.dukascopy.charts.data.datacache.CandleData;
import com.dukascopy.charts.data.datacache.Data;
import com.dukascopy.charts.data.datacache.TickData;
import com.dukascopy.dds3.transport.msg.acc.FeedCommission;
import java.util.List;
import java.util.Map;

public abstract interface IFeedCommissionManager
{
  public abstract void setupFeedCommissionsFromAuthServer(List<String[]> paramList);
  
  public abstract void setupFeedCommissions(List<IInstrumentFeedCommissionInfo> paramList);
  
  public abstract void addFeedCommissions(Map<String, FeedCommission> paramMap);
  
  public abstract void addFeedCommissions(Map<String, FeedCommission> paramMap, Long paramLong);
  
  public abstract void addFeedCommissions(Map<String, FeedCommission> paramMap, long paramLong);
  
  public abstract void addFeedCommissions(List<IInstrumentFeedCommissionInfo> paramList);
  
  public abstract void clear();
  
  public abstract boolean hasCommission(Instrument paramInstrument);
  
  public abstract double getFeedCommission(Instrument paramInstrument, OfferSide paramOfferSide, long paramLong);
  
  public abstract double getPriceWithCommission(Instrument paramInstrument, OfferSide paramOfferSide, double paramDouble, long paramLong);
  
  public abstract CandleData applyFeedCommissionToCandle(Instrument paramInstrument, OfferSide paramOfferSide, CandleData paramCandleData);
  
  public abstract TickData applyFeedCommissionToTick(Instrument paramInstrument, OfferSide paramOfferSide, TickData paramTickData);
  
  public abstract TickData applyFeedCommissionToTick(Instrument paramInstrument, TickData paramTickData);
  
  public abstract Data[] applyFeedCommissionToData(Instrument paramInstrument, Period paramPeriod, OfferSide paramOfferSide, Data[] paramArrayOfData);
  
  public abstract List<String[]> getFeedCommissions();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\feed\IFeedCommissionManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */