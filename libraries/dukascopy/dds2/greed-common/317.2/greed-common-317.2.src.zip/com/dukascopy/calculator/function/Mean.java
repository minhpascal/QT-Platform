/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.complex.Complex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Mean
/*    */   extends Container
/*    */ {
/*    */   public Mean()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.the.mean.of.the.numbers.stored.in.statistics.memory";
/* 15 */     this.fshortcut = 'm';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setError(boolean error)
/*    */   {
/* 23 */     this.error = error;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(double d)
/*    */   {
/* 31 */     this.d = d;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValue(Complex c)
/*    */   {
/* 39 */     this.c = c;
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 43 */     return fname;
/*    */   }
/*    */   
/*    */ 
/* 47 */   private static final String[] fname = { "m", "e", "a", "n" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Mean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */