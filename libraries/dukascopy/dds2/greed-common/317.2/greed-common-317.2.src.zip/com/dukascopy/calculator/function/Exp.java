/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Exp
/*    */   extends RFunction
/*    */ {
/*    */   public Exp()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.exponential.function";
/* 15 */     this.fshortcut = 'e';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 24 */     return Math.exp(x);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 33 */     return x.exp();
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 37 */     return fname;
/*    */   }
/*    */   
/* 40 */   private static final String[] fname = { "e", "x", "p", " " };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Exp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */