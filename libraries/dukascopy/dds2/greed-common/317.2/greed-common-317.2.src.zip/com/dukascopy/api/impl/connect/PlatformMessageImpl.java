/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IMessage;
/*    */ import com.dukascopy.api.IMessage.Reason;
/*    */ import com.dukascopy.api.IMessage.Type;
/*    */ import com.dukascopy.api.IOrder;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformMessageImpl
/*    */   implements IMessage
/*    */ {
/*    */   private final IMessage.Type messageType;
/*    */   private final IOrder relatedOrder;
/*    */   private final String content;
/*    */   private final long creationTime;
/* 24 */   private Set<IMessage.Reason> reasons = Collections.synchronizedSet(new HashSet());
/*    */   
/*    */   public PlatformMessageImpl(String content, IOrder relatedOrder, IMessage.Type messageType, long creationTime) {
/* 27 */     this.messageType = messageType;
/* 28 */     this.relatedOrder = relatedOrder;
/* 29 */     this.content = content;
/* 30 */     this.creationTime = creationTime;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getContent()
/*    */   {
/* 37 */     return this.content;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final IOrder getOrder()
/*    */   {
/* 44 */     return this.relatedOrder;
/*    */   }
/*    */   
/*    */   public final IMessage.Type getType() {
/* 48 */     return this.messageType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Set<IMessage.Reason> getReasons()
/*    */   {
/* 56 */     return new HashSet(this.reasons);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void addReason(IMessage.Reason reason)
/*    */   {
/* 63 */     if (reason.isMessageTypeSupported(getType())) {
/* 64 */       this.reasons.add(reason);
/*    */     }
/*    */   }
/*    */   
/*    */   public long getCreationTime()
/*    */   {
/* 70 */     return this.creationTime;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 75 */     String orderInfo = this.relatedOrder != null ? "Related Order: " + this.relatedOrder : "No related order";
/* 76 */     return String.format("Message Type: %s; Text: %s; %s", new Object[] { getType(), getContent(), orderInfo });
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformMessageImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */