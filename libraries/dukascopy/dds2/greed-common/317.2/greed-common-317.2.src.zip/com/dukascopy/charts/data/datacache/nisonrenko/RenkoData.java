/*     */ package com.dukascopy.charts.data.datacache.nisonrenko;
/*     */ 
/*     */ import com.dukascopy.api.feed.IRenkoBar;
/*     */ import com.dukascopy.charts.data.datacache.priceaggregation.AbstractPriceAggregationData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenkoData
/*     */   extends AbstractPriceAggregationData
/*     */   implements IRenkoBar
/*     */ {
/*     */   private Boolean rising;
/*     */   private Double wickPrice;
/*     */   private Double oppositeWickPrice;
/*     */   
/*     */   public RenkoData() {}
/*     */   
/*     */   public RenkoData(long time, long endTime, double open, double close, double low, double high, double vol, long formedElementsCount)
/*     */   {
/*  35 */     super(time, endTime, open, close, low, high, vol, formedElementsCount);
/*     */   }
/*     */   
/*     */   public RenkoData clone()
/*     */   {
/*  40 */     return (RenkoData)super.clone();
/*     */   }
/*     */   
/*     */   public Boolean isRising() {
/*  44 */     return this.rising;
/*     */   }
/*     */   
/*     */   public void setRising(Boolean rising) {
/*  48 */     this.rising = rising;
/*     */   }
/*     */   
/*     */   public Double getWickPrice()
/*     */   {
/*  53 */     return this.wickPrice;
/*     */   }
/*     */   
/*     */   public void setWickPrice(Double wickPrice) {
/*  57 */     this.wickPrice = wickPrice;
/*     */   }
/*     */   
/*     */   public Double getOppositeWickPrice() {
/*  61 */     return this.oppositeWickPrice;
/*     */   }
/*     */   
/*     */   public void setOppositeWickPrice(Double oppositeWickPrice) {
/*  65 */     this.oppositeWickPrice = oppositeWickPrice;
/*     */   }
/*     */   
/*     */ 
/*     */   public void fromBytes(int version, long fileStartTime, double pipValue, byte[] bytes, int off)
/*     */   {
/*  71 */     off = fromBytesGeneral(version, pipValue, bytes, off);
/*     */     
/*  73 */     this.wickPrice = Double.valueOf(getDouble(bytes, off));
/*  74 */     if (this.wickPrice.doubleValue() == Double.MIN_VALUE) {
/*  75 */       this.wickPrice = null;
/*     */     }
/*     */     
/*  78 */     byte risingByte = Byte.valueOf(getByte(bytes, off + 8)).byteValue();
/*  79 */     if (risingByte == Byte.MIN_VALUE) {
/*  80 */       this.rising = null;
/*     */     }
/*     */     else {
/*  83 */       this.rising = Boolean.valueOf(getBoolean(bytes, off + 8));
/*     */     }
/*     */     
/*  86 */     this.oppositeWickPrice = Double.valueOf(getDouble(bytes, off + 9));
/*  87 */     if (this.oppositeWickPrice.doubleValue() == Double.MIN_VALUE) {
/*  88 */       this.oppositeWickPrice = null;
/*     */     }
/*  90 */     else if (this.oppositeWickPrice.doubleValue() == Double.MAX_VALUE) {
/*  91 */       this.oppositeWickPrice = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void toBytes(int version, long fileStartTime, double pipValue, byte[] buff, int off)
/*     */   {
/*  98 */     if (buff.length < off + getBytesCount(version)) {
/*  99 */       throw new ArrayIndexOutOfBoundsException("Buffer too short");
/*     */     }
/*     */     
/* 102 */     off = toBytesGeneral(version, pipValue, buff, off);
/*     */     
/* 104 */     if (this.wickPrice != null) {
/* 105 */       off = putDouble(buff, off, this.wickPrice.doubleValue());
/*     */     }
/*     */     else {
/* 108 */       off = putDouble(buff, off, Double.MIN_VALUE);
/*     */     }
/*     */     
/* 111 */     if (this.rising != null) {
/* 112 */       off = putBoolean(buff, off, this.rising.booleanValue());
/*     */     }
/*     */     else {
/* 115 */       off = putByte(buff, off, (byte)Byte.MIN_VALUE);
/*     */     }
/*     */     
/* 118 */     if (this.oppositeWickPrice != null) {
/* 119 */       off = putDouble(buff, off, this.oppositeWickPrice.doubleValue());
/*     */     }
/*     */     else {
/* 122 */       off = putDouble(buff, off, Double.MIN_VALUE);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getBytesCount(int version)
/*     */   {
/* 128 */     return 74;
/*     */   }
/*     */   
/*     */   public static int getLength(int version) {
/* 132 */     return 74;
/*     */   }
/*     */   
/*     */   public IRenkoBar getInProgressBar()
/*     */   {
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isIndicationRenko() {
/* 141 */     return (this.close < 0.0D) && (this.high < 0.0D) && (this.low < 0.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\nisonrenko\RenkoData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */