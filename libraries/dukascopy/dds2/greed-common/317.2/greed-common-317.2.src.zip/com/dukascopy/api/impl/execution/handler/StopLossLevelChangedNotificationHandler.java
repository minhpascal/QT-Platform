/*    */ package com.dukascopy.api.impl.execution.handler;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.StopLossLevelChangedMessageImpl;
/*    */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*    */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StopLossLevelChangedNotificationHandler
/*    */   implements INotificationHandler
/*    */ {
/*    */   private static final String NOTIFICATIOIN_REGEX = "^Client ID \\d++ changed Stop loss level from \\d++ to \\d++[A-Z]{3}.$";
/* 22 */   private static final Pattern NOTIFICATION_PATTERN = Pattern.compile("^Client ID \\d++ changed Stop loss level from \\d++ to \\d++[A-Z]{3}.$", 2);
/*    */   
/*    */   public boolean canHandle(NotificationMessage notificationMessage) {
/* 25 */     String text = notificationMessage.getText();
/* 26 */     return NOTIFICATION_PATTERN.matcher(text).matches();
/*    */   }
/*    */   
/*    */   public StopLossLevelChangedMessageImpl handleNotificationMessage(NotificationMessage notificationMessage) {
/* 30 */     StopLossLevelChangedMessageImpl message = null;
/* 31 */     if (canHandle(notificationMessage)) {
/* 32 */       String text = notificationMessage.getText();
/* 33 */       String regex = "\\b\\d++";
/* 34 */       Pattern pattern = Pattern.compile(regex);
/* 35 */       Matcher matcher = pattern.matcher(text);
/* 36 */       int i = 0;
/* 37 */       String[] groups = new String[3];
/* 38 */       while ((matcher.find()) && (i < groups.length)) {
/* 39 */         groups[(i++)] = matcher.group();
/*    */       }
/* 41 */       message = new StopLossLevelChangedMessageImpl(groups[0], Double.parseDouble(groups[1]), Double.parseDouble(groups[2]), text, FeedDataProvider.getDefaultInstance().getCurrentTime());
/*    */     }
/* 43 */     return message;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\handler\StopLossLevelChangedNotificationHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */