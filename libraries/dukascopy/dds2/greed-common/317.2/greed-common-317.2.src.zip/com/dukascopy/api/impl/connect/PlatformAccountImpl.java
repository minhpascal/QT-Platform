/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IAccount;
/*     */ import com.dukascopy.api.IAccount.AccountState;
/*     */ import com.dukascopy.api.IClientInfo;
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.JFCurrency;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.util.EnumConverter;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessage;
/*     */ import com.dukascopy.dds3.transport.msg.acc.AccountInfoMessageInit;
/*     */ import com.dukascopy.dds3.transport.msg.acc.ClientInfoMessage;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Collections;
/*     */ import java.util.Currency;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class PlatformAccountImpl
/*     */   implements IAccount
/*     */ {
/*     */   private ICurrency currency;
/*     */   private double creditLine;
/*     */   private double equity;
/*     */   private double baseEquity;
/*     */   private double balance;
/*     */   private double leverage;
/*     */   private double useOfLeverage;
/*     */   private double usedMargin;
/*     */   private boolean global;
/*     */   private String accountId;
/*     */   private IAccount.AccountState accountState;
/*     */   private final String username;
/*  37 */   private int marginCutLevel = 200;
/*  38 */   private int overTheWeekendLeverage = 30;
/*     */   private double stopLossLevel;
/*  40 */   private Set<String> clientIds = new HashSet(0);
/*  41 */   private final Set<IClientInfo> clientInfoSet = Collections.synchronizedSet(new HashSet());
/*     */   private static volatile boolean connected;
/*     */   private static IAccount account;
/*     */   
/*     */   public PlatformAccountImpl(AccountInfoMessage accountInfoMessage, String username)
/*     */   {
/*  47 */     this(accountInfoMessage, null, username);
/*     */   }
/*     */   
/*     */   public PlatformAccountImpl(AccountInfoMessage accountInfoMessage, AccountInfoMessageInit accountInfoMessageInit, String username) {
/*  51 */     this.username = username;
/*  52 */     if (account == null) {
/*  53 */       account = this;
/*     */     }
/*     */     
/*  56 */     if (accountInfoMessageInit != null) {
/*  57 */       updateFromMessage(accountInfoMessageInit);
/*     */     }
/*  59 */     updateFromMessage(accountInfoMessage);
/*     */   }
/*     */   
/*     */   public static IAccount getAccount() {
/*  63 */     return account;
/*     */   }
/*     */   
/*     */   public static void setConnected(boolean isConnected) {
/*  67 */     connected = isConnected;
/*     */   }
/*     */   
/*     */   public void updateFromMessage(AccountInfoMessage accountInfoMessage) {
/*  71 */     if ((accountInfoMessage instanceof AccountInfoMessageInit)) {
/*  72 */       updateInitValues((AccountInfoMessageInit)accountInfoMessage);
/*     */     }
/*     */     
/*  75 */     updateMainValues(accountInfoMessage);
/*     */   }
/*     */   
/*     */   private void updateInitValues(AccountInfoMessageInit accountInfoMessageInit) {
/*  79 */     this.marginCutLevel = accountInfoMessageInit.getMcLeverageUse().intValue();
/*  80 */     BigDecimal mcEquityLimit = accountInfoMessageInit.getMcEquityLimit();
/*  81 */     if (mcEquityLimit != null) {
/*  82 */       this.stopLossLevel = mcEquityLimit.doubleValue();
/*     */     }
/*  84 */     if (accountInfoMessageInit.getWeekendLeverage() != null) {
/*  85 */       this.overTheWeekendLeverage = accountInfoMessageInit.getWeekendLeverage().intValue();
/*     */     }
/*  87 */     updateClientInfos(accountInfoMessageInit);
/*     */   }
/*     */   
/*     */   private void updateClientInfos(AccountInfoMessageInit accountInfoMessage) {
/*  91 */     List<ClientInfoMessage> clientInfoMessageList = accountInfoMessage.getClients();
/*  92 */     if (!ObjectUtils.isNullOrEmpty(clientInfoMessageList)) {
/*  93 */       Set<IClientInfo> clients = new HashSet(clientInfoMessageList.size());
/*  94 */       Set<String> clientIds = new HashSet(clientInfoMessageList.size());
/*     */       
/*  96 */       for (ClientInfoMessage clientInfoMessage : clientInfoMessageList) {
/*  97 */         clients.add(new PlatformClientInfo(clientInfoMessage));
/*  98 */         clientIds.add(clientInfoMessage.getClientId());
/*     */       }
/*     */       
/* 101 */       synchronized (this.clientInfoSet) {
/* 102 */         this.clientInfoSet.clear();
/* 103 */         this.clientInfoSet.addAll(clients);
/*     */       }
/*     */       
/* 106 */       this.clientIds = Collections.unmodifiableSet(clientIds);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateMainValues(AccountInfoMessage accountInfoMessage) {
/* 111 */     this.currency = JFCurrency.getInstance(accountInfoMessage.getCurrency());
/* 112 */     this.leverage = accountInfoMessage.getLeverage().intValue();
/*     */     
/* 114 */     if (accountInfoMessage.getUsableMargin() != null) {
/* 115 */       this.creditLine = accountInfoMessage.getUsableMargin().multiply(new BigDecimal(this.leverage)).doubleValue();
/*     */     } else {
/* 117 */       this.creditLine = 0.0D;
/*     */     }
/*     */     
/* 120 */     if ((accountInfoMessage.getEquity() != null) && (accountInfoMessage.getEquity().doubleValue() > 0.0D)) {
/* 121 */       this.equity = accountInfoMessage.getEquity().doubleValue();
/*     */     } else {
/* 123 */       this.equity = 0.0D;
/*     */     }
/*     */     
/* 126 */     if ((accountInfoMessage.getBalance() != null) && (accountInfoMessage.getBalance().doubleValue() > 0.0D)) {
/* 127 */       this.balance = accountInfoMessage.getBalance().doubleValue();
/*     */     } else {
/* 129 */       this.balance = 0.0D;
/*     */     }
/*     */     
/* 132 */     if ((accountInfoMessage.getBaseEquity() != null) && (accountInfoMessage.getBaseEquity().doubleValue() > 0.0D)) {
/* 133 */       this.baseEquity = accountInfoMessage.getBaseEquity().doubleValue();
/*     */     } else {
/* 135 */       this.baseEquity = 0.0D;
/*     */     }
/*     */     
/* 138 */     if ((accountInfoMessage.getEquity() != null) && (accountInfoMessage.getEquity().doubleValue() > 0.0D) && (accountInfoMessage.getUsableMargin() != null)) {
/* 139 */       this.useOfLeverage = accountInfoMessage.getEquity().subtract(accountInfoMessage.getUsableMargin()).divide(accountInfoMessage.getEquity(), 2, RoundingMode.HALF_EVEN).doubleValue();
/* 140 */       this.useOfLeverage = StratUtils.round(this.useOfLeverage * 100.0D, 5);
/*     */       
/* 142 */       this.usedMargin = accountInfoMessage.getEquity().subtract(accountInfoMessage.getUsableMargin()).doubleValue();
/*     */     } else {
/* 144 */       this.useOfLeverage = 0.0D;
/*     */     }
/*     */     
/* 147 */     if (accountInfoMessage.getState() != null) {
/* 148 */       this.accountState = ((IAccount.AccountState)EnumConverter.convert(accountInfoMessage.getState(), IAccount.AccountState.class));
/*     */     }
/*     */     
/* 151 */     this.global = accountInfoMessage.isGlobal();
/* 152 */     this.accountId = accountInfoMessage.getUserId();
/*     */   }
/*     */   
/*     */   public double getCreditLine()
/*     */   {
/* 157 */     return this.creditLine;
/*     */   }
/*     */   
/*     */   public Currency getCurrency()
/*     */   {
/* 162 */     return this.currency.getJavaCurrency();
/*     */   }
/*     */   
/*     */   public ICurrency getAccountCurrency()
/*     */   {
/* 167 */     return this.currency;
/*     */   }
/*     */   
/*     */   public double getEquity()
/*     */   {
/* 172 */     return this.equity;
/*     */   }
/*     */   
/*     */   public double getBalance()
/*     */   {
/* 177 */     return this.balance;
/*     */   }
/*     */   
/*     */   public double getLeverage()
/*     */   {
/* 182 */     return this.leverage;
/*     */   }
/*     */   
/*     */   public double getUseOfLeverage()
/*     */   {
/* 187 */     return this.useOfLeverage;
/*     */   }
/*     */   
/*     */   public int getMarginCutLevel()
/*     */   {
/* 192 */     return this.marginCutLevel;
/*     */   }
/*     */   
/*     */   public int getOverWeekEndLeverage()
/*     */   {
/* 197 */     return this.overTheWeekendLeverage;
/*     */   }
/*     */   
/*     */   public boolean isGlobal()
/*     */   {
/* 202 */     return this.global;
/*     */   }
/*     */   
/*     */   public String getAccountId()
/*     */   {
/* 207 */     return this.accountId;
/*     */   }
/*     */   
/*     */   public Set<String> getClientIds()
/*     */   {
/* 212 */     return this.clientIds;
/*     */   }
/*     */   
/*     */   public IAccount.AccountState getAccountState()
/*     */   {
/* 217 */     return this.accountState;
/*     */   }
/*     */   
/*     */   public double getStopLossLevel()
/*     */   {
/* 222 */     return this.stopLossLevel;
/*     */   }
/*     */   
/*     */   public double getBaseEquity()
/*     */   {
/* 227 */     return this.baseEquity;
/*     */   }
/*     */   
/*     */   public Set<IClientInfo> getClients()
/*     */   {
/* 232 */     return this.clientInfoSet;
/*     */   }
/*     */   
/*     */   public boolean isConnected()
/*     */   {
/* 237 */     return connected;
/*     */   }
/*     */   
/*     */   public String getUserName()
/*     */   {
/* 242 */     return this.username;
/*     */   }
/*     */   
/*     */   public double getUsedMargin() {
/* 246 */     return this.usedMargin;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 251 */     return "Equity = " + getEquity() + " " + getAccountCurrency() + " Leverage=" + getLeverage();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\PlatformAccountImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */