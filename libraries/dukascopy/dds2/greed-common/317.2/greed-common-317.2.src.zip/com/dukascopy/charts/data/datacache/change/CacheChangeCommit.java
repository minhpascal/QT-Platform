/*    */ package com.dukascopy.charts.data.datacache.change;
/*    */ 
/*    */ import com.dukascopy.api.util.DateUtils;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheChangeCommit
/*    */ {
/*    */   private boolean successfull;
/*    */   private Set<String> uniqueInstrumentFolderNames;
/*    */   private long lastPerformedTime;
/*    */   
/* 22 */   public CacheChangeCommit(boolean successfull) { this(successfull, null, 0L); }
/*    */   
/*    */   public CacheChangeCommit(boolean successfull, Set<String> uniqueInstrumentFolderNames, long lastPerformedTime) {
/* 25 */     this.successfull = successfull;
/* 26 */     this.uniqueInstrumentFolderNames = uniqueInstrumentFolderNames;
/* 27 */     this.lastPerformedTime = lastPerformedTime;
/*    */   }
/*    */   
/* 30 */   public boolean isSuccessfull() { return this.successfull; }
/*    */   
/*    */   public void setSuccessfull(boolean successfull) {
/* 33 */     this.successfull = successfull;
/*    */   }
/*    */   
/* 36 */   public Set<String> getUniqueInstrumentFolderNames() { return this.uniqueInstrumentFolderNames; }
/*    */   
/*    */   public void setUniqueInstrumentFolderNames(Set<String> uniqueInstrumentFolderNames) {
/* 39 */     this.uniqueInstrumentFolderNames = uniqueInstrumentFolderNames;
/*    */   }
/*    */   
/* 42 */   public long getLastPerformedTime() { return this.lastPerformedTime; }
/*    */   
/*    */   public void setLastPerformedTime(long lastPerformedTime) {
/* 45 */     this.lastPerformedTime = lastPerformedTime;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 49 */     int prime = 31;
/* 50 */     int result = 1;
/* 51 */     result = 31 * result + (int)(this.lastPerformedTime ^ this.lastPerformedTime >>> 32);
/* 52 */     result = 31 * result + (this.successfull ? 1231 : 1237);
/* 53 */     result = 31 * result + (this.uniqueInstrumentFolderNames == null ? 0 : this.uniqueInstrumentFolderNames.hashCode());
/* 54 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 58 */     if (this == obj)
/* 59 */       return true;
/* 60 */     if (obj == null)
/* 61 */       return false;
/* 62 */     if (getClass() != obj.getClass())
/* 63 */       return false;
/* 64 */     CacheChangeCommit other = (CacheChangeCommit)obj;
/* 65 */     if (this.lastPerformedTime != other.lastPerformedTime)
/* 66 */       return false;
/* 67 */     if (this.successfull != other.successfull)
/* 68 */       return false;
/* 69 */     if (this.uniqueInstrumentFolderNames == null) {
/* 70 */       if (other.uniqueInstrumentFolderNames != null)
/* 71 */         return false;
/* 72 */     } else if (!this.uniqueInstrumentFolderNames.equals(other.uniqueInstrumentFolderNames))
/* 73 */       return false;
/* 74 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 78 */     return "[successfull=" + this.successfull + ", uniqueInstrumentFolderNames=" + this.uniqueInstrumentFolderNames + ", lastPerformedTime=" + DateUtils.format(this.lastPerformedTime) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\change\CacheChangeCommit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */