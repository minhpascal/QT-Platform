/*     */ package com.dukascopy.charts.data.datacache.hl;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.CandleData;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HighLowManager
/*     */   implements IHighLowManager, LiveFeedListener
/*     */ {
/*  34 */   private static final Logger LOGGER = LoggerFactory.getLogger(HighLowManager.class);
/*     */   
/*     */   private final Map<Instrument, HighLow> highLowMap;
/*     */   
/*     */   private final Map<Instrument, List<ICommonHighLowListener>> listenersMap;
/*     */   
/*     */   private final Period targetPeriod;
/*     */   
/*     */   private final IFeedDataProvider feedDataProvider;
/*     */   
/*     */   public HighLowManager(Period period)
/*     */   {
/*  46 */     this(null, period);
/*     */   }
/*     */   
/*     */   public HighLowManager(IFeedDataProvider feedDataProvider, Period period) {
/*  50 */     this.feedDataProvider = feedDataProvider;
/*  51 */     this.targetPeriod = period;
/*  52 */     this.highLowMap = new ConcurrentHashMap();
/*  53 */     this.listenersMap = new ConcurrentHashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addHighLowListener(Instrument instrument, ICommonHighLowListener listener)
/*     */   {
/*  61 */     if (instrument == null) {
/*  62 */       LOGGER.warn("Cannot add HighLowListener. Instrument is null.");
/*  63 */       return;
/*     */     }
/*  65 */     if (listener == null) {
/*  66 */       LOGGER.warn("Cannot add HighLowListener. Listener is null.");
/*  67 */       return;
/*     */     }
/*  69 */     synchronized (this) {
/*  70 */       List<ICommonHighLowListener> list = (List)this.listenersMap.get(instrument);
/*     */       
/*  72 */       if (list == null) {
/*  73 */         list = new ArrayList();
/*  74 */         this.listenersMap.put(instrument, list);
/*     */       }
/*  76 */       if ((list.isEmpty()) && (this.feedDataProvider != null)) {
/*  77 */         this.feedDataProvider.addInProgressCandleListener(instrument, this.targetPeriod, OfferSide.ASK, this);
/*  78 */         this.feedDataProvider.addInProgressCandleListener(instrument, this.targetPeriod, OfferSide.BID, this);
/*     */       }
/*  80 */       list.add(listener);
/*     */       
/*  82 */       HighLow highLow = (HighLow)this.highLowMap.get(instrument);
/*     */       
/*  84 */       if ((highLow == null) && (this.feedDataProvider != null)) {
/*  85 */         CandleData bidCandle = this.feedDataProvider.getInProgressCandle(instrument, this.targetPeriod, OfferSide.BID);
/*  86 */         CandleData askCandle = this.feedDataProvider.getInProgressCandle(instrument, this.targetPeriod, OfferSide.ASK);
/*     */         
/*  88 */         if ((bidCandle != null) && (askCandle != null)) {
/*  89 */           highLow = new HighLow(bidCandle.time, Math.max(bidCandle.high, askCandle.high), Math.min(bidCandle.low, askCandle.low));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*  95 */         else if (bidCandle != null) {
/*  96 */           highLow = new HighLow(bidCandle.time, bidCandle.high, bidCandle.low);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 102 */         else if (askCandle != null) {
/* 103 */           highLow = new HighLow(askCandle.time, askCandle.high, askCandle.low);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */         if (highLow != null) {
/* 111 */           this.highLowMap.put(instrument, highLow);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Instrument, List<ICommonHighLowListener>> getHighLowListeners()
/*     */   {
/* 122 */     return new HashMap(this.listenersMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeHighLowListener(ICommonHighLowListener listener)
/*     */   {
/* 130 */     synchronized (this) {
/* 131 */       Set<Map.Entry<Instrument, List<ICommonHighLowListener>>> entrySet = this.listenersMap.entrySet();
/* 132 */       List<ICommonHighLowListener> valuesToRemove = new ArrayList();
/*     */       
/* 134 */       for (Map.Entry<Instrument, List<ICommonHighLowListener>> entry : entrySet) {
/* 135 */         if (entry.getValue() != null) {
/* 136 */           for (ICommonHighLowListener l : (List)entry.getValue()) {
/* 137 */             if (l.equals(listener)) {
/* 138 */               valuesToRemove.add(l);
/*     */             }
/*     */           }
/*     */           
/* 142 */           ((List)entry.getValue()).removeAll(valuesToRemove);
/* 143 */           valuesToRemove.clear();
/*     */         }
/*     */       }
/*     */       
/* 147 */       for (Instrument instrument : this.listenersMap.keySet()) {
/* 148 */         List<ICommonHighLowListener> list = (List)this.listenersMap.get(instrument);
/* 149 */         if ((ObjectUtils.isNullOrEmpty(list)) && (this.feedDataProvider != null)) {
/* 150 */           this.feedDataProvider.removeInProgressCandleListener(instrument, this.targetPeriod, OfferSide.ASK, this);
/* 151 */           this.feedDataProvider.removeInProgressCandleListener(instrument, this.targetPeriod, OfferSide.BID, this);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<ICommonHighLowListener> getHighLowListeners(Instrument instrument)
/*     */   {
/* 163 */     synchronized (this) {
/* 164 */       List<ICommonHighLowListener> list = (List)this.listenersMap.get(instrument);
/* 165 */       if (list == null) {
/* 166 */         return Collections.emptyList();
/*     */       }
/* 168 */       return Collections.unmodifiableList(list);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol)
/*     */   {
/* 178 */     if (ObjectUtils.isEqual(this.targetPeriod, period)) {
/* 179 */       synchronized (this) {
/* 180 */         HighLow highLow = (HighLow)this.highLowMap.get(instrument);
/* 181 */         if ((highLow != null) && 
/* 182 */           (highLow.getTime() != time)) {
/* 183 */           highLow = null;
/*     */         }
/*     */         
/* 186 */         if (highLow == null) {
/* 187 */           highLow = new HighLow(time, high, low);
/* 188 */           this.highLowMap.put(instrument, highLow);
/*     */           
/* 190 */           fireHighUpdated(instrument, period, high);
/* 191 */           fireLowUpdated(instrument, period, low);
/*     */         } else {
/* 193 */           if (highLow.getHigh() < high) {
/* 194 */             highLow.setHigh(high);
/* 195 */             fireHighUpdated(instrument, period, high);
/*     */           }
/*     */           
/* 198 */           if (highLow.getLow() > low) {
/* 199 */             highLow.setLow(low);
/* 200 */             fireLowUpdated(instrument, period, low);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAllListeners()
/*     */   {
/* 212 */     synchronized (this) {
/* 213 */       if (this.feedDataProvider != null) {
/* 214 */         for (Instrument instrument : this.listenersMap.keySet()) {
/* 215 */           this.feedDataProvider.removeInProgressCandleListener(instrument, this.targetPeriod, OfferSide.ASK, this);
/* 216 */           this.feedDataProvider.removeInProgressCandleListener(instrument, this.targetPeriod, OfferSide.BID, this);
/*     */         }
/*     */       }
/* 219 */       this.listenersMap.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Period getTargetPeriod()
/*     */   {
/* 236 */     return this.targetPeriod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fireHighUpdated(Instrument instrument, Period period, double high)
/*     */   {
/* 244 */     synchronized (this) {
/* 245 */       List<ICommonHighLowListener> list = (List)this.listenersMap.get(instrument);
/* 246 */       for (ICommonHighLowListener l : list) {
/* 247 */         fireHighUpdated(l, instrument, period, high);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fireLowUpdated(Instrument instrument, Period period, double low)
/*     */   {
/* 257 */     synchronized (this) {
/* 258 */       List<ICommonHighLowListener> list = (List)this.listenersMap.get(instrument);
/* 259 */       for (ICommonHighLowListener l : list) {
/* 260 */         fireLowUpdated(l, instrument, period, low);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fireHighUpdated(ICommonHighLowListener listener, Instrument instrument, Period period, double high)
/*     */   {
/* 271 */     listener.highUpdated(instrument, period, high);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fireLowUpdated(ICommonHighLowListener listener, Instrument instrument, Period period, double low)
/*     */   {
/* 280 */     listener.lowUpdated(instrument, period, low);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\hl\HighLowManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */