/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ 
/*    */ public class AnsButton extends CalculatorButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public AnsButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 11 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 12 */     setPobject(new com.dukascopy.calculator.function.Ans());
/* 13 */     setText();
/* 14 */     setTextSize();
/* 15 */     addActionListener(this);
/*    */     
/* 17 */     setShortcut('a');
/* 18 */     setToolTipKey("sc.calculator.use.to.calculate.with.the.last.result.you.found");
/*    */   }
/*    */   
/*    */   public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
/* 22 */     synchronized (this.mainCalculatorPanel) {
/* 23 */       if (getMainCalculatorPanel().getMode() != 0) {
/* 24 */         getMainCalculatorPanel().setMode(getPobject());
/* 25 */         getMainCalculatorPanel().requestFocusInWindow();
/* 26 */         return;
/*    */       }
/* 28 */       if (!(getMainCalculatorPanel().getValue() instanceof com.dukascopy.calculator.Error)) {
/* 29 */         ((com.dukascopy.calculator.function.Ans)getPobject()).setValue(getMainCalculatorPanel().getValue());
/*    */       }
/* 31 */       if (getPobject() == null) {
/* 32 */         return;
/*    */       }
/* 34 */       add(getPobject());
/* 35 */       getMainCalculatorPanel().updateDisplay(true, true);
/* 36 */       if (getMainCalculatorPanel().getShift()) {
/* 37 */         getMainCalculatorPanel().setShift(false);
/*    */       }
/* 39 */       getMainCalculatorPanel().requestFocusInWindow();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\AnsButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */