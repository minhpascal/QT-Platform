package com.dukascopy.calculator.graph;

import java.awt.Graphics2D;

public abstract class Element
{
  public abstract void draw(Model paramModel, View paramView, Graphics2D paramGraphics2D);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\graph\Element.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */