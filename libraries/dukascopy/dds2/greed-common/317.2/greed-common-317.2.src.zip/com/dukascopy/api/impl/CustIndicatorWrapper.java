/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.indicators.IIndicator;
/*    */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*    */ import com.dukascopy.dds2.greed.util.FullAccessDisclaimerProvider;
/*    */ import com.dukascopy.dds2.greed.util.IFullAccessDisclaimer;
/*    */ import java.io.File;
/*    */ 
/*    */ public class CustIndicatorWrapper extends ServiceWrapper
/*    */ {
/*    */   private JFXPack pack;
/*    */   
/*    */   public String getName()
/*    */   {
/* 15 */     if (this.isNewUnsaved) {
/* 16 */       return "*Indicator" + this.newFileIndex;
/*    */     }
/* 18 */     if (this.srcFile != null) {
/* 19 */       return this.srcFile.getName();
/*    */     }
/* 21 */     if (this.binFile != null) {
/* 22 */       return this.binFile.getName();
/*    */     }
/* 24 */     return null;
/*    */   }
/*    */   
/*    */   public IIndicator getIndicator() {
/* 28 */     if (this.pack == null) {
/* 29 */       return null;
/*    */     }
/* 31 */     return (IIndicator)this.pack.getTarget();
/*    */   }
/*    */   
/*    */   public void reinit() {
/* 35 */     this.pack = null;
/*    */   }
/*    */   
/*    */   public boolean requestFullAccess() throws Exception {
/* 39 */     if (this.pack == null) {
/* 40 */       this.pack = JFXPack.loadFromPack(getBinaryFile());
/*    */     }
/* 42 */     if (this.pack != null) {
/* 43 */       if ((this.pack.isFullAccessRequested()) && (FullAccessDisclaimerProvider.getDisclaimer() != null)) {
/* 44 */         return FullAccessDisclaimerProvider.getDisclaimer().showDialog(this.pack);
/*    */       }
/* 46 */       return true;
/*    */     }
/*    */     
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   public JFXPack getPack() {
/* 53 */     return this.pack;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\CustIndicatorWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */