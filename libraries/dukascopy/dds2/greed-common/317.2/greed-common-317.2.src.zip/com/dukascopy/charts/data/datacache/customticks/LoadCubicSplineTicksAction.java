/*     */ package com.dukascopy.charts.data.datacache.customticks;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.TickData;
/*     */ import com.dukascopy.charts.data.datacache.listener.TickFeedListener;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.tester.CubicSplineInterpolation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadCubicSplineTicksAction
/*     */   extends AbstractLoadCustomTicksFromCandlesAction
/*     */ {
/*     */   private final TickFeedListener feedListener;
/*  23 */   private final int tickSpread = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoadCubicSplineTicksAction(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, OfferSide offerSide, long from, long to, TickFeedListener feedListener, ILoadingProgressListener loadingProgressListener)
/*     */   {
/*  35 */     super(feedDataProvider, instrument, period, offerSide, from, to, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */     this.feedListener = feedListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TickData[] candleToTicks(long time, double open, double high, double low, double close, double volume, long length, double pipValue, int tickSpreadInPips, OfferSide offerSide)
/*     */   {
/*  59 */     long step = length / 4L;
/*  60 */     long baseTime = time;
/*     */     
/*  62 */     long x1 = length;
/*  63 */     long x4 = x1 + length;
/*  64 */     long x2 = x1 + step;
/*  65 */     long x3 = x2 + step;
/*     */     
/*  67 */     double y1 = open;
/*  68 */     double y2 = open > close ? low : high;
/*  69 */     double y3 = open > close ? high : low;
/*  70 */     double y4 = close;
/*     */     
/*  72 */     CubicSplineInterpolation cubicSplineInterpolation = new CubicSplineInterpolation(new double[] { x1, x2, x3, x4 }, new double[] { y1, y2, y3, y4 });
/*     */     
/*     */ 
/*     */ 
/*  76 */     int ticksNumber = (int)((high - low) / (pipValue / 2.0D));
/*  77 */     if (ticksNumber == 0)
/*     */     {
/*  79 */       ticksNumber = 1;
/*     */     }
/*     */     
/*  82 */     TickData[] result = new TickData[ticksNumber];
/*     */     
/*  84 */     step = length / ticksNumber;
/*  85 */     double vol = StratUtils.roundHalfEven(volume / ticksNumber, 2);
/*     */     
/*  87 */     for (int i = 0; i < ticksNumber; i++) {
/*  88 */       long xx = x1 + step * i;
/*     */       double bid;
/*     */       double bid;
/*  91 */       double ask; if (offerSide == OfferSide.ASK) {
/*  92 */         double ask = StratUtils.round(cubicSplineInterpolation.interpolate(xx), 5);
/*  93 */         bid = StratUtils.round(ask - pipValue * tickSpreadInPips, 5);
/*     */       } else {
/*  95 */         bid = StratUtils.round(cubicSplineInterpolation.interpolate(xx), 5);
/*  96 */         ask = StratUtils.round(bid + pipValue * tickSpreadInPips, 5);
/*     */       }
/*  98 */       result[i] = new TickData(baseTime + step * i, ask, bid, vol, vol);
/*     */     }
/*     */     
/* 101 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void candleToTicks(long time, double open, double high, double low, double close, double volume)
/*     */   {
/* 112 */     TickData[] ticks = candleToTicks(time, open, high, low, close, volume, this.period.getInterval(), this.instrument.getPipValue(), 2, this.offerSide);
/*     */     
/* 114 */     for (int i = 0; i < ticks.length; i++) {
/* 115 */       TickData t = ticks[i];
/* 116 */       newTick(t.getTime(), t.getAsk(), t.getBid(), t.getAskVolume(), t.getBidVolume());
/*     */     }
/*     */   }
/*     */   
/*     */   private void newTick(long time, double ask, double bid, double askVol, double bidVol) {
/* 121 */     if ((this.from <= time) && (time <= this.to)) {
/* 122 */       this.feedListener.newTick(this.instrument, time, ask, bid, askVol, bidVol);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void candleReceived(long time, double open, double close, double low, double high, double vol)
/*     */   {
/* 128 */     candleToTicks(time, open, high, low, close, vol);
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\LoadCubicSplineTicksAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */