package com.dukascopy.charts.data.datacache.hl;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.Period;

public abstract interface ICommonHighLowListener
{
  public abstract void highUpdated(Instrument paramInstrument, Period paramPeriod, double paramDouble);
  
  public abstract void lowUpdated(Instrument paramInstrument, Period paramPeriod, double paramDouble);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\hl\ICommonHighLowListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */