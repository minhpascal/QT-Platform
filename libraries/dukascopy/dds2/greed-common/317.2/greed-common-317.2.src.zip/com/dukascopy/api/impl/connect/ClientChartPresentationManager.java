/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.DataType;
/*     */ import com.dukascopy.api.DataType.DataPresentationType;
/*     */ import com.dukascopy.api.Filter;
/*     */ import com.dukascopy.api.IChart;
/*     */ import com.dukascopy.api.IClientChartPresentationManager;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.chart.IChartTheme;
/*     */ import com.dukascopy.api.chart.IChartTheme.Predefined;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.main.interfaces.DDSChartsController;
/*     */ import com.dukascopy.charts.persistence.ThemeManager;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientChartPresentationManager
/*     */   implements IClientChartPresentationManager
/*     */ {
/*     */   private final int chartPanelId;
/*     */   private final IChart chart;
/*     */   private final DDSChartsController ddsChartsController;
/*     */   
/*     */   public ClientChartPresentationManager(DDSChartsController ddsChartsController, int chartPanelId, IChart chart)
/*     */   {
/*  34 */     this.chart = chart;
/*  35 */     this.chartPanelId = chartPanelId;
/*  36 */     this.ddsChartsController = ddsChartsController;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFeedDescriptor(IFeedDescriptor feedDescriptor)
/*     */   {
/*  44 */     if (feedDescriptor == null) {
/*  45 */       throw new IllegalArgumentException("feedDescriptor is null ");
/*     */     }
/*  47 */     if (isValid()) {
/*  48 */       JForexPeriod jForexPeriod = JForexPeriod.createJForexPeriod(feedDescriptor);
/*  49 */       this.ddsChartsController.changeInstrument(Integer.valueOf(this.chartPanelId), feedDescriptor.getInstrument());
/*  50 */       this.ddsChartsController.changeJForexPeriod(Integer.valueOf(this.chartPanelId), jForexPeriod);
/*  51 */       this.ddsChartsController.changeFilter(feedDescriptor.getFilter());
/*  52 */       if (!ObjectUtils.isEqual(DataType.TICKS, feedDescriptor.getDataType())) {
/*  53 */         this.ddsChartsController.switchBidAskTo(Integer.valueOf(this.chartPanelId), feedDescriptor.getOfferSide());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IFeedDescriptor getFeedDescriptor()
/*     */   {
/*  63 */     if (isValid()) {
/*  64 */       this.chart.getFeedDescriptor();
/*     */     }
/*  66 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChartAutoShift()
/*     */   {
/*  74 */     if (isValid()) {
/*  75 */       this.ddsChartsController.shiftChartToFront(Integer.valueOf(this.chartPanelId));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isChartAutoShift()
/*     */   {
/*  81 */     if (isValid()) {
/*  82 */       return this.ddsChartsController.isChartShiftActive(Integer.valueOf(this.chartPanelId));
/*     */     }
/*  84 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void zoomIn()
/*     */   {
/*  92 */     if (isValid()) {
/*  93 */       this.ddsChartsController.zoomIn(Integer.valueOf(this.chartPanelId));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void zoomOut()
/*     */   {
/* 102 */     if (isValid()) {
/* 103 */       this.ddsChartsController.zoomOut(Integer.valueOf(this.chartPanelId));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void switchOfferSide(OfferSide offerSide)
/*     */   {
/* 112 */     if (isValid()) {
/* 113 */       this.ddsChartsController.switchBidAskTo(Integer.valueOf(this.chartPanelId), offerSide);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInstrument(Instrument instrument)
/*     */   {
/* 123 */     if (isValid()) {
/* 124 */       this.ddsChartsController.changeInstrument(Integer.valueOf(this.chartPanelId), instrument);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataPresentationType(DataType.DataPresentationType dataPresentationType)
/*     */   {
/* 133 */     if (isValid()) {
/* 134 */       this.chart.setDataPresentationType(dataPresentationType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataType.DataPresentationType getDataPresentationType()
/*     */   {
/* 143 */     if (isValid()) {
/* 144 */       return this.chart.getDataPresentationType();
/*     */     }
/* 146 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter getFilter()
/*     */   {
/* 154 */     if (isValid()) {
/* 155 */       return this.ddsChartsController.getFilter();
/*     */     }
/* 157 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilter(Filter filter)
/*     */   {
/* 165 */     if (isValid()) {
/* 166 */       this.ddsChartsController.changeFilter(filter);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isValid() {
/* 171 */     boolean valid = false;
/* 172 */     if ((this.ddsChartsController != null) && (this.chartPanelId != -1)) {
/* 173 */       valid = true;
/*     */     }
/* 175 */     return valid;
/*     */   }
/*     */   
/*     */   public IChartTheme getTheme()
/*     */   {
/* 180 */     IChartTheme theme = ThemeManager.getTheme(this.ddsChartsController.getTheme(this.chartPanelId));
/* 181 */     if (ThemeManager.isDefault(theme.getName())) {
/* 182 */       theme = theme.clone();
/* 183 */       theme.setName(theme.getName() + " cloned, id: " + UUID.randomUUID());
/*     */     }
/* 185 */     return theme;
/*     */   }
/*     */   
/*     */   public void setTheme(IChartTheme theme)
/*     */   {
/* 190 */     ThemeManager.add(theme);
/* 191 */     this.ddsChartsController.setTheme(this.chartPanelId, theme.getName());
/*     */   }
/*     */   
/*     */   public IChartTheme getPredefinedTheme(IChartTheme.Predefined predefinedTheme)
/*     */   {
/* 196 */     IChartTheme theme = ThemeManager.getTheme(predefinedTheme);
/* 197 */     theme = theme.clone();
/* 198 */     theme.setName(theme.getName() + " cloned, id: " + UUID.randomUUID());
/* 199 */     return theme;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ClientChartPresentationManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */