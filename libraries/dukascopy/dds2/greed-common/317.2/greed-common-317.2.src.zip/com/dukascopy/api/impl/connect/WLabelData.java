/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IWLabelData;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WLabelData
/*     */   implements IWLabelData
/*     */ {
/*  29 */   private static final Logger LOGGER = LoggerFactory.getLogger(WLabelData.class);
/*     */   
/*     */   private static final String WLABEL_SHORT_NAME_KEY = "wlabel.shortLabel";
/*     */   
/*     */   private static final String WLABEL_LONG_NAME_KEY = "wlabel.longLabel";
/*     */   
/*     */   private static final String WLABEL_IMAGES_KEY = "wlabel.logo";
/*     */   
/*     */   private static final String WLABEL_PHONE_KEY = "wlabel.phone";
/*     */   
/*     */   private static final String WLABEL_SKYPE_KEY = "wlabel.skype";
/*     */   
/*     */   private static final String WLABEL_URL_KEY = "wlabel.url";
/*     */   
/*     */   private static final String DUKASCOPY = "Dukascopy";
/*     */   
/*     */   private static final String DEFAULT_LABEL_SHORT_NAME = "Dukascopy Bank";
/*     */   
/*     */   private static final String DEFAULT_LABEL_LONG_NAME = "Dukascopy Bank SA";
/*     */   
/*     */   private static final String DEFAULT_LABEL_URL = "www.dukascopy.com";
/*     */   
/*     */   private static final String DEFAULT_LABEL_PHONE = "+41 (0) 22 799 48 48";
/*     */   
/*     */   private static final String DEFAULT_LABEL_SKYPE_ID = "dukascopy";
/*     */   private static final int ICON_WIDTH = 32;
/*     */   private static final int ICON_HEIGTH = 32;
/*     */   private static final int LOGO_WIDTH = 240;
/*     */   private static final int LOGO_HEIGTH = 60;
/*     */   private static final int SPLASH_WIDTH = 600;
/*     */   private static final int SPLASH_HEIGTH = 370;
/*     */   private final String shortName;
/*     */   private final String longName;
/*     */   private final String url;
/*     */   private final String phone;
/*     */   private final String skypeId;
/*     */   private final BufferedImage icon;
/*     */   private final BufferedImage logo;
/*     */   private final BufferedImage splash;
/*     */   
/*     */   public WLabelData(Properties serverProperties)
/*     */   {
/*  71 */     this.shortName = ((String)String.class.cast(serverProperties.get("wlabel.shortLabel")));
/*  72 */     this.longName = ((String)String.class.cast(serverProperties.get("wlabel.longLabel")));
/*  73 */     this.url = ((String)String.class.cast(serverProperties.get("wlabel.url")));
/*  74 */     this.phone = ((String)String.class.cast(serverProperties.get("wlabel.phone")));
/*  75 */     this.skypeId = ((String)String.class.cast(serverProperties.get("wlabel.skype")));
/*     */     
/*     */ 
/*  78 */     BufferedImage iconImage = null;
/*  79 */     BufferedImage logoImage = null;
/*  80 */     BufferedImage splashImage = null;
/*  81 */     byte[] bytes = (byte[])serverProperties.get("wlabel.logo");
/*  82 */     if (bytes == null) {
/*  83 */       LOGGER.warn("White Label Image is not received");
/*     */     } else {
/*     */       try
/*     */       {
/*  87 */         BufferedImage image = ImageIO.read(new ByteArrayInputStream(bytes));
/*  88 */         iconImage = image.getSubimage(0, 0, 32, 32);
/*  89 */         logoImage = image.getSubimage(0, 32, 240, 60);
/*  90 */         splashImage = image.getSubimage(0, 92, 600, 370);
/*     */       } catch (IOException e) {
/*  92 */         LOGGER.error("Unable to read image data bytes", e);
/*     */       }
/*     */     }
/*  95 */     this.icon = iconImage;
/*  96 */     this.logo = logoImage;
/*  97 */     this.splash = splashImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getShortName()
/*     */   {
/* 105 */     return ObjectUtils.isNullOrEmpty(this.shortName) ? "Dukascopy Bank" : this.shortName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLongName()
/*     */   {
/* 114 */     return ObjectUtils.isNullOrEmpty(this.longName) ? "Dukascopy Bank SA" : this.longName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 123 */     return ObjectUtils.isNullOrEmpty(this.url) ? "www.dukascopy.com" : this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSkype()
/*     */   {
/* 132 */     return ObjectUtils.isNullOrEmpty(this.skypeId) ? "dukascopy" : this.skypeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPhone()
/*     */   {
/* 141 */     return ObjectUtils.isNullOrEmpty(this.phone) ? "+41 (0) 22 799 48 48" : this.phone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedImage getIcon()
/*     */   {
/* 150 */     return this.icon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedImage getLogo()
/*     */   {
/* 158 */     return this.logo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedImage getSplash()
/*     */   {
/* 166 */     return this.splash;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\WLabelData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */