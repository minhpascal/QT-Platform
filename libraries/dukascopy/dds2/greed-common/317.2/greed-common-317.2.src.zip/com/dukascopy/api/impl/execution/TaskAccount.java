/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IAccount;
/*    */ import com.dukascopy.api.IStrategy;
/*    */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*    */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*    */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskAccount
/*    */   implements Task
/*    */ {
/* 21 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskAccount.class);
/*    */   
/* 23 */   private IStrategy strategy = null;
/* 24 */   private IAccount account = null;
/*    */   private IStrategyExceptionHandler exceptionHandler;
/*    */   private JForexTaskManager taskManager;
/*    */   private StrategyEventsCallback strategyEventsCallback;
/*    */   
/*    */   public TaskAccount(JForexTaskManager taskManager, IStrategy strategy, IAccount account, IStrategyExceptionHandler exceptionHandler) {
/* 30 */     this.strategy = strategy;
/* 31 */     this.account = account;
/* 32 */     this.exceptionHandler = exceptionHandler;
/* 33 */     this.taskManager = taskManager;
/* 34 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 39 */     return Task.Type.ACCOUNT;
/*    */   }
/*    */   
/*    */   public Object call() throws Exception
/*    */   {
/* 44 */     if (this.taskManager.isStrategyStopping()) {
/* 45 */       return null;
/*    */     }
/*    */     try {
/* 48 */       this.strategy.onAccount(this.account);
/* 49 */       if (this.strategyEventsCallback != null) {
/* 50 */         this.strategyEventsCallback.onAccount(this.account);
/*    */       }
/*    */     } catch (Throwable t) {
/* 53 */       String msg = ErrorHelper.representError(this.strategy, t);
/* 54 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 55 */       LOGGER.error(t.getMessage(), t);
/* 56 */       this.exceptionHandler.onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_ACCOUNT_INFO, t);
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskAccount.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */