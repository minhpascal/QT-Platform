package com.dukascopy.charts.data.datacache.hl;

import com.dukascopy.api.Instrument;
import com.dukascopy.api.Period;
import com.dukascopy.charts.data.datacache.LiveFeedListener;
import java.util.List;
import java.util.Map;

public abstract interface IHighLowManager
  extends LiveFeedListener
{
  public abstract void addHighLowListener(Instrument paramInstrument, ICommonHighLowListener paramICommonHighLowListener);
  
  public abstract void removeHighLowListener(ICommonHighLowListener paramICommonHighLowListener);
  
  public abstract List<ICommonHighLowListener> getHighLowListeners(Instrument paramInstrument);
  
  public abstract Map<Instrument, List<ICommonHighLowListener>> getHighLowListeners();
  
  public abstract void removeAllListeners();
  
  public abstract Period getTargetPeriod();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\hl\IHighLowManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */