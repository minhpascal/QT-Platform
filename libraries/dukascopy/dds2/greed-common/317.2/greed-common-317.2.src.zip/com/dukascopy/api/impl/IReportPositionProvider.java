package com.dukascopy.api.impl;

import com.dukascopy.api.IReportPosition;
import com.dukascopy.charts.data.datacache.DataCacheException;
import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
import com.dukascopy.charts.data.datacache.IReportPositionsListener;
import java.util.List;

public abstract interface IReportPositionProvider
{
  public abstract List<IReportPosition> getOpenPositions()
    throws DataCacheException;
  
  public abstract void readOpenPositions(IReportPositionsListener paramIReportPositionsListener, ILoadingProgressListener paramILoadingProgressListener)
    throws DataCacheException;
  
  public abstract List<IReportPosition> getClosedPositions(long paramLong1, long paramLong2)
    throws DataCacheException;
  
  public abstract void readClosedPositions(long paramLong1, long paramLong2, IReportPositionsListener paramIReportPositionsListener, ILoadingProgressListener paramILoadingProgressListener)
    throws DataCacheException;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\IReportPositionProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */