/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IContext;
/*    */ import com.dukascopy.api.IJFRunnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskStop<T extends IContext>
/*    */   implements Task<Void>
/*    */ {
/* 15 */   private IJFRunnable<T> strategy = null;
/*    */   
/* 17 */   public TaskStop(IJFRunnable<T> strategy) { this.strategy = strategy; }
/*    */   
/*    */ 
/*    */ 
/*    */   public Task.Type getType()
/*    */   {
/* 23 */     return Task.Type.STOP;
/*    */   }
/*    */   
/*    */   public Void call() throws Exception
/*    */   {
/* 28 */     if (this.strategy != null) {
/* 29 */       this.strategy.onStop();
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskStop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */