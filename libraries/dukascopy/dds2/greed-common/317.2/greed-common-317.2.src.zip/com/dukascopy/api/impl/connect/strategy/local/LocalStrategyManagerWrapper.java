/*    */ package com.dukascopy.api.impl.connect.strategy.local;
/*    */ 
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.impl.connect.strategy.StrategyManagerWrapper;
/*    */ import com.dukascopy.api.strategy.IStrategyParameter;
/*    */ import com.dukascopy.api.strategy.local.ILocalStrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.local.ILocalStrategyManager;
/*    */ import com.dukascopy.api.strategy.local.LocalStrategyListener;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ 
/*    */ public class LocalStrategyManagerWrapper extends StrategyManagerWrapper<ILocalStrategyDescriptor, LocalStrategyListener, ILocalStrategyManager> implements ILocalStrategyManager
/*    */ {
/*    */   public LocalStrategyManagerWrapper(ILocalStrategyManager manager)
/*    */   {
/* 17 */     super(manager);
/*    */   }
/*    */   
/*    */   public List<IStrategyParameter> getDefaultParameters(File file) throws IOException, JFException
/*    */   {
/* 22 */     return ((ILocalStrategyManager)this.manager).getDefaultParameters(file);
/*    */   }
/*    */   
/*    */   public File compileStrategy(File srcFile)
/*    */   {
/* 27 */     return ((ILocalStrategyManager)this.manager).compileStrategy(srcFile);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\local\LocalStrategyManagerWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */