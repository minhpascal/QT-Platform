/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.impl.talib.FuncInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.Holder;
/*     */ import com.dukascopy.api.impl.talib.InputParameterInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.IntegerListHolder;
/*     */ import com.dukascopy.api.impl.talib.IntegerRangeHolder;
/*     */ import com.dukascopy.api.impl.talib.OptInputParameterInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.OutputParameterInfoHolder;
/*     */ import com.dukascopy.api.impl.talib.RealListHolder;
/*     */ import com.dukascopy.api.impl.talib.RealRangeHolder;
/*     */ import com.dukascopy.api.impl.talib.TaFuncService;
/*     */ import com.dukascopy.api.impl.talib.TaGrpService;
/*     */ import com.tictactec.ta.lib.CoreAnnotated;
/*     */ import com.tictactec.ta.lib.MAType;
/*     */ import com.tictactec.ta.lib.MInteger;
/*     */ import com.tictactec.ta.lib.RetCode;
/*     */ import com.tictactec.ta.lib.meta.PriceInputParameter;
/*     */ import com.tictactec.ta.lib.meta.annotation.FuncInfo;
/*     */ import com.tictactec.ta.lib.meta.annotation.InputParameterInfo;
/*     */ import com.tictactec.ta.lib.meta.annotation.InputParameterType;
/*     */ import com.tictactec.ta.lib.meta.annotation.IntegerList;
/*     */ import com.tictactec.ta.lib.meta.annotation.IntegerRange;
/*     */ import com.tictactec.ta.lib.meta.annotation.OptInputParameterInfo;
/*     */ import com.tictactec.ta.lib.meta.annotation.OptInputParameterType;
/*     */ import com.tictactec.ta.lib.meta.annotation.OutputParameterInfo;
/*     */ import com.tictactec.ta.lib.meta.annotation.OutputParameterType;
/*     */ import com.tictactec.ta.lib.meta.annotation.RealList;
/*     */ import com.tictactec.ta.lib.meta.annotation.RealRange;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.IncompleteAnnotationException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaLibMetaData
/*     */   implements Comparable<TaLibMetaData>, Cloneable
/*     */ {
/*     */   private static final transient String PARAM_NOT_FOUND = "Parameter with specified index was not found";
/*     */   private static final transient String UNKNOWN_PARAM_TYPE = "Unknown parameter type";
/*     */   private static final transient String UNEXPECTED_PARAM_TYPE = "Unexpected parameter type";
/*     */   private static final transient String UNEXPECTED_PARAM_VALUE = "Unexpected parameter value";
/*     */   private static final transient String INDEX_OUT_OF_BOUNDS = "Index out of bounds";
/*     */   private static final transient String ILLEGAL_NUMBER_OF_ARGUMENTS = "Illegal number of arguments";
/*     */   private static final String PARAM_VALUE_OUT_OF_BOUNDS = "Parameter value out of bounds";
/*     */   private static final transient String ARRAY_IS_NULL = "Array is null";
/*     */   private static final transient String INT_ARRAY_EXPECTED = "int[] expected";
/*     */   private static final transient String DOUBLE_ARRAY_EXPECTED = "double[] expected";
/*     */   private static final transient String PRICE_EXPECTED = "PriceInputParameter object expected";
/*  64 */   private static final transient Class<CoreAnnotated> coreClass = CoreAnnotated.class;
/*     */   
/*     */   private static final transient String LOOKBACK_SUFFIX = "Lookback";
/*  67 */   private static transient CoreAnnotated taCore = null;
/*     */   
/*  69 */   private String name = null;
/*  70 */   private Method function = null;
/*  71 */   private Method lookback = null;
/*     */   
/*  73 */   private static transient Map<String, TaLibMetaData> taFuncMap = null;
/*  74 */   private static transient Map<String, Set<TaLibMetaData>> taGrpMap = null;
/*     */   
/*  76 */   private transient Object[] callInputParams = null;
/*  77 */   private transient Object[] callOutputParams = null;
/*  78 */   private transient Object[] callOptInputParams = null;
/*     */   
/*     */   private transient FuncInfoHolder funcInfo;
/*     */   private transient Holder[][] parameterAnnotations;
/*     */   
/*     */   protected TaLibMetaData()
/*     */   {
/*  85 */     synchronized (coreClass) {
/*  86 */       if (taCore == null) {
/*  87 */         taCore = new CoreAnnotated();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int compareTo(TaLibMetaData arg) {
/*  93 */     return this.name.compareTo(arg.name);
/*     */   }
/*     */   
/*     */   private static Map<String, TaLibMetaData> getAllFuncs() {
/*  97 */     synchronized (coreClass) {
/*  98 */       if (taFuncMap == null) {
/*  99 */         taFuncMap = getTaFuncMetaInfoMap();
/*     */       }
/*     */     }
/* 102 */     return taFuncMap;
/*     */   }
/*     */   
/*     */   private static Map<String, Set<TaLibMetaData>> getAllGrps() {
/* 106 */     synchronized (coreClass) {
/* 107 */       if (taGrpMap == null) {
/* 108 */         taGrpMap = getTaGrpMetaInfoMap();
/*     */       }
/*     */     }
/* 111 */     return taGrpMap;
/*     */   }
/*     */   
/*     */   private static Map<String, Method> getLookbackMethodMap() {
/* 115 */     Map<String, Method> map = new HashMap();
/* 116 */     Method[] ms = coreClass.getDeclaredMethods();
/* 117 */     for (Method m : ms) {
/* 118 */       if (m.getName().endsWith("Lookback")) {
/* 119 */         map.put(m.getName(), m);
/*     */       }
/*     */     }
/* 122 */     return map;
/*     */   }
/*     */   
/*     */   private static Map<String, TaLibMetaData> getTaFuncMetaInfoMap() {
/* 126 */     Map<String, TaLibMetaData> result = new TreeMap();
/* 127 */     Method[] ms = coreClass.getDeclaredMethods();
/* 128 */     Map<String, Method> lookbackMap = getLookbackMethodMap();
/* 129 */     for (Method funcMethod : ms) {
/* 130 */       String fn = funcMethod.getName();
/* 131 */       if (funcMethod.getReturnType().equals(RetCode.class))
/*     */       {
/*     */ 
/* 134 */         String lookbackName = fn + "Lookback";
/* 135 */         Method lookbackMethod = (Method)lookbackMap.get(lookbackName);
/* 136 */         if (lookbackMethod != null) {
/* 137 */           FuncInfoHolder info = getFuncInfo(funcMethod);
/* 138 */           String funcName = info.name;
/* 139 */           TaLibMetaData mi = new TaLibMetaData();
/* 140 */           mi.name = funcName;
/* 141 */           mi.function = funcMethod;
/* 142 */           mi.lookback = lookbackMethod;
/* 143 */           result.put(funcName, mi);
/*     */         }
/*     */       }
/*     */     }
/* 147 */     return result;
/*     */   }
/*     */   
/*     */   private static Map<String, Set<TaLibMetaData>> getTaGrpMetaInfoMap() {
/* 151 */     if (taFuncMap == null) getAllFuncs();
/* 152 */     Map<String, Set<TaLibMetaData>> result = new TreeMap();
/* 153 */     for (String func : taFuncMap.keySet()) {
/* 154 */       TaLibMetaData mi = (TaLibMetaData)taFuncMap.get(func);
/* 155 */       String group = mi.getFuncInfo().group;
/* 156 */       Set<TaLibMetaData> set = (Set)result.get(group);
/* 157 */       if (set == null) {
/* 158 */         set = new TreeSet();
/* 159 */         result.put(group, set);
/*     */       }
/* 161 */       set.add(mi);
/*     */     }
/* 163 */     return result;
/*     */   }
/*     */   
/*     */   private static FuncInfoHolder getFuncInfo(Method method) throws IncompleteAnnotationException {
/* 167 */     FuncInfo annotation = (FuncInfo)method.getAnnotation(FuncInfo.class);
/* 168 */     if (annotation != null) {
/* 169 */       FuncInfoHolder holder = new FuncInfoHolder();
/* 170 */       holder.name = annotation.name();
/* 171 */       holder.group = annotation.group();
/* 172 */       holder.hint = annotation.hint();
/* 173 */       holder.helpFile = annotation.helpFile();
/* 174 */       holder.flags = annotation.flags();
/* 175 */       holder.nbInput = annotation.nbInput();
/* 176 */       holder.nbOptInput = annotation.nbOptInput();
/* 177 */       holder.nbOutput = annotation.nbOutput();
/* 178 */       return holder;
/*     */     }
/* 180 */     throw new IncompleteAnnotationException(FuncInfo.class, "Method " + method.getName());
/*     */   }
/*     */   
/*     */   static TaLibMetaData getFuncHandle(String name) throws NoSuchMethodException {
/* 184 */     TaLibMetaData mi = (TaLibMetaData)getAllFuncs().get(name.toUpperCase());
/* 185 */     if (mi == null) throw new NoSuchMethodException(name.toUpperCase());
/* 186 */     mi.callInputParams = null;
/* 187 */     mi.callOutputParams = null;
/* 188 */     mi.callOptInputParams = null;
/* 189 */     if (mi != null) return mi;
/* 190 */     throw new NoSuchMethodException("Function " + name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TaLibMetaData getInstance(String name)
/*     */     throws NoSuchMethodException
/*     */   {
/* 203 */     return getFuncHandle(name).clone();
/*     */   }
/*     */   
/*     */   protected TaLibMetaData clone()
/*     */   {
/*     */     try {
/* 209 */       getFuncInfo();
/* 210 */       getParameterAnnotations();
/* 211 */       TaLibMetaData clone = (TaLibMetaData)super.clone();
/* 212 */       this.callInputParams = null;
/* 213 */       this.callOutputParams = null;
/* 214 */       this.callOptInputParams = null;
/* 215 */       return clone;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/* 218 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FuncInfoHolder getFuncInfo()
/*     */     throws IncompleteAnnotationException
/*     */   {
/* 229 */     if (this.funcInfo == null) {
/* 230 */       this.funcInfo = getFuncInfo(this.function);
/*     */     }
/* 232 */     return this.funcInfo;
/*     */   }
/*     */   
/*     */   private Holder getParameterInfo(int paramIndex, Class<? extends Object> paramAnnotation) {
/* 236 */     if (paramIndex < 0)
/* 237 */       throw new IllegalArgumentException("Index out of bounds");
/* 238 */     int i = 0;
/* 239 */     for (Holder[] annArray : getParameterAnnotations()) {
/* 240 */       for (Holder ann : annArray) {
/* 241 */         if ((ann.annotationType == paramAnnotation) && (paramIndex == i++)) {
/* 242 */           return ann;
/*     */         }
/*     */       }
/*     */     }
/* 246 */     return null;
/*     */   }
/*     */   
/*     */   private Holder[][] getParameterAnnotations() {
/* 250 */     if (this.parameterAnnotations == null) {
/* 251 */       Annotation[][] annotations = this.function.getParameterAnnotations();
/* 252 */       this.parameterAnnotations = new Holder[annotations.length][];
/* 253 */       for (int i = 0; i < annotations.length; i++) {
/* 254 */         Annotation[] paramAnnotations = annotations[i];
/* 255 */         this.parameterAnnotations[i] = new Holder[paramAnnotations.length];
/* 256 */         for (int j = 0; j < paramAnnotations.length; j++) {
/* 257 */           Annotation annotation = paramAnnotations[j];
/* 258 */           Holder holder = null;
/* 259 */           Class<? extends Annotation> annotationType = annotation.annotationType();
/* 260 */           if (annotationType == InputParameterInfo.class) {
/* 261 */             InputParameterInfo infoAnnotation = (InputParameterInfo)annotation;
/* 262 */             InputParameterInfoHolder infoHolder = new InputParameterInfoHolder();
/* 263 */             infoHolder.annotationType = InputParameterInfo.class;
/* 264 */             infoHolder.flags = infoAnnotation.flags();
/* 265 */             infoHolder.paramName = infoAnnotation.paramName();
/* 266 */             infoHolder.type = infoAnnotation.type();
/* 267 */             holder = infoHolder;
/* 268 */           } else if (annotationType == OptInputParameterInfo.class) {
/* 269 */             OptInputParameterInfo infoAnnotation = (OptInputParameterInfo)annotation;
/* 270 */             OptInputParameterInfoHolder infoHolder = new OptInputParameterInfoHolder();
/* 271 */             infoHolder.annotationType = OptInputParameterInfo.class;
/* 272 */             infoHolder.type = infoAnnotation.type();
/* 273 */             infoHolder.paramName = infoAnnotation.paramName();
/* 274 */             infoHolder.flags = infoAnnotation.flags();
/* 275 */             infoHolder.displayName = infoAnnotation.displayName();
/* 276 */             infoHolder.dataSet = infoAnnotation.dataSet();
/* 277 */             holder = infoHolder;
/* 278 */           } else if (annotationType == OutputParameterInfo.class) {
/* 279 */             OutputParameterInfo infoAnnotation = (OutputParameterInfo)annotation;
/* 280 */             OutputParameterInfoHolder infoHolder = new OutputParameterInfoHolder();
/* 281 */             infoHolder.annotationType = OutputParameterInfo.class;
/* 282 */             infoHolder.type = infoAnnotation.type();
/* 283 */             infoHolder.paramName = infoAnnotation.paramName();
/* 284 */             infoHolder.flags = infoAnnotation.flags();
/* 285 */             holder = infoHolder;
/* 286 */           } else if (annotationType == IntegerList.class) {
/* 287 */             IntegerList infoAnnotation = (IntegerList)annotation;
/* 288 */             IntegerListHolder infoHolder = new IntegerListHolder();
/* 289 */             infoHolder.annotationType = IntegerList.class;
/* 290 */             infoHolder.value = infoAnnotation.value();
/* 291 */             infoHolder.paramName = infoAnnotation.paramName();
/* 292 */             infoHolder.defaultValue = infoAnnotation.defaultValue();
/* 293 */             infoHolder.string = infoAnnotation.string();
/* 294 */             holder = infoHolder;
/* 295 */           } else if (annotationType == RealList.class) {
/* 296 */             RealList infoAnnotation = (RealList)annotation;
/* 297 */             RealListHolder infoHolder = new RealListHolder();
/* 298 */             infoHolder.annotationType = RealList.class;
/* 299 */             infoHolder.value = infoAnnotation.value();
/* 300 */             infoHolder.paramName = infoAnnotation.paramName();
/* 301 */             infoHolder.defaultValue = infoAnnotation.defaultValue();
/* 302 */             infoHolder.string = infoAnnotation.string();
/* 303 */             holder = infoHolder;
/* 304 */           } else if (annotationType == IntegerRange.class) {
/* 305 */             IntegerRange infoAnnotation = (IntegerRange)annotation;
/* 306 */             IntegerRangeHolder infoHolder = new IntegerRangeHolder();
/* 307 */             infoHolder.annotationType = IntegerRange.class;
/* 308 */             infoHolder.paramName = infoAnnotation.paramName();
/* 309 */             infoHolder.defaultValue = infoAnnotation.defaultValue();
/* 310 */             infoHolder.max = infoAnnotation.max();
/* 311 */             infoHolder.min = infoAnnotation.min();
/* 312 */             infoHolder.suggested_start = infoAnnotation.suggested_start();
/* 313 */             infoHolder.suggested_end = infoAnnotation.suggested_end();
/* 314 */             infoHolder.suggested_increment = infoAnnotation.suggested_increment();
/* 315 */             holder = infoHolder;
/* 316 */           } else if (annotationType == RealRange.class) {
/* 317 */             RealRange infoAnnotation = (RealRange)annotation;
/* 318 */             RealRangeHolder infoHolder = new RealRangeHolder();
/* 319 */             infoHolder.annotationType = RealRange.class;
/* 320 */             infoHolder.paramName = infoAnnotation.paramName();
/* 321 */             infoHolder.defaultValue = infoAnnotation.defaultValue();
/* 322 */             infoHolder.max = infoAnnotation.max();
/* 323 */             infoHolder.min = infoAnnotation.min();
/* 324 */             infoHolder.suggested_start = infoAnnotation.suggested_start();
/* 325 */             infoHolder.suggested_end = infoAnnotation.suggested_end();
/* 326 */             infoHolder.suggested_increment = infoAnnotation.suggested_increment();
/* 327 */             infoHolder.precision = infoAnnotation.precision();
/* 328 */             holder = infoHolder;
/*     */           }
/* 330 */           this.parameterAnnotations[i][j] = holder;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 335 */     return this.parameterAnnotations;
/*     */   }
/*     */   
/*     */   private Holder getParameterInfo(int paramIndex, Class<? extends Object> paramAnnotation, Class<? extends Object> paramExtraAnnotation) {
/* 339 */     if (paramIndex < 0)
/* 340 */       throw new IllegalArgumentException("Index out of bounds");
/* 341 */     int i = 0;
/* 342 */     for (Holder[] annArray : getParameterAnnotations()) {
/* 343 */       for (Holder ann : annArray) {
/* 344 */         if ((ann.annotationType == paramAnnotation) && (paramIndex == i++)) {
/* 345 */           for (Holder annExt : annArray) {
/* 346 */             if (annExt.annotationType == paramExtraAnnotation) {
/* 347 */               return annExt;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 353 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputParameterInfoHolder getInputParameterInfo(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 364 */     return (InputParameterInfoHolder)getParameterInfo(paramIndex, InputParameterInfo.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputParameterInfoHolder getOutputParameterInfo(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 375 */     return (OutputParameterInfoHolder)getParameterInfo(paramIndex, OutputParameterInfo.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OptInputParameterInfoHolder getOptInputParameterInfo(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 386 */     return (OptInputParameterInfoHolder)getParameterInfo(paramIndex, OptInputParameterInfo.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IntegerListHolder getOptInputIntegerList(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 398 */     return (IntegerListHolder)getParameterInfo(paramIndex, OptInputParameterInfo.class, IntegerList.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IntegerRangeHolder getOptInputIntegerRange(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 410 */     return (IntegerRangeHolder)getParameterInfo(paramIndex, OptInputParameterInfo.class, IntegerRange.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RealListHolder getOptInputRealList(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 422 */     return (RealListHolder)getParameterInfo(paramIndex, OptInputParameterInfo.class, RealList.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RealRangeHolder getOptInputRealRange(int paramIndex)
/*     */     throws IllegalArgumentException
/*     */   {
/* 434 */     return (RealRangeHolder)getParameterInfo(paramIndex, OptInputParameterInfo.class, RealRange.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptInputParamInteger(int paramIndex, int value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 446 */     OptInputParameterInfoHolder param = getOptInputParameterInfo(paramIndex);
/* 447 */     if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 448 */     if (param.type == OptInputParameterType.TA_OptInput_IntegerList) {
/* 449 */       IntegerListHolder list = getOptInputIntegerList(paramIndex);
/* 450 */       int[] values = list.value;
/* 451 */       for (int i = 0; i < values.length; i++) {
/* 452 */         if (value == values[i]) {
/* 453 */           String strValue = list.string[i];
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 461 */           MAType[] fields = MAType.values();
/* 462 */           for (MAType maType : fields) {
/* 463 */             if (maType.name().toUpperCase().equals(strValue.toUpperCase())) {
/* 464 */               if (this.callOptInputParams == null) this.callOptInputParams = new Object[getFuncInfo().nbOptInput];
/* 465 */               this.callOptInputParams[paramIndex] = maType;
/* 466 */               return;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 471 */     } else if (param.type == OptInputParameterType.TA_OptInput_IntegerRange) {
/* 472 */       IntegerRangeHolder range = getOptInputIntegerRange(paramIndex);
/*     */       
/* 474 */       validateValueInRange(Integer.valueOf(value), Integer.valueOf(range.min), Integer.valueOf(range.max), paramIndex);
/*     */       
/* 476 */       if (this.callOptInputParams == null) this.callOptInputParams = new Object[getFuncInfo().nbOptInput];
/* 477 */       this.callOptInputParams[paramIndex] = Integer.valueOf(value);
/* 478 */       return;
/*     */     }
/* 480 */     throw new InternalError("Unknown parameter type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptInputParamInteger(int paramIndex, String string)
/*     */     throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 493 */       Integer v = new Integer(string);
/* 494 */       setOptInputParamInteger(paramIndex, v.intValue());
/*     */     } catch (NumberFormatException e) {
/* 496 */       OptInputParameterInfoHolder param = getOptInputParameterInfo(paramIndex);
/* 497 */       if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 498 */       if (param.type != OptInputParameterType.TA_OptInput_IntegerList) { throw new InternalError("Unexpected parameter type");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 506 */       MAType[] fields = MAType.values();
/* 507 */       for (MAType value : fields) {
/* 508 */         if (value.name().toUpperCase().equals(string.toUpperCase())) {
/* 509 */           if (this.callOptInputParams == null) this.callOptInputParams = new Object[getFuncInfo().nbOptInput];
/* 510 */           this.callOptInputParams[paramIndex] = value;
/* 511 */           return;
/*     */         }
/*     */       }
/* 514 */       throw new InternalError("Unexpected parameter value");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptInputParamReal(int paramIndex, double value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 527 */     OptInputParameterInfoHolder param = getOptInputParameterInfo(paramIndex);
/* 528 */     if (param.type == OptInputParameterType.TA_OptInput_RealList) {
/* 529 */       RealListHolder list = getOptInputRealList(paramIndex);
/* 530 */       for (double entry : list.value) {
/* 531 */         if (value == entry) {
/* 532 */           if (this.callOptInputParams == null) this.callOptInputParams = new Object[getFuncInfo().nbOptInput];
/* 533 */           this.callOptInputParams[paramIndex] = Double.valueOf(value);
/* 534 */           return;
/*     */         }
/*     */       }
/* 537 */     } else if (param.type == OptInputParameterType.TA_OptInput_RealRange) {
/* 538 */       RealRangeHolder range = getOptInputRealRange(paramIndex);
/*     */       
/* 540 */       validateValueInRange(Double.valueOf(value), Double.valueOf(range.min), Double.valueOf(range.max), paramIndex);
/*     */       
/* 542 */       if (this.callOptInputParams == null) this.callOptInputParams = new Object[getFuncInfo().nbOptInput];
/* 543 */       this.callOptInputParams[paramIndex] = Double.valueOf(value);
/* 544 */       return;
/*     */     }
/* 546 */     throw new InternalError("Unknown parameter type");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptInputParamReal(int paramIndex, String string)
/*     */     throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 559 */       Double v = new Double(string);
/* 560 */       setOptInputParamReal(paramIndex, v.doubleValue());
/*     */     } catch (NumberFormatException e) {
/* 562 */       OptInputParameterInfoHolder param = getOptInputParameterInfo(paramIndex);
/* 563 */       if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 564 */       if (param.type == OptInputParameterType.TA_OptInput_RealList) {
/* 565 */         RealListHolder list = getOptInputRealList(paramIndex);
/* 566 */         for (int i = 0; i < list.string.length; i++) {
/* 567 */           if (string.toUpperCase().equals(list.string[i])) {
/* 568 */             if (this.callOptInputParams == null) this.callOptInputParams = new Object[getFuncInfo().nbOptInput];
/* 569 */             double value = list.value[i];
/* 570 */             this.callOptInputParams[paramIndex] = Double.valueOf(value);
/* 571 */             return;
/*     */           }
/*     */         }
/* 574 */         throw new InternalError("Unexpected parameter value");
/*     */       }
/* 576 */       throw new InternalError("Unexpected parameter type");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputParamReal(int paramIndex, Object array)
/*     */     throws IllegalArgumentException, NullPointerException
/*     */   {
/* 590 */     if (array == null) throw new NullPointerException("Array is null");
/* 591 */     InputParameterInfoHolder param = getInputParameterInfo(paramIndex);
/* 592 */     if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 593 */     if (param.type != InputParameterType.TA_Input_Real) throw new InternalError("Unexpected parameter type");
/* 594 */     if (!(array instanceof double[])) throw new IllegalArgumentException("double[] expected");
/* 595 */     if (this.callInputParams == null) this.callInputParams = new Object[getFuncInfo().nbInput];
/* 596 */     this.callInputParams[paramIndex] = array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputParamInteger(int paramIndex, Object array)
/*     */     throws IllegalArgumentException, NullPointerException
/*     */   {
/* 609 */     if (array == null) throw new NullPointerException("Array is null");
/* 610 */     InputParameterInfoHolder param = getInputParameterInfo(paramIndex);
/* 611 */     if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 612 */     if (param.type != InputParameterType.TA_Input_Integer) throw new InternalError("Unexpected parameter type");
/* 613 */     if (!(array instanceof int[])) throw new IllegalArgumentException("int[] expected");
/* 614 */     if (this.callInputParams == null) this.callInputParams = new Object[getFuncInfo().nbInput];
/* 615 */     this.callInputParams[paramIndex] = array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputParamPrice(int paramIndex, double[] open, double[] high, double[] low, double[] close, double[] volume, double[] openInterest)
/*     */     throws IllegalArgumentException, NullPointerException
/*     */   {
/* 638 */     InputParameterInfoHolder param = getInputParameterInfo(paramIndex);
/* 639 */     if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 640 */     if (param.type != InputParameterType.TA_Input_Price) throw new InternalError("Unexpected parameter type");
/* 641 */     if (this.callInputParams == null) this.callInputParams = new Object[getFuncInfo().nbInput];
/* 642 */     this.callInputParams[paramIndex] = new PriceInputParameter(param.flags, open, high, low, close, volume, openInterest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputParamReal(int paramIndex, Object array)
/*     */     throws IllegalArgumentException, NullPointerException, ClassCastException
/*     */   {
/* 656 */     if (array == null) throw new NullPointerException("Array is null");
/* 657 */     OutputParameterInfoHolder param = getOutputParameterInfo(paramIndex);
/* 658 */     if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 659 */     if (param.type != OutputParameterType.TA_Output_Real) throw new InternalError("Unexpected parameter type");
/* 660 */     if (!(array instanceof double[])) throw new IllegalArgumentException("double[] expected");
/* 661 */     if (this.callOutputParams == null) this.callOutputParams = new Object[getFuncInfo().nbOutput];
/* 662 */     this.callOutputParams[paramIndex] = array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputParamInteger(int paramIndex, Object array)
/*     */     throws IllegalArgumentException, NullPointerException, ClassCastException
/*     */   {
/* 676 */     if (array == null) throw new NullPointerException("Array is null");
/* 677 */     OutputParameterInfoHolder param = getOutputParameterInfo(paramIndex);
/* 678 */     if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 679 */     if (param.type != OutputParameterType.TA_Output_Integer) throw new InternalError("Unexpected parameter type");
/* 680 */     if (!(array instanceof int[])) throw new IllegalArgumentException("int[] expected");
/* 681 */     if (this.callOutputParams == null) this.callOutputParams = new Object[getFuncInfo().nbOutput];
/* 682 */     this.callOutputParams[paramIndex] = array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void forEachFunc(TaFuncService service)
/*     */     throws Exception
/*     */   {
/* 693 */     for (TaLibMetaData mi : getAllFuncs().values()) {
/* 694 */       service.execute(mi);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void forEachGrp(TaGrpService service)
/*     */     throws Exception
/*     */   {
/* 706 */     for (String group : getAllGrps().keySet()) {
/* 707 */       service.execute(group, (Set)taGrpMap.get(group));
/*     */     }
/*     */   }
/*     */   
/*     */   private Object[] getOptInputParameters() {
/* 712 */     int size = getFuncInfo().nbOptInput;
/* 713 */     if (this.callOptInputParams == null) this.callOptInputParams = new Object[size];
/* 714 */     for (int i = 0; i < size; i++) {
/* 715 */       if (this.callOptInputParams[i] == null) {
/* 716 */         OptInputParameterInfoHolder param = getOptInputParameterInfo(i);
/* 717 */         if (param == null) throw new InternalError("Parameter with specified index was not found");
/* 718 */         if (param.type == OptInputParameterType.TA_OptInput_IntegerList) {
/* 719 */           IntegerListHolder list = getOptInputIntegerList(i);
/* 720 */           this.callOptInputParams[i] = Integer.valueOf(list.defaultValue);
/* 721 */         } else if (param.type == OptInputParameterType.TA_OptInput_IntegerRange) {
/* 722 */           IntegerRangeHolder range = getOptInputIntegerRange(i);
/* 723 */           this.callOptInputParams[i] = Integer.valueOf(range.defaultValue);
/* 724 */         } else if (param.type == OptInputParameterType.TA_OptInput_RealList) {
/* 725 */           RealListHolder list = getOptInputRealList(i);
/* 726 */           this.callOptInputParams[i] = Double.valueOf(list.defaultValue);
/* 727 */         } else if (param.type == OptInputParameterType.TA_OptInput_RealRange) {
/* 728 */           RealRangeHolder range = getOptInputRealRange(i);
/* 729 */           this.callOptInputParams[i] = Double.valueOf(range.defaultValue);
/*     */         } else {
/* 731 */           throw new InternalError("Unknown parameter type");
/*     */         }
/*     */       }
/*     */     }
/* 735 */     return this.callOptInputParams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLookback()
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 751 */     Object[] params = getOptInputParameters();
/* 752 */     return ((Integer)this.lookback.invoke(taCore, params)).intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void callFunc(int startIndex, int endIndex, MInteger outBegIdx, MInteger outNbElement)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 775 */     int count = 0;
/* 776 */     for (Object item : this.callInputParams) {
/* 777 */       if (PriceInputParameter.class == item.getClass()) {
/* 778 */         count += ((PriceInputParameter)item).getCount();
/*     */       } else {
/* 780 */         count++;
/*     */       }
/*     */     }
/*     */     
/* 784 */     count += this.callOutputParams.length;
/*     */     
/* 786 */     if (this.callOptInputParams != null) {
/* 787 */       count += this.callOptInputParams.length;
/*     */     }
/*     */     
/* 790 */     Object[] params = new Object[count + 4];
/* 791 */     count = 0;
/* 792 */     params[(count++)] = Integer.valueOf(startIndex);
/* 793 */     params[(count++)] = Integer.valueOf(endIndex);
/*     */     
/* 795 */     for (Object item : this.callInputParams) {
/* 796 */       if (PriceInputParameter.class == item.getClass()) {
/* 797 */         Object[] objs = ((PriceInputParameter)item).toArrays();
/* 798 */         for (int i = 0; i < objs.length; i++) {
/* 799 */           params[(count++)] = objs[i];
/*     */         }
/*     */       } else {
/* 802 */         params[(count++)] = item;
/*     */       }
/*     */     }
/*     */     
/* 806 */     if (this.callOptInputParams != null) {
/* 807 */       for (int i = 0; i < this.callOptInputParams.length; i++) {
/* 808 */         if (this.callOptInputParams[i] == null) {
/* 809 */           throw new IllegalArgumentException("Optional parameter with index " + i + " not set");
/*     */         }
/* 811 */         params[(count++)] = this.callOptInputParams[i];
/*     */       }
/*     */     }
/*     */     
/* 815 */     params[(count++)] = outBegIdx;
/* 816 */     params[(count++)] = outNbElement;
/*     */     
/* 818 */     for (Object item : this.callOutputParams) {
/* 819 */       params[(count++)] = item;
/*     */     }
/*     */     
/* 822 */     Type[] types = this.function.getGenericParameterTypes();
/* 823 */     if (types.length != params.length) { throw new IllegalArgumentException("Illegal number of arguments");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 830 */     this.function.invoke(taCore, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T extends Comparable<T>> void validateValueInRange(T value, T min, T max, int paramIndex)
/*     */   {
/* 838 */     if ((value.compareTo(min) < 0) || (value.compareTo(max) > 0)) {
/* 839 */       throw new IllegalArgumentException("Parameter value out of bounds for parameter with index " + paramIndex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\TaLibMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */