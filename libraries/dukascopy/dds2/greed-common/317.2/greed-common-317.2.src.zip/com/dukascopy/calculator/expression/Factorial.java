/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.Base;
/*    */ import com.dukascopy.calculator.Notation;
/*    */ import com.dukascopy.calculator.StringArray;
/*    */ import com.dukascopy.calculator.function.SFunction;
/*    */ 
/*    */ public class Factorial extends Monadic
/*    */ {
/*    */   public Factorial(Expression expression)
/*    */   {
/* 12 */     super(new com.dukascopy.calculator.function.Factorial(), expression);
/*    */   }
/*    */   
/*    */ 
/*    */   public StringArray toHTMLSubString(int maxChars, int precision, Base base, Notation notation, double polarFactor)
/*    */   {
/* 18 */     StringArray s = new StringArray();
/* 19 */     s.addAll(this.expression.toHTMLParenString(maxChars, precision, base, notation, polarFactor));
/*    */     
/* 21 */     s.add(this.function.name_array());
/* 22 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Factorial.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */