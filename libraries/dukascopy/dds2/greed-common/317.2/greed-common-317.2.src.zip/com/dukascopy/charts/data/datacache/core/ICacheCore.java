package com.dukascopy.charts.data.datacache.core;

import com.dukascopy.charts.data.datacache.core.connection.ICacheConnection;
import com.dukascopy.charts.data.datacache.core.connection.ICacheReadConnection;
import com.dukascopy.charts.data.datacache.core.connection.ICacheWriteConnection;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeoutException;

public abstract interface ICacheCore
{
  public abstract ICacheReadConnection getCacheReadConnection(File paramFile)
    throws TimeoutException, IOException;
  
  public abstract ICacheReadConnection getCacheReadConnection(File paramFile, boolean paramBoolean)
    throws TimeoutException, IOException;
  
  public abstract ICacheWriteConnection getCacheWriteConnection(File paramFile)
    throws TimeoutException, IOException;
  
  public abstract ICacheWriteConnection getCacheWriteConnection(File paramFile, boolean paramBoolean)
    throws TimeoutException, IOException;
  
  public abstract void close(ICacheConnection paramICacheConnection)
    throws Exception;
  
  public abstract boolean cleanup(boolean paramBoolean)
    throws IOException;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\ICacheCore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */