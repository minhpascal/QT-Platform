/*    */ package com.dukascopy.api.impl.connect.strategy;
/*    */ 
/*    */ import com.dukascopy.api.strategy.IStrategyParameter;
/*    */ import com.dukascopy.dds2.greed.strategy.TransportHelper;
/*    */ import com.dukascopy.dds3.transport.msg.jss.StrategyParameter;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ public class StrategyParameterWrapper implements IStrategyParameter
/*    */ {
/*    */   private final String name;
/*    */   private final Object value;
/*    */   private final Class<?> type;
/*    */   
/*    */   public StrategyParameterWrapper(StrategyParameter parameter)
/*    */   {
/* 16 */     this.name = parameter.getName();
/* 17 */     this.value = parameter.getValue();
/* 18 */     this.type = TransportHelper.stringToType(parameter.getType());
/*    */   }
/*    */   
/*    */   public StrategyParameterWrapper(Field field, Object object) {
/* 22 */     this.name = field.getName();
/* 23 */     Object fieldValue = null;
/*    */     try {
/* 25 */       fieldValue = field.get(object);
/*    */     } catch (IllegalArgumentException e) {
/* 27 */       e.printStackTrace();
/*    */     } catch (IllegalAccessException e) {
/* 29 */       e.printStackTrace();
/*    */     }
/* 31 */     this.value = fieldValue;
/* 32 */     this.type = field.getType();
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */   public Object getValue()
/*    */   {
/* 42 */     return this.value;
/*    */   }
/*    */   
/*    */   public Class<?> getType()
/*    */   {
/* 47 */     return this.type;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     return String.format("%s=%s", new Object[] { this.name, this.value });
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\StrategyParameterWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */