/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.IBar;
/*     */ import com.dukascopy.api.IIndicators;
/*     */ import com.dukascopy.api.IIndicators.AppliedPrice;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.api.indicators.IIndicator;
/*     */ import com.dukascopy.api.indicators.IIndicatorCalculator;
/*     */ import com.dukascopy.api.indicators.IndicatorInfo;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Set;
/*     */ 
/*     */ class Calculator
/*     */ {
/*     */   private final IIndicators indicators;
/*     */   
/*     */   Calculator(IIndicators indicators)
/*     */   {
/*  22 */     this.indicators = indicators;
/*     */   }
/*     */   
/*     */   <T, U> IIndicatorCalculator<T, U> newInstance(String indName, IFeedDescriptor feedDescriptor, OfferSide[] sides, IIndicators.AppliedPrice[] appliedPrices, Object[] optInputs)
/*     */   {
/*  27 */     return new CalculatorInternal(indName, feedDescriptor, optInputs, appliedPrices, sides);
/*     */   }
/*     */   
/*  30 */   private static Set<String> takeOnly0thDim = new java.util.HashSet(Arrays.asList(new String[] { "HeikinAshi", "WADDAHAT", "WaddahAT", "PCHANNEL", "KAMA", "VolumeWAP", "FORCEI" }));
/*     */   
/*     */ 
/*     */ 
/*  34 */   private static Set<String> onlyByShift = new java.util.HashSet(Arrays.asList(new String[] { "THRUSTOUTSIDEBAR", "THRUSTBAR" }));
/*     */   
/*     */   private class CalculatorInternal<T, U>
/*     */     implements IIndicatorCalculator<T, U>
/*     */   {
/*     */     private final Object[] optInputs;
/*     */     private final IIndicators.AppliedPrice[] appliedPrices;
/*     */     private final OfferSide[] offerSides;
/*     */     private final String indName;
/*     */     private final IIndicator indicator;
/*     */     private final IFeedDescriptor feedDescriptor;
/*     */     
/*     */     protected CalculatorInternal(String indName, IFeedDescriptor feedDescriptor, Object[] optInputs, IIndicators.AppliedPrice[] appliedPrices, OfferSide[] offerSides)
/*     */     {
/*  48 */       this.indName = indName;
/*  49 */       this.feedDescriptor = feedDescriptor;
/*  50 */       this.optInputs = optInputs;
/*  51 */       this.appliedPrices = ((appliedPrices != null) && (appliedPrices.length == 0) ? null : appliedPrices);
/*     */       
/*     */ 
/*  54 */       this.offerSides = offerSides;
/*  55 */       this.indicator = Calculator.this.indicators.getIndicator(indName);
/*     */     }
/*     */     
/*     */     public T calculate(int shift) throws JFException
/*     */     {
/*  60 */       Object[] result = Calculator.this.indicators.calculateIndicator(this.feedDescriptor, this.offerSides, this.indName, this.appliedPrices, this.optInputs, shift);
/*  61 */       return (T)getResult(result, false);
/*     */     }
/*     */     
/*     */     public U calculate(long from, long to) throws JFException
/*     */     {
/*  66 */       Object[] result = Calculator.this.indicators.calculateIndicator(this.feedDescriptor, this.offerSides, this.indName, this.appliedPrices, this.optInputs, from, to);
/*  67 */       return (U)getResult(result, true);
/*     */     }
/*     */     
/*     */     public U calculate(int candlesBefore, long time, int candlesAfter) throws JFException
/*     */     {
/*  72 */       Object[] result = Calculator.this.indicators.calculateIndicator(this.feedDescriptor, this.offerSides, this.indName, this.appliedPrices, this.optInputs, candlesBefore, time, candlesAfter);
/*     */       
/*  74 */       return (U)getResult(result, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private <A> A getResult(Object[] result, boolean isArray)
/*     */     {
/*  81 */       String name = this.indicator.getIndicatorInfo().getName();
/*  82 */       if ((name.equals("HeikinAshi")) && (isArray)) {
/*  83 */         return Arrays.copyOf((Object[])result[0], ((Object[])result[0]).length, double[][].class);
/*     */       }
/*  85 */       int outputCount = this.indicator.getIndicatorInfo().getNumberOfOutputs();
/*  86 */       if ((outputCount == 1) || (Calculator.takeOnly0thDim.contains(name))) {
/*  87 */         return (A)result[0];
/*     */       }
/*     */       
/*  90 */       A arr = Array.newInstance(getType(isArray, Calculator.onlyByShift.contains(name) ? 2 : 0), outputCount);
/*  91 */       for (int i = 0; i < outputCount; i++) {
/*  92 */         if ((name.equals("ICHIMOKU")) && ((i == 5) || (i == 6))) {
/*  93 */           Array.set(arr, i, isArray ? ((Object[])(Object[])result[5])[(i - 5)] : Double.valueOf(((double[])(double[])result[5])[(i - 5)]));
/*     */         }
/*  95 */         else if ((Calculator.onlyByShift.contains(name)) && ((i == 0) || (i == 1)) && (!isArray)) {
/*  96 */           Array.set(arr, i, (Integer)result[i]);
/*     */         }
/*     */         else
/*  99 */           Array.set(arr, i, result[i]);
/*     */       }
/* 101 */       return arr;
/*     */     }
/*     */     
/*     */     private Class<?> getType(boolean isArray, int outputIdx) {
/* 105 */       switch (Calculator.1.$SwitchMap$com$dukascopy$api$indicators$OutputParameterInfo$Type[this.indicator.getOutputParameterInfo(outputIdx).getType().ordinal()]) {
/*     */       case 1: 
/* 107 */         return isArray ? IBar[].class : IBar.class;
/*     */       case 2: 
/* 109 */         return isArray ? double[].class : Double.TYPE;
/*     */       case 3: 
/* 111 */         return isArray ? int[].class : Integer.TYPE;
/*     */       }
/* 113 */       return isArray ? Object[].class : Object.class;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\Calculator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */