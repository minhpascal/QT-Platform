/*    */ package com.dukascopy.charts.data.datacache.intraperiod;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*    */ 
/*    */ public class LastBarLoadingProgressListener
/*    */   implements ILoadingProgressListener
/*    */ {
/*  8 */   private volatile boolean stopJob = false;
/*    */   
/*    */   public void dataLoaded(long start, long end, long currentPosition, String information) {}
/*    */   
/*    */   public void loadingFinished(boolean allDataLoaded, long start, long end, long currentPosition, Throwable e) {}
/*    */   
/*    */   public boolean stopJob() {
/* 15 */     return this.stopJob;
/*    */   }
/*    */   
/*    */   public void setStopJob(boolean stop) {
/* 19 */     this.stopJob = stop;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\intraperiod\LastBarLoadingProgressListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */