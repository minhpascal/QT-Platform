/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Multiply
/*    */   extends MFunction
/*    */ {
/*    */   public Multiply()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.multiplication";
/* 15 */     this.fshortcut = '*';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x, double y)
/*    */   {
/* 25 */     return x * y;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x, OObject y)
/*    */   {
/* 35 */     return x.multiply(y);
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 39 */     return fname;
/*    */   }
/*    */   
/* 42 */   private static final String[] fname = { "&#215;" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Multiply.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */