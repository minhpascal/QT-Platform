/*    */ package com.dukascopy.charts.data.datacache.core.lock;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandlerSyncronizerCounter
/*    */ {
/*    */   private AtomicInteger counter;
/*    */   
/*    */   public HandlerSyncronizerCounter(int counter)
/*    */   {
/* 17 */     this.counter = new AtomicInteger(counter);
/*    */   }
/*    */   
/*    */   public int inc() {
/* 21 */     return this.counter.incrementAndGet();
/*    */   }
/*    */   
/*    */   public int dec() {
/* 25 */     return this.counter.decrementAndGet();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 30 */     return "counter=" + this.counter;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 35 */     int prime = 31;
/* 36 */     int result = 1;
/* 37 */     result = 31 * result + (this.counter == null ? 0 : this.counter.hashCode());
/* 38 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 43 */     if (this == obj)
/* 44 */       return true;
/* 45 */     if (obj == null)
/* 46 */       return false;
/* 47 */     if (getClass() != obj.getClass())
/* 48 */       return false;
/* 49 */     HandlerSyncronizerCounter other = (HandlerSyncronizerCounter)obj;
/* 50 */     if (this.counter == null) {
/* 51 */       if (other.counter != null)
/* 52 */         return false;
/* 53 */     } else if (this.counter.get() != other.counter.get())
/* 54 */       return false;
/* 55 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\core\lock\HandlerSyncronizerCounter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */