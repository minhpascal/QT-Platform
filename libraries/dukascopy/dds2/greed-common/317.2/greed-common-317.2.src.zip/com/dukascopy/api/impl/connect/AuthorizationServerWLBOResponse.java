/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.json.JSONObject;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class AuthorizationServerWLBOResponse
/*     */   extends AbstractAuthorizationServerResponse
/*     */ {
/*  10 */   private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationServerStsTokenResponse.class);
/*     */   
/*     */   private static final String AUTH_TICKET_PARAM_NAME = "authTicket";
/*     */   
/*     */   private static final String SID_PARAM_NAME = "sid";
/*     */   private static final String READONLY_PARAM_NAME = "readOnly";
/*     */   private static final String AUTH_API_URL_PARAM_NAME = "authApiURL";
/*     */   private static final String LOGIN_PARAM_NAME = "login";
/*     */   private String authTicket;
/*     */   private String sid;
/*     */   private boolean readOnly;
/*     */   private String authApiURL;
/*     */   private String login;
/*     */   private String error;
/*     */   
/*     */   public AuthorizationServerWLBOResponse(AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode)
/*     */   {
/*  27 */     this.responseMessage = null;
/*  28 */     this.responseCode = authorizationServerResponseCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AuthorizationServerWLBOResponse(String responseMessage, AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode)
/*     */   {
/*  35 */     this.responseMessage = null;
/*  36 */     this.responseCode = authorizationServerResponseCode;
/*     */     
/*  38 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AuthorizationServerWLBOResponse(String responseMessage, int authorizationServerResponseCode)
/*     */   {
/*  45 */     this.responseMessage = responseMessage;
/*  46 */     this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.fromValue(authorizationServerResponseCode);
/*     */     
/*  48 */     init();
/*     */   }
/*     */   
/*     */   public String getError() {
/*  52 */     return this.error;
/*     */   }
/*     */   
/*     */   protected void validateResponse(String authorizationResponse)
/*     */   {
/*  57 */     if ((authorizationResponse == null) || (authorizationResponse.length() == 0)) {
/*  58 */       this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.EMPTY_RESPONSE;
/*     */     } else {
/*     */       try {
/*  61 */         JSONObject jsonObject = new JSONObject(authorizationResponse, false);
/*     */         
/*  63 */         if (!jsonObject.isNull("error")) {
/*  64 */           this.error = jsonObject.getString("error");
/*  65 */           if (this.error != null) {
/*  66 */             this.error.trim();
/*     */           }
/*     */         }
/*     */         
/*  70 */         if ((this.error != null) && (this.error.length() > 0)) {
/*  71 */           LOGGER.error("Error [" + authorizationResponse + "]");
/*  72 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/*  73 */           return;
/*     */         }
/*     */         
/*  76 */         this.authTicket = jsonObject.getString("authTicket");
/*  77 */         this.sid = jsonObject.getString("sid");
/*  78 */         this.readOnly = jsonObject.getBoolean("readOnly");
/*  79 */         this.authApiURL = jsonObject.getString("authApiURL");
/*  80 */         this.login = jsonObject.getString("login");
/*     */         
/*  82 */         if (this.authApiURL != null) {
/*  83 */           this.authApiURL = this.authApiURL.trim();
/*     */         }
/*     */         
/*  86 */         if (isEmpty(this.authTicket)) {
/*  87 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/*  88 */           LOGGER.error("Wrong authTicket [" + authorizationResponse + "]");
/*  89 */           return;
/*     */         }
/*     */         
/*  92 */         if (isEmpty(this.sid)) {
/*  93 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/*  94 */           LOGGER.error("Wrong sid [" + authorizationResponse + "]");
/*  95 */           return;
/*     */         }
/*     */         
/*  98 */         if (isEmpty(this.authApiURL)) {
/*  99 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/* 100 */           LOGGER.error("Wrong authApiURL [" + authorizationResponse + "]");
/* 101 */           return;
/*     */         }
/*     */         
/* 104 */         if (isEmpty(this.login)) {
/* 105 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/* 106 */           LOGGER.error("Wrong login [" + authorizationResponse + "]");
/* 107 */           return;
/*     */         }
/*     */       } catch (Throwable e) {
/* 110 */         LOGGER.error(e.getMessage(), e);
/* 111 */         this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/* 112 */         LOGGER.error("Cannot parse the authorization answer [" + authorizationResponse + "]");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isEmpty(String message) {
/* 118 */     if (message != null) {
/* 119 */       message = message.trim();
/*     */     }
/*     */     
/* 122 */     if ((message == null) || (message.isEmpty())) {
/* 123 */       return true;
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public String getAuthTicket()
/*     */   {
/* 130 */     return this.authTicket;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 134 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public String getAuthApiURL() {
/* 138 */     return this.authApiURL;
/*     */   }
/*     */   
/*     */   public String getLogin() {
/* 142 */     return this.login;
/*     */   }
/*     */   
/*     */   public String getSid() {
/* 146 */     return this.sid;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\AuthorizationServerWLBOResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */