/*    */ package com.dukascopy.calculator.function;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Square
/*    */   extends LFunction
/*    */ {
/*    */   public Square()
/*    */   {
/* 14 */     this.ftooltip = "sc.calculator.square.of.x";
/* 15 */     this.fshortcut = 'q';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double function(double x)
/*    */   {
/* 24 */     return x * x;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject function(OObject x)
/*    */   {
/* 33 */     return x.square();
/*    */   }
/*    */   
/*    */   public String[] name_array() {
/* 37 */     return fname;
/*    */   }
/*    */   
/*    */   public String shortName() {
/* 41 */     return "<i>x</i><sup>2</sup>";
/*    */   }
/*    */   
/* 44 */   private static final String[] fname = { "<sup>2</sup>" };
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\function\Square.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */