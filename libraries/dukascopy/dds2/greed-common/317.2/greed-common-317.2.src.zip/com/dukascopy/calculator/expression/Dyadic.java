/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ public abstract class Dyadic<E extends com.dukascopy.calculator.function.PObject> extends Expression { protected E function;
/*    */   protected OObject expression1;
/*    */   protected OObject expression2;
/*    */   
/*  9 */   public Dyadic(E function, OObject expression1, OObject expression2) { this.function = function;
/* 10 */     this.expression1 = expression1;
/* 11 */     this.expression2 = expression2;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public com.dukascopy.calculator.StringArray toHTMLSubString(int maxChars, int precision, com.dukascopy.calculator.Base base, com.dukascopy.calculator.Notation notation, double polarFactor)
/*    */   {
/* 28 */     com.dukascopy.calculator.StringArray s = new com.dukascopy.calculator.StringArray();
/* 29 */     s.addAll(this.expression1.toHTMLParenString(maxChars, precision, base, notation, polarFactor));
/*    */     
/* 31 */     s.add(this.function.name_array());
/* 32 */     s.addAll(this.expression2.toHTMLParenString(maxChars, precision, base, notation, polarFactor));
/*    */     
/* 34 */     return s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OObject auto_simplify()
/*    */   {
/* 42 */     this.expression1 = this.expression1.auto_simplify();
/* 43 */     this.expression2 = this.expression2.auto_simplify();
/* 44 */     if (((this.expression1 instanceof com.dukascopy.calculator.Error)) || ((this.expression1 instanceof com.dukascopy.calculator.Error)))
/*    */     {
/* 46 */       return new com.dukascopy.calculator.Error("Function auto_simplify() error");
/*    */     }
/* 48 */     return this;
/*    */   }
/*    */   
/*    */   public OObject substitute(com.dukascopy.calculator.Substitution substitution) {
/* 52 */     if ((this.function instanceof com.dukascopy.calculator.function.DFunction)) {
/* 53 */       com.dukascopy.calculator.function.DFunction d = (com.dukascopy.calculator.function.DFunction)this.function;
/* 54 */       return d.function(this.expression1.substitute(substitution), this.expression2.substitute(substitution));
/*    */     }
/*    */     
/* 57 */     return new com.dukascopy.calculator.Error("Dyadic.substitute Error");
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Dyadic.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */