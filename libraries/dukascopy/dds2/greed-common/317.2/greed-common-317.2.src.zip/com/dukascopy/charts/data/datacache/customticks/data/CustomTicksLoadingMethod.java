package com.dukascopy.charts.data.datacache.customticks.data;

public enum CustomTicksLoadingMethod
{
  OPEN_TICK,  CLOSE_TICK,  FOUR_TICKS,  CUBIC_SPLINE,  ALL_TICKS,  DIFFERENT_PRICE_TICKS,  PIVOT_TICKS,  TICKS_WITH_PRICE_DIFFERENCE_IN_PIPS,  TICKS_WITH_TIME_INTERVAL;
  
  private CustomTicksLoadingMethod() {}
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\data\CustomTicksLoadingMethod.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */