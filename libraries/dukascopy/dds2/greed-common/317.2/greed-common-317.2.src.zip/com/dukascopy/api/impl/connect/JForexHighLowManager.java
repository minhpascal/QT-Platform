/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IStrategyListener;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.charts.data.datacache.hl.ICommonHighLowListener;
/*     */ import com.dukascopy.charts.data.datacache.hl.IHighLowManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JForexHighLowManager
/*     */   implements IHighLowManager, IStrategyListener
/*     */ {
/*  34 */   private static final Logger LOGGER = LoggerFactory.getLogger(JForexHighLowManager.class);
/*     */   
/*     */   private Set<ICommonHighLowListener> highLowListeners;
/*     */   
/*     */   protected final IHighLowManager highLowManager;
/*     */   
/*     */ 
/*     */   public JForexHighLowManager(IHighLowManager highLowManager)
/*     */   {
/*  43 */     this.highLowManager = highLowManager;
/*  44 */     this.highLowListeners = Collections.synchronizedSet(new HashSet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addHighLowListener(Instrument instrument, ICommonHighLowListener listener)
/*     */   {
/*  52 */     if ((instrument != null) && (listener != null)) {
/*  53 */       this.highLowListeners.add(listener);
/*  54 */       this.highLowManager.addHighLowListener(instrument, listener);
/*     */     } else {
/*  56 */       LOGGER.warn("Cannot add new HighLowListener. Instrument and listener must not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Instrument, List<ICommonHighLowListener>> getHighLowListeners()
/*     */   {
/*  65 */     Map<Instrument, List<ICommonHighLowListener>> highLowListenersByInstrument = new HashMap(this.highLowManager.getHighLowListeners());
/*  66 */     synchronized (this.highLowListeners) {
/*  67 */       for (List<ICommonHighLowListener> highLowListenerList : highLowListenersByInstrument.values()) {
/*  68 */         highLowListenerList.retainAll(this.highLowListeners);
/*     */       }
/*     */     }
/*  71 */     return highLowListenersByInstrument;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeHighLowListener(ICommonHighLowListener listener)
/*     */   {
/*  79 */     if (listener != null) {
/*  80 */       this.highLowManager.removeHighLowListener(listener);
/*  81 */       this.highLowListeners.remove(listener);
/*     */     } else {
/*  83 */       LOGGER.warn("Cannot remove HighLowListener. Listener must not be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ICommonHighLowListener> getHighLowListeners(Instrument instrument)
/*     */   {
/*  90 */     List<ICommonHighLowListener> highLowListenerList = Collections.emptyList();
/*  91 */     if (instrument != null) {
/*  92 */       highLowListenerList = new ArrayList(this.highLowManager.getHighLowListeners(instrument));
/*  93 */       synchronized (this.highLowListeners) {
/*  94 */         highLowListenerList.retainAll(this.highLowListeners);
/*     */       }
/*     */     } else {
/*  97 */       LOGGER.warn("Cannot get a list of HighLowListeners by Instrument. Instrument must not be null");
/*     */     }
/*  99 */     return highLowListenerList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAllListeners()
/*     */   {
/* 108 */     synchronized (this.highLowListeners) {
/* 109 */       for (ICommonHighLowListener highLowListener : this.highLowListeners) {
/* 110 */         removeHighLowListener(highLowListener);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol)
/*     */   {
/* 121 */     this.highLowManager.newTick(instrument, time, ask, bid, askVol, bidVol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol)
/*     */   {
/* 129 */     this.highLowManager.newCandle(instrument, period, side, time, open, close, low, high, vol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onStart(long strategyId) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onStop(long strategyId)
/*     */   {
/* 145 */     removeAllListeners();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Period getTargetPeriod()
/*     */   {
/* 153 */     return this.highLowManager.getTargetPeriod();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexHighLowManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */