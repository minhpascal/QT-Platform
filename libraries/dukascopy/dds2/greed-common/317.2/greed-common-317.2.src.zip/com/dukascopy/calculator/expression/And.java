/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.OObject;
/*    */ 
/*    */ public class And extends Dyadic<com.dukascopy.calculator.function.BoolFunction> {
/*    */   public And(OObject expression1, OObject expression2) {
/*  7 */     super(new com.dukascopy.calculator.function.And(), expression1, expression2);
/*    */   }
/*    */   
/*    */   public Product negate() {
/* 11 */     Product p = new Product(this, false);
/* 12 */     return p.negate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\And.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */