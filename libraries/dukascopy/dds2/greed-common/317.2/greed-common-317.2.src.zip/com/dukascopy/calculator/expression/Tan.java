/*    */ package com.dukascopy.calculator.expression;
/*    */ 
/*    */ import com.dukascopy.calculator.AngleType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tan
/*    */   extends Monadic
/*    */ {
/*    */   public Tan(Expression expression, AngleType angleType)
/*    */   {
/* 12 */     super(new com.dukascopy.calculator.function.Tan(angleType), expression);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Tan.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */