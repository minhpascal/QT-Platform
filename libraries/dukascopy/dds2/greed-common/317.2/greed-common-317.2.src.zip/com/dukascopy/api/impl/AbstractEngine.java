/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.ICurrency;
/*    */ import com.dukascopy.api.IEngine.OrderCommand;
/*    */ import com.dukascopy.api.IOrder;
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.impl.connect.ILotAmountProvider;
/*    */ import com.dukascopy.api.impl.connect.JForexAPI;
/*    */ import java.math.BigDecimal;
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractEngine
/*    */ {
/* 22 */   protected static final ThreadLocal<DateFormat> DATE_FORMAT_THREAD_LOCAL = new ThreadLocal()
/*    */   {
/*    */     protected DateFormat initialValue() {
/* 25 */       SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS 'GMT'");
/* 26 */       dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
/* 27 */       return dateFormat;
/*    */     }
/*    */   };
/*    */   
/*    */   protected String generateNotificationMessage(IOrder order, String strategyName, double slippage, boolean local)
/*    */   {
/* 33 */     IEngine.OrderCommand orderCommand = order.getOrderCommand();
/* 34 */     Instrument instrument = order.getInstrument();
/* 35 */     String goodTillTime = order.getGoodTillTime() == 0L ? "GTC" : ((DateFormat)DATE_FORMAT_THREAD_LOCAL.get()).format(Long.valueOf(order.getGoodTillTime()));
/* 36 */     double openPrice = order.getOpenPrice();
/* 37 */     String price = BigDecimal.valueOf(order.getOpenPrice()).toPlainString();
/* 38 */     String amount = BigDecimal.valueOf(order.getAmount()).multiply(BigDecimal.valueOf(1000000L)).stripTrailingZeros().toPlainString();
/*    */     
/*    */ 
/*    */ 
/* 42 */     StringBuilder messageContent = new StringBuilder("Order ");
/* 43 */     messageContent.append((orderCommand.isConditional() ? "ENTRY " : "") + (orderCommand.isLong() ? "BUY" : "SELL"));
/*    */     
/* 45 */     messageContent.append(" ").append(amount);
/* 46 */     messageContent.append(" ").append(instrument).append(" @ ");
/*    */     
/* 48 */     if (JForexAPI.isPlaceBidOffer(orderCommand)) {
/* 49 */       messageContent.append(price);
/* 50 */       messageContent.append(" EXPIRES:" + goodTillTime);
/* 51 */     } else if ((!orderCommand.isConditional()) || (Double.isNaN(slippage))) {
/* 52 */       messageContent.append("MKT ");
/*    */     } else {
/* 54 */       double limitSlippage = Double.isNaN(slippage) ? 0.0D : slippage;
/* 55 */       String conditionalPrice = orderCommand.isLong() ? BigDecimal.valueOf(openPrice).add(BigDecimal.valueOf(limitSlippage)).toPlainString() : BigDecimal.valueOf(openPrice).subtract(BigDecimal.valueOf(limitSlippage)).toPlainString();
/* 56 */       messageContent.append("LIMIT ");
/* 57 */       messageContent.append(conditionalPrice);
/*    */     }
/* 59 */     if (orderCommand.isConditional()) {
/* 60 */       messageContent.append(" IF ");
/* 61 */       messageContent.append((orderCommand == IEngine.OrderCommand.BUYLIMIT) || (orderCommand == IEngine.OrderCommand.BUYSTOP) || (orderCommand == IEngine.OrderCommand.SELLLIMIT_BYASK) || (orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "ASK" : "BID");
/* 62 */       messageContent.append(" ").append((orderCommand == IEngine.OrderCommand.BUYLIMIT) || (orderCommand == IEngine.OrderCommand.BUYLIMIT_BYBID) || (orderCommand == IEngine.OrderCommand.SELLSTOP) || (orderCommand == IEngine.OrderCommand.SELLSTOP_BYASK) ? "<=" : "=>");
/* 63 */       messageContent.append(" ").append(price);
/*    */     }
/* 65 */     messageContent.append(" is sent at ").append(((DateFormat)DATE_FORMAT_THREAD_LOCAL.get()).format(Long.valueOf(System.currentTimeMillis()))).append(" by the strategy \"").append(strategyName).append("\": from the ");
/* 66 */     messageContent.append(local ? "local computer" : "remote server");
/* 67 */     return messageContent.toString();
/*    */   }
/*    */   
/*    */   protected String generateSubmitRejectFormat(IOrder order)
/*    */   {
/* 72 */     IEngine.OrderCommand orderCommand = order.getOrderCommand();
/* 73 */     Instrument instrument = order.getInstrument();
/* 74 */     String orderCommandString = (orderCommand.isConditional() ? "CONDITIONAL " : "") + (orderCommand.isLong() ? "BUY" : "SELL");
/*    */     
/*    */ 
/* 77 */     return String.format("Order REJECTED: %s %s, REASON: %%s", new Object[] { orderCommandString, instrument });
/*    */   }
/*    */   
/*    */   protected String generateFeedCommissionWarning(Instrument instrument) {
/* 81 */     return String.format("Unable to submit \"Place bid\" or \"Place offer\" orders. Instrument \"%s\" has feed commissions.", new Object[] { instrument });
/*    */   }
/*    */   
/*    */   protected abstract ILotAmountProvider getLotAmountProvider();
/*    */   
/*    */   protected abstract ICurrency getAccountCurrency();
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\AbstractEngine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */