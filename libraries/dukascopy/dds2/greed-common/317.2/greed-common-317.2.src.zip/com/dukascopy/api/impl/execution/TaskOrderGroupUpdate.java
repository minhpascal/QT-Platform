/*     */ package com.dukascopy.api.impl.execution;
/*     */ 
/*     */ import com.dukascopy.api.IMessage;
/*     */ import com.dukascopy.api.IOrder.State;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*     */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*     */ import com.dukascopy.api.impl.connect.OrdersInternalCollection;
/*     */ import com.dukascopy.api.impl.connect.PlatformOrderImpl;
/*     */ import com.dukascopy.api.plugins.IMessageListener;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*     */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import com.dukascopy.dds3.transport.msg.ord.OrderGroupMessage;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.List;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskOrderGroupUpdate
/*     */   implements Task
/*     */ {
/*  29 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskOrderGroupUpdate.class);
/*     */   private IMessageListener strategy;
/*     */   private OrderGroupMessage orderGroupMessage;
/*     */   private JForexTaskManager taskManager;
/*     */   private StrategyEventsCallback strategyEventsCallback;
/*     */   
/*     */   public TaskOrderGroupUpdate(JForexTaskManager taskManager, IMessageListener strategy, OrderGroupMessage orderGroupMessage)
/*     */   {
/*  37 */     this.strategy = strategy;
/*  38 */     this.orderGroupMessage = orderGroupMessage;
/*  39 */     this.taskManager = taskManager;
/*  40 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*     */   }
/*     */   
/*     */   public Task.Type getType()
/*     */   {
/*  45 */     return Task.Type.MESSAGE;
/*     */   }
/*     */   
/*     */   public Object call() throws Exception
/*     */   {
/*  50 */     if (this.taskManager.isStrategyStopping()) {
/*  51 */       return null;
/*     */     }
/*  53 */     if (LOGGER.isDebugEnabled()) {
/*  54 */       LOGGER.debug("Starting processing of order group message [" + this.orderGroupMessage + "]");
/*     */     }
/*     */     try {
/*  57 */       OrdersInternalCollection ordersInternalCollection = this.taskManager.getOrdersInternalCollection();
/*  58 */       PlatformOrderImpl platformOrderImpl = null;
/*  59 */       String orderGroupId = this.orderGroupMessage.getOrderGroupId();
/*  60 */       if (orderGroupId != null) {
/*  61 */         platformOrderImpl = ordersInternalCollection.getOrderById(orderGroupId);
/*     */       }
/*     */       
/*  64 */       String label = PlatformOrderImpl.extractLabel(this.orderGroupMessage);
/*  65 */       if ((platformOrderImpl == null) && (label != null)) {
/*  66 */         platformOrderImpl = ordersInternalCollection.getOrderByLabel(label);
/*  67 */         if ((platformOrderImpl != null) && (platformOrderImpl.getState() != IOrder.State.CREATED)) {
/*  68 */           LOGGER.warn("Getting order by label [" + label + "] instead of order id");
/*     */         }
/*     */       }
/*     */       
/*  72 */       if (platformOrderImpl == null) {
/*  73 */         if (label == null) {
/*  74 */           if (!this.taskManager.isGlobal()) {
/*  75 */             LOGGER.warn("Order group message received that doesn't have assigned external id. Order group id [" + orderGroupId + "]");
/*  76 */             this.orderGroupMessage.setExternalSysId(orderGroupId);
/*     */           }
/*  78 */           label = orderGroupId;
/*     */         }
/*  80 */         if (this.orderGroupMessage.getOrders().size() > 0) {
/*  81 */           platformOrderImpl = new PlatformOrderImpl(this.taskManager);
/*     */           try {
/*  83 */             ordersInternalCollection.put(label, platformOrderImpl, false);
/*     */           } catch (JFException e) {
/*  85 */             LOGGER.error(e.getMessage(), e);
/*     */           }
/*  87 */         } else if ((this.taskManager.isGlobal()) && (this.orderGroupMessage.getAmount() != null) && (this.orderGroupMessage.getAmount().compareTo(BigDecimal.ZERO) > 0)) {
/*  88 */           platformOrderImpl = new PlatformOrderImpl(this.taskManager);
/*     */           try {
/*  90 */             ordersInternalCollection.put(label, platformOrderImpl, false);
/*     */           } catch (JFException e) {
/*  92 */             LOGGER.error(e.getMessage(), e);
/*     */           }
/*  94 */         } else if ((this.orderGroupMessage.isOcoMerge()) && (this.orderGroupMessage.getAmount() != null) && (this.orderGroupMessage.getAmount().compareTo(BigDecimal.ZERO) == 0))
/*     */         {
/*  96 */           platformOrderImpl = new PlatformOrderImpl(this.taskManager);
/*     */           try {
/*  98 */             ordersInternalCollection.put(label, platformOrderImpl, false);
/*     */           } catch (JFException e) {
/* 100 */             LOGGER.error(e.getMessage(), e);
/*     */           }
/*     */         }
/*     */         else {
/* 104 */           return null;
/*     */         }
/*     */       }
/*     */       
/* 108 */       IMessage platformMessageImpl = platformOrderImpl.update(this.orderGroupMessage);
/*     */       
/* 110 */       if (platformMessageImpl != null) {
/* 111 */         this.strategy.onMessage(platformMessageImpl);
/* 112 */         if (this.strategyEventsCallback != null) {
/* 113 */           this.strategyEventsCallback.onMessage(platformMessageImpl);
/*     */         }
/*     */       }
/*     */     } catch (Throwable t) {
/* 117 */       String msg = ErrorHelper.representError(this.strategy, t);
/* 118 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 119 */       LOGGER.error(t.getMessage(), t);
/* 120 */       this.taskManager.getExceptionHandler().onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_MESSAGE, t);
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 127 */     return "TaskOrderGroupUpdate [" + this.orderGroupMessage + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskOrderGroupUpdate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */