/*    */ package com.dukascopy.api.impl.connect.strategy.local;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.strategy.StrategyDescriptor;
/*    */ import com.dukascopy.api.strategy.IStrategyParameter;
/*    */ import com.dukascopy.api.strategy.local.ILocalStrategyDescriptor;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.bean.StrategyNewBean;
/*    */ import com.dukascopy.dds2.greed.util.ParameterUtils;
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class LocalStrategyDescriptor extends StrategyDescriptor implements ILocalStrategyDescriptor
/*    */ {
/*    */   private final File file;
/*    */   
/*    */   public LocalStrategyDescriptor(long processId, StrategyNewBean bean)
/*    */   {
/* 18 */     this(bean.getName(), bean.getStartingTimestamp(), ParameterUtils.getParameters((com.dukascopy.api.IStrategy)bean.getJFRunnable()), new UUID(processId, 0L), null, bean.getBinaryFile());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LocalStrategyDescriptor(String name, long startTime, List<IStrategyParameter> parameters, UUID id, String comments, File file)
/*    */   {
/* 29 */     super(name, startTime, parameters, id, comments);
/* 30 */     this.file = file;
/*    */   }
/*    */   
/*    */   public File getFile()
/*    */   {
/* 35 */     return this.file;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\strategy\local\LocalStrategyDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */