/*     */ package com.dukascopy.api.impl.email;
/*     */ 
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.util.IEmailResponse;
/*     */ import com.dukascopy.dds3.transport.msg.sms.EmailMessage;
/*     */ import com.dukascopy.dds3.transport.msg.sms.EmailResponseMessage;
/*     */ import com.dukascopy.dds4.transport.client.TransportClient;
/*     */ import com.dukascopy.dds4.transport.common.mina.ClientListener;
/*     */ import com.dukascopy.dds4.transport.common.mina.DisconnectedEvent;
/*     */ import com.dukascopy.dds4.transport.common.mina.ITransportClient;
/*     */ import com.dukascopy.dds4.transport.msg.system.ProtocolMessage;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ public class EmailManager
/*     */   implements IEmailManager
/*     */ {
/*  27 */   private static final Logger LOGGER = LoggerFactory.getLogger(EmailManager.class);
/*     */   
/*  29 */   private static final long REQUEST_TIMEOUT = TimeUnit.SECONDS.toMillis(60L);
/*     */   
/*     */   private static final int MAX_EMAIL_TEXT_LENGTH = 500;
/*     */   
/*     */   private static final int MAX_EMAIL_SUBJECT_LENGTH = 200;
/*     */   private static final long MIN_EMAIL_SEND_INTERVAL_MILLIS = 1000L;
/*  35 */   protected final ExecutorService executor = Executors.newFixedThreadPool(2);
/*  36 */   protected final Map<UUID, IEmailResponse> requestResponseMap = new HashMap();
/*  37 */   private long lastSendAttemptTime = 0L;
/*     */   
/*     */   private ClientListener clientListener;
/*     */   
/*     */   private TransportClient transportClient;
/*     */   private String userId;
/*     */   
/*     */   public void setup(TransportClient transportClient, String userId)
/*     */   {
/*  46 */     this.transportClient = transportClient;
/*  47 */     if (this.clientListener != null) {
/*  48 */       transportClient.removeListener(this.clientListener);
/*     */     }
/*  50 */     this.userId = userId;
/*  51 */     this.clientListener = new ClientListener()
/*     */     {
/*     */       public void feedbackMessageReceived(ITransportClient client, ProtocolMessage message)
/*     */       {
/*  55 */         if ((message instanceof EmailResponseMessage)) {
/*  56 */           EmailManager.LOGGER.debug("e-mail response received: " + message);
/*  57 */           EmailResponseMessage msg = (EmailResponseMessage)message;
/*  58 */           IEmailResponse response = new EmailResponse(msg);
/*  59 */           EmailManager.this.processResponse(UUID.fromString(msg.getRequestId()), response);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void disconnected(DisconnectedEvent disconnectedEvent) {}
/*     */       
/*     */ 
/*     */ 
/*     */       public void authorized(ITransportClient client) {}
/*  70 */     };
/*  71 */     transportClient.addListener(this.clientListener);
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/*  76 */     if ((this.clientListener != null) && (this.transportClient != null)) {
/*  77 */       this.transportClient.removeListener(this.clientListener);
/*     */     }
/*  79 */     this.transportClient = null;
/*     */   }
/*     */   
/*     */   public Future<IEmailResponse> sendMail(String to, String subject, String content) throws JFException
/*     */   {
/*  84 */     if (this.transportClient == null) {
/*  85 */       throw new JFException("Can't send the e-mail. The servers are not connected.");
/*     */     }
/*  87 */     if ((to == null) || (subject == null) || (content == null)) {
/*  88 */       String str = "Null parameters not allowed - passed null for: " + (to == null ? "to, " : "") + (subject == null ? "subject, " : "") + (content == null ? "content, " : "");
/*     */       
/*     */ 
/*     */ 
/*  92 */       throw new JFException(str.substring(0, str.length() - 3));
/*     */     }
/*  94 */     if ((content != null) && (content.length() > 500)) {
/*  95 */       throw new JFException(String.format("Text length of %s exceeds the allowed maximum length of %s", new Object[] { Integer.valueOf(content.length()), Integer.valueOf(500) }));
/*     */     }
/*     */     
/*  98 */     if ((subject != null) && (subject.length() > 200)) {
/*  99 */       throw new JFException(String.format("Text length of %s exceeds the allowed maximum length of %s", new Object[] { Integer.valueOf(subject.length()), Integer.valueOf(500) }));
/*     */     }
/*     */     
/* 102 */     if (System.currentTimeMillis() - this.lastSendAttemptTime < 1000L) {
/* 103 */       throw new JFException(String.format("Last e-mail send attempt was %sms ago which is less than the minimum interval of %sms", new Object[] { Long.valueOf(System.currentTimeMillis() - this.lastSendAttemptTime), Long.valueOf(1000L) }));
/*     */     }
/*     */     
/* 106 */     this.lastSendAttemptTime = System.currentTimeMillis();
/* 107 */     EmailMessage email = new EmailMessage();
/* 108 */     UUID id = UUID.randomUUID();
/* 109 */     email.setUserId(this.userId);
/* 110 */     email.setRequestId(id.toString());
/* 111 */     email.setSubject(subject);
/* 112 */     email.setBody(content);
/* 113 */     email.setRecipient(to);
/* 114 */     LOGGER.debug("sending e-mail: " + email);
/* 115 */     Future<IEmailResponse> future = processRequest(id);
/* 116 */     this.transportClient.controlRequest(email);
/* 117 */     return future;
/*     */   }
/*     */   
/*     */   private Future<IEmailResponse> processRequest(final UUID requestId) {
/* 121 */     synchronized (this.requestResponseMap) {
/* 122 */       this.requestResponseMap.put(requestId, null);
/*     */     }
/*     */     
/* 125 */     Callable<IEmailResponse> callable = new Callable()
/*     */     {
/*     */       public IEmailResponse call() throws Exception {
/* 128 */         synchronized (requestId)
/*     */         {
/* 130 */           if (EmailManager.this.requestResponseMap.get(requestId) == null) {
/* 131 */             requestId.wait(EmailManager.REQUEST_TIMEOUT);
/*     */           }
/*     */         }
/* 134 */         synchronized (EmailManager.this.requestResponseMap) {
/* 135 */           IEmailResponse responseValue = (IEmailResponse)EmailManager.this.requestResponseMap.remove(requestId);
/* 136 */           if (responseValue == null) {
/* 137 */             return new EmailResponse("E-mail request " + requestId + " timed out!");
/*     */           }
/* 139 */           return responseValue;
/*     */         }
/*     */       }
/* 142 */     };
/* 143 */     return this.executor.submit(callable);
/*     */   }
/*     */   
/*     */   private void processResponse(UUID requestId, IEmailResponse response) {
/* 147 */     synchronized (this.requestResponseMap)
/*     */     {
/* 149 */       if (!this.requestResponseMap.containsKey(requestId)) {
/* 150 */         return;
/*     */       }
/*     */       
/* 153 */       for (UUID id : this.requestResponseMap.keySet()) {
/* 154 */         if (id.equals(requestId)) {
/* 155 */           synchronized (id) {
/*     */             try {
/* 157 */               this.requestResponseMap.put(id, response);
/*     */             } catch (Exception e) {
/* 159 */               LOGGER.error(e.getMessage(), e);
/*     */             }
/* 161 */             id.notifyAll();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\email\EmailManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */