/*    */ package com.dukascopy.charts.data.datacache.customticks.candletoticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.tester.CubicSplineInterpolation;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class CubicSpLineCandleToTicksConverter
/*    */   implements ICandleToTicksConverter
/*    */ {
/*    */   private Instrument instrument;
/*    */   private OfferSide offerSide;
/*    */   private final double spreadInPips;
/*    */   private final long length;
/*    */   
/*    */   public CubicSpLineCandleToTicksConverter(Instrument instrument, OfferSide offerSide, Period period)
/*    */   {
/* 21 */     this.instrument = instrument;
/* 22 */     this.offerSide = offerSide;
/* 23 */     this.spreadInPips = 2.0D;
/* 24 */     this.length = period.getInterval();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TickData[] splitCandle(long time, double open, double high, double low, double close, double volume)
/*    */   {
/* 36 */     ArrayList<TickData> result = new ArrayList();
/*    */     
/* 38 */     long step = this.length / 4L;
/* 39 */     long baseTime = time;
/*    */     
/* 41 */     long x1 = this.length;
/* 42 */     long x4 = x1 + this.length;
/* 43 */     long x2 = x1 + step;
/* 44 */     long x3 = x2 + step;
/*    */     
/* 46 */     double y1 = open;
/* 47 */     double y2 = open > close ? low : high;
/* 48 */     double y3 = open > close ? high : low;
/* 49 */     double y4 = close;
/*    */     
/* 51 */     CubicSplineInterpolation cubicSplineInterpolation = new CubicSplineInterpolation(new double[] { x1, x2, x3, x4 }, new double[] { y1, y2, y3, y4 });
/*    */     
/*    */ 
/* 54 */     double pip = this.instrument.getPipValue();
/*    */     
/* 56 */     long ticksNumber = ((high - low) / (pip / 2.0D));
/* 57 */     if (ticksNumber == 0L)
/*    */     {
/* 59 */       ticksNumber = 1L;
/*    */     }
/* 61 */     step = this.length / ticksNumber;
/* 62 */     double vol = StratUtils.roundHalfEven(volume / ticksNumber, 2);
/*    */     
/* 64 */     for (int i = 0; i < ticksNumber; i++) {
/* 65 */       long xx = x1 + step * i;
/*    */       double bid;
/*    */       double bid;
/* 68 */       double ask; if (this.offerSide == OfferSide.ASK) {
/* 69 */         double ask = StratUtils.round(cubicSplineInterpolation.interpolate(xx), 5);
/* 70 */         bid = StratUtils.round(ask - pip * this.spreadInPips, 5);
/*    */       } else {
/* 72 */         bid = StratUtils.round(cubicSplineInterpolation.interpolate(xx), 5);
/* 73 */         ask = StratUtils.round(bid + pip * this.spreadInPips, 5);
/*    */       }
/* 75 */       result.add(new TickData(baseTime + step * i, ask, bid, vol, vol, null, null, null, null));
/*    */     }
/*    */     
/* 78 */     return (TickData[])result.toArray(new TickData[result.size()]);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\candletoticks\CubicSpLineCandleToTicksConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */