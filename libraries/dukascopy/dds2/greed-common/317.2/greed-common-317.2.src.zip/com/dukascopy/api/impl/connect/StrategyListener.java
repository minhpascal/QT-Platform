package com.dukascopy.api.impl.connect;

public abstract interface StrategyListener
{
  public abstract void strategyStartingFailed();
  
  public abstract void strategyStarted(long paramLong);
  
  public abstract void strategyStopped(long paramLong);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\StrategyListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */