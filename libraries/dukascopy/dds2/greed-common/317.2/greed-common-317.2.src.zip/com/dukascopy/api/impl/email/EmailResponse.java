/*    */ package com.dukascopy.api.impl.email;
/*    */ 
/*    */ import com.dukascopy.dds3.transport.msg.sms.EmailResponseMessage;
/*    */ import com.dukascopy.dds3.transport.msg.sms.EmailStatus;
/*    */ 
/*    */ public class EmailResponse implements com.dukascopy.api.util.IEmailResponse
/*    */ {
/*    */   private final boolean isError;
/*    */   private final String message;
/*    */   
/*    */   public EmailResponse(EmailResponseMessage msg)
/*    */   {
/* 13 */     this.isError = (msg.getStatus() != EmailStatus.OK);
/* 14 */     this.message = msg.getStatusText();
/*    */   }
/*    */   
/*    */   public EmailResponse(String errorMessage) {
/* 18 */     this.isError = true;
/* 19 */     this.message = errorMessage;
/*    */   }
/*    */   
/*    */   public boolean isError()
/*    */   {
/* 24 */     return this.isError;
/*    */   }
/*    */   
/*    */   public String getErrorMessage()
/*    */   {
/* 29 */     return this.message;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 34 */     return getClass().getSimpleName() + (this.isError ? "ERROR " : "OK ") + this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\email\EmailResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */