/*    */ package com.dukascopy.api.impl.execution;
/*    */ 
/*    */ import com.dukascopy.api.IBar;
/*    */ import com.dukascopy.api.IStrategy;
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*    */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*    */ import com.dukascopy.api.impl.connect.StrategyProcessor;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*    */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskOnBar
/*    */   extends AbstractPostDataTask<Void>
/*    */ {
/* 24 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskOnBar.class);
/*    */   
/* 26 */   private StrategyProcessor strategyProcessor = null;
/* 27 */   private Instrument instrument = null;
/* 28 */   private Period period = null;
/* 29 */   private IBar askBar = null;
/* 30 */   private IBar bidBar = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private StrategyEventsCallback strategyEventsCallback;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TaskOnBar(JForexTaskManager<?, ?, ?> taskManager, StrategyProcessor strategyProcessor, Instrument instrument, Period period, IBar askBar, IBar bidBar, IStrategyExceptionHandler exceptionHandler)
/*    */   {
/* 42 */     super(taskManager, strategyProcessor.getJfRunnable(), exceptionHandler);
/* 43 */     this.strategyProcessor = strategyProcessor;
/* 44 */     this.instrument = instrument;
/* 45 */     this.period = period;
/* 46 */     this.askBar = askBar;
/* 47 */     this.bidBar = bidBar;
/* 48 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*    */   }
/*    */   
/*    */   public Task.Type getType()
/*    */   {
/* 53 */     return Task.Type.BAR;
/*    */   }
/*    */   
/*    */   public Void call() throws Exception
/*    */   {
/* 58 */     if (this.taskManager.isStrategyStopping()) {
/* 59 */       return null;
/*    */     }
/* 61 */     if (this.strategyProcessor.isOnBarImplemented()) {
/*    */       try {
/* 63 */         postData();
/*    */       } catch (AbstractMethodError abstractMethodError) {
/* 65 */         this.strategyProcessor.setOnBarImplemented(false);
/*    */       } catch (Throwable t) {
/* 67 */         handleError(t);
/*    */       }
/*    */     }
/* 70 */     return null;
/*    */   }
/*    */   
/*    */   protected Logger getLogger()
/*    */   {
/* 75 */     return LOGGER;
/*    */   }
/*    */   
/*    */   protected IStrategyExceptionHandler.Source getSource()
/*    */   {
/* 80 */     return IStrategyExceptionHandler.Source.ON_BAR;
/*    */   }
/*    */   
/*    */   protected void postData() throws Throwable
/*    */   {
/* 85 */     ((IStrategy)this.strategyProcessor.getJfRunnable()).onBar(this.instrument, this.period, this.askBar, this.bidBar);
/* 86 */     if (this.strategyEventsCallback != null) {
/* 87 */       this.strategyEventsCallback.onBar(this.instrument, this.period, this.askBar, this.bidBar);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskOnBar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */