/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.api.IMessage.Type;
/*    */ import com.dukascopy.api.IStopLossLevelChangedMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StopLossLevelChangedMessageImpl
/*    */   extends PlatformMessageImpl
/*    */   implements IStopLossLevelChangedMessage
/*    */ {
/*    */   private static final String FORMAT = "Stop Loss Level Changed Message: [%s]";
/*    */   private String clientId;
/*    */   private double previousStopLossLevel;
/*    */   private double stopLossLevel;
/*    */   
/*    */   public StopLossLevelChangedMessageImpl(String clientId, double previousValue, double newValue, String content, long creationTime)
/*    */   {
/* 38 */     super(content, null, IMessage.Type.STOP_LOSS_LEVEL_CHANGED, creationTime);
/* 39 */     this.clientId = clientId;
/* 40 */     this.previousStopLossLevel = previousValue;
/* 41 */     this.stopLossLevel = newValue;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getClientId()
/*    */   {
/* 49 */     return this.clientId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double previousStopLossLevel()
/*    */   {
/* 57 */     return this.previousStopLossLevel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double stopLossLevel()
/*    */   {
/* 65 */     return this.stopLossLevel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 73 */     return String.format("Stop Loss Level Changed Message: [%s]", new Object[] { getContent() });
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\StopLossLevelChangedMessageImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */