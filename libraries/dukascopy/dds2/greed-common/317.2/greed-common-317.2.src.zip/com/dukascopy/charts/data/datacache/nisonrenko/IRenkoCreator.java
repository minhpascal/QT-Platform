package com.dukascopy.charts.data.datacache.nisonrenko;

import com.dukascopy.charts.data.datacache.CandleData;
import com.dukascopy.charts.data.datacache.TickData;
import com.dukascopy.charts.data.datacache.priceaggregation.IPriceAggregationCreator;

public abstract interface IRenkoCreator
  extends IPriceAggregationCreator<RenkoData, TickData, IRenkoLiveFeedListener>
{
  public abstract boolean analyse(CandleData paramCandleData);
  
  public abstract long getCreateBarsFromTime();
  
  public abstract double getAccumulatedVolume();
  
  public abstract long getAccumulatedFEC();
  
  public abstract void setupIndicationPoint(RenkoData paramRenkoData);
  
  public abstract double getCurrentMinimum();
  
  public abstract double getCurrentMaximum();
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\nisonrenko\IRenkoCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */