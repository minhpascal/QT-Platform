package com.dukascopy.api.impl.talib;

public class IntegerListHolder
  extends Holder
{
  public String paramName;
  public int defaultValue;
  public int[] value;
  public String[] string;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\talib\IntegerListHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */