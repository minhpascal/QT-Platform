package com.dukascopy.api.impl.connect.validation;

import com.dukascopy.api.ICurrency;
import com.dukascopy.api.IEngine.OrderCommand;
import com.dukascopy.api.IOrder;
import com.dukascopy.api.Instrument;
import com.dukascopy.api.JFException;
import com.dukascopy.api.OfferSide;
import com.dukascopy.charts.data.datacache.IFeedDataProvider;
import java.util.Collection;

public abstract interface IOrderValidator
{
  public abstract String validateLabel(String paramString)
    throws JFException;
  
  public abstract String validateComment(String paramString);
  
  public abstract String validateOrderParameters(String paramString, boolean paramBoolean, Instrument paramInstrument, ICurrency paramICurrency, IEngine.OrderCommand paramOrderCommand, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong)
    throws JFException;
  
  public abstract String validateOrderParameters(String paramString, boolean paramBoolean, Instrument paramInstrument, ICurrency paramICurrency, IEngine.OrderCommand paramOrderCommand, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong, IFeedDataProvider paramIFeedDataProvider)
    throws JFException;
  
  public abstract String validateMergeOrders(String paramString, boolean paramBoolean, Collection<IOrder> paramCollection)
    throws JFException;
  
  public abstract String validateOrder(IOrder paramIOrder);
  
  public abstract String validateMinMaxAmount(double paramDouble, Instrument paramInstrument);
  
  public abstract String validateStopLossTakeProfitPrice(boolean paramBoolean, double paramDouble, Instrument paramInstrument);
  
  public abstract String validateRequestedAmount(IOrder paramIOrder, double paramDouble, long paramLong, String paramString1, String paramString2)
    throws JFException;
  
  public abstract String validateLabel(IOrder paramIOrder, String paramString1, long paramLong, boolean paramBoolean, String paramString2, String paramString3)
    throws JFException;
  
  public abstract String validateOpenPrice(IOrder paramIOrder, double paramDouble, long paramLong, boolean paramBoolean, String paramString)
    throws JFException;
  
  public abstract String validateClose(IOrder paramIOrder, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong)
    throws JFException;
  
  public abstract String validateStopLossPrice(IOrder paramIOrder, double paramDouble1, OfferSide paramOfferSide, double paramDouble2, boolean paramBoolean, long paramLong)
    throws JFException;
  
  public abstract String validateTakeProfitPrice(IOrder paramIOrder, double paramDouble, OfferSide paramOfferSide, boolean paramBoolean, long paramLong)
    throws JFException;
  
  public abstract void validateGoodTillTime(long paramLong, IEngine.OrderCommand paramOrderCommand)
    throws JFException;
  
  public abstract String validateGoodTillTime(IOrder paramIOrder, long paramLong1, long paramLong2, boolean paramBoolean, String paramString)
    throws JFException;
  
  public abstract void validateCloseOrders(boolean paramBoolean, Collection<IOrder> paramCollection)
    throws JFException;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\validation\IOrderValidator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */