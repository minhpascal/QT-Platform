/*     */ package com.dukascopy.charts.data.datacache.pamanager.dataload.beforetimeafter;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.IPACacheManager;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadClosestPointAndFigureAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PALoadToCachePointAndFigureAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.helpactions.PANthPointAndFigureFromSeedBarAction;
/*     */ import com.dukascopy.charts.data.datacache.pamanager.dataload.timeinterval.PALoadByTimeIntervalPointAndFigureAction;
/*     */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureCreator;
/*     */ import com.dukascopy.charts.data.datacache.pnf.IPointAndFigureLiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.pnf.PointAndFigureData;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PALoadNumberOfBarsBeforeAfterTimePointAndFigureAction
/*     */   extends PAAbstractLoadNumOfBarsBeforeAfterTimeAction<PointAndFigureData, IPointAndFigureLiveFeedListener, IPointAndFigureCreator, PALoadToCachePointAndFigureAction, PALoadByTimeIntervalPointAndFigureAction>
/*     */ {
/*     */   public PALoadNumberOfBarsBeforeAfterTimePointAndFigureAction(IPACacheManager cacheManager, Instrument instrument, DataInterpolationDescriptor interpolationDescriptor, OfferSide side, JForexPeriod jfPeriod, int numOfBarsBefore, long time, int numOfBarsAfter, boolean fireUncompletedLastBasePeriodBars, boolean infinitBasePeriod, int version, IPointAndFigureLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException, TimeoutException
/*     */   {
/*  54 */     super(cacheManager, instrument, interpolationDescriptor, side, jfPeriod, numOfBarsBefore, time, numOfBarsAfter, fireUncompletedLastBasePeriodBars, infinitBasePeriod, version, listener, loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected IPointAndFigureLiveFeedListener createOneBarListener(final List<PointAndFigureData> oneBarList)
/*     */   {
/*  74 */     new IPointAndFigureLiveFeedListener()
/*     */     {
/*     */       public void newPriceData(PointAndFigureData data) {
/*  77 */         oneBarList.add(data);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   protected PALoadByTimeIntervalPointAndFigureAction createLoadIntervalAction(long timeFrom, long timeTo, ILoadingProgressListener loadingProgressListener) throws DataCacheException
/*     */   {
/*  84 */     return new PALoadByTimeIntervalPointAndFigureAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), timeFrom, timeTo, isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), (IPointAndFigureLiveFeedListener)getListener(), loadingProgressListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PALoadClosestPointAndFigureAction createLoadClosestAction(IPointAndFigureLiveFeedListener listener, ILoadingProgressListener loadingProgressListener)
/*     */     throws DataCacheException
/*     */   {
/* 102 */     PALoadClosestPointAndFigureAction action = new PALoadClosestPointAndFigureAction(getCacheManager(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), getTime(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), getVersion(), listener, loadingProgressListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */     return action;
/*     */   }
/*     */   
/*     */   protected PANthPointAndFigureFromSeedBarAction createNthBarFromSeedAction(PointAndFigureData timedBar, IPointAndFigureLiveFeedListener oneBarListener, boolean lookLeft, ILoadingProgressListener loadingProgressListener)
/*     */   {
/* 120 */     PANthPointAndFigureFromSeedBarAction action = new PANthPointAndFigureFromSeedBarAction(getCacheManager(), getVersion(), getNumOfBarsBefore(), timedBar, getNumOfBarsAfter(), getInstrument(), getInterpolationDescriptor(), getSide(), getJfPeriod(), isFireUncompletedLastBasePeriodBars(), isInfinitBasePeriod(), lookLeft, loadingProgressListener, oneBarListener);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     return action;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\dataload\beforetimeafter\PALoadNumberOfBarsBeforeAfterTimePointAndFigureAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */