/*    */ package com.dukascopy.charts.data.datacache.customticks.data;
/*    */ 
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.api.Period;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomTicksLoadingDescriptor
/*    */   implements ICustomTicksLoadingDescriptor
/*    */ {
/*    */   private Period period;
/*    */   private OfferSide offerSide;
/*    */   private CustomTicksLoadingMethod loadingMethod;
/*    */   private long priceDifferenceInPips;
/*    */   private long timeIntervalBetweenTicks;
/*    */   
/*    */   public CustomTicksLoadingDescriptor() {}
/*    */   
/* 26 */   public CustomTicksLoadingDescriptor(CustomTicksLoadingMethod loadingMethod) { this.loadingMethod = loadingMethod; }
/*    */   
/*    */   public CustomTicksLoadingDescriptor(CustomTicksLoadingMethod loadingMethod, Period period, OfferSide offerSide) {
/* 29 */     this.loadingMethod = loadingMethod;
/* 30 */     this.period = period;
/* 31 */     this.offerSide = offerSide;
/*    */   }
/*    */   
/*    */   public Period getPeriod()
/*    */   {
/* 36 */     return this.period;
/*    */   }
/*    */   
/*    */   public void setPeriod(Period period) {
/* 40 */     this.period = period;
/*    */   }
/*    */   
/*    */   public OfferSide getOfferSide() {
/* 44 */     return this.offerSide;
/*    */   }
/*    */   
/*    */   public void setOfferSide(OfferSide offerSide) {
/* 48 */     this.offerSide = offerSide;
/*    */   }
/*    */   
/*    */   public CustomTicksLoadingMethod getLoadingMethod() {
/* 52 */     return this.loadingMethod;
/*    */   }
/*    */   
/*    */   public void setLoadingMethod(CustomTicksLoadingMethod loadingMethod) {
/* 56 */     this.loadingMethod = loadingMethod;
/*    */   }
/*    */   
/*    */   public long getPriceDifferenceInPips() {
/* 60 */     return this.priceDifferenceInPips;
/*    */   }
/*    */   
/*    */   public void setPriceDifferenceInPips(long priceDifferenceInPips) {
/* 64 */     this.priceDifferenceInPips = priceDifferenceInPips;
/*    */   }
/*    */   
/*    */   public long getTimeIntervalBetweenTicks() {
/* 68 */     return this.timeIntervalBetweenTicks;
/*    */   }
/*    */   
/*    */   public void setTimeIntervalBetweenTicks(long timeIntervalBetweenTicks) {
/* 72 */     this.timeIntervalBetweenTicks = timeIntervalBetweenTicks;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 76 */     return this.period + " " + this.offerSide + " " + this.loadingMethod;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\data\CustomTicksLoadingDescriptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */