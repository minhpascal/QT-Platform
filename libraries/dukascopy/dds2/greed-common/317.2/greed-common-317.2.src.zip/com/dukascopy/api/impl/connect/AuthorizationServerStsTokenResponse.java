/*    */ package com.dukascopy.api.impl.connect;
/*    */ 
/*    */ import com.dukascopy.json.JSONObject;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class AuthorizationServerStsTokenResponse
/*    */   extends AbstractAuthorizationServerResponse
/*    */ {
/* 10 */   private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationServerStsTokenResponse.class);
/*    */   private String stsToken;
/*    */   private String error;
/*    */   
/*    */   public AuthorizationServerStsTokenResponse(AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode)
/*    */   {
/* 16 */     this.responseMessage = null;
/* 17 */     this.responseCode = authorizationServerResponseCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AuthorizationServerStsTokenResponse(String responseMessage, AuthorizationClient.AuthorizationServerResponseCode authorizationServerResponseCode)
/*    */   {
/* 24 */     this.responseMessage = null;
/* 25 */     this.responseCode = authorizationServerResponseCode;
/*    */     
/* 27 */     init();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AuthorizationServerStsTokenResponse(String responseMessage, int authorizationServerResponseCode)
/*    */   {
/* 34 */     this.responseMessage = responseMessage;
/* 35 */     this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.fromValue(authorizationServerResponseCode);
/*    */     
/* 37 */     init();
/*    */   }
/*    */   
/*    */   public String getStsToken() {
/* 41 */     return this.stsToken;
/*    */   }
/*    */   
/*    */   public String getError() {
/* 45 */     return this.error;
/*    */   }
/*    */   
/*    */   protected void validateResponse(String authorizationResponse)
/*    */   {
/* 50 */     if ((authorizationResponse == null) || (authorizationResponse.length() == 0)) {
/* 51 */       this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.EMPTY_RESPONSE;
/*    */     } else {
/*    */       try {
/* 54 */         JSONObject jsonObject = new JSONObject(authorizationResponse, false);
/* 55 */         this.stsToken = jsonObject.getString("result");
/* 56 */         if (!jsonObject.isNull("error")) {
/* 57 */           this.error = jsonObject.getString("error");
/* 58 */           if (this.error != null) {
/* 59 */             this.error.trim();
/*    */           }
/*    */         }
/*    */         
/* 63 */         if ((this.stsToken == null) || (this.stsToken.isEmpty()) || (this.error != null)) {
/* 64 */           this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/*    */         }
/*    */       } catch (Throwable e) {
/* 67 */         LOGGER.error(e.getMessage(), e);
/* 68 */         this.responseCode = AuthorizationClient.AuthorizationServerResponseCode.WRONG_AUTH_RESPONSE;
/* 69 */         LOGGER.error("Cannot parse STS Token answer [" + authorizationResponse + "]");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\AuthorizationServerStsTokenResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */