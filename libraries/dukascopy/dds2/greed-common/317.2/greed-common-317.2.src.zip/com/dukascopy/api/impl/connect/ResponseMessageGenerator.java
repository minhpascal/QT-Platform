/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.IMessage.Type;
/*     */ import com.dukascopy.api.IOrder.State;
/*     */ import com.dukascopy.dds3.transport.msg.types.NotificationMessageCode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseMessageGenerator
/*     */ {
/*  41 */   private static final Logger LOGGER = LoggerFactory.getLogger(ResponseMessageGenerator.class);
/*     */   
/*     */   static enum MessageType {
/*  44 */     OK,  REJECT;
/*     */     
/*     */     private MessageType() {} }
/*  47 */   Map<PlatformOrderImpl.ServerRequest, Set<IMessage.Type>> byServerRequest = new HashMap();
/*  48 */   Map<MessageType, Set<IMessage.Type>> byMessageType = new HashMap();
/*  49 */   Map<IOrder.State, Set<IMessage.Type>> byOrderState = new HashMap();
/*     */   
/*     */   public ResponseMessageGenerator() {
/*  52 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.NONE, asSet(new IMessage.Type[] { IMessage.Type.ORDER_SUBMIT_OK, IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_FILL_OK, IMessage.Type.ORDERS_MERGE_OK, IMessage.Type.ORDER_CHANGED_OK }));
/*  53 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SUBMIT, asSet(new IMessage.Type[] { IMessage.Type.ORDER_SUBMIT_OK, IMessage.Type.ORDER_SUBMIT_REJECTED, IMessage.Type.ORDER_FILL_REJECTED, IMessage.Type.ORDER_FILL_OK }));
/*  54 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SET_REQ_AMOUNT, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  55 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SET_OPEN_PRICE, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  56 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SET_LABEL, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  57 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.CLOSE, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_CLOSE_REJECTED }));
/*  58 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SET_EXPIRATION, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  59 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SET_SL, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  60 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.SET_TP, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  61 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.MERGE_SOURCE, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_CLOSE_REJECTED }));
/*  62 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.MERGE_TARGET, asSet(new IMessage.Type[] { IMessage.Type.ORDERS_MERGE_OK, IMessage.Type.ORDERS_MERGE_REJECTED, IMessage.Type.ORDER_CLOSE_OK }));
/*  63 */     this.byServerRequest.put(PlatformOrderImpl.ServerRequest.CANCEL_ORDER, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_CLOSE_REJECTED }));
/*     */     
/*  65 */     this.byOrderState.put(IOrder.State.CREATED, asSet(new IMessage.Type[] { IMessage.Type.ORDER_SUBMIT_OK, IMessage.Type.ORDER_SUBMIT_REJECTED, IMessage.Type.ORDERS_MERGE_OK, IMessage.Type.ORDERS_MERGE_REJECTED }));
/*  66 */     this.byOrderState.put(IOrder.State.OPENED, asSet(new IMessage.Type[] { IMessage.Type.ORDER_FILL_OK, IMessage.Type.ORDER_FILL_REJECTED, IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_CLOSE_REJECTED, IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED }));
/*  67 */     this.byOrderState.put(IOrder.State.FILLED, asSet(new IMessage.Type[] { IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_CLOSE_REJECTED, IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CHANGED_REJECTED, IMessage.Type.ORDERS_MERGE_REJECTED, IMessage.Type.ORDERS_MERGE_OK }));
/*  68 */     this.byOrderState.put(IOrder.State.CLOSED, asSet(new IMessage.Type[0]));
/*  69 */     this.byOrderState.put(IOrder.State.CANCELED, asSet(new IMessage.Type[0]));
/*     */     
/*  71 */     this.byMessageType.put(MessageType.OK, asSet(new IMessage.Type[] { IMessage.Type.ORDER_SUBMIT_OK, IMessage.Type.ORDER_CHANGED_OK, IMessage.Type.ORDER_CLOSE_OK, IMessage.Type.ORDER_FILL_OK, IMessage.Type.ORDERS_MERGE_OK }));
/*     */     
/*  73 */     this.byMessageType.put(MessageType.REJECT, asSet(new IMessage.Type[] { IMessage.Type.ORDER_SUBMIT_REJECTED, IMessage.Type.ORDER_CHANGED_REJECTED, IMessage.Type.ORDER_CLOSE_REJECTED, IMessage.Type.ORDER_FILL_REJECTED, IMessage.Type.ORDERS_MERGE_REJECTED }));
/*     */   }
/*     */   
/*     */   private Set<IMessage.Type> asSet(IMessage.Type... types)
/*     */   {
/*  78 */     return new HashSet(Arrays.asList(types));
/*     */   }
/*     */   
/*     */ 
/*     */   public IMessage.Type generateResponse(PlatformOrderImpl.ServerRequest lastServerRequest, IOrder.State state, NotificationMessageCode code, String text)
/*     */   {
/*  84 */     IMessage.Type rc = null;
/*     */     
/*  86 */     switch (code) {
/*     */     case ACCOUNT_BLOCKED: 
/*     */     case ACCOUNT_DISABLED: 
/*     */     case AMOUNT_EMPTY_OR_ZERO: 
/*     */     case AMOUNT_GREATER_REMAINING: 
/*     */     case AMOUNT_TO_LARGE: 
/*     */     case FAILED_CANCEL_OFFER: 
/*     */     case FAILED_EDIT_OFFER: 
/*     */     case GROUP_MISSED: 
/*     */     case INSTRUMENT_EMPTY: 
/*     */     case INVALID_ORDER: 
/*     */     case MAS_CLOSE_FAIL_BAD_ORDER: 
/*     */     case MAX_SUBMIT_COUNT_REACHED: 
/*     */     case ORDER_ALREADY_FILLED: 
/*     */     case PRICE_CLIENT_EMPTY: 
/*     */     case PRICE_STOP_INVALID: 
/*     */     case NO_ORDER_FOUND: 
/*     */     case ORDER_IN_ERROR_STATE: 
/*     */     case ORDER_IN_EXEC_STATE: 
/*     */     case ORDER_NOT_FOUND: 
/*     */     case ORDER_SIDE_EMPTY: 
/*     */     case ORDER_STATE_EMPTY: 
/*     */     case ORDER_DIRECTION_EMPTY: 
/*     */     case REJECT_INVALID_ORDER: 
/*     */     case REJECT_NO_MARGIN: 
/*     */     case REJECTED_COUNTERPARTY: 
/*     */     case REJECTED_MIN_OPEN_AMOUNT: 
/*     */     case SL_TP_DISABLED_NONHADGE: 
/*     */     case STEP_LESS_3PIP: 
/*     */     case SYSTEM_UNAVAILABLE: 
/*     */     case UNSUFF_MARGIN_ON_CLOSE: 
/*     */     case UPDATE_ORDER_NOT_FOUND: 
/*     */     case VALIDATION_ERROR: 
/*     */     case POSITION_MERGE_FAILED: 
/* 120 */       rc = retain(MessageType.REJECT, lastServerRequest, state, code, text);
/* 121 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case CANCELING_OFFER_MC: 
/*     */     case EQUITY_LIMIT_REACHED: 
/*     */     case ACCOUNT_BLOCKED_CLOSED: 
/*     */     case ACCOUNT_SETTING_SAVE_FAIL: 
/*     */     case ACCOUNT_STATUS_DISABLED: 
/*     */     case MC_MARGIN_CUT: 
/*     */     case MC_MARGIN_CUT_WEEKEND: 
/*     */     case MERGE_IN_PROGRESS: 
/*     */     case OCO_GROUPED: 
/*     */     case OCO_UNGROUPED: 
/*     */     case REJECT_AND_RESUBMIT: 
/*     */     case OFFER_CANCELED: 
/*     */     case OFFER_CANCELED_FILLED: 
/*     */     case OFFER_CANCELED_LEVERAGE: 
/*     */     case ORDER_CANCELED: 
/*     */     case ORDER_FILLED: 
/*     */     case ORDER_FILLED_PARTIALLY: 
/*     */     case POSITION_MERGED_CLOSED: 
/*     */     case POSITION_MERGED_TO: 
/*     */     case STRING_MESSAGE: 
/*     */     case UNSUFFICIENT_MARGIN: 
/*     */     case ORDER_ACCEPTED: 
/*     */     case MULTIPLE_SIM_ORDERED: 
/*     */     case ACCOUNT_LOCKED: 
/*     */     case NO_MARGIN_LEVEL: 
/*     */     case MERGE_DENIED: 
/*     */     case CONDITION_CHANGED: 
/*     */     case DEACT_CLIENT_DLL_ST: 
/*     */     case DEACT_CLIENT_DLL_MC: 
/*     */     case DEACT_CLIENT_LL_ST: 
/*     */     case DEACT_CLIENT_LL_MC: 
/*     */     case DEACT_CLIENT_OTHER: 
/*     */     case ALREADY_PROCESSED: 
/*     */     case POSITION_LIMIT: 
/*     */     case SYSTEM_ERROR: 
/*     */     case TRALING_UPDATE: 
/*     */     case ORDER_LOCKED: 
/*     */     case CONTEST_OVER: 
/*     */     case WITHDRAWAL_DIONE: 
/* 167 */       rc = IMessage.Type.NOTIFICATION;
/* 168 */       break;
/*     */     
/*     */ 
/*     */     default: 
/* 172 */       assertion(text, state, lastServerRequest, code);
/*     */     }
/*     */     
/*     */     
/* 176 */     return rc;
/*     */   }
/*     */   
/*     */   private IMessage.Type retain(MessageType messageType, PlatformOrderImpl.ServerRequest lastServerRequest, IOrder.State state, NotificationMessageCode code, String text) {
/* 180 */     IMessage.Type rc = null;
/* 181 */     List<IMessage.Type> rcList = new ArrayList((Collection)this.byMessageType.get(messageType));
/* 182 */     rcList.retainAll((Collection)this.byServerRequest.get(lastServerRequest));
/* 183 */     rcList.retainAll((Collection)this.byOrderState.get(state));
/* 184 */     if (rcList.size() == 1) {
/* 185 */       rc = (IMessage.Type)rcList.get(0);
/* 186 */     } else if ((lastServerRequest != PlatformOrderImpl.ServerRequest.NONE) || (messageType != MessageType.REJECT))
/*     */     {
/*     */ 
/* 189 */       assertion(text, state, lastServerRequest, code);
/*     */     }
/* 191 */     return rc;
/*     */   }
/*     */   
/*     */   private void assertion(String msg, IOrder.State state, PlatformOrderImpl.ServerRequest lastServerRequest, NotificationMessageCode code)
/*     */   {
/* 196 */     LOGGER.error(msg);
/* 197 */     LOGGER.error("STATES[" + state + "][" + lastServerRequest + "][" + code + "]");
/* 198 */     LOGGER.error("----");
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\ResponseMessageGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */