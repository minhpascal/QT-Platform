/*    */ package com.dukascopy.charts.data.datacache.customticks.candletoticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ 
/*    */ public class FourTicksCandleToTicksConverter implements ICandleToTicksConverter
/*    */ {
/*    */   private final double spreadInPipsAsk;
/*    */   private final double spreadInPipsBid;
/*    */   private final double step;
/*    */   
/*    */   public FourTicksCandleToTicksConverter(Instrument instrument, OfferSide offerSide, com.dukascopy.api.Period period)
/*    */   {
/* 16 */     this.spreadInPipsAsk = ((offerSide == OfferSide.ASK ? 0.0D : 2.0D) * instrument.getPipValue());
/* 17 */     this.spreadInPipsBid = ((offerSide == OfferSide.ASK ? -2.0D : 0.0D) * instrument.getPipValue());
/* 18 */     this.step = (period.getInterval() / 8.0D);
/*    */   }
/*    */   
/*    */ 
/*    */   public TickData[] splitCandle(long time, double open, double high, double low, double close, double volume)
/*    */   {
/* 24 */     TickData[] result = new TickData[4];
/*    */     
/*    */ 
/* 27 */     double ask = StratUtils.round(open + this.spreadInPipsAsk, 5);
/* 28 */     double bid = StratUtils.round(open + this.spreadInPipsBid, 5);
/* 29 */     double vol = StratUtils.round(volume / 4.0D, 5);
/* 30 */     result[0] = new TickData((time + this.step), ask, bid, vol, vol, null, null, null, null);
/*    */     
/*    */ 
/* 33 */     double lowhigh = close < open ? high : low;
/* 34 */     ask = StratUtils.round(lowhigh + this.spreadInPipsAsk, 5);
/* 35 */     bid = StratUtils.round(lowhigh + this.spreadInPipsBid, 5);
/* 36 */     result[1] = new TickData((time + this.step * 3.0D), ask, bid, vol, vol, null, null, null, null);
/*    */     
/*    */ 
/* 39 */     lowhigh = close < open ? low : high;
/* 40 */     ask = StratUtils.round(lowhigh + this.spreadInPipsAsk, 5);
/* 41 */     bid = StratUtils.round(lowhigh + this.spreadInPipsBid, 5);
/* 42 */     result[2] = new TickData((time + this.step * 5.0D), ask, bid, vol, vol, null, null, null, null);
/*    */     
/*    */ 
/* 45 */     ask = StratUtils.round(close + this.spreadInPipsAsk, 5);
/* 46 */     bid = StratUtils.round(close + this.spreadInPipsBid, 5);
/* 47 */     result[3] = new TickData((time + this.step * 7.0D), ask, bid, vol, vol, null, null, null, null);
/*    */     
/* 49 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\candletoticks\FourTicksCandleToTicksConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */