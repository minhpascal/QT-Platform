/*    */ package com.dukascopy.charts.data.datacache.pamanager.creators;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.charts.data.datacache.JForexPeriod;
/*    */ import com.dukascopy.charts.data.datacache.rangebar.IPriceRangeLiveFeedListener;
/*    */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeCreator;
/*    */ import com.dukascopy.charts.data.datacache.rangebar.PriceRangeData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachePriceRangeCreator
/*    */   extends PriceRangeCreator
/*    */ {
/*    */   private IPriceRangeLiveFeedListener cacheFeedListener;
/*    */   
/*    */   public CachePriceRangeCreator(Instrument instrument, OfferSide offerSide, JForexPeriod jfPeriod, IPriceRangeLiveFeedListener cacheFeedListener, boolean fromTheBeginningOfTheHistory)
/*    */   {
/* 29 */     super(instrument, jfPeriod.getPriceRange(), offerSide, -1, false, true, fromTheBeginningOfTheHistory, null);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 40 */     this.cacheFeedListener = cacheFeedListener;
/*    */   }
/*    */   
/*    */   public boolean isAllDesiredDataLoaded()
/*    */   {
/* 45 */     return false;
/*    */   }
/*    */   
/*    */   private PriceRangeData finishPriceRange(PriceRangeData bar)
/*    */   {
/* 50 */     bar.setFinishedFromTheEnd(true);
/* 51 */     this.cacheFeedListener.newPriceData(bar);
/* 52 */     return bar;
/*    */   }
/*    */   
/*    */   protected void resetResulArray()
/*    */   {
/* 57 */     this.result = new PriceRangeData[1];
/*    */   }
/*    */   
/*    */   public int getLastElementIndex()
/*    */   {
/* 62 */     return 0;
/*    */   }
/*    */   
/*    */   public void fireNewBarCreated(PriceRangeData data)
/*    */   {
/* 67 */     this.lastFiredData = data;
/* 68 */     finishPriceRange(data);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\pamanager\creators\CachePriceRangeCreator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */