/*    */ package com.dukascopy.calculator.graph;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ 
/*    */ public class View extends javax.swing.JPanel
/*    */ {
/*    */   protected Graph graph;
/*    */   protected Model model;
/*    */   protected Transformation transformation;
/*    */   protected double distanceValue;
/*    */   
/*    */   public View(Model model, Graph graph)
/*    */   {
/* 14 */     this.model = model;
/* 15 */     this.graph = graph;
/* 16 */     this.forceUpdateBool = new java.util.concurrent.atomic.AtomicBoolean(false);
/* 17 */     this.transformation = new Transformation(this);
/*    */     
/* 19 */     java.awt.Font font = javax.swing.UIManager.getFont("Label.font");
/* 20 */     setFont(font.deriveFont(10.0F));
/* 21 */     this.distanceValue = 1.0D;
/* 22 */     this.lastWidth = (this.lastHeight = 0);
/*    */   }
/*    */   
/*    */ 
/*    */   public void forceUpdate()
/*    */   {
/* 28 */     this.forceUpdateBool.set(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void paintComponent(java.awt.Graphics graphics)
/*    */   {
/* 36 */     if ((this.lastWidth != getWidth()) || (this.lastHeight != getHeight()) || (this.forceUpdateBool.compareAndSet(true, false)))
/*    */     {
/* 38 */       System.out.println("*** changed size  or forced update *** ");
/* 39 */       this.graph.updateMenu();
/* 40 */       setCursor(new java.awt.Cursor(3));
/* 41 */       this.model.updatePaths();
/* 42 */       this.lastWidth = getWidth();
/* 43 */       this.lastHeight = getHeight();
/*    */     }
/*    */     
/* 46 */     Graphics2D graphics2d = (Graphics2D)graphics;
/* 47 */     graphics2d.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
/*    */     
/* 49 */     graphics2d.setColor(java.awt.Color.WHITE);
/* 50 */     graphics2d.fillRect(0, 0, this.lastWidth, this.lastHeight);
/* 51 */     graphics2d.setColor(java.awt.Color.BLACK);
/* 52 */     this.model.draw(this, graphics2d);
/* 53 */     System.out.println("finished updating view");
/*    */   }
/*    */   
/*    */   public static final double delta = 0.001D;
/*    */   private int lastWidth;
/*    */   private int lastHeight;
/*    */   java.util.concurrent.atomic.AtomicBoolean forceUpdateBool;
/*    */   private static final long serialVersionUID = 1L;
/*    */   public final Transformation getTransformation() {
/* 62 */     return this.transformation;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Model getModel()
/*    */   {
/* 70 */     return this.model;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   double distance()
/*    */   {
/* 79 */     return this.distanceValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\graph\View.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */