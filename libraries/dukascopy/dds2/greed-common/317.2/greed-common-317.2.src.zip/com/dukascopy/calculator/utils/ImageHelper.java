/*    */ package com.dukascopy.calculator.utils;
/*    */ 
/*    */ import com.dukascopy.dds2.greed.agent.strategy.StratUtils;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageHelper
/*    */ {
/*    */   public static final String DOWN_ARROW = "downarrow.png";
/*    */   public static final String RIGHT_ARROW = "rightarrow.png";
/*    */   public static final String LEFT_ARROW = "leftarrow.png";
/*    */   public static final String UP_ARROW = "uparrow.png";
/*    */   public static final String INFO = "info.png";
/*    */   
/*    */   public static ImageIcon getImageIcon(String name, int size)
/*    */   {
/* 19 */     return StratUtils.loadImageIcon("resources/icons/" + size + name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\utils\ImageHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */