/*   */ package com.dukascopy.calculator.expression;
/*   */ 
/*   */ 
/*   */ public class Log
/*   */   extends Monadic
/*   */ {
/*   */   public Log(Expression expression)
/*   */   {
/* 9 */     super(new com.dukascopy.calculator.function.Log(), expression);
/*   */   }
/*   */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\expression\Log.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */