/*    */ package com.dukascopy.charts.data.datacache.hl;
/*    */ 
/*    */ import com.dukascopy.api.Period;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HighLowManagerProvider
/*    */   implements IHighLowManagerProvider
/*    */ {
/*    */   private final IFeedDataProvider feedDataProvider;
/*    */   private final Map<Period, IHighLowManager> highLowManagersByPeriod;
/*    */   
/*    */   public HighLowManagerProvider(IFeedDataProvider feedDataProvider)
/*    */   {
/* 25 */     this.feedDataProvider = feedDataProvider;
/* 26 */     this.highLowManagersByPeriod = new ConcurrentHashMap();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IHighLowManager getHighLowManager(Period period)
/*    */   {
/* 35 */     validatePeriod(period);
/* 36 */     synchronized (this.highLowManagersByPeriod) {
/* 37 */       IHighLowManager highLowManager = (IHighLowManager)this.highLowManagersByPeriod.get(period);
/* 38 */       if (highLowManager == null) {
/* 39 */         highLowManager = new HighLowManager(this.feedDataProvider, period);
/* 40 */         this.highLowManagersByPeriod.put(period, highLowManager);
/*    */       }
/* 42 */       return highLowManager;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void dispose()
/*    */   {
/* 51 */     this.highLowManagersByPeriod.clear();
/*    */   }
/*    */   
/*    */   private void validatePeriod(Period period) {
/* 55 */     if (period == null)
/* 56 */       throw new IllegalArgumentException("Period could not be null");
/* 57 */     if ((period == null) || (period.isTickBasedPeriod())) {
/* 58 */       throw new IllegalArgumentException("Tick period is not supported for H&L listeners");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\hl\HighLowManagerProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */