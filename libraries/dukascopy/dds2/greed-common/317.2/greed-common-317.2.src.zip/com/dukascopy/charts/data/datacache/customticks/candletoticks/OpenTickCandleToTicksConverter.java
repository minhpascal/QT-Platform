/*    */ package com.dukascopy.charts.data.datacache.customticks.candletoticks;
/*    */ 
/*    */ import com.dukascopy.api.Instrument;
/*    */ import com.dukascopy.api.OfferSide;
/*    */ import com.dukascopy.charts.data.datacache.TickData;
/*    */ 
/*    */ public class OpenTickCandleToTicksConverter implements ICandleToTicksConverter
/*    */ {
/*    */   private final double spreadInPipsAsk;
/*    */   private final double spreadInPipsBid;
/*    */   
/*    */   public OpenTickCandleToTicksConverter(Instrument instrument, OfferSide offerSide)
/*    */   {
/* 14 */     this.spreadInPipsAsk = ((OfferSide.ASK.equals(offerSide) ? 0.0D : 2.0D) * instrument.getPipValue());
/* 15 */     this.spreadInPipsBid = ((OfferSide.ASK.equals(offerSide) ? -2.0D : 0.0D) * instrument.getPipValue());
/*    */   }
/*    */   
/*    */ 
/*    */   public TickData[] splitCandle(long time, double open, double high, double low, double close, double volume)
/*    */   {
/* 21 */     double ask = com.dukascopy.dds2.greed.agent.strategy.StratUtils.round(open + this.spreadInPipsAsk, 5);
/* 22 */     double bid = com.dukascopy.dds2.greed.agent.strategy.StratUtils.round(open + this.spreadInPipsBid, 5);
/*    */     
/* 24 */     return new TickData[] { new TickData(time, ask, bid, volume, volume, null, null, null, null) };
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\candletoticks\OpenTickCandleToTicksConverter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */