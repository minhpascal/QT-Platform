package com.dukascopy.charts.data.datacache.feed;

import com.dukascopy.charts.data.datacache.preloader.IInstrumentTimeInterval;

public abstract interface IInstrumentFeedCommissionInfo
  extends IInstrumentTimeInterval
{
  public abstract void setAskFeedCommission(double paramDouble);
  
  public abstract double getAskFeedCommission();
  
  public abstract void setBidFeedCommission(double paramDouble);
  
  public abstract double getBidFeedCommission();
  
  public abstract long getPriority();
  
  public abstract void setPriority(long paramLong);
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\feed\IInstrumentFeedCommissionInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */