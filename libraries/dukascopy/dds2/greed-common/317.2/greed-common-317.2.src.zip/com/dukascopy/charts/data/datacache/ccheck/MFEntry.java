/*     */ package com.dukascopy.charts.data.datacache.ccheck;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MFEntry
/*     */ {
/*     */   private static final String SEPARATOR = ";";
/*     */   private long chunkTime;
/*     */   private Instrument instrument;
/*     */   private OfferSide side;
/*     */   
/*     */   public MFEntry(long chunkTime, Instrument instrument, OfferSide side)
/*     */   {
/*  24 */     this.chunkTime = chunkTime;
/*  25 */     this.instrument = instrument;
/*  26 */     this.side = side;
/*     */   }
/*     */   
/*     */   public long getChunkTime() {
/*  30 */     return this.chunkTime;
/*     */   }
/*     */   
/*  33 */   public void setChunkTime(long chunkTime) { this.chunkTime = chunkTime; }
/*     */   
/*     */   public Instrument getInstrument() {
/*  36 */     return this.instrument;
/*     */   }
/*     */   
/*  39 */   public void setInstrument(Instrument instrument) { this.instrument = instrument; }
/*     */   
/*     */   public OfferSide getSide() {
/*  42 */     return this.side;
/*     */   }
/*     */   
/*  45 */   public void setSide(OfferSide side) { this.side = side; }
/*     */   
/*     */   public static MFEntry fromString(String stringEntry)
/*     */     throws DataCacheException
/*     */   {
/*  50 */     if (ObjectUtils.isNullOrEmpty(stringEntry)) {
/*  51 */       throw new DataCacheException("Cannot parse MFEntry string to MFEntry object. [" + stringEntry + "]");
/*     */     }
/*     */     
/*  54 */     String[] tokens = stringEntry.split(";");
/*  55 */     if (tokens.length != 3) {
/*  56 */       throw new DataCacheException("Cannot parse MFEntry string to MFEntry object! Num of tokens not valid! [tokens length = " + tokens.length + "]");
/*     */     }
/*     */     
/*  59 */     long time = Long.parseLong(tokens[0]);
/*     */     
/*  61 */     String instrString = tokens[1];
/*     */     
/*  63 */     if (ObjectUtils.isNullOrEmpty(instrString)) {
/*  64 */       throw new DataCacheException("Cannot parse MFEntry string to MFEntry object! Instrument string is null or empty [" + instrString + "]");
/*     */     }
/*     */     
/*  67 */     Instrument instrument = Instrument.fromString(tokens[1]);
/*     */     
/*  69 */     if (instrument == null) {
/*  70 */       throw new DataCacheException("Cannot parse MFEntry string to MFEntry object! Cannot parse string to Instrument. String [" + tokens[1] + "]");
/*     */     }
/*     */     
/*  73 */     OfferSide side = null;
/*  74 */     String sideString = tokens[2];
/*  75 */     if ((!ObjectUtils.isNullOrEmpty(sideString)) && 
/*  76 */       (!"null".equalsIgnoreCase(sideString))) {
/*  77 */       side = OfferSide.valueOf(sideString.toUpperCase());
/*  78 */       if (side == null) {
/*  79 */         throw new DataCacheException("Cannot parse MFEntry string to MFEntry object! Cannot parse OfferSide. String [" + sideString + "]");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  84 */     MFEntry result = new MFEntry(time, instrument, side);
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  91 */     int prime = 31;
/*  92 */     int result = 1;
/*  93 */     result = 31 * result + (int)(this.chunkTime ^ this.chunkTime >>> 32);
/*  94 */     result = 31 * result + (this.instrument == null ? 0 : this.instrument.hashCode());
/*     */     
/*  96 */     result = 31 * result + (this.side == null ? 0 : this.side.hashCode());
/*  97 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 102 */     if (this == obj)
/* 103 */       return true;
/* 104 */     if (obj == null)
/* 105 */       return false;
/* 106 */     if (getClass() != obj.getClass())
/* 107 */       return false;
/* 108 */     MFEntry other = (MFEntry)obj;
/* 109 */     if (this.chunkTime != other.chunkTime)
/* 110 */       return false;
/* 111 */     if (this.instrument != other.instrument)
/* 112 */       return false;
/* 113 */     if (this.side != other.side)
/* 114 */       return false;
/* 115 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 120 */     return this.chunkTime + ";" + this.instrument.toString() + ";" + this.side;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\ccheck\MFEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */