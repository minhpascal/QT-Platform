/*    */ package com.dukascopy.calculator.button;
/*    */ 
/*    */ import com.dukascopy.calculator.MainCalculatorPanel;
/*    */ import com.dukascopy.calculator.function.Off;
/*    */ import java.awt.event.ActionEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OffButton
/*    */   extends CalculatorButton
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public OffButton(MainCalculatorPanel mainCalculatorPanel)
/*    */   {
/* 19 */     this.mainCalculatorPanel = mainCalculatorPanel;
/* 20 */     setPobject(new Off());
/* 21 */     setText();
/* 22 */     setTextSize();
/* 23 */     addActionListener(this);
/*    */     
/* 25 */     setShortcut('Q');
/* 26 */     setToolTipKey("sc.calculator.switch.off");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent actionEvent)
/*    */   {
/* 36 */     synchronized (this.mainCalculatorPanel) {
/* 37 */       getMainCalculatorPanel().setOn(false);
/* 38 */       getMainCalculatorPanel().clearHistory();
/* 39 */       getMainCalculatorPanel().setShift(false);
/* 40 */       getMainCalculatorPanel().updateDisplay(true, true);
/*    */     }
/* 42 */     getMainCalculatorPanel().requestFocusInWindow();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\calculator\button\OffButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */