/*    */ package com.dukascopy.api.impl.execution.handler;
/*    */ 
/*    */ import com.dukascopy.api.impl.connect.PlatformMessageImpl;
/*    */ import com.dukascopy.api.impl.connect.WithdrawalMessageImpl;
/*    */ import com.dukascopy.charts.data.datacache.FeedDataProvider;
/*    */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WithdrawalNotificationHandler
/*    */   implements INotificationHandler
/*    */ {
/*    */   private static final String SUFFIX_DONE = "has been done.";
/*    */   private static final String SUFFIX_SCHEDULED = "will be executed at the following settlement.";
/* 27 */   private static final String NOTIFICATIOIN_STRICT_REGEX = String.format("^Withdrawal of\\s*+[-\\.\\d]++ [A-Z]{3} on account #*+\\d++ %s$", new Object[] { "has been done.", "will be executed at the following settlement." });
/* 28 */   private static final String NOTIFICATIOIN_LENIENT_REGEX = String.format("^Withdrawal of.*[(%s)|(%s)]++$", new Object[] { "has been done.", "will be executed at the following settlement." });
/* 29 */   private static final Pattern NOTIFICATION_PATTERN = Pattern.compile(NOTIFICATIOIN_LENIENT_REGEX, 2);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean canHandle(NotificationMessage notificationMessage)
/*    */   {
/* 37 */     String text = notificationMessage.getText();
/* 38 */     return NOTIFICATION_PATTERN.matcher(text).matches();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PlatformMessageImpl handleNotificationMessage(NotificationMessage notificationMessage)
/*    */   {
/* 46 */     WithdrawalMessageImpl message = null;
/* 47 */     if (canHandle(notificationMessage)) {
/* 48 */       String text = notificationMessage.getText();
/* 49 */       String regex = "\\b\\d++";
/* 50 */       Pattern pattern = Pattern.compile(regex);
/* 51 */       Matcher matcher = pattern.matcher(text);
/* 52 */       int i = 0;
/* 53 */       String[] groups = new String[2];
/* 54 */       while ((matcher.find()) && (i < groups.length)) {
/* 55 */         groups[(i++)] = matcher.group();
/*    */       }
/* 57 */       message = new WithdrawalMessageImpl(groups[1], Double.parseDouble(groups[0]), text.endsWith("will be executed at the following settlement."), text, FeedDataProvider.getDefaultInstance().getCurrentTime());
/*    */     }
/* 59 */     return message;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\handler\WithdrawalNotificationHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */