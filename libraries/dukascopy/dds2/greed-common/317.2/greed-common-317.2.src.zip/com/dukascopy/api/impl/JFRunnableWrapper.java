/*     */ package com.dukascopy.api.impl;
/*     */ 
/*     */ import com.dukascopy.api.Configurable;
/*     */ import com.dukascopy.api.CustomIndicators;
/*     */ import com.dukascopy.api.IJFRunnable;
/*     */ import com.dukascopy.api.Library;
/*     */ import com.dukascopy.api.RequiresFullAccess;
/*     */ import com.dukascopy.dds2.greed.agent.compiler.JFXPack;
/*     */ import com.dukascopy.dds2.greed.agent.strategy.bean.JFRunnableBean;
/*     */ import com.dukascopy.dds2.greed.util.FullAccessDisclaimerProvider;
/*     */ import com.dukascopy.dds2.greed.util.IFullAccessDisclaimer;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.security.GeneralSecurityException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JFRunnableWrapper<T extends IJFRunnable<?>>
/*     */   extends ServiceWrapper
/*     */ {
/*  23 */   protected T jfRunnable = null;
/*  24 */   protected JFXPack pack = null;
/*     */   
/*     */   protected JFRunnableBean<T, ?> bean;
/*     */   
/*     */   public void setBean(JFRunnableBean<T, ?> bean)
/*     */   {
/*  30 */     this.bean = bean;
/*     */   }
/*     */   
/*     */   public JFRunnableBean<T, ?> getBean() {
/*  34 */     return this.bean;
/*     */   }
/*     */   
/*     */   public T getJFRunnable(boolean hasToReload) throws Exception {
/*  38 */     if ((this.jfRunnable == null) || (hasToReload)) {
/*  39 */       this.pack = loadFromPack();
/*  40 */       if (this.pack != null) {
/*  41 */         if (this.pack.isFullAccessRequested()) {
/*  42 */           FullAccessDisclaimerProvider.getDisclaimer().showDialog(this.pack);
/*     */         }
/*  44 */         if (this.pack != null) {
/*  45 */           this.jfRunnable = getTarget();
/*     */         }
/*     */       }
/*     */     }
/*  49 */     return this.jfRunnable;
/*     */   }
/*     */   
/*     */   public T getJFRunnable(boolean hasToReload, boolean fullAccessGranted) throws Exception {
/*  53 */     if ((this.jfRunnable == null) || (hasToReload)) {
/*  54 */       this.pack = loadFromPack();
/*  55 */       if (this.pack != null) {
/*  56 */         if ((this.pack.isFullAccessRequested()) && 
/*  57 */           (fullAccessGranted)) {
/*  58 */           this.pack.setFullAccess(fullAccessGranted);
/*     */         }
/*     */         
/*  61 */         if (this.pack != null) {
/*  62 */           this.jfRunnable = getTarget();
/*     */         }
/*     */       }
/*     */     }
/*  66 */     return this.jfRunnable;
/*     */   }
/*     */   
/*     */   public T getJFRunnable() throws Exception {
/*  70 */     if (this.jfRunnable == null) {
/*  71 */       throw new Exception("Init the runnable first");
/*     */     }
/*  73 */     return this.jfRunnable;
/*     */   }
/*     */   
/*     */   protected T getTarget() {
/*  77 */     return (IJFRunnable)this.pack.getTarget();
/*     */   }
/*     */   
/*     */   protected JFXPack loadFromPack() throws IOException, GeneralSecurityException {
/*  81 */     return JFXPack.loadFromPack(getBinaryFile());
/*     */   }
/*     */   
/*     */   public String getNameNoExtension() {
/*  85 */     return getName().lastIndexOf('.') > -1 ? getName().substring(0, getName().lastIndexOf('.')) : getName();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStrategyKey()
/*     */   {
/*  91 */     return getName() + " " + this.pack.getMD5HexString();
/*     */   }
/*     */   
/*     */   public String getMD5HexStringOfJFXPack() {
/*  95 */     return this.pack.getMD5HexString();
/*     */   }
/*     */   
/*     */   public boolean isFullAccessGranted() {
/*  99 */     return (this.jfRunnable != null) && (this.pack != null) && (this.pack.isFullAccess());
/*     */   }
/*     */   
/*     */   public ClassLoader getClassLoader() {
/* 103 */     return this.pack.getClassLoader();
/*     */   }
/*     */   
/*     */   public boolean isAnnotated() throws Exception {
/* 107 */     if (this.jfRunnable != null) {
/* 108 */       T strategy = getJFRunnable();
/*     */       
/* 110 */       if (strategy != null) {
/* 111 */         for (Field field : strategy.getClass().getFields()) {
/* 112 */           for (Annotation annotation : field.getAnnotations()) {
/* 113 */             if ((annotation.annotationType().equals(Configurable.class)) || (annotation.annotationType().equals(Library.class)) || (annotation.annotationType().equals(CustomIndicators.class)) || (annotation.annotationType().equals(RequiresFullAccess.class)))
/*     */             {
/*     */ 
/*     */ 
/* 117 */               return true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isFullAccessRequested() throws Exception {
/* 127 */     File binaryFile = getBinaryFile();
/* 128 */     if (binaryFile != null) {
/* 129 */       return loadFromPack().isFullAccessRequested();
/*     */     }
/* 131 */     return false;
/*     */   }
/*     */   
/*     */   public static String representError(Object str, Throwable ex)
/*     */   {
/* 136 */     Throwable throwable = null;
/* 137 */     if (ex.getCause() != null) {
/* 138 */       throwable = ex.getCause();
/*     */     } else {
/* 140 */       throwable = ex;
/*     */     }
/*     */     
/* 143 */     String msg = throwable.toString();
/*     */     
/* 145 */     StackTraceElement[] elements = throwable.getStackTrace();
/* 146 */     if ((elements != null) && (elements.length > 0)) {
/* 147 */       StackTraceElement element = elements[0];
/* 148 */       for (StackTraceElement stackTraceElement : elements) {
/* 149 */         if ((stackTraceElement != null) && (stackTraceElement.getClassName().equals(str.getClass().getName()))) {
/* 150 */           element = stackTraceElement;
/* 151 */           break;
/*     */         }
/*     */       }
/* 154 */       if (element != null) {
/* 155 */         msg = msg + " @ " + element;
/*     */       }
/*     */     }
/*     */     
/* 159 */     return msg;
/*     */   }
/*     */   
/*     */   public boolean isRemote() {
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isRemotelyRunnable()
/*     */   {
/* 168 */     return (getBinaryFile() != null) && (getBinaryFile().exists());
/*     */   }
/*     */   
/*     */   public String getOutputKey() {
/* 172 */     File binaryFile = getBinaryFile();
/* 173 */     if (binaryFile != null) {
/* 174 */       return binaryFile.getPath();
/*     */     }
/* 176 */     return getStrategyKey();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\JFRunnableWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */