/*     */ package com.dukascopy.api.impl.connect;
/*     */ 
/*     */ import com.dukascopy.api.ICurrency;
/*     */ import com.dukascopy.api.IDailyHighLowListener;
/*     */ import com.dukascopy.api.IFXSentimentIndex;
/*     */ import com.dukascopy.api.IFXSentimentIndexBar;
/*     */ import com.dukascopy.api.IHighLowListener;
/*     */ import com.dukascopy.api.ITimeDomain;
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.JFCurrency;
/*     */ import com.dukascopy.api.JFException;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.PriceRange;
/*     */ import com.dukascopy.api.ReversalAmount;
/*     */ import com.dukascopy.api.feed.DataInterpolationDescriptor;
/*     */ import com.dukascopy.api.feed.IFeedDescriptor;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.filtering.IFilterManager;
/*     */ import com.dukascopy.charts.data.datacache.hl.ICommonHighLowListener;
/*     */ import com.dukascopy.charts.data.datacache.wrapper.ITimeInterval;
/*     */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*     */ import java.util.Collection;
/*     */ import java.util.Currency;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class JForexDataService implements com.dukascopy.api.IDataService
/*     */ {
/*  34 */   private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(JForexDataService.class);
/*     */   
/*     */   private final IFeedDataProvider feedDataProvider;
/*     */   
/*     */   private final IFilterManager filterManager;
/*     */   private final JFRunnableProcessor strategyProcessor;
/*     */   private final Properties serverProperties;
/*     */   private com.dukascopy.api.IWLabelData whiteLabelData;
/*  42 */   private static final Period MIN_SENTIMENT_INDEX_PERIOD = Period.THIRTY_MINS;
/*     */   protected Map<Period, JForexHighLowManager> highLowManagersByPeriod;
/*     */   
/*     */   public JForexDataService(IFeedDataProvider feedDataProvider, Properties serverProperties)
/*     */   {
/*  47 */     this(feedDataProvider, serverProperties, null);
/*     */   }
/*     */   
/*     */   public JForexDataService(IFeedDataProvider feedDataProvider, Properties serverProperties, JFRunnableProcessor strategyProcessor) {
/*  51 */     if (feedDataProvider == null) {
/*  52 */       throw new IllegalArgumentException("FeedDataProvider must not be null.");
/*     */     }
/*  54 */     this.feedDataProvider = feedDataProvider;
/*  55 */     this.filterManager = feedDataProvider.getFilterManager();
/*  56 */     this.strategyProcessor = strategyProcessor;
/*  57 */     this.highLowManagersByPeriod = new java.util.concurrent.ConcurrentHashMap();
/*  58 */     this.serverProperties = (serverProperties == null ? new Properties() : serverProperties);
/*     */     try {
/*  60 */       java.security.AccessController.doPrivileged(new java.security.PrivilegedExceptionAction()
/*     */       {
/*     */         public Void run() {
/*  63 */           JForexDataService.this.whiteLabelData = new WLabelData(JForexDataService.this.serverProperties);
/*  64 */           return null;
/*     */         }
/*     */       });
/*     */     } catch (Throwable e) {
/*  68 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addDailyHighLowListener(Instrument instrument, IDailyHighLowListener listener)
/*     */   {
/*  74 */     addHighLowListener(Period.DAILY, instrument, listener);
/*     */   }
/*     */   
/*     */   public void removeDailyHighLowListener(IDailyHighLowListener listener)
/*     */   {
/*  79 */     removeHighLowListener(listener);
/*     */   }
/*     */   
/*     */   public Collection<IDailyHighLowListener> getDailyHighLowListeners(Instrument instrument)
/*     */   {
/*  84 */     Collection<IHighLowListener> highLowListeners = getHighLowListeners(Period.DAILY, instrument);
/*  85 */     List<IDailyHighLowListener> dailyHighLowListeners = new java.util.ArrayList();
/*  86 */     for (IHighLowListener highLowListener : highLowListeners) {
/*  87 */       if ((highLowListener instanceof IDailyHighLowListener)) {
/*  88 */         dailyHighLowListeners.add(IDailyHighLowListener.class.cast(highLowListener));
/*     */       }
/*     */     }
/*  91 */     return dailyHighLowListeners;
/*     */   }
/*     */   
/*     */   public Map<Instrument, Collection<IDailyHighLowListener>> getDailyHighLowListeners()
/*     */   {
/*  96 */     JForexHighLowManager highLowManager = getHighLowManager(Period.DAILY);
/*  97 */     Map<Instrument, List<ICommonHighLowListener>> highLowListenerMap = highLowManager.getHighLowListeners();
/*  98 */     Map<Instrument, Collection<IDailyHighLowListener>> dailyHighLowListenerMap = new HashMap(highLowListenerMap.size());
/*  99 */     for (Map.Entry<Instrument, List<ICommonHighLowListener>> entry : highLowListenerMap.entrySet()) {
/* 100 */       Instrument instrument = (Instrument)entry.getKey();
/* 101 */       dailyHighLowListenerMap.put(instrument, getDailyHighLowListeners(instrument));
/*     */     }
/* 103 */     return dailyHighLowListenerMap;
/*     */   }
/*     */   
/*     */   public void removeAllDailyHighLowListeners()
/*     */   {
/* 108 */     JForexHighLowManager highLowManager = getHighLowManager(Period.DAILY);
/* 109 */     highLowManager.removeAllListeners();
/*     */   }
/*     */   
/*     */   public void addHighLowListener(Period period, Instrument instrument, IHighLowListener listener)
/*     */   {
/* 114 */     if (listener == null) {
/* 115 */       return;
/*     */     }
/* 117 */     JForexHighLowManager highLowManager = getHighLowManager(period);
/* 118 */     highLowManager.addHighLowListener(instrument, new HighLowListener(listener));
/*     */   }
/*     */   
/*     */   public void removeHighLowListener(IHighLowListener listener)
/*     */   {
/* 123 */     if (listener == null) {
/* 124 */       return;
/*     */     }
/* 126 */     synchronized (this.highLowManagersByPeriod) {
/* 127 */       for (JForexHighLowManager highLowManager : this.highLowManagersByPeriod.values()) {
/* 128 */         highLowManager.removeHighLowListener(new HighLowListener(listener));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Collection<IHighLowListener> getHighLowListeners(Period period, Instrument instrument)
/*     */   {
/* 136 */     JForexHighLowManager highLowManager = getHighLowManager(period);
/* 137 */     return getHighLowListeners(highLowManager.getHighLowListeners(instrument));
/*     */   }
/*     */   
/*     */   public Map<Instrument, Collection<IHighLowListener>> getHighLowListeners(Period period)
/*     */   {
/* 142 */     JForexHighLowManager highLowManager = getHighLowManager(period);
/* 143 */     return getHighLowListeners(highLowManager);
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<Period, Map<Instrument, Collection<IHighLowListener>>> getHighLowListeners()
/*     */   {
/* 149 */     Map<Period, Map<Instrument, Collection<IHighLowListener>>> allHighLowListeners = new HashMap();
/* 150 */     synchronized (this.highLowManagersByPeriod) {
/* 151 */       for (Map.Entry<Period, JForexHighLowManager> managerByPeriod : this.highLowManagersByPeriod.entrySet()) {
/* 152 */         Map<Instrument, Collection<IHighLowListener>> highLowListenerMap = getHighLowListeners((JForexHighLowManager)managerByPeriod.getValue());
/* 153 */         allHighLowListeners.put(managerByPeriod.getKey(), highLowListenerMap);
/*     */       }
/*     */     }
/* 156 */     return allHighLowListeners;
/*     */   }
/*     */   
/*     */   public void removeAllHighLowListeners()
/*     */   {
/* 161 */     synchronized (this.highLowManagersByPeriod) {
/* 162 */       for (JForexHighLowManager highLowManager : this.highLowManagersByPeriod.values()) {
/* 163 */         highLowManager.removeAllListeners();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstCandle(IFeedDescriptor feedDescriptor)
/*     */   {
/* 170 */     long firstTime = Long.MAX_VALUE;
/* 171 */     if (feedDescriptor == null) {
/* 172 */       LOGGER.error("FeedDescriptor is null");
/* 173 */       return firstTime;
/*     */     }
/* 175 */     Instrument instrument = feedDescriptor.getInstrument();
/* 176 */     Period period = feedDescriptor.getPeriod();
/* 177 */     PriceRange priceRange = feedDescriptor.getPriceRange();
/* 178 */     ReversalAmount reversalAmount = feedDescriptor.getReversalAmount();
/*     */     
/* 180 */     switch (feedDescriptor.getDataType()) {
/*     */     case TICKS: 
/* 182 */       firstTime = getTimeOfFirstTick(instrument);
/* 183 */       break;
/*     */     case TICK_BAR: 
/* 185 */       firstTime = getTimeOfFirstTickBar(instrument);
/* 186 */       break;
/*     */     case TIME_PERIOD_AGGREGATION: 
/* 188 */       firstTime = getTimeOfFirstCandle(instrument, period);
/* 189 */       break;
/*     */     case PRICE_RANGE_AGGREGATION: 
/* 191 */       firstTime = getTimeOfFirstRangeBar(instrument, priceRange);
/* 192 */       break;
/*     */     case POINT_AND_FIGURE: 
/* 194 */       firstTime = getTimeOfFirstPointAndFigure(instrument, priceRange, reversalAmount);
/* 195 */       break;
/*     */     case RENKO: 
/* 197 */       firstTime = getTimeOfFirstRenko(instrument, priceRange);
/* 198 */       break;
/*     */     default: 
/* 200 */       LOGGER.error("Illegal DataType: {}", feedDescriptor.getDataType());
/*     */     }
/* 202 */     return firstTime;
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstTick(Instrument instrument)
/*     */   {
/* 207 */     return this.feedDataProvider.getTimeOfFirstTick(instrument);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTimeOfFirstTickBar(Instrument instrument)
/*     */   {
/* 215 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, com.dukascopy.api.TickBarSize.TWO);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstCandle(Instrument instrument, Period period)
/*     */   {
/* 220 */     return this.feedDataProvider.getTimeOfFirstCandle(instrument, period);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstRangeBar(Instrument instrument, PriceRange priceRange)
/*     */   {
/* 225 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, priceRange, DataInterpolationDescriptor.DEFAULT);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstPointAndFigure(Instrument instrument, PriceRange priceRange, ReversalAmount reversalAmount)
/*     */   {
/* 230 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, priceRange, reversalAmount, DataInterpolationDescriptor.DEFAULT);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstRenko(Instrument instrument, PriceRange priceRange)
/*     */   {
/* 235 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, Period.TICK);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstRangeBar(Instrument instrument, PriceRange priceRange, DataInterpolationDescriptor dataInterpolationDescriptor)
/*     */   {
/* 240 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, priceRange, dataInterpolationDescriptor);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstPointAndFigure(Instrument instrument, PriceRange priceRange, ReversalAmount reversalAmount, DataInterpolationDescriptor dataInterpolationDescriptor)
/*     */   {
/* 245 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, priceRange, reversalAmount, dataInterpolationDescriptor);
/*     */   }
/*     */   
/*     */   public long getTimeOfFirstRenko(Instrument instrument, Period renkoSession)
/*     */   {
/* 250 */     return this.feedDataProvider.getTimeOfFirstBar(instrument, renkoSession);
/*     */   }
/*     */   
/*     */   public IFXSentimentIndex getFXSentimentIndex(Instrument instrument)
/*     */   {
/* 255 */     return getFXSentimentIndex(instrument, System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   public IFXSentimentIndex getFXSentimentIndex(Instrument instrument, long time)
/*     */   {
/* 260 */     return adjustTimeAndGetFXSentimentIndex(instrument, time);
/*     */   }
/*     */   
/*     */   public List<IFXSentimentIndexBar> getFXSentimentIndex(Instrument instrument, Period period, long from, long to) throws JFException
/*     */   {
/* 265 */     return this.feedDataProvider.getFXSentimentIndex(instrument, period, from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IFXSentimentIndex getFXSentimentIndex(Currency currency)
/*     */   {
/* 272 */     ICurrency jfCurrency = JFCurrency.getInstance(currency.getCurrencyCode());
/* 273 */     return getFXSentimentIndex(jfCurrency);
/*     */   }
/*     */   
/*     */   public IFXSentimentIndex getFXSentimentIndex(Currency currency, long time)
/*     */   {
/* 278 */     ICurrency jfCurrency = JFCurrency.getInstance(currency.getCurrencyCode());
/* 279 */     return getFXSentimentIndex(jfCurrency, time);
/*     */   }
/*     */   
/*     */   public List<IFXSentimentIndexBar> getFXSentimentIndex(Currency currency, Period period, long from, long to) throws JFException
/*     */   {
/* 284 */     ICurrency jfCurrency = JFCurrency.getInstance(currency.getCurrencyCode());
/* 285 */     return getFXSentimentIndex(jfCurrency, period, from, to);
/*     */   }
/*     */   
/*     */   public IFXSentimentIndex getFXSentimentIndex(ICurrency currency)
/*     */   {
/* 290 */     return getFXSentimentIndex(currency, System.currentTimeMillis());
/*     */   }
/*     */   
/*     */   public IFXSentimentIndex getFXSentimentIndex(ICurrency currency, long time)
/*     */   {
/* 295 */     return adjustTimeAndGetFXSentimentIndex(currency, time);
/*     */   }
/*     */   
/*     */   public List<IFXSentimentIndexBar> getFXSentimentIndex(ICurrency currency, Period period, long from, long to) throws JFException {
/* 299 */     return this.feedDataProvider.getFXSentimentIndex(currency, period, from, to);
/*     */   }
/*     */   
/*     */   public boolean isOfflineTime(long time)
/*     */   {
/* 304 */     return this.filterManager.isWeekendTime(time);
/*     */   }
/*     */   
/*     */   public Set<ITimeDomain> getOfflineTimeDomains(long from, long to) throws JFException
/*     */   {
/* 309 */     Set<ITimeDomain> timeDomains = new java.util.TreeSet();
/* 310 */     ITimeInterval[] weekends = this.filterManager.getWeekends(from, to);
/* 311 */     for (ITimeInterval weekend : weekends) {
/* 312 */       timeDomains.add(new TimeDomain(weekend));
/*     */     }
/* 314 */     return timeDomains;
/*     */   }
/*     */   
/*     */   public ITimeDomain getOfflineTimeDomain() throws JFException
/*     */   {
/* 319 */     return getOfflineTimeDomain(0);
/*     */   }
/*     */   
/*     */   public ITimeDomain getOfflineTimeDomain(int shift) throws JFException
/*     */   {
/* 324 */     return getOfflineTimeDomain(shift, this.feedDataProvider.getEstimatedServerOrLocalTime());
/*     */   }
/*     */   
/*     */   public com.dukascopy.api.IWLabelData getWhiteLabelData()
/*     */   {
/* 329 */     return this.whiteLabelData;
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, Object> getServerProperties()
/*     */   {
/* 335 */     Properties properties = (Properties)org.apache.commons.lang3.SerializationUtils.clone(this.serverProperties);
/* 336 */     Map<String, ?> result = new HashMap(properties.size());
/* 337 */     result.putAll(properties);
/* 338 */     return java.util.Collections.unmodifiableMap(result);
/*     */   }
/*     */   
/*     */   protected JForexHighLowManager getHighLowManager(Period period) {
/* 342 */     synchronized (this.highLowManagersByPeriod) {
/* 343 */       JForexHighLowManager highLowManager = (JForexHighLowManager)this.highLowManagersByPeriod.get(period);
/* 344 */       if (highLowManager == null) {
/* 345 */         highLowManager = new JForexHighLowManager(this.feedDataProvider.getHighLowManager(period));
/* 346 */         this.highLowManagersByPeriod.put(period, highLowManager);
/* 347 */         if (this.strategyProcessor != null) {
/* 348 */           this.strategyProcessor.getTaskManager().addStrategyListener(highLowManager);
/*     */         }
/*     */       }
/* 351 */       return highLowManager;
/*     */     }
/*     */   }
/*     */   
/*     */   protected ITimeDomain getOfflineTimeDomain(int shift, long localTime) throws JFException {
/* 356 */     long week = java.util.concurrent.TimeUnit.DAYS.toMillis(7L);
/* 357 */     final long from = localTime + shift * week;
/* 358 */     long to = from + week;
/*     */     try
/*     */     {
/* 361 */       (ITimeDomain)java.security.AccessController.doPrivileged(new java.security.PrivilegedExceptionAction()
/*     */       {
/*     */         public ITimeDomain run() throws Exception {
/* 364 */           JForexDataService.TimeDomain result = null;
/* 365 */           ITimeInterval[] weekends = JForexDataService.this.filterManager.getWeekends(from, this.val$to);
/* 366 */           if (!ObjectUtils.isNullOrEmpty(weekends)) {
/* 367 */             result = new JForexDataService.TimeDomain(JForexDataService.this, weekends[0]);
/*     */           }
/* 369 */           return result;
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 375 */       throw new JFException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<IHighLowListener> getHighLowListeners(List<ICommonHighLowListener> highLowListenerList)
/*     */   {
/* 381 */     List<IHighLowListener> result = new java.util.ArrayList(highLowListenerList.size());
/* 382 */     for (ICommonHighLowListener highLowListener : highLowListenerList) {
/* 383 */       if ((highLowListener instanceof HighLowListener)) {
/* 384 */         result.add(((HighLowListener)HighLowListener.class.cast(highLowListener)).highLowListener);
/*     */       }
/*     */     }
/* 387 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<Instrument, Collection<IHighLowListener>> getHighLowListeners(JForexHighLowManager highLowManager)
/*     */   {
/* 395 */     Map<Instrument, List<ICommonHighLowListener>> commonHighLowListenerMap = highLowManager.getHighLowListeners();
/* 396 */     Map<Instrument, Collection<IHighLowListener>> highLowListenerMap = new HashMap(commonHighLowListenerMap.size());
/* 397 */     for (Map.Entry<Instrument, List<ICommonHighLowListener>> entry : commonHighLowListenerMap.entrySet()) {
/* 398 */       Instrument instrument = (Instrument)entry.getKey();
/* 399 */       highLowListenerMap.put(instrument, getHighLowListeners((List)entry.getValue()));
/*     */     }
/*     */     
/* 402 */     return highLowListenerMap;
/*     */   }
/*     */   
/*     */ 
/*     */   private class HighLowListener
/*     */     implements ICommonHighLowListener
/*     */   {
/*     */     private IHighLowListener highLowListener;
/*     */     
/*     */     public HighLowListener(IHighLowListener highLowListener)
/*     */     {
/* 413 */       this.highLowListener = highLowListener;
/*     */     }
/*     */     
/*     */ 
/*     */     public void highUpdated(Instrument instrument, Period period, double high)
/*     */     {
/* 419 */       this.highLowListener.highUpdated(instrument, high);
/*     */     }
/*     */     
/*     */ 
/*     */     public void lowUpdated(Instrument instrument, Period period, double low)
/*     */     {
/* 425 */       this.highLowListener.lowUpdated(instrument, low);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 430 */       return ObjectUtils.getHash(this.highLowListener);
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 435 */       return ObjectUtils.isEqual(this.highLowListener, ((HighLowListener)HighLowListener.class.cast(obj)).highLowListener);
/*     */     }
/*     */   }
/*     */   
/*     */   private class TimeDomain implements ITimeDomain, Comparable<TimeDomain>
/*     */   {
/*     */     private ITimeInterval timeInterval;
/*     */     
/*     */     public TimeDomain(ITimeInterval timeInterval)
/*     */     {
/* 445 */       this.timeInterval = timeInterval;
/*     */     }
/*     */     
/*     */     public long getStart()
/*     */     {
/* 450 */       return this.timeInterval.getStart();
/*     */     }
/*     */     
/*     */     public long getEnd()
/*     */     {
/* 455 */       return this.timeInterval.getEnd();
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 460 */       int prime = 31;
/* 461 */       int result = 1;
/* 462 */       result = 31 * result + getOuterType().hashCode();
/* 463 */       result = 31 * result + (this.timeInterval == null ? 0 : this.timeInterval.hashCode());
/* 464 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 469 */       if (this == obj)
/* 470 */         return true;
/* 471 */       if (obj == null)
/* 472 */         return false;
/* 473 */       if (getClass() != obj.getClass())
/* 474 */         return false;
/* 475 */       TimeDomain other = (TimeDomain)obj;
/* 476 */       if (!getOuterType().equals(other.getOuterType()))
/* 477 */         return false;
/* 478 */       if (this.timeInterval == null) {
/* 479 */         if (other.timeInterval != null)
/* 480 */           return false;
/* 481 */       } else if (!this.timeInterval.isIntervalTheSame(other.timeInterval))
/* 482 */         return false;
/* 483 */       return true;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 488 */       return "TimeDomain [" + this.timeInterval + "]";
/*     */     }
/*     */     
/*     */     public int compareTo(TimeDomain o)
/*     */     {
/* 493 */       if (getStart() < o.getStart())
/* 494 */         return -1;
/* 495 */       if (getStart() > o.getStart())
/* 496 */         return 1;
/* 497 */       if (getEnd() < o.getEnd())
/* 498 */         return -1;
/* 499 */       if (getEnd() > o.getEnd()) {
/* 500 */         return 1;
/*     */       }
/* 502 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */     private JForexDataService getOuterType()
/*     */     {
/* 508 */       return JForexDataService.this;
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> IFXSentimentIndex adjustTimeAndGetFXSentimentIndex(T indexInstrument, long time) {
/* 513 */     IFXSentimentIndex result = null;
/*     */     try
/*     */     {
/* 516 */       time -= time % MIN_SENTIMENT_INDEX_PERIOD.getInterval();
/* 517 */       List<IFXSentimentIndexBar> fxSentimentIndices = this.feedDataProvider.getFXSentimentIndex(indexInstrument, MIN_SENTIMENT_INDEX_PERIOD, time, time);
/* 518 */       if (!ObjectUtils.isNullOrEmpty(fxSentimentIndices)) {
/* 519 */         final IFXSentimentIndexBar fxBar = (IFXSentimentIndexBar)fxSentimentIndices.get(fxSentimentIndices.size() - 1);
/* 520 */         result = new com.dukascopy.charts.data.datacache.sentimentindex.AbstractFXSentimentIndex()
/*     */         {
/*     */           public long getIndexTime()
/*     */           {
/* 524 */             return fxBar.getIndexTime();
/*     */           }
/*     */           
/*     */           public double getIndexValue()
/*     */           {
/* 529 */             return fxBar.getClose();
/*     */           }
/*     */         };
/*     */       }
/*     */     }
/*     */     catch (JFException e) {
/* 535 */       LOGGER.error("Unable to load FXSentiment Index", e);
/*     */     }
/* 537 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\connect\JForexDataService.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */