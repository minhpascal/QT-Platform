/*    */ package com.dukascopy.charts.data.datacache.filtering;
/*    */ 
/*    */ import com.dukascopy.charts.data.datacache.DataCacheException;
/*    */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*    */ import com.dukascopy.charts.data.datacache.wrapper.ITimeInterval;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TesterFilterManager
/*    */   extends FilterManager
/*    */ {
/*    */   public TesterFilterManager(IFeedDataProvider feedDataProvider)
/*    */   {
/* 19 */     super(feedDataProvider);
/*    */   }
/*    */   
/*    */   protected List<ITimeInterval> calculatePreciseWeekendsBasedOnTicks(long from, long to) throws DataCacheException
/*    */   {
/* 24 */     return calculateApproximateWeekends(from, to);
/*    */   }
/*    */   
/*    */   protected long getServerTime()
/*    */   {
/* 29 */     return System.currentTimeMillis();
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\filtering\TesterFilterManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */