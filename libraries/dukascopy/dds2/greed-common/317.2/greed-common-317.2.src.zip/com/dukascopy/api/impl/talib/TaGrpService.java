package com.dukascopy.api.impl.talib;

import com.dukascopy.api.impl.TaLibMetaData;
import java.util.Set;

public abstract interface TaGrpService
{
  public abstract void execute(String paramString, Set<TaLibMetaData> paramSet)
    throws Exception;
}


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\talib\TaGrpService.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */