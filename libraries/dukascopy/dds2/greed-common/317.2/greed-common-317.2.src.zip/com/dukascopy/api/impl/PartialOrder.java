/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IPartialOrder;
/*    */ import com.dukascopy.api.util.DateUtils;
/*    */ import com.dukascopy.dds2.greed.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PartialOrder
/*    */   implements IPartialOrder
/*    */ {
/*    */   private long time;
/*    */   private double price;
/*    */   private double amount;
/*    */   
/*    */   public PartialOrder(long time, double price, double amount)
/*    */   {
/* 22 */     this.time = time;
/* 23 */     this.price = price;
/* 24 */     this.amount = amount;
/*    */   }
/*    */   
/*    */   public long getTime()
/*    */   {
/* 29 */     return this.time;
/*    */   }
/*    */   
/*    */   public double getPrice()
/*    */   {
/* 34 */     return this.price;
/*    */   }
/*    */   
/*    */   public double getAmount()
/*    */   {
/* 39 */     return this.amount;
/*    */   }
/*    */   
/*    */   public void setTime(long time) {
/* 43 */     this.time = time;
/*    */   }
/*    */   
/*    */   public void setPrice(double price) {
/* 47 */     this.price = price;
/*    */   }
/*    */   
/*    */   public void setAmount(double amount) {
/* 51 */     this.amount = amount;
/*    */   }
/*    */   
/*    */   public int compareTo(IPartialOrder other)
/*    */   {
/* 56 */     if (other == null) {
/* 57 */       return 1;
/*    */     }
/* 59 */     return ObjectUtils.compare(Long.valueOf(getTime()), Long.valueOf(other.getTime()));
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 64 */     return String.format("[time=%s, price=%s, amount=%s]", new Object[] { DateUtils.formatToSeconds(this.time), Double.valueOf(this.price), Double.valueOf(this.amount) });
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\PartialOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */