/*    */ package com.dukascopy.api.impl;
/*    */ 
/*    */ import com.dukascopy.api.IFillOrder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FillOrder
/*    */   extends PartialOrder
/*    */   implements IFillOrder
/*    */ {
/*    */   public FillOrder(long time, double price, double amount)
/*    */   {
/* 15 */     super(time, price, amount);
/*    */   }
/*    */   
/*    */   public FillOrder(PartialOrder partialOrder) {
/* 19 */     super(partialOrder.getTime(), partialOrder.getPrice(), partialOrder.getAmount());
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\FillOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */