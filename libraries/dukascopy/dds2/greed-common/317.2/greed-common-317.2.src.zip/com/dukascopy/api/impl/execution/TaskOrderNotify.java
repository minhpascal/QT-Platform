/*     */ package com.dukascopy.api.impl.execution;
/*     */ 
/*     */ import com.dukascopy.api.IMessage;
/*     */ import com.dukascopy.api.impl.StrategyEventsCallback;
/*     */ import com.dukascopy.api.impl.connect.JForexTaskManager;
/*     */ import com.dukascopy.api.impl.connect.OrdersInternalCollection;
/*     */ import com.dukascopy.api.impl.connect.PlatformOrderImpl;
/*     */ import com.dukascopy.api.plugins.IMessageListener;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler;
/*     */ import com.dukascopy.api.system.IStrategyExceptionHandler.Source;
/*     */ import com.dukascopy.dds2.greed.strategy.ErrorHelper;
/*     */ import com.dukascopy.dds2.greed.util.INotificationUtils;
/*     */ import com.dukascopy.dds2.greed.util.NotificationUtilsProvider;
/*     */ import com.dukascopy.dds3.transport.msg.ord.NotificationMessage;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskOrderNotify
/*     */   implements Task<Void>
/*     */ {
/*  25 */   private static final Logger LOGGER = LoggerFactory.getLogger(TaskOrderNotify.class);
/*     */   private JForexTaskManager taskManager;
/*     */   private IMessageListener strategy;
/*     */   private NotificationMessage notificationMessage;
/*     */   private StrategyEventsCallback strategyEventsCallback;
/*     */   
/*     */   public TaskOrderNotify(JForexTaskManager taskManager, IMessageListener strategy, NotificationMessage notificationMessage)
/*     */   {
/*  33 */     this.strategy = strategy;
/*  34 */     this.notificationMessage = notificationMessage;
/*  35 */     this.taskManager = taskManager;
/*  36 */     this.strategyEventsCallback = taskManager.getStrategyEventsCallback();
/*     */   }
/*     */   
/*     */   public Task.Type getType()
/*     */   {
/*  41 */     return Task.Type.MESSAGE;
/*     */   }
/*     */   
/*     */   public Void call() throws Exception
/*     */   {
/*  46 */     if (this.taskManager.isStrategyStopping()) {
/*  47 */       return null;
/*     */     }
/*  49 */     if (LOGGER.isDebugEnabled()) {
/*  50 */       LOGGER.debug("Starting processing of notify message [" + this.notificationMessage + "]");
/*     */     }
/*     */     try {
/*  53 */       OrdersInternalCollection ordersInternalCollection = this.taskManager.getOrdersInternalCollection();
/*  54 */       PlatformOrderImpl platformOrderImpl = null;
/*  55 */       if (this.taskManager.isGlobal())
/*     */       {
/*  57 */         String orderId = this.notificationMessage.getOrderId();
/*  58 */         if (orderId != null) {
/*  59 */           platformOrderImpl = ordersInternalCollection.getOrderByOpeningOrderId(orderId);
/*     */         }
/*     */       }
/*  62 */       else if (platformOrderImpl == null) {
/*  63 */         String positionId = this.notificationMessage.getOrderGroupId();
/*  64 */         if (positionId != null) {
/*  65 */           platformOrderImpl = ordersInternalCollection.getOrderById(positionId);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  70 */       if (platformOrderImpl == null) {
/*  71 */         String label = this.notificationMessage.getExternalSysId();
/*  72 */         platformOrderImpl = ordersInternalCollection.getOrderByLabel(label);
/*     */       }
/*     */       
/*  75 */       if (platformOrderImpl != null) {
/*  76 */         IMessage platformMessageImpl = platformOrderImpl.update(this.notificationMessage);
/*  77 */         if (platformMessageImpl != null) {
/*  78 */           this.strategy.onMessage(platformMessageImpl);
/*  79 */           if (this.strategyEventsCallback != null) {
/*  80 */             this.strategyEventsCallback.onMessage(platformMessageImpl);
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  86 */         String text = this.notificationMessage.getText();
/*  87 */         if ((text != null) && 
/*  88 */           (text.indexOf("Failed to merge positions") != -1)) {
/*  89 */           for (PlatformOrderImpl impl : ordersInternalCollection.getAllMergeTargets()) {
/*  90 */             this.notificationMessage.setExternalSysId(impl.getLabel());
/*  91 */             IMessage platformMessageImpl = impl.update(this.notificationMessage);
/*  92 */             if (platformMessageImpl != null) {
/*  93 */               this.strategy.onMessage(platformMessageImpl);
/*  94 */               if (this.strategyEventsCallback != null) {
/*  95 */                 this.strategyEventsCallback.onMessage(platformMessageImpl);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 103 */       String msg = ErrorHelper.representError(this.strategy, t);
/* 104 */       NotificationUtilsProvider.getNotificationUtils().postErrorMessage(msg, t, false);
/* 105 */       LOGGER.error(t.getMessage(), t);
/* 106 */       this.taskManager.getExceptionHandler().onException(this.taskManager.getStrategyId(), IStrategyExceptionHandler.Source.ON_MESSAGE, t);
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 113 */     return "TaskOrderNotify [" + this.notificationMessage + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\execution\TaskOrderNotify.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */