/*    */ package com.dukascopy.api.impl.util;
/*    */ 
/*    */ import com.dukascopy.api.IDownloadableStrategy.ComponentType;
/*    */ import com.dukascopy.api.JFException;
/*    */ import com.dukascopy.api.impl.connect.PlatformType;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceComponentDownloader
/*    */   extends ComponentDownloaderUtils
/*    */ {
/* 19 */   private static final Logger LOGGER = LoggerFactory.getLogger(SourceComponentDownloader.class);
/*    */   private static SourceComponentDownloader downloaderObject;
/*    */   
/*    */   public static SourceComponentDownloader getInstance() {
/* 23 */     if (downloaderObject == null) {
/* 24 */       downloaderObject = new SourceComponentDownloader();
/*    */     }
/* 26 */     return downloaderObject;
/*    */   }
/*    */   
/*    */   public byte[] downloadFile(String id, IDownloadableStrategy.ComponentType blockType) throws JFException {
/* 30 */     FileCache fileCache = (FileCache)fileCacheStorage.get(id);
/*    */     
/* 32 */     if ((blockType != IDownloadableStrategy.ComponentType.BLOCK_INDICATOR) && 
/* 33 */       (fileCache != null) && (fileCache.getSourceCache() != null)) {
/* 34 */       if (isVFStrategyUpdatedOnTheServer(id, true)) {
/* 35 */         LOGGER.info("The '" + fileCache.getFileName() + "' strategy updating ...");
/* 36 */         fileCache.setSourceCache(null);
/*    */       } else {
/* 38 */         return fileCache.getSourceCache();
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 43 */     return getComponentFromServer(id, blockType, fileCache);
/*    */   }
/*    */   
/*    */   private byte[] getComponentFromServer(String id, IDownloadableStrategy.ComponentType blockType, FileCache fileCache) throws JFException {
/* 47 */     Date modifiedTime = null;
/* 48 */     if (fileCache != null) {
/* 49 */       modifiedTime = fileCache.getLastSourceModifyTime();
/*    */     }
/* 51 */     String params = prepeareParamsForHttpRequest(blockType, modifiedTime != null);
/* 52 */     byte[] component = readComponentAsByteFromServer(id, params, modifiedTime);
/* 53 */     if ((component != null) && (component.length > 0)) {
/* 54 */       this.currentFileCache.setSourceCache(component);
/* 55 */       this.currentFileCache.setLastSourceModifyTime(this.strategyModifyDate);
/*    */       
/*    */ 
/* 58 */       if ((fileCache != null) && (fileCache.getCompiledCache() != null)) {
/* 59 */         this.currentFileCache.setCompiledCache(fileCache.getCompiledCache());
/* 60 */         this.currentFileCache.setLastBinaryModifyTime(fileCache.getLastBinaryModifyTime());
/*    */       }
/* 62 */       fileCacheStorage.put(id, this.currentFileCache);
/*    */     }
/* 64 */     else if ((fileCache != null) && (fileCache.getSourceCache() != null)) {
/* 65 */       component = fileCache.getSourceCache();
/*    */     }
/*    */     
/* 68 */     return component;
/*    */   }
/*    */   
/*    */   private String prepeareParamsForHttpRequest(IDownloadableStrategy.ComponentType blockType, boolean isModifiedTimeSpecified) { String paramsForHttpRequest;
/*    */     String paramsForHttpRequest;
/* 73 */     if (runningMode.equals(PlatformType.JSS)) { String paramsForHttpRequest;
/* 74 */       if (blockType == IDownloadableStrategy.ComponentType.BLOCK_OWN_STRATEGY) {
/* 75 */         paramsForHttpRequest = isModifiedTimeSpecified ? "protected/getProtectedUserStrategySrc?id={0}&login={1}&modifyDate={2}" : "protected/getProtectedUserStrategySrc?id={0}&login={1}";
/*    */       } else
/* 77 */         paramsForHttpRequest = isModifiedTimeSpecified ? "protected/getProtectedSourceFilePlatform?id={0}&login={1}&modifyDate={2}" : "protected/getProtectedSourceFilePlatform?id={0}&login={1}";
/*    */     } else {
/*    */       String paramsForHttpRequest;
/* 80 */       if (blockType == IDownloadableStrategy.ComponentType.BLOCK_OWN_STRATEGY) {
/* 81 */         paramsForHttpRequest = isModifiedTimeSpecified ? "getUserStrategySrc?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}&modifyDate={5}" : "getUserStrategySrc?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
/*    */       } else {
/* 83 */         paramsForHttpRequest = isModifiedTimeSpecified ? "getSourceFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}" : "getSourceFilePlatform?id={0}&login={1}&sessionid={2}&ticket={3}&scheme={4}";
/*    */       }
/*    */     }
/* 86 */     return paramsForHttpRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\api\impl\util\SourceComponentDownloader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */