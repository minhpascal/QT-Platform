/*     */ package com.dukascopy.charts.data.datacache.customticks;
/*     */ 
/*     */ import com.dukascopy.api.Instrument;
/*     */ import com.dukascopy.api.OfferSide;
/*     */ import com.dukascopy.api.Period;
/*     */ import com.dukascopy.api.util.DateUtils;
/*     */ import com.dukascopy.charts.data.datacache.DataCacheUtils;
/*     */ import com.dukascopy.charts.data.datacache.IFeedDataProvider;
/*     */ import com.dukascopy.charts.data.datacache.ILoadingProgressListener;
/*     */ import com.dukascopy.charts.data.datacache.LiveFeedListener;
/*     */ import com.dukascopy.charts.data.datacache.metadata.IFeedMetadataManager;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLoadCustomTicksFromCandlesAction
/*     */   extends AbstractLoadCustomTicksAction
/*     */ {
/*  24 */   private static final Logger LOGGER = LoggerFactory.getLogger(AbstractLoadCustomTicksFromCandlesAction.class);
/*     */   
/*     */ 
/*     */   protected final IFeedDataProvider feedDataProvider;
/*     */   
/*     */ 
/*     */   protected final Instrument instrument;
/*     */   
/*     */   protected final Period period;
/*     */   
/*     */   protected final OfferSide offerSide;
/*     */   
/*     */   protected final ILoadingProgressListener loadingProgressListener;
/*     */   
/*     */   protected final long candledFrom;
/*     */   
/*     */   protected final long candledTo;
/*     */   
/*     */ 
/*     */   public AbstractLoadCustomTicksFromCandlesAction(IFeedDataProvider feedDataProvider, Instrument instrument, Period period, OfferSide offerSide, long from, long to, ILoadingProgressListener loadingProgressListener)
/*     */   {
/*  45 */     super(from, to);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  50 */     this.feedDataProvider = feedDataProvider;
/*  51 */     this.instrument = instrument;
/*  52 */     this.period = period;
/*  53 */     this.offerSide = offerSide;
/*  54 */     this.loadingProgressListener = loadingProgressListener;
/*     */     
/*  56 */     this.candledFrom = DataCacheUtils.getCandleStartFast(period, from);
/*  57 */     this.candledTo = DataCacheUtils.getCandleStartFast(period, to);
/*     */     
/*  59 */     validateFromTo();
/*     */   }
/*     */   
/*     */   protected void validateFromTo() {
/*  63 */     long lastTickTime = this.feedDataProvider.getLastTickTime(this.instrument);
/*  64 */     if (this.to > lastTickTime) {
/*  65 */       throw new IllegalArgumentException("to(" + DateUtils.format(this.to) + ") > last tick time (" + DateUtils.format(lastTickTime) + " " + lastTickTime + ")");
/*     */     }
/*     */     
/*  68 */     long firstCandleTime = this.feedDataProvider.getFeedMetadataManager().getTimeOfFirstCandle(this.instrument, this.period);
/*  69 */     if (this.from < firstCandleTime) {
/*  70 */       throw new IllegalArgumentException("from(" + DateUtils.format(this.from) + ") < first candle time (" + DateUtils.format(firstCandleTime) + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*  76 */     LiveFeedListener feedListener = new LiveFeedListener()
/*     */     {
/*     */       public void newCandle(Instrument instrument, Period period, OfferSide side, long time, double open, double close, double low, double high, double vol) {
/*  79 */         AbstractLoadCustomTicksFromCandlesAction.this.candleReceived(time, open, close, low, high, vol);
/*     */       }
/*     */       
/*     */ 
/*     */       public void newTick(Instrument instrument, long time, double ask, double bid, double askVol, double bidVol) {}
/*     */     };
/*     */     try
/*     */     {
/*  87 */       this.feedDataProvider.loadCandlesDataBlockingSynched(this.instrument, this.period, this.offerSide, this.candledFrom, this.candledTo, feedListener, this.loadingProgressListener);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  97 */       LOGGER.error(e.getLocalizedMessage(), e);
/*  98 */       this.loadingProgressListener.loadingFinished(false, this.candledFrom, this.candledFrom, this.candledTo, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void candleReceived(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
/*     */   
/*     */   protected boolean isStop() {
/* 105 */     return this.loadingProgressListener.stopJob();
/*     */   }
/*     */ }


/* Location:              C:\Users\Miquel Sas\Eclipse\Luna\eclipse-workspaces\workspace-trading\Libraries\dukascopy\dds2\greed-common\317.2\greed-common-317.2.jar!\com\dukascopy\charts\data\datacache\customticks\AbstractLoadCustomTicksFromCandlesAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */